
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0040010 <applet_entry>:
d0040010:	b570      	push	{r4, r5, r6, lr}
d0040012:	4e09      	ldr	r6, [pc, #36]	; (d0040038 <applet_entry+0x28>)
d0040014:	460d      	mov	r5, r1
d0040016:	4604      	mov	r4, r0
d0040018:	2100      	movs	r1, #0
d004001a:	6833      	ldr	r3, [r6, #0]
d004001c:	6898      	ldr	r0, [r3, #8]
d004001e:	f001 fe07 	bl	d0041c30 <setbuf>
d0040022:	6833      	ldr	r3, [r6, #0]
d0040024:	2100      	movs	r1, #0
d0040026:	68d8      	ldr	r0, [r3, #12]
d0040028:	f001 fe02 	bl	d0041c30 <setbuf>
d004002c:	4629      	mov	r1, r5
d004002e:	4620      	mov	r0, r4
d0040030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0040034:	f000 be62 	b.w	d0040cfc <main>
d0040038:	d0042d40 	.word	0xd0042d40

d004003c <memset>:
d004003c:	4402      	add	r2, r0
d004003e:	4603      	mov	r3, r0
d0040040:	4293      	cmp	r3, r2
d0040042:	d100      	bne.n	d0040046 <memset+0xa>
d0040044:	4770      	bx	lr
d0040046:	f803 1b01 	strb.w	r1, [r3], #1
d004004a:	e7f9      	b.n	d0040040 <memset+0x4>

d004004c <LoadPPB>:
d004004c:	b5f0      	push	{r4, r5, r6, r7, lr}
d004004e:	4c28      	ldr	r4, [pc, #160]	; (d00400f0 <LoadPPB+0xa4>)
d0040050:	2600      	movs	r6, #0
d0040052:	f2ad 4d1c 	subw	sp, sp, #1052	; 0x41c
d0040056:	460f      	mov	r7, r1
d0040058:	7923      	ldrb	r3, [r4, #4]
d004005a:	4601      	mov	r1, r0
d004005c:	7965      	ldrb	r5, [r4, #5]
d004005e:	4630      	mov	r0, r6
d0040060:	f894 c006 	ldrb.w	ip, [r4, #6]
d0040064:	2201      	movs	r2, #1
d0040066:	ea43 2305 	orr.w	r3, r3, r5, lsl #8
d004006a:	79e5      	ldrb	r5, [r4, #7]
d004006c:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040070:	ea43 6305 	orr.w	r3, r3, r5, lsl #24
d0040074:	681b      	ldr	r3, [r3, #0]
d0040076:	681b      	ldr	r3, [r3, #0]
d0040078:	4798      	blx	r3
d004007a:	7925      	ldrb	r5, [r4, #4]
d004007c:	7961      	ldrb	r1, [r4, #5]
d004007e:	4630      	mov	r0, r6
d0040080:	79a2      	ldrb	r2, [r4, #6]
d0040082:	ab01      	add	r3, sp, #4
d0040084:	ea45 2501 	orr.w	r5, r5, r1, lsl #8
d0040088:	f894 c007 	ldrb.w	ip, [r4, #7]
d004008c:	a902      	add	r1, sp, #8
d004008e:	ea45 4502 	orr.w	r5, r5, r2, lsl #16
d0040092:	f44f 6282 	mov.w	r2, #1040	; 0x410
d0040096:	ea45 650c 	orr.w	r5, r5, ip, lsl #24
d004009a:	682d      	ldr	r5, [r5, #0]
d004009c:	68ad      	ldr	r5, [r5, #8]
d004009e:	47a8      	blx	r5
d00400a0:	7925      	ldrb	r5, [r4, #4]
d00400a2:	7962      	ldrb	r2, [r4, #5]
d00400a4:	4639      	mov	r1, r7
d00400a6:	79a7      	ldrb	r7, [r4, #6]
d00400a8:	ab01      	add	r3, sp, #4
d00400aa:	ea45 2502 	orr.w	r5, r5, r2, lsl #8
d00400ae:	f894 c007 	ldrb.w	ip, [r4, #7]
d00400b2:	f89d 2010 	ldrb.w	r2, [sp, #16]
d00400b6:	4630      	mov	r0, r6
d00400b8:	ea45 4507 	orr.w	r5, r5, r7, lsl #16
d00400bc:	9f03      	ldr	r7, [sp, #12]
d00400be:	0612      	lsls	r2, r2, #24
d00400c0:	ea45 650c 	orr.w	r5, r5, ip, lsl #24
d00400c4:	ea42 2217 	orr.w	r2, r2, r7, lsr #8
d00400c8:	682d      	ldr	r5, [r5, #0]
d00400ca:	68ad      	ldr	r5, [r5, #8]
d00400cc:	47a8      	blx	r5
d00400ce:	7923      	ldrb	r3, [r4, #4]
d00400d0:	7962      	ldrb	r2, [r4, #5]
d00400d2:	4630      	mov	r0, r6
d00400d4:	79a1      	ldrb	r1, [r4, #6]
d00400d6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00400da:	79e2      	ldrb	r2, [r4, #7]
d00400dc:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00400e0:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00400e4:	681b      	ldr	r3, [r3, #0]
d00400e6:	68db      	ldr	r3, [r3, #12]
d00400e8:	4798      	blx	r3
d00400ea:	f20d 4d1c 	addw	sp, sp, #1052	; 0x41c
d00400ee:	bdf0      	pop	{r4, r5, r6, r7, pc}
d00400f0:	2001f000 	.word	0x2001f000

d00400f4 <initMalloc>:
d00400f4:	4902      	ldr	r1, [pc, #8]	; (d0040100 <initMalloc+0xc>)
d00400f6:	4b03      	ldr	r3, [pc, #12]	; (d0040104 <initMalloc+0x10>)
d00400f8:	4a03      	ldr	r2, [pc, #12]	; (d0040108 <initMalloc+0x14>)
d00400fa:	1a5b      	subs	r3, r3, r1
d00400fc:	6013      	str	r3, [r2, #0]
d00400fe:	4770      	bx	lr
d0040100:	d0046458 	.word	0xd0046458
d0040104:	d0600000 	.word	0xd0600000
d0040108:	d0043614 	.word	0xd0043614

d004010c <_write_r>:
d004010c:	3901      	subs	r1, #1
d004010e:	2901      	cmp	r1, #1
d0040110:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0040112:	d81f      	bhi.n	d0040154 <_write_r+0x48>
d0040114:	b1e2      	cbz	r2, d0040150 <_write_r+0x44>
d0040116:	461c      	mov	r4, r3
d0040118:	b1d3      	cbz	r3, d0040150 <_write_r+0x44>
d004011a:	4d12      	ldr	r5, [pc, #72]	; (d0040164 <_write_r+0x58>)
d004011c:	682e      	ldr	r6, [r5, #0]
d004011e:	b9ae      	cbnz	r6, d004014c <_write_r+0x40>
d0040120:	4f11      	ldr	r7, [pc, #68]	; (d0040168 <_write_r+0x5c>)
d0040122:	2301      	movs	r3, #1
d0040124:	4611      	mov	r1, r2
d0040126:	4630      	mov	r0, r6
d0040128:	602b      	str	r3, [r5, #0]
d004012a:	4622      	mov	r2, r4
d004012c:	7a3b      	ldrb	r3, [r7, #8]
d004012e:	f897 c009 	ldrb.w	ip, [r7, #9]
d0040132:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d0040136:	f897 c00a 	ldrb.w	ip, [r7, #10]
d004013a:	7aff      	ldrb	r7, [r7, #11]
d004013c:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040140:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d0040144:	681b      	ldr	r3, [r3, #0]
d0040146:	685b      	ldr	r3, [r3, #4]
d0040148:	4798      	blx	r3
d004014a:	602e      	str	r6, [r5, #0]
d004014c:	4620      	mov	r0, r4
d004014e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0040150:	2000      	movs	r0, #0
d0040152:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0040154:	f001 fca6 	bl	d0041aa4 <__errno>
d0040158:	2209      	movs	r2, #9
d004015a:	4603      	mov	r3, r0
d004015c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0040160:	601a      	str	r2, [r3, #0]
d0040162:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0040164:	d00435e4 	.word	0xd00435e4
d0040168:	2001f000 	.word	0x2001f000

d004016c <_read>:
d004016c:	b508      	push	{r3, lr}
d004016e:	f001 fc99 	bl	d0041aa4 <__errno>
d0040172:	2258      	movs	r2, #88	; 0x58
d0040174:	4603      	mov	r3, r0
d0040176:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d004017a:	601a      	str	r2, [r3, #0]
d004017c:	bd08      	pop	{r3, pc}
d004017e:	bf00      	nop

d0040180 <_close>:
d0040180:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0040184:	4770      	bx	lr
d0040186:	bf00      	nop

d0040188 <_fstat>:
d0040188:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d004018c:	2000      	movs	r0, #0
d004018e:	604b      	str	r3, [r1, #4]
d0040190:	4770      	bx	lr
d0040192:	bf00      	nop

d0040194 <_lseek>:
d0040194:	2000      	movs	r0, #0
d0040196:	4770      	bx	lr

d0040198 <_sbrk_r>:
d0040198:	4b0c      	ldr	r3, [pc, #48]	; (d00401cc <_sbrk_r+0x34>)
d004019a:	4a0d      	ldr	r2, [pc, #52]	; (d00401d0 <_sbrk_r+0x38>)
d004019c:	6818      	ldr	r0, [r3, #0]
d004019e:	b510      	push	{r4, lr}
d00401a0:	b918      	cbnz	r0, d00401aa <_sbrk_r+0x12>
d00401a2:	1dd0      	adds	r0, r2, #7
d00401a4:	f020 0007 	bic.w	r0, r0, #7
d00401a8:	6018      	str	r0, [r3, #0]
d00401aa:	4401      	add	r1, r0
d00401ac:	4c09      	ldr	r4, [pc, #36]	; (d00401d4 <_sbrk_r+0x3c>)
d00401ae:	42a1      	cmp	r1, r4
d00401b0:	d803      	bhi.n	d00401ba <_sbrk_r+0x22>
d00401b2:	4291      	cmp	r1, r2
d00401b4:	d301      	bcc.n	d00401ba <_sbrk_r+0x22>
d00401b6:	6019      	str	r1, [r3, #0]
d00401b8:	bd10      	pop	{r4, pc}
d00401ba:	f001 fc73 	bl	d0041aa4 <__errno>
d00401be:	220c      	movs	r2, #12
d00401c0:	4603      	mov	r3, r0
d00401c2:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00401c6:	601a      	str	r2, [r3, #0]
d00401c8:	bd10      	pop	{r4, pc}
d00401ca:	bf00      	nop
d00401cc:	d00435e0 	.word	0xd00435e0
d00401d0:	d0046458 	.word	0xd0046458
d00401d4:	d0600000 	.word	0xd0600000

d00401d8 <LoadSFX>:
d00401d8:	b5f0      	push	{r4, r5, r6, r7, lr}
d00401da:	4c40      	ldr	r4, [pc, #256]	; (d00402dc <LoadSFX+0x104>)
d00401dc:	460f      	mov	r7, r1
d00401de:	4601      	mov	r1, r0
d00401e0:	b08f      	sub	sp, #60	; 0x3c
d00401e2:	7925      	ldrb	r5, [r4, #4]
d00401e4:	2201      	movs	r2, #1
d00401e6:	7963      	ldrb	r3, [r4, #5]
d00401e8:	79a0      	ldrb	r0, [r4, #6]
d00401ea:	ea45 2303 	orr.w	r3, r5, r3, lsl #8
d00401ee:	79e5      	ldrb	r5, [r4, #7]
d00401f0:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d00401f4:	2000      	movs	r0, #0
d00401f6:	ea43 6305 	orr.w	r3, r3, r5, lsl #24
d00401fa:	681b      	ldr	r3, [r3, #0]
d00401fc:	681b      	ldr	r3, [r3, #0]
d00401fe:	4798      	blx	r3
d0040200:	bb00      	cbnz	r0, d0040244 <LoadSFX+0x6c>
d0040202:	7921      	ldrb	r1, [r4, #4]
d0040204:	ab02      	add	r3, sp, #8
d0040206:	7962      	ldrb	r2, [r4, #5]
d0040208:	79a6      	ldrb	r6, [r4, #6]
d004020a:	ea41 2202 	orr.w	r2, r1, r2, lsl #8
d004020e:	79e5      	ldrb	r5, [r4, #7]
d0040210:	a903      	add	r1, sp, #12
d0040212:	ea42 4606 	orr.w	r6, r2, r6, lsl #16
d0040216:	222c      	movs	r2, #44	; 0x2c
d0040218:	ea46 6505 	orr.w	r5, r6, r5, lsl #24
d004021c:	682d      	ldr	r5, [r5, #0]
d004021e:	68ad      	ldr	r5, [r5, #8]
d0040220:	47a8      	blx	r5
d0040222:	a803      	add	r0, sp, #12
d0040224:	2204      	movs	r2, #4
d0040226:	492e      	ldr	r1, [pc, #184]	; (d00402e0 <LoadSFX+0x108>)
d0040228:	f001 fc4a 	bl	d0041ac0 <memcmp>
d004022c:	b950      	cbnz	r0, d0040244 <LoadSFX+0x6c>
d004022e:	2204      	movs	r2, #4
d0040230:	492c      	ldr	r1, [pc, #176]	; (d00402e4 <LoadSFX+0x10c>)
d0040232:	a805      	add	r0, sp, #20
d0040234:	f001 fc44 	bl	d0041ac0 <memcmp>
d0040238:	4605      	mov	r5, r0
d004023a:	b918      	cbnz	r0, d0040244 <LoadSFX+0x6c>
d004023c:	f8bd 3020 	ldrh.w	r3, [sp, #32]
d0040240:	2b01      	cmp	r3, #1
d0040242:	d010      	beq.n	d0040266 <LoadSFX+0x8e>
d0040244:	7923      	ldrb	r3, [r4, #4]
d0040246:	2000      	movs	r0, #0
d0040248:	7962      	ldrb	r2, [r4, #5]
d004024a:	79a1      	ldrb	r1, [r4, #6]
d004024c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040250:	79e2      	ldrb	r2, [r4, #7]
d0040252:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040256:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004025a:	681b      	ldr	r3, [r3, #0]
d004025c:	68db      	ldr	r3, [r3, #12]
d004025e:	4798      	blx	r3
d0040260:	2000      	movs	r0, #0
d0040262:	b00f      	add	sp, #60	; 0x3c
d0040264:	bdf0      	pop	{r4, r5, r6, r7, pc}
d0040266:	9a0d      	ldr	r2, [sp, #52]	; 0x34
d0040268:	4610      	mov	r0, r2
d004026a:	9201      	str	r2, [sp, #4]
d004026c:	f001 fc20 	bl	d0041ab0 <malloc>
d0040270:	9a01      	ldr	r2, [sp, #4]
d0040272:	4601      	mov	r1, r0
d0040274:	6038      	str	r0, [r7, #0]
d0040276:	b1f8      	cbz	r0, d00402b8 <LoadSFX+0xe0>
d0040278:	7920      	ldrb	r0, [r4, #4]
d004027a:	ab02      	add	r3, sp, #8
d004027c:	7966      	ldrb	r6, [r4, #5]
d004027e:	f894 c006 	ldrb.w	ip, [r4, #6]
d0040282:	ea40 2606 	orr.w	r6, r0, r6, lsl #8
d0040286:	79e7      	ldrb	r7, [r4, #7]
d0040288:	4628      	mov	r0, r5
d004028a:	ea46 460c 	orr.w	r6, r6, ip, lsl #16
d004028e:	ea46 6607 	orr.w	r6, r6, r7, lsl #24
d0040292:	6836      	ldr	r6, [r6, #0]
d0040294:	68b6      	ldr	r6, [r6, #8]
d0040296:	47b0      	blx	r6
d0040298:	7923      	ldrb	r3, [r4, #4]
d004029a:	7962      	ldrb	r2, [r4, #5]
d004029c:	4628      	mov	r0, r5
d004029e:	79a1      	ldrb	r1, [r4, #6]
d00402a0:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00402a4:	79e2      	ldrb	r2, [r4, #7]
d00402a6:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00402aa:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00402ae:	681b      	ldr	r3, [r3, #0]
d00402b0:	68db      	ldr	r3, [r3, #12]
d00402b2:	4798      	blx	r3
d00402b4:	980d      	ldr	r0, [sp, #52]	; 0x34
d00402b6:	e7d4      	b.n	d0040262 <LoadSFX+0x8a>
d00402b8:	7923      	ldrb	r3, [r4, #4]
d00402ba:	7962      	ldrb	r2, [r4, #5]
d00402bc:	79a5      	ldrb	r5, [r4, #6]
d00402be:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00402c2:	79e2      	ldrb	r2, [r4, #7]
d00402c4:	9001      	str	r0, [sp, #4]
d00402c6:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d00402ca:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00402ce:	681b      	ldr	r3, [r3, #0]
d00402d0:	68db      	ldr	r3, [r3, #12]
d00402d2:	4798      	blx	r3
d00402d4:	9901      	ldr	r1, [sp, #4]
d00402d6:	4608      	mov	r0, r1
d00402d8:	e7c3      	b.n	d0040262 <LoadSFX+0x8a>
d00402da:	bf00      	nop
d00402dc:	2001f000 	.word	0x2001f000
d00402e0:	d0042a24 	.word	0xd0042a24
d00402e4:	d0042a2c 	.word	0xd0042a2c

d00402e8 <spawnFlame>:
d00402e8:	4b39      	ldr	r3, [pc, #228]	; (d00403d0 <spawnFlame+0xe8>)
d00402ea:	681b      	ldr	r3, [r3, #0]
d00402ec:	1e5a      	subs	r2, r3, #1
d00402ee:	1c59      	adds	r1, r3, #1
d00402f0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d00402f4:	2a00      	cmp	r2, #0
d00402f6:	b084      	sub	sp, #16
d00402f8:	9303      	str	r3, [sp, #12]
d00402fa:	9201      	str	r2, [sp, #4]
d00402fc:	9102      	str	r1, [sp, #8]
d00402fe:	da01      	bge.n	d0040304 <spawnFlame+0x1c>
d0040300:	2223      	movs	r2, #35	; 0x23
d0040302:	9201      	str	r2, [sp, #4]
d0040304:	2b23      	cmp	r3, #35	; 0x23
d0040306:	dd01      	ble.n	d004030c <spawnFlame+0x24>
d0040308:	2300      	movs	r3, #0
d004030a:	9303      	str	r3, [sp, #12]
d004030c:	f8df 80c8 	ldr.w	r8, [pc, #200]	; d00403d8 <spawnFlame+0xf0>
d0040310:	eeb3 6a06 	vmov.f32	s12, #54	; 0x41b00000  22.0
d0040314:	af01      	add	r7, sp, #4
d0040316:	f10d 0e10 	add.w	lr, sp, #16
d004031a:	f8d8 6000 	ldr.w	r6, [r8]
d004031e:	f04f 0a11 	mov.w	sl, #17
d0040322:	4d2c      	ldr	r5, [pc, #176]	; (d00403d4 <spawnFlame+0xec>)
d0040324:	f8df c0b4 	ldr.w	ip, [pc, #180]	; d00403dc <spawnFlame+0xf4>
d0040328:	f8df 90b4 	ldr.w	r9, [pc, #180]	; d00403e0 <spawnFlame+0xf8>
d004032c:	2300      	movs	r3, #0
d004032e:	e001      	b.n	d0040334 <spawnFlame+0x4c>
d0040330:	2b20      	cmp	r3, #32
d0040332:	d044      	beq.n	d00403be <spawnFlame+0xd6>
d0040334:	eb05 1243 	add.w	r2, r5, r3, lsl #5
d0040338:	3301      	adds	r3, #1
d004033a:	7d91      	ldrb	r1, [r2, #22]
d004033c:	f001 00ff 	and.w	r0, r1, #255	; 0xff
d0040340:	2900      	cmp	r1, #0
d0040342:	d1f5      	bne.n	d0040330 <spawnFlame+0x48>
d0040344:	f882 a016 	strb.w	sl, [r2, #22]
d0040348:	ea86 3646 	eor.w	r6, r6, r6, lsl #13
d004034c:	7610      	strb	r0, [r2, #24]
d004034e:	f8bc 3014 	ldrh.w	r3, [ip, #20]
d0040352:	ea86 4656 	eor.w	r6, r6, r6, lsr #17
d0040356:	6838      	ldr	r0, [r7, #0]
d0040358:	b21b      	sxth	r3, r3
d004035a:	f006 010f 	and.w	r1, r6, #15
d004035e:	eb09 04c0 	add.w	r4, r9, r0, lsl #3
d0040362:	3318      	adds	r3, #24
d0040364:	b240      	sxtb	r0, r0
d0040366:	edd4 6a00 	vldr	s13, [r4]
d004036a:	ea86 1646 	eor.w	r6, r6, r6, lsl #5
d004036e:	ee07 3a90 	vmov	s15, r3
d0040372:	ed94 7a01 	vldr	s14, [r4, #4]
d0040376:	ee36 5aa6 	vadd.f32	s10, s13, s13
d004037a:	eef8 7ae7 	vcvt.f32.s32	s15, s15
d004037e:	ee77 5a07 	vadd.f32	s11, s14, s14
d0040382:	edc2 7a02 	vstr	s15, [r2, #8]
d0040386:	f8bc 3016 	ldrh.w	r3, [ip, #22]
d004038a:	b21b      	sxth	r3, r3
d004038c:	3318      	adds	r3, #24
d004038e:	ee07 3a90 	vmov	s15, r3
d0040392:	eef8 7ae7 	vcvt.f32.s32	s15, s15
d0040396:	edc2 7a03 	vstr	s15, [r2, #12]
d004039a:	7510      	strb	r0, [r2, #20]
d004039c:	7511      	strb	r1, [r2, #20]
d004039e:	ed82 5a00 	vstr	s10, [r2]
d00403a2:	edc2 5a01 	vstr	s11, [r2, #4]
d00403a6:	edd2 7a02 	vldr	s15, [r2, #8]
d00403aa:	eee6 7ac6 	vfms.f32	s15, s13, s12
d00403ae:	edc2 7a02 	vstr	s15, [r2, #8]
d00403b2:	edd2 7a03 	vldr	s15, [r2, #12]
d00403b6:	eee7 7a06 	vfma.f32	s15, s14, s12
d00403ba:	edc2 7a03 	vstr	s15, [r2, #12]
d00403be:	3704      	adds	r7, #4
d00403c0:	45be      	cmp	lr, r7
d00403c2:	d1b3      	bne.n	d004032c <spawnFlame+0x44>
d00403c4:	f8c8 6000 	str.w	r6, [r8]
d00403c8:	b004      	add	sp, #16
d00403ca:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d00403ce:	bf00      	nop
d00403d0:	d00435f4 	.word	0xd00435f4
d00403d4:	d0044044 	.word	0xd0044044
d00403d8:	d00435c0 	.word	0xd00435c0
d00403dc:	d0043fa0 	.word	0xd0043fa0
d00403e0:	d0042b74 	.word	0xd0042b74

d00403e4 <doFlames>:
d00403e4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00403e6:	2400      	movs	r4, #0
d00403e8:	4d42      	ldr	r5, [pc, #264]	; (d00404f4 <doFlames+0x110>)
d00403ea:	4e43      	ldr	r6, [pc, #268]	; (d00404f8 <doFlames+0x114>)
d00403ec:	ed2d 8b02 	vpush	{d8}
d00403f0:	eddf 8a42 	vldr	s17, [pc, #264]	; d00404fc <doFlames+0x118>
d00403f4:	ed9f 8a42 	vldr	s16, [pc, #264]	; d0040500 <doFlames+0x11c>
d00403f8:	eb05 1244 	add.w	r2, r5, r4, lsl #5
d00403fc:	0163      	lsls	r3, r4, #5
d00403fe:	7d91      	ldrb	r1, [r2, #22]
d0040400:	2900      	cmp	r1, #0
d0040402:	d070      	beq.n	d00404e6 <doFlames+0x102>
d0040404:	7d91      	ldrb	r1, [r2, #22]
d0040406:	eebb 7a04 	vmov.f32	s14, #180	; 0xc1a00000 -20.0
d004040a:	3901      	subs	r1, #1
d004040c:	b2c9      	uxtb	r1, r1
d004040e:	7591      	strb	r1, [r2, #22]
d0040410:	edd2 6a00 	vldr	s13, [r2]
d0040414:	edd2 7a02 	vldr	s15, [r2, #8]
d0040418:	ee77 7ae6 	vsub.f32	s15, s15, s13
d004041c:	edc2 7a02 	vstr	s15, [r2, #8]
d0040420:	edd2 6a01 	vldr	s13, [r2, #4]
d0040424:	edd2 7a03 	vldr	s15, [r2, #12]
d0040428:	ee77 7aa6 	vadd.f32	s15, s15, s13
d004042c:	edc2 7a03 	vstr	s15, [r2, #12]
d0040430:	edd2 7a02 	vldr	s15, [r2, #8]
d0040434:	eef4 7ac7 	vcmpe.f32	s15, s14
d0040438:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d004043c:	d501      	bpl.n	d0040442 <doFlames+0x5e>
d004043e:	edc2 8a02 	vstr	s17, [r2, #8]
d0040442:	18ea      	adds	r2, r5, r3
d0040444:	edd2 7a02 	vldr	s15, [r2, #8]
d0040448:	eef4 7ae8 	vcmpe.f32	s15, s17
d004044c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040450:	dd01      	ble.n	d0040456 <doFlames+0x72>
d0040452:	492c      	ldr	r1, [pc, #176]	; (d0040504 <doFlames+0x120>)
d0040454:	6091      	str	r1, [r2, #8]
d0040456:	18ea      	adds	r2, r5, r3
d0040458:	eefb 7a04 	vmov.f32	s15, #180	; 0xc1a00000 -20.0
d004045c:	ed92 7a03 	vldr	s14, [r2, #12]
d0040460:	eeb4 7ae7 	vcmpe.f32	s14, s15
d0040464:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040468:	d501      	bpl.n	d004046e <doFlames+0x8a>
d004046a:	ed82 8a03 	vstr	s16, [r2, #12]
d004046e:	18ea      	adds	r2, r5, r3
d0040470:	edd2 7a03 	vldr	s15, [r2, #12]
d0040474:	eef4 7ac8 	vcmpe.f32	s15, s16
d0040478:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d004047c:	dd01      	ble.n	d0040482 <doFlames+0x9e>
d004047e:	4921      	ldr	r1, [pc, #132]	; (d0040504 <doFlames+0x120>)
d0040480:	60d1      	str	r1, [r2, #12]
d0040482:	442b      	add	r3, r5
d0040484:	2102      	movs	r1, #2
d0040486:	edd3 7a02 	vldr	s15, [r3, #8]
d004048a:	eefd 7ae7 	vcvt.s32.f32	s15, s15
d004048e:	ee17 2a90 	vmov	r2, s15
d0040492:	b212      	sxth	r2, r2
d0040494:	821a      	strh	r2, [r3, #16]
d0040496:	edd3 7a03 	vldr	s15, [r3, #12]
d004049a:	eefd 7ae7 	vcvt.s32.f32	s15, s15
d004049e:	ee17 2a90 	vmov	r2, s15
d00404a2:	b212      	sxth	r2, r2
d00404a4:	825a      	strh	r2, [r3, #18]
d00404a6:	8a1a      	ldrh	r2, [r3, #16]
d00404a8:	82b2      	strh	r2, [r6, #20]
d00404aa:	8a5a      	ldrh	r2, [r3, #18]
d00404ac:	82f2      	strh	r2, [r6, #22]
d00404ae:	7131      	strb	r1, [r6, #4]
d00404b0:	7e1a      	ldrb	r2, [r3, #24]
d00404b2:	b2d2      	uxtb	r2, r2
d00404b4:	71b2      	strb	r2, [r6, #6]
d00404b6:	7e1a      	ldrb	r2, [r3, #24]
d00404b8:	3205      	adds	r2, #5
d00404ba:	b2d2      	uxtb	r2, r2
d00404bc:	761a      	strb	r2, [r3, #24]
d00404be:	7e1a      	ldrb	r2, [r3, #24]
d00404c0:	2a64      	cmp	r2, #100	; 0x64
d00404c2:	d901      	bls.n	d00404c8 <doFlames+0xe4>
d00404c4:	2264      	movs	r2, #100	; 0x64
d00404c6:	761a      	strb	r2, [r3, #24]
d00404c8:	4a0f      	ldr	r2, [pc, #60]	; (d0040508 <doFlames+0x124>)
d00404ca:	4630      	mov	r0, r6
d00404cc:	7b13      	ldrb	r3, [r2, #12]
d00404ce:	7b57      	ldrb	r7, [r2, #13]
d00404d0:	7b91      	ldrb	r1, [r2, #14]
d00404d2:	ea43 2307 	orr.w	r3, r3, r7, lsl #8
d00404d6:	7bd2      	ldrb	r2, [r2, #15]
d00404d8:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00404dc:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00404e0:	685b      	ldr	r3, [r3, #4]
d00404e2:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d00404e4:	4798      	blx	r3
d00404e6:	3401      	adds	r4, #1
d00404e8:	2c20      	cmp	r4, #32
d00404ea:	d185      	bne.n	d00403f8 <doFlames+0x14>
d00404ec:	ecbd 8b02 	vpop	{d8}
d00404f0:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00404f2:	bf00      	nop
d00404f4:	d0044044 	.word	0xd0044044
d00404f8:	d0043ea0 	.word	0xd0043ea0
d00404fc:	43f00000 	.word	0x43f00000
d0040500:	43a00000 	.word	0x43a00000
d0040504:	c1a00000 	.word	0xc1a00000
d0040508:	2001f000 	.word	0x2001f000

d004050c <initAstroids>:
d004050c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0040510:	2000      	movs	r0, #0
d0040512:	f8df a1e4 	ldr.w	sl, [pc, #484]	; d00406f8 <initAstroids+0x1ec>
d0040516:	4f73      	ldr	r7, [pc, #460]	; (d00406e4 <initAstroids+0x1d8>)
d0040518:	b083      	sub	sp, #12
d004051a:	f8da 3000 	ldr.w	r3, [sl]
d004051e:	4684      	mov	ip, r0
d0040520:	463e      	mov	r6, r7
d0040522:	4a71      	ldr	r2, [pc, #452]	; (d00406e8 <initAstroids+0x1dc>)
d0040524:	f04f 0b18 	mov.w	fp, #24
d0040528:	ea83 3143 	eor.w	r1, r3, r3, lsl #13
d004052c:	4c6f      	ldr	r4, [pc, #444]	; (d00406ec <initAstroids+0x1e0>)
d004052e:	f240 1879 	movw	r8, #377	; 0x179
d0040532:	eb00 0e40 	add.w	lr, r0, r0, lsl #1
d0040536:	ea81 4151 	eor.w	r1, r1, r1, lsr #17
d004053a:	f8c6 c000 	str.w	ip, [r6]
d004053e:	f8c6 c004 	str.w	ip, [r6, #4]
d0040542:	ea81 1141 	eor.w	r1, r1, r1, lsl #5
d0040546:	f8c6 c008 	str.w	ip, [r6, #8]
d004054a:	f8c6 c00c 	str.w	ip, [r6, #12]
d004054e:	fba4 4501 	umull	r4, r5, r4, r1
d0040552:	ea81 3341 	eor.w	r3, r1, r1, lsl #13
d0040556:	f240 2419 	movw	r4, #537	; 0x219
d004055a:	f8c6 c010 	str.w	ip, [r6, #16]
d004055e:	ea83 4353 	eor.w	r3, r3, r3, lsr #17
d0040562:	f8c6 c014 	str.w	ip, [r6, #20]
d0040566:	0a2d      	lsrs	r5, r5, #8
d0040568:	ea83 1343 	eor.w	r3, r3, r3, lsl #5
d004056c:	fb04 1515 	mls	r5, r4, r5, r1
d0040570:	495f      	ldr	r1, [pc, #380]	; (d00406f0 <initAstroids+0x1e4>)
d0040572:	fba1 1403 	umull	r1, r4, r1, r3
d0040576:	3d3c      	subs	r5, #60	; 0x3c
d0040578:	1b19      	subs	r1, r3, r4
d004057a:	b22d      	sxth	r5, r5
d004057c:	eb04 0151 	add.w	r1, r4, r1, lsr #1
d0040580:	f827 503e 	strh.w	r5, [r7, lr, lsl #3]
d0040584:	eb07 0ece 	add.w	lr, r7, lr, lsl #3
d0040588:	0a09      	lsrs	r1, r1, #8
d004058a:	4674      	mov	r4, lr
d004058c:	0045      	lsls	r5, r0, #1
d004058e:	fb08 3111 	mls	r1, r8, r1, r3
d0040592:	393c      	subs	r1, #60	; 0x3c
d0040594:	b209      	sxth	r1, r1
d0040596:	f8ae 1002 	strh.w	r1, [lr, #2]
d004059a:	ea83 3343 	eor.w	r3, r3, r3, lsl #13
d004059e:	ea83 4353 	eor.w	r3, r3, r3, lsr #17
d00405a2:	ea83 1343 	eor.w	r3, r3, r3, lsl #5
d00405a6:	fba2 e103 	umull	lr, r1, r2, r3
d00405aa:	eba3 0e01 	sub.w	lr, r3, r1
d00405ae:	eb01 015e 	add.w	r1, r1, lr, lsr #1
d00405b2:	0889      	lsrs	r1, r1, #2
d00405b4:	ebc1 01c1 	rsb	r1, r1, r1, lsl #3
d00405b8:	1a59      	subs	r1, r3, r1
d00405ba:	3903      	subs	r1, #3
d00405bc:	b209      	sxth	r1, r1
d00405be:	80a1      	strh	r1, [r4, #4]
d00405c0:	88a1      	ldrh	r1, [r4, #4]
d00405c2:	b209      	sxth	r1, r1
d00405c4:	2900      	cmp	r1, #0
d00405c6:	d0e8      	beq.n	d004059a <initAstroids+0x8e>
d00405c8:	182c      	adds	r4, r5, r0
d00405ca:	eb07 04c4 	add.w	r4, r7, r4, lsl #3
d00405ce:	ea83 3343 	eor.w	r3, r3, r3, lsl #13
d00405d2:	ea83 4353 	eor.w	r3, r3, r3, lsr #17
d00405d6:	ea83 1343 	eor.w	r3, r3, r3, lsl #5
d00405da:	fba2 e103 	umull	lr, r1, r2, r3
d00405de:	eba3 0e01 	sub.w	lr, r3, r1
d00405e2:	eb01 015e 	add.w	r1, r1, lr, lsr #1
d00405e6:	0889      	lsrs	r1, r1, #2
d00405e8:	ebc1 01c1 	rsb	r1, r1, r1, lsl #3
d00405ec:	1a59      	subs	r1, r3, r1
d00405ee:	3903      	subs	r1, #3
d00405f0:	b209      	sxth	r1, r1
d00405f2:	80e1      	strh	r1, [r4, #6]
d00405f4:	88e1      	ldrh	r1, [r4, #6]
d00405f6:	b209      	sxth	r1, r1
d00405f8:	2900      	cmp	r1, #0
d00405fa:	d0e8      	beq.n	d00405ce <initAstroids+0xc2>
d00405fc:	ea83 3343 	eor.w	r3, r3, r3, lsl #13
d0040600:	ea83 4353 	eor.w	r3, r3, r3, lsr #17
d0040604:	ea83 1343 	eor.w	r3, r3, r3, lsl #5
d0040608:	f003 0103 	and.w	r1, r3, #3
d004060c:	f8ca 3000 	str.w	r3, [sl]
d0040610:	7321      	strb	r1, [r4, #12]
d0040612:	7b21      	ldrb	r1, [r4, #12]
d0040614:	b929      	cbnz	r1, d0040622 <initAstroids+0x116>
d0040616:	f04f 0160 	mov.w	r1, #96	; 0x60
d004061a:	8161      	strh	r1, [r4, #10]
d004061c:	8121      	strh	r1, [r4, #8]
d004061e:	f884 b010 	strb.w	fp, [r4, #16]
d0040622:	1829      	adds	r1, r5, r0
d0040624:	eb07 01c1 	add.w	r1, r7, r1, lsl #3
d0040628:	7b0c      	ldrb	r4, [r1, #12]
d004062a:	2c01      	cmp	r4, #1
d004062c:	d104      	bne.n	d0040638 <initAstroids+0x12c>
d004062e:	2440      	movs	r4, #64	; 0x40
d0040630:	814c      	strh	r4, [r1, #10]
d0040632:	810c      	strh	r4, [r1, #8]
d0040634:	f881 b010 	strb.w	fp, [r1, #16]
d0040638:	1829      	adds	r1, r5, r0
d004063a:	eb07 01c1 	add.w	r1, r7, r1, lsl #3
d004063e:	7b0c      	ldrb	r4, [r1, #12]
d0040640:	2c02      	cmp	r4, #2
d0040642:	d104      	bne.n	d004064e <initAstroids+0x142>
d0040644:	2440      	movs	r4, #64	; 0x40
d0040646:	814c      	strh	r4, [r1, #10]
d0040648:	810c      	strh	r4, [r1, #8]
d004064a:	f881 b010 	strb.w	fp, [r1, #16]
d004064e:	1829      	adds	r1, r5, r0
d0040650:	eb07 01c1 	add.w	r1, r7, r1, lsl #3
d0040654:	7b0c      	ldrb	r4, [r1, #12]
d0040656:	2c03      	cmp	r4, #3
d0040658:	d106      	bne.n	d0040668 <initAstroids+0x15c>
d004065a:	2420      	movs	r4, #32
d004065c:	f04f 0e10 	mov.w	lr, #16
d0040660:	814c      	strh	r4, [r1, #10]
d0040662:	810c      	strh	r4, [r1, #8]
d0040664:	f881 e010 	strb.w	lr, [r1, #16]
d0040668:	ea83 3343 	eor.w	r3, r3, r3, lsl #13
d004066c:	4405      	add	r5, r0
d004066e:	3001      	adds	r0, #1
d0040670:	3618      	adds	r6, #24
d0040672:	ea83 4353 	eor.w	r3, r3, r3, lsr #17
d0040676:	eb07 05c5 	add.w	r5, r7, r5, lsl #3
d004067a:	ea83 1343 	eor.w	r3, r3, r3, lsl #5
d004067e:	7c2c      	ldrb	r4, [r5, #16]
d0040680:	9300      	str	r3, [sp, #0]
d0040682:	9900      	ldr	r1, [sp, #0]
d0040684:	4623      	mov	r3, r4
d0040686:	4c1b      	ldr	r4, [pc, #108]	; (d00406f4 <initAstroids+0x1e8>)
d0040688:	ea81 3141 	eor.w	r1, r1, r1, lsl #13
d004068c:	9301      	str	r3, [sp, #4]
d004068e:	ea81 4151 	eor.w	r1, r1, r1, lsr #17
d0040692:	ea81 1141 	eor.w	r1, r1, r1, lsl #5
d0040696:	fba4 4801 	umull	r4, r8, r4, r1
d004069a:	9c00      	ldr	r4, [sp, #0]
d004069c:	f028 0e01 	bic.w	lr, r8, #1
d00406a0:	fbb4 f9f3 	udiv	r9, r4, r3
d00406a4:	eb0e 0e58 	add.w	lr, lr, r8, lsr #1
d00406a8:	461c      	mov	r4, r3
d00406aa:	9b00      	ldr	r3, [sp, #0]
d00406ac:	fb09 3414 	mls	r4, r9, r4, r3
d00406b0:	ea81 3341 	eor.w	r3, r1, r1, lsl #13
d00406b4:	eba1 010e 	sub.w	r1, r1, lr
d00406b8:	ea83 4353 	eor.w	r3, r3, r3, lsr #17
d00406bc:	3101      	adds	r1, #1
d00406be:	b264      	sxtb	r4, r4
d00406c0:	ea83 1343 	eor.w	r3, r3, r3, lsl #5
d00406c4:	b2c9      	uxtb	r1, r1
d00406c6:	736c      	strb	r4, [r5, #13]
d00406c8:	f8ca 3000 	str.w	r3, [sl]
d00406cc:	73a9      	strb	r1, [r5, #14]
d00406ce:	07d9      	lsls	r1, r3, #31
d00406d0:	bf54      	ite	pl
d00406d2:	21ff      	movpl	r1, #255	; 0xff
d00406d4:	2101      	movmi	r1, #1
d00406d6:	2808      	cmp	r0, #8
d00406d8:	7469      	strb	r1, [r5, #17]
d00406da:	f47f af25 	bne.w	d0040528 <initAstroids+0x1c>
d00406de:	b003      	add	sp, #12
d00406e0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00406e4:	d0043ec0 	.word	0xd0043ec0
d00406e8:	24924925 	.word	0x24924925
d00406ec:	7a0a7ce7 	.word	0x7a0a7ce7
d00406f0:	5babcc65 	.word	0x5babcc65
d00406f4:	aaaaaaab 	.word	0xaaaaaaab
d00406f8:	d00435c0 	.word	0xd00435c0

d00406fc <proc_astroids>:
d00406fc:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0040700:	2300      	movs	r3, #0
d0040702:	b083      	sub	sp, #12
d0040704:	4f6f      	ldr	r7, [pc, #444]	; (d00408c4 <proc_astroids+0x1c8>)
d0040706:	4e70      	ldr	r6, [pc, #448]	; (d00408c8 <proc_astroids+0x1cc>)
d0040708:	f8df b1cc 	ldr.w	fp, [pc, #460]	; d00408d8 <proc_astroids+0x1dc>
d004070c:	4d6f      	ldr	r5, [pc, #444]	; (d00408cc <proc_astroids+0x1d0>)
d004070e:	9300      	str	r3, [sp, #0]
d0040710:	9a00      	ldr	r2, [sp, #0]
d0040712:	eb02 0342 	add.w	r3, r2, r2, lsl #1
d0040716:	0051      	lsls	r1, r2, #1
d0040718:	eb07 03c3 	add.w	r3, r7, r3, lsl #3
d004071c:	7b1a      	ldrb	r2, [r3, #12]
d004071e:	7bd8      	ldrb	r0, [r3, #15]
d0040720:	b2d2      	uxtb	r2, r2
d0040722:	3001      	adds	r0, #1
d0040724:	b2c0      	uxtb	r0, r0
d0040726:	73d8      	strb	r0, [r3, #15]
d0040728:	7bdc      	ldrb	r4, [r3, #15]
d004072a:	7b98      	ldrb	r0, [r3, #14]
d004072c:	4284      	cmp	r4, r0
d004072e:	d91a      	bls.n	d0040766 <proc_astroids+0x6a>
d0040730:	f04f 0000 	mov.w	r0, #0
d0040734:	73d8      	strb	r0, [r3, #15]
d0040736:	7c5c      	ldrb	r4, [r3, #17]
d0040738:	7b58      	ldrb	r0, [r3, #13]
d004073a:	4420      	add	r0, r4
d004073c:	b240      	sxtb	r0, r0
d004073e:	7358      	strb	r0, [r3, #13]
d0040740:	7b58      	ldrb	r0, [r3, #13]
d0040742:	0600      	lsls	r0, r0, #24
d0040744:	d503      	bpl.n	d004074e <proc_astroids+0x52>
d0040746:	7c18      	ldrb	r0, [r3, #16]
d0040748:	3801      	subs	r0, #1
d004074a:	b240      	sxtb	r0, r0
d004074c:	7358      	strb	r0, [r3, #13]
d004074e:	9b00      	ldr	r3, [sp, #0]
d0040750:	18cb      	adds	r3, r1, r3
d0040752:	eb07 03c3 	add.w	r3, r7, r3, lsl #3
d0040756:	7c1c      	ldrb	r4, [r3, #16]
d0040758:	7b58      	ldrb	r0, [r3, #13]
d004075a:	b240      	sxtb	r0, r0
d004075c:	4284      	cmp	r4, r0
d004075e:	dc02      	bgt.n	d0040766 <proc_astroids+0x6a>
d0040760:	f04f 0000 	mov.w	r0, #0
d0040764:	7358      	strb	r0, [r3, #13]
d0040766:	9b00      	ldr	r3, [sp, #0]
d0040768:	18c8      	adds	r0, r1, r3
d004076a:	eb07 04c0 	add.w	r4, r7, r0, lsl #3
d004076e:	f8b4 c004 	ldrh.w	ip, [r4, #4]
d0040772:	f837 3030 	ldrh.w	r3, [r7, r0, lsl #3]
d0040776:	4463      	add	r3, ip
d0040778:	b21b      	sxth	r3, r3
d004077a:	f827 3030 	strh.w	r3, [r7, r0, lsl #3]
d004077e:	f8b4 c006 	ldrh.w	ip, [r4, #6]
d0040782:	8863      	ldrh	r3, [r4, #2]
d0040784:	4463      	add	r3, ip
d0040786:	b21b      	sxth	r3, r3
d0040788:	8063      	strh	r3, [r4, #2]
d004078a:	f837 3030 	ldrh.w	r3, [r7, r0, lsl #3]
d004078e:	b21b      	sxth	r3, r3
d0040790:	f5b3 7ff0 	cmp.w	r3, #480	; 0x1e0
d0040794:	dd04      	ble.n	d00407a0 <proc_astroids+0xa4>
d0040796:	8923      	ldrh	r3, [r4, #8]
d0040798:	425b      	negs	r3, r3
d004079a:	b21b      	sxth	r3, r3
d004079c:	f827 3030 	strh.w	r3, [r7, r0, lsl #3]
d00407a0:	9b00      	ldr	r3, [sp, #0]
d00407a2:	18cb      	adds	r3, r1, r3
d00407a4:	eb07 03c3 	add.w	r3, r7, r3, lsl #3
d00407a8:	8858      	ldrh	r0, [r3, #2]
d00407aa:	b200      	sxth	r0, r0
d00407ac:	f5b0 7fa0 	cmp.w	r0, #320	; 0x140
d00407b0:	dd03      	ble.n	d00407ba <proc_astroids+0xbe>
d00407b2:	8958      	ldrh	r0, [r3, #10]
d00407b4:	4240      	negs	r0, r0
d00407b6:	b200      	sxth	r0, r0
d00407b8:	8058      	strh	r0, [r3, #2]
d00407ba:	9b00      	ldr	r3, [sp, #0]
d00407bc:	18cc      	adds	r4, r1, r3
d00407be:	eb07 03c4 	add.w	r3, r7, r4, lsl #3
d00407c2:	f837 0034 	ldrh.w	r0, [r7, r4, lsl #3]
d00407c6:	891b      	ldrh	r3, [r3, #8]
d00407c8:	b200      	sxth	r0, r0
d00407ca:	b21b      	sxth	r3, r3
d00407cc:	425b      	negs	r3, r3
d00407ce:	4298      	cmp	r0, r3
d00407d0:	da03      	bge.n	d00407da <proc_astroids+0xde>
d00407d2:	f44f 73f0 	mov.w	r3, #480	; 0x1e0
d00407d6:	f827 3034 	strh.w	r3, [r7, r4, lsl #3]
d00407da:	9b00      	ldr	r3, [sp, #0]
d00407dc:	18c8      	adds	r0, r1, r3
d00407de:	eb07 00c0 	add.w	r0, r7, r0, lsl #3
d00407e2:	8844      	ldrh	r4, [r0, #2]
d00407e4:	8943      	ldrh	r3, [r0, #10]
d00407e6:	b224      	sxth	r4, r4
d00407e8:	b21b      	sxth	r3, r3
d00407ea:	425b      	negs	r3, r3
d00407ec:	429c      	cmp	r4, r3
d00407ee:	da02      	bge.n	d00407f6 <proc_astroids+0xfa>
d00407f0:	f44f 73a0 	mov.w	r3, #320	; 0x140
d00407f4:	8043      	strh	r3, [r0, #2]
d00407f6:	9b00      	ldr	r3, [sp, #0]
d00407f8:	0150      	lsls	r0, r2, #5
d00407fa:	4c35      	ldr	r4, [pc, #212]	; (d00408d0 <proc_astroids+0x1d4>)
d00407fc:	f04f 0801 	mov.w	r8, #1
d0040800:	4419      	add	r1, r3
d0040802:	9001      	str	r0, [sp, #4]
d0040804:	eb04 1342 	add.w	r3, r4, r2, lsl #5
d0040808:	eb07 00c1 	add.w	r0, r7, r1, lsl #3
d004080c:	469a      	mov	sl, r3
d004080e:	4699      	mov	r9, r3
d0040810:	7b44      	ldrb	r4, [r0, #13]
d0040812:	761c      	strb	r4, [r3, #24]
d0040814:	f837 1031 	ldrh.w	r1, [r7, r1, lsl #3]
d0040818:	4c2e      	ldr	r4, [pc, #184]	; (d00408d4 <proc_astroids+0x1d8>)
d004081a:	8299      	strh	r1, [r3, #20]
d004081c:	8841      	ldrh	r1, [r0, #2]
d004081e:	82d9      	strh	r1, [r3, #22]
d0040820:	7c81      	ldrb	r1, [r0, #18]
d0040822:	b2c9      	uxtb	r1, r1
d0040824:	7119      	strb	r1, [r3, #4]
d0040826:	7d01      	ldrb	r1, [r0, #20]
d0040828:	b2c9      	uxtb	r1, r1
d004082a:	7199      	strb	r1, [r3, #6]
d004082c:	7da3      	ldrb	r3, [r4, #22]
d004082e:	4629      	mov	r1, r5
d0040830:	4650      	mov	r0, sl
d0040832:	b313      	cbz	r3, d004087a <proc_astroids+0x17e>
d0040834:	f9b4 c010 	ldrsh.w	ip, [r4, #16]
d0040838:	f9b4 2012 	ldrsh.w	r2, [r4, #18]
d004083c:	7d23      	ldrb	r3, [r4, #20]
d004083e:	f8a5 c014 	strh.w	ip, [r5, #20]
d0040842:	82ea      	strh	r2, [r5, #22]
d0040844:	762b      	strb	r3, [r5, #24]
d0040846:	f89b e00c 	ldrb.w	lr, [fp, #12]
d004084a:	f89b c00d 	ldrb.w	ip, [fp, #13]
d004084e:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040852:	ea4e 2c0c 	orr.w	ip, lr, ip, lsl #8
d0040856:	f89b 300f 	ldrb.w	r3, [fp, #15]
d004085a:	ea4c 4202 	orr.w	r2, ip, r2, lsl #16
d004085e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040862:	685b      	ldr	r3, [r3, #4]
d0040864:	6a9b      	ldr	r3, [r3, #40]	; 0x28
d0040866:	4798      	blx	r3
d0040868:	2802      	cmp	r0, #2
d004086a:	d106      	bne.n	d004087a <proc_astroids+0x17e>
d004086c:	23a8      	movs	r3, #168	; 0xa8
d004086e:	f889 8004 	strb.w	r8, [r9, #4]
d0040872:	f884 8016 	strb.w	r8, [r4, #22]
d0040876:	f889 3005 	strb.w	r3, [r9, #5]
d004087a:	341c      	adds	r4, #28
d004087c:	42b4      	cmp	r4, r6
d004087e:	d1d5      	bne.n	d004082c <proc_astroids+0x130>
d0040880:	9a00      	ldr	r2, [sp, #0]
d0040882:	4650      	mov	r0, sl
d0040884:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0040888:	3201      	adds	r2, #1
d004088a:	f89b 300d 	ldrb.w	r3, [fp, #13]
d004088e:	9200      	str	r2, [sp, #0]
d0040890:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0040894:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040898:	f89b 300f 	ldrb.w	r3, [fp, #15]
d004089c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00408a0:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00408a4:	685b      	ldr	r3, [r3, #4]
d00408a6:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d00408a8:	4798      	blx	r3
d00408aa:	4909      	ldr	r1, [pc, #36]	; (d00408d0 <proc_astroids+0x1d4>)
d00408ac:	9b01      	ldr	r3, [sp, #4]
d00408ae:	9a00      	ldr	r2, [sp, #0]
d00408b0:	440b      	add	r3, r1
d00408b2:	f04f 0100 	mov.w	r1, #0
d00408b6:	2a08      	cmp	r2, #8
d00408b8:	7119      	strb	r1, [r3, #4]
d00408ba:	f47f af29 	bne.w	d0040710 <proc_astroids+0x14>
d00408be:	b003      	add	sp, #12
d00408c0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00408c4:	d0043ec0 	.word	0xd0043ec0
d00408c8:	d0043a50 	.word	0xd0043a50
d00408cc:	d0043e60 	.word	0xd0043e60
d00408d0:	d0043620 	.word	0xd0043620
d00408d4:	d00436d0 	.word	0xd00436d0
d00408d8:	2001f000 	.word	0x2001f000

d00408dc <ShipUpdate>:
d00408dc:	4a52      	ldr	r2, [pc, #328]	; (d0040a28 <ShipUpdate+0x14c>)
d00408de:	7813      	ldrb	r3, [r2, #0]
d00408e0:	3301      	adds	r3, #1
d00408e2:	b25b      	sxtb	r3, r3
d00408e4:	2b01      	cmp	r3, #1
d00408e6:	7013      	strb	r3, [r2, #0]
d00408e8:	f340 808b 	ble.w	d0040a02 <ShipUpdate+0x126>
d00408ec:	2300      	movs	r3, #0
d00408ee:	06c1      	lsls	r1, r0, #27
d00408f0:	7013      	strb	r3, [r2, #0]
d00408f2:	4a4e      	ldr	r2, [pc, #312]	; (d0040a2c <ShipUpdate+0x150>)
d00408f4:	6813      	ldr	r3, [r2, #0]
d00408f6:	bf44      	itt	mi
d00408f8:	f103 33ff 	addmi.w	r3, r3, #4294967295	; 0xffffffff
d00408fc:	6013      	strmi	r3, [r2, #0]
d00408fe:	0681      	lsls	r1, r0, #26
d0040900:	d501      	bpl.n	d0040906 <ShipUpdate+0x2a>
d0040902:	3301      	adds	r3, #1
d0040904:	6013      	str	r3, [r2, #0]
d0040906:	2b23      	cmp	r3, #35	; 0x23
d0040908:	dc5a      	bgt.n	d00409c0 <ShipUpdate+0xe4>
d004090a:	2b00      	cmp	r3, #0
d004090c:	f280 8083 	bge.w	d0040a16 <ShipUpdate+0x13a>
d0040910:	2323      	movs	r3, #35	; 0x23
d0040912:	ed9f 7a47 	vldr	s14, [pc, #284]	; d0040a30 <ShipUpdate+0x154>
d0040916:	eddf 7a47 	vldr	s15, [pc, #284]	; d0040a34 <ShipUpdate+0x158>
d004091a:	6013      	str	r3, [r2, #0]
d004091c:	0743      	lsls	r3, r0, #29
d004091e:	d557      	bpl.n	d00409d0 <ShipUpdate+0xf4>
d0040920:	eef5 6a00 	vmov.f32	s13, #80	; 0x3e800000  0.250
d0040924:	ee67 7aa6 	vmul.f32	s15, s15, s13
d0040928:	ee67 6a26 	vmul.f32	s13, s14, s13
d004092c:	4942      	ldr	r1, [pc, #264]	; (d0040a38 <ShipUpdate+0x15c>)
d004092e:	eeb3 6a00 	vmov.f32	s12, #48	; 0x41800000  16.0
d0040932:	4842      	ldr	r0, [pc, #264]	; (d0040a3c <ShipUpdate+0x160>)
d0040934:	ed91 7a00 	vldr	s14, [r1]
d0040938:	edd0 5a00 	vldr	s11, [r0]
d004093c:	ee37 7a66 	vsub.f32	s14, s14, s13
d0040940:	ee77 7aa5 	vadd.f32	s15, s15, s11
d0040944:	ee67 6a07 	vmul.f32	s13, s14, s14
d0040948:	eee7 6aa7 	vfma.f32	s13, s15, s15
d004094c:	eef4 6ac6 	vcmpe.f32	s13, s12
d0040950:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040954:	dd09      	ble.n	d004096a <ShipUpdate+0x8e>
d0040956:	eeb1 6ae6 	vsqrt.f32	s12, s13
d004095a:	eef1 5a00 	vmov.f32	s11, #16	; 0x40800000  4.0
d004095e:	eec5 6a86 	vdiv.f32	s13, s11, s12
d0040962:	ee67 7aa6 	vmul.f32	s15, s15, s13
d0040966:	ee27 7a26 	vmul.f32	s14, s14, s13
d004096a:	4a35      	ldr	r2, [pc, #212]	; (d0040a40 <ShipUpdate+0x164>)
d004096c:	ed9f 5a35 	vldr	s10, [pc, #212]	; d0040a44 <ShipUpdate+0x168>
d0040970:	ed92 6a00 	vldr	s12, [r2]
d0040974:	4b34      	ldr	r3, [pc, #208]	; (d0040a48 <ShipUpdate+0x16c>)
d0040976:	ee37 6a86 	vadd.f32	s12, s15, s12
d004097a:	eddf 5a34 	vldr	s11, [pc, #208]	; d0040a4c <ShipUpdate+0x170>
d004097e:	edd3 6a00 	vldr	s13, [r3]
d0040982:	ee67 7aa5 	vmul.f32	s15, s15, s11
d0040986:	eeb4 6ac5 	vcmpe.f32	s12, s10
d004098a:	ed82 6a00 	vstr	s12, [r2]
d004098e:	ee77 6a26 	vadd.f32	s13, s14, s13
d0040992:	ee27 7a25 	vmul.f32	s14, s14, s11
d0040996:	edc0 7a00 	vstr	s15, [r0]
d004099a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d004099e:	edc3 6a00 	vstr	s13, [r3]
d00409a2:	ed81 7a00 	vstr	s14, [r1]
d00409a6:	d522      	bpl.n	d00409ee <ShipUpdate+0x112>
d00409a8:	4929      	ldr	r1, [pc, #164]	; (d0040a50 <ShipUpdate+0x174>)
d00409aa:	6011      	str	r1, [r2, #0]
d00409ac:	eddf 7a25 	vldr	s15, [pc, #148]	; d0040a44 <ShipUpdate+0x168>
d00409b0:	eef4 6ae7 	vcmpe.f32	s13, s15
d00409b4:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00409b8:	d50f      	bpl.n	d00409da <ShipUpdate+0xfe>
d00409ba:	4a26      	ldr	r2, [pc, #152]	; (d0040a54 <ShipUpdate+0x178>)
d00409bc:	601a      	str	r2, [r3, #0]
d00409be:	4770      	bx	lr
d00409c0:	2300      	movs	r3, #0
d00409c2:	eeb7 7a00 	vmov.f32	s14, #112	; 0x3f800000  1.0
d00409c6:	eddf 7a24 	vldr	s15, [pc, #144]	; d0040a58 <ShipUpdate+0x17c>
d00409ca:	6013      	str	r3, [r2, #0]
d00409cc:	0743      	lsls	r3, r0, #29
d00409ce:	d4a7      	bmi.n	d0040920 <ShipUpdate+0x44>
d00409d0:	eddf 6a21 	vldr	s13, [pc, #132]	; d0040a58 <ShipUpdate+0x17c>
d00409d4:	eef0 7a66 	vmov.f32	s15, s13
d00409d8:	e7a8      	b.n	d004092c <ShipUpdate+0x50>
d00409da:	ed9f 7a20 	vldr	s14, [pc, #128]	; d0040a5c <ShipUpdate+0x180>
d00409de:	eef4 6ac7 	vcmpe.f32	s13, s14
d00409e2:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00409e6:	bfc8      	it	gt
d00409e8:	edc3 7a00 	vstrgt	s15, [r3]
d00409ec:	4770      	bx	lr
d00409ee:	eddf 7a1c 	vldr	s15, [pc, #112]	; d0040a60 <ShipUpdate+0x184>
d00409f2:	eeb4 6ae7 	vcmpe.f32	s12, s15
d00409f6:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00409fa:	bfc8      	it	gt
d00409fc:	ed82 5a00 	vstrgt	s10, [r2]
d0040a00:	e7d4      	b.n	d00409ac <ShipUpdate+0xd0>
d0040a02:	4a0a      	ldr	r2, [pc, #40]	; (d0040a2c <ShipUpdate+0x150>)
d0040a04:	4b17      	ldr	r3, [pc, #92]	; (d0040a64 <ShipUpdate+0x188>)
d0040a06:	6812      	ldr	r2, [r2, #0]
d0040a08:	eb03 03c2 	add.w	r3, r3, r2, lsl #3
d0040a0c:	edd3 7a00 	vldr	s15, [r3]
d0040a10:	ed93 7a01 	vldr	s14, [r3, #4]
d0040a14:	e782      	b.n	d004091c <ShipUpdate+0x40>
d0040a16:	4a13      	ldr	r2, [pc, #76]	; (d0040a64 <ShipUpdate+0x188>)
d0040a18:	eb02 03c3 	add.w	r3, r2, r3, lsl #3
d0040a1c:	edd3 7a00 	vldr	s15, [r3]
d0040a20:	ed93 7a01 	vldr	s14, [r3, #4]
d0040a24:	e77a      	b.n	d004091c <ShipUpdate+0x40>
d0040a26:	bf00      	nop
d0040a28:	d00435f8 	.word	0xd00435f8
d0040a2c:	d00435f4 	.word	0xd00435f4
d0040a30:	3f7c1bda 	.word	0x3f7c1bda
d0040a34:	be31c433 	.word	0xbe31c433
d0040a38:	d0043600 	.word	0xd0043600
d0040a3c:	d00435fc 	.word	0xd00435fc
d0040a40:	d0043604 	.word	0xd0043604
d0040a44:	c2800000 	.word	0xc2800000
d0040a48:	d0043608 	.word	0xd0043608
d0040a4c:	3f7d70a4 	.word	0x3f7d70a4
d0040a50:	43f00000 	.word	0x43f00000
d0040a54:	43a00000 	.word	0x43a00000
d0040a58:	00000000 	.word	0x00000000
d0040a5c:	43a00000 	.word	0x43a00000
d0040a60:	43f00000 	.word	0x43f00000
d0040a64:	d0042b74 	.word	0xd0042b74

d0040a68 <fireBullet>:
d0040a68:	4b55      	ldr	r3, [pc, #340]	; (d0040bc0 <fireBullet+0x158>)
d0040a6a:	681b      	ldr	r3, [r3, #0]
d0040a6c:	1e59      	subs	r1, r3, #1
d0040a6e:	1c5a      	adds	r2, r3, #1
d0040a70:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0040a74:	2900      	cmp	r1, #0
d0040a76:	b084      	sub	sp, #16
d0040a78:	9302      	str	r3, [sp, #8]
d0040a7a:	9101      	str	r1, [sp, #4]
d0040a7c:	9203      	str	r2, [sp, #12]
d0040a7e:	da01      	bge.n	d0040a84 <fireBullet+0x1c>
d0040a80:	2323      	movs	r3, #35	; 0x23
d0040a82:	9301      	str	r3, [sp, #4]
d0040a84:	2a23      	cmp	r2, #35	; 0x23
d0040a86:	dd01      	ble.n	d0040a8c <fireBullet+0x24>
d0040a88:	2300      	movs	r3, #0
d0040a8a:	9303      	str	r3, [sp, #12]
d0040a8c:	eef2 5a00 	vmov.f32	s11, #32	; 0x41000000  8.0
d0040a90:	ae01      	add	r6, sp, #4
d0040a92:	eeb3 6a06 	vmov.f32	s12, #54	; 0x41b00000  22.0
d0040a96:	f10d 0c10 	add.w	ip, sp, #16
d0040a9a:	2700      	movs	r7, #0
d0040a9c:	4d49      	ldr	r5, [pc, #292]	; (d0040bc4 <fireBullet+0x15c>)
d0040a9e:	f04f 0811 	mov.w	r8, #17
d0040aa2:	4849      	ldr	r0, [pc, #292]	; (d0040bc8 <fireBullet+0x160>)
d0040aa4:	f8df e12c 	ldr.w	lr, [pc, #300]	; d0040bd4 <fireBullet+0x16c>
d0040aa8:	2200      	movs	r2, #0
d0040aaa:	e001      	b.n	d0040ab0 <fireBullet+0x48>
d0040aac:	2a20      	cmp	r2, #32
d0040aae:	d039      	beq.n	d0040b24 <fireBullet+0xbc>
d0040ab0:	ebc2 03c2 	rsb	r3, r2, r2, lsl #3
d0040ab4:	3201      	adds	r2, #1
d0040ab6:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0040aba:	7d99      	ldrb	r1, [r3, #22]
d0040abc:	2900      	cmp	r1, #0
d0040abe:	d1f5      	bne.n	d0040aac <fireBullet+0x44>
d0040ac0:	f883 8016 	strb.w	r8, [r3, #22]
d0040ac4:	2701      	movs	r7, #1
d0040ac6:	8a82      	ldrh	r2, [r0, #20]
d0040ac8:	6831      	ldr	r1, [r6, #0]
d0040aca:	b212      	sxth	r2, r2
d0040acc:	eb0e 04c1 	add.w	r4, lr, r1, lsl #3
d0040ad0:	3218      	adds	r2, #24
d0040ad2:	b249      	sxtb	r1, r1
d0040ad4:	edd4 6a00 	vldr	s13, [r4]
d0040ad8:	ee07 2a90 	vmov	s15, r2
d0040adc:	ed94 7a01 	vldr	s14, [r4, #4]
d0040ae0:	ee66 4aa5 	vmul.f32	s9, s13, s11
d0040ae4:	eef8 7ae7 	vcvt.f32.s32	s15, s15
d0040ae8:	ee27 5a25 	vmul.f32	s10, s14, s11
d0040aec:	edc3 7a02 	vstr	s15, [r3, #8]
d0040af0:	8ac2      	ldrh	r2, [r0, #22]
d0040af2:	b212      	sxth	r2, r2
d0040af4:	3218      	adds	r2, #24
d0040af6:	ee07 2a90 	vmov	s15, r2
d0040afa:	eef8 7ae7 	vcvt.f32.s32	s15, s15
d0040afe:	edc3 7a03 	vstr	s15, [r3, #12]
d0040b02:	7519      	strb	r1, [r3, #20]
d0040b04:	edc3 4a00 	vstr	s9, [r3]
d0040b08:	ed83 5a01 	vstr	s10, [r3, #4]
d0040b0c:	edd3 7a02 	vldr	s15, [r3, #8]
d0040b10:	eee6 7a86 	vfma.f32	s15, s13, s12
d0040b14:	edc3 7a02 	vstr	s15, [r3, #8]
d0040b18:	edd3 7a03 	vldr	s15, [r3, #12]
d0040b1c:	eee7 7a46 	vfms.f32	s15, s14, s12
d0040b20:	edc3 7a03 	vstr	s15, [r3, #12]
d0040b24:	3604      	adds	r6, #4
d0040b26:	45b4      	cmp	ip, r6
d0040b28:	d1be      	bne.n	d0040aa8 <fireBullet+0x40>
d0040b2a:	b917      	cbnz	r7, d0040b32 <fireBullet+0xca>
d0040b2c:	b004      	add	sp, #16
d0040b2e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0040b32:	4c26      	ldr	r4, [pc, #152]	; (d0040bcc <fireBullet+0x164>)
d0040b34:	4638      	mov	r0, r7
d0040b36:	4e26      	ldr	r6, [pc, #152]	; (d0040bd0 <fireBullet+0x168>)
d0040b38:	f06f 057e 	mvn.w	r5, #126	; 0x7e
d0040b3c:	7c23      	ldrb	r3, [r4, #16]
d0040b3e:	7c62      	ldrb	r2, [r4, #17]
d0040b40:	7ca1      	ldrb	r1, [r4, #18]
d0040b42:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040b46:	7ce2      	ldrb	r2, [r4, #19]
d0040b48:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040b4c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040b50:	689b      	ldr	r3, [r3, #8]
d0040b52:	689b      	ldr	r3, [r3, #8]
d0040b54:	4798      	blx	r3
d0040b56:	4b1c      	ldr	r3, [pc, #112]	; (d0040bc8 <fireBullet+0x160>)
d0040b58:	4638      	mov	r0, r7
d0040b5a:	8a9b      	ldrh	r3, [r3, #20]
d0040b5c:	7c21      	ldrb	r1, [r4, #16]
d0040b5e:	3320      	adds	r3, #32
d0040b60:	b21b      	sxth	r3, r3
d0040b62:	3bf0      	subs	r3, #240	; 0xf0
d0040b64:	ebc3 13c3 	rsb	r3, r3, r3, lsl #7
d0040b68:	fb86 2603 	smull	r2, r6, r6, r3
d0040b6c:	17da      	asrs	r2, r3, #31
d0040b6e:	4433      	add	r3, r6
d0040b70:	7c66      	ldrb	r6, [r4, #17]
d0040b72:	ebc2 13e3 	rsb	r3, r2, r3, asr #7
d0040b76:	ea41 2206 	orr.w	r2, r1, r6, lsl #8
d0040b7a:	7ca6      	ldrb	r6, [r4, #18]
d0040b7c:	b219      	sxth	r1, r3
d0040b7e:	ea42 4306 	orr.w	r3, r2, r6, lsl #16
d0040b82:	7ce2      	ldrb	r2, [r4, #19]
d0040b84:	297f      	cmp	r1, #127	; 0x7f
d0040b86:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040b8a:	bfa8      	it	ge
d0040b8c:	217f      	movge	r1, #127	; 0x7f
d0040b8e:	689b      	ldr	r3, [r3, #8]
d0040b90:	42a9      	cmp	r1, r5
d0040b92:	699b      	ldr	r3, [r3, #24]
d0040b94:	bfb8      	it	lt
d0040b96:	4629      	movlt	r1, r5
d0040b98:	b249      	sxtb	r1, r1
d0040b9a:	4798      	blx	r3
d0040b9c:	7c23      	ldrb	r3, [r4, #16]
d0040b9e:	7c62      	ldrb	r2, [r4, #17]
d0040ba0:	4638      	mov	r0, r7
d0040ba2:	7ca1      	ldrb	r1, [r4, #18]
d0040ba4:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040ba8:	7ce2      	ldrb	r2, [r4, #19]
d0040baa:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040bae:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040bb2:	689b      	ldr	r3, [r3, #8]
d0040bb4:	685b      	ldr	r3, [r3, #4]
d0040bb6:	b004      	add	sp, #16
d0040bb8:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d0040bbc:	4718      	bx	r3
d0040bbe:	bf00      	nop
d0040bc0:	d00435f4 	.word	0xd00435f4
d0040bc4:	d00436d0 	.word	0xd00436d0
d0040bc8:	d0043fa0 	.word	0xd0043fa0
d0040bcc:	2001f000 	.word	0x2001f000
d0040bd0:	88888889 	.word	0x88888889
d0040bd4:	d0042b74 	.word	0xd0042b74

d0040bd8 <doBullets>:
d0040bd8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0040bda:	2400      	movs	r4, #0
d0040bdc:	4d41      	ldr	r5, [pc, #260]	; (d0040ce4 <doBullets+0x10c>)
d0040bde:	4e42      	ldr	r6, [pc, #264]	; (d0040ce8 <doBullets+0x110>)
d0040be0:	ed2d 8b02 	vpush	{d8}
d0040be4:	eddf 8a41 	vldr	s17, [pc, #260]	; d0040cec <doBullets+0x114>
d0040be8:	ed9f 8a41 	vldr	s16, [pc, #260]	; d0040cf0 <doBullets+0x118>
d0040bec:	ebc4 03c4 	rsb	r3, r4, r4, lsl #3
d0040bf0:	00e2      	lsls	r2, r4, #3
d0040bf2:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0040bf6:	7d99      	ldrb	r1, [r3, #22]
d0040bf8:	2900      	cmp	r1, #0
d0040bfa:	d06c      	beq.n	d0040cd6 <doBullets+0xfe>
d0040bfc:	7d99      	ldrb	r1, [r3, #22]
d0040bfe:	eebb 7a00 	vmov.f32	s14, #176	; 0xc1800000 -16.0
d0040c02:	3901      	subs	r1, #1
d0040c04:	b2c9      	uxtb	r1, r1
d0040c06:	7599      	strb	r1, [r3, #22]
d0040c08:	edd3 6a00 	vldr	s13, [r3]
d0040c0c:	edd3 7a02 	vldr	s15, [r3, #8]
d0040c10:	ee77 7aa6 	vadd.f32	s15, s15, s13
d0040c14:	edc3 7a02 	vstr	s15, [r3, #8]
d0040c18:	edd3 6a01 	vldr	s13, [r3, #4]
d0040c1c:	edd3 7a03 	vldr	s15, [r3, #12]
d0040c20:	ee77 7ae6 	vsub.f32	s15, s15, s13
d0040c24:	edc3 7a03 	vstr	s15, [r3, #12]
d0040c28:	edd3 7a02 	vldr	s15, [r3, #8]
d0040c2c:	eef4 7ac7 	vcmpe.f32	s15, s14
d0040c30:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040c34:	d501      	bpl.n	d0040c3a <doBullets+0x62>
d0040c36:	edc3 8a02 	vstr	s17, [r3, #8]
d0040c3a:	1b13      	subs	r3, r2, r4
d0040c3c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0040c40:	edd3 7a02 	vldr	s15, [r3, #8]
d0040c44:	eef4 7ae8 	vcmpe.f32	s15, s17
d0040c48:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040c4c:	dd01      	ble.n	d0040c52 <doBullets+0x7a>
d0040c4e:	4929      	ldr	r1, [pc, #164]	; (d0040cf4 <doBullets+0x11c>)
d0040c50:	6099      	str	r1, [r3, #8]
d0040c52:	1b13      	subs	r3, r2, r4
d0040c54:	eefb 7a00 	vmov.f32	s15, #176	; 0xc1800000 -16.0
d0040c58:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0040c5c:	ed93 7a03 	vldr	s14, [r3, #12]
d0040c60:	eeb4 7ae7 	vcmpe.f32	s14, s15
d0040c64:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040c68:	d501      	bpl.n	d0040c6e <doBullets+0x96>
d0040c6a:	ed83 8a03 	vstr	s16, [r3, #12]
d0040c6e:	1b13      	subs	r3, r2, r4
d0040c70:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0040c74:	edd3 7a03 	vldr	s15, [r3, #12]
d0040c78:	eef4 7ac8 	vcmpe.f32	s15, s16
d0040c7c:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d0040c80:	dd01      	ble.n	d0040c86 <doBullets+0xae>
d0040c82:	491c      	ldr	r1, [pc, #112]	; (d0040cf4 <doBullets+0x11c>)
d0040c84:	60d9      	str	r1, [r3, #12]
d0040c86:	1b13      	subs	r3, r2, r4
d0040c88:	491b      	ldr	r1, [pc, #108]	; (d0040cf8 <doBullets+0x120>)
d0040c8a:	4817      	ldr	r0, [pc, #92]	; (d0040ce8 <doBullets+0x110>)
d0040c8c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0040c90:	edd3 7a02 	vldr	s15, [r3, #8]
d0040c94:	eefd 7ae7 	vcvt.s32.f32	s15, s15
d0040c98:	ee17 2a90 	vmov	r2, s15
d0040c9c:	b212      	sxth	r2, r2
d0040c9e:	821a      	strh	r2, [r3, #16]
d0040ca0:	edd3 7a03 	vldr	s15, [r3, #12]
d0040ca4:	eefd 7ae7 	vcvt.s32.f32	s15, s15
d0040ca8:	ee17 2a90 	vmov	r2, s15
d0040cac:	b212      	sxth	r2, r2
d0040cae:	825a      	strh	r2, [r3, #18]
d0040cb0:	7d1a      	ldrb	r2, [r3, #20]
d0040cb2:	7632      	strb	r2, [r6, #24]
d0040cb4:	8a1a      	ldrh	r2, [r3, #16]
d0040cb6:	82b2      	strh	r2, [r6, #20]
d0040cb8:	8a5b      	ldrh	r3, [r3, #18]
d0040cba:	82f3      	strh	r3, [r6, #22]
d0040cbc:	7b0b      	ldrb	r3, [r1, #12]
d0040cbe:	7b4a      	ldrb	r2, [r1, #13]
d0040cc0:	7b8f      	ldrb	r7, [r1, #14]
d0040cc2:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040cc6:	7bca      	ldrb	r2, [r1, #15]
d0040cc8:	ea43 4307 	orr.w	r3, r3, r7, lsl #16
d0040ccc:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040cd0:	685b      	ldr	r3, [r3, #4]
d0040cd2:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d0040cd4:	4798      	blx	r3
d0040cd6:	3401      	adds	r4, #1
d0040cd8:	2c20      	cmp	r4, #32
d0040cda:	d187      	bne.n	d0040bec <doBullets+0x14>
d0040cdc:	ecbd 8b02 	vpop	{d8}
d0040ce0:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0040ce2:	bf00      	nop
d0040ce4:	d00436d0 	.word	0xd00436d0
d0040ce8:	d0043e60 	.word	0xd0043e60
d0040cec:	43f00000 	.word	0x43f00000
d0040cf0:	43a00000 	.word	0x43a00000
d0040cf4:	c1800000 	.word	0xc1800000
d0040cf8:	2001f000 	.word	0x2001f000

d0040cfc <main>:
d0040cfc:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0040d00:	4cb8      	ldr	r4, [pc, #736]	; (d0040fe4 <main+0x2e8>)
d0040d02:	f44f 3000 	mov.w	r0, #131072	; 0x20000
d0040d06:	2600      	movs	r6, #0
d0040d08:	2701      	movs	r7, #1
d0040d0a:	7823      	ldrb	r3, [r4, #0]
d0040d0c:	f04f 0a60 	mov.w	sl, #96	; 0x60
d0040d10:	7862      	ldrb	r2, [r4, #1]
d0040d12:	78a1      	ldrb	r1, [r4, #2]
d0040d14:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040d18:	78e2      	ldrb	r2, [r4, #3]
d0040d1a:	4db3      	ldr	r5, [pc, #716]	; (d0040fe8 <main+0x2ec>)
d0040d1c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040d20:	f8df b2d8 	ldr.w	fp, [pc, #728]	; d0040ffc <main+0x300>
d0040d24:	f8df 92d8 	ldr.w	r9, [pc, #728]	; d0041000 <main+0x304>
d0040d28:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040d2c:	ed2d 8b04 	vpush	{d8-d9}
d0040d30:	681b      	ldr	r3, [r3, #0]
d0040d32:	b089      	sub	sp, #36	; 0x24
d0040d34:	4798      	blx	r3
d0040d36:	f7ff f9dd 	bl	d00400f4 <initMalloc>
d0040d3a:	7b23      	ldrb	r3, [r4, #12]
d0040d3c:	7b62      	ldrb	r2, [r4, #13]
d0040d3e:	2190      	movs	r1, #144	; 0x90
d0040d40:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0040d44:	20dc      	movs	r0, #220	; 0xdc
d0040d46:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040d4a:	7be2      	ldrb	r2, [r4, #15]
d0040d4c:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040d50:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040d54:	681b      	ldr	r3, [r3, #0]
d0040d56:	691b      	ldr	r3, [r3, #16]
d0040d58:	4798      	blx	r3
d0040d5a:	7b23      	ldrb	r3, [r4, #12]
d0040d5c:	7b62      	ldrb	r2, [r4, #13]
d0040d5e:	4630      	mov	r0, r6
d0040d60:	7ba1      	ldrb	r1, [r4, #14]
d0040d62:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040d66:	7be2      	ldrb	r2, [r4, #15]
d0040d68:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040d6c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040d70:	681b      	ldr	r3, [r3, #0]
d0040d72:	689b      	ldr	r3, [r3, #8]
d0040d74:	4798      	blx	r3
d0040d76:	7b21      	ldrb	r1, [r4, #12]
d0040d78:	7b62      	ldrb	r2, [r4, #13]
d0040d7a:	f04f 0c06 	mov.w	ip, #6
d0040d7e:	7ba0      	ldrb	r0, [r4, #14]
d0040d80:	f44f 73f0 	mov.w	r3, #480	; 0x1e0
d0040d84:	ea41 2102 	orr.w	r1, r1, r2, lsl #8
d0040d88:	7be2      	ldrb	r2, [r4, #15]
d0040d8a:	ea41 4100 	orr.w	r1, r1, r0, lsl #16
d0040d8e:	4618      	mov	r0, r3
d0040d90:	ea41 6102 	orr.w	r1, r1, r2, lsl #24
d0040d94:	f44f 7220 	mov.w	r2, #640	; 0x280
d0040d98:	f8d1 e000 	ldr.w	lr, [r1]
d0040d9c:	f44f 71a0 	mov.w	r1, #320	; 0x140
d0040da0:	f8cd c000 	str.w	ip, [sp]
d0040da4:	f8de 8014 	ldr.w	r8, [lr, #20]
d0040da8:	47c0      	blx	r8
d0040daa:	7c23      	ldrb	r3, [r4, #16]
d0040dac:	7c62      	ldrb	r2, [r4, #17]
d0040dae:	f44f 7000 	mov.w	r0, #512	; 0x200
d0040db2:	7ca1      	ldrb	r1, [r4, #18]
d0040db4:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040db8:	7ce2      	ldrb	r2, [r4, #19]
d0040dba:	f8df 8248 	ldr.w	r8, [pc, #584]	; d0041004 <main+0x308>
d0040dbe:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040dc2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040dc6:	681b      	ldr	r3, [r3, #0]
d0040dc8:	681b      	ldr	r3, [r3, #0]
d0040dca:	4798      	blx	r3
d0040dcc:	7c22      	ldrb	r2, [r4, #16]
d0040dce:	7c63      	ldrb	r3, [r4, #17]
d0040dd0:	7ca1      	ldrb	r1, [r4, #18]
d0040dd2:	ea42 2203 	orr.w	r2, r2, r3, lsl #8
d0040dd6:	7ce0      	ldrb	r0, [r4, #19]
d0040dd8:	7b23      	ldrb	r3, [r4, #12]
d0040dda:	ea42 4201 	orr.w	r2, r2, r1, lsl #16
d0040dde:	7b61      	ldrb	r1, [r4, #13]
d0040de0:	ea42 6200 	orr.w	r2, r2, r0, lsl #24
d0040de4:	7ba0      	ldrb	r0, [r4, #14]
d0040de6:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d0040dea:	7be1      	ldrb	r1, [r4, #15]
d0040dec:	6812      	ldr	r2, [r2, #0]
d0040dee:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d0040df2:	6852      	ldr	r2, [r2, #4]
d0040df4:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d0040df8:	7017      	strb	r7, [r2, #0]
d0040dfa:	681b      	ldr	r3, [r3, #0]
d0040dfc:	6b5b      	ldr	r3, [r3, #52]	; 0x34
d0040dfe:	4798      	blx	r3
d0040e00:	7b23      	ldrb	r3, [r4, #12]
d0040e02:	7b62      	ldrb	r2, [r4, #13]
d0040e04:	7ba1      	ldrb	r1, [r4, #14]
d0040e06:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040e0a:	7be2      	ldrb	r2, [r4, #15]
d0040e0c:	6028      	str	r0, [r5, #0]
d0040e0e:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040e12:	4d76      	ldr	r5, [pc, #472]	; (d0040fec <main+0x2f0>)
d0040e14:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040e18:	681b      	ldr	r3, [r3, #0]
d0040e1a:	6b9b      	ldr	r3, [r3, #56]	; 0x38
d0040e1c:	4798      	blx	r3
d0040e1e:	7b23      	ldrb	r3, [r4, #12]
d0040e20:	4601      	mov	r1, r0
d0040e22:	7b62      	ldrb	r2, [r4, #13]
d0040e24:	2064      	movs	r0, #100	; 0x64
d0040e26:	6029      	str	r1, [r5, #0]
d0040e28:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040e2c:	7ba1      	ldrb	r1, [r4, #14]
d0040e2e:	7be2      	ldrb	r2, [r4, #15]
d0040e30:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040e34:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040e38:	681b      	ldr	r3, [r3, #0]
d0040e3a:	689b      	ldr	r3, [r3, #8]
d0040e3c:	4798      	blx	r3
d0040e3e:	4659      	mov	r1, fp
d0040e40:	486b      	ldr	r0, [pc, #428]	; (d0040ff0 <main+0x2f4>)
d0040e42:	f7ff f9c9 	bl	d00401d8 <LoadSFX>
d0040e46:	f894 c010 	ldrb.w	ip, [r4, #16]
d0040e4a:	f894 e011 	ldrb.w	lr, [r4, #17]
d0040e4e:	4602      	mov	r2, r0
d0040e50:	7ca0      	ldrb	r0, [r4, #18]
d0040e52:	4633      	mov	r3, r6
d0040e54:	ea4c 250e 	orr.w	r5, ip, lr, lsl #8
d0040e58:	f8db 1000 	ldr.w	r1, [fp]
d0040e5c:	f04f 0b10 	mov.w	fp, #16
d0040e60:	ea45 4500 	orr.w	r5, r5, r0, lsl #16
d0040e64:	7ce0      	ldrb	r0, [r4, #19]
d0040e66:	ea45 6500 	orr.w	r5, r5, r0, lsl #24
d0040e6a:	4630      	mov	r0, r6
d0040e6c:	68ad      	ldr	r5, [r5, #8]
d0040e6e:	68ed      	ldr	r5, [r5, #12]
d0040e70:	47a8      	blx	r5
d0040e72:	7c23      	ldrb	r3, [r4, #16]
d0040e74:	7c62      	ldrb	r2, [r4, #17]
d0040e76:	f64a 4144 	movw	r1, #44100	; 0xac44
d0040e7a:	7ca0      	ldrb	r0, [r4, #18]
d0040e7c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040e80:	7ce2      	ldrb	r2, [r4, #19]
d0040e82:	4d5c      	ldr	r5, [pc, #368]	; (d0040ff4 <main+0x2f8>)
d0040e84:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d0040e88:	4630      	mov	r0, r6
d0040e8a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040e8e:	689b      	ldr	r3, [r3, #8]
d0040e90:	691b      	ldr	r3, [r3, #16]
d0040e92:	4798      	blx	r3
d0040e94:	7c23      	ldrb	r3, [r4, #16]
d0040e96:	7c62      	ldrb	r2, [r4, #17]
d0040e98:	4630      	mov	r0, r6
d0040e9a:	7ca1      	ldrb	r1, [r4, #18]
d0040e9c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040ea0:	7ce2      	ldrb	r2, [r4, #19]
d0040ea2:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040ea6:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040eaa:	689b      	ldr	r3, [r3, #8]
d0040eac:	685b      	ldr	r3, [r3, #4]
d0040eae:	4798      	blx	r3
d0040eb0:	7c23      	ldrb	r3, [r4, #16]
d0040eb2:	7c62      	ldrb	r2, [r4, #17]
d0040eb4:	21f0      	movs	r1, #240	; 0xf0
d0040eb6:	7ca0      	ldrb	r0, [r4, #18]
d0040eb8:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040ebc:	7ce2      	ldrb	r2, [r4, #19]
d0040ebe:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d0040ec2:	4630      	mov	r0, r6
d0040ec4:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040ec8:	689b      	ldr	r3, [r3, #8]
d0040eca:	695b      	ldr	r3, [r3, #20]
d0040ecc:	4798      	blx	r3
d0040ece:	7c23      	ldrb	r3, [r4, #16]
d0040ed0:	7c62      	ldrb	r2, [r4, #17]
d0040ed2:	4631      	mov	r1, r6
d0040ed4:	7ca0      	ldrb	r0, [r4, #18]
d0040ed6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040eda:	7ce2      	ldrb	r2, [r4, #19]
d0040edc:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d0040ee0:	4630      	mov	r0, r6
d0040ee2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040ee6:	689b      	ldr	r3, [r3, #8]
d0040ee8:	699b      	ldr	r3, [r3, #24]
d0040eea:	4798      	blx	r3
d0040eec:	7c23      	ldrb	r3, [r4, #16]
d0040eee:	7c60      	ldrb	r0, [r4, #17]
d0040ef0:	f241 1251 	movw	r2, #4433	; 0x1151
d0040ef4:	7ca1      	ldrb	r1, [r4, #18]
d0040ef6:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
d0040efa:	7ce0      	ldrb	r0, [r4, #19]
d0040efc:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040f00:	21c8      	movs	r1, #200	; 0xc8
d0040f02:	ea43 6300 	orr.w	r3, r3, r0, lsl #24
d0040f06:	4630      	mov	r0, r6
d0040f08:	689b      	ldr	r3, [r3, #8]
d0040f0a:	69db      	ldr	r3, [r3, #28]
d0040f0c:	4798      	blx	r3
d0040f0e:	7c23      	ldrb	r3, [r4, #16]
d0040f10:	7c62      	ldrb	r2, [r4, #17]
d0040f12:	4631      	mov	r1, r6
d0040f14:	7ca0      	ldrb	r0, [r4, #18]
d0040f16:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040f1a:	7ce2      	ldrb	r2, [r4, #19]
d0040f1c:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d0040f20:	4630      	mov	r0, r6
d0040f22:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040f26:	689b      	ldr	r3, [r3, #8]
d0040f28:	6a1b      	ldr	r3, [r3, #32]
d0040f2a:	4798      	blx	r3
d0040f2c:	4649      	mov	r1, r9
d0040f2e:	4832      	ldr	r0, [pc, #200]	; (d0040ff8 <main+0x2fc>)
d0040f30:	f7ff f952 	bl	d00401d8 <LoadSFX>
d0040f34:	7c23      	ldrb	r3, [r4, #16]
d0040f36:	f894 c011 	ldrb.w	ip, [r4, #17]
d0040f3a:	4602      	mov	r2, r0
d0040f3c:	f8d9 1000 	ldr.w	r1, [r9]
d0040f40:	4638      	mov	r0, r7
d0040f42:	ea43 2c0c 	orr.w	ip, r3, ip, lsl #8
d0040f46:	7ca3      	ldrb	r3, [r4, #18]
d0040f48:	ea4c 4c03 	orr.w	ip, ip, r3, lsl #16
d0040f4c:	7ce3      	ldrb	r3, [r4, #19]
d0040f4e:	ea4c 6c03 	orr.w	ip, ip, r3, lsl #24
d0040f52:	4633      	mov	r3, r6
d0040f54:	f8dc c008 	ldr.w	ip, [ip, #8]
d0040f58:	f8dc 900c 	ldr.w	r9, [ip, #12]
d0040f5c:	47c8      	blx	r9
d0040f5e:	7c23      	ldrb	r3, [r4, #16]
d0040f60:	7c62      	ldrb	r2, [r4, #17]
d0040f62:	4638      	mov	r0, r7
d0040f64:	f894 c012 	ldrb.w	ip, [r4, #18]
d0040f68:	f64a 4144 	movw	r1, #44100	; 0xac44
d0040f6c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040f70:	7ce2      	ldrb	r2, [r4, #19]
d0040f72:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040f76:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040f7a:	689b      	ldr	r3, [r3, #8]
d0040f7c:	691b      	ldr	r3, [r3, #16]
d0040f7e:	4798      	blx	r3
d0040f80:	7c23      	ldrb	r3, [r4, #16]
d0040f82:	7c62      	ldrb	r2, [r4, #17]
d0040f84:	4638      	mov	r0, r7
d0040f86:	f894 c012 	ldrb.w	ip, [r4, #18]
d0040f8a:	21ff      	movs	r1, #255	; 0xff
d0040f8c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040f90:	7ce2      	ldrb	r2, [r4, #19]
d0040f92:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040f96:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040f9a:	689b      	ldr	r3, [r3, #8]
d0040f9c:	695b      	ldr	r3, [r3, #20]
d0040f9e:	4798      	blx	r3
d0040fa0:	7c23      	ldrb	r3, [r4, #16]
d0040fa2:	7c62      	ldrb	r2, [r4, #17]
d0040fa4:	4638      	mov	r0, r7
d0040fa6:	f894 c012 	ldrb.w	ip, [r4, #18]
d0040faa:	4631      	mov	r1, r6
d0040fac:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040fb0:	7ce2      	ldrb	r2, [r4, #19]
d0040fb2:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040fb6:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040fba:	689b      	ldr	r3, [r3, #8]
d0040fbc:	699b      	ldr	r3, [r3, #24]
d0040fbe:	4798      	blx	r3
d0040fc0:	7c23      	ldrb	r3, [r4, #16]
d0040fc2:	f894 c011 	ldrb.w	ip, [r4, #17]
d0040fc6:	4638      	mov	r0, r7
d0040fc8:	7ca1      	ldrb	r1, [r4, #18]
d0040fca:	f241 1251 	movw	r2, #4433	; 0x1151
d0040fce:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d0040fd2:	f894 c013 	ldrb.w	ip, [r4, #19]
d0040fd6:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0040fda:	21c8      	movs	r1, #200	; 0xc8
d0040fdc:	ea43 630c 	orr.w	r3, r3, ip, lsl #24
d0040fe0:	689b      	ldr	r3, [r3, #8]
d0040fe2:	e011      	b.n	d0041008 <main+0x30c>
d0040fe4:	2001f000 	.word	0x2001f000
d0040fe8:	d0044040 	.word	0xd0044040
d0040fec:	d0044004 	.word	0xd0044004
d0040ff0:	d0042a34 	.word	0xd0042a34
d0040ff4:	d0043620 	.word	0xd0043620
d0040ff8:	d0042a48 	.word	0xd0042a48
d0040ffc:	d0043e84 	.word	0xd0043e84
d0041000:	d00436a0 	.word	0xd00436a0
d0041004:	d0043a50 	.word	0xd0043a50
d0041008:	69db      	ldr	r3, [r3, #28]
d004100a:	4798      	blx	r3
d004100c:	7c23      	ldrb	r3, [r4, #16]
d004100e:	7c62      	ldrb	r2, [r4, #17]
d0041010:	4638      	mov	r0, r7
d0041012:	f894 c012 	ldrb.w	ip, [r4, #18]
d0041016:	4631      	mov	r1, r6
d0041018:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d004101c:	7ce2      	ldrb	r2, [r4, #19]
d004101e:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0041022:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041026:	689b      	ldr	r3, [r3, #8]
d0041028:	6a1b      	ldr	r3, [r3, #32]
d004102a:	4798      	blx	r3
d004102c:	4641      	mov	r1, r8
d004102e:	48c3      	ldr	r0, [pc, #780]	; (d004133c <main+0x640>)
d0041030:	f7ff f8d2 	bl	d00401d8 <LoadSFX>
d0041034:	f894 c010 	ldrb.w	ip, [r4, #16]
d0041038:	7c61      	ldrb	r1, [r4, #17]
d004103a:	4681      	mov	r9, r0
d004103c:	7ca2      	ldrb	r2, [r4, #18]
d004103e:	4633      	mov	r3, r6
d0041040:	ea4c 2c01 	orr.w	ip, ip, r1, lsl #8
d0041044:	7ce0      	ldrb	r0, [r4, #19]
d0041046:	f8d8 1000 	ldr.w	r1, [r8]
d004104a:	ea4c 4c02 	orr.w	ip, ip, r2, lsl #16
d004104e:	464a      	mov	r2, r9
d0041050:	ea4c 6c00 	orr.w	ip, ip, r0, lsl #24
d0041054:	2002      	movs	r0, #2
d0041056:	f8dc c008 	ldr.w	ip, [ip, #8]
d004105a:	f8dc 800c 	ldr.w	r8, [ip, #12]
d004105e:	47c0      	blx	r8
d0041060:	7c23      	ldrb	r3, [r4, #16]
d0041062:	7c62      	ldrb	r2, [r4, #17]
d0041064:	f64a 4144 	movw	r1, #44100	; 0xac44
d0041068:	7ca0      	ldrb	r0, [r4, #18]
d004106a:	f44f 7800 	mov.w	r8, #512	; 0x200
d004106e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041072:	7ce2      	ldrb	r2, [r4, #19]
d0041074:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d0041078:	2002      	movs	r0, #2
d004107a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004107e:	689b      	ldr	r3, [r3, #8]
d0041080:	691b      	ldr	r3, [r3, #16]
d0041082:	4798      	blx	r3
d0041084:	7c23      	ldrb	r3, [r4, #16]
d0041086:	7c62      	ldrb	r2, [r4, #17]
d0041088:	f44f 71be 	mov.w	r1, #380	; 0x17c
d004108c:	2002      	movs	r0, #2
d004108e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041092:	7ca2      	ldrb	r2, [r4, #18]
d0041094:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0041098:	7ce2      	ldrb	r2, [r4, #19]
d004109a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004109e:	689b      	ldr	r3, [r3, #8]
d00410a0:	695b      	ldr	r3, [r3, #20]
d00410a2:	4798      	blx	r3
d00410a4:	7c23      	ldrb	r3, [r4, #16]
d00410a6:	7c62      	ldrb	r2, [r4, #17]
d00410a8:	4631      	mov	r1, r6
d00410aa:	2002      	movs	r0, #2
d00410ac:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00410b0:	7ca2      	ldrb	r2, [r4, #18]
d00410b2:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00410b6:	7ce2      	ldrb	r2, [r4, #19]
d00410b8:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00410bc:	689b      	ldr	r3, [r3, #8]
d00410be:	699b      	ldr	r3, [r3, #24]
d00410c0:	4798      	blx	r3
d00410c2:	7c23      	ldrb	r3, [r4, #16]
d00410c4:	7c60      	ldrb	r0, [r4, #17]
d00410c6:	f1a9 022c 	sub.w	r2, r9, #44	; 0x2c
d00410ca:	7ca1      	ldrb	r1, [r4, #18]
d00410cc:	f04f 09c0 	mov.w	r9, #192	; 0xc0
d00410d0:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
d00410d4:	7ce0      	ldrb	r0, [r4, #19]
d00410d6:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00410da:	21c8      	movs	r1, #200	; 0xc8
d00410dc:	ea43 6300 	orr.w	r3, r3, r0, lsl #24
d00410e0:	2002      	movs	r0, #2
d00410e2:	689b      	ldr	r3, [r3, #8]
d00410e4:	69db      	ldr	r3, [r3, #28]
d00410e6:	4798      	blx	r3
d00410e8:	7c23      	ldrb	r3, [r4, #16]
d00410ea:	7c62      	ldrb	r2, [r4, #17]
d00410ec:	4639      	mov	r1, r7
d00410ee:	7ca0      	ldrb	r0, [r4, #18]
d00410f0:	2740      	movs	r7, #64	; 0x40
d00410f2:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00410f6:	7ce2      	ldrb	r2, [r4, #19]
d00410f8:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d00410fc:	2002      	movs	r0, #2
d00410fe:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041102:	689b      	ldr	r3, [r3, #8]
d0041104:	6a1b      	ldr	r3, [r3, #32]
d0041106:	4798      	blx	r3
d0041108:	4b8d      	ldr	r3, [pc, #564]	; (d0041340 <main+0x644>)
d004110a:	4631      	mov	r1, r6
d004110c:	488d      	ldr	r0, [pc, #564]	; (d0041344 <main+0x648>)
d004110e:	601e      	str	r6, [r3, #0]
d0041110:	7c23      	ldrb	r3, [r4, #16]
d0041112:	7c62      	ldrb	r2, [r4, #17]
d0041114:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041118:	7ca2      	ldrb	r2, [r4, #18]
d004111a:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d004111e:	7ce2      	ldrb	r2, [r4, #19]
d0041120:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041124:	685b      	ldr	r3, [r3, #4]
d0041126:	681b      	ldr	r3, [r3, #0]
d0041128:	4798      	blx	r3
d004112a:	f44f 3061 	mov.w	r0, #230400	; 0x38400
d004112e:	f000 fcbf 	bl	d0041ab0 <malloc>
d0041132:	4603      	mov	r3, r0
d0041134:	4884      	ldr	r0, [pc, #528]	; (d0041348 <main+0x64c>)
d0041136:	602b      	str	r3, [r5, #0]
d0041138:	f44f 73f0 	mov.w	r3, #480	; 0x1e0
d004113c:	81ab      	strh	r3, [r5, #12]
d004113e:	81eb      	strh	r3, [r5, #14]
d0041140:	f8a5 a010 	strh.w	sl, [r5, #16]
d0041144:	f8a5 a012 	strh.w	sl, [r5, #18]
d0041148:	82ae      	strh	r6, [r5, #20]
d004114a:	82ee      	strh	r6, [r5, #22]
d004114c:	6829      	ldr	r1, [r5, #0]
d004114e:	f7fe ff7d 	bl	d004004c <LoadPPB>
d0041152:	f44f 30c0 	mov.w	r0, #98304	; 0x18000
d0041156:	f000 fcab 	bl	d0041ab0 <malloc>
d004115a:	4603      	mov	r3, r0
d004115c:	487b      	ldr	r0, [pc, #492]	; (d004134c <main+0x650>)
d004115e:	622b      	str	r3, [r5, #32]
d0041160:	f8a5 802c 	strh.w	r8, [r5, #44]	; 0x2c
d0041164:	f8a5 902e 	strh.w	r9, [r5, #46]	; 0x2e
d0041168:	862f      	strh	r7, [r5, #48]	; 0x30
d004116a:	866f      	strh	r7, [r5, #50]	; 0x32
d004116c:	86ae      	strh	r6, [r5, #52]	; 0x34
d004116e:	86ee      	strh	r6, [r5, #54]	; 0x36
d0041170:	6a29      	ldr	r1, [r5, #32]
d0041172:	f7fe ff6b 	bl	d004004c <LoadPPB>
d0041176:	f44f 30c0 	mov.w	r0, #98304	; 0x18000
d004117a:	f000 fc99 	bl	d0041ab0 <malloc>
d004117e:	4603      	mov	r3, r0
d0041180:	4873      	ldr	r0, [pc, #460]	; (d0041350 <main+0x654>)
d0041182:	642b      	str	r3, [r5, #64]	; 0x40
d0041184:	f8a5 804c 	strh.w	r8, [r5, #76]	; 0x4c
d0041188:	f8a5 904e 	strh.w	r9, [r5, #78]	; 0x4e
d004118c:	f8a5 7050 	strh.w	r7, [r5, #80]	; 0x50
d0041190:	f8a5 7052 	strh.w	r7, [r5, #82]	; 0x52
d0041194:	f8a5 6054 	strh.w	r6, [r5, #84]	; 0x54
d0041198:	f8a5 6056 	strh.w	r6, [r5, #86]	; 0x56
d004119c:	6c29      	ldr	r1, [r5, #64]	; 0x40
d004119e:	f7fe ff55 	bl	d004004c <LoadPPB>
d00411a2:	f44f 4080 	mov.w	r0, #16384	; 0x4000
d00411a6:	f000 fc83 	bl	d0041ab0 <malloc>
d00411aa:	2320      	movs	r3, #32
d00411ac:	f44f 7280 	mov.w	r2, #256	; 0x100
d00411b0:	6628      	str	r0, [r5, #96]	; 0x60
d00411b2:	4868      	ldr	r0, [pc, #416]	; (d0041354 <main+0x658>)
d00411b4:	f8a5 206c 	strh.w	r2, [r5, #108]	; 0x6c
d00411b8:	f8a5 706e 	strh.w	r7, [r5, #110]	; 0x6e
d00411bc:	f8a5 3070 	strh.w	r3, [r5, #112]	; 0x70
d00411c0:	f8a5 3072 	strh.w	r3, [r5, #114]	; 0x72
d00411c4:	f8a5 6074 	strh.w	r6, [r5, #116]	; 0x74
d00411c8:	f8a5 6076 	strh.w	r6, [r5, #118]	; 0x76
d00411cc:	6e29      	ldr	r1, [r5, #96]	; 0x60
d00411ce:	f7fe ff3d 	bl	d004004c <LoadPPB>
d00411d2:	f44f 3010 	mov.w	r0, #147456	; 0x24000
d00411d6:	f000 fc6b 	bl	d0041ab0 <malloc>
d00411da:	495f      	ldr	r1, [pc, #380]	; (d0041358 <main+0x65c>)
d00411dc:	f44f 72c0 	mov.w	r2, #384	; 0x180
d00411e0:	230a      	movs	r3, #10
d00411e2:	6008      	str	r0, [r1, #0]
d00411e4:	81ca      	strh	r2, [r1, #14]
d00411e6:	485d      	ldr	r0, [pc, #372]	; (d004135c <main+0x660>)
d00411e8:	818a      	strh	r2, [r1, #12]
d00411ea:	824f      	strh	r7, [r1, #18]
d00411ec:	820f      	strh	r7, [r1, #16]
d00411ee:	760e      	strb	r6, [r1, #24]
d00411f0:	828b      	strh	r3, [r1, #20]
d00411f2:	82cb      	strh	r3, [r1, #22]
d00411f4:	6809      	ldr	r1, [r1, #0]
d00411f6:	f7fe ff29 	bl	d004004c <LoadPPB>
d00411fa:	f44f 5010 	mov.w	r0, #9216	; 0x2400
d00411fe:	f000 fc57 	bl	d0041ab0 <malloc>
d0041202:	4b57      	ldr	r3, [pc, #348]	; (d0041360 <main+0x664>)
d0041204:	4602      	mov	r2, r0
d0041206:	4857      	ldr	r0, [pc, #348]	; (d0041364 <main+0x668>)
d0041208:	f8df 9198 	ldr.w	r9, [pc, #408]	; d00413a4 <main+0x6a8>
d004120c:	601a      	str	r2, [r3, #0]
d004120e:	f8a3 a00e 	strh.w	sl, [r3, #14]
d0041212:	f8a3 a00c 	strh.w	sl, [r3, #12]
d0041216:	f04f 0a80 	mov.w	sl, #128	; 0x80
d004121a:	f8a3 b012 	strh.w	fp, [r3, #18]
d004121e:	f8a3 b010 	strh.w	fp, [r3, #16]
d0041222:	761e      	strb	r6, [r3, #24]
d0041224:	6819      	ldr	r1, [r3, #0]
d0041226:	f7fe ff11 	bl	d004004c <LoadPPB>
d004122a:	f44f 6048 	mov.w	r0, #3200	; 0xc80
d004122e:	f000 fc3f 	bl	d0041ab0 <malloc>
d0041232:	4b4d      	ldr	r3, [pc, #308]	; (d0041368 <main+0x66c>)
d0041234:	2214      	movs	r2, #20
d0041236:	21a0      	movs	r1, #160	; 0xa0
d0041238:	6018      	str	r0, [r3, #0]
d004123a:	81da      	strh	r2, [r3, #14]
d004123c:	484b      	ldr	r0, [pc, #300]	; (d004136c <main+0x670>)
d004123e:	8199      	strh	r1, [r3, #12]
d0041240:	825a      	strh	r2, [r3, #18]
d0041242:	821a      	strh	r2, [r3, #16]
d0041244:	761e      	strb	r6, [r3, #24]
d0041246:	6819      	ldr	r1, [r3, #0]
d0041248:	f7fe ff00 	bl	d004004c <LoadPPB>
d004124c:	f44f 4020 	mov.w	r0, #40960	; 0xa000
d0041250:	f000 fc2e 	bl	d0041ab0 <malloc>
d0041254:	f44f 72a0 	mov.w	r2, #320	; 0x140
d0041258:	4603      	mov	r3, r0
d004125a:	4845      	ldr	r0, [pc, #276]	; (d0041370 <main+0x674>)
d004125c:	4d45      	ldr	r5, [pc, #276]	; (d0041374 <main+0x678>)
d004125e:	f8c9 3000 	str.w	r3, [r9]
d0041262:	f8a9 a00e 	strh.w	sl, [r9, #14]
d0041266:	f8a9 200c 	strh.w	r2, [r9, #12]
d004126a:	f8a9 7012 	strh.w	r7, [r9, #18]
d004126e:	f8a9 7010 	strh.w	r7, [r9, #16]
d0041272:	f889 6018 	strb.w	r6, [r9, #24]
d0041276:	f8d9 1000 	ldr.w	r1, [r9]
d004127a:	f7fe fee7 	bl	d004004c <LoadPPB>
d004127e:	f44f 40c0 	mov.w	r0, #24576	; 0x6000
d0041282:	f000 fc15 	bl	d0041ab0 <malloc>
d0041286:	f04f 02c0 	mov.w	r2, #192	; 0xc0
d004128a:	4603      	mov	r3, r0
d004128c:	483a      	ldr	r0, [pc, #232]	; (d0041378 <main+0x67c>)
d004128e:	f8df 8118 	ldr.w	r8, [pc, #280]	; d00413a8 <main+0x6ac>
d0041292:	602b      	str	r3, [r5, #0]
d0041294:	81ea      	strh	r2, [r5, #14]
d0041296:	f8a5 a00c 	strh.w	sl, [r5, #12]
d004129a:	f8a5 b010 	strh.w	fp, [r5, #16]
d004129e:	f8a5 b012 	strh.w	fp, [r5, #18]
d00412a2:	762e      	strb	r6, [r5, #24]
d00412a4:	6829      	ldr	r1, [r5, #0]
d00412a6:	f7fe fed1 	bl	d004004c <LoadPPB>
d00412aa:	f44f 2096 	mov.w	r0, #307200	; 0x4b000
d00412ae:	f44f 7320 	mov.w	r3, #640	; 0x280
d00412b2:	4f32      	ldr	r7, [pc, #200]	; (d004137c <main+0x680>)
d00412b4:	f8c8 000c 	str.w	r0, [r8, #12]
d00412b8:	f8a8 3004 	strh.w	r3, [r8, #4]
d00412bc:	f44f 73f0 	mov.w	r3, #480	; 0x1e0
d00412c0:	f507 6680 	add.w	r6, r7, #1024	; 0x400
d00412c4:	f8a8 3006 	strh.w	r3, [r8, #6]
d00412c8:	f8a8 3008 	strh.w	r3, [r8, #8]
d00412cc:	f000 fbf0 	bl	d0041ab0 <malloc>
d00412d0:	4603      	mov	r3, r0
d00412d2:	482b      	ldr	r0, [pc, #172]	; (d0041380 <main+0x684>)
d00412d4:	f8c8 3000 	str.w	r3, [r8]
d00412d8:	f8d8 1000 	ldr.w	r1, [r8]
d00412dc:	f7fe feb6 	bl	d004004c <LoadPPB>
d00412e0:	f7ff f914 	bl	d004050c <initAstroids>
d00412e4:	4638      	mov	r0, r7
d00412e6:	3720      	adds	r7, #32
d00412e8:	2220      	movs	r2, #32
d00412ea:	2100      	movs	r1, #0
d00412ec:	f7fe fea6 	bl	d004003c <memset>
d00412f0:	42be      	cmp	r6, r7
d00412f2:	d1f7      	bne.n	d00412e4 <main+0x5e8>
d00412f4:	4e23      	ldr	r6, [pc, #140]	; (d0041384 <main+0x688>)
d00412f6:	f506 6780 	add.w	r7, r6, #1024	; 0x400
d00412fa:	4630      	mov	r0, r6
d00412fc:	3620      	adds	r6, #32
d00412fe:	2220      	movs	r2, #32
d0041300:	2100      	movs	r1, #0
d0041302:	f7fe fe9b 	bl	d004003c <memset>
d0041306:	42b7      	cmp	r7, r6
d0041308:	d1f7      	bne.n	d00412fa <main+0x5fe>
d004130a:	2200      	movs	r2, #0
d004130c:	4f1e      	ldr	r7, [pc, #120]	; (d0041388 <main+0x68c>)
d004130e:	f8df c09c 	ldr.w	ip, [pc, #156]	; d00413ac <main+0x6b0>
d0041312:	f04f 4186 	mov.w	r1, #1124073472	; 0x43000000
d0041316:	703a      	strb	r2, [r7, #0]
d0041318:	4616      	mov	r6, r2
d004131a:	4f1c      	ldr	r7, [pc, #112]	; (d004138c <main+0x690>)
d004131c:	4b1c      	ldr	r3, [pc, #112]	; (d0041390 <main+0x694>)
d004131e:	603a      	str	r2, [r7, #0]
d0041320:	2200      	movs	r2, #0
d0041322:	4f1c      	ldr	r7, [pc, #112]	; (d0041394 <main+0x698>)
d0041324:	f503 7060 	add.w	r0, r3, #896	; 0x380
d0041328:	f8c7 c000 	str.w	ip, [r7]
d004132c:	4f1a      	ldr	r7, [pc, #104]	; (d0041398 <main+0x69c>)
d004132e:	6039      	str	r1, [r7, #0]
d0041330:	491a      	ldr	r1, [pc, #104]	; (d004139c <main+0x6a0>)
d0041332:	600a      	str	r2, [r1, #0]
d0041334:	491a      	ldr	r1, [pc, #104]	; (d00413a0 <main+0x6a4>)
d0041336:	600a      	str	r2, [r1, #0]
d0041338:	e03a      	b.n	d00413b0 <main+0x6b4>
d004133a:	bf00      	nop
d004133c:	d0042a58 	.word	0xd0042a58
d0041340:	d00431c0 	.word	0xd00431c0
d0041344:	d0042a68 	.word	0xd0042a68
d0041348:	d0042a78 	.word	0xd0042a78
d004134c:	d0042a90 	.word	0xd0042a90
d0041350:	d0042aac 	.word	0xd0042aac
d0041354:	d0042ac8 	.word	0xd0042ac8
d0041358:	d0043fa0 	.word	0xd0043fa0
d004135c:	d0042ae0 	.word	0xd0042ae0
d0041360:	d0043e60 	.word	0xd0043e60
d0041364:	d0042af0 	.word	0xd0042af0
d0041368:	d0043ea0 	.word	0xd0043ea0
d004136c:	d0042b08 	.word	0xd0042b08
d0041370:	d0042b18 	.word	0xd0042b18
d0041374:	d0043f80 	.word	0xd0043f80
d0041378:	d0042b28 	.word	0xd0042b28
d004137c:	d0044044 	.word	0xd0044044
d0041380:	d0042b3c 	.word	0xd0042b3c
d0041384:	d0043a58 	.word	0xd0043a58
d0041388:	d00435f8 	.word	0xd00435f8
d004138c:	d00435f4 	.word	0xd00435f4
d0041390:	d00436d0 	.word	0xd00436d0
d0041394:	d0043604 	.word	0xd0043604
d0041398:	d0043608 	.word	0xd0043608
d004139c:	d00435fc 	.word	0xd00435fc
d00413a0:	d0043600 	.word	0xd0043600
d00413a4:	d0044020 	.word	0xd0044020
d00413a8:	d00436c0 	.word	0xd00436c0
d00413ac:	43500000 	.word	0x43500000
d00413b0:	601e      	str	r6, [r3, #0]
d00413b2:	331c      	adds	r3, #28
d00413b4:	f843 6c18 	str.w	r6, [r3, #-24]
d00413b8:	f843 6c14 	str.w	r6, [r3, #-20]
d00413bc:	f843 6c10 	str.w	r6, [r3, #-16]
d00413c0:	f843 6c0c 	str.w	r6, [r3, #-12]
d00413c4:	f843 6c08 	str.w	r6, [r3, #-8]
d00413c8:	f843 6c04 	str.w	r6, [r3, #-4]
d00413cc:	4298      	cmp	r0, r3
d00413ce:	d1ef      	bne.n	d00413b0 <main+0x6b4>
d00413d0:	7b23      	ldrb	r3, [r4, #12]
d00413d2:	2700      	movs	r7, #0
d00413d4:	7b62      	ldrb	r2, [r4, #13]
d00413d6:	7ba1      	ldrb	r1, [r4, #14]
d00413d8:	46b8      	mov	r8, r7
d00413da:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00413de:	7be2      	ldrb	r2, [r4, #15]
d00413e0:	48b0      	ldr	r0, [pc, #704]	; (d00416a4 <main+0x9a8>)
d00413e2:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00413e6:	9707      	str	r7, [sp, #28]
d00413e8:	9706      	str	r7, [sp, #24]
d00413ea:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00413ee:	9705      	str	r7, [sp, #20]
d00413f0:	eddf 8aad 	vldr	s17, [pc, #692]	; d00416a8 <main+0x9ac>
d00413f4:	681b      	ldr	r3, [r3, #0]
d00413f6:	f8df a300 	ldr.w	sl, [pc, #768]	; d00416f8 <main+0x9fc>
d00413fa:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d00413fc:	4798      	blx	r3
d00413fe:	7b23      	ldrb	r3, [r4, #12]
d0041400:	7b62      	ldrb	r2, [r4, #13]
d0041402:	7ba1      	ldrb	r1, [r4, #14]
d0041404:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041408:	7be2      	ldrb	r2, [r4, #15]
d004140a:	48a8      	ldr	r0, [pc, #672]	; (d00416ac <main+0x9b0>)
d004140c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0041410:	ed9f 8aa7 	vldr	s16, [pc, #668]	; d00416b0 <main+0x9b4>
d0041414:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041418:	681b      	ldr	r3, [r3, #0]
d004141a:	6d1b      	ldr	r3, [r3, #80]	; 0x50
d004141c:	4798      	blx	r3
d004141e:	7b23      	ldrb	r3, [r4, #12]
d0041420:	7b62      	ldrb	r2, [r4, #13]
d0041422:	7ba1      	ldrb	r1, [r4, #14]
d0041424:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041428:	7be2      	ldrb	r2, [r4, #15]
d004142a:	48a2      	ldr	r0, [pc, #648]	; (d00416b4 <main+0x9b8>)
d004142c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0041430:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041434:	681b      	ldr	r3, [r3, #0]
d0041436:	6a1b      	ldr	r3, [r3, #32]
d0041438:	4798      	blx	r3
d004143a:	7b23      	ldrb	r3, [r4, #12]
d004143c:	7b62      	ldrb	r2, [r4, #13]
d004143e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041442:	7ba2      	ldrb	r2, [r4, #14]
d0041444:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0041448:	7be2      	ldrb	r2, [r4, #15]
d004144a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004144e:	4a9a      	ldr	r2, [pc, #616]	; (d00416b8 <main+0x9bc>)
d0041450:	681b      	ldr	r3, [r3, #0]
d0041452:	6810      	ldr	r0, [r2, #0]
d0041454:	69db      	ldr	r3, [r3, #28]
d0041456:	4798      	blx	r3
d0041458:	7b23      	ldrb	r3, [r4, #12]
d004145a:	7b62      	ldrb	r2, [r4, #13]
d004145c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041460:	7ba2      	ldrb	r2, [r4, #14]
d0041462:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0041466:	7be2      	ldrb	r2, [r4, #15]
d0041468:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004146c:	4a92      	ldr	r2, [pc, #584]	; (d00416b8 <main+0x9bc>)
d004146e:	681b      	ldr	r3, [r3, #0]
d0041470:	6810      	ldr	r0, [r2, #0]
d0041472:	699b      	ldr	r3, [r3, #24]
d0041474:	4798      	blx	r3
d0041476:	4991      	ldr	r1, [pc, #580]	; (d00416bc <main+0x9c0>)
d0041478:	2203      	movs	r2, #3
d004147a:	4b91      	ldr	r3, [pc, #580]	; (d00416c0 <main+0x9c4>)
d004147c:	edc1 8a00 	vstr	s17, [r1]
d0041480:	4990      	ldr	r1, [pc, #576]	; (d00416c4 <main+0x9c8>)
d0041482:	601e      	str	r6, [r3, #0]
d0041484:	2301      	movs	r3, #1
d0041486:	edc1 8a00 	vstr	s17, [r1]
d004148a:	498f      	ldr	r1, [pc, #572]	; (d00416c8 <main+0x9cc>)
d004148c:	9302      	str	r3, [sp, #8]
d004148e:	700a      	strb	r2, [r1, #0]
d0041490:	4a8e      	ldr	r2, [pc, #568]	; (d00416cc <main+0x9d0>)
d0041492:	7013      	strb	r3, [r2, #0]
d0041494:	7820      	ldrb	r0, [r4, #0]
d0041496:	7861      	ldrb	r1, [r4, #1]
d0041498:	78a2      	ldrb	r2, [r4, #2]
d004149a:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d004149e:	78e3      	ldrb	r3, [r4, #3]
d00414a0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00414a4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00414a8:	691b      	ldr	r3, [r3, #16]
d00414aa:	4798      	blx	r3
d00414ac:	4606      	mov	r6, r0
d00414ae:	f7ff fa15 	bl	d00408dc <ShipUpdate>
d00414b2:	f006 0301 	and.w	r3, r6, #1
d00414b6:	ea83 0808 	eor.w	r8, r3, r8
d00414ba:	9303      	str	r3, [sp, #12]
d00414bc:	ea06 0808 	and.w	r8, r6, r8
d00414c0:	f018 0f01 	tst.w	r8, #1
d00414c4:	f040 827e 	bne.w	d00419c4 <main+0xcc8>
d00414c8:	f006 0302 	and.w	r3, r6, #2
d00414cc:	07b2      	lsls	r2, r6, #30
d00414ce:	9304      	str	r3, [sp, #16]
d00414d0:	f140 8204 	bpl.w	d00418dc <main+0xbe0>
d00414d4:	42bb      	cmp	r3, r7
d00414d6:	f000 8201 	beq.w	d00418dc <main+0xbe0>
d00414da:	231f      	movs	r3, #31
d00414dc:	9306      	str	r3, [sp, #24]
d00414de:	4b7c      	ldr	r3, [pc, #496]	; (d00416d0 <main+0x9d4>)
d00414e0:	781b      	ldrb	r3, [r3, #0]
d00414e2:	b9a3      	cbnz	r3, d004150e <main+0x812>
d00414e4:	f016 0604 	ands.w	r6, r6, #4
d00414e8:	f040 8292 	bne.w	d0041a10 <main+0xd14>
d00414ec:	9b07      	ldr	r3, [sp, #28]
d00414ee:	b173      	cbz	r3, d004150e <main+0x812>
d00414f0:	7c23      	ldrb	r3, [r4, #16]
d00414f2:	2002      	movs	r0, #2
d00414f4:	7c61      	ldrb	r1, [r4, #17]
d00414f6:	7ca2      	ldrb	r2, [r4, #18]
d00414f8:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d00414fc:	9607      	str	r6, [sp, #28]
d00414fe:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0041502:	7ce2      	ldrb	r2, [r4, #19]
d0041504:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041508:	689b      	ldr	r3, [r3, #8]
d004150a:	689b      	ldr	r3, [r3, #8]
d004150c:	4798      	blx	r3
d004150e:	4b71      	ldr	r3, [pc, #452]	; (d00416d4 <main+0x9d8>)
d0041510:	4971      	ldr	r1, [pc, #452]	; (d00416d8 <main+0x9dc>)
d0041512:	ed93 7a00 	vldr	s14, [r3]
d0041516:	4b71      	ldr	r3, [pc, #452]	; (d00416dc <main+0x9e0>)
d0041518:	eebd 7ac7 	vcvt.s32.f32	s14, s14
d004151c:	edd3 7a00 	vldr	s15, [r3]
d0041520:	4b6f      	ldr	r3, [pc, #444]	; (d00416e0 <main+0x9e4>)
d0041522:	eefd 7ae7 	vcvt.s32.f32	s15, s15
d0041526:	781b      	ldrb	r3, [r3, #0]
d0041528:	760b      	strb	r3, [r1, #24]
d004152a:	ee17 3a10 	vmov	r3, s14
d004152e:	b21a      	sxth	r2, r3
d0041530:	ee17 3a90 	vmov	r3, s15
d0041534:	b21b      	sxth	r3, r3
d0041536:	828a      	strh	r2, [r1, #20]
d0041538:	82cb      	strh	r3, [r1, #22]
d004153a:	9b05      	ldr	r3, [sp, #20]
d004153c:	2b63      	cmp	r3, #99	; 0x63
d004153e:	d810      	bhi.n	d0041562 <main+0x866>
d0041540:	7b20      	ldrb	r0, [r4, #12]
d0041542:	3301      	adds	r3, #1
d0041544:	7b61      	ldrb	r1, [r4, #13]
d0041546:	7ba2      	ldrb	r2, [r4, #14]
d0041548:	b2de      	uxtb	r6, r3
d004154a:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d004154e:	7be3      	ldrb	r3, [r4, #15]
d0041550:	4630      	mov	r0, r6
d0041552:	9605      	str	r6, [sp, #20]
d0041554:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0041558:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d004155c:	681b      	ldr	r3, [r3, #0]
d004155e:	689b      	ldr	r3, [r3, #8]
d0041560:	4798      	blx	r3
d0041562:	4b56      	ldr	r3, [pc, #344]	; (d00416bc <main+0x9c0>)
d0041564:	4a5f      	ldr	r2, [pc, #380]	; (d00416e4 <main+0x9e8>)
d0041566:	ed93 7a00 	vldr	s14, [r3]
d004156a:	ed92 6a00 	vldr	s12, [r2]
d004156e:	495e      	ldr	r1, [pc, #376]	; (d00416e8 <main+0x9ec>)
d0041570:	ee37 7a06 	vadd.f32	s14, s14, s12
d0041574:	4a53      	ldr	r2, [pc, #332]	; (d00416c4 <main+0x9c8>)
d0041576:	edd1 6a00 	vldr	s13, [r1]
d004157a:	edd2 7a00 	vldr	s15, [r2]
d004157e:	eeb4 7ac8 	vcmpe.f32	s14, s16
d0041582:	ed83 7a00 	vstr	s14, [r3]
d0041586:	ee77 7aa6 	vadd.f32	s15, s15, s13
d004158a:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d004158e:	edc2 7a00 	vstr	s15, [r2]
d0041592:	f340 820b 	ble.w	d00419ac <main+0xcb0>
d0041596:	ed83 8a00 	vstr	s16, [r3]
d004159a:	23a0      	movs	r3, #160	; 0xa0
d004159c:	ee09 3a10 	vmov	s18, r3
d00415a0:	eef4 7ac8 	vcmpe.f32	s15, s16
d00415a4:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00415a8:	f340 81f4 	ble.w	d0041994 <main+0xc98>
d00415ac:	4b45      	ldr	r3, [pc, #276]	; (d00416c4 <main+0x9c8>)
d00415ae:	ed83 8a00 	vstr	s16, [r3]
d00415b2:	23a0      	movs	r3, #160	; 0xa0
d00415b4:	ee09 3a90 	vmov	s19, r3
d00415b8:	7b20      	ldrb	r0, [r4, #12]
d00415ba:	7b61      	ldrb	r1, [r4, #13]
d00415bc:	7ba2      	ldrb	r2, [r4, #14]
d00415be:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d00415c2:	7be3      	ldrb	r3, [r4, #15]
d00415c4:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00415c8:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00415cc:	681b      	ldr	r3, [r3, #0]
d00415ce:	68db      	ldr	r3, [r3, #12]
d00415d0:	4798      	blx	r3
d00415d2:	4a3f      	ldr	r2, [pc, #252]	; (d00416d0 <main+0x9d4>)
d00415d4:	7813      	ldrb	r3, [r2, #0]
d00415d6:	f1c3 0301 	rsb	r3, r3, #1
d00415da:	b2db      	uxtb	r3, r3
d00415dc:	7013      	strb	r3, [r2, #0]
d00415de:	7813      	ldrb	r3, [r2, #0]
d00415e0:	7b21      	ldrb	r1, [r4, #12]
d00415e2:	7b60      	ldrb	r0, [r4, #13]
d00415e4:	7ba2      	ldrb	r2, [r4, #14]
d00415e6:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d00415ea:	2b00      	cmp	r3, #0
d00415ec:	f000 81cb 	beq.w	d0041986 <main+0xc8a>
d00415f0:	493e      	ldr	r1, [pc, #248]	; (d00416ec <main+0x9f0>)
d00415f2:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d00415f6:	7be3      	ldrb	r3, [r4, #15]
d00415f8:	6809      	ldr	r1, [r1, #0]
d00415fa:	482f      	ldr	r0, [pc, #188]	; (d00416b8 <main+0x9bc>)
d00415fc:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0041600:	6800      	ldr	r0, [r0, #0]
d0041602:	f04f 0b00 	mov.w	fp, #0
d0041606:	4e3a      	ldr	r6, [pc, #232]	; (d00416f0 <main+0x9f4>)
d0041608:	681b      	ldr	r3, [r3, #0]
d004160a:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d004160c:	4798      	blx	r3
d004160e:	7b23      	ldrb	r3, [r4, #12]
d0041610:	7b62      	ldrb	r2, [r4, #13]
d0041612:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041616:	7ba2      	ldrb	r2, [r4, #14]
d0041618:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d004161c:	7be2      	ldrb	r2, [r4, #15]
d004161e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041622:	685b      	ldr	r3, [r3, #4]
d0041624:	681b      	ldr	r3, [r3, #0]
d0041626:	4798      	blx	r3
d0041628:	f7ff f868 	bl	d00406fc <proc_astroids>
d004162c:	f7ff fad4 	bl	d0040bd8 <doBullets>
d0041630:	f7fe fed8 	bl	d00403e4 <doFlames>
d0041634:	4b2f      	ldr	r3, [pc, #188]	; (d00416f4 <main+0x9f8>)
d0041636:	4630      	mov	r0, r6
d0041638:	eb03 124b 	add.w	r2, r3, fp, lsl #5
d004163c:	f10b 0b01 	add.w	fp, fp, #1
d0041640:	7d93      	ldrb	r3, [r2, #22]
d0041642:	b303      	cbz	r3, d0041686 <main+0x98a>
d0041644:	8a13      	ldrh	r3, [r2, #16]
d0041646:	f8a9 3014 	strh.w	r3, [r9, #20]
d004164a:	8a53      	ldrh	r3, [r2, #18]
d004164c:	f8a9 3016 	strh.w	r3, [r9, #22]
d0041650:	7d93      	ldrb	r3, [r2, #22]
d0041652:	f1c3 0314 	rsb	r3, r3, #20
d0041656:	f3c3 0347 	ubfx	r3, r3, #1, #8
d004165a:	2b09      	cmp	r3, #9
d004165c:	bf28      	it	cs
d004165e:	2309      	movcs	r3, #9
d0041660:	f889 3018 	strb.w	r3, [r9, #24]
d0041664:	7d93      	ldrb	r3, [r2, #22]
d0041666:	3b01      	subs	r3, #1
d0041668:	b2db      	uxtb	r3, r3
d004166a:	7593      	strb	r3, [r2, #22]
d004166c:	7b27      	ldrb	r7, [r4, #12]
d004166e:	7b61      	ldrb	r1, [r4, #13]
d0041670:	7ba2      	ldrb	r2, [r4, #14]
d0041672:	ea47 2101 	orr.w	r1, r7, r1, lsl #8
d0041676:	7be3      	ldrb	r3, [r4, #15]
d0041678:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d004167c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0041680:	685b      	ldr	r3, [r3, #4]
d0041682:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d0041684:	4798      	blx	r3
d0041686:	f1bb 0f20 	cmp.w	fp, #32
d004168a:	d1d3      	bne.n	d0041634 <main+0x938>
d004168c:	7b20      	ldrb	r0, [r4, #12]
d004168e:	7b61      	ldrb	r1, [r4, #13]
d0041690:	7ba2      	ldrb	r2, [r4, #14]
d0041692:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0041696:	7be3      	ldrb	r3, [r4, #15]
d0041698:	480f      	ldr	r0, [pc, #60]	; (d00416d8 <main+0x9dc>)
d004169a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d004169e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00416a2:	e02b      	b.n	d00416fc <main+0xa00>
d00416a4:	d00431c0 	.word	0xd00431c0
d00416a8:	00000000 	.word	0x00000000
d00416ac:	d0042dc0 	.word	0xd0042dc0
d00416b0:	43200000 	.word	0x43200000
d00416b4:	d00436c0 	.word	0xd00436c0
d00416b8:	d0044040 	.word	0xd0044040
d00416bc:	d0043a54 	.word	0xd0043a54
d00416c0:	d00435ec 	.word	0xd00435ec
d00416c4:	d0044000 	.word	0xd0044000
d00416c8:	d00435e8 	.word	0xd00435e8
d00416cc:	d00435f0 	.word	0xd00435f0
d00416d0:	d00435f1 	.word	0xd00435f1
d00416d4:	d0043604 	.word	0xd0043604
d00416d8:	d0043fa0 	.word	0xd0043fa0
d00416dc:	d0043608 	.word	0xd0043608
d00416e0:	d00435f4 	.word	0xd00435f4
d00416e4:	d00435fc 	.word	0xd00435fc
d00416e8:	d0043600 	.word	0xd0043600
d00416ec:	d0044004 	.word	0xd0044004
d00416f0:	d0044020 	.word	0xd0044020
d00416f4:	d0043a58 	.word	0xd0043a58
d00416f8:	d0043fc0 	.word	0xd0043fc0
d00416fc:	685b      	ldr	r3, [r3, #4]
d00416fe:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d0041700:	4798      	blx	r3
d0041702:	4bb2      	ldr	r3, [pc, #712]	; (d00419cc <main+0xcd0>)
d0041704:	49b2      	ldr	r1, [pc, #712]	; (d00419d0 <main+0xcd4>)
d0041706:	4650      	mov	r0, sl
d0041708:	681a      	ldr	r2, [r3, #0]
d004170a:	f000 fb5f 	bl	d0041dcc <siprintf>
d004170e:	4bb1      	ldr	r3, [pc, #708]	; (d00419d4 <main+0xcd8>)
d0041710:	781b      	ldrb	r3, [r3, #0]
d0041712:	b32b      	cbz	r3, d0041760 <main+0xa64>
d0041714:	260a      	movs	r6, #10
d0041716:	f8df 82bc 	ldr.w	r8, [pc, #700]	; d00419d4 <main+0xcd8>
d004171a:	4faf      	ldr	r7, [pc, #700]	; (d00419d8 <main+0xcdc>)
d004171c:	46b3      	mov	fp, r6
d004171e:	f1a3 0220 	sub.w	r2, r3, #32
d0041722:	2b0a      	cmp	r3, #10
d0041724:	4638      	mov	r0, r7
d0041726:	ea22 73e2 	bic.w	r3, r2, r2, asr #31
d004172a:	f000 80c0 	beq.w	d00418ae <main+0xbb2>
d004172e:	b2db      	uxtb	r3, r3
d0041730:	82ae      	strh	r6, [r5, #20]
d0041732:	f8a5 b016 	strh.w	fp, [r5, #22]
d0041736:	3610      	adds	r6, #16
d0041738:	762b      	strb	r3, [r5, #24]
d004173a:	f894 c00c 	ldrb.w	ip, [r4, #12]
d004173e:	b236      	sxth	r6, r6
d0041740:	7b61      	ldrb	r1, [r4, #13]
d0041742:	7ba2      	ldrb	r2, [r4, #14]
d0041744:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d0041748:	7be3      	ldrb	r3, [r4, #15]
d004174a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d004174e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0041752:	685b      	ldr	r3, [r3, #4]
d0041754:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d0041756:	4798      	blx	r3
d0041758:	f818 3f01 	ldrb.w	r3, [r8, #1]!
d004175c:	2b00      	cmp	r3, #0
d004175e:	d1de      	bne.n	d004171e <main+0xa22>
d0041760:	4b9e      	ldr	r3, [pc, #632]	; (d00419dc <main+0xce0>)
d0041762:	4650      	mov	r0, sl
d0041764:	499e      	ldr	r1, [pc, #632]	; (d00419e0 <main+0xce4>)
d0041766:	781a      	ldrb	r2, [r3, #0]
d0041768:	f000 fb30 	bl	d0041dcc <siprintf>
d004176c:	4b99      	ldr	r3, [pc, #612]	; (d00419d4 <main+0xcd8>)
d004176e:	781b      	ldrb	r3, [r3, #0]
d0041770:	b33b      	cbz	r3, d00417c2 <main+0xac6>
d0041772:	f8df 8260 	ldr.w	r8, [pc, #608]	; d00419d4 <main+0xcd8>
d0041776:	f44f 76aa 	mov.w	r6, #340	; 0x154
d004177a:	f04f 0b0a 	mov.w	fp, #10
d004177e:	4f96      	ldr	r7, [pc, #600]	; (d00419d8 <main+0xcdc>)
d0041780:	f1a3 0220 	sub.w	r2, r3, #32
d0041784:	2b0a      	cmp	r3, #10
d0041786:	4638      	mov	r0, r7
d0041788:	ea22 73e2 	bic.w	r3, r2, r2, asr #31
d004178c:	f000 809a 	beq.w	d00418c4 <main+0xbc8>
d0041790:	b2db      	uxtb	r3, r3
d0041792:	82ae      	strh	r6, [r5, #20]
d0041794:	f8a5 b016 	strh.w	fp, [r5, #22]
d0041798:	3610      	adds	r6, #16
d004179a:	762b      	strb	r3, [r5, #24]
d004179c:	f894 c00c 	ldrb.w	ip, [r4, #12]
d00417a0:	b236      	sxth	r6, r6
d00417a2:	7b61      	ldrb	r1, [r4, #13]
d00417a4:	7ba2      	ldrb	r2, [r4, #14]
d00417a6:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d00417aa:	7be3      	ldrb	r3, [r4, #15]
d00417ac:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00417b0:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00417b4:	685b      	ldr	r3, [r3, #4]
d00417b6:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d00417b8:	4798      	blx	r3
d00417ba:	f818 3f01 	ldrb.w	r3, [r8, #1]!
d00417be:	2b00      	cmp	r3, #0
d00417c0:	d1de      	bne.n	d0041780 <main+0xa84>
d00417c2:	4b88      	ldr	r3, [pc, #544]	; (d00419e4 <main+0xce8>)
d00417c4:	4650      	mov	r0, sl
d00417c6:	4988      	ldr	r1, [pc, #544]	; (d00419e8 <main+0xcec>)
d00417c8:	781a      	ldrb	r2, [r3, #0]
d00417ca:	f000 faff 	bl	d0041dcc <siprintf>
d00417ce:	4b81      	ldr	r3, [pc, #516]	; (d00419d4 <main+0xcd8>)
d00417d0:	781b      	ldrb	r3, [r3, #0]
d00417d2:	b32b      	cbz	r3, d0041820 <main+0xb24>
d00417d4:	f8df 81fc 	ldr.w	r8, [pc, #508]	; d00419d4 <main+0xcd8>
d00417d8:	260a      	movs	r6, #10
d00417da:	f44f 7b93 	mov.w	fp, #294	; 0x126
d00417de:	4f7e      	ldr	r7, [pc, #504]	; (d00419d8 <main+0xcdc>)
d00417e0:	f1a3 0220 	sub.w	r2, r3, #32
d00417e4:	2b0a      	cmp	r3, #10
d00417e6:	4638      	mov	r0, r7
d00417e8:	ea22 73e2 	bic.w	r3, r2, r2, asr #31
d00417ec:	d055      	beq.n	d004189a <main+0xb9e>
d00417ee:	b2db      	uxtb	r3, r3
d00417f0:	82ae      	strh	r6, [r5, #20]
d00417f2:	f8a5 b016 	strh.w	fp, [r5, #22]
d00417f6:	3610      	adds	r6, #16
d00417f8:	762b      	strb	r3, [r5, #24]
d00417fa:	f894 c00c 	ldrb.w	ip, [r4, #12]
d00417fe:	b236      	sxth	r6, r6
d0041800:	7b61      	ldrb	r1, [r4, #13]
d0041802:	7ba2      	ldrb	r2, [r4, #14]
d0041804:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d0041808:	7be3      	ldrb	r3, [r4, #15]
d004180a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d004180e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0041812:	685b      	ldr	r3, [r3, #4]
d0041814:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d0041816:	4798      	blx	r3
d0041818:	f818 3f01 	ldrb.w	r3, [r8, #1]!
d004181c:	2b00      	cmp	r3, #0
d004181e:	d1df      	bne.n	d00417e0 <main+0xae4>
d0041820:	4b72      	ldr	r3, [pc, #456]	; (d00419ec <main+0xcf0>)
d0041822:	f04f 0200 	mov.w	r2, #0
d0041826:	ee19 1a90 	vmov	r1, s19
d004182a:	ee19 0a10 	vmov	r0, s18
d004182e:	711a      	strb	r2, [r3, #4]
d0041830:	7b26      	ldrb	r6, [r4, #12]
d0041832:	7b62      	ldrb	r2, [r4, #13]
d0041834:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0041838:	ea46 2602 	orr.w	r6, r6, r2, lsl #8
d004183c:	7be3      	ldrb	r3, [r4, #15]
d004183e:	ea46 420c 	orr.w	r2, r6, ip, lsl #16
d0041842:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0041846:	681b      	ldr	r3, [r3, #0]
d0041848:	6b1b      	ldr	r3, [r3, #48]	; 0x30
d004184a:	4798      	blx	r3
d004184c:	7b20      	ldrb	r0, [r4, #12]
d004184e:	7b61      	ldrb	r1, [r4, #13]
d0041850:	7ba2      	ldrb	r2, [r4, #14]
d0041852:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0041856:	7be3      	ldrb	r3, [r4, #15]
d0041858:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d004185c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0041860:	681b      	ldr	r3, [r3, #0]
d0041862:	681b      	ldr	r3, [r3, #0]
d0041864:	4798      	blx	r3
d0041866:	9b02      	ldr	r3, [sp, #8]
d0041868:	3301      	adds	r3, #1
d004186a:	b2db      	uxtb	r3, r3
d004186c:	2b65      	cmp	r3, #101	; 0x65
d004186e:	9302      	str	r3, [sp, #8]
d0041870:	d10f      	bne.n	d0041892 <main+0xb96>
d0041872:	7c23      	ldrb	r3, [r4, #16]
d0041874:	2200      	movs	r2, #0
d0041876:	7c61      	ldrb	r1, [r4, #17]
d0041878:	4610      	mov	r0, r2
d004187a:	9202      	str	r2, [sp, #8]
d004187c:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d0041880:	7ca2      	ldrb	r2, [r4, #18]
d0041882:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0041886:	7ce2      	ldrb	r2, [r4, #19]
d0041888:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004188c:	689b      	ldr	r3, [r3, #8]
d004188e:	689b      	ldr	r3, [r3, #8]
d0041890:	4798      	blx	r3
d0041892:	9f04      	ldr	r7, [sp, #16]
d0041894:	f8dd 800c 	ldr.w	r8, [sp, #12]
d0041898:	e5fc      	b.n	d0041494 <main+0x798>
d004189a:	f10b 0b10 	add.w	fp, fp, #16
d004189e:	f818 3f01 	ldrb.w	r3, [r8, #1]!
d00418a2:	260a      	movs	r6, #10
d00418a4:	fa0f fb8b 	sxth.w	fp, fp
d00418a8:	2b00      	cmp	r3, #0
d00418aa:	d199      	bne.n	d00417e0 <main+0xae4>
d00418ac:	e7b8      	b.n	d0041820 <main+0xb24>
d00418ae:	f10b 0b10 	add.w	fp, fp, #16
d00418b2:	f818 3f01 	ldrb.w	r3, [r8, #1]!
d00418b6:	260a      	movs	r6, #10
d00418b8:	fa0f fb8b 	sxth.w	fp, fp
d00418bc:	2b00      	cmp	r3, #0
d00418be:	f47f af2e 	bne.w	d004171e <main+0xa22>
d00418c2:	e74d      	b.n	d0041760 <main+0xa64>
d00418c4:	f10b 0b10 	add.w	fp, fp, #16
d00418c8:	f818 3f01 	ldrb.w	r3, [r8, #1]!
d00418cc:	f44f 76aa 	mov.w	r6, #340	; 0x154
d00418d0:	fa0f fb8b 	sxth.w	fp, fp
d00418d4:	2b00      	cmp	r3, #0
d00418d6:	f47f af53 	bne.w	d0041780 <main+0xa84>
d00418da:	e772      	b.n	d00417c2 <main+0xac6>
d00418dc:	9b06      	ldr	r3, [sp, #24]
d00418de:	2b00      	cmp	r3, #0
d00418e0:	f43f adfd 	beq.w	d00414de <main+0x7e2>
d00418e4:	f103 3cff 	add.w	ip, r3, #4294967295	; 0xffffffff
d00418e8:	fa5f f38c 	uxtb.w	r3, ip
d00418ec:	f01c 0c03 	ands.w	ip, ip, #3
d00418f0:	9306      	str	r3, [sp, #24]
d00418f2:	f47f adf4 	bne.w	d00414de <main+0x7e2>
d00418f6:	4b3e      	ldr	r3, [pc, #248]	; (d00419f0 <main+0xcf4>)
d00418f8:	681a      	ldr	r2, [r3, #0]
d00418fa:	ea82 3242 	eor.w	r2, r2, r2, lsl #13
d00418fe:	ea82 4252 	eor.w	r2, r2, r2, lsr #17
d0041902:	ea82 1242 	eor.w	r2, r2, r2, lsl #5
d0041906:	ea82 3742 	eor.w	r7, r2, r2, lsl #13
d004190a:	ea87 4757 	eor.w	r7, r7, r7, lsr #17
d004190e:	ea87 1747 	eor.w	r7, r7, r7, lsl #5
d0041912:	601f      	str	r7, [r3, #0]
d0041914:	e003      	b.n	d004191e <main+0xc22>
d0041916:	f1bc 0f20 	cmp.w	ip, #32
d004191a:	f43f ade0 	beq.w	d00414de <main+0x7e2>
d004191e:	4b35      	ldr	r3, [pc, #212]	; (d00419f4 <main+0xcf8>)
d0041920:	eb03 134c 	add.w	r3, r3, ip, lsl #5
d0041924:	f10c 0c01 	add.w	ip, ip, #1
d0041928:	7d99      	ldrb	r1, [r3, #22]
d004192a:	f103 0016 	add.w	r0, r3, #22
d004192e:	f001 0eff 	and.w	lr, r1, #255	; 0xff
d0041932:	2900      	cmp	r1, #0
d0041934:	d1ef      	bne.n	d0041916 <main+0xc1a>
d0041936:	4683      	mov	fp, r0
d0041938:	482f      	ldr	r0, [pc, #188]	; (d00419f8 <main+0xcfc>)
d004193a:	4671      	mov	r1, lr
d004193c:	f04f 0814 	mov.w	r8, #20
d0041940:	fba0 0c02 	umull	r0, ip, r0, r2
d0041944:	482d      	ldr	r0, [pc, #180]	; (d00419fc <main+0xd00>)
d0041946:	f88b 8000 	strb.w	r8, [fp]
d004194a:	eba2 0e0c 	sub.w	lr, r2, ip
d004194e:	fba0 8007 	umull	r8, r0, r0, r7
d0041952:	7519      	strb	r1, [r3, #20]
d0041954:	eb0c 0c5e 	add.w	ip, ip, lr, lsr #1
d0041958:	7619      	strb	r1, [r3, #24]
d004195a:	0a00      	lsrs	r0, r0, #8
d004195c:	ea4f 2c1c 	mov.w	ip, ip, lsr #8
d0041960:	eb00 0880 	add.w	r8, r0, r0, lsl #2
d0041964:	ebcc 1e0c 	rsb	lr, ip, ip, lsl #4
d0041968:	eb00 1088 	add.w	r0, r0, r8, lsl #6
d004196c:	eb0c 1c4e 	add.w	ip, ip, lr, lsl #5
d0041970:	1a38      	subs	r0, r7, r0
d0041972:	eba2 020c 	sub.w	r2, r2, ip
d0041976:	3820      	subs	r0, #32
d0041978:	3a20      	subs	r2, #32
d004197a:	b200      	sxth	r0, r0
d004197c:	b212      	sxth	r2, r2
d004197e:	821a      	strh	r2, [r3, #16]
d0041980:	8258      	strh	r0, [r3, #18]
d0041982:	7519      	strb	r1, [r3, #20]
d0041984:	e5ab      	b.n	d00414de <main+0x7e2>
d0041986:	491e      	ldr	r1, [pc, #120]	; (d0041a00 <main+0xd04>)
d0041988:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d004198c:	7be3      	ldrb	r3, [r4, #15]
d004198e:	6809      	ldr	r1, [r1, #0]
d0041990:	481c      	ldr	r0, [pc, #112]	; (d0041a04 <main+0xd08>)
d0041992:	e633      	b.n	d00415fc <main+0x900>
d0041994:	eef5 7ac0 	vcmpe.f32	s15, #0.0
d0041998:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d004199c:	d579      	bpl.n	d0041a92 <main+0xd96>
d004199e:	2300      	movs	r3, #0
d00419a0:	ee09 3a90 	vmov	s19, r3
d00419a4:	4b18      	ldr	r3, [pc, #96]	; (d0041a08 <main+0xd0c>)
d00419a6:	edc3 8a00 	vstr	s17, [r3]
d00419aa:	e605      	b.n	d00415b8 <main+0x8bc>
d00419ac:	eeb5 7ac0 	vcmpe.f32	s14, #0.0
d00419b0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00419b4:	d568      	bpl.n	d0041a88 <main+0xd8c>
d00419b6:	2300      	movs	r3, #0
d00419b8:	ee09 3a10 	vmov	s18, r3
d00419bc:	4b13      	ldr	r3, [pc, #76]	; (d0041a0c <main+0xd10>)
d00419be:	edc3 8a00 	vstr	s17, [r3]
d00419c2:	e5ed      	b.n	d00415a0 <main+0x8a4>
d00419c4:	f7ff f850 	bl	d0040a68 <fireBullet>
d00419c8:	e57e      	b.n	d00414c8 <main+0x7cc>
d00419ca:	bf00      	nop
d00419cc:	d00435ec 	.word	0xd00435ec
d00419d0:	d0042b4c 	.word	0xd0042b4c
d00419d4:	d0043fc0 	.word	0xd0043fc0
d00419d8:	d0043f80 	.word	0xd0043f80
d00419dc:	d00435e8 	.word	0xd00435e8
d00419e0:	d0042b5c 	.word	0xd0042b5c
d00419e4:	d00435f0 	.word	0xd00435f0
d00419e8:	d0042b68 	.word	0xd0042b68
d00419ec:	d0043fa0 	.word	0xd0043fa0
d00419f0:	d00435c0 	.word	0xd00435c0
d00419f4:	d0043a58 	.word	0xd0043a58
d00419f8:	107fbbe1 	.word	0x107fbbe1
d00419fc:	cc29786d 	.word	0xcc29786d
d0041a00:	d0044040 	.word	0xd0044040
d0041a04:	d0044004 	.word	0xd0044004
d0041a08:	d0044000 	.word	0xd0044000
d0041a0c:	d0043a54 	.word	0xd0043a54
d0041a10:	f7fe fc6a 	bl	d00402e8 <spawnFlame>
d0041a14:	9b07      	ldr	r3, [sp, #28]
d0041a16:	b96b      	cbnz	r3, d0041a34 <main+0xd38>
d0041a18:	7c23      	ldrb	r3, [r4, #16]
d0041a1a:	2002      	movs	r0, #2
d0041a1c:	7c62      	ldrb	r2, [r4, #17]
d0041a1e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0041a22:	7ca2      	ldrb	r2, [r4, #18]
d0041a24:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0041a28:	7ce2      	ldrb	r2, [r4, #19]
d0041a2a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0041a2e:	689b      	ldr	r3, [r3, #8]
d0041a30:	685b      	ldr	r3, [r3, #4]
d0041a32:	4798      	blx	r3
d0041a34:	4b19      	ldr	r3, [pc, #100]	; (d0041a9c <main+0xda0>)
d0041a36:	f06f 017e 	mvn.w	r1, #126	; 0x7e
d0041a3a:	2002      	movs	r0, #2
d0041a3c:	8a9e      	ldrh	r6, [r3, #20]
d0041a3e:	4b18      	ldr	r3, [pc, #96]	; (d0041aa0 <main+0xda4>)
d0041a40:	3620      	adds	r6, #32
d0041a42:	7c27      	ldrb	r7, [r4, #16]
d0041a44:	b236      	sxth	r6, r6
d0041a46:	3ef0      	subs	r6, #240	; 0xf0
d0041a48:	ebc6 16c6 	rsb	r6, r6, r6, lsl #7
d0041a4c:	fb83 2306 	smull	r2, r3, r3, r6
d0041a50:	ea4f 7ce6 	mov.w	ip, r6, asr #31
d0041a54:	7c62      	ldrb	r2, [r4, #17]
d0041a56:	4433      	add	r3, r6
d0041a58:	ea47 2702 	orr.w	r7, r7, r2, lsl #8
d0041a5c:	7ca2      	ldrb	r2, [r4, #18]
d0041a5e:	ebcc 13e3 	rsb	r3, ip, r3, asr #7
d0041a62:	ea47 4202 	orr.w	r2, r7, r2, lsl #16
d0041a66:	7ce7      	ldrb	r7, [r4, #19]
d0041a68:	b21b      	sxth	r3, r3
d0041a6a:	ea42 6707 	orr.w	r7, r2, r7, lsl #24
d0041a6e:	2b7f      	cmp	r3, #127	; 0x7f
d0041a70:	bfa8      	it	ge
d0041a72:	237f      	movge	r3, #127	; 0x7f
d0041a74:	4299      	cmp	r1, r3
d0041a76:	bfb8      	it	lt
d0041a78:	4619      	movlt	r1, r3
d0041a7a:	2301      	movs	r3, #1
d0041a7c:	9307      	str	r3, [sp, #28]
d0041a7e:	b249      	sxtb	r1, r1
d0041a80:	68bb      	ldr	r3, [r7, #8]
d0041a82:	699b      	ldr	r3, [r3, #24]
d0041a84:	4798      	blx	r3
d0041a86:	e542      	b.n	d004150e <main+0x812>
d0041a88:	eebd 7ac7 	vcvt.s32.f32	s14, s14
d0041a8c:	eeb0 9a47 	vmov.f32	s18, s14
d0041a90:	e586      	b.n	d00415a0 <main+0x8a4>
d0041a92:	eefd 7ae7 	vcvt.s32.f32	s15, s15
d0041a96:	eef0 9a67 	vmov.f32	s19, s15
d0041a9a:	e58d      	b.n	d00415b8 <main+0x8bc>
d0041a9c:	d0043fa0 	.word	0xd0043fa0
d0041aa0:	88888889 	.word	0x88888889

d0041aa4 <__errno>:
d0041aa4:	4b01      	ldr	r3, [pc, #4]	; (d0041aac <__errno+0x8>)
d0041aa6:	6818      	ldr	r0, [r3, #0]
d0041aa8:	4770      	bx	lr
d0041aaa:	bf00      	nop
d0041aac:	d0042d40 	.word	0xd0042d40

d0041ab0 <malloc>:
d0041ab0:	4b02      	ldr	r3, [pc, #8]	; (d0041abc <malloc+0xc>)
d0041ab2:	4601      	mov	r1, r0
d0041ab4:	6818      	ldr	r0, [r3, #0]
d0041ab6:	f000 b861 	b.w	d0041b7c <_malloc_r>
d0041aba:	bf00      	nop
d0041abc:	d0042d40 	.word	0xd0042d40

d0041ac0 <memcmp>:
d0041ac0:	b530      	push	{r4, r5, lr}
d0041ac2:	3901      	subs	r1, #1
d0041ac4:	2400      	movs	r4, #0
d0041ac6:	42a2      	cmp	r2, r4
d0041ac8:	d101      	bne.n	d0041ace <memcmp+0xe>
d0041aca:	2000      	movs	r0, #0
d0041acc:	e005      	b.n	d0041ada <memcmp+0x1a>
d0041ace:	5d03      	ldrb	r3, [r0, r4]
d0041ad0:	3401      	adds	r4, #1
d0041ad2:	5d0d      	ldrb	r5, [r1, r4]
d0041ad4:	42ab      	cmp	r3, r5
d0041ad6:	d0f6      	beq.n	d0041ac6 <memcmp+0x6>
d0041ad8:	1b58      	subs	r0, r3, r5
d0041ada:	bd30      	pop	{r4, r5, pc}

d0041adc <_free_r>:
d0041adc:	b537      	push	{r0, r1, r2, r4, r5, lr}
d0041ade:	2900      	cmp	r1, #0
d0041ae0:	d048      	beq.n	d0041b74 <_free_r+0x98>
d0041ae2:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0041ae6:	9001      	str	r0, [sp, #4]
d0041ae8:	2b00      	cmp	r3, #0
d0041aea:	f1a1 0404 	sub.w	r4, r1, #4
d0041aee:	bfb8      	it	lt
d0041af0:	18e4      	addlt	r4, r4, r3
d0041af2:	f000 fb69 	bl	d00421c8 <__malloc_lock>
d0041af6:	4a20      	ldr	r2, [pc, #128]	; (d0041b78 <_free_r+0x9c>)
d0041af8:	9801      	ldr	r0, [sp, #4]
d0041afa:	6813      	ldr	r3, [r2, #0]
d0041afc:	4615      	mov	r5, r2
d0041afe:	b933      	cbnz	r3, d0041b0e <_free_r+0x32>
d0041b00:	6063      	str	r3, [r4, #4]
d0041b02:	6014      	str	r4, [r2, #0]
d0041b04:	b003      	add	sp, #12
d0041b06:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d0041b0a:	f000 bb63 	b.w	d00421d4 <__malloc_unlock>
d0041b0e:	42a3      	cmp	r3, r4
d0041b10:	d90b      	bls.n	d0041b2a <_free_r+0x4e>
d0041b12:	6821      	ldr	r1, [r4, #0]
d0041b14:	1862      	adds	r2, r4, r1
d0041b16:	4293      	cmp	r3, r2
d0041b18:	bf04      	itt	eq
d0041b1a:	681a      	ldreq	r2, [r3, #0]
d0041b1c:	685b      	ldreq	r3, [r3, #4]
d0041b1e:	6063      	str	r3, [r4, #4]
d0041b20:	bf04      	itt	eq
d0041b22:	1852      	addeq	r2, r2, r1
d0041b24:	6022      	streq	r2, [r4, #0]
d0041b26:	602c      	str	r4, [r5, #0]
d0041b28:	e7ec      	b.n	d0041b04 <_free_r+0x28>
d0041b2a:	461a      	mov	r2, r3
d0041b2c:	685b      	ldr	r3, [r3, #4]
d0041b2e:	b10b      	cbz	r3, d0041b34 <_free_r+0x58>
d0041b30:	42a3      	cmp	r3, r4
d0041b32:	d9fa      	bls.n	d0041b2a <_free_r+0x4e>
d0041b34:	6811      	ldr	r1, [r2, #0]
d0041b36:	1855      	adds	r5, r2, r1
d0041b38:	42a5      	cmp	r5, r4
d0041b3a:	d10b      	bne.n	d0041b54 <_free_r+0x78>
d0041b3c:	6824      	ldr	r4, [r4, #0]
d0041b3e:	4421      	add	r1, r4
d0041b40:	1854      	adds	r4, r2, r1
d0041b42:	42a3      	cmp	r3, r4
d0041b44:	6011      	str	r1, [r2, #0]
d0041b46:	d1dd      	bne.n	d0041b04 <_free_r+0x28>
d0041b48:	681c      	ldr	r4, [r3, #0]
d0041b4a:	685b      	ldr	r3, [r3, #4]
d0041b4c:	6053      	str	r3, [r2, #4]
d0041b4e:	4421      	add	r1, r4
d0041b50:	6011      	str	r1, [r2, #0]
d0041b52:	e7d7      	b.n	d0041b04 <_free_r+0x28>
d0041b54:	d902      	bls.n	d0041b5c <_free_r+0x80>
d0041b56:	230c      	movs	r3, #12
d0041b58:	6003      	str	r3, [r0, #0]
d0041b5a:	e7d3      	b.n	d0041b04 <_free_r+0x28>
d0041b5c:	6825      	ldr	r5, [r4, #0]
d0041b5e:	1961      	adds	r1, r4, r5
d0041b60:	428b      	cmp	r3, r1
d0041b62:	bf04      	itt	eq
d0041b64:	6819      	ldreq	r1, [r3, #0]
d0041b66:	685b      	ldreq	r3, [r3, #4]
d0041b68:	6063      	str	r3, [r4, #4]
d0041b6a:	bf04      	itt	eq
d0041b6c:	1949      	addeq	r1, r1, r5
d0041b6e:	6021      	streq	r1, [r4, #0]
d0041b70:	6054      	str	r4, [r2, #4]
d0041b72:	e7c7      	b.n	d0041b04 <_free_r+0x28>
d0041b74:	b003      	add	sp, #12
d0041b76:	bd30      	pop	{r4, r5, pc}
d0041b78:	d004360c 	.word	0xd004360c

d0041b7c <_malloc_r>:
d0041b7c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0041b7e:	1ccd      	adds	r5, r1, #3
d0041b80:	f025 0503 	bic.w	r5, r5, #3
d0041b84:	3508      	adds	r5, #8
d0041b86:	2d0c      	cmp	r5, #12
d0041b88:	bf38      	it	cc
d0041b8a:	250c      	movcc	r5, #12
d0041b8c:	2d00      	cmp	r5, #0
d0041b8e:	4606      	mov	r6, r0
d0041b90:	db01      	blt.n	d0041b96 <_malloc_r+0x1a>
d0041b92:	42a9      	cmp	r1, r5
d0041b94:	d903      	bls.n	d0041b9e <_malloc_r+0x22>
d0041b96:	230c      	movs	r3, #12
d0041b98:	6033      	str	r3, [r6, #0]
d0041b9a:	2000      	movs	r0, #0
d0041b9c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0041b9e:	f000 fb13 	bl	d00421c8 <__malloc_lock>
d0041ba2:	4921      	ldr	r1, [pc, #132]	; (d0041c28 <_malloc_r+0xac>)
d0041ba4:	680a      	ldr	r2, [r1, #0]
d0041ba6:	4614      	mov	r4, r2
d0041ba8:	b99c      	cbnz	r4, d0041bd2 <_malloc_r+0x56>
d0041baa:	4f20      	ldr	r7, [pc, #128]	; (d0041c2c <_malloc_r+0xb0>)
d0041bac:	683b      	ldr	r3, [r7, #0]
d0041bae:	b923      	cbnz	r3, d0041bba <_malloc_r+0x3e>
d0041bb0:	4621      	mov	r1, r4
d0041bb2:	4630      	mov	r0, r6
d0041bb4:	f7fe faf0 	bl	d0040198 <_sbrk_r>
d0041bb8:	6038      	str	r0, [r7, #0]
d0041bba:	4629      	mov	r1, r5
d0041bbc:	4630      	mov	r0, r6
d0041bbe:	f7fe faeb 	bl	d0040198 <_sbrk_r>
d0041bc2:	1c43      	adds	r3, r0, #1
d0041bc4:	d123      	bne.n	d0041c0e <_malloc_r+0x92>
d0041bc6:	230c      	movs	r3, #12
d0041bc8:	6033      	str	r3, [r6, #0]
d0041bca:	4630      	mov	r0, r6
d0041bcc:	f000 fb02 	bl	d00421d4 <__malloc_unlock>
d0041bd0:	e7e3      	b.n	d0041b9a <_malloc_r+0x1e>
d0041bd2:	6823      	ldr	r3, [r4, #0]
d0041bd4:	1b5b      	subs	r3, r3, r5
d0041bd6:	d417      	bmi.n	d0041c08 <_malloc_r+0x8c>
d0041bd8:	2b0b      	cmp	r3, #11
d0041bda:	d903      	bls.n	d0041be4 <_malloc_r+0x68>
d0041bdc:	6023      	str	r3, [r4, #0]
d0041bde:	441c      	add	r4, r3
d0041be0:	6025      	str	r5, [r4, #0]
d0041be2:	e004      	b.n	d0041bee <_malloc_r+0x72>
d0041be4:	6863      	ldr	r3, [r4, #4]
d0041be6:	42a2      	cmp	r2, r4
d0041be8:	bf0c      	ite	eq
d0041bea:	600b      	streq	r3, [r1, #0]
d0041bec:	6053      	strne	r3, [r2, #4]
d0041bee:	4630      	mov	r0, r6
d0041bf0:	f000 faf0 	bl	d00421d4 <__malloc_unlock>
d0041bf4:	f104 000b 	add.w	r0, r4, #11
d0041bf8:	1d23      	adds	r3, r4, #4
d0041bfa:	f020 0007 	bic.w	r0, r0, #7
d0041bfe:	1ac2      	subs	r2, r0, r3
d0041c00:	d0cc      	beq.n	d0041b9c <_malloc_r+0x20>
d0041c02:	1a1b      	subs	r3, r3, r0
d0041c04:	50a3      	str	r3, [r4, r2]
d0041c06:	e7c9      	b.n	d0041b9c <_malloc_r+0x20>
d0041c08:	4622      	mov	r2, r4
d0041c0a:	6864      	ldr	r4, [r4, #4]
d0041c0c:	e7cc      	b.n	d0041ba8 <_malloc_r+0x2c>
d0041c0e:	1cc4      	adds	r4, r0, #3
d0041c10:	f024 0403 	bic.w	r4, r4, #3
d0041c14:	42a0      	cmp	r0, r4
d0041c16:	d0e3      	beq.n	d0041be0 <_malloc_r+0x64>
d0041c18:	1a21      	subs	r1, r4, r0
d0041c1a:	4630      	mov	r0, r6
d0041c1c:	f7fe fabc 	bl	d0040198 <_sbrk_r>
d0041c20:	3001      	adds	r0, #1
d0041c22:	d1dd      	bne.n	d0041be0 <_malloc_r+0x64>
d0041c24:	e7cf      	b.n	d0041bc6 <_malloc_r+0x4a>
d0041c26:	bf00      	nop
d0041c28:	d004360c 	.word	0xd004360c
d0041c2c:	d0043610 	.word	0xd0043610

d0041c30 <setbuf>:
d0041c30:	2900      	cmp	r1, #0
d0041c32:	f44f 6380 	mov.w	r3, #1024	; 0x400
d0041c36:	bf0c      	ite	eq
d0041c38:	2202      	moveq	r2, #2
d0041c3a:	2200      	movne	r2, #0
d0041c3c:	f000 b800 	b.w	d0041c40 <setvbuf>

d0041c40 <setvbuf>:
d0041c40:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d0041c44:	461d      	mov	r5, r3
d0041c46:	4b5d      	ldr	r3, [pc, #372]	; (d0041dbc <setvbuf+0x17c>)
d0041c48:	681f      	ldr	r7, [r3, #0]
d0041c4a:	4604      	mov	r4, r0
d0041c4c:	460e      	mov	r6, r1
d0041c4e:	4690      	mov	r8, r2
d0041c50:	b127      	cbz	r7, d0041c5c <setvbuf+0x1c>
d0041c52:	69bb      	ldr	r3, [r7, #24]
d0041c54:	b913      	cbnz	r3, d0041c5c <setvbuf+0x1c>
d0041c56:	4638      	mov	r0, r7
d0041c58:	f000 f9f2 	bl	d0042040 <__sinit>
d0041c5c:	4b58      	ldr	r3, [pc, #352]	; (d0041dc0 <setvbuf+0x180>)
d0041c5e:	429c      	cmp	r4, r3
d0041c60:	d167      	bne.n	d0041d32 <setvbuf+0xf2>
d0041c62:	687c      	ldr	r4, [r7, #4]
d0041c64:	f1b8 0f02 	cmp.w	r8, #2
d0041c68:	d006      	beq.n	d0041c78 <setvbuf+0x38>
d0041c6a:	f1b8 0f01 	cmp.w	r8, #1
d0041c6e:	f200 809f 	bhi.w	d0041db0 <setvbuf+0x170>
d0041c72:	2d00      	cmp	r5, #0
d0041c74:	f2c0 809c 	blt.w	d0041db0 <setvbuf+0x170>
d0041c78:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0041c7a:	07db      	lsls	r3, r3, #31
d0041c7c:	d405      	bmi.n	d0041c8a <setvbuf+0x4a>
d0041c7e:	89a3      	ldrh	r3, [r4, #12]
d0041c80:	0598      	lsls	r0, r3, #22
d0041c82:	d402      	bmi.n	d0041c8a <setvbuf+0x4a>
d0041c84:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0041c86:	f000 fa79 	bl	d004217c <__retarget_lock_acquire_recursive>
d0041c8a:	4621      	mov	r1, r4
d0041c8c:	4638      	mov	r0, r7
d0041c8e:	f000 f943 	bl	d0041f18 <_fflush_r>
d0041c92:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0041c94:	b141      	cbz	r1, d0041ca8 <setvbuf+0x68>
d0041c96:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0041c9a:	4299      	cmp	r1, r3
d0041c9c:	d002      	beq.n	d0041ca4 <setvbuf+0x64>
d0041c9e:	4638      	mov	r0, r7
d0041ca0:	f7ff ff1c 	bl	d0041adc <_free_r>
d0041ca4:	2300      	movs	r3, #0
d0041ca6:	6363      	str	r3, [r4, #52]	; 0x34
d0041ca8:	2300      	movs	r3, #0
d0041caa:	61a3      	str	r3, [r4, #24]
d0041cac:	6063      	str	r3, [r4, #4]
d0041cae:	89a3      	ldrh	r3, [r4, #12]
d0041cb0:	0619      	lsls	r1, r3, #24
d0041cb2:	d503      	bpl.n	d0041cbc <setvbuf+0x7c>
d0041cb4:	6921      	ldr	r1, [r4, #16]
d0041cb6:	4638      	mov	r0, r7
d0041cb8:	f7ff ff10 	bl	d0041adc <_free_r>
d0041cbc:	89a3      	ldrh	r3, [r4, #12]
d0041cbe:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d0041cc2:	f023 0303 	bic.w	r3, r3, #3
d0041cc6:	f1b8 0f02 	cmp.w	r8, #2
d0041cca:	81a3      	strh	r3, [r4, #12]
d0041ccc:	d06c      	beq.n	d0041da8 <setvbuf+0x168>
d0041cce:	ab01      	add	r3, sp, #4
d0041cd0:	466a      	mov	r2, sp
d0041cd2:	4621      	mov	r1, r4
d0041cd4:	4638      	mov	r0, r7
d0041cd6:	f000 fa53 	bl	d0042180 <__swhatbuf_r>
d0041cda:	89a3      	ldrh	r3, [r4, #12]
d0041cdc:	4318      	orrs	r0, r3
d0041cde:	81a0      	strh	r0, [r4, #12]
d0041ce0:	2d00      	cmp	r5, #0
d0041ce2:	d130      	bne.n	d0041d46 <setvbuf+0x106>
d0041ce4:	9d00      	ldr	r5, [sp, #0]
d0041ce6:	4628      	mov	r0, r5
d0041ce8:	f7ff fee2 	bl	d0041ab0 <malloc>
d0041cec:	4606      	mov	r6, r0
d0041cee:	2800      	cmp	r0, #0
d0041cf0:	d155      	bne.n	d0041d9e <setvbuf+0x15e>
d0041cf2:	f8dd 9000 	ldr.w	r9, [sp]
d0041cf6:	45a9      	cmp	r9, r5
d0041cf8:	d14a      	bne.n	d0041d90 <setvbuf+0x150>
d0041cfa:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0041cfe:	2200      	movs	r2, #0
d0041d00:	60a2      	str	r2, [r4, #8]
d0041d02:	f104 0247 	add.w	r2, r4, #71	; 0x47
d0041d06:	6022      	str	r2, [r4, #0]
d0041d08:	6122      	str	r2, [r4, #16]
d0041d0a:	2201      	movs	r2, #1
d0041d0c:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0041d10:	6162      	str	r2, [r4, #20]
d0041d12:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0041d14:	f043 0302 	orr.w	r3, r3, #2
d0041d18:	07d2      	lsls	r2, r2, #31
d0041d1a:	81a3      	strh	r3, [r4, #12]
d0041d1c:	d405      	bmi.n	d0041d2a <setvbuf+0xea>
d0041d1e:	f413 7f00 	tst.w	r3, #512	; 0x200
d0041d22:	d102      	bne.n	d0041d2a <setvbuf+0xea>
d0041d24:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0041d26:	f000 fa2a 	bl	d004217e <__retarget_lock_release_recursive>
d0041d2a:	4628      	mov	r0, r5
d0041d2c:	b003      	add	sp, #12
d0041d2e:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0041d32:	4b24      	ldr	r3, [pc, #144]	; (d0041dc4 <setvbuf+0x184>)
d0041d34:	429c      	cmp	r4, r3
d0041d36:	d101      	bne.n	d0041d3c <setvbuf+0xfc>
d0041d38:	68bc      	ldr	r4, [r7, #8]
d0041d3a:	e793      	b.n	d0041c64 <setvbuf+0x24>
d0041d3c:	4b22      	ldr	r3, [pc, #136]	; (d0041dc8 <setvbuf+0x188>)
d0041d3e:	429c      	cmp	r4, r3
d0041d40:	bf08      	it	eq
d0041d42:	68fc      	ldreq	r4, [r7, #12]
d0041d44:	e78e      	b.n	d0041c64 <setvbuf+0x24>
d0041d46:	2e00      	cmp	r6, #0
d0041d48:	d0cd      	beq.n	d0041ce6 <setvbuf+0xa6>
d0041d4a:	69bb      	ldr	r3, [r7, #24]
d0041d4c:	b913      	cbnz	r3, d0041d54 <setvbuf+0x114>
d0041d4e:	4638      	mov	r0, r7
d0041d50:	f000 f976 	bl	d0042040 <__sinit>
d0041d54:	f1b8 0f01 	cmp.w	r8, #1
d0041d58:	bf08      	it	eq
d0041d5a:	89a3      	ldrheq	r3, [r4, #12]
d0041d5c:	6026      	str	r6, [r4, #0]
d0041d5e:	bf04      	itt	eq
d0041d60:	f043 0301 	orreq.w	r3, r3, #1
d0041d64:	81a3      	strheq	r3, [r4, #12]
d0041d66:	89a2      	ldrh	r2, [r4, #12]
d0041d68:	f012 0308 	ands.w	r3, r2, #8
d0041d6c:	e9c4 6504 	strd	r6, r5, [r4, #16]
d0041d70:	d01c      	beq.n	d0041dac <setvbuf+0x16c>
d0041d72:	07d3      	lsls	r3, r2, #31
d0041d74:	bf41      	itttt	mi
d0041d76:	2300      	movmi	r3, #0
d0041d78:	426d      	negmi	r5, r5
d0041d7a:	60a3      	strmi	r3, [r4, #8]
d0041d7c:	61a5      	strmi	r5, [r4, #24]
d0041d7e:	bf58      	it	pl
d0041d80:	60a5      	strpl	r5, [r4, #8]
d0041d82:	6e65      	ldr	r5, [r4, #100]	; 0x64
d0041d84:	f015 0501 	ands.w	r5, r5, #1
d0041d88:	d115      	bne.n	d0041db6 <setvbuf+0x176>
d0041d8a:	f412 7f00 	tst.w	r2, #512	; 0x200
d0041d8e:	e7c8      	b.n	d0041d22 <setvbuf+0xe2>
d0041d90:	4648      	mov	r0, r9
d0041d92:	f7ff fe8d 	bl	d0041ab0 <malloc>
d0041d96:	4606      	mov	r6, r0
d0041d98:	2800      	cmp	r0, #0
d0041d9a:	d0ae      	beq.n	d0041cfa <setvbuf+0xba>
d0041d9c:	464d      	mov	r5, r9
d0041d9e:	89a3      	ldrh	r3, [r4, #12]
d0041da0:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0041da4:	81a3      	strh	r3, [r4, #12]
d0041da6:	e7d0      	b.n	d0041d4a <setvbuf+0x10a>
d0041da8:	2500      	movs	r5, #0
d0041daa:	e7a8      	b.n	d0041cfe <setvbuf+0xbe>
d0041dac:	60a3      	str	r3, [r4, #8]
d0041dae:	e7e8      	b.n	d0041d82 <setvbuf+0x142>
d0041db0:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0041db4:	e7b9      	b.n	d0041d2a <setvbuf+0xea>
d0041db6:	2500      	movs	r5, #0
d0041db8:	e7b7      	b.n	d0041d2a <setvbuf+0xea>
d0041dba:	bf00      	nop
d0041dbc:	d0042d40 	.word	0xd0042d40
d0041dc0:	d0042cb4 	.word	0xd0042cb4
d0041dc4:	d0042cd4 	.word	0xd0042cd4
d0041dc8:	d0042c94 	.word	0xd0042c94

d0041dcc <siprintf>:
d0041dcc:	b40e      	push	{r1, r2, r3}
d0041dce:	b500      	push	{lr}
d0041dd0:	b09c      	sub	sp, #112	; 0x70
d0041dd2:	ab1d      	add	r3, sp, #116	; 0x74
d0041dd4:	9002      	str	r0, [sp, #8]
d0041dd6:	9006      	str	r0, [sp, #24]
d0041dd8:	f06f 4100 	mvn.w	r1, #2147483648	; 0x80000000
d0041ddc:	4809      	ldr	r0, [pc, #36]	; (d0041e04 <siprintf+0x38>)
d0041dde:	9107      	str	r1, [sp, #28]
d0041de0:	9104      	str	r1, [sp, #16]
d0041de2:	4909      	ldr	r1, [pc, #36]	; (d0041e08 <siprintf+0x3c>)
d0041de4:	f853 2b04 	ldr.w	r2, [r3], #4
d0041de8:	9105      	str	r1, [sp, #20]
d0041dea:	6800      	ldr	r0, [r0, #0]
d0041dec:	9301      	str	r3, [sp, #4]
d0041dee:	a902      	add	r1, sp, #8
d0041df0:	f000 fa52 	bl	d0042298 <_svfiprintf_r>
d0041df4:	9b02      	ldr	r3, [sp, #8]
d0041df6:	2200      	movs	r2, #0
d0041df8:	701a      	strb	r2, [r3, #0]
d0041dfa:	b01c      	add	sp, #112	; 0x70
d0041dfc:	f85d eb04 	ldr.w	lr, [sp], #4
d0041e00:	b003      	add	sp, #12
d0041e02:	4770      	bx	lr
d0041e04:	d0042d40 	.word	0xd0042d40
d0041e08:	ffff0208 	.word	0xffff0208

d0041e0c <__sflush_r>:
d0041e0c:	898a      	ldrh	r2, [r1, #12]
d0041e0e:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0041e12:	4605      	mov	r5, r0
d0041e14:	0710      	lsls	r0, r2, #28
d0041e16:	460c      	mov	r4, r1
d0041e18:	d458      	bmi.n	d0041ecc <__sflush_r+0xc0>
d0041e1a:	684b      	ldr	r3, [r1, #4]
d0041e1c:	2b00      	cmp	r3, #0
d0041e1e:	dc05      	bgt.n	d0041e2c <__sflush_r+0x20>
d0041e20:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d0041e22:	2b00      	cmp	r3, #0
d0041e24:	dc02      	bgt.n	d0041e2c <__sflush_r+0x20>
d0041e26:	2000      	movs	r0, #0
d0041e28:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0041e2c:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0041e2e:	2e00      	cmp	r6, #0
d0041e30:	d0f9      	beq.n	d0041e26 <__sflush_r+0x1a>
d0041e32:	2300      	movs	r3, #0
d0041e34:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d0041e38:	682f      	ldr	r7, [r5, #0]
d0041e3a:	602b      	str	r3, [r5, #0]
d0041e3c:	d032      	beq.n	d0041ea4 <__sflush_r+0x98>
d0041e3e:	6d60      	ldr	r0, [r4, #84]	; 0x54
d0041e40:	89a3      	ldrh	r3, [r4, #12]
d0041e42:	075a      	lsls	r2, r3, #29
d0041e44:	d505      	bpl.n	d0041e52 <__sflush_r+0x46>
d0041e46:	6863      	ldr	r3, [r4, #4]
d0041e48:	1ac0      	subs	r0, r0, r3
d0041e4a:	6b63      	ldr	r3, [r4, #52]	; 0x34
d0041e4c:	b10b      	cbz	r3, d0041e52 <__sflush_r+0x46>
d0041e4e:	6c23      	ldr	r3, [r4, #64]	; 0x40
d0041e50:	1ac0      	subs	r0, r0, r3
d0041e52:	2300      	movs	r3, #0
d0041e54:	4602      	mov	r2, r0
d0041e56:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0041e58:	6a21      	ldr	r1, [r4, #32]
d0041e5a:	4628      	mov	r0, r5
d0041e5c:	47b0      	blx	r6
d0041e5e:	1c43      	adds	r3, r0, #1
d0041e60:	89a3      	ldrh	r3, [r4, #12]
d0041e62:	d106      	bne.n	d0041e72 <__sflush_r+0x66>
d0041e64:	6829      	ldr	r1, [r5, #0]
d0041e66:	291d      	cmp	r1, #29
d0041e68:	d82c      	bhi.n	d0041ec4 <__sflush_r+0xb8>
d0041e6a:	4a2a      	ldr	r2, [pc, #168]	; (d0041f14 <__sflush_r+0x108>)
d0041e6c:	40ca      	lsrs	r2, r1
d0041e6e:	07d6      	lsls	r6, r2, #31
d0041e70:	d528      	bpl.n	d0041ec4 <__sflush_r+0xb8>
d0041e72:	2200      	movs	r2, #0
d0041e74:	6062      	str	r2, [r4, #4]
d0041e76:	04d9      	lsls	r1, r3, #19
d0041e78:	6922      	ldr	r2, [r4, #16]
d0041e7a:	6022      	str	r2, [r4, #0]
d0041e7c:	d504      	bpl.n	d0041e88 <__sflush_r+0x7c>
d0041e7e:	1c42      	adds	r2, r0, #1
d0041e80:	d101      	bne.n	d0041e86 <__sflush_r+0x7a>
d0041e82:	682b      	ldr	r3, [r5, #0]
d0041e84:	b903      	cbnz	r3, d0041e88 <__sflush_r+0x7c>
d0041e86:	6560      	str	r0, [r4, #84]	; 0x54
d0041e88:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0041e8a:	602f      	str	r7, [r5, #0]
d0041e8c:	2900      	cmp	r1, #0
d0041e8e:	d0ca      	beq.n	d0041e26 <__sflush_r+0x1a>
d0041e90:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0041e94:	4299      	cmp	r1, r3
d0041e96:	d002      	beq.n	d0041e9e <__sflush_r+0x92>
d0041e98:	4628      	mov	r0, r5
d0041e9a:	f7ff fe1f 	bl	d0041adc <_free_r>
d0041e9e:	2000      	movs	r0, #0
d0041ea0:	6360      	str	r0, [r4, #52]	; 0x34
d0041ea2:	e7c1      	b.n	d0041e28 <__sflush_r+0x1c>
d0041ea4:	6a21      	ldr	r1, [r4, #32]
d0041ea6:	2301      	movs	r3, #1
d0041ea8:	4628      	mov	r0, r5
d0041eaa:	47b0      	blx	r6
d0041eac:	1c41      	adds	r1, r0, #1
d0041eae:	d1c7      	bne.n	d0041e40 <__sflush_r+0x34>
d0041eb0:	682b      	ldr	r3, [r5, #0]
d0041eb2:	2b00      	cmp	r3, #0
d0041eb4:	d0c4      	beq.n	d0041e40 <__sflush_r+0x34>
d0041eb6:	2b1d      	cmp	r3, #29
d0041eb8:	d001      	beq.n	d0041ebe <__sflush_r+0xb2>
d0041eba:	2b16      	cmp	r3, #22
d0041ebc:	d101      	bne.n	d0041ec2 <__sflush_r+0xb6>
d0041ebe:	602f      	str	r7, [r5, #0]
d0041ec0:	e7b1      	b.n	d0041e26 <__sflush_r+0x1a>
d0041ec2:	89a3      	ldrh	r3, [r4, #12]
d0041ec4:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0041ec8:	81a3      	strh	r3, [r4, #12]
d0041eca:	e7ad      	b.n	d0041e28 <__sflush_r+0x1c>
d0041ecc:	690f      	ldr	r7, [r1, #16]
d0041ece:	2f00      	cmp	r7, #0
d0041ed0:	d0a9      	beq.n	d0041e26 <__sflush_r+0x1a>
d0041ed2:	0793      	lsls	r3, r2, #30
d0041ed4:	680e      	ldr	r6, [r1, #0]
d0041ed6:	bf08      	it	eq
d0041ed8:	694b      	ldreq	r3, [r1, #20]
d0041eda:	600f      	str	r7, [r1, #0]
d0041edc:	bf18      	it	ne
d0041ede:	2300      	movne	r3, #0
d0041ee0:	eba6 0807 	sub.w	r8, r6, r7
d0041ee4:	608b      	str	r3, [r1, #8]
d0041ee6:	f1b8 0f00 	cmp.w	r8, #0
d0041eea:	dd9c      	ble.n	d0041e26 <__sflush_r+0x1a>
d0041eec:	6a21      	ldr	r1, [r4, #32]
d0041eee:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d0041ef0:	4643      	mov	r3, r8
d0041ef2:	463a      	mov	r2, r7
d0041ef4:	4628      	mov	r0, r5
d0041ef6:	47b0      	blx	r6
d0041ef8:	2800      	cmp	r0, #0
d0041efa:	dc06      	bgt.n	d0041f0a <__sflush_r+0xfe>
d0041efc:	89a3      	ldrh	r3, [r4, #12]
d0041efe:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0041f02:	81a3      	strh	r3, [r4, #12]
d0041f04:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0041f08:	e78e      	b.n	d0041e28 <__sflush_r+0x1c>
d0041f0a:	4407      	add	r7, r0
d0041f0c:	eba8 0800 	sub.w	r8, r8, r0
d0041f10:	e7e9      	b.n	d0041ee6 <__sflush_r+0xda>
d0041f12:	bf00      	nop
d0041f14:	20400001 	.word	0x20400001

d0041f18 <_fflush_r>:
d0041f18:	b538      	push	{r3, r4, r5, lr}
d0041f1a:	690b      	ldr	r3, [r1, #16]
d0041f1c:	4605      	mov	r5, r0
d0041f1e:	460c      	mov	r4, r1
d0041f20:	b913      	cbnz	r3, d0041f28 <_fflush_r+0x10>
d0041f22:	2500      	movs	r5, #0
d0041f24:	4628      	mov	r0, r5
d0041f26:	bd38      	pop	{r3, r4, r5, pc}
d0041f28:	b118      	cbz	r0, d0041f32 <_fflush_r+0x1a>
d0041f2a:	6983      	ldr	r3, [r0, #24]
d0041f2c:	b90b      	cbnz	r3, d0041f32 <_fflush_r+0x1a>
d0041f2e:	f000 f887 	bl	d0042040 <__sinit>
d0041f32:	4b14      	ldr	r3, [pc, #80]	; (d0041f84 <_fflush_r+0x6c>)
d0041f34:	429c      	cmp	r4, r3
d0041f36:	d11b      	bne.n	d0041f70 <_fflush_r+0x58>
d0041f38:	686c      	ldr	r4, [r5, #4]
d0041f3a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0041f3e:	2b00      	cmp	r3, #0
d0041f40:	d0ef      	beq.n	d0041f22 <_fflush_r+0xa>
d0041f42:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0041f44:	07d0      	lsls	r0, r2, #31
d0041f46:	d404      	bmi.n	d0041f52 <_fflush_r+0x3a>
d0041f48:	0599      	lsls	r1, r3, #22
d0041f4a:	d402      	bmi.n	d0041f52 <_fflush_r+0x3a>
d0041f4c:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0041f4e:	f000 f915 	bl	d004217c <__retarget_lock_acquire_recursive>
d0041f52:	4628      	mov	r0, r5
d0041f54:	4621      	mov	r1, r4
d0041f56:	f7ff ff59 	bl	d0041e0c <__sflush_r>
d0041f5a:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0041f5c:	07da      	lsls	r2, r3, #31
d0041f5e:	4605      	mov	r5, r0
d0041f60:	d4e0      	bmi.n	d0041f24 <_fflush_r+0xc>
d0041f62:	89a3      	ldrh	r3, [r4, #12]
d0041f64:	059b      	lsls	r3, r3, #22
d0041f66:	d4dd      	bmi.n	d0041f24 <_fflush_r+0xc>
d0041f68:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0041f6a:	f000 f908 	bl	d004217e <__retarget_lock_release_recursive>
d0041f6e:	e7d9      	b.n	d0041f24 <_fflush_r+0xc>
d0041f70:	4b05      	ldr	r3, [pc, #20]	; (d0041f88 <_fflush_r+0x70>)
d0041f72:	429c      	cmp	r4, r3
d0041f74:	d101      	bne.n	d0041f7a <_fflush_r+0x62>
d0041f76:	68ac      	ldr	r4, [r5, #8]
d0041f78:	e7df      	b.n	d0041f3a <_fflush_r+0x22>
d0041f7a:	4b04      	ldr	r3, [pc, #16]	; (d0041f8c <_fflush_r+0x74>)
d0041f7c:	429c      	cmp	r4, r3
d0041f7e:	bf08      	it	eq
d0041f80:	68ec      	ldreq	r4, [r5, #12]
d0041f82:	e7da      	b.n	d0041f3a <_fflush_r+0x22>
d0041f84:	d0042cb4 	.word	0xd0042cb4
d0041f88:	d0042cd4 	.word	0xd0042cd4
d0041f8c:	d0042c94 	.word	0xd0042c94

d0041f90 <std>:
d0041f90:	2300      	movs	r3, #0
d0041f92:	b510      	push	{r4, lr}
d0041f94:	4604      	mov	r4, r0
d0041f96:	e9c0 3300 	strd	r3, r3, [r0]
d0041f9a:	e9c0 3304 	strd	r3, r3, [r0, #16]
d0041f9e:	6083      	str	r3, [r0, #8]
d0041fa0:	8181      	strh	r1, [r0, #12]
d0041fa2:	6643      	str	r3, [r0, #100]	; 0x64
d0041fa4:	81c2      	strh	r2, [r0, #14]
d0041fa6:	6183      	str	r3, [r0, #24]
d0041fa8:	4619      	mov	r1, r3
d0041faa:	2208      	movs	r2, #8
d0041fac:	305c      	adds	r0, #92	; 0x5c
d0041fae:	f7fe f845 	bl	d004003c <memset>
d0041fb2:	4b05      	ldr	r3, [pc, #20]	; (d0041fc8 <std+0x38>)
d0041fb4:	6263      	str	r3, [r4, #36]	; 0x24
d0041fb6:	4b05      	ldr	r3, [pc, #20]	; (d0041fcc <std+0x3c>)
d0041fb8:	62a3      	str	r3, [r4, #40]	; 0x28
d0041fba:	4b05      	ldr	r3, [pc, #20]	; (d0041fd0 <std+0x40>)
d0041fbc:	62e3      	str	r3, [r4, #44]	; 0x2c
d0041fbe:	4b05      	ldr	r3, [pc, #20]	; (d0041fd4 <std+0x44>)
d0041fc0:	6224      	str	r4, [r4, #32]
d0041fc2:	6323      	str	r3, [r4, #48]	; 0x30
d0041fc4:	bd10      	pop	{r4, pc}
d0041fc6:	bf00      	nop
d0041fc8:	d00427c1 	.word	0xd00427c1
d0041fcc:	d00427e3 	.word	0xd00427e3
d0041fd0:	d004281b 	.word	0xd004281b
d0041fd4:	d004283f 	.word	0xd004283f

d0041fd8 <_cleanup_r>:
d0041fd8:	4901      	ldr	r1, [pc, #4]	; (d0041fe0 <_cleanup_r+0x8>)
d0041fda:	f000 b8af 	b.w	d004213c <_fwalk_reent>
d0041fde:	bf00      	nop
d0041fe0:	d0041f19 	.word	0xd0041f19

d0041fe4 <__sfmoreglue>:
d0041fe4:	b570      	push	{r4, r5, r6, lr}
d0041fe6:	1e4a      	subs	r2, r1, #1
d0041fe8:	2568      	movs	r5, #104	; 0x68
d0041fea:	4355      	muls	r5, r2
d0041fec:	460e      	mov	r6, r1
d0041fee:	f105 0174 	add.w	r1, r5, #116	; 0x74
d0041ff2:	f7ff fdc3 	bl	d0041b7c <_malloc_r>
d0041ff6:	4604      	mov	r4, r0
d0041ff8:	b140      	cbz	r0, d004200c <__sfmoreglue+0x28>
d0041ffa:	2100      	movs	r1, #0
d0041ffc:	e9c0 1600 	strd	r1, r6, [r0]
d0042000:	300c      	adds	r0, #12
d0042002:	60a0      	str	r0, [r4, #8]
d0042004:	f105 0268 	add.w	r2, r5, #104	; 0x68
d0042008:	f7fe f818 	bl	d004003c <memset>
d004200c:	4620      	mov	r0, r4
d004200e:	bd70      	pop	{r4, r5, r6, pc}

d0042010 <__sfp_lock_acquire>:
d0042010:	4801      	ldr	r0, [pc, #4]	; (d0042018 <__sfp_lock_acquire+0x8>)
d0042012:	f000 b8b3 	b.w	d004217c <__retarget_lock_acquire_recursive>
d0042016:	bf00      	nop
d0042018:	d004444c 	.word	0xd004444c

d004201c <__sfp_lock_release>:
d004201c:	4801      	ldr	r0, [pc, #4]	; (d0042024 <__sfp_lock_release+0x8>)
d004201e:	f000 b8ae 	b.w	d004217e <__retarget_lock_release_recursive>
d0042022:	bf00      	nop
d0042024:	d004444c 	.word	0xd004444c

d0042028 <__sinit_lock_acquire>:
d0042028:	4801      	ldr	r0, [pc, #4]	; (d0042030 <__sinit_lock_acquire+0x8>)
d004202a:	f000 b8a7 	b.w	d004217c <__retarget_lock_acquire_recursive>
d004202e:	bf00      	nop
d0042030:	d0044447 	.word	0xd0044447

d0042034 <__sinit_lock_release>:
d0042034:	4801      	ldr	r0, [pc, #4]	; (d004203c <__sinit_lock_release+0x8>)
d0042036:	f000 b8a2 	b.w	d004217e <__retarget_lock_release_recursive>
d004203a:	bf00      	nop
d004203c:	d0044447 	.word	0xd0044447

d0042040 <__sinit>:
d0042040:	b510      	push	{r4, lr}
d0042042:	4604      	mov	r4, r0
d0042044:	f7ff fff0 	bl	d0042028 <__sinit_lock_acquire>
d0042048:	69a3      	ldr	r3, [r4, #24]
d004204a:	b11b      	cbz	r3, d0042054 <__sinit+0x14>
d004204c:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d0042050:	f7ff bff0 	b.w	d0042034 <__sinit_lock_release>
d0042054:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d0042058:	6523      	str	r3, [r4, #80]	; 0x50
d004205a:	4b13      	ldr	r3, [pc, #76]	; (d00420a8 <__sinit+0x68>)
d004205c:	4a13      	ldr	r2, [pc, #76]	; (d00420ac <__sinit+0x6c>)
d004205e:	681b      	ldr	r3, [r3, #0]
d0042060:	62a2      	str	r2, [r4, #40]	; 0x28
d0042062:	42a3      	cmp	r3, r4
d0042064:	bf04      	itt	eq
d0042066:	2301      	moveq	r3, #1
d0042068:	61a3      	streq	r3, [r4, #24]
d004206a:	4620      	mov	r0, r4
d004206c:	f000 f820 	bl	d00420b0 <__sfp>
d0042070:	6060      	str	r0, [r4, #4]
d0042072:	4620      	mov	r0, r4
d0042074:	f000 f81c 	bl	d00420b0 <__sfp>
d0042078:	60a0      	str	r0, [r4, #8]
d004207a:	4620      	mov	r0, r4
d004207c:	f000 f818 	bl	d00420b0 <__sfp>
d0042080:	2200      	movs	r2, #0
d0042082:	60e0      	str	r0, [r4, #12]
d0042084:	2104      	movs	r1, #4
d0042086:	6860      	ldr	r0, [r4, #4]
d0042088:	f7ff ff82 	bl	d0041f90 <std>
d004208c:	68a0      	ldr	r0, [r4, #8]
d004208e:	2201      	movs	r2, #1
d0042090:	2109      	movs	r1, #9
d0042092:	f7ff ff7d 	bl	d0041f90 <std>
d0042096:	68e0      	ldr	r0, [r4, #12]
d0042098:	2202      	movs	r2, #2
d004209a:	2112      	movs	r1, #18
d004209c:	f7ff ff78 	bl	d0041f90 <std>
d00420a0:	2301      	movs	r3, #1
d00420a2:	61a3      	str	r3, [r4, #24]
d00420a4:	e7d2      	b.n	d004204c <__sinit+0xc>
d00420a6:	bf00      	nop
d00420a8:	d0042a20 	.word	0xd0042a20
d00420ac:	d0041fd9 	.word	0xd0041fd9

d00420b0 <__sfp>:
d00420b0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00420b2:	4607      	mov	r7, r0
d00420b4:	f7ff ffac 	bl	d0042010 <__sfp_lock_acquire>
d00420b8:	4b1e      	ldr	r3, [pc, #120]	; (d0042134 <__sfp+0x84>)
d00420ba:	681e      	ldr	r6, [r3, #0]
d00420bc:	69b3      	ldr	r3, [r6, #24]
d00420be:	b913      	cbnz	r3, d00420c6 <__sfp+0x16>
d00420c0:	4630      	mov	r0, r6
d00420c2:	f7ff ffbd 	bl	d0042040 <__sinit>
d00420c6:	3648      	adds	r6, #72	; 0x48
d00420c8:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d00420cc:	3b01      	subs	r3, #1
d00420ce:	d503      	bpl.n	d00420d8 <__sfp+0x28>
d00420d0:	6833      	ldr	r3, [r6, #0]
d00420d2:	b30b      	cbz	r3, d0042118 <__sfp+0x68>
d00420d4:	6836      	ldr	r6, [r6, #0]
d00420d6:	e7f7      	b.n	d00420c8 <__sfp+0x18>
d00420d8:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d00420dc:	b9d5      	cbnz	r5, d0042114 <__sfp+0x64>
d00420de:	4b16      	ldr	r3, [pc, #88]	; (d0042138 <__sfp+0x88>)
d00420e0:	60e3      	str	r3, [r4, #12]
d00420e2:	f104 0058 	add.w	r0, r4, #88	; 0x58
d00420e6:	6665      	str	r5, [r4, #100]	; 0x64
d00420e8:	f000 f847 	bl	d004217a <__retarget_lock_init_recursive>
d00420ec:	f7ff ff96 	bl	d004201c <__sfp_lock_release>
d00420f0:	e9c4 5501 	strd	r5, r5, [r4, #4]
d00420f4:	e9c4 5504 	strd	r5, r5, [r4, #16]
d00420f8:	6025      	str	r5, [r4, #0]
d00420fa:	61a5      	str	r5, [r4, #24]
d00420fc:	2208      	movs	r2, #8
d00420fe:	4629      	mov	r1, r5
d0042100:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d0042104:	f7fd ff9a 	bl	d004003c <memset>
d0042108:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d004210c:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d0042110:	4620      	mov	r0, r4
d0042112:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0042114:	3468      	adds	r4, #104	; 0x68
d0042116:	e7d9      	b.n	d00420cc <__sfp+0x1c>
d0042118:	2104      	movs	r1, #4
d004211a:	4638      	mov	r0, r7
d004211c:	f7ff ff62 	bl	d0041fe4 <__sfmoreglue>
d0042120:	4604      	mov	r4, r0
d0042122:	6030      	str	r0, [r6, #0]
d0042124:	2800      	cmp	r0, #0
d0042126:	d1d5      	bne.n	d00420d4 <__sfp+0x24>
d0042128:	f7ff ff78 	bl	d004201c <__sfp_lock_release>
d004212c:	230c      	movs	r3, #12
d004212e:	603b      	str	r3, [r7, #0]
d0042130:	e7ee      	b.n	d0042110 <__sfp+0x60>
d0042132:	bf00      	nop
d0042134:	d0042a20 	.word	0xd0042a20
d0042138:	ffff0001 	.word	0xffff0001

d004213c <_fwalk_reent>:
d004213c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0042140:	4606      	mov	r6, r0
d0042142:	4688      	mov	r8, r1
d0042144:	f100 0448 	add.w	r4, r0, #72	; 0x48
d0042148:	2700      	movs	r7, #0
d004214a:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d004214e:	f1b9 0901 	subs.w	r9, r9, #1
d0042152:	d505      	bpl.n	d0042160 <_fwalk_reent+0x24>
d0042154:	6824      	ldr	r4, [r4, #0]
d0042156:	2c00      	cmp	r4, #0
d0042158:	d1f7      	bne.n	d004214a <_fwalk_reent+0xe>
d004215a:	4638      	mov	r0, r7
d004215c:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d0042160:	89ab      	ldrh	r3, [r5, #12]
d0042162:	2b01      	cmp	r3, #1
d0042164:	d907      	bls.n	d0042176 <_fwalk_reent+0x3a>
d0042166:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d004216a:	3301      	adds	r3, #1
d004216c:	d003      	beq.n	d0042176 <_fwalk_reent+0x3a>
d004216e:	4629      	mov	r1, r5
d0042170:	4630      	mov	r0, r6
d0042172:	47c0      	blx	r8
d0042174:	4307      	orrs	r7, r0
d0042176:	3568      	adds	r5, #104	; 0x68
d0042178:	e7e9      	b.n	d004214e <_fwalk_reent+0x12>

d004217a <__retarget_lock_init_recursive>:
d004217a:	4770      	bx	lr

d004217c <__retarget_lock_acquire_recursive>:
d004217c:	4770      	bx	lr

d004217e <__retarget_lock_release_recursive>:
d004217e:	4770      	bx	lr

d0042180 <__swhatbuf_r>:
d0042180:	b570      	push	{r4, r5, r6, lr}
d0042182:	460e      	mov	r6, r1
d0042184:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0042188:	2900      	cmp	r1, #0
d004218a:	b096      	sub	sp, #88	; 0x58
d004218c:	4614      	mov	r4, r2
d004218e:	461d      	mov	r5, r3
d0042190:	da07      	bge.n	d00421a2 <__swhatbuf_r+0x22>
d0042192:	2300      	movs	r3, #0
d0042194:	602b      	str	r3, [r5, #0]
d0042196:	89b3      	ldrh	r3, [r6, #12]
d0042198:	061a      	lsls	r2, r3, #24
d004219a:	d410      	bmi.n	d00421be <__swhatbuf_r+0x3e>
d004219c:	f44f 6380 	mov.w	r3, #1024	; 0x400
d00421a0:	e00e      	b.n	d00421c0 <__swhatbuf_r+0x40>
d00421a2:	466a      	mov	r2, sp
d00421a4:	f000 fb60 	bl	d0042868 <_fstat_r>
d00421a8:	2800      	cmp	r0, #0
d00421aa:	dbf2      	blt.n	d0042192 <__swhatbuf_r+0x12>
d00421ac:	9a01      	ldr	r2, [sp, #4]
d00421ae:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d00421b2:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d00421b6:	425a      	negs	r2, r3
d00421b8:	415a      	adcs	r2, r3
d00421ba:	602a      	str	r2, [r5, #0]
d00421bc:	e7ee      	b.n	d004219c <__swhatbuf_r+0x1c>
d00421be:	2340      	movs	r3, #64	; 0x40
d00421c0:	2000      	movs	r0, #0
d00421c2:	6023      	str	r3, [r4, #0]
d00421c4:	b016      	add	sp, #88	; 0x58
d00421c6:	bd70      	pop	{r4, r5, r6, pc}

d00421c8 <__malloc_lock>:
d00421c8:	4801      	ldr	r0, [pc, #4]	; (d00421d0 <__malloc_lock+0x8>)
d00421ca:	f7ff bfd7 	b.w	d004217c <__retarget_lock_acquire_recursive>
d00421ce:	bf00      	nop
d00421d0:	d0044448 	.word	0xd0044448

d00421d4 <__malloc_unlock>:
d00421d4:	4801      	ldr	r0, [pc, #4]	; (d00421dc <__malloc_unlock+0x8>)
d00421d6:	f7ff bfd2 	b.w	d004217e <__retarget_lock_release_recursive>
d00421da:	bf00      	nop
d00421dc:	d0044448 	.word	0xd0044448

d00421e0 <__ssputs_r>:
d00421e0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d00421e4:	688e      	ldr	r6, [r1, #8]
d00421e6:	429e      	cmp	r6, r3
d00421e8:	4682      	mov	sl, r0
d00421ea:	460c      	mov	r4, r1
d00421ec:	4690      	mov	r8, r2
d00421ee:	461f      	mov	r7, r3
d00421f0:	d838      	bhi.n	d0042264 <__ssputs_r+0x84>
d00421f2:	898a      	ldrh	r2, [r1, #12]
d00421f4:	f412 6f90 	tst.w	r2, #1152	; 0x480
d00421f8:	d032      	beq.n	d0042260 <__ssputs_r+0x80>
d00421fa:	6825      	ldr	r5, [r4, #0]
d00421fc:	6909      	ldr	r1, [r1, #16]
d00421fe:	eba5 0901 	sub.w	r9, r5, r1
d0042202:	6965      	ldr	r5, [r4, #20]
d0042204:	eb05 0545 	add.w	r5, r5, r5, lsl #1
d0042208:	eb05 75d5 	add.w	r5, r5, r5, lsr #31
d004220c:	3301      	adds	r3, #1
d004220e:	444b      	add	r3, r9
d0042210:	106d      	asrs	r5, r5, #1
d0042212:	429d      	cmp	r5, r3
d0042214:	bf38      	it	cc
d0042216:	461d      	movcc	r5, r3
d0042218:	0553      	lsls	r3, r2, #21
d004221a:	d531      	bpl.n	d0042280 <__ssputs_r+0xa0>
d004221c:	4629      	mov	r1, r5
d004221e:	f7ff fcad 	bl	d0041b7c <_malloc_r>
d0042222:	4606      	mov	r6, r0
d0042224:	b950      	cbnz	r0, d004223c <__ssputs_r+0x5c>
d0042226:	230c      	movs	r3, #12
d0042228:	f8ca 3000 	str.w	r3, [sl]
d004222c:	89a3      	ldrh	r3, [r4, #12]
d004222e:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0042232:	81a3      	strh	r3, [r4, #12]
d0042234:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0042238:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d004223c:	6921      	ldr	r1, [r4, #16]
d004223e:	464a      	mov	r2, r9
d0042240:	f000 fb86 	bl	d0042950 <memcpy>
d0042244:	89a3      	ldrh	r3, [r4, #12]
d0042246:	f423 6390 	bic.w	r3, r3, #1152	; 0x480
d004224a:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d004224e:	81a3      	strh	r3, [r4, #12]
d0042250:	6126      	str	r6, [r4, #16]
d0042252:	6165      	str	r5, [r4, #20]
d0042254:	444e      	add	r6, r9
d0042256:	eba5 0509 	sub.w	r5, r5, r9
d004225a:	6026      	str	r6, [r4, #0]
d004225c:	60a5      	str	r5, [r4, #8]
d004225e:	463e      	mov	r6, r7
d0042260:	42be      	cmp	r6, r7
d0042262:	d900      	bls.n	d0042266 <__ssputs_r+0x86>
d0042264:	463e      	mov	r6, r7
d0042266:	4632      	mov	r2, r6
d0042268:	6820      	ldr	r0, [r4, #0]
d004226a:	4641      	mov	r1, r8
d004226c:	f000 fb7e 	bl	d004296c <memmove>
d0042270:	68a3      	ldr	r3, [r4, #8]
d0042272:	6822      	ldr	r2, [r4, #0]
d0042274:	1b9b      	subs	r3, r3, r6
d0042276:	4432      	add	r2, r6
d0042278:	60a3      	str	r3, [r4, #8]
d004227a:	6022      	str	r2, [r4, #0]
d004227c:	2000      	movs	r0, #0
d004227e:	e7db      	b.n	d0042238 <__ssputs_r+0x58>
d0042280:	462a      	mov	r2, r5
d0042282:	f000 fb8d 	bl	d00429a0 <_realloc_r>
d0042286:	4606      	mov	r6, r0
d0042288:	2800      	cmp	r0, #0
d004228a:	d1e1      	bne.n	d0042250 <__ssputs_r+0x70>
d004228c:	6921      	ldr	r1, [r4, #16]
d004228e:	4650      	mov	r0, sl
d0042290:	f7ff fc24 	bl	d0041adc <_free_r>
d0042294:	e7c7      	b.n	d0042226 <__ssputs_r+0x46>
	...

d0042298 <_svfiprintf_r>:
d0042298:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d004229c:	4698      	mov	r8, r3
d004229e:	898b      	ldrh	r3, [r1, #12]
d00422a0:	061b      	lsls	r3, r3, #24
d00422a2:	b09d      	sub	sp, #116	; 0x74
d00422a4:	4607      	mov	r7, r0
d00422a6:	460d      	mov	r5, r1
d00422a8:	4614      	mov	r4, r2
d00422aa:	d50e      	bpl.n	d00422ca <_svfiprintf_r+0x32>
d00422ac:	690b      	ldr	r3, [r1, #16]
d00422ae:	b963      	cbnz	r3, d00422ca <_svfiprintf_r+0x32>
d00422b0:	2140      	movs	r1, #64	; 0x40
d00422b2:	f7ff fc63 	bl	d0041b7c <_malloc_r>
d00422b6:	6028      	str	r0, [r5, #0]
d00422b8:	6128      	str	r0, [r5, #16]
d00422ba:	b920      	cbnz	r0, d00422c6 <_svfiprintf_r+0x2e>
d00422bc:	230c      	movs	r3, #12
d00422be:	603b      	str	r3, [r7, #0]
d00422c0:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00422c4:	e0d1      	b.n	d004246a <_svfiprintf_r+0x1d2>
d00422c6:	2340      	movs	r3, #64	; 0x40
d00422c8:	616b      	str	r3, [r5, #20]
d00422ca:	2300      	movs	r3, #0
d00422cc:	9309      	str	r3, [sp, #36]	; 0x24
d00422ce:	2320      	movs	r3, #32
d00422d0:	f88d 3029 	strb.w	r3, [sp, #41]	; 0x29
d00422d4:	f8cd 800c 	str.w	r8, [sp, #12]
d00422d8:	2330      	movs	r3, #48	; 0x30
d00422da:	f8df 81a8 	ldr.w	r8, [pc, #424]	; d0042484 <_svfiprintf_r+0x1ec>
d00422de:	f88d 302a 	strb.w	r3, [sp, #42]	; 0x2a
d00422e2:	f04f 0901 	mov.w	r9, #1
d00422e6:	4623      	mov	r3, r4
d00422e8:	469a      	mov	sl, r3
d00422ea:	f813 2b01 	ldrb.w	r2, [r3], #1
d00422ee:	b10a      	cbz	r2, d00422f4 <_svfiprintf_r+0x5c>
d00422f0:	2a25      	cmp	r2, #37	; 0x25
d00422f2:	d1f9      	bne.n	d00422e8 <_svfiprintf_r+0x50>
d00422f4:	ebba 0b04 	subs.w	fp, sl, r4
d00422f8:	d00b      	beq.n	d0042312 <_svfiprintf_r+0x7a>
d00422fa:	465b      	mov	r3, fp
d00422fc:	4622      	mov	r2, r4
d00422fe:	4629      	mov	r1, r5
d0042300:	4638      	mov	r0, r7
d0042302:	f7ff ff6d 	bl	d00421e0 <__ssputs_r>
d0042306:	3001      	adds	r0, #1
d0042308:	f000 80aa 	beq.w	d0042460 <_svfiprintf_r+0x1c8>
d004230c:	9a09      	ldr	r2, [sp, #36]	; 0x24
d004230e:	445a      	add	r2, fp
d0042310:	9209      	str	r2, [sp, #36]	; 0x24
d0042312:	f89a 3000 	ldrb.w	r3, [sl]
d0042316:	2b00      	cmp	r3, #0
d0042318:	f000 80a2 	beq.w	d0042460 <_svfiprintf_r+0x1c8>
d004231c:	2300      	movs	r3, #0
d004231e:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d0042322:	e9cd 2305 	strd	r2, r3, [sp, #20]
d0042326:	f10a 0a01 	add.w	sl, sl, #1
d004232a:	9304      	str	r3, [sp, #16]
d004232c:	9307      	str	r3, [sp, #28]
d004232e:	f88d 3053 	strb.w	r3, [sp, #83]	; 0x53
d0042332:	931a      	str	r3, [sp, #104]	; 0x68
d0042334:	4654      	mov	r4, sl
d0042336:	2205      	movs	r2, #5
d0042338:	f814 1b01 	ldrb.w	r1, [r4], #1
d004233c:	4851      	ldr	r0, [pc, #324]	; (d0042484 <_svfiprintf_r+0x1ec>)
d004233e:	f000 fab7 	bl	d00428b0 <memchr>
d0042342:	9a04      	ldr	r2, [sp, #16]
d0042344:	b9d8      	cbnz	r0, d004237e <_svfiprintf_r+0xe6>
d0042346:	06d0      	lsls	r0, r2, #27
d0042348:	bf44      	itt	mi
d004234a:	2320      	movmi	r3, #32
d004234c:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d0042350:	0711      	lsls	r1, r2, #28
d0042352:	bf44      	itt	mi
d0042354:	232b      	movmi	r3, #43	; 0x2b
d0042356:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d004235a:	f89a 3000 	ldrb.w	r3, [sl]
d004235e:	2b2a      	cmp	r3, #42	; 0x2a
d0042360:	d015      	beq.n	d004238e <_svfiprintf_r+0xf6>
d0042362:	9a07      	ldr	r2, [sp, #28]
d0042364:	4654      	mov	r4, sl
d0042366:	2000      	movs	r0, #0
d0042368:	f04f 0c0a 	mov.w	ip, #10
d004236c:	4621      	mov	r1, r4
d004236e:	f811 3b01 	ldrb.w	r3, [r1], #1
d0042372:	3b30      	subs	r3, #48	; 0x30
d0042374:	2b09      	cmp	r3, #9
d0042376:	d94e      	bls.n	d0042416 <_svfiprintf_r+0x17e>
d0042378:	b1b0      	cbz	r0, d00423a8 <_svfiprintf_r+0x110>
d004237a:	9207      	str	r2, [sp, #28]
d004237c:	e014      	b.n	d00423a8 <_svfiprintf_r+0x110>
d004237e:	eba0 0308 	sub.w	r3, r0, r8
d0042382:	fa09 f303 	lsl.w	r3, r9, r3
d0042386:	4313      	orrs	r3, r2
d0042388:	9304      	str	r3, [sp, #16]
d004238a:	46a2      	mov	sl, r4
d004238c:	e7d2      	b.n	d0042334 <_svfiprintf_r+0x9c>
d004238e:	9b03      	ldr	r3, [sp, #12]
d0042390:	1d19      	adds	r1, r3, #4
d0042392:	681b      	ldr	r3, [r3, #0]
d0042394:	9103      	str	r1, [sp, #12]
d0042396:	2b00      	cmp	r3, #0
d0042398:	bfbb      	ittet	lt
d004239a:	425b      	neglt	r3, r3
d004239c:	f042 0202 	orrlt.w	r2, r2, #2
d00423a0:	9307      	strge	r3, [sp, #28]
d00423a2:	9307      	strlt	r3, [sp, #28]
d00423a4:	bfb8      	it	lt
d00423a6:	9204      	strlt	r2, [sp, #16]
d00423a8:	7823      	ldrb	r3, [r4, #0]
d00423aa:	2b2e      	cmp	r3, #46	; 0x2e
d00423ac:	d10c      	bne.n	d00423c8 <_svfiprintf_r+0x130>
d00423ae:	7863      	ldrb	r3, [r4, #1]
d00423b0:	2b2a      	cmp	r3, #42	; 0x2a
d00423b2:	d135      	bne.n	d0042420 <_svfiprintf_r+0x188>
d00423b4:	9b03      	ldr	r3, [sp, #12]
d00423b6:	1d1a      	adds	r2, r3, #4
d00423b8:	681b      	ldr	r3, [r3, #0]
d00423ba:	9203      	str	r2, [sp, #12]
d00423bc:	2b00      	cmp	r3, #0
d00423be:	bfb8      	it	lt
d00423c0:	f04f 33ff 	movlt.w	r3, #4294967295	; 0xffffffff
d00423c4:	3402      	adds	r4, #2
d00423c6:	9305      	str	r3, [sp, #20]
d00423c8:	f8df a0c8 	ldr.w	sl, [pc, #200]	; d0042494 <_svfiprintf_r+0x1fc>
d00423cc:	7821      	ldrb	r1, [r4, #0]
d00423ce:	2203      	movs	r2, #3
d00423d0:	4650      	mov	r0, sl
d00423d2:	f000 fa6d 	bl	d00428b0 <memchr>
d00423d6:	b140      	cbz	r0, d00423ea <_svfiprintf_r+0x152>
d00423d8:	2340      	movs	r3, #64	; 0x40
d00423da:	eba0 000a 	sub.w	r0, r0, sl
d00423de:	fa03 f000 	lsl.w	r0, r3, r0
d00423e2:	9b04      	ldr	r3, [sp, #16]
d00423e4:	4303      	orrs	r3, r0
d00423e6:	3401      	adds	r4, #1
d00423e8:	9304      	str	r3, [sp, #16]
d00423ea:	f814 1b01 	ldrb.w	r1, [r4], #1
d00423ee:	4826      	ldr	r0, [pc, #152]	; (d0042488 <_svfiprintf_r+0x1f0>)
d00423f0:	f88d 1028 	strb.w	r1, [sp, #40]	; 0x28
d00423f4:	2206      	movs	r2, #6
d00423f6:	f000 fa5b 	bl	d00428b0 <memchr>
d00423fa:	2800      	cmp	r0, #0
d00423fc:	d038      	beq.n	d0042470 <_svfiprintf_r+0x1d8>
d00423fe:	4b23      	ldr	r3, [pc, #140]	; (d004248c <_svfiprintf_r+0x1f4>)
d0042400:	bb1b      	cbnz	r3, d004244a <_svfiprintf_r+0x1b2>
d0042402:	9b03      	ldr	r3, [sp, #12]
d0042404:	3307      	adds	r3, #7
d0042406:	f023 0307 	bic.w	r3, r3, #7
d004240a:	3308      	adds	r3, #8
d004240c:	9303      	str	r3, [sp, #12]
d004240e:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0042410:	4433      	add	r3, r6
d0042412:	9309      	str	r3, [sp, #36]	; 0x24
d0042414:	e767      	b.n	d00422e6 <_svfiprintf_r+0x4e>
d0042416:	fb0c 3202 	mla	r2, ip, r2, r3
d004241a:	460c      	mov	r4, r1
d004241c:	2001      	movs	r0, #1
d004241e:	e7a5      	b.n	d004236c <_svfiprintf_r+0xd4>
d0042420:	2300      	movs	r3, #0
d0042422:	3401      	adds	r4, #1
d0042424:	9305      	str	r3, [sp, #20]
d0042426:	4619      	mov	r1, r3
d0042428:	f04f 0c0a 	mov.w	ip, #10
d004242c:	4620      	mov	r0, r4
d004242e:	f810 2b01 	ldrb.w	r2, [r0], #1
d0042432:	3a30      	subs	r2, #48	; 0x30
d0042434:	2a09      	cmp	r2, #9
d0042436:	d903      	bls.n	d0042440 <_svfiprintf_r+0x1a8>
d0042438:	2b00      	cmp	r3, #0
d004243a:	d0c5      	beq.n	d00423c8 <_svfiprintf_r+0x130>
d004243c:	9105      	str	r1, [sp, #20]
d004243e:	e7c3      	b.n	d00423c8 <_svfiprintf_r+0x130>
d0042440:	fb0c 2101 	mla	r1, ip, r1, r2
d0042444:	4604      	mov	r4, r0
d0042446:	2301      	movs	r3, #1
d0042448:	e7f0      	b.n	d004242c <_svfiprintf_r+0x194>
d004244a:	ab03      	add	r3, sp, #12
d004244c:	9300      	str	r3, [sp, #0]
d004244e:	462a      	mov	r2, r5
d0042450:	4b0f      	ldr	r3, [pc, #60]	; (d0042490 <_svfiprintf_r+0x1f8>)
d0042452:	a904      	add	r1, sp, #16
d0042454:	4638      	mov	r0, r7
d0042456:	f3af 8000 	nop.w
d004245a:	1c42      	adds	r2, r0, #1
d004245c:	4606      	mov	r6, r0
d004245e:	d1d6      	bne.n	d004240e <_svfiprintf_r+0x176>
d0042460:	89ab      	ldrh	r3, [r5, #12]
d0042462:	065b      	lsls	r3, r3, #25
d0042464:	f53f af2c 	bmi.w	d00422c0 <_svfiprintf_r+0x28>
d0042468:	9809      	ldr	r0, [sp, #36]	; 0x24
d004246a:	b01d      	add	sp, #116	; 0x74
d004246c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0042470:	ab03      	add	r3, sp, #12
d0042472:	9300      	str	r3, [sp, #0]
d0042474:	462a      	mov	r2, r5
d0042476:	4b06      	ldr	r3, [pc, #24]	; (d0042490 <_svfiprintf_r+0x1f8>)
d0042478:	a904      	add	r1, sp, #16
d004247a:	4638      	mov	r0, r7
d004247c:	f000 f87a 	bl	d0042574 <_printf_i>
d0042480:	e7eb      	b.n	d004245a <_svfiprintf_r+0x1c2>
d0042482:	bf00      	nop
d0042484:	d0042cf4 	.word	0xd0042cf4
d0042488:	d0042cfe 	.word	0xd0042cfe
d004248c:	00000000 	.word	0x00000000
d0042490:	d00421e1 	.word	0xd00421e1
d0042494:	d0042cfa 	.word	0xd0042cfa

d0042498 <_printf_common>:
d0042498:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d004249c:	4616      	mov	r6, r2
d004249e:	4699      	mov	r9, r3
d00424a0:	688a      	ldr	r2, [r1, #8]
d00424a2:	690b      	ldr	r3, [r1, #16]
d00424a4:	f8dd 8020 	ldr.w	r8, [sp, #32]
d00424a8:	4293      	cmp	r3, r2
d00424aa:	bfb8      	it	lt
d00424ac:	4613      	movlt	r3, r2
d00424ae:	6033      	str	r3, [r6, #0]
d00424b0:	f891 2043 	ldrb.w	r2, [r1, #67]	; 0x43
d00424b4:	4607      	mov	r7, r0
d00424b6:	460c      	mov	r4, r1
d00424b8:	b10a      	cbz	r2, d00424be <_printf_common+0x26>
d00424ba:	3301      	adds	r3, #1
d00424bc:	6033      	str	r3, [r6, #0]
d00424be:	6823      	ldr	r3, [r4, #0]
d00424c0:	0699      	lsls	r1, r3, #26
d00424c2:	bf42      	ittt	mi
d00424c4:	6833      	ldrmi	r3, [r6, #0]
d00424c6:	3302      	addmi	r3, #2
d00424c8:	6033      	strmi	r3, [r6, #0]
d00424ca:	6825      	ldr	r5, [r4, #0]
d00424cc:	f015 0506 	ands.w	r5, r5, #6
d00424d0:	d106      	bne.n	d00424e0 <_printf_common+0x48>
d00424d2:	f104 0a19 	add.w	sl, r4, #25
d00424d6:	68e3      	ldr	r3, [r4, #12]
d00424d8:	6832      	ldr	r2, [r6, #0]
d00424da:	1a9b      	subs	r3, r3, r2
d00424dc:	42ab      	cmp	r3, r5
d00424de:	dc26      	bgt.n	d004252e <_printf_common+0x96>
d00424e0:	f894 2043 	ldrb.w	r2, [r4, #67]	; 0x43
d00424e4:	1e13      	subs	r3, r2, #0
d00424e6:	6822      	ldr	r2, [r4, #0]
d00424e8:	bf18      	it	ne
d00424ea:	2301      	movne	r3, #1
d00424ec:	0692      	lsls	r2, r2, #26
d00424ee:	d42b      	bmi.n	d0042548 <_printf_common+0xb0>
d00424f0:	f104 0243 	add.w	r2, r4, #67	; 0x43
d00424f4:	4649      	mov	r1, r9
d00424f6:	4638      	mov	r0, r7
d00424f8:	47c0      	blx	r8
d00424fa:	3001      	adds	r0, #1
d00424fc:	d01e      	beq.n	d004253c <_printf_common+0xa4>
d00424fe:	6823      	ldr	r3, [r4, #0]
d0042500:	68e5      	ldr	r5, [r4, #12]
d0042502:	6832      	ldr	r2, [r6, #0]
d0042504:	f003 0306 	and.w	r3, r3, #6
d0042508:	2b04      	cmp	r3, #4
d004250a:	bf08      	it	eq
d004250c:	1aad      	subeq	r5, r5, r2
d004250e:	68a3      	ldr	r3, [r4, #8]
d0042510:	6922      	ldr	r2, [r4, #16]
d0042512:	bf0c      	ite	eq
d0042514:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
d0042518:	2500      	movne	r5, #0
d004251a:	4293      	cmp	r3, r2
d004251c:	bfc4      	itt	gt
d004251e:	1a9b      	subgt	r3, r3, r2
d0042520:	18ed      	addgt	r5, r5, r3
d0042522:	2600      	movs	r6, #0
d0042524:	341a      	adds	r4, #26
d0042526:	42b5      	cmp	r5, r6
d0042528:	d11a      	bne.n	d0042560 <_printf_common+0xc8>
d004252a:	2000      	movs	r0, #0
d004252c:	e008      	b.n	d0042540 <_printf_common+0xa8>
d004252e:	2301      	movs	r3, #1
d0042530:	4652      	mov	r2, sl
d0042532:	4649      	mov	r1, r9
d0042534:	4638      	mov	r0, r7
d0042536:	47c0      	blx	r8
d0042538:	3001      	adds	r0, #1
d004253a:	d103      	bne.n	d0042544 <_printf_common+0xac>
d004253c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0042540:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d0042544:	3501      	adds	r5, #1
d0042546:	e7c6      	b.n	d00424d6 <_printf_common+0x3e>
d0042548:	18e1      	adds	r1, r4, r3
d004254a:	1c5a      	adds	r2, r3, #1
d004254c:	2030      	movs	r0, #48	; 0x30
d004254e:	f881 0043 	strb.w	r0, [r1, #67]	; 0x43
d0042552:	4422      	add	r2, r4
d0042554:	f894 1045 	ldrb.w	r1, [r4, #69]	; 0x45
d0042558:	f882 1043 	strb.w	r1, [r2, #67]	; 0x43
d004255c:	3302      	adds	r3, #2
d004255e:	e7c7      	b.n	d00424f0 <_printf_common+0x58>
d0042560:	2301      	movs	r3, #1
d0042562:	4622      	mov	r2, r4
d0042564:	4649      	mov	r1, r9
d0042566:	4638      	mov	r0, r7
d0042568:	47c0      	blx	r8
d004256a:	3001      	adds	r0, #1
d004256c:	d0e6      	beq.n	d004253c <_printf_common+0xa4>
d004256e:	3601      	adds	r6, #1
d0042570:	e7d9      	b.n	d0042526 <_printf_common+0x8e>
	...

d0042574 <_printf_i>:
d0042574:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
d0042578:	460c      	mov	r4, r1
d004257a:	4691      	mov	r9, r2
d004257c:	7e27      	ldrb	r7, [r4, #24]
d004257e:	990c      	ldr	r1, [sp, #48]	; 0x30
d0042580:	2f78      	cmp	r7, #120	; 0x78
d0042582:	4680      	mov	r8, r0
d0042584:	469a      	mov	sl, r3
d0042586:	f104 0243 	add.w	r2, r4, #67	; 0x43
d004258a:	d807      	bhi.n	d004259c <_printf_i+0x28>
d004258c:	2f62      	cmp	r7, #98	; 0x62
d004258e:	d80a      	bhi.n	d00425a6 <_printf_i+0x32>
d0042590:	2f00      	cmp	r7, #0
d0042592:	f000 80d8 	beq.w	d0042746 <_printf_i+0x1d2>
d0042596:	2f58      	cmp	r7, #88	; 0x58
d0042598:	f000 80a3 	beq.w	d00426e2 <_printf_i+0x16e>
d004259c:	f104 0642 	add.w	r6, r4, #66	; 0x42
d00425a0:	f884 7042 	strb.w	r7, [r4, #66]	; 0x42
d00425a4:	e03a      	b.n	d004261c <_printf_i+0xa8>
d00425a6:	f1a7 0363 	sub.w	r3, r7, #99	; 0x63
d00425aa:	2b15      	cmp	r3, #21
d00425ac:	d8f6      	bhi.n	d004259c <_printf_i+0x28>
d00425ae:	a001      	add	r0, pc, #4	; (adr r0, d00425b4 <_printf_i+0x40>)
d00425b0:	f850 f023 	ldr.w	pc, [r0, r3, lsl #2]
d00425b4:	d004260d 	.word	0xd004260d
d00425b8:	d0042621 	.word	0xd0042621
d00425bc:	d004259d 	.word	0xd004259d
d00425c0:	d004259d 	.word	0xd004259d
d00425c4:	d004259d 	.word	0xd004259d
d00425c8:	d004259d 	.word	0xd004259d
d00425cc:	d0042621 	.word	0xd0042621
d00425d0:	d004259d 	.word	0xd004259d
d00425d4:	d004259d 	.word	0xd004259d
d00425d8:	d004259d 	.word	0xd004259d
d00425dc:	d004259d 	.word	0xd004259d
d00425e0:	d004272d 	.word	0xd004272d
d00425e4:	d0042651 	.word	0xd0042651
d00425e8:	d004270f 	.word	0xd004270f
d00425ec:	d004259d 	.word	0xd004259d
d00425f0:	d004259d 	.word	0xd004259d
d00425f4:	d004274f 	.word	0xd004274f
d00425f8:	d004259d 	.word	0xd004259d
d00425fc:	d0042651 	.word	0xd0042651
d0042600:	d004259d 	.word	0xd004259d
d0042604:	d004259d 	.word	0xd004259d
d0042608:	d0042717 	.word	0xd0042717
d004260c:	680b      	ldr	r3, [r1, #0]
d004260e:	1d1a      	adds	r2, r3, #4
d0042610:	681b      	ldr	r3, [r3, #0]
d0042612:	600a      	str	r2, [r1, #0]
d0042614:	f104 0642 	add.w	r6, r4, #66	; 0x42
d0042618:	f884 3042 	strb.w	r3, [r4, #66]	; 0x42
d004261c:	2301      	movs	r3, #1
d004261e:	e0a3      	b.n	d0042768 <_printf_i+0x1f4>
d0042620:	6825      	ldr	r5, [r4, #0]
d0042622:	6808      	ldr	r0, [r1, #0]
d0042624:	062e      	lsls	r6, r5, #24
d0042626:	f100 0304 	add.w	r3, r0, #4
d004262a:	d50a      	bpl.n	d0042642 <_printf_i+0xce>
d004262c:	6805      	ldr	r5, [r0, #0]
d004262e:	600b      	str	r3, [r1, #0]
d0042630:	2d00      	cmp	r5, #0
d0042632:	da03      	bge.n	d004263c <_printf_i+0xc8>
d0042634:	232d      	movs	r3, #45	; 0x2d
d0042636:	426d      	negs	r5, r5
d0042638:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d004263c:	485e      	ldr	r0, [pc, #376]	; (d00427b8 <_printf_i+0x244>)
d004263e:	230a      	movs	r3, #10
d0042640:	e019      	b.n	d0042676 <_printf_i+0x102>
d0042642:	f015 0f40 	tst.w	r5, #64	; 0x40
d0042646:	6805      	ldr	r5, [r0, #0]
d0042648:	600b      	str	r3, [r1, #0]
d004264a:	bf18      	it	ne
d004264c:	b22d      	sxthne	r5, r5
d004264e:	e7ef      	b.n	d0042630 <_printf_i+0xbc>
d0042650:	680b      	ldr	r3, [r1, #0]
d0042652:	6825      	ldr	r5, [r4, #0]
d0042654:	1d18      	adds	r0, r3, #4
d0042656:	6008      	str	r0, [r1, #0]
d0042658:	0628      	lsls	r0, r5, #24
d004265a:	d501      	bpl.n	d0042660 <_printf_i+0xec>
d004265c:	681d      	ldr	r5, [r3, #0]
d004265e:	e002      	b.n	d0042666 <_printf_i+0xf2>
d0042660:	0669      	lsls	r1, r5, #25
d0042662:	d5fb      	bpl.n	d004265c <_printf_i+0xe8>
d0042664:	881d      	ldrh	r5, [r3, #0]
d0042666:	4854      	ldr	r0, [pc, #336]	; (d00427b8 <_printf_i+0x244>)
d0042668:	2f6f      	cmp	r7, #111	; 0x6f
d004266a:	bf0c      	ite	eq
d004266c:	2308      	moveq	r3, #8
d004266e:	230a      	movne	r3, #10
d0042670:	2100      	movs	r1, #0
d0042672:	f884 1043 	strb.w	r1, [r4, #67]	; 0x43
d0042676:	6866      	ldr	r6, [r4, #4]
d0042678:	60a6      	str	r6, [r4, #8]
d004267a:	2e00      	cmp	r6, #0
d004267c:	bfa2      	ittt	ge
d004267e:	6821      	ldrge	r1, [r4, #0]
d0042680:	f021 0104 	bicge.w	r1, r1, #4
d0042684:	6021      	strge	r1, [r4, #0]
d0042686:	b90d      	cbnz	r5, d004268c <_printf_i+0x118>
d0042688:	2e00      	cmp	r6, #0
d004268a:	d04d      	beq.n	d0042728 <_printf_i+0x1b4>
d004268c:	4616      	mov	r6, r2
d004268e:	fbb5 f1f3 	udiv	r1, r5, r3
d0042692:	fb03 5711 	mls	r7, r3, r1, r5
d0042696:	5dc7      	ldrb	r7, [r0, r7]
d0042698:	f806 7d01 	strb.w	r7, [r6, #-1]!
d004269c:	462f      	mov	r7, r5
d004269e:	42bb      	cmp	r3, r7
d00426a0:	460d      	mov	r5, r1
d00426a2:	d9f4      	bls.n	d004268e <_printf_i+0x11a>
d00426a4:	2b08      	cmp	r3, #8
d00426a6:	d10b      	bne.n	d00426c0 <_printf_i+0x14c>
d00426a8:	6823      	ldr	r3, [r4, #0]
d00426aa:	07df      	lsls	r7, r3, #31
d00426ac:	d508      	bpl.n	d00426c0 <_printf_i+0x14c>
d00426ae:	6923      	ldr	r3, [r4, #16]
d00426b0:	6861      	ldr	r1, [r4, #4]
d00426b2:	4299      	cmp	r1, r3
d00426b4:	bfde      	ittt	le
d00426b6:	2330      	movle	r3, #48	; 0x30
d00426b8:	f806 3c01 	strble.w	r3, [r6, #-1]
d00426bc:	f106 36ff 	addle.w	r6, r6, #4294967295	; 0xffffffff
d00426c0:	1b92      	subs	r2, r2, r6
d00426c2:	6122      	str	r2, [r4, #16]
d00426c4:	f8cd a000 	str.w	sl, [sp]
d00426c8:	464b      	mov	r3, r9
d00426ca:	aa03      	add	r2, sp, #12
d00426cc:	4621      	mov	r1, r4
d00426ce:	4640      	mov	r0, r8
d00426d0:	f7ff fee2 	bl	d0042498 <_printf_common>
d00426d4:	3001      	adds	r0, #1
d00426d6:	d14c      	bne.n	d0042772 <_printf_i+0x1fe>
d00426d8:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00426dc:	b004      	add	sp, #16
d00426de:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d00426e2:	4835      	ldr	r0, [pc, #212]	; (d00427b8 <_printf_i+0x244>)
d00426e4:	f884 7045 	strb.w	r7, [r4, #69]	; 0x45
d00426e8:	6823      	ldr	r3, [r4, #0]
d00426ea:	680e      	ldr	r6, [r1, #0]
d00426ec:	061f      	lsls	r7, r3, #24
d00426ee:	f856 5b04 	ldr.w	r5, [r6], #4
d00426f2:	600e      	str	r6, [r1, #0]
d00426f4:	d514      	bpl.n	d0042720 <_printf_i+0x1ac>
d00426f6:	07d9      	lsls	r1, r3, #31
d00426f8:	bf44      	itt	mi
d00426fa:	f043 0320 	orrmi.w	r3, r3, #32
d00426fe:	6023      	strmi	r3, [r4, #0]
d0042700:	b91d      	cbnz	r5, d004270a <_printf_i+0x196>
d0042702:	6823      	ldr	r3, [r4, #0]
d0042704:	f023 0320 	bic.w	r3, r3, #32
d0042708:	6023      	str	r3, [r4, #0]
d004270a:	2310      	movs	r3, #16
d004270c:	e7b0      	b.n	d0042670 <_printf_i+0xfc>
d004270e:	6823      	ldr	r3, [r4, #0]
d0042710:	f043 0320 	orr.w	r3, r3, #32
d0042714:	6023      	str	r3, [r4, #0]
d0042716:	2378      	movs	r3, #120	; 0x78
d0042718:	4828      	ldr	r0, [pc, #160]	; (d00427bc <_printf_i+0x248>)
d004271a:	f884 3045 	strb.w	r3, [r4, #69]	; 0x45
d004271e:	e7e3      	b.n	d00426e8 <_printf_i+0x174>
d0042720:	065e      	lsls	r6, r3, #25
d0042722:	bf48      	it	mi
d0042724:	b2ad      	uxthmi	r5, r5
d0042726:	e7e6      	b.n	d00426f6 <_printf_i+0x182>
d0042728:	4616      	mov	r6, r2
d004272a:	e7bb      	b.n	d00426a4 <_printf_i+0x130>
d004272c:	680b      	ldr	r3, [r1, #0]
d004272e:	6826      	ldr	r6, [r4, #0]
d0042730:	6960      	ldr	r0, [r4, #20]
d0042732:	1d1d      	adds	r5, r3, #4
d0042734:	600d      	str	r5, [r1, #0]
d0042736:	0635      	lsls	r5, r6, #24
d0042738:	681b      	ldr	r3, [r3, #0]
d004273a:	d501      	bpl.n	d0042740 <_printf_i+0x1cc>
d004273c:	6018      	str	r0, [r3, #0]
d004273e:	e002      	b.n	d0042746 <_printf_i+0x1d2>
d0042740:	0671      	lsls	r1, r6, #25
d0042742:	d5fb      	bpl.n	d004273c <_printf_i+0x1c8>
d0042744:	8018      	strh	r0, [r3, #0]
d0042746:	2300      	movs	r3, #0
d0042748:	6123      	str	r3, [r4, #16]
d004274a:	4616      	mov	r6, r2
d004274c:	e7ba      	b.n	d00426c4 <_printf_i+0x150>
d004274e:	680b      	ldr	r3, [r1, #0]
d0042750:	1d1a      	adds	r2, r3, #4
d0042752:	600a      	str	r2, [r1, #0]
d0042754:	681e      	ldr	r6, [r3, #0]
d0042756:	6862      	ldr	r2, [r4, #4]
d0042758:	2100      	movs	r1, #0
d004275a:	4630      	mov	r0, r6
d004275c:	f000 f8a8 	bl	d00428b0 <memchr>
d0042760:	b108      	cbz	r0, d0042766 <_printf_i+0x1f2>
d0042762:	1b80      	subs	r0, r0, r6
d0042764:	6060      	str	r0, [r4, #4]
d0042766:	6863      	ldr	r3, [r4, #4]
d0042768:	6123      	str	r3, [r4, #16]
d004276a:	2300      	movs	r3, #0
d004276c:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d0042770:	e7a8      	b.n	d00426c4 <_printf_i+0x150>
d0042772:	6923      	ldr	r3, [r4, #16]
d0042774:	4632      	mov	r2, r6
d0042776:	4649      	mov	r1, r9
d0042778:	4640      	mov	r0, r8
d004277a:	47d0      	blx	sl
d004277c:	3001      	adds	r0, #1
d004277e:	d0ab      	beq.n	d00426d8 <_printf_i+0x164>
d0042780:	6823      	ldr	r3, [r4, #0]
d0042782:	079b      	lsls	r3, r3, #30
d0042784:	d413      	bmi.n	d00427ae <_printf_i+0x23a>
d0042786:	68e0      	ldr	r0, [r4, #12]
d0042788:	9b03      	ldr	r3, [sp, #12]
d004278a:	4298      	cmp	r0, r3
d004278c:	bfb8      	it	lt
d004278e:	4618      	movlt	r0, r3
d0042790:	e7a4      	b.n	d00426dc <_printf_i+0x168>
d0042792:	2301      	movs	r3, #1
d0042794:	4632      	mov	r2, r6
d0042796:	4649      	mov	r1, r9
d0042798:	4640      	mov	r0, r8
d004279a:	47d0      	blx	sl
d004279c:	3001      	adds	r0, #1
d004279e:	d09b      	beq.n	d00426d8 <_printf_i+0x164>
d00427a0:	3501      	adds	r5, #1
d00427a2:	68e3      	ldr	r3, [r4, #12]
d00427a4:	9903      	ldr	r1, [sp, #12]
d00427a6:	1a5b      	subs	r3, r3, r1
d00427a8:	42ab      	cmp	r3, r5
d00427aa:	dcf2      	bgt.n	d0042792 <_printf_i+0x21e>
d00427ac:	e7eb      	b.n	d0042786 <_printf_i+0x212>
d00427ae:	2500      	movs	r5, #0
d00427b0:	f104 0619 	add.w	r6, r4, #25
d00427b4:	e7f5      	b.n	d00427a2 <_printf_i+0x22e>
d00427b6:	bf00      	nop
d00427b8:	d0042d05 	.word	0xd0042d05
d00427bc:	d0042d16 	.word	0xd0042d16

d00427c0 <__sread>:
d00427c0:	b510      	push	{r4, lr}
d00427c2:	460c      	mov	r4, r1
d00427c4:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00427c8:	f000 f910 	bl	d00429ec <_read_r>
d00427cc:	2800      	cmp	r0, #0
d00427ce:	bfab      	itete	ge
d00427d0:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d00427d2:	89a3      	ldrhlt	r3, [r4, #12]
d00427d4:	181b      	addge	r3, r3, r0
d00427d6:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d00427da:	bfac      	ite	ge
d00427dc:	6563      	strge	r3, [r4, #84]	; 0x54
d00427de:	81a3      	strhlt	r3, [r4, #12]
d00427e0:	bd10      	pop	{r4, pc}

d00427e2 <__swrite>:
d00427e2:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d00427e6:	461f      	mov	r7, r3
d00427e8:	898b      	ldrh	r3, [r1, #12]
d00427ea:	05db      	lsls	r3, r3, #23
d00427ec:	4605      	mov	r5, r0
d00427ee:	460c      	mov	r4, r1
d00427f0:	4616      	mov	r6, r2
d00427f2:	d505      	bpl.n	d0042800 <__swrite+0x1e>
d00427f4:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00427f8:	2302      	movs	r3, #2
d00427fa:	2200      	movs	r2, #0
d00427fc:	f000 f846 	bl	d004288c <_lseek_r>
d0042800:	89a3      	ldrh	r3, [r4, #12]
d0042802:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d0042806:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d004280a:	81a3      	strh	r3, [r4, #12]
d004280c:	4632      	mov	r2, r6
d004280e:	463b      	mov	r3, r7
d0042810:	4628      	mov	r0, r5
d0042812:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d0042816:	f7fd bc79 	b.w	d004010c <_write_r>

d004281a <__sseek>:
d004281a:	b510      	push	{r4, lr}
d004281c:	460c      	mov	r4, r1
d004281e:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0042822:	f000 f833 	bl	d004288c <_lseek_r>
d0042826:	1c43      	adds	r3, r0, #1
d0042828:	89a3      	ldrh	r3, [r4, #12]
d004282a:	bf15      	itete	ne
d004282c:	6560      	strne	r0, [r4, #84]	; 0x54
d004282e:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d0042832:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d0042836:	81a3      	strheq	r3, [r4, #12]
d0042838:	bf18      	it	ne
d004283a:	81a3      	strhne	r3, [r4, #12]
d004283c:	bd10      	pop	{r4, pc}

d004283e <__sclose>:
d004283e:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0042842:	f000 b801 	b.w	d0042848 <_close_r>
	...

d0042848 <_close_r>:
d0042848:	b538      	push	{r3, r4, r5, lr}
d004284a:	4d06      	ldr	r5, [pc, #24]	; (d0042864 <_close_r+0x1c>)
d004284c:	2300      	movs	r3, #0
d004284e:	4604      	mov	r4, r0
d0042850:	4608      	mov	r0, r1
d0042852:	602b      	str	r3, [r5, #0]
d0042854:	f7fd fc94 	bl	d0040180 <_close>
d0042858:	1c43      	adds	r3, r0, #1
d004285a:	d102      	bne.n	d0042862 <_close_r+0x1a>
d004285c:	682b      	ldr	r3, [r5, #0]
d004285e:	b103      	cbz	r3, d0042862 <_close_r+0x1a>
d0042860:	6023      	str	r3, [r4, #0]
d0042862:	bd38      	pop	{r3, r4, r5, pc}
d0042864:	d0044450 	.word	0xd0044450

d0042868 <_fstat_r>:
d0042868:	b538      	push	{r3, r4, r5, lr}
d004286a:	4d07      	ldr	r5, [pc, #28]	; (d0042888 <_fstat_r+0x20>)
d004286c:	2300      	movs	r3, #0
d004286e:	4604      	mov	r4, r0
d0042870:	4608      	mov	r0, r1
d0042872:	4611      	mov	r1, r2
d0042874:	602b      	str	r3, [r5, #0]
d0042876:	f7fd fc87 	bl	d0040188 <_fstat>
d004287a:	1c43      	adds	r3, r0, #1
d004287c:	d102      	bne.n	d0042884 <_fstat_r+0x1c>
d004287e:	682b      	ldr	r3, [r5, #0]
d0042880:	b103      	cbz	r3, d0042884 <_fstat_r+0x1c>
d0042882:	6023      	str	r3, [r4, #0]
d0042884:	bd38      	pop	{r3, r4, r5, pc}
d0042886:	bf00      	nop
d0042888:	d0044450 	.word	0xd0044450

d004288c <_lseek_r>:
d004288c:	b538      	push	{r3, r4, r5, lr}
d004288e:	4d07      	ldr	r5, [pc, #28]	; (d00428ac <_lseek_r+0x20>)
d0042890:	4604      	mov	r4, r0
d0042892:	4608      	mov	r0, r1
d0042894:	4611      	mov	r1, r2
d0042896:	2200      	movs	r2, #0
d0042898:	602a      	str	r2, [r5, #0]
d004289a:	461a      	mov	r2, r3
d004289c:	f7fd fc7a 	bl	d0040194 <_lseek>
d00428a0:	1c43      	adds	r3, r0, #1
d00428a2:	d102      	bne.n	d00428aa <_lseek_r+0x1e>
d00428a4:	682b      	ldr	r3, [r5, #0]
d00428a6:	b103      	cbz	r3, d00428aa <_lseek_r+0x1e>
d00428a8:	6023      	str	r3, [r4, #0]
d00428aa:	bd38      	pop	{r3, r4, r5, pc}
d00428ac:	d0044450 	.word	0xd0044450

d00428b0 <memchr>:
d00428b0:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d00428b4:	2a10      	cmp	r2, #16
d00428b6:	db2b      	blt.n	d0042910 <memchr+0x60>
d00428b8:	f010 0f07 	tst.w	r0, #7
d00428bc:	d008      	beq.n	d00428d0 <memchr+0x20>
d00428be:	f810 3b01 	ldrb.w	r3, [r0], #1
d00428c2:	3a01      	subs	r2, #1
d00428c4:	428b      	cmp	r3, r1
d00428c6:	d02d      	beq.n	d0042924 <memchr+0x74>
d00428c8:	f010 0f07 	tst.w	r0, #7
d00428cc:	b342      	cbz	r2, d0042920 <memchr+0x70>
d00428ce:	d1f6      	bne.n	d00428be <memchr+0xe>
d00428d0:	b4f0      	push	{r4, r5, r6, r7}
d00428d2:	ea41 2101 	orr.w	r1, r1, r1, lsl #8
d00428d6:	ea41 4101 	orr.w	r1, r1, r1, lsl #16
d00428da:	f022 0407 	bic.w	r4, r2, #7
d00428de:	f07f 0700 	mvns.w	r7, #0
d00428e2:	2300      	movs	r3, #0
d00428e4:	e8f0 5602 	ldrd	r5, r6, [r0], #8
d00428e8:	3c08      	subs	r4, #8
d00428ea:	ea85 0501 	eor.w	r5, r5, r1
d00428ee:	ea86 0601 	eor.w	r6, r6, r1
d00428f2:	fa85 f547 	uadd8	r5, r5, r7
d00428f6:	faa3 f587 	sel	r5, r3, r7
d00428fa:	fa86 f647 	uadd8	r6, r6, r7
d00428fe:	faa5 f687 	sel	r6, r5, r7
d0042902:	b98e      	cbnz	r6, d0042928 <memchr+0x78>
d0042904:	d1ee      	bne.n	d00428e4 <memchr+0x34>
d0042906:	bcf0      	pop	{r4, r5, r6, r7}
d0042908:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d004290c:	f002 0207 	and.w	r2, r2, #7
d0042910:	b132      	cbz	r2, d0042920 <memchr+0x70>
d0042912:	f810 3b01 	ldrb.w	r3, [r0], #1
d0042916:	3a01      	subs	r2, #1
d0042918:	ea83 0301 	eor.w	r3, r3, r1
d004291c:	b113      	cbz	r3, d0042924 <memchr+0x74>
d004291e:	d1f8      	bne.n	d0042912 <memchr+0x62>
d0042920:	2000      	movs	r0, #0
d0042922:	4770      	bx	lr
d0042924:	3801      	subs	r0, #1
d0042926:	4770      	bx	lr
d0042928:	2d00      	cmp	r5, #0
d004292a:	bf06      	itte	eq
d004292c:	4635      	moveq	r5, r6
d004292e:	3803      	subeq	r0, #3
d0042930:	3807      	subne	r0, #7
d0042932:	f015 0f01 	tst.w	r5, #1
d0042936:	d107      	bne.n	d0042948 <memchr+0x98>
d0042938:	3001      	adds	r0, #1
d004293a:	f415 7f80 	tst.w	r5, #256	; 0x100
d004293e:	bf02      	ittt	eq
d0042940:	3001      	addeq	r0, #1
d0042942:	f415 3fc0 	tsteq.w	r5, #98304	; 0x18000
d0042946:	3001      	addeq	r0, #1
d0042948:	bcf0      	pop	{r4, r5, r6, r7}
d004294a:	3801      	subs	r0, #1
d004294c:	4770      	bx	lr
d004294e:	bf00      	nop

d0042950 <memcpy>:
d0042950:	440a      	add	r2, r1
d0042952:	4291      	cmp	r1, r2
d0042954:	f100 33ff 	add.w	r3, r0, #4294967295	; 0xffffffff
d0042958:	d100      	bne.n	d004295c <memcpy+0xc>
d004295a:	4770      	bx	lr
d004295c:	b510      	push	{r4, lr}
d004295e:	f811 4b01 	ldrb.w	r4, [r1], #1
d0042962:	f803 4f01 	strb.w	r4, [r3, #1]!
d0042966:	4291      	cmp	r1, r2
d0042968:	d1f9      	bne.n	d004295e <memcpy+0xe>
d004296a:	bd10      	pop	{r4, pc}

d004296c <memmove>:
d004296c:	4288      	cmp	r0, r1
d004296e:	b510      	push	{r4, lr}
d0042970:	eb01 0402 	add.w	r4, r1, r2
d0042974:	d902      	bls.n	d004297c <memmove+0x10>
d0042976:	4284      	cmp	r4, r0
d0042978:	4623      	mov	r3, r4
d004297a:	d807      	bhi.n	d004298c <memmove+0x20>
d004297c:	1e43      	subs	r3, r0, #1
d004297e:	42a1      	cmp	r1, r4
d0042980:	d008      	beq.n	d0042994 <memmove+0x28>
d0042982:	f811 2b01 	ldrb.w	r2, [r1], #1
d0042986:	f803 2f01 	strb.w	r2, [r3, #1]!
d004298a:	e7f8      	b.n	d004297e <memmove+0x12>
d004298c:	4402      	add	r2, r0
d004298e:	4601      	mov	r1, r0
d0042990:	428a      	cmp	r2, r1
d0042992:	d100      	bne.n	d0042996 <memmove+0x2a>
d0042994:	bd10      	pop	{r4, pc}
d0042996:	f813 4d01 	ldrb.w	r4, [r3, #-1]!
d004299a:	f802 4d01 	strb.w	r4, [r2, #-1]!
d004299e:	e7f7      	b.n	d0042990 <memmove+0x24>

d00429a0 <_realloc_r>:
d00429a0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00429a2:	4607      	mov	r7, r0
d00429a4:	4614      	mov	r4, r2
d00429a6:	460e      	mov	r6, r1
d00429a8:	b921      	cbnz	r1, d00429b4 <_realloc_r+0x14>
d00429aa:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
d00429ae:	4611      	mov	r1, r2
d00429b0:	f7ff b8e4 	b.w	d0041b7c <_malloc_r>
d00429b4:	b922      	cbnz	r2, d00429c0 <_realloc_r+0x20>
d00429b6:	f7ff f891 	bl	d0041adc <_free_r>
d00429ba:	4625      	mov	r5, r4
d00429bc:	4628      	mov	r0, r5
d00429be:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00429c0:	f000 f826 	bl	d0042a10 <_malloc_usable_size_r>
d00429c4:	42a0      	cmp	r0, r4
d00429c6:	d20f      	bcs.n	d00429e8 <_realloc_r+0x48>
d00429c8:	4621      	mov	r1, r4
d00429ca:	4638      	mov	r0, r7
d00429cc:	f7ff f8d6 	bl	d0041b7c <_malloc_r>
d00429d0:	4605      	mov	r5, r0
d00429d2:	2800      	cmp	r0, #0
d00429d4:	d0f2      	beq.n	d00429bc <_realloc_r+0x1c>
d00429d6:	4631      	mov	r1, r6
d00429d8:	4622      	mov	r2, r4
d00429da:	f7ff ffb9 	bl	d0042950 <memcpy>
d00429de:	4631      	mov	r1, r6
d00429e0:	4638      	mov	r0, r7
d00429e2:	f7ff f87b 	bl	d0041adc <_free_r>
d00429e6:	e7e9      	b.n	d00429bc <_realloc_r+0x1c>
d00429e8:	4635      	mov	r5, r6
d00429ea:	e7e7      	b.n	d00429bc <_realloc_r+0x1c>

d00429ec <_read_r>:
d00429ec:	b538      	push	{r3, r4, r5, lr}
d00429ee:	4d07      	ldr	r5, [pc, #28]	; (d0042a0c <_read_r+0x20>)
d00429f0:	4604      	mov	r4, r0
d00429f2:	4608      	mov	r0, r1
d00429f4:	4611      	mov	r1, r2
d00429f6:	2200      	movs	r2, #0
d00429f8:	602a      	str	r2, [r5, #0]
d00429fa:	461a      	mov	r2, r3
d00429fc:	f7fd fbb6 	bl	d004016c <_read>
d0042a00:	1c43      	adds	r3, r0, #1
d0042a02:	d102      	bne.n	d0042a0a <_read_r+0x1e>
d0042a04:	682b      	ldr	r3, [r5, #0]
d0042a06:	b103      	cbz	r3, d0042a0a <_read_r+0x1e>
d0042a08:	6023      	str	r3, [r4, #0]
d0042a0a:	bd38      	pop	{r3, r4, r5, pc}
d0042a0c:	d0044450 	.word	0xd0044450

d0042a10 <_malloc_usable_size_r>:
d0042a10:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0042a14:	1f18      	subs	r0, r3, #4
d0042a16:	2b00      	cmp	r3, #0
d0042a18:	bfbc      	itt	lt
d0042a1a:	580b      	ldrlt	r3, [r1, r0]
d0042a1c:	18c0      	addlt	r0, r0, r3
d0042a1e:	4770      	bx	lr

d0042a20 <_global_impure_ptr>:
d0042a20:	2d44 d004 4952 4646 0000 0000 4157 4556     D-..RIFF....WAVE
d0042a30:	0000 0000 6572 2f73 7865 7274 6c61 6669     ....res/extralif
d0042a40:	2e65 6177 0076 0000 6572 2f73 6966 6572     e.wav...res/fire
d0042a50:	2e6d 6177 0076 0000 6572 2f73 6874 7572     m.wav...res/thru
d0042a60:	7473 2e32 6177 0076 6572 2f73 6473 656c     st2.wav.res/sdle
d0042a70:	3176 6d2e 646f 0000 6572 2f73 7361 7274     v1.mod..res/astr
d0042a80:	696f 5f64 616c 6772 5f65 2e31 7070 0062     oid_large_1.ppb.
d0042a90:	6572 2f73 7361 7274 696f 5f64 656d 6964     res/astroid_medi
d0042aa0:	6d75 315f 702e 6270 0000 0000 6572 2f73     um_1.ppb....res/
d0042ab0:	7361 7274 696f 5f64 656d 6964 6d75 325f     astroid_medium_2
d0042ac0:	702e 6270 0000 0000 6572 2f73 7361 7274     .ppb....res/astr
d0042ad0:	696f 5f64 6d73 6c61 5f6c 2e32 7070 0062     oid_small_2.ppb.
d0042ae0:	6572 2f73 6873 7069 7372 702e 6270 0000     res/shiprs.ppb..
d0042af0:	6572 2f73 7562 6c6c 7465 5f73 7974 6570     res/bullets_type
d0042b00:	2e31 7070 0062 0000 6572 2f73 6c66 6d61     1.ppb...res/flam
d0042b10:	7365 702e 6270 0000 6572 2f73 7865 6c70     es.ppb..res/expl
d0042b20:	646f 2e65 7070 0062 6572 2f73 6f66 746e     ode.ppb.res/font
d0042b30:	3631 3631 702e 6270 0000 0000 6572 2f73     1616.ppb....res/
d0042b40:	6162 6b63 702e 6270 0000 0000 4353 524f     back.ppb....SCOR
d0042b50:	3a45 2520 3630 756c 0000 0000 494c 4556     E: %06lu....LIVE
d0042b60:	3a53 2520 756c 0000 4157 4556 3a53 2520     S: %lu..WAVES: %
d0042b70:	756c 0000                                   lu..

d0042b74 <dirTable>:
d0042b74:	0000 0000 0000 3f80 c433 3e31 1bda 3f7c     .......?3.1>..|?
d0042b84:	1aa0 3eaf 902e 3f70 0000 3f00 b22d 3f5d     ...>..p?...?-.]?
d0042b94:	8e8a 3f24 1893 3f44 1893 3f44 8e8a 3f24     ..$?..D?..D?..$?
d0042ba4:	b22d 3f5d 0000 3f00 902e 3f70 1aa0 3eaf     -.]?...?..p?...>
d0042bb4:	1bda 3f7c c433 3e31 0000 3f80 0000 0000     ..|?3.1>...?....
d0042bc4:	1bda 3f7c c433 be31 902e 3f70 1aa0 beaf     ..|?3.1...p?....
d0042bd4:	b22d 3f5d 0000 bf00 1893 3f44 8e8a bf24     -.]?......D?..$.
d0042be4:	8e8a 3f24 1893 bf44 0000 3f00 b22d bf5d     ..$?..D....?-.].
d0042bf4:	1aa0 3eaf 902e bf70 c433 3e31 1bda bf7c     ...>..p.3.1>..|.
d0042c04:	0000 0000 0000 bf80 c433 be31 1bda bf7c     ........3.1...|.
d0042c14:	1aa0 beaf 902e bf70 0000 bf00 b22d bf5d     ......p.....-.].
d0042c24:	8e8a bf24 1893 bf44 1893 bf44 8e8a bf24     ..$...D...D...$.
d0042c34:	b22d bf5d 0000 bf00 902e bf70 1aa0 beaf     -.].......p.....
d0042c44:	1bda bf7c c433 be31 0000 bf80 0000 0000     ..|.3.1.........
d0042c54:	1bda bf7c c433 3e31 902e bf70 1aa0 3eaf     ..|.3.1>..p....>
d0042c64:	b22d bf5d 0000 3f00 1893 bf44 8e8a 3f24     -.]....?..D...$?
d0042c74:	8e8a bf24 1893 3f44 0000 bf00 b22d 3f5d     ..$...D?....-.]?
d0042c84:	1aa0 beaf 902e 3f70 c433 be31 1bda 3f7c     ......p?3.1...|?

d0042c94 <__sf_fake_stderr>:
	...

d0042cb4 <__sf_fake_stdin>:
	...

d0042cd4 <__sf_fake_stdout>:
	...
d0042cf4:	2d23 2b30 0020 6c68 004c 6665 4567 4746     #-0+ .hlL.efgEFG
d0042d04:	3000 3231 3433 3635 3837 4139 4342 4544     .0123456789ABCDE
d0042d14:	0046 3130 3332 3534 3736 3938 6261 6463     F.0123456789abcd
d0042d24:	6665                                         ef.

Disassembly of section .init:

d0042d28 <_init>:
d0042d28:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0042d2a:	bf00      	nop

Disassembly of section .fini:

d0042d2c <_fini>:
d0042d2c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0042d2e:	bf00      	nop
