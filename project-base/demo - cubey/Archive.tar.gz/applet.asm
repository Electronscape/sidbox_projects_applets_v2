
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0080010 <applet_entry>:
d0080010:	b570      	push	{r4, r5, r6, lr}
d0080012:	4e09      	ldr	r6, [pc, #36]	; (d0080038 <applet_entry+0x28>)
d0080014:	460d      	mov	r5, r1
d0080016:	4604      	mov	r4, r0
d0080018:	2100      	movs	r1, #0
d008001a:	6833      	ldr	r3, [r6, #0]
d008001c:	6898      	ldr	r0, [r3, #8]
d008001e:	f001 fe1d 	bl	d0081c5c <setbuf>
d0080022:	6833      	ldr	r3, [r6, #0]
d0080024:	2100      	movs	r1, #0
d0080026:	68d8      	ldr	r0, [r3, #12]
d0080028:	f001 fe18 	bl	d0081c5c <setbuf>
d008002c:	4629      	mov	r1, r5
d008002e:	4620      	mov	r0, r4
d0080030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0080034:	f000 bcc8 	b.w	d00809c8 <main>
d0080038:	d008775c 	.word	0xd008775c

d008003c <gfx_createBitmap>:
d008003c:	b510      	push	{r4, lr}
d008003e:	4604      	mov	r4, r0
d0080040:	fb01 f002 	mul.w	r0, r1, r2
d0080044:	b292      	uxth	r2, r2
d0080046:	80a1      	strh	r1, [r4, #4]
d0080048:	60e0      	str	r0, [r4, #12]
d008004a:	80e2      	strh	r2, [r4, #6]
d008004c:	8122      	strh	r2, [r4, #8]
d008004e:	f001 fd33 	bl	d0081ab8 <malloc>
d0080052:	6020      	str	r0, [r4, #0]
d0080054:	bd10      	pop	{r4, pc}
d0080056:	bf00      	nop

d0080058 <initMalloc>:
d0080058:	4902      	ldr	r1, [pc, #8]	; (d0080064 <initMalloc+0xc>)
d008005a:	4b03      	ldr	r3, [pc, #12]	; (d0080068 <initMalloc+0x10>)
d008005c:	4a03      	ldr	r2, [pc, #12]	; (d008006c <initMalloc+0x14>)
d008005e:	1a5b      	subs	r3, r3, r1
d0080060:	6013      	str	r3, [r2, #0]
d0080062:	4770      	bx	lr
d0080064:	d008b520 	.word	0xd008b520
d0080068:	d0600000 	.word	0xd0600000
d008006c:	d0089508 	.word	0xd0089508

d0080070 <_write_r>:
d0080070:	3901      	subs	r1, #1
d0080072:	2901      	cmp	r1, #1
d0080074:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0080076:	d81f      	bhi.n	d00800b8 <_write_r+0x48>
d0080078:	b1e2      	cbz	r2, d00800b4 <_write_r+0x44>
d008007a:	461c      	mov	r4, r3
d008007c:	b1d3      	cbz	r3, d00800b4 <_write_r+0x44>
d008007e:	4d12      	ldr	r5, [pc, #72]	; (d00800c8 <_write_r+0x58>)
d0080080:	682e      	ldr	r6, [r5, #0]
d0080082:	b9ae      	cbnz	r6, d00800b0 <_write_r+0x40>
d0080084:	4f11      	ldr	r7, [pc, #68]	; (d00800cc <_write_r+0x5c>)
d0080086:	2301      	movs	r3, #1
d0080088:	4611      	mov	r1, r2
d008008a:	4630      	mov	r0, r6
d008008c:	602b      	str	r3, [r5, #0]
d008008e:	4622      	mov	r2, r4
d0080090:	7a3b      	ldrb	r3, [r7, #8]
d0080092:	f897 c009 	ldrb.w	ip, [r7, #9]
d0080096:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d008009a:	f897 c00a 	ldrb.w	ip, [r7, #10]
d008009e:	7aff      	ldrb	r7, [r7, #11]
d00800a0:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d00800a4:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d00800a8:	681b      	ldr	r3, [r3, #0]
d00800aa:	685b      	ldr	r3, [r3, #4]
d00800ac:	4798      	blx	r3
d00800ae:	602e      	str	r6, [r5, #0]
d00800b0:	4620      	mov	r0, r4
d00800b2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800b4:	2000      	movs	r0, #0
d00800b6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800b8:	f001 fcf8 	bl	d0081aac <__errno>
d00800bc:	2209      	movs	r2, #9
d00800be:	4603      	mov	r3, r0
d00800c0:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800c4:	601a      	str	r2, [r3, #0]
d00800c6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800c8:	d00877c4 	.word	0xd00877c4
d00800cc:	2001f000 	.word	0x2001f000

d00800d0 <_read>:
d00800d0:	b508      	push	{r3, lr}
d00800d2:	f001 fceb 	bl	d0081aac <__errno>
d00800d6:	2258      	movs	r2, #88	; 0x58
d00800d8:	4603      	mov	r3, r0
d00800da:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800de:	601a      	str	r2, [r3, #0]
d00800e0:	bd08      	pop	{r3, pc}
d00800e2:	bf00      	nop

d00800e4 <_close>:
d00800e4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800e8:	4770      	bx	lr
d00800ea:	bf00      	nop

d00800ec <_fstat>:
d00800ec:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d00800f0:	2000      	movs	r0, #0
d00800f2:	604b      	str	r3, [r1, #4]
d00800f4:	4770      	bx	lr
d00800f6:	bf00      	nop

d00800f8 <_lseek>:
d00800f8:	2000      	movs	r0, #0
d00800fa:	4770      	bx	lr

d00800fc <_sbrk_r>:
d00800fc:	4b0c      	ldr	r3, [pc, #48]	; (d0080130 <_sbrk_r+0x34>)
d00800fe:	4a0d      	ldr	r2, [pc, #52]	; (d0080134 <_sbrk_r+0x38>)
d0080100:	6818      	ldr	r0, [r3, #0]
d0080102:	b510      	push	{r4, lr}
d0080104:	b918      	cbnz	r0, d008010e <_sbrk_r+0x12>
d0080106:	1dd0      	adds	r0, r2, #7
d0080108:	f020 0007 	bic.w	r0, r0, #7
d008010c:	6018      	str	r0, [r3, #0]
d008010e:	4401      	add	r1, r0
d0080110:	4c09      	ldr	r4, [pc, #36]	; (d0080138 <_sbrk_r+0x3c>)
d0080112:	42a1      	cmp	r1, r4
d0080114:	d803      	bhi.n	d008011e <_sbrk_r+0x22>
d0080116:	4291      	cmp	r1, r2
d0080118:	d301      	bcc.n	d008011e <_sbrk_r+0x22>
d008011a:	6019      	str	r1, [r3, #0]
d008011c:	bd10      	pop	{r4, pc}
d008011e:	f001 fcc5 	bl	d0081aac <__errno>
d0080122:	220c      	movs	r2, #12
d0080124:	4603      	mov	r3, r0
d0080126:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008012a:	601a      	str	r2, [r3, #0]
d008012c:	bd10      	pop	{r4, pc}
d008012e:	bf00      	nop
d0080130:	d00877c0 	.word	0xd00877c0
d0080134:	d008b520 	.word	0xd008b520
d0080138:	d0600000 	.word	0xd0600000

d008013c <_isatty>:
d008013c:	2001      	movs	r0, #1
d008013e:	4770      	bx	lr

d0080140 <draw_textf_multiline.constprop.0>:
d0080140:	2300      	movs	r3, #0
d0080142:	2220      	movs	r2, #32
d0080144:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
d0080148:	4c2a      	ldr	r4, [pc, #168]	; (d00801f4 <draw_textf_multiline.constprop.0+0xb4>)
d008014a:	b091      	sub	sp, #68	; 0x44
d008014c:	460d      	mov	r5, r1
d008014e:	461f      	mov	r7, r3
d0080150:	4e29      	ldr	r6, [pc, #164]	; (d00801f8 <draw_textf_multiline.constprop.0+0xb8>)
d0080152:	e00c      	b.n	d008016e <draw_textf_multiline.constprop.0+0x2e>
d0080154:	a910      	add	r1, sp, #64	; 0x40
d0080156:	2b2e      	cmp	r3, #46	; 0x2e
d0080158:	f103 0c01 	add.w	ip, r3, #1
d008015c:	4419      	add	r1, r3
d008015e:	d803      	bhi.n	d0080168 <draw_textf_multiline.constprop.0+0x28>
d0080160:	fa5f f38c 	uxtb.w	r3, ip
d0080164:	f801 2c30 	strb.w	r2, [r1, #-48]
d0080168:	f814 2f01 	ldrb.w	r2, [r4, #1]!
d008016c:	b33a      	cbz	r2, d00801be <draw_textf_multiline.constprop.0+0x7e>
d008016e:	2a0a      	cmp	r2, #10
d0080170:	d1f0      	bne.n	d0080154 <draw_textf_multiline.constprop.0+0x14>
d0080172:	f896 900c 	ldrb.w	r9, [r6, #12]
d0080176:	aa10      	add	r2, sp, #64	; 0x40
d0080178:	7b71      	ldrb	r1, [r6, #13]
d008017a:	f04f 0802 	mov.w	r8, #2
d008017e:	f896 e00e 	ldrb.w	lr, [r6, #14]
d0080182:	441a      	add	r2, r3
d0080184:	ea49 2101 	orr.w	r1, r9, r1, lsl #8
d0080188:	f896 c00f 	ldrb.w	ip, [r6, #15]
d008018c:	f802 7c30 	strb.w	r7, [r2, #-48]
d0080190:	2301      	movs	r3, #1
d0080192:	ea41 4e0e 	orr.w	lr, r1, lr, lsl #16
d0080196:	aa04      	add	r2, sp, #16
d0080198:	4629      	mov	r1, r5
d008019a:	9003      	str	r0, [sp, #12]
d008019c:	ea4e 6c0c 	orr.w	ip, lr, ip, lsl #24
d00801a0:	3510      	adds	r5, #16
d00801a2:	f8dc c004 	ldr.w	ip, [ip, #4]
d00801a6:	b22d      	sxth	r5, r5
d00801a8:	f8cd 8000 	str.w	r8, [sp]
d00801ac:	f8dc 8030 	ldr.w	r8, [ip, #48]	; 0x30
d00801b0:	47c0      	blx	r8
d00801b2:	f814 2f01 	ldrb.w	r2, [r4, #1]!
d00801b6:	2300      	movs	r3, #0
d00801b8:	9803      	ldr	r0, [sp, #12]
d00801ba:	2a00      	cmp	r2, #0
d00801bc:	d1d7      	bne.n	d008016e <draw_textf_multiline.constprop.0+0x2e>
d00801be:	b1b3      	cbz	r3, d00801ee <draw_textf_multiline.constprop.0+0xae>
d00801c0:	4e0d      	ldr	r6, [pc, #52]	; (d00801f8 <draw_textf_multiline.constprop.0+0xb8>)
d00801c2:	a910      	add	r1, sp, #64	; 0x40
d00801c4:	2702      	movs	r7, #2
d00801c6:	7b34      	ldrb	r4, [r6, #12]
d00801c8:	440b      	add	r3, r1
d00801ca:	4629      	mov	r1, r5
d00801cc:	7b75      	ldrb	r5, [r6, #13]
d00801ce:	f803 2c30 	strb.w	r2, [r3, #-48]
d00801d2:	ea44 2405 	orr.w	r4, r4, r5, lsl #8
d00801d6:	7bb3      	ldrb	r3, [r6, #14]
d00801d8:	7bf2      	ldrb	r2, [r6, #15]
d00801da:	ea44 4403 	orr.w	r4, r4, r3, lsl #16
d00801de:	2301      	movs	r3, #1
d00801e0:	ea44 6402 	orr.w	r4, r4, r2, lsl #24
d00801e4:	aa04      	add	r2, sp, #16
d00801e6:	6864      	ldr	r4, [r4, #4]
d00801e8:	9700      	str	r7, [sp, #0]
d00801ea:	6b24      	ldr	r4, [r4, #48]	; 0x30
d00801ec:	47a0      	blx	r4
d00801ee:	b011      	add	sp, #68	; 0x44
d00801f0:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d00801f4:	d0082c38 	.word	0xd0082c38
d00801f8:	2001f000 	.word	0x2001f000

d00801fc <draw_filled_triangle.part.0.constprop.0>:
d00801fc:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0080200:	f9b0 2000 	ldrsh.w	r2, [r0]
d0080204:	b089      	sub	sp, #36	; 0x24
d0080206:	f9b0 6004 	ldrsh.w	r6, [r0, #4]
d008020a:	f9b0 5008 	ldrsh.w	r5, [r0, #8]
d008020e:	4690      	mov	r8, r2
d0080210:	42b2      	cmp	r2, r6
d0080212:	f9b0 c002 	ldrsh.w	ip, [r0, #2]
d0080216:	f9b0 7006 	ldrsh.w	r7, [r0, #6]
d008021a:	4696      	mov	lr, r2
d008021c:	bfa8      	it	ge
d008021e:	46b0      	movge	r8, r6
d0080220:	42b2      	cmp	r2, r6
d0080222:	4b72      	ldr	r3, [pc, #456]	; (d00803ec <draw_filled_triangle.part.0.constprop.0+0x1f0>)
d0080224:	46e1      	mov	r9, ip
d0080226:	bfb8      	it	lt
d0080228:	46b6      	movlt	lr, r6
d008022a:	45a8      	cmp	r8, r5
d008022c:	889b      	ldrh	r3, [r3, #4]
d008022e:	4664      	mov	r4, ip
d0080230:	bfa8      	it	ge
d0080232:	46a8      	movge	r8, r5
d0080234:	45bc      	cmp	ip, r7
d0080236:	9107      	str	r1, [sp, #28]
d0080238:	b299      	uxth	r1, r3
d008023a:	bfa8      	it	ge
d008023c:	46b9      	movge	r9, r7
d008023e:	45bc      	cmp	ip, r7
d0080240:	f9b0 300a 	ldrsh.w	r3, [r0, #10]
d0080244:	f101 3aff 	add.w	sl, r1, #4294967295	; 0xffffffff
d0080248:	bfb8      	it	lt
d008024a:	463c      	movlt	r4, r7
d008024c:	45ae      	cmp	lr, r5
d008024e:	bfb8      	it	lt
d0080250:	46ae      	movlt	lr, r5
d0080252:	4599      	cmp	r9, r3
d0080254:	bfa8      	it	ge
d0080256:	4699      	movge	r9, r3
d0080258:	429c      	cmp	r4, r3
d008025a:	bfb8      	it	lt
d008025c:	461c      	movlt	r4, r3
d008025e:	f1b8 0f00 	cmp.w	r8, #0
d0080262:	f2c0 80bf 	blt.w	d00803e4 <draw_filled_triangle.part.0.constprop.0+0x1e8>
d0080266:	45d0      	cmp	r8, sl
d0080268:	4641      	mov	r1, r8
d008026a:	bfa8      	it	ge
d008026c:	4651      	movge	r1, sl
d008026e:	9105      	str	r1, [sp, #20]
d0080270:	f1be 0f00 	cmp.w	lr, #0
d0080274:	f2c0 80b3 	blt.w	d00803de <draw_filled_triangle.part.0.constprop.0+0x1e2>
d0080278:	45d6      	cmp	lr, sl
d008027a:	4671      	mov	r1, lr
d008027c:	bfa8      	it	ge
d008027e:	4651      	movge	r1, sl
d0080280:	9102      	str	r1, [sp, #8]
d0080282:	495a      	ldr	r1, [pc, #360]	; (d00803ec <draw_filled_triangle.part.0.constprop.0+0x1f0>)
d0080284:	f1b9 0f00 	cmp.w	r9, #0
d0080288:	88c9      	ldrh	r1, [r1, #6]
d008028a:	b289      	uxth	r1, r1
d008028c:	f101 31ff 	add.w	r1, r1, #4294967295	; 0xffffffff
d0080290:	f2c0 80a2 	blt.w	d00803d8 <draw_filled_triangle.part.0.constprop.0+0x1dc>
d0080294:	4589      	cmp	r9, r1
d0080296:	bfa8      	it	ge
d0080298:	4689      	movge	r9, r1
d008029a:	2c00      	cmp	r4, #0
d008029c:	f2c0 8099 	blt.w	d00803d2 <draw_filled_triangle.part.0.constprop.0+0x1d6>
d00802a0:	428c      	cmp	r4, r1
d00802a2:	bfa8      	it	ge
d00802a4:	460c      	movge	r4, r1
d00802a6:	9406      	str	r4, [sp, #24]
d00802a8:	9905      	ldr	r1, [sp, #20]
d00802aa:	9c02      	ldr	r4, [sp, #8]
d00802ac:	42a1      	cmp	r1, r4
d00802ae:	f300 808d 	bgt.w	d00803cc <draw_filled_triangle.part.0.constprop.0+0x1d0>
d00802b2:	9906      	ldr	r1, [sp, #24]
d00802b4:	4589      	cmp	r9, r1
d00802b6:	f300 8089 	bgt.w	d00803cc <draw_filled_triangle.part.0.constprop.0+0x1d0>
d00802ba:	eba6 0b02 	sub.w	fp, r6, r2
d00802be:	eba3 040c 	sub.w	r4, r3, ip
d00802c2:	eba7 0a0c 	sub.w	sl, r7, ip
d00802c6:	1aa9      	subs	r1, r5, r2
d00802c8:	fb04 f40b 	mul.w	r4, r4, fp
d00802cc:	fb01 411a 	mls	r1, r1, sl, r4
d00802d0:	2900      	cmp	r1, #0
d00802d2:	d07b      	beq.n	d00803cc <draw_filled_triangle.part.0.constprop.0+0x1d0>
d00802d4:	ea4f 71d1 	mov.w	r1, r1, lsr #31
d00802d8:	9104      	str	r1, [sp, #16]
d00802da:	bfcc      	ite	gt
d00802dc:	2101      	movgt	r1, #1
d00802de:	2100      	movle	r1, #0
d00802e0:	9103      	str	r1, [sp, #12]
d00802e2:	9905      	ldr	r1, [sp, #20]
d00802e4:	9300      	str	r3, [sp, #0]
d00802e6:	e02a      	b.n	d008033e <draw_filled_triangle.part.0.constprop.0+0x142>
d00802e8:	2d00      	cmp	r5, #0
d00802ea:	db13      	blt.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d00802ec:	2a00      	cmp	r2, #0
d00802ee:	db11      	blt.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d00802f0:	4c3e      	ldr	r4, [pc, #248]	; (d00803ec <draw_filled_triangle.part.0.constprop.0+0x1f0>)
d00802f2:	6822      	ldr	r2, [r4, #0]
d00802f4:	b172      	cbz	r2, d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d00802f6:	88a3      	ldrh	r3, [r4, #4]
d00802f8:	b29b      	uxth	r3, r3
d00802fa:	4299      	cmp	r1, r3
d00802fc:	d20a      	bcs.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d00802fe:	88e3      	ldrh	r3, [r4, #6]
d0080300:	b29b      	uxth	r3, r3
d0080302:	4599      	cmp	r9, r3
d0080304:	d206      	bcs.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d0080306:	8923      	ldrh	r3, [r4, #8]
d0080308:	b29b      	uxth	r3, r3
d008030a:	fb01 2203 	mla	r2, r1, r3, r2
d008030e:	9b07      	ldr	r3, [sp, #28]
d0080310:	f802 3009 	strb.w	r3, [r2, r9]
d0080314:	3101      	adds	r1, #1
d0080316:	9b02      	ldr	r3, [sp, #8]
d0080318:	428b      	cmp	r3, r1
d008031a:	db41      	blt.n	d00803a0 <draw_filled_triangle.part.0.constprop.0+0x1a4>
d008031c:	f9b0 6004 	ldrsh.w	r6, [r0, #4]
d0080320:	f9b0 2000 	ldrsh.w	r2, [r0]
d0080324:	f9b0 7006 	ldrsh.w	r7, [r0, #6]
d0080328:	f9b0 c002 	ldrsh.w	ip, [r0, #2]
d008032c:	eba6 0b02 	sub.w	fp, r6, r2
d0080330:	f9b0 300a 	ldrsh.w	r3, [r0, #10]
d0080334:	f9b0 5008 	ldrsh.w	r5, [r0, #8]
d0080338:	eba7 0a0c 	sub.w	sl, r7, ip
d008033c:	9300      	str	r3, [sp, #0]
d008033e:	1b8b      	subs	r3, r1, r6
d0080340:	eba5 0e06 	sub.w	lr, r5, r6
d0080344:	eba9 0407 	sub.w	r4, r9, r7
d0080348:	9e00      	ldr	r6, [sp, #0]
d008034a:	9301      	str	r3, [sp, #4]
d008034c:	1b53      	subs	r3, r2, r5
d008034e:	1bf7      	subs	r7, r6, r7
d0080350:	fb04 f40e 	mul.w	r4, r4, lr
d0080354:	eba9 0806 	sub.w	r8, r9, r6
d0080358:	9e01      	ldr	r6, [sp, #4]
d008035a:	eba9 0e0c 	sub.w	lr, r9, ip
d008035e:	1b4d      	subs	r5, r1, r5
d0080360:	fb08 f803 	mul.w	r8, r8, r3
d0080364:	9b00      	ldr	r3, [sp, #0]
d0080366:	fb06 4417 	mls	r4, r6, r7, r4
d008036a:	1a8a      	subs	r2, r1, r2
d008036c:	ebac 0303 	sub.w	r3, ip, r3
d0080370:	fb0e fe0b 	mul.w	lr, lr, fp
d0080374:	2c00      	cmp	r4, #0
d0080376:	fb05 8513 	mls	r5, r5, r3, r8
d008037a:	fb02 e21a 	mls	r2, r2, sl, lr
d008037e:	db02      	blt.n	d0080386 <draw_filled_triangle.part.0.constprop.0+0x18a>
d0080380:	9b03      	ldr	r3, [sp, #12]
d0080382:	2b00      	cmp	r3, #0
d0080384:	d1b0      	bne.n	d00802e8 <draw_filled_triangle.part.0.constprop.0+0xec>
d0080386:	9b04      	ldr	r3, [sp, #16]
d0080388:	2b00      	cmp	r3, #0
d008038a:	d0c3      	beq.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d008038c:	2c00      	cmp	r4, #0
d008038e:	dcc1      	bgt.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d0080390:	2d00      	cmp	r5, #0
d0080392:	dcbf      	bgt.n	d0080314 <draw_filled_triangle.part.0.constprop.0+0x118>
d0080394:	2a00      	cmp	r2, #0
d0080396:	ddab      	ble.n	d00802f0 <draw_filled_triangle.part.0.constprop.0+0xf4>
d0080398:	3101      	adds	r1, #1
d008039a:	9b02      	ldr	r3, [sp, #8]
d008039c:	428b      	cmp	r3, r1
d008039e:	dabd      	bge.n	d008031c <draw_filled_triangle.part.0.constprop.0+0x120>
d00803a0:	f109 0901 	add.w	r9, r9, #1
d00803a4:	9b06      	ldr	r3, [sp, #24]
d00803a6:	454b      	cmp	r3, r9
d00803a8:	db10      	blt.n	d00803cc <draw_filled_triangle.part.0.constprop.0+0x1d0>
d00803aa:	f9b0 6004 	ldrsh.w	r6, [r0, #4]
d00803ae:	f9b0 2000 	ldrsh.w	r2, [r0]
d00803b2:	f9b0 7006 	ldrsh.w	r7, [r0, #6]
d00803b6:	f9b0 c002 	ldrsh.w	ip, [r0, #2]
d00803ba:	eba6 0b02 	sub.w	fp, r6, r2
d00803be:	f9b0 5008 	ldrsh.w	r5, [r0, #8]
d00803c2:	eba7 0a0c 	sub.w	sl, r7, ip
d00803c6:	f9b0 300a 	ldrsh.w	r3, [r0, #10]
d00803ca:	e78a      	b.n	d00802e2 <draw_filled_triangle.part.0.constprop.0+0xe6>
d00803cc:	b009      	add	sp, #36	; 0x24
d00803ce:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00803d2:	2100      	movs	r1, #0
d00803d4:	9106      	str	r1, [sp, #24]
d00803d6:	e767      	b.n	d00802a8 <draw_filled_triangle.part.0.constprop.0+0xac>
d00803d8:	f04f 0900 	mov.w	r9, #0
d00803dc:	e75d      	b.n	d008029a <draw_filled_triangle.part.0.constprop.0+0x9e>
d00803de:	2100      	movs	r1, #0
d00803e0:	9102      	str	r1, [sp, #8]
d00803e2:	e74e      	b.n	d0080282 <draw_filled_triangle.part.0.constprop.0+0x86>
d00803e4:	2100      	movs	r1, #0
d00803e6:	9105      	str	r1, [sp, #20]
d00803e8:	e742      	b.n	d0080270 <draw_filled_triangle.part.0.constprop.0+0x74>
d00803ea:	bf00      	nop
d00803ec:	d00877e0 	.word	0xd00877e0

d00803f0 <draw_cube>:
d00803f0:	4ad7      	ldr	r2, [pc, #860]	; (d0080750 <draw_cube+0x360>)
d00803f2:	4bd8      	ldr	r3, [pc, #864]	; (d0080754 <draw_cube+0x364>)
d00803f4:	6811      	ldr	r1, [r2, #0]
d00803f6:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00803fa:	681f      	ldr	r7, [r3, #0]
d00803fc:	f5ad 7d47 	sub.w	sp, sp, #796	; 0x31c
d0080400:	eb07 0741 	add.w	r7, r7, r1, lsl #1
d0080404:	9000      	str	r0, [sp, #0]
d0080406:	f5b7 7f80 	cmp.w	r7, #256	; 0x100
d008040a:	f340 82cd 	ble.w	d00809a8 <draw_cube+0x5b8>
d008040e:	f44f 7780 	mov.w	r7, #256	; 0x100
d0080412:	f06f 0104 	mvn.w	r1, #4
d0080416:	601f      	str	r7, [r3, #0]
d0080418:	6011      	str	r1, [r2, #0]
d008041a:	f8df 835c 	ldr.w	r8, [pc, #860]	; d0080778 <draw_cube+0x388>
d008041e:	f8d8 3000 	ldr.w	r3, [r8]
d0080422:	42bb      	cmp	r3, r7
d0080424:	d032      	beq.n	d008048c <draw_cube+0x9c>
d0080426:	4bcc      	ldr	r3, [pc, #816]	; (d0080758 <draw_cube+0x368>)
d0080428:	f04f 0e00 	mov.w	lr, #0
d008042c:	4ecb      	ldr	r6, [pc, #812]	; (d008075c <draw_cube+0x36c>)
d008042e:	f503 6c96 	add.w	ip, r3, #1200	; 0x4b0
d0080432:	4acb      	ldr	r2, [pc, #812]	; (d0080760 <draw_cube+0x370>)
d0080434:	f9b3 4002 	ldrsh.w	r4, [r3, #2]
d0080438:	3308      	adds	r3, #8
d008043a:	f9b6 1002 	ldrsh.w	r1, [r6, #2]
d008043e:	3208      	adds	r2, #8
d0080440:	f933 ac04 	ldrsh.w	sl, [r3, #-4]
d0080444:	f933 9c08 	ldrsh.w	r9, [r3, #-8]
d0080448:	eba1 0b04 	sub.w	fp, r1, r4
d008044c:	f9b6 0004 	ldrsh.w	r0, [r6, #4]
d0080450:	459c      	cmp	ip, r3
d0080452:	f936 5b08 	ldrsh.w	r5, [r6], #8
d0080456:	fb07 f10b 	mul.w	r1, r7, fp
d008045a:	eba0 000a 	sub.w	r0, r0, sl
d008045e:	f822 ec02 	strh.w	lr, [r2, #-2]
d0080462:	eba5 0509 	sub.w	r5, r5, r9
d0080466:	eb04 2421 	add.w	r4, r4, r1, asr #8
d008046a:	fb07 f000 	mul.w	r0, r7, r0
d008046e:	fb07 f105 	mul.w	r1, r7, r5
d0080472:	eb0a 2020 	add.w	r0, sl, r0, asr #8
d0080476:	f822 4c06 	strh.w	r4, [r2, #-6]
d008047a:	eb09 2121 	add.w	r1, r9, r1, asr #8
d008047e:	f822 0c04 	strh.w	r0, [r2, #-4]
d0080482:	f822 1c08 	strh.w	r1, [r2, #-8]
d0080486:	d1d5      	bne.n	d0080434 <draw_cube+0x44>
d0080488:	f8c8 7000 	str.w	r7, [r8]
d008048c:	4ab5      	ldr	r2, [pc, #724]	; (d0080764 <draw_cube+0x374>)
d008048e:	f44f 76b4 	mov.w	r6, #360	; 0x168
d0080492:	4bb5      	ldr	r3, [pc, #724]	; (d0080768 <draw_cube+0x378>)
d0080494:	f649 6734 	movw	r7, #40500	; 0x9e34
d0080498:	6811      	ldr	r1, [r2, #0]
d008049a:	4cb4      	ldr	r4, [pc, #720]	; (d008076c <draw_cube+0x37c>)
d008049c:	fb83 0201 	smull	r0, r2, r3, r1
d00804a0:	ea4f 78e1 	mov.w	r8, r1, asr #31
d00804a4:	f101 005a 	add.w	r0, r1, #90	; 0x5a
d00804a8:	6825      	ldr	r5, [r4, #0]
d00804aa:	440a      	add	r2, r1
d00804ac:	f8df e2cc 	ldr.w	lr, [pc, #716]	; d008077c <draw_cube+0x38c>
d00804b0:	fb83 c400 	smull	ip, r4, r3, r0
d00804b4:	ea4f 7ce0 	mov.w	ip, r0, asr #31
d00804b8:	ebc8 2222 	rsb	r2, r8, r2, asr #8
d00804bc:	f8de e000 	ldr.w	lr, [lr]
d00804c0:	4404      	add	r4, r0
d00804c2:	fb06 1212 	mls	r2, r6, r2, r1
d00804c6:	ebcc 2424 	rsb	r4, ip, r4, asr #8
d00804ca:	fb83 c105 	smull	ip, r1, r3, r5
d00804ce:	eb02 0806 	add.w	r8, r2, r6
d00804d2:	ea4f 7ce5 	mov.w	ip, r5, asr #31
d00804d6:	fb06 0414 	mls	r4, r6, r4, r0
d00804da:	4429      	add	r1, r5
d00804dc:	ea32 0222 	bics.w	r2, r2, r2, asr #32
d00804e0:	bf28      	it	cs
d00804e2:	4642      	movcs	r2, r8
d00804e4:	f105 005a 	add.w	r0, r5, #90	; 0x5a
d00804e8:	eb04 0906 	add.w	r9, r4, r6
d00804ec:	ebcc 2121 	rsb	r1, ip, r1, asr #8
d00804f0:	2ab4      	cmp	r2, #180	; 0xb4
d00804f2:	f1a2 08b4 	sub.w	r8, r2, #180	; 0xb4
d00804f6:	fb06 5111 	mls	r1, r6, r1, r5
d00804fa:	ea4f 7ce0 	mov.w	ip, r0, asr #31
d00804fe:	bfcb      	itete	gt
d0080500:	4645      	movgt	r5, r8
d0080502:	4615      	movle	r5, r2
d0080504:	f04f 38ff 	movgt.w	r8, #4294967295	; 0xffffffff
d0080508:	f04f 0801 	movle.w	r8, #1
d008050c:	ea34 0424 	bics.w	r4, r4, r4, asr #32
d0080510:	bf28      	it	cs
d0080512:	464c      	movcs	r4, r9
d0080514:	fb83 9200 	smull	r9, r2, r3, r0
d0080518:	f1c5 09b4 	rsb	r9, r5, #180	; 0xb4
d008051c:	4402      	add	r2, r0
d008051e:	2cb4      	cmp	r4, #180	; 0xb4
d0080520:	fb05 f509 	mul.w	r5, r5, r9
d0080524:	ebcc 2222 	rsb	r2, ip, r2, asr #8
d0080528:	f1a4 0cb4 	sub.w	ip, r4, #180	; 0xb4
d008052c:	bfca      	itet	gt
d008052e:	f04f 3bff 	movgt.w	fp, #4294967295	; 0xffffffff
d0080532:	f04f 0b01 	movle.w	fp, #1
d0080536:	4664      	movgt	r4, ip
d0080538:	fb06 0212 	mls	r2, r6, r2, r0
d008053c:	eb01 0c06 	add.w	ip, r1, r6
d0080540:	fb83 900e 	smull	r9, r0, r3, lr
d0080544:	ebc5 3ac5 	rsb	sl, r5, r5, lsl #15
d0080548:	1b7d      	subs	r5, r7, r5
d008054a:	ea31 0121 	bics.w	r1, r1, r1, asr #32
d008054e:	bf28      	it	cs
d0080550:	4661      	movcs	r1, ip
d0080552:	4470      	add	r0, lr
d0080554:	ea4f 7cee 	mov.w	ip, lr, asr #31
d0080558:	29b4      	cmp	r1, #180	; 0xb4
d008055a:	ea4f 0a8a 	mov.w	sl, sl, lsl #2
d008055e:	ebcc 2020 	rsb	r0, ip, r0, asr #8
d0080562:	f10e 0c5a 	add.w	ip, lr, #90	; 0x5a
d0080566:	fb06 e010 	mls	r0, r6, r0, lr
d008056a:	fb83 e30c 	smull	lr, r3, r3, ip
d008056e:	f1a1 0eb4 	sub.w	lr, r1, #180	; 0xb4
d0080572:	bfc8      	it	gt
d0080574:	4671      	movgt	r1, lr
d0080576:	eb02 0e06 	add.w	lr, r2, r6
d008057a:	eb03 090c 	add.w	r9, r3, ip
d008057e:	bfcc      	ite	gt
d0080580:	f04f 33ff 	movgt.w	r3, #4294967295	; 0xffffffff
d0080584:	2301      	movle	r3, #1
d0080586:	ea32 0222 	bics.w	r2, r2, r2, asr #32
d008058a:	bf28      	it	cs
d008058c:	4672      	movcs	r2, lr
d008058e:	ea4f 7eec 	mov.w	lr, ip, asr #31
d0080592:	9301      	str	r3, [sp, #4]
d0080594:	2ab4      	cmp	r2, #180	; 0xb4
d0080596:	ebce 2329 	rsb	r3, lr, r9, asr #8
d008059a:	bfcc      	ite	gt
d008059c:	f04f 3eff 	movgt.w	lr, #4294967295	; 0xffffffff
d00805a0:	f04f 0e01 	movle.w	lr, #1
d00805a4:	fb06 c313 	mls	r3, r6, r3, ip
d00805a8:	f1a2 0cb4 	sub.w	ip, r2, #180	; 0xb4
d00805ac:	4406      	add	r6, r0
d00805ae:	bfc8      	it	gt
d00805b0:	4662      	movgt	r2, ip
d00805b2:	ea30 0020 	bics.w	r0, r0, r0, asr #32
d00805b6:	bf28      	it	cs
d00805b8:	4630      	movcs	r0, r6
d00805ba:	f503 76b4 	add.w	r6, r3, #360	; 0x168
d00805be:	28b4      	cmp	r0, #180	; 0xb4
d00805c0:	f1a0 0cb4 	sub.w	ip, r0, #180	; 0xb4
d00805c4:	bfd2      	itee	le
d00805c6:	f04f 0c01 	movle.w	ip, #1
d00805ca:	4660      	movgt	r0, ip
d00805cc:	f04f 3cff 	movgt.w	ip, #4294967295	; 0xffffffff
d00805d0:	ea33 0323 	bics.w	r3, r3, r3, asr #32
d00805d4:	bf28      	it	cs
d00805d6:	4633      	movcs	r3, r6
d00805d8:	2bb4      	cmp	r3, #180	; 0xb4
d00805da:	f1a3 06b4 	sub.w	r6, r3, #180	; 0xb4
d00805de:	bfc8      	it	gt
d00805e0:	4633      	movgt	r3, r6
d00805e2:	f1c4 06b4 	rsb	r6, r4, #180	; 0xb4
d00805e6:	fb04 f406 	mul.w	r4, r4, r6
d00805ea:	f1c1 06b4 	rsb	r6, r1, #180	; 0xb4
d00805ee:	fb01 f106 	mul.w	r1, r1, r6
d00805f2:	f1c2 06b4 	rsb	r6, r2, #180	; 0xb4
d00805f6:	ebc4 39c4 	rsb	r9, r4, r4, lsl #15
d00805fa:	eba7 0404 	sub.w	r4, r7, r4
d00805fe:	fb02 f206 	mul.w	r2, r2, r6
d0080602:	f1c0 06b4 	rsb	r6, r0, #180	; 0xb4
d0080606:	ea4f 0989 	mov.w	r9, r9, lsl #2
d008060a:	fb00 f006 	mul.w	r0, r0, r6
d008060e:	f1c3 06b4 	rsb	r6, r3, #180	; 0xb4
d0080612:	fbba faf5 	udiv	sl, sl, r5
d0080616:	fb03 f306 	mul.w	r3, r3, r6
d008061a:	ebc1 36c1 	rsb	r6, r1, r1, lsl #15
d008061e:	ebc2 35c2 	rsb	r5, r2, r2, lsl #15
d0080622:	eba7 0101 	sub.w	r1, r7, r1
d0080626:	ea4f 0686 	mov.w	r6, r6, lsl #2
d008062a:	eba7 0202 	sub.w	r2, r7, r2
d008062e:	fb08 f80a 	mul.w	r8, r8, sl
d0080632:	ea4f 0a85 	mov.w	sl, r5, lsl #2
d0080636:	fbb9 f4f4 	udiv	r4, r9, r4
d008063a:	ebc0 39c0 	rsb	r9, r0, r0, lsl #15
d008063e:	eba7 0000 	sub.w	r0, r7, r0
d0080642:	eba7 0703 	sub.w	r7, r7, r3
d0080646:	ebc3 33c3 	rsb	r3, r3, r3, lsl #15
d008064a:	ea4f 0989 	mov.w	r9, r9, lsl #2
d008064e:	ea4f 0383 	mov.w	r3, r3, lsl #2
d0080652:	fbb6 f1f1 	udiv	r1, r6, r1
d0080656:	fbb3 f7f7 	udiv	r7, r3, r7
d008065a:	fbb9 f0f0 	udiv	r0, r9, r0
d008065e:	fbba f2f2 	udiv	r2, sl, r2
d0080662:	fb0b f604 	mul.w	r6, fp, r4
d0080666:	9c01      	ldr	r4, [sp, #4]
d0080668:	bfcc      	ite	gt
d008066a:	f04f 33ff 	movgt.w	r3, #4294967295	; 0xffffffff
d008066e:	2301      	movle	r3, #1
d0080670:	fb04 f501 	mul.w	r5, r4, r1
d0080674:	4c3e      	ldr	r4, [pc, #248]	; (d0080770 <draw_cube+0x380>)
d0080676:	fb0c fc00 	mul.w	ip, ip, r0
d008067a:	4939      	ldr	r1, [pc, #228]	; (d0080760 <draw_cube+0x370>)
d008067c:	fb0e fe02 	mul.w	lr, lr, r2
d0080680:	4620      	mov	r0, r4
d0080682:	fb03 f707 	mul.w	r7, r3, r7
d0080686:	f9b1 3004 	ldrsh.w	r3, [r1, #4]
d008068a:	3008      	adds	r0, #8
d008068c:	f9b1 9002 	ldrsh.w	r9, [r1, #2]
d0080690:	fb03 fa06 	mul.w	sl, r3, r6
d0080694:	f9b1 2006 	ldrsh.w	r2, [r1, #6]
d0080698:	fb09 fb06 	mul.w	fp, r9, r6
d008069c:	fb09 a908 	mla	r9, r9, r8, sl
d00806a0:	f931 ab08 	ldrsh.w	sl, [r1], #8
d00806a4:	f820 2c02 	strh.w	r2, [r0, #-2]
d00806a8:	f349 39cf 	sbfx	r9, r9, #15, #16
d00806ac:	fb03 b318 	mls	r3, r3, r8, fp
d00806b0:	fb09 f205 	mul.w	r2, r9, r5
d00806b4:	f343 33cf 	sbfx	r3, r3, #15, #16
d00806b8:	fb09 f90e 	mul.w	r9, r9, lr
d00806bc:	fb0a 220e 	mla	r2, sl, lr, r2
d00806c0:	fb0a 9915 	mls	r9, sl, r5, r9
d00806c4:	f342 32cf 	sbfx	r2, r2, #15, #16
d00806c8:	fb03 fb07 	mul.w	fp, r3, r7
d00806cc:	ea4f 39e9 	mov.w	r9, r9, asr #15
d00806d0:	fb02 fa07 	mul.w	sl, r2, r7
d00806d4:	fb02 b20c 	mla	r2, r2, ip, fp
d00806d8:	fb03 a31c 	mls	r3, r3, ip, sl
d00806dc:	13d2      	asrs	r2, r2, #15
d00806de:	f820 9c04 	strh.w	r9, [r0, #-4]
d00806e2:	13db      	asrs	r3, r3, #15
d00806e4:	f820 2c06 	strh.w	r2, [r0, #-6]
d00806e8:	f820 3c08 	strh.w	r3, [r0, #-8]
d00806ec:	4b21      	ldr	r3, [pc, #132]	; (d0080774 <draw_cube+0x384>)
d00806ee:	428b      	cmp	r3, r1
d00806f0:	d1c9      	bne.n	d0080686 <draw_cube+0x296>
d00806f2:	f10d 0027 	add.w	r0, sp, #39	; 0x27
d00806f6:	f10d 05bd 	add.w	r5, sp, #189	; 0xbd
d00806fa:	2700      	movs	r7, #0
d00806fc:	a930      	add	r1, sp, #192	; 0xc0
d00806fe:	2601      	movs	r6, #1
d0080700:	f9b4 3004 	ldrsh.w	r3, [r4, #4]
d0080704:	f503 7cfa 	add.w	ip, r3, #500	; 0x1f4
d0080708:	f1bc 0f00 	cmp.w	ip, #0
d008070c:	f340 8134 	ble.w	d0080978 <draw_cube+0x588>
d0080710:	f9b4 2002 	ldrsh.w	r2, [r4, #2]
d0080714:	3104      	adds	r1, #4
d0080716:	f934 3b08 	ldrsh.w	r3, [r4], #8
d008071a:	ebc2 1202 	rsb	r2, r2, r2, lsl #4
d008071e:	f800 6f01 	strb.w	r6, [r0, #1]!
d0080722:	ebc3 1303 	rsb	r3, r3, r3, lsl #4
d0080726:	42a8      	cmp	r0, r5
d0080728:	ea4f 1202 	mov.w	r2, r2, lsl #4
d008072c:	ea4f 1303 	mov.w	r3, r3, lsl #4
d0080730:	fb92 f2fc 	sdiv	r2, r2, ip
d0080734:	fb93 f3fc 	sdiv	r3, r3, ip
d0080738:	f1c2 02a0 	rsb	r2, r2, #160	; 0xa0
d008073c:	f103 03f0 	add.w	r3, r3, #240	; 0xf0
d0080740:	f821 2c02 	strh.w	r2, [r1, #-2]
d0080744:	f821 3c04 	strh.w	r3, [r1, #-4]
d0080748:	d1da      	bne.n	d0080700 <draw_cube+0x310>
d008074a:	f8df b034 	ldr.w	fp, [pc, #52]	; d0080780 <draw_cube+0x390>
d008074e:	e019      	b.n	d0080784 <draw_cube+0x394>
d0080750:	d0087754 	.word	0xd0087754
d0080754:	d0088b98 	.word	0xd0088b98
d0080758:	d0087804 	.word	0xd0087804
d008075c:	d0089050 	.word	0xd0089050
d0080760:	d00886e4 	.word	0xd00886e4
d0080764:	d00877c8 	.word	0xd00877c8
d0080768:	b60b60b7 	.word	0xb60b60b7
d008076c:	d00877cc 	.word	0xd00877cc
d0080770:	d0088b9c 	.word	0xd0088b9c
d0080774:	d0088b94 	.word	0xd0088b94
d0080778:	d0087750 	.word	0xd0087750
d008077c:	d00877d0 	.word	0xd00877d0
d0080780:	d00880c0 	.word	0xd00880c0
d0080784:	f9bb 3000 	ldrsh.w	r3, [fp]
d0080788:	aa0a      	add	r2, sp, #40	; 0x28
d008078a:	5cd2      	ldrb	r2, [r2, r3]
d008078c:	2a00      	cmp	r2, #0
d008078e:	f000 80e9 	beq.w	d0080964 <draw_cube+0x574>
d0080792:	f9bb 2002 	ldrsh.w	r2, [fp, #2]
d0080796:	a90a      	add	r1, sp, #40	; 0x28
d0080798:	5c88      	ldrb	r0, [r1, r2]
d008079a:	2800      	cmp	r0, #0
d008079c:	f000 80e2 	beq.w	d0080964 <draw_cube+0x574>
d00807a0:	f9bb 5004 	ldrsh.w	r5, [fp, #4]
d00807a4:	5d48      	ldrb	r0, [r1, r5]
d00807a6:	2800      	cmp	r0, #0
d00807a8:	f000 80dc 	beq.w	d0080964 <draw_cube+0x574>
d00807ac:	a930      	add	r1, sp, #192	; 0xc0
d00807ae:	eb01 0083 	add.w	r0, r1, r3, lsl #2
d00807b2:	f931 8023 	ldrsh.w	r8, [r1, r3, lsl #2]
d00807b6:	eb01 0385 	add.w	r3, r1, r5, lsl #2
d00807ba:	f931 4022 	ldrsh.w	r4, [r1, r2, lsl #2]
d00807be:	f9b0 7002 	ldrsh.w	r7, [r0, #2]
d00807c2:	eb01 0282 	add.w	r2, r1, r2, lsl #2
d00807c6:	f9b3 0002 	ldrsh.w	r0, [r3, #2]
d00807ca:	eba4 0608 	sub.w	r6, r4, r8
d00807ce:	f931 c025 	ldrsh.w	ip, [r1, r5, lsl #2]
d00807d2:	1bc3      	subs	r3, r0, r7
d00807d4:	f9b2 5002 	ldrsh.w	r5, [r2, #2]
d00807d8:	9604      	str	r6, [sp, #16]
d00807da:	ebac 0208 	sub.w	r2, ip, r8
d00807de:	fb06 f303 	mul.w	r3, r6, r3
d00807e2:	1bee      	subs	r6, r5, r7
d00807e4:	fb06 3312 	mls	r3, r6, r2, r3
d00807e8:	9601      	str	r6, [sp, #4]
d00807ea:	2b00      	cmp	r3, #0
d00807ec:	f2c0 80ba 	blt.w	d0080964 <draw_cube+0x574>
d00807f0:	9900      	ldr	r1, [sp, #0]
d00807f2:	2900      	cmp	r1, #0
d00807f4:	f000 80b6 	beq.w	d0080964 <draw_cube+0x574>
d00807f8:	680a      	ldr	r2, [r1, #0]
d00807fa:	2a00      	cmp	r2, #0
d00807fc:	f000 80b2 	beq.w	d0080964 <draw_cube+0x574>
d0080800:	4544      	cmp	r4, r8
d0080802:	46a6      	mov	lr, r4
d0080804:	4626      	mov	r6, r4
d0080806:	462a      	mov	r2, r5
d0080808:	bfa8      	it	ge
d008080a:	46c6      	movge	lr, r8
d008080c:	4544      	cmp	r4, r8
d008080e:	46aa      	mov	sl, r5
d0080810:	f8b1 9004 	ldrh.w	r9, [r1, #4]
d0080814:	bfb8      	it	lt
d0080816:	4646      	movlt	r6, r8
d0080818:	42bd      	cmp	r5, r7
d008081a:	f109 39ff 	add.w	r9, r9, #4294967295	; 0xffffffff
d008081e:	bfa8      	it	ge
d0080820:	463a      	movge	r2, r7
d0080822:	42bd      	cmp	r5, r7
d0080824:	bfb8      	it	lt
d0080826:	46ba      	movlt	sl, r7
d0080828:	45e6      	cmp	lr, ip
d008082a:	bfa8      	it	ge
d008082c:	46e6      	movge	lr, ip
d008082e:	4566      	cmp	r6, ip
d0080830:	4651      	mov	r1, sl
d0080832:	bfb8      	it	lt
d0080834:	4666      	movlt	r6, ip
d0080836:	4282      	cmp	r2, r0
d0080838:	bfa8      	it	ge
d008083a:	4602      	movge	r2, r0
d008083c:	4582      	cmp	sl, r0
d008083e:	bfb8      	it	lt
d0080840:	4601      	movlt	r1, r0
d0080842:	f1be 0f00 	cmp.w	lr, #0
d0080846:	9105      	str	r1, [sp, #20]
d0080848:	f2c0 80ab 	blt.w	d00809a2 <draw_cube+0x5b2>
d008084c:	45ce      	cmp	lr, r9
d008084e:	4671      	mov	r1, lr
d0080850:	bfa8      	it	ge
d0080852:	4649      	movge	r1, r9
d0080854:	9103      	str	r1, [sp, #12]
d0080856:	2e00      	cmp	r6, #0
d0080858:	f2c0 80a0 	blt.w	d008099c <draw_cube+0x5ac>
d008085c:	454e      	cmp	r6, r9
d008085e:	4631      	mov	r1, r6
d0080860:	bfa8      	it	ge
d0080862:	4649      	movge	r1, r9
d0080864:	9102      	str	r1, [sp, #8]
d0080866:	9900      	ldr	r1, [sp, #0]
d0080868:	2a00      	cmp	r2, #0
d008086a:	f8b1 a006 	ldrh.w	sl, [r1, #6]
d008086e:	f10a 3aff 	add.w	sl, sl, #4294967295	; 0xffffffff
d0080872:	f2c0 808b 	blt.w	d008098c <draw_cube+0x59c>
d0080876:	4552      	cmp	r2, sl
d0080878:	9905      	ldr	r1, [sp, #20]
d008087a:	bfa8      	it	ge
d008087c:	4652      	movge	r2, sl
d008087e:	2900      	cmp	r1, #0
d0080880:	f2c0 8089 	blt.w	d0080996 <draw_cube+0x5a6>
d0080884:	4551      	cmp	r1, sl
d0080886:	bfa8      	it	ge
d0080888:	4651      	movge	r1, sl
d008088a:	9105      	str	r1, [sp, #20]
d008088c:	9e03      	ldr	r6, [sp, #12]
d008088e:	9902      	ldr	r1, [sp, #8]
d0080890:	428e      	cmp	r6, r1
d0080892:	dc67      	bgt.n	d0080964 <draw_cube+0x574>
d0080894:	9905      	ldr	r1, [sp, #20]
d0080896:	428a      	cmp	r2, r1
d0080898:	dc64      	bgt.n	d0080964 <draw_cube+0x574>
d008089a:	2b00      	cmp	r3, #0
d008089c:	d062      	beq.n	d0080964 <draw_cube+0x574>
d008089e:	ebac 0104 	sub.w	r1, ip, r4
d00808a2:	1b56      	subs	r6, r2, r5
d00808a4:	eba8 030c 	sub.w	r3, r8, ip
d00808a8:	eba2 0900 	sub.w	r9, r2, r0
d00808ac:	fb01 f606 	mul.w	r6, r1, r6
d00808b0:	9107      	str	r1, [sp, #28]
d00808b2:	9903      	ldr	r1, [sp, #12]
d00808b4:	9306      	str	r3, [sp, #24]
d00808b6:	eba1 0e08 	sub.w	lr, r1, r8
d00808ba:	eba1 0c0c 	sub.w	ip, r1, ip
d00808be:	9906      	ldr	r1, [sp, #24]
d00808c0:	eba2 0807 	sub.w	r8, r2, r7
d00808c4:	9b03      	ldr	r3, [sp, #12]
d00808c6:	1a3f      	subs	r7, r7, r0
d00808c8:	fb01 f909 	mul.w	r9, r1, r9
d00808cc:	9904      	ldr	r1, [sp, #16]
d00808ce:	1b1c      	subs	r4, r3, r4
d00808d0:	1b43      	subs	r3, r0, r5
d00808d2:	fb01 f808 	mul.w	r8, r1, r8
d00808d6:	f89b 1006 	ldrb.w	r1, [fp, #6]
d00808da:	fb03 6614 	mls	r6, r3, r4, r6
d00808de:	1a2b      	subs	r3, r5, r0
d00808e0:	9108      	str	r1, [sp, #32]
d00808e2:	46ba      	mov	sl, r7
d00808e4:	9901      	ldr	r1, [sp, #4]
d00808e6:	fb07 991c 	mls	r9, r7, ip, r9
d00808ea:	f8cd b024 	str.w	fp, [sp, #36]	; 0x24
d00808ee:	469b      	mov	fp, r3
d00808f0:	fb01 881e 	mls	r8, r1, lr, r8
d00808f4:	46b6      	mov	lr, r6
d00808f6:	9900      	ldr	r1, [sp, #0]
d00808f8:	0fd7      	lsrs	r7, r2, #31
d00808fa:	4645      	mov	r5, r8
d00808fc:	464c      	mov	r4, r9
d00808fe:	4670      	mov	r0, lr
d0080900:	9b03      	ldr	r3, [sp, #12]
d0080902:	9700      	str	r7, [sp, #0]
d0080904:	2800      	cmp	r0, #0
d0080906:	4458      	add	r0, fp
d0080908:	db17      	blt.n	d008093a <draw_cube+0x54a>
d008090a:	2c00      	cmp	r4, #0
d008090c:	db15      	blt.n	d008093a <draw_cube+0x54a>
d008090e:	2d00      	cmp	r5, #0
d0080910:	db13      	blt.n	d008093a <draw_cube+0x54a>
d0080912:	680e      	ldr	r6, [r1, #0]
d0080914:	b18e      	cbz	r6, d008093a <draw_cube+0x54a>
d0080916:	2b00      	cmp	r3, #0
d0080918:	db0f      	blt.n	d008093a <draw_cube+0x54a>
d008091a:	9f00      	ldr	r7, [sp, #0]
d008091c:	b96f      	cbnz	r7, d008093a <draw_cube+0x54a>
d008091e:	f8b1 c004 	ldrh.w	ip, [r1, #4]
d0080922:	459c      	cmp	ip, r3
d0080924:	dd09      	ble.n	d008093a <draw_cube+0x54a>
d0080926:	f8b1 c006 	ldrh.w	ip, [r1, #6]
d008092a:	4594      	cmp	ip, r2
d008092c:	dd05      	ble.n	d008093a <draw_cube+0x54a>
d008092e:	f8b1 c008 	ldrh.w	ip, [r1, #8]
d0080932:	9f08      	ldr	r7, [sp, #32]
d0080934:	fb03 660c 	mla	r6, r3, ip, r6
d0080938:	54b7      	strb	r7, [r6, r2]
d008093a:	9e01      	ldr	r6, [sp, #4]
d008093c:	3301      	adds	r3, #1
d008093e:	eba4 040a 	sub.w	r4, r4, sl
d0080942:	1bad      	subs	r5, r5, r6
d0080944:	9e02      	ldr	r6, [sp, #8]
d0080946:	429e      	cmp	r6, r3
d0080948:	dadc      	bge.n	d0080904 <draw_cube+0x514>
d008094a:	9b07      	ldr	r3, [sp, #28]
d008094c:	3201      	adds	r2, #1
d008094e:	449e      	add	lr, r3
d0080950:	9b06      	ldr	r3, [sp, #24]
d0080952:	4499      	add	r9, r3
d0080954:	9b04      	ldr	r3, [sp, #16]
d0080956:	4498      	add	r8, r3
d0080958:	9b05      	ldr	r3, [sp, #20]
d008095a:	4293      	cmp	r3, r2
d008095c:	dacc      	bge.n	d00808f8 <draw_cube+0x508>
d008095e:	f8dd b024 	ldr.w	fp, [sp, #36]	; 0x24
d0080962:	9100      	str	r1, [sp, #0]
d0080964:	f10b 0b08 	add.w	fp, fp, #8
d0080968:	4b15      	ldr	r3, [pc, #84]	; (d00809c0 <draw_cube+0x5d0>)
d008096a:	455b      	cmp	r3, fp
d008096c:	f47f af0a 	bne.w	d0080784 <draw_cube+0x394>
d0080970:	f50d 7d47 	add.w	sp, sp, #796	; 0x31c
d0080974:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0080978:	f800 7f01 	strb.w	r7, [r0, #1]!
d008097c:	4285      	cmp	r5, r0
d008097e:	f104 0408 	add.w	r4, r4, #8
d0080982:	f101 0104 	add.w	r1, r1, #4
d0080986:	f47f aebb 	bne.w	d0080700 <draw_cube+0x310>
d008098a:	e6de      	b.n	d008074a <draw_cube+0x35a>
d008098c:	9905      	ldr	r1, [sp, #20]
d008098e:	2200      	movs	r2, #0
d0080990:	2900      	cmp	r1, #0
d0080992:	f6bf af77 	bge.w	d0080884 <draw_cube+0x494>
d0080996:	2100      	movs	r1, #0
d0080998:	9105      	str	r1, [sp, #20]
d008099a:	e777      	b.n	d008088c <draw_cube+0x49c>
d008099c:	2100      	movs	r1, #0
d008099e:	9102      	str	r1, [sp, #8]
d00809a0:	e761      	b.n	d0080866 <draw_cube+0x476>
d00809a2:	2100      	movs	r1, #0
d00809a4:	9103      	str	r1, [sp, #12]
d00809a6:	e756      	b.n	d0080856 <draw_cube+0x466>
d00809a8:	f117 0fff 	cmn.w	r7, #255	; 0xff
d00809ac:	da06      	bge.n	d00809bc <draw_cube+0x5cc>
d00809ae:	f06f 01fe 	mvn.w	r1, #254	; 0xfe
d00809b2:	2005      	movs	r0, #5
d00809b4:	460f      	mov	r7, r1
d00809b6:	6019      	str	r1, [r3, #0]
d00809b8:	6010      	str	r0, [r2, #0]
d00809ba:	e52e      	b.n	d008041a <draw_cube+0x2a>
d00809bc:	601f      	str	r7, [r3, #0]
d00809be:	e52c      	b.n	d008041a <draw_cube+0x2a>
d00809c0:	d00886c0 	.word	0xd00886c0
d00809c4:	00000000 	.word	0x00000000

d00809c8 <main>:
d00809c8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00809cc:	f8df b434 	ldr.w	fp, [pc, #1076]	; d0080e04 <main+0x43c>
d00809d0:	b0bd      	sub	sp, #244	; 0xf4
d00809d2:	f44f 2000 	mov.w	r0, #524288	; 0x80000
d00809d6:	f8df 8430 	ldr.w	r8, [pc, #1072]	; d0080e08 <main+0x440>
d00809da:	f89b 3000 	ldrb.w	r3, [fp]
d00809de:	f89b 2001 	ldrb.w	r2, [fp, #1]
d00809e2:	f89b 1002 	ldrb.w	r1, [fp, #2]
d00809e6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00809ea:	f89b 2003 	ldrb.w	r2, [fp, #3]
d00809ee:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00809f2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00809f6:	681b      	ldr	r3, [r3, #0]
d00809f8:	4798      	blx	r3
d00809fa:	f7ff fb2d 	bl	d0080058 <initMalloc>
d00809fe:	f89b 3014 	ldrb.w	r3, [fp, #20]
d0080a02:	f89b 2015 	ldrb.w	r2, [fp, #21]
d0080a06:	f44f 7000 	mov.w	r0, #512	; 0x200
d0080a0a:	f89b 1016 	ldrb.w	r1, [fp, #22]
d0080a0e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080a12:	f89b 2017 	ldrb.w	r2, [fp, #23]
d0080a16:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080a1a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080a1e:	681b      	ldr	r3, [r3, #0]
d0080a20:	681b      	ldr	r3, [r3, #0]
d0080a22:	4798      	blx	r3
d0080a24:	f89b 2014 	ldrb.w	r2, [fp, #20]
d0080a28:	f89b 3015 	ldrb.w	r3, [fp, #21]
d0080a2c:	2101      	movs	r1, #1
d0080a2e:	f89b 4016 	ldrb.w	r4, [fp, #22]
d0080a32:	ea42 2203 	orr.w	r2, r2, r3, lsl #8
d0080a36:	f89b 0017 	ldrb.w	r0, [fp, #23]
d0080a3a:	f89b 3014 	ldrb.w	r3, [fp, #20]
d0080a3e:	ea42 4204 	orr.w	r2, r2, r4, lsl #16
d0080a42:	f89b 5015 	ldrb.w	r5, [fp, #21]
d0080a46:	f89b 4016 	ldrb.w	r4, [fp, #22]
d0080a4a:	ea42 6200 	orr.w	r2, r2, r0, lsl #24
d0080a4e:	f89b 0017 	ldrb.w	r0, [fp, #23]
d0080a52:	ea43 2305 	orr.w	r3, r3, r5, lsl #8
d0080a56:	2506      	movs	r5, #6
d0080a58:	6812      	ldr	r2, [r2, #0]
d0080a5a:	ea43 4304 	orr.w	r3, r3, r4, lsl #16
d0080a5e:	6852      	ldr	r2, [r2, #4]
d0080a60:	ea43 6300 	orr.w	r3, r3, r0, lsl #24
d0080a64:	7011      	strb	r1, [r2, #0]
d0080a66:	681b      	ldr	r3, [r3, #0]
d0080a68:	68db      	ldr	r3, [r3, #12]
d0080a6a:	4798      	blx	r3
d0080a6c:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0080a70:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0080a74:	2190      	movs	r1, #144	; 0x90
d0080a76:	f89b 400e 	ldrb.w	r4, [fp, #14]
d0080a7a:	20dc      	movs	r0, #220	; 0xdc
d0080a7c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080a80:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0080a84:	ea43 4304 	orr.w	r3, r3, r4, lsl #16
d0080a88:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080a8c:	681b      	ldr	r3, [r3, #0]
d0080a8e:	691b      	ldr	r3, [r3, #16]
d0080a90:	4798      	blx	r3
d0080a92:	f89b 400c 	ldrb.w	r4, [fp, #12]
d0080a96:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0080a9a:	f44f 7320 	mov.w	r3, #640	; 0x280
d0080a9e:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0080aa2:	ea44 2402 	orr.w	r4, r4, r2, lsl #8
d0080aa6:	f89b 000f 	ldrb.w	r0, [fp, #15]
d0080aaa:	f44f 7270 	mov.w	r2, #960	; 0x3c0
d0080aae:	ea44 4401 	orr.w	r4, r4, r1, lsl #16
d0080ab2:	f44f 71a0 	mov.w	r1, #320	; 0x140
d0080ab6:	ea44 6400 	orr.w	r4, r4, r0, lsl #24
d0080aba:	f44f 70f0 	mov.w	r0, #480	; 0x1e0
d0080abe:	6824      	ldr	r4, [r4, #0]
d0080ac0:	9500      	str	r5, [sp, #0]
d0080ac2:	6964      	ldr	r4, [r4, #20]
d0080ac4:	47a0      	blx	r4
d0080ac6:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0080aca:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0080ace:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0080ad2:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080ad6:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0080ada:	4cc3      	ldr	r4, [pc, #780]	; (d0080de8 <main+0x420>)
d0080adc:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080ae0:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080ae4:	681b      	ldr	r3, [r3, #0]
d0080ae6:	6b5b      	ldr	r3, [r3, #52]	; 0x34
d0080ae8:	4798      	blx	r3
d0080aea:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0080aee:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0080af2:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0080af6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080afa:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0080afe:	6020      	str	r0, [r4, #0]
d0080b00:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080b04:	4cb9      	ldr	r4, [pc, #740]	; (d0080dec <main+0x424>)
d0080b06:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080b0a:	681b      	ldr	r3, [r3, #0]
d0080b0c:	6b9b      	ldr	r3, [r3, #56]	; 0x38
d0080b0e:	4798      	blx	r3
d0080b10:	4603      	mov	r3, r0
d0080b12:	f44f 7220 	mov.w	r2, #640	; 0x280
d0080b16:	f44f 7170 	mov.w	r1, #960	; 0x3c0
d0080b1a:	48b5      	ldr	r0, [pc, #724]	; (d0080df0 <main+0x428>)
d0080b1c:	6023      	str	r3, [r4, #0]
d0080b1e:	f7ff fa8d 	bl	d008003c <gfx_createBitmap>
d0080b22:	f04f 407f 	mov.w	r0, #4278190080	; 0xff000000
d0080b26:	f04f 417f 	mov.w	r1, #4278190080	; 0xff000000
d0080b2a:	4643      	mov	r3, r8
d0080b2c:	f508 6280 	add.w	r2, r8, #1024	; 0x400
d0080b30:	e8e3 0102 	strd	r0, r1, [r3], #8
d0080b34:	4293      	cmp	r3, r2
d0080b36:	d1fb      	bne.n	d0080b30 <main+0x168>
d0080b38:	a799      	add	r7, pc, #612	; (adr r7, d0080da0 <main+0x3d8>)
d0080b3a:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b3e:	4cad      	ldr	r4, [pc, #692]	; (d0080df4 <main+0x42c>)
d0080b40:	f10d 0e60 	add.w	lr, sp, #96	; 0x60
d0080b44:	f04f 497f 	mov.w	r9, #4278190080	; 0xff000000
d0080b48:	f8df a2c0 	ldr.w	sl, [pc, #704]	; d0080e0c <main+0x444>
d0080b4c:	f10d 0c90 	add.w	ip, sp, #144	; 0x90
d0080b50:	ad30      	add	r5, sp, #192	; 0xc0
d0080b52:	e9c8 6700 	strd	r6, r7, [r8]
d0080b56:	a794      	add	r7, pc, #592	; (adr r7, d0080da8 <main+0x3e0>)
d0080b58:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b5c:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
d0080b5e:	e9c8 6702 	strd	r6, r7, [r8, #8]
d0080b62:	a793      	add	r7, pc, #588	; (adr r7, d0080db0 <main+0x3e8>)
d0080b64:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b68:	e8ae 000f 	stmia.w	lr!, {r0, r1, r2, r3}
d0080b6c:	e9c8 6704 	strd	r6, r7, [r8, #16]
d0080b70:	a791      	add	r7, pc, #580	; (adr r7, d0080db8 <main+0x3f0>)
d0080b72:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b76:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
d0080b78:	e9c8 6706 	strd	r6, r7, [r8, #24]
d0080b7c:	a790      	add	r7, pc, #576	; (adr r7, d0080dc0 <main+0x3f8>)
d0080b7e:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b82:	e8ae 000f 	stmia.w	lr!, {r0, r1, r2, r3}
d0080b86:	e9c8 6708 	strd	r6, r7, [r8, #32]
d0080b8a:	a78f      	add	r7, pc, #572	; (adr r7, d0080dc8 <main+0x400>)
d0080b8c:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b90:	e894 000f 	ldmia.w	r4, {r0, r1, r2, r3}
d0080b94:	e9c8 670a 	strd	r6, r7, [r8, #40]	; 0x28
d0080b98:	a78d      	add	r7, pc, #564	; (adr r7, d0080dd0 <main+0x408>)
d0080b9a:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080b9e:	e9c8 9a12 	strd	r9, sl, [r8, #72]	; 0x48
d0080ba2:	e9c8 670c 	strd	r6, r7, [r8, #48]	; 0x30
d0080ba6:	a78c      	add	r7, pc, #560	; (adr r7, d0080dd8 <main+0x410>)
d0080ba8:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080bac:	f104 0910 	add.w	r9, r4, #16
d0080bb0:	3440      	adds	r4, #64	; 0x40
d0080bb2:	e9c8 670e 	strd	r6, r7, [r8, #56]	; 0x38
d0080bb6:	a78a      	add	r7, pc, #552	; (adr r7, d0080de0 <main+0x418>)
d0080bb8:	e9d7 6700 	ldrd	r6, r7, [r7]
d0080bbc:	e9c8 6710 	strd	r6, r7, [r8, #64]	; 0x40
d0080bc0:	e88e 000f 	stmia.w	lr, {r0, r1, r2, r3}
d0080bc4:	e8b9 000f 	ldmia.w	r9!, {r0, r1, r2, r3}
d0080bc8:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
d0080bcc:	e8b9 000f 	ldmia.w	r9!, {r0, r1, r2, r3}
d0080bd0:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
d0080bd4:	e899 000f 	ldmia.w	r9, {r0, r1, r2, r3}
d0080bd8:	e88c 000f 	stmia.w	ip, {r0, r1, r2, r3}
d0080bdc:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
d0080bde:	2600      	movs	r6, #0
d0080be0:	f8df e22c 	ldr.w	lr, [pc, #556]	; d0080e10 <main+0x448>
d0080be4:	c50f      	stmia	r5!, {r0, r1, r2, r3}
d0080be6:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
d0080be8:	9603      	str	r6, [sp, #12]
d0080bea:	ae18      	add	r6, sp, #96	; 0x60
d0080bec:	46f2      	mov	sl, lr
d0080bee:	9608      	str	r6, [sp, #32]
d0080bf0:	ae24      	add	r6, sp, #144	; 0x90
d0080bf2:	c50f      	stmia	r5!, {r0, r1, r2, r3}
d0080bf4:	e894 000f 	ldmia.w	r4, {r0, r1, r2, r3}
d0080bf8:	e885 000f 	stmia.w	r5, {r0, r1, r2, r3}
d0080bfc:	4b7e      	ldr	r3, [pc, #504]	; (d0080df8 <main+0x430>)
d0080bfe:	9607      	str	r6, [sp, #28]
d0080c00:	ae30      	add	r6, sp, #192	; 0xc0
d0080c02:	930f      	str	r3, [sp, #60]	; 0x3c
d0080c04:	4b7d      	ldr	r3, [pc, #500]	; (d0080dfc <main+0x434>)
d0080c06:	9609      	str	r6, [sp, #36]	; 0x24
d0080c08:	930a      	str	r3, [sp, #40]	; 0x28
d0080c0a:	9b07      	ldr	r3, [sp, #28]
d0080c0c:	9a03      	ldr	r2, [sp, #12]
d0080c0e:	8819      	ldrh	r1, [r3, #0]
d0080c10:	9205      	str	r2, [sp, #20]
d0080c12:	885a      	ldrh	r2, [r3, #2]
d0080c14:	ebc1 2541 	rsb	r5, r1, r1, lsl #9
d0080c18:	889b      	ldrh	r3, [r3, #4]
d0080c1a:	9f08      	ldr	r7, [sp, #32]
d0080c1c:	ebc2 2442 	rsb	r4, r2, r2, lsl #9
d0080c20:	ebc3 2043 	rsb	r0, r3, r3, lsl #9
d0080c24:	f8dd 9028 	ldr.w	r9, [sp, #40]	; 0x28
d0080c28:	f8b7 c000 	ldrh.w	ip, [r7]
d0080c2c:	eb02 0484 	add.w	r4, r2, r4, lsl #2
d0080c30:	887e      	ldrh	r6, [r7, #2]
d0080c32:	eb03 0080 	add.w	r0, r3, r0, lsl #2
d0080c36:	f8b7 8004 	ldrh.w	r8, [r7, #4]
d0080c3a:	eb01 0585 	add.w	r5, r1, r5, lsl #2
d0080c3e:	9f09      	ldr	r7, [sp, #36]	; 0x24
d0080c40:	ebc3 00c0 	rsb	r0, r3, r0, lsl #3
d0080c44:	9404      	str	r4, [sp, #16]
d0080c46:	eb03 0383 	add.w	r3, r3, r3, lsl #2
d0080c4a:	883c      	ldrh	r4, [r7, #0]
d0080c4c:	ebc1 05c5 	rsb	r5, r1, r5, lsl #3
d0080c50:	f8b7 e002 	ldrh.w	lr, [r7, #2]
d0080c54:	eb0c 0c8c 	add.w	ip, ip, ip, lsl #2
d0080c58:	940b      	str	r4, [sp, #44]	; 0x2c
d0080c5a:	eb08 0888 	add.w	r8, r8, r8, lsl #2
d0080c5e:	9c03      	ldr	r4, [sp, #12]
d0080c60:	eb03 0383 	add.w	r3, r3, r3, lsl #2
d0080c64:	f8cd e030 	str.w	lr, [sp, #48]	; 0x30
d0080c68:	eb0c 0c8c 	add.w	ip, ip, ip, lsl #2
d0080c6c:	f8b7 e004 	ldrh.w	lr, [r7, #4]
d0080c70:	eb01 0181 	add.w	r1, r1, r1, lsl #2
d0080c74:	9f0b      	ldr	r7, [sp, #44]	; 0x2c
d0080c76:	eb06 0686 	add.w	r6, r6, r6, lsl #2
d0080c7a:	f8cd e034 	str.w	lr, [sp, #52]	; 0x34
d0080c7e:	f104 0e19 	add.w	lr, r4, #25
d0080c82:	9c04      	ldr	r4, [sp, #16]
d0080c84:	00ad      	lsls	r5, r5, #2
d0080c86:	f8cd e058 	str.w	lr, [sp, #88]	; 0x58
d0080c8a:	0080      	lsls	r0, r0, #2
d0080c8c:	ebc2 04c4 	rsb	r4, r2, r4, lsl #3
d0080c90:	ebc7 3ec7 	rsb	lr, r7, r7, lsl #15
d0080c94:	9f0c      	ldr	r7, [sp, #48]	; 0x30
d0080c96:	eb02 0282 	add.w	r2, r2, r2, lsl #2
d0080c9a:	eb08 0888 	add.w	r8, r8, r8, lsl #2
d0080c9e:	005b      	lsls	r3, r3, #1
d0080ca0:	eb06 0686 	add.w	r6, r6, r6, lsl #2
d0080ca4:	eb05 058c 	add.w	r5, r5, ip, lsl #2
d0080ca8:	b29b      	uxth	r3, r3
d0080caa:	ebc7 3cc7 	rsb	ip, r7, r7, lsl #15
d0080cae:	9f0d      	ldr	r7, [sp, #52]	; 0x34
d0080cb0:	eb01 0181 	add.w	r1, r1, r1, lsl #2
d0080cb4:	9313      	str	r3, [sp, #76]	; 0x4c
d0080cb6:	00a4      	lsls	r4, r4, #2
d0080cb8:	eb02 0282 	add.w	r2, r2, r2, lsl #2
d0080cbc:	eb00 0088 	add.w	r0, r0, r8, lsl #2
d0080cc0:	eb04 0486 	add.w	r4, r4, r6, lsl #2
d0080cc4:	b283      	uxth	r3, r0
d0080cc6:	ebc7 36c7 	rsb	r6, r7, r7, lsl #15
d0080cca:	464f      	mov	r7, r9
d0080ccc:	0049      	lsls	r1, r1, #1
d0080cce:	9312      	str	r3, [sp, #72]	; 0x48
d0080cd0:	0052      	lsls	r2, r2, #1
d0080cd2:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
d0080cd6:	b289      	uxth	r1, r1
d0080cd8:	b292      	uxth	r2, r2
d0080cda:	fa1f f38c 	uxth.w	r3, ip
d0080cde:	9115      	str	r1, [sp, #84]	; 0x54
d0080ce0:	0076      	lsls	r6, r6, #1
d0080ce2:	9214      	str	r2, [sp, #80]	; 0x50
d0080ce4:	9306      	str	r3, [sp, #24]
d0080ce6:	b2a2      	uxth	r2, r4
d0080ce8:	b2b3      	uxth	r3, r6
d0080cea:	ea4f 0e4e 	mov.w	lr, lr, lsl #1
d0080cee:	9211      	str	r2, [sp, #68]	; 0x44
d0080cf0:	b2a9      	uxth	r1, r5
d0080cf2:	fa1f fe8e 	uxth.w	lr, lr
d0080cf6:	9110      	str	r1, [sp, #64]	; 0x40
d0080cf8:	9304      	str	r3, [sp, #16]
d0080cfa:	9b06      	ldr	r3, [sp, #24]
d0080cfc:	9c05      	ldr	r4, [sp, #20]
d0080cfe:	f8cd a05c 	str.w	sl, [sp, #92]	; 0x5c
d0080d02:	f107 0028 	add.w	r0, r7, #40	; 0x28
d0080d06:	eb0e 018e 	add.w	r1, lr, lr, lsl #2
d0080d0a:	eb03 0283 	add.w	r2, r3, r3, lsl #2
d0080d0e:	9b04      	ldr	r3, [sp, #16]
d0080d10:	eb01 0181 	add.w	r1, r1, r1, lsl #2
d0080d14:	900e      	str	r0, [sp, #56]	; 0x38
d0080d16:	9810      	ldr	r0, [sp, #64]	; 0x40
d0080d18:	eb03 0383 	add.w	r3, r3, r3, lsl #2
d0080d1c:	eb02 0282 	add.w	r2, r2, r2, lsl #2
d0080d20:	eb00 0141 	add.w	r1, r0, r1, lsl #1
d0080d24:	9811      	ldr	r0, [sp, #68]	; 0x44
d0080d26:	eb03 0383 	add.w	r3, r3, r3, lsl #2
d0080d2a:	eb00 0242 	add.w	r2, r0, r2, lsl #1
d0080d2e:	9812      	ldr	r0, [sp, #72]	; 0x48
d0080d30:	b289      	uxth	r1, r1
d0080d32:	eb00 0343 	add.w	r3, r0, r3, lsl #1
d0080d36:	4832      	ldr	r0, [pc, #200]	; (d0080e00 <main+0x438>)
d0080d38:	b292      	uxth	r2, r2
d0080d3a:	b29b      	uxth	r3, r3
d0080d3c:	eb00 0cc4 	add.w	ip, r0, r4, lsl #3
d0080d40:	b214      	sxth	r4, r2
d0080d42:	f04f 0000 	mov.w	r0, #0
d0080d46:	b20d      	sxth	r5, r1
d0080d48:	f04f 4680 	mov.w	r6, #1073741824	; 0x40000000
d0080d4c:	fb04 f804 	mul.w	r8, r4, r4
d0080d50:	80f8      	strh	r0, [r7, #6]
d0080d52:	b218      	sxth	r0, r3
d0080d54:	fb05 8805 	mla	r8, r5, r5, r8
d0080d58:	807c      	strh	r4, [r7, #2]
d0080d5a:	fb00 8800 	mla	r8, r0, r0, r8
d0080d5e:	803d      	strh	r5, [r7, #0]
d0080d60:	f1b8 4f80 	cmp.w	r8, #1073741824	; 0x40000000
d0080d64:	80b8      	strh	r0, [r7, #4]
d0080d66:	d204      	bcs.n	d0080d72 <main+0x3aa>
d0080d68:	08b6      	lsrs	r6, r6, #2
d0080d6a:	45b0      	cmp	r8, r6
d0080d6c:	d3fc      	bcc.n	d0080d68 <main+0x3a0>
d0080d6e:	2e00      	cmp	r6, #0
d0080d70:	d050      	beq.n	d0080e14 <main+0x44c>
d0080d72:	f04f 0900 	mov.w	r9, #0
d0080d76:	e005      	b.n	d0080d84 <main+0x3bc>
d0080d78:	eb06 0959 	add.w	r9, r6, r9, lsr #1
d0080d7c:	eba8 080a 	sub.w	r8, r8, sl
d0080d80:	08b6      	lsrs	r6, r6, #2
d0080d82:	d007      	beq.n	d0080d94 <main+0x3cc>
d0080d84:	eb06 0a09 	add.w	sl, r6, r9
d0080d88:	45c2      	cmp	sl, r8
d0080d8a:	d9f5      	bls.n	d0080d78 <main+0x3b0>
d0080d8c:	08b6      	lsrs	r6, r6, #2
d0080d8e:	ea4f 0959 	mov.w	r9, r9, lsr #1
d0080d92:	d1f7      	bne.n	d0080d84 <main+0x3bc>
d0080d94:	464e      	mov	r6, r9
d0080d96:	2e01      	cmp	r6, #1
d0080d98:	bf38      	it	cc
d0080d9a:	2601      	movcc	r6, #1
d0080d9c:	e03b      	b.n	d0080e16 <main+0x44e>
d0080d9e:	bf00      	nop
d0080da0:	00000000 	.word	0x00000000
d0080da4:	8f245dff 	.word	0x8f245dff
d0080da8:	8f24e06f 	.word	0x8f24e06f
d0080dac:	8fff3d52 	.word	0x8fff3d52
d0080db0:	8fb24bff 	.word	0x8fb24bff
d0080db4:	8ffff040 	.word	0x8ffff040
d0080db8:	8fff9a24 	.word	0x8fff9a24
d0080dbc:	6f102c88 	.word	0x6f102c88
d0080dc0:	6f08763f 	.word	0x6f08763f
d0080dc4:	6f8d1723 	.word	0x6f8d1723
d0080dc8:	6f5a257f 	.word	0x6f5a257f
d0080dcc:	6f8f8420 	.word	0x6f8f8420
d0080dd0:	6f9a5412 	.word	0x6f9a5412
d0080dd4:	5f15315a 	.word	0x5f15315a
d0080dd8:	5fb7c7d9 	.word	0x5fb7c7d9
d0080ddc:	5f07101f 	.word	0x5f07101f
d0080de0:	5fff3348 	.word	0x5fff3348
d0080de4:	ffffffff 	.word	0xffffffff
d0080de8:	d00886c0 	.word	0xd00886c0
d0080dec:	d00886e0 	.word	0xd00886e0
d0080df0:	d00877e0 	.word	0xd00877e0
d0080df4:	d0082ba0 	.word	0xd0082ba0
d0080df8:	d0082c30 	.word	0xd0082c30
d0080dfc:	d0087804 	.word	0xd0087804
d0080e00:	d0089050 	.word	0xd0089050
d0080e04:	2001f000 	.word	0x2001f000
d0080e08:	d0087cc0 	.word	0xd0087cc0
d0080e0c:	6f000147 	.word	0x6f000147
d0080e10:	d00880c0 	.word	0xd00880c0
d0080e14:	2601      	movs	r6, #1
d0080e16:	eb05 0885 	add.w	r8, r5, r5, lsl #2
d0080e1a:	9d15      	ldr	r5, [sp, #84]	; 0x54
d0080e1c:	eb04 0484 	add.w	r4, r4, r4, lsl #2
d0080e20:	3708      	adds	r7, #8
d0080e22:	4429      	add	r1, r5
d0080e24:	9d14      	ldr	r5, [sp, #80]	; 0x50
d0080e26:	eb00 0080 	add.w	r0, r0, r0, lsl #2
d0080e2a:	f10c 0c08 	add.w	ip, ip, #8
d0080e2e:	442a      	add	r2, r5
d0080e30:	9d13      	ldr	r5, [sp, #76]	; 0x4c
d0080e32:	eb04 0484 	add.w	r4, r4, r4, lsl #2
d0080e36:	442b      	add	r3, r5
d0080e38:	eb00 0080 	add.w	r0, r0, r0, lsl #2
d0080e3c:	eb08 0588 	add.w	r5, r8, r8, lsl #2
d0080e40:	f04f 0800 	mov.w	r8, #0
d0080e44:	0080      	lsls	r0, r0, #2
d0080e46:	00ad      	lsls	r5, r5, #2
d0080e48:	f82c 8c02 	strh.w	r8, [ip, #-2]
d0080e4c:	00a4      	lsls	r4, r4, #2
d0080e4e:	b289      	uxth	r1, r1
d0080e50:	b292      	uxth	r2, r2
d0080e52:	b29b      	uxth	r3, r3
d0080e54:	fb95 f5f6 	sdiv	r5, r5, r6
d0080e58:	fb94 f4f6 	sdiv	r4, r4, r6
d0080e5c:	fb90 f6f6 	sdiv	r6, r0, r6
d0080e60:	980e      	ldr	r0, [sp, #56]	; 0x38
d0080e62:	f82c 5c08 	strh.w	r5, [ip, #-8]
d0080e66:	42b8      	cmp	r0, r7
d0080e68:	f82c 4c06 	strh.w	r4, [ip, #-6]
d0080e6c:	f82c 6c04 	strh.w	r6, [ip, #-4]
d0080e70:	f47f af66 	bne.w	d0080d40 <main+0x378>
d0080e74:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d0080e76:	990c      	ldr	r1, [sp, #48]	; 0x30
d0080e78:	449e      	add	lr, r3
d0080e7a:	9b06      	ldr	r3, [sp, #24]
d0080e7c:	440b      	add	r3, r1
d0080e7e:	990d      	ldr	r1, [sp, #52]	; 0x34
d0080e80:	fa1f fe8e 	uxth.w	lr, lr
d0080e84:	461a      	mov	r2, r3
d0080e86:	9b04      	ldr	r3, [sp, #16]
d0080e88:	440b      	add	r3, r1
d0080e8a:	9905      	ldr	r1, [sp, #20]
d0080e8c:	b292      	uxth	r2, r2
d0080e8e:	b29b      	uxth	r3, r3
d0080e90:	3105      	adds	r1, #5
d0080e92:	9206      	str	r2, [sp, #24]
d0080e94:	9304      	str	r3, [sp, #16]
d0080e96:	9b16      	ldr	r3, [sp, #88]	; 0x58
d0080e98:	9105      	str	r1, [sp, #20]
d0080e9a:	4299      	cmp	r1, r3
d0080e9c:	d003      	beq.n	d0080ea6 <main+0x4de>
d0080e9e:	4607      	mov	r7, r0
d0080ea0:	4613      	mov	r3, r2
d0080ea2:	460c      	mov	r4, r1
d0080ea4:	e72d      	b.n	d0080d02 <main+0x33a>
d0080ea6:	9b0f      	ldr	r3, [sp, #60]	; 0x3c
d0080ea8:	9a03      	ldr	r2, [sp, #12]
d0080eaa:	f813 1b01 	ldrb.w	r1, [r3], #1
d0080eae:	b214      	sxth	r4, r2
d0080eb0:	f8dd a05c 	ldr.w	sl, [sp, #92]	; 0x5c
d0080eb4:	930f      	str	r3, [sp, #60]	; 0x3c
d0080eb6:	b293      	uxth	r3, r2
d0080eb8:	9a08      	ldr	r2, [sp, #32]
d0080eba:	f103 0905 	add.w	r9, r3, #5
d0080ebe:	1c58      	adds	r0, r3, #1
d0080ec0:	3208      	adds	r2, #8
d0080ec2:	1d9f      	adds	r7, r3, #6
d0080ec4:	b200      	sxth	r0, r0
d0080ec6:	f103 0e03 	add.w	lr, r3, #3
d0080eca:	9208      	str	r2, [sp, #32]
d0080ecc:	1d8a      	adds	r2, r1, #6
d0080ece:	f8aa 0002 	strh.w	r0, [sl, #2]
d0080ed2:	b23f      	sxth	r7, r7
d0080ed4:	b2d2      	uxtb	r2, r2
d0080ed6:	f8aa 0010 	strh.w	r0, [sl, #16]
d0080eda:	f8aa 0018 	strh.w	r0, [sl, #24]
d0080ede:	f103 000d 	add.w	r0, r3, #13
d0080ee2:	9203      	str	r2, [sp, #12]
d0080ee4:	fa0f fe8e 	sxth.w	lr, lr
d0080ee8:	9a07      	ldr	r2, [sp, #28]
d0080eea:	b200      	sxth	r0, r0
d0080eec:	f8aa 4000 	strh.w	r4, [sl]
d0080ef0:	f103 0802 	add.w	r8, r3, #2
d0080ef4:	3208      	adds	r2, #8
d0080ef6:	9004      	str	r0, [sp, #16]
d0080ef8:	f103 000e 	add.w	r0, r3, #14
d0080efc:	f8aa 4008 	strh.w	r4, [sl, #8]
d0080f00:	9207      	str	r2, [sp, #28]
d0080f02:	1dde      	adds	r6, r3, #7
d0080f04:	9a09      	ldr	r2, [sp, #36]	; 0x24
d0080f06:	b200      	sxth	r0, r0
d0080f08:	f8aa 7004 	strh.w	r7, [sl, #4]
d0080f0c:	f103 0508 	add.w	r5, r3, #8
d0080f10:	3208      	adds	r2, #8
d0080f12:	f8aa 700a 	strh.w	r7, [sl, #10]
d0080f16:	f88a 1006 	strb.w	r1, [sl, #6]
d0080f1a:	f103 0c09 	add.w	ip, r3, #9
d0080f1e:	9209      	str	r2, [sp, #36]	; 0x24
d0080f20:	fa0f f289 	sxth.w	r2, r9
d0080f24:	f88a 100e 	strb.w	r1, [sl, #14]
d0080f28:	b236      	sxth	r6, r6
d0080f2a:	920b      	str	r2, [sp, #44]	; 0x2c
d0080f2c:	b22d      	sxth	r5, r5
d0080f2e:	9a0a      	ldr	r2, [sp, #40]	; 0x28
d0080f30:	fa0f f888 	sxth.w	r8, r8
d0080f34:	f88a 1026 	strb.w	r1, [sl, #38]	; 0x26
d0080f38:	fa0f fc8c 	sxth.w	ip, ip
d0080f3c:	32c8      	adds	r2, #200	; 0xc8
d0080f3e:	f88a 102e 	strb.w	r1, [sl, #46]	; 0x2e
d0080f42:	f103 090b 	add.w	r9, r3, #11
d0080f46:	f103 040c 	add.w	r4, r3, #12
d0080f4a:	920a      	str	r2, [sp, #40]	; 0x28
d0080f4c:	f50a 7a80 	add.w	sl, sl, #256	; 0x100
d0080f50:	9a03      	ldr	r2, [sp, #12]
d0080f52:	fa0f f989 	sxth.w	r9, r9
d0080f56:	b224      	sxth	r4, r4
d0080f58:	f80a 2cea 	strb.w	r2, [sl, #-234]
d0080f5c:	f80a 2ce2 	strb.w	r2, [sl, #-226]
d0080f60:	f80a 2cca 	strb.w	r2, [sl, #-202]
d0080f64:	f103 020a 	add.w	r2, r3, #10
d0080f68:	b212      	sxth	r2, r2
d0080f6a:	920c      	str	r2, [sp, #48]	; 0x30
d0080f6c:	f82a 7ce4 	strh.w	r7, [sl, #-228]
d0080f70:	9a0b      	ldr	r2, [sp, #44]	; 0x2c
d0080f72:	f82a ecde 	strh.w	lr, [sl, #-222]
d0080f76:	f82a ecd0 	strh.w	lr, [sl, #-208]
d0080f7a:	f82a ecc8 	strh.w	lr, [sl, #-200]
d0080f7e:	f103 0e04 	add.w	lr, r3, #4
d0080f82:	f82a 2cf4 	strh.w	r2, [sl, #-244]
d0080f86:	f82a ecce 	strh.w	lr, [sl, #-206]
d0080f8a:	f103 0e0f 	add.w	lr, r3, #15
d0080f8e:	9a03      	ldr	r2, [sp, #12]
d0080f90:	9006      	str	r0, [sp, #24]
d0080f92:	fa0f fe8e 	sxth.w	lr, lr
d0080f96:	9803      	ldr	r0, [sp, #12]
d0080f98:	f80a 2cba 	strb.w	r2, [sl, #-186]
d0080f9c:	f80a 0cc2 	strb.w	r0, [sl, #-194]
d0080fa0:	9a03      	ldr	r2, [sp, #12]
d0080fa2:	980b      	ldr	r0, [sp, #44]	; 0x2c
d0080fa4:	f82a 8cee 	strh.w	r8, [sl, #-238]
d0080fa8:	f82a 8ce0 	strh.w	r8, [sl, #-224]
d0080fac:	f82a 8cd8 	strh.w	r8, [sl, #-216]
d0080fb0:	f103 0810 	add.w	r8, r3, #16
d0080fb4:	f82a 6cec 	strh.w	r6, [sl, #-236]
d0080fb8:	f82a 6ce6 	strh.w	r6, [sl, #-230]
d0080fbc:	fa0f f888 	sxth.w	r8, r8
d0080fc0:	f82a 6cd4 	strh.w	r6, [sl, #-212]
d0080fc4:	f82a 5cdc 	strh.w	r5, [sl, #-220]
d0080fc8:	f82a 5cd6 	strh.w	r5, [sl, #-214]
d0080fcc:	f82a 5cc4 	strh.w	r5, [sl, #-196]
d0080fd0:	f82a cccc 	strh.w	ip, [sl, #-204]
d0080fd4:	f82a ccc6 	strh.w	ip, [sl, #-198]
d0080fd8:	f82a cc8e 	strh.w	ip, [sl, #-142]
d0080fdc:	f103 0c11 	add.w	ip, r3, #17
d0080fe0:	f82a 0cc0 	strh.w	r0, [sl, #-192]
d0080fe4:	f82a 7cbe 	strh.w	r7, [sl, #-190]
d0080fe8:	fa0f fc8c 	sxth.w	ip, ip
d0080fec:	f82a 0cb8 	strh.w	r0, [sl, #-184]
d0080ff0:	f80a 2cb2 	strb.w	r2, [sl, #-178]
d0080ff4:	f82a 7cb0 	strh.w	r7, [sl, #-176]
d0080ff8:	f82a 6cae 	strh.w	r6, [sl, #-174]
d0080ffc:	f8cd e034 	str.w	lr, [sp, #52]	; 0x34
d0081000:	f103 0e15 	add.w	lr, r3, #21
d0081004:	f82a 7ca8 	strh.w	r7, [sl, #-168]
d0081008:	f103 0712 	add.w	r7, r3, #18
d008100c:	f82a 5c9e 	strh.w	r5, [sl, #-158]
d0081010:	fa0f fe8e 	sxth.w	lr, lr
d0081014:	f82a 5c90 	strh.w	r5, [sl, #-144]
d0081018:	b23f      	sxth	r7, r7
d008101a:	f82a 5c88 	strh.w	r5, [sl, #-136]
d008101e:	f103 0516 	add.w	r5, r3, #22
d0081022:	9806      	ldr	r0, [sp, #24]
d0081024:	b22d      	sxth	r5, r5
d0081026:	f80a 2c9a 	strb.w	r2, [sl, #-154]
d008102a:	f80a 2c92 	strb.w	r2, [sl, #-146]
d008102e:	950b      	str	r5, [sp, #44]	; 0x2c
d0081030:	9a0c      	ldr	r2, [sp, #48]	; 0x30
d0081032:	9d04      	ldr	r5, [sp, #16]
d0081034:	f82a 6ca0 	strh.w	r6, [sl, #-160]
d0081038:	f82a 6c98 	strh.w	r6, [sl, #-152]
d008103c:	f103 0613 	add.w	r6, r3, #19
d0081040:	f82a 9cbc 	strh.w	r9, [sl, #-188]
d0081044:	f82a 9cb6 	strh.w	r9, [sl, #-182]
d0081048:	b236      	sxth	r6, r6
d008104a:	f82a 9ca4 	strh.w	r9, [sl, #-164]
d008104e:	f82a 4cac 	strh.w	r4, [sl, #-172]
d0081052:	f82a 4ca6 	strh.w	r4, [sl, #-166]
d0081056:	f82a 4c94 	strh.w	r4, [sl, #-148]
d008105a:	f82a 5c9c 	strh.w	r5, [sl, #-156]
d008105e:	f82a 5c96 	strh.w	r5, [sl, #-150]
d0081062:	f82a 5c84 	strh.w	r5, [sl, #-132]
d0081066:	f82a 0c8c 	strh.w	r0, [sl, #-140]
d008106a:	f82a 0c86 	strh.w	r0, [sl, #-134]
d008106e:	f82a 9c7e 	strh.w	r9, [sl, #-126]
d0081072:	f82a 9c70 	strh.w	r9, [sl, #-112]
d0081076:	f82a 4c6e 	strh.w	r4, [sl, #-110]
d008107a:	f80a 1caa 	strb.w	r1, [sl, #-170]
d008107e:	f80a 1ca2 	strb.w	r1, [sl, #-162]
d0081082:	f80a 1c8a 	strb.w	r1, [sl, #-138]
d0081086:	f80a 1c82 	strb.w	r1, [sl, #-130]
d008108a:	f82a 2cb4 	strh.w	r2, [sl, #-180]
d008108e:	f82a 2c80 	strh.w	r2, [sl, #-128]
d0081092:	f82a 2c78 	strh.w	r2, [sl, #-120]
d0081096:	9a03      	ldr	r2, [sp, #12]
d0081098:	9804      	ldr	r0, [sp, #16]
d008109a:	4615      	mov	r5, r2
d008109c:	f80a 2c6a 	strb.w	r2, [sl, #-106]
d00810a0:	f82a 0c5e 	strh.w	r0, [sl, #-94]
d00810a4:	f82a 0c50 	strh.w	r0, [sl, #-80]
d00810a8:	9806      	ldr	r0, [sp, #24]
d00810aa:	f82a 9c68 	strh.w	r9, [sl, #-104]
d00810ae:	f103 0917 	add.w	r9, r3, #23
d00810b2:	f80a 2c62 	strb.w	r2, [sl, #-98]
d00810b6:	f82a 4c60 	strh.w	r4, [sl, #-96]
d00810ba:	fa0f f989 	sxth.w	r9, r9
d00810be:	f82a 4c58 	strh.w	r4, [sl, #-88]
d00810c2:	f103 0418 	add.w	r4, r3, #24
d00810c6:	f82a 0c4e 	strh.w	r0, [sl, #-78]
d00810ca:	3314      	adds	r3, #20
d00810cc:	f80a 2c4a 	strb.w	r2, [sl, #-74]
d00810d0:	b224      	sxth	r4, r4
d00810d2:	f80a 2c42 	strb.w	r2, [sl, #-66]
d00810d6:	9804      	ldr	r0, [sp, #16]
d00810d8:	9a0d      	ldr	r2, [sp, #52]	; 0x34
d00810da:	f82a 0c48 	strh.w	r0, [sl, #-72]
d00810de:	f82a 2c74 	strh.w	r2, [sl, #-116]
d00810e2:	f82a 2c40 	strh.w	r2, [sl, #-64]
d00810e6:	f80a 1c7a 	strb.w	r1, [sl, #-122]
d00810ea:	f80a 1c72 	strb.w	r1, [sl, #-114]
d00810ee:	f80a 1c5a 	strb.w	r1, [sl, #-90]
d00810f2:	f80a 1c52 	strb.w	r1, [sl, #-82]
d00810f6:	f82a 8c7c 	strh.w	r8, [sl, #-124]
d00810fa:	f82a 8c76 	strh.w	r8, [sl, #-118]
d00810fe:	f82a 8c64 	strh.w	r8, [sl, #-100]
d0081102:	f82a cc6c 	strh.w	ip, [sl, #-108]
d0081106:	f82a cc66 	strh.w	ip, [sl, #-102]
d008110a:	f82a cc54 	strh.w	ip, [sl, #-84]
d008110e:	f82a 7c5c 	strh.w	r7, [sl, #-92]
d0081112:	f82a 7c56 	strh.w	r7, [sl, #-86]
d0081116:	f82a 7c44 	strh.w	r7, [sl, #-68]
d008111a:	f82a 6c4c 	strh.w	r6, [sl, #-76]
d008111e:	f82a 6c46 	strh.w	r6, [sl, #-70]
d0081122:	f82a 2c38 	strh.w	r2, [sl, #-56]
d0081126:	9a0b      	ldr	r2, [sp, #44]	; 0x2c
d0081128:	f82a 8c3e 	strh.w	r8, [sl, #-62]
d008112c:	f80a 5c3a 	strb.w	r5, [sl, #-58]
d0081130:	f80a 5c32 	strb.w	r5, [sl, #-50]
d0081134:	f82a 8c30 	strh.w	r8, [sl, #-48]
d0081138:	f82a cc2e 	strh.w	ip, [sl, #-46]
d008113c:	f82a 8c28 	strh.w	r8, [sl, #-40]
d0081140:	f82a cc20 	strh.w	ip, [sl, #-32]
d0081144:	f82a 7c1e 	strh.w	r7, [sl, #-30]
d0081148:	f80a 5c1a 	strb.w	r5, [sl, #-26]
d008114c:	f82a cc18 	strh.w	ip, [sl, #-24]
d0081150:	f80a 5c12 	strb.w	r5, [sl, #-18]
d0081154:	f82a 7c10 	strh.w	r7, [sl, #-16]
d0081158:	f82a 6c0e 	strh.w	r6, [sl, #-14]
d008115c:	f82a 7c08 	strh.w	r7, [sl, #-8]
d0081160:	f80a 1c2a 	strb.w	r1, [sl, #-42]
d0081164:	f80a 1c22 	strb.w	r1, [sl, #-34]
d0081168:	f80a 1c0a 	strb.w	r1, [sl, #-10]
d008116c:	f80a 1c02 	strb.w	r1, [sl, #-2]
d0081170:	f82a ec3c 	strh.w	lr, [sl, #-60]
d0081174:	f82a ec36 	strh.w	lr, [sl, #-54]
d0081178:	f82a ec24 	strh.w	lr, [sl, #-36]
d008117c:	f82a 2c2c 	strh.w	r2, [sl, #-44]
d0081180:	f82a 2c26 	strh.w	r2, [sl, #-38]
d0081184:	f82a 2c14 	strh.w	r2, [sl, #-20]
d0081188:	f82a 9c1c 	strh.w	r9, [sl, #-28]
d008118c:	f82a 9c16 	strh.w	r9, [sl, #-22]
d0081190:	f82a 9c04 	strh.w	r9, [sl, #-4]
d0081194:	f82a 4c0c 	strh.w	r4, [sl, #-12]
d0081198:	f82a 4c06 	strh.w	r4, [sl, #-6]
d008119c:	f82a 3c34 	strh.w	r3, [sl, #-52]
d00811a0:	9b05      	ldr	r3, [sp, #20]
d00811a2:	2b96      	cmp	r3, #150	; 0x96
d00811a4:	d001      	beq.n	d00811aa <main+0x7e2>
d00811a6:	9303      	str	r3, [sp, #12]
d00811a8:	e52f      	b.n	d0080c0a <main+0x242>
d00811aa:	4901      	ldr	r1, [pc, #4]	; (d00811b0 <main+0x7e8>)
d00811ac:	2300      	movs	r3, #0
d00811ae:	e004      	b.n	d00811ba <main+0x7f2>
d00811b0:	d0082c39 	.word	0xd0082c39
d00811b4:	2a0a      	cmp	r2, #10
d00811b6:	bf08      	it	eq
d00811b8:	3301      	addeq	r3, #1
d00811ba:	f811 2f01 	ldrb.w	r2, [r1, #1]!
d00811be:	2a00      	cmp	r2, #0
d00811c0:	d1f8      	bne.n	d00811b4 <main+0x7ec>
d00811c2:	f89b 4014 	ldrb.w	r4, [fp, #20]
d00811c6:	f103 0514 	add.w	r5, r3, #20
d00811ca:	f89b 0015 	ldrb.w	r0, [fp, #21]
d00811ce:	f644 0150 	movw	r1, #18512	; 0x4850
d00811d2:	f89b 2016 	ldrb.w	r2, [fp, #22]
d00811d6:	012d      	lsls	r5, r5, #4
d00811d8:	ea44 2000 	orr.w	r0, r4, r0, lsl #8
d00811dc:	f89b 3017 	ldrb.w	r3, [fp, #23]
d00811e0:	f06f 0409 	mvn.w	r4, #9
d00811e4:	f46f 7ac5 	mvn.w	sl, #394	; 0x18a
d00811e8:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d00811ec:	48ad      	ldr	r0, [pc, #692]	; (d00814a4 <main+0xadc>)
d00811ee:	9404      	str	r4, [sp, #16]
d00811f0:	f244 59ab 	movw	r9, #17835	; 0x45ab
d00811f4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00811f8:	4cab      	ldr	r4, [pc, #684]	; (d00814a8 <main+0xae0>)
d00811fa:	4fac      	ldr	r7, [pc, #688]	; (d00814ac <main+0xae4>)
d00811fc:	f646 382f 	movw	r8, #27439	; 0x6b2f
d0081200:	685b      	ldr	r3, [r3, #4]
d0081202:	6025      	str	r5, [r4, #0]
d0081204:	689b      	ldr	r3, [r3, #8]
d0081206:	4798      	blx	r3
d0081208:	f89b 3014 	ldrb.w	r3, [fp, #20]
d008120c:	49a8      	ldr	r1, [pc, #672]	; (d00814b0 <main+0xae8>)
d008120e:	f89b 2015 	ldrb.w	r2, [fp, #21]
d0081212:	6008      	str	r0, [r1, #0]
d0081214:	ea43 2102 	orr.w	r1, r3, r2, lsl #8
d0081218:	f89b 2016 	ldrb.w	r2, [fp, #22]
d008121c:	f89b 3017 	ldrb.w	r3, [fp, #23]
d0081220:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0081224:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081228:	685b      	ldr	r3, [r3, #4]
d008122a:	685b      	ldr	r3, [r3, #4]
d008122c:	4798      	blx	r3
d008122e:	f89b 0014 	ldrb.w	r0, [fp, #20]
d0081232:	f89b 1015 	ldrb.w	r1, [fp, #21]
d0081236:	f89b 2016 	ldrb.w	r2, [fp, #22]
d008123a:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d008123e:	f89b 3017 	ldrb.w	r3, [fp, #23]
d0081242:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0081246:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d008124a:	685b      	ldr	r3, [r3, #4]
d008124c:	685b      	ldr	r3, [r3, #4]
d008124e:	4798      	blx	r3
d0081250:	f89b 000c 	ldrb.w	r0, [fp, #12]
d0081254:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0081258:	f89b 200e 	ldrb.w	r2, [fp, #14]
d008125c:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0081260:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0081264:	4893      	ldr	r0, [pc, #588]	; (d00814b4 <main+0xaec>)
d0081266:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008126a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d008126e:	681b      	ldr	r3, [r3, #0]
d0081270:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d0081272:	4798      	blx	r3
d0081274:	f89b 000c 	ldrb.w	r0, [fp, #12]
d0081278:	f89b 100d 	ldrb.w	r1, [fp, #13]
d008127c:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081280:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0081284:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0081288:	488a      	ldr	r0, [pc, #552]	; (d00814b4 <main+0xaec>)
d008128a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008128e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081292:	681b      	ldr	r3, [r3, #0]
d0081294:	6d1b      	ldr	r3, [r3, #80]	; 0x50
d0081296:	4798      	blx	r3
d0081298:	4b87      	ldr	r3, [pc, #540]	; (d00814b8 <main+0xaf0>)
d008129a:	210f      	movs	r1, #15
d008129c:	6818      	ldr	r0, [r3, #0]
d008129e:	68da      	ldr	r2, [r3, #12]
d00812a0:	f000 fc12 	bl	d0081ac8 <memset>
d00812a4:	9705      	str	r7, [sp, #20]
d00812a6:	f8cd a01c 	str.w	sl, [sp, #28]
d00812aa:	9b05      	ldr	r3, [sp, #20]
d00812ac:	f46f 77c5 	mvn.w	r7, #394	; 0x18a
d00812b0:	9904      	ldr	r1, [sp, #16]
d00812b2:	f503 529e 	add.w	r2, r3, #5056	; 0x13c0
d00812b6:	9b07      	ldr	r3, [sp, #28]
d00812b8:	9106      	str	r1, [sp, #24]
d00812ba:	9205      	str	r2, [sp, #20]
d00812bc:	1192      	asrs	r2, r2, #6
d00812be:	fb09 f103 	mul.w	r1, r9, r3
d00812c2:	f8df a1e8 	ldr.w	sl, [pc, #488]	; d00814ac <main+0xae4>
d00812c6:	fb08 f303 	mul.w	r3, r8, r3
d00812ca:	9207      	str	r2, [sp, #28]
d00812cc:	9309      	str	r3, [sp, #36]	; 0x24
d00812ce:	fb09 f302 	mul.w	r3, r9, r2
d00812d2:	9108      	str	r1, [sp, #32]
d00812d4:	930a      	str	r3, [sp, #40]	; 0x28
d00812d6:	fb08 f302 	mul.w	r3, r8, r2
d00812da:	9703      	str	r7, [sp, #12]
d00812dc:	930b      	str	r3, [sp, #44]	; 0x2c
d00812de:	f50a 5a9e 	add.w	sl, sl, #5056	; 0x13c0
d00812e2:	9b03      	ldr	r3, [sp, #12]
d00812e4:	9f0a      	ldr	r7, [sp, #40]	; 0x28
d00812e6:	a824      	add	r0, sp, #144	; 0x90
d00812e8:	ea4f 12aa 	mov.w	r2, sl, asr #6
d00812ec:	fb08 f403 	mul.w	r4, r8, r3
d00812f0:	fb09 f303 	mul.w	r3, r9, r3
d00812f4:	fb08 f102 	mul.w	r1, r8, r2
d00812f8:	9203      	str	r2, [sp, #12]
d00812fa:	9a08      	ldr	r2, [sp, #32]
d00812fc:	eba1 0e07 	sub.w	lr, r1, r7
d0081300:	9e03      	ldr	r6, [sp, #12]
d0081302:	1a89      	subs	r1, r1, r2
d0081304:	1aa5      	subs	r5, r4, r2
d0081306:	fb09 f606 	mul.w	r6, r9, r6
d008130a:	1be4      	subs	r4, r4, r7
d008130c:	910c      	str	r1, [sp, #48]	; 0x30
d008130e:	13ed      	asrs	r5, r5, #15
d0081310:	990c      	ldr	r1, [sp, #48]	; 0x30
d0081312:	13e4      	asrs	r4, r4, #15
d0081314:	9f0b      	ldr	r7, [sp, #44]	; 0x2c
d0081316:	ea4f 3eee 	mov.w	lr, lr, asr #15
d008131a:	9a09      	ldr	r2, [sp, #36]	; 0x24
d008131c:	13c9      	asrs	r1, r1, #15
d008131e:	eb06 0c07 	add.w	ip, r6, r7
d0081322:	f504 74f0 	add.w	r4, r4, #480	; 0x1e0
d0081326:	4416      	add	r6, r2
d0081328:	f501 71f0 	add.w	r1, r1, #480	; 0x1e0
d008132c:	189a      	adds	r2, r3, r2
d008132e:	443b      	add	r3, r7
d0081330:	9f06      	ldr	r7, [sp, #24]
d0081332:	ea4f 3cec 	mov.w	ip, ip, asr #15
d0081336:	13f6      	asrs	r6, r6, #15
d0081338:	f8ad 1094 	strh.w	r1, [sp, #148]	; 0x94
d008133c:	13d2      	asrs	r2, r2, #15
d008133e:	f007 0101 	and.w	r1, r7, #1
d0081342:	13db      	asrs	r3, r3, #15
d0081344:	f506 76a0 	add.w	r6, r6, #320	; 0x140
d0081348:	f1c1 010e 	rsb	r1, r1, #14
d008134c:	f50e 7ef0 	add.w	lr, lr, #480	; 0x1e0
d0081350:	f503 73a0 	add.w	r3, r3, #320	; 0x140
d0081354:	f505 75f0 	add.w	r5, r5, #480	; 0x1e0
d0081358:	f50c 7ca0 	add.w	ip, ip, #320	; 0x140
d008135c:	f502 72a0 	add.w	r2, r2, #320	; 0x140
d0081360:	f8ad 40c8 	strh.w	r4, [sp, #200]	; 0xc8
d0081364:	fa0f fe8e 	sxth.w	lr, lr
d0081368:	4c53      	ldr	r4, [pc, #332]	; (d00814b8 <main+0xaf0>)
d008136a:	fa0f fc8c 	sxth.w	ip, ip
d008136e:	b22d      	sxth	r5, r5
d0081370:	3701      	adds	r7, #1
d0081372:	b212      	sxth	r2, r2
d0081374:	f8ad 6096 	strh.w	r6, [sp, #150]	; 0x96
d0081378:	f8ad 30ca 	strh.w	r3, [sp, #202]	; 0xca
d008137c:	b2ce      	uxtb	r6, r1
d008137e:	6823      	ldr	r3, [r4, #0]
d0081380:	4631      	mov	r1, r6
d0081382:	f8ad e098 	strh.w	lr, [sp, #152]	; 0x98
d0081386:	f8ad e0c4 	strh.w	lr, [sp, #196]	; 0xc4
d008138a:	f8ad c09a 	strh.w	ip, [sp, #154]	; 0x9a
d008138e:	9706      	str	r7, [sp, #24]
d0081390:	f8ad c0c6 	strh.w	ip, [sp, #198]	; 0xc6
d0081394:	f8ad 5090 	strh.w	r5, [sp, #144]	; 0x90
d0081398:	f8ad 50c0 	strh.w	r5, [sp, #192]	; 0xc0
d008139c:	f8ad 2092 	strh.w	r2, [sp, #146]	; 0x92
d00813a0:	f8ad 20c2 	strh.w	r2, [sp, #194]	; 0xc2
d00813a4:	b13b      	cbz	r3, d00813b6 <main+0x9ee>
d00813a6:	f7fe ff29 	bl	d00801fc <draw_filled_triangle.part.0.constprop.0>
d00813aa:	6823      	ldr	r3, [r4, #0]
d00813ac:	4631      	mov	r1, r6
d00813ae:	a830      	add	r0, sp, #192	; 0xc0
d00813b0:	b10b      	cbz	r3, d00813b6 <main+0x9ee>
d00813b2:	f7fe ff23 	bl	d00801fc <draw_filled_triangle.part.0.constprop.0>
d00813b6:	f246 23c0 	movw	r3, #25280	; 0x62c0
d00813ba:	459a      	cmp	sl, r3
d00813bc:	d18f      	bne.n	d00812de <main+0x916>
d00813be:	9b04      	ldr	r3, [sp, #16]
d00813c0:	3301      	adds	r3, #1
d00813c2:	9304      	str	r3, [sp, #16]
d00813c4:	9b05      	ldr	r3, [sp, #20]
d00813c6:	4553      	cmp	r3, sl
d00813c8:	f47f af6f 	bne.w	d00812aa <main+0x8e2>
d00813cc:	f89b 000c 	ldrb.w	r0, [fp, #12]
d00813d0:	2500      	movs	r5, #0
d00813d2:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00813d6:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00813da:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d00813de:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00813e2:	4835      	ldr	r0, [pc, #212]	; (d00814b8 <main+0xaf0>)
d00813e4:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00813e8:	f8df 90e0 	ldr.w	r9, [pc, #224]	; d00814cc <main+0xb04>
d00813ec:	4e33      	ldr	r6, [pc, #204]	; (d00814bc <main+0xaf4>)
d00813ee:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00813f2:	4c33      	ldr	r4, [pc, #204]	; (d00814c0 <main+0xaf8>)
d00813f4:	681b      	ldr	r3, [r3, #0]
d00813f6:	6a1b      	ldr	r3, [r3, #32]
d00813f8:	4798      	blx	r3
d00813fa:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00813fe:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0081402:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0081406:	f89b 200e 	ldrb.w	r2, [fp, #14]
d008140a:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d008140e:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0081412:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0081416:	4a2b      	ldr	r2, [pc, #172]	; (d00814c4 <main+0xafc>)
d0081418:	681b      	ldr	r3, [r3, #0]
d008141a:	6810      	ldr	r0, [r2, #0]
d008141c:	69db      	ldr	r3, [r3, #28]
d008141e:	4798      	blx	r3
d0081420:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0081424:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0081428:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008142c:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081430:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0081434:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0081438:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008143c:	4a22      	ldr	r2, [pc, #136]	; (d00814c8 <main+0xb00>)
d008143e:	681b      	ldr	r3, [r3, #0]
d0081440:	6810      	ldr	r0, [r2, #0]
d0081442:	699b      	ldr	r3, [r3, #24]
d0081444:	4798      	blx	r3
d0081446:	f89b 300c 	ldrb.w	r3, [fp, #12]
d008144a:	f89b 200d 	ldrb.w	r2, [fp, #13]
d008144e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0081452:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081456:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d008145a:	f89b 200f 	ldrb.w	r2, [fp, #15]
d008145e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0081462:	681b      	ldr	r3, [r3, #0]
d0081464:	681b      	ldr	r3, [r3, #0]
d0081466:	4798      	blx	r3
d0081468:	9503      	str	r5, [sp, #12]
d008146a:	f89b 0000 	ldrb.w	r0, [fp]
d008146e:	f89b 1001 	ldrb.w	r1, [fp, #1]
d0081472:	f89b 2002 	ldrb.w	r2, [fp, #2]
d0081476:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d008147a:	f89b 3003 	ldrb.w	r3, [fp, #3]
d008147e:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0081482:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081486:	6a1b      	ldr	r3, [r3, #32]
d0081488:	4798      	blx	r3
d008148a:	f000 0003 	and.w	r0, r0, #3
d008148e:	2803      	cmp	r0, #3
d0081490:	f000 8257 	beq.w	d0081942 <main+0xf7a>
d0081494:	f899 3000 	ldrb.w	r3, [r9]
d0081498:	2b00      	cmp	r3, #0
d008149a:	f000 82df 	beq.w	d0081a5c <main+0x1094>
d008149e:	4b09      	ldr	r3, [pc, #36]	; (d00814c4 <main+0xafc>)
d00814a0:	6818      	ldr	r0, [r3, #0]
d00814a2:	e015      	b.n	d00814d0 <main+0xb08>
d00814a4:	d0082e60 	.word	0xd0082e60
d00814a8:	d008904c 	.word	0xd008904c
d00814ac:	ffff9d40 	.word	0xffff9d40
d00814b0:	d0088b94 	.word	0xd0088b94
d00814b4:	d0087cc0 	.word	0xd0087cc0
d00814b8:	d00877e0 	.word	0xd00877e0
d00814bc:	d0087758 	.word	0xd0087758
d00814c0:	b60b60b7 	.word	0xb60b60b7
d00814c4:	d00886c0 	.word	0xd00886c0
d00814c8:	d00886e0 	.word	0xd00886e0
d00814cc:	d0087cb4 	.word	0xd0087cb4
d00814d0:	f89b 500c 	ldrb.w	r5, [fp, #12]
d00814d4:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00814d8:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00814dc:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d00814e0:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00814e4:	9004      	str	r0, [sp, #16]
d00814e6:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00814ea:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00814ee:	681b      	ldr	r3, [r3, #0]
d00814f0:	68db      	ldr	r3, [r3, #12]
d00814f2:	4798      	blx	r3
d00814f4:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00814f8:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00814fc:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081500:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d0081504:	9804      	ldr	r0, [sp, #16]
d0081506:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d008150a:	f89b 200f 	ldrb.w	r2, [fp, #15]
d008150e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0081512:	681b      	ldr	r3, [r3, #0]
d0081514:	699b      	ldr	r3, [r3, #24]
d0081516:	4798      	blx	r3
d0081518:	f89b 500c 	ldrb.w	r5, [fp, #12]
d008151c:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0081520:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081524:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d0081528:	f89b 300f 	ldrb.w	r3, [fp, #15]
d008152c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0081530:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081534:	685b      	ldr	r3, [r3, #4]
d0081536:	681b      	ldr	r3, [r3, #0]
d0081538:	4798      	blx	r3
d008153a:	9804      	ldr	r0, [sp, #16]
d008153c:	f7fe ff58 	bl	d00803f0 <draw_cube>
d0081540:	4acf      	ldr	r2, [pc, #828]	; (d0081880 <main+0xeb8>)
d0081542:	6833      	ldr	r3, [r6, #0]
d0081544:	6812      	ldr	r2, [r2, #0]
d0081546:	3b01      	subs	r3, #1
d0081548:	4251      	negs	r1, r2
d008154a:	6033      	str	r3, [r6, #0]
d008154c:	428b      	cmp	r3, r1
d008154e:	f280 8274 	bge.w	d0081a3a <main+0x1072>
d0081552:	f44f 73a0 	mov.w	r3, #320	; 0x140
d0081556:	2a00      	cmp	r2, #0
d0081558:	6033      	str	r3, [r6, #0]
d008155a:	f280 826a 	bge.w	d0081a32 <main+0x106a>
d008155e:	4dc9      	ldr	r5, [pc, #804]	; (d0081884 <main+0xebc>)
d0081560:	682b      	ldr	r3, [r5, #0]
d0081562:	3b01      	subs	r3, #1
d0081564:	f100 828f 	bmi.w	d0081a86 <main+0x10be>
d0081568:	602b      	str	r3, [r5, #0]
d008156a:	f89b 700c 	ldrb.w	r7, [fp, #12]
d008156e:	2012      	movs	r0, #18
d0081570:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0081574:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081578:	ea47 2101 	orr.w	r1, r7, r1, lsl #8
d008157c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0081580:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0081584:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081588:	685b      	ldr	r3, [r3, #4]
d008158a:	68db      	ldr	r3, [r3, #12]
d008158c:	4798      	blx	r3
d008158e:	6831      	ldr	r1, [r6, #0]
d0081590:	2058      	movs	r0, #88	; 0x58
d0081592:	3102      	adds	r1, #2
d0081594:	b209      	sxth	r1, r1
d0081596:	f7fe fdd3 	bl	d0080140 <draw_textf_multiline.constprop.0>
d008159a:	f89b 700c 	ldrb.w	r7, [fp, #12]
d008159e:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00815a2:	2011      	movs	r0, #17
d00815a4:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00815a8:	ea47 2101 	orr.w	r1, r7, r1, lsl #8
d00815ac:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00815b0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00815b4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00815b8:	685b      	ldr	r3, [r3, #4]
d00815ba:	68db      	ldr	r3, [r3, #12]
d00815bc:	4798      	blx	r3
d00815be:	f9b6 1000 	ldrsh.w	r1, [r6]
d00815c2:	2056      	movs	r0, #86	; 0x56
d00815c4:	f7fe fdbc 	bl	d0080140 <draw_textf_multiline.constprop.0>
d00815c8:	f89b 700c 	ldrb.w	r7, [fp, #12]
d00815cc:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00815d0:	2013      	movs	r0, #19
d00815d2:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00815d6:	ea47 2101 	orr.w	r1, r7, r1, lsl #8
d00815da:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00815de:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00815e2:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00815e6:	685b      	ldr	r3, [r3, #4]
d00815e8:	68db      	ldr	r3, [r3, #12]
d00815ea:	4798      	blx	r3
d00815ec:	f89b 000c 	ldrb.w	r0, [fp, #12]
d00815f0:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00815f4:	2100      	movs	r1, #0
d00815f6:	f89b c00e 	ldrb.w	ip, [fp, #14]
d00815fa:	2310      	movs	r3, #16
d00815fc:	ea40 2202 	orr.w	r2, r0, r2, lsl #8
d0081600:	f89b 700f 	ldrb.w	r7, [fp, #15]
d0081604:	4608      	mov	r0, r1
d0081606:	ea42 4c0c 	orr.w	ip, r2, ip, lsl #16
d008160a:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d008160e:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d0081612:	687f      	ldr	r7, [r7, #4]
d0081614:	687f      	ldr	r7, [r7, #4]
d0081616:	47b8      	blx	r7
d0081618:	f89b 100c 	ldrb.w	r1, [fp, #12]
d008161c:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0081620:	2310      	movs	r3, #16
d0081622:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0081626:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d008162a:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d008162e:	f89b 700f 	ldrb.w	r7, [fp, #15]
d0081632:	f44f 7198 	mov.w	r1, #304	; 0x130
d0081636:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d008163a:	2000      	movs	r0, #0
d008163c:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d0081640:	687f      	ldr	r7, [r7, #4]
d0081642:	687f      	ldr	r7, [r7, #4]
d0081644:	47b8      	blx	r7
d0081646:	f89b 200c 	ldrb.w	r2, [fp, #12]
d008164a:	f89b 000d 	ldrb.w	r0, [fp, #13]
d008164e:	f44f 738e 	mov.w	r3, #284	; 0x11c
d0081652:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0081656:	2112      	movs	r1, #18
d0081658:	ea42 2000 	orr.w	r0, r2, r0, lsl #8
d008165c:	f89b 700f 	ldrb.w	r7, [fp, #15]
d0081660:	f9b5 2000 	ldrsh.w	r2, [r5]
d0081664:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d0081668:	2000      	movs	r0, #0
d008166a:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d008166e:	687f      	ldr	r7, [r7, #4]
d0081670:	687f      	ldr	r7, [r7, #4]
d0081672:	47b8      	blx	r7
d0081674:	f89b 200c 	ldrb.w	r2, [fp, #12]
d0081678:	f89b 000d 	ldrb.w	r0, [fp, #13]
d008167c:	f44f 738e 	mov.w	r3, #284	; 0x11c
d0081680:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0081684:	2112      	movs	r1, #18
d0081686:	ea42 2000 	orr.w	r0, r2, r0, lsl #8
d008168a:	f89b 700f 	ldrb.w	r7, [fp, #15]
d008168e:	682a      	ldr	r2, [r5, #0]
d0081690:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d0081694:	f5c2 70f0 	rsb	r0, r2, #480	; 0x1e0
d0081698:	b212      	sxth	r2, r2
d008169a:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d008169e:	b200      	sxth	r0, r0
d00816a0:	687f      	ldr	r7, [r7, #4]
d00816a2:	687f      	ldr	r7, [r7, #4]
d00816a4:	47b8      	blx	r7
d00816a6:	f89b 700c 	ldrb.w	r7, [fp, #12]
d00816aa:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00816ae:	2011      	movs	r0, #17
d00816b0:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00816b4:	ea47 2101 	orr.w	r1, r7, r1, lsl #8
d00816b8:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00816bc:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00816c0:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00816c4:	685b      	ldr	r3, [r3, #4]
d00816c6:	68db      	ldr	r3, [r3, #12]
d00816c8:	4798      	blx	r3
d00816ca:	f89b 100c 	ldrb.w	r1, [fp, #12]
d00816ce:	f89b 000d 	ldrb.w	r0, [fp, #13]
d00816d2:	2302      	movs	r3, #2
d00816d4:	f89b c00e 	ldrb.w	ip, [fp, #14]
d00816d8:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d00816dc:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d00816e0:	f89b 700f 	ldrb.w	r7, [fp, #15]
d00816e4:	2110      	movs	r1, #16
d00816e6:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d00816ea:	2000      	movs	r0, #0
d00816ec:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d00816f0:	687f      	ldr	r7, [r7, #4]
d00816f2:	687f      	ldr	r7, [r7, #4]
d00816f4:	47b8      	blx	r7
d00816f6:	f89b 100c 	ldrb.w	r1, [fp, #12]
d00816fa:	f89b 000d 	ldrb.w	r0, [fp, #13]
d00816fe:	2302      	movs	r3, #2
d0081700:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0081704:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0081708:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d008170c:	f89b 700f 	ldrb.w	r7, [fp, #15]
d0081710:	f44f 7197 	mov.w	r1, #302	; 0x12e
d0081714:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d0081718:	2000      	movs	r0, #0
d008171a:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d008171e:	687f      	ldr	r7, [r7, #4]
d0081720:	687f      	ldr	r7, [r7, #4]
d0081722:	47b8      	blx	r7
d0081724:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0081728:	f89b 000d 	ldrb.w	r0, [fp, #13]
d008172c:	f44f 738e 	mov.w	r3, #284	; 0x11c
d0081730:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0081734:	2202      	movs	r2, #2
d0081736:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d008173a:	f89b 700f 	ldrb.w	r7, [fp, #15]
d008173e:	2112      	movs	r1, #18
d0081740:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d0081744:	f9b5 0000 	ldrsh.w	r0, [r5]
d0081748:	ea4c 6707 	orr.w	r7, ip, r7, lsl #24
d008174c:	687f      	ldr	r7, [r7, #4]
d008174e:	687f      	ldr	r7, [r7, #4]
d0081750:	47b8      	blx	r7
d0081752:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0081756:	f89b 700d 	ldrb.w	r7, [fp, #13]
d008175a:	f44f 738e 	mov.w	r3, #284	; 0x11c
d008175e:	f89b 800e 	ldrb.w	r8, [fp, #14]
d0081762:	2202      	movs	r2, #2
d0081764:	ea41 2c07 	orr.w	ip, r1, r7, lsl #8
d0081768:	f89b e00f 	ldrb.w	lr, [fp, #15]
d008176c:	6828      	ldr	r0, [r5, #0]
d008176e:	2112      	movs	r1, #18
d0081770:	ea4c 4708 	orr.w	r7, ip, r8, lsl #16
d0081774:	f5c0 70ef 	rsb	r0, r0, #478	; 0x1de
d0081778:	ea47 650e 	orr.w	r5, r7, lr, lsl #24
d008177c:	b200      	sxth	r0, r0
d008177e:	686d      	ldr	r5, [r5, #4]
d0081780:	686d      	ldr	r5, [r5, #4]
d0081782:	47a8      	blx	r5
d0081784:	9b03      	ldr	r3, [sp, #12]
d0081786:	f44f 75b4 	mov.w	r5, #360	; 0x168
d008178a:	eb03 0143 	add.w	r1, r3, r3, lsl #1
d008178e:	005a      	lsls	r2, r3, #1
d0081790:	fb84 3001 	smull	r3, r0, r4, r1
d0081794:	17cb      	asrs	r3, r1, #31
d0081796:	4408      	add	r0, r1
d0081798:	ebc3 2320 	rsb	r3, r3, r0, asr #8
d008179c:	fb05 1313 	mls	r3, r5, r3, r1
d00817a0:	2b00      	cmp	r3, #0
d00817a2:	bfb8      	it	lt
d00817a4:	195b      	addlt	r3, r3, r5
d00817a6:	2bb4      	cmp	r3, #180	; 0xb4
d00817a8:	f340 8145 	ble.w	d0081a36 <main+0x106e>
d00817ac:	3bb4      	subs	r3, #180	; 0xb4
d00817ae:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00817b2:	f1c3 01b4 	rsb	r1, r3, #180	; 0xb4
d00817b6:	325a      	adds	r2, #90	; 0x5a
d00817b8:	f649 6534 	movw	r5, #40500	; 0x9e34
d00817bc:	fb03 f301 	mul.w	r3, r3, r1
d00817c0:	ea4f 7ce2 	mov.w	ip, r2, asr #31
d00817c4:	fb84 1702 	smull	r1, r7, r4, r2
d00817c8:	ebc3 31c3 	rsb	r1, r3, r3, lsl #15
d00817cc:	1aed      	subs	r5, r5, r3
d00817ce:	18bb      	adds	r3, r7, r2
d00817d0:	f44f 77b4 	mov.w	r7, #360	; 0x168
d00817d4:	0089      	lsls	r1, r1, #2
d00817d6:	ebcc 2323 	rsb	r3, ip, r3, asr #8
d00817da:	fbb1 f1f5 	udiv	r1, r1, r5
d00817de:	fb07 2313 	mls	r3, r7, r3, r2
d00817e2:	fb00 f001 	mul.w	r0, r0, r1
d00817e6:	2b00      	cmp	r3, #0
d00817e8:	f340 2050 	sbfx	r0, r0, #9, #17
d00817ec:	da01      	bge.n	d00817f2 <main+0xe2a>
d00817ee:	f503 73b4 	add.w	r3, r3, #360	; 0x168
d00817f2:	2bb4      	cmp	r3, #180	; 0xb4
d00817f4:	f340 8145 	ble.w	d0081a82 <main+0x10ba>
d00817f8:	3bb4      	subs	r3, #180	; 0xb4
d00817fa:	f04f 31ff 	mov.w	r1, #4294967295	; 0xffffffff
d00817fe:	f1c3 02b4 	rsb	r2, r3, #180	; 0xb4
d0081802:	f89b 700c 	ldrb.w	r7, [fp, #12]
d0081806:	f649 6c34 	movw	ip, #40500	; 0x9e34
d008180a:	30f0      	adds	r0, #240	; 0xf0
d008180c:	fb03 f302 	mul.w	r3, r3, r2
d0081810:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0081814:	ebc3 3ec3 	rsb	lr, r3, r3, lsl #15
d0081818:	ebac 0c03 	sub.w	ip, ip, r3
d008181c:	ea47 2502 	orr.w	r5, r7, r2, lsl #8
d0081820:	f89b 300e 	ldrb.w	r3, [fp, #14]
d0081824:	ea4f 078e 	mov.w	r7, lr, lsl #2
d0081828:	ea45 4203 	orr.w	r2, r5, r3, lsl #16
d008182c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0081830:	fbb7 f5fc 	udiv	r5, r7, ip
d0081834:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081838:	fb01 f105 	mul.w	r1, r1, r5
d008183c:	681b      	ldr	r3, [r3, #0]
d008183e:	f341 2150 	sbfx	r1, r1, #9, #17
d0081842:	6b1b      	ldr	r3, [r3, #48]	; 0x30
d0081844:	31a0      	adds	r1, #160	; 0xa0
d0081846:	4798      	blx	r3
d0081848:	f899 3000 	ldrb.w	r3, [r9]
d008184c:	f1c3 0301 	rsb	r3, r3, #1
d0081850:	b2db      	uxtb	r3, r3
d0081852:	f889 3000 	strb.w	r3, [r9]
d0081856:	f899 3000 	ldrb.w	r3, [r9]
d008185a:	2b00      	cmp	r3, #0
d008185c:	f000 8101 	beq.w	d0081a62 <main+0x109a>
d0081860:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0081864:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0081868:	f89b 200e 	ldrb.w	r2, [fp, #14]
d008186c:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d0081870:	4905      	ldr	r1, [pc, #20]	; (d0081888 <main+0xec0>)
d0081872:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0081876:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d008187a:	6809      	ldr	r1, [r1, #0]
d008187c:	4803      	ldr	r0, [pc, #12]	; (d008188c <main+0xec4>)
d008187e:	e007      	b.n	d0081890 <main+0xec8>
d0081880:	d008904c 	.word	0xd008904c
d0081884:	d0087800 	.word	0xd0087800
d0081888:	d00886e0 	.word	0xd00886e0
d008188c:	d00886c0 	.word	0xd00886c0
d0081890:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0081894:	6800      	ldr	r0, [r0, #0]
d0081896:	f44f 75b4 	mov.w	r5, #360	; 0x168
d008189a:	681b      	ldr	r3, [r3, #0]
d008189c:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d008189e:	4798      	blx	r3
d00818a0:	f89b 000c 	ldrb.w	r0, [fp, #12]
d00818a4:	9b03      	ldr	r3, [sp, #12]
d00818a6:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00818aa:	3301      	adds	r3, #1
d00818ac:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00818b0:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d00818b4:	9303      	str	r3, [sp, #12]
d00818b6:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00818ba:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00818be:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00818c2:	681b      	ldr	r3, [r3, #0]
d00818c4:	681b      	ldr	r3, [r3, #0]
d00818c6:	4798      	blx	r3
d00818c8:	f89b 0014 	ldrb.w	r0, [fp, #20]
d00818cc:	f89b 1015 	ldrb.w	r1, [fp, #21]
d00818d0:	f89b 2016 	ldrb.w	r2, [fp, #22]
d00818d4:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d00818d8:	f89b 3017 	ldrb.w	r3, [fp, #23]
d00818dc:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00818e0:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00818e4:	685b      	ldr	r3, [r3, #4]
d00818e6:	685b      	ldr	r3, [r3, #4]
d00818e8:	4798      	blx	r3
d00818ea:	f8df e1b8 	ldr.w	lr, [pc, #440]	; d0081aa4 <main+0x10dc>
d00818ee:	4a67      	ldr	r2, [pc, #412]	; (d0081a8c <main+0x10c4>)
d00818f0:	f8de 3000 	ldr.w	r3, [lr]
d00818f4:	6811      	ldr	r1, [r2, #0]
d00818f6:	3302      	adds	r3, #2
d00818f8:	f8df c1ac 	ldr.w	ip, [pc, #428]	; d0081aa8 <main+0x10e0>
d00818fc:	3101      	adds	r1, #1
d00818fe:	fb84 2a03 	smull	r2, sl, r4, r3
d0081902:	f8dc 0000 	ldr.w	r0, [ip]
d0081906:	17da      	asrs	r2, r3, #31
d0081908:	449a      	add	sl, r3
d008190a:	3003      	adds	r0, #3
d008190c:	ebc2 222a 	rsb	r2, r2, sl, asr #8
d0081910:	fb84 7800 	smull	r7, r8, r4, r0
d0081914:	fb84 7a01 	smull	r7, sl, r4, r1
d0081918:	fb05 3312 	mls	r3, r5, r2, r3
d008191c:	4480      	add	r8, r0
d008191e:	448a      	add	sl, r1
d0081920:	17c2      	asrs	r2, r0, #31
d0081922:	f8ce 3000 	str.w	r3, [lr]
d0081926:	17cb      	asrs	r3, r1, #31
d0081928:	ebc2 2228 	rsb	r2, r2, r8, asr #8
d008192c:	ebc3 2a2a 	rsb	sl, r3, sl, asr #8
d0081930:	4b56      	ldr	r3, [pc, #344]	; (d0081a8c <main+0x10c4>)
d0081932:	fb05 0012 	mls	r0, r5, r2, r0
d0081936:	fb05 111a 	mls	r1, r5, sl, r1
d008193a:	f8cc 0000 	str.w	r0, [ip]
d008193e:	6019      	str	r1, [r3, #0]
d0081940:	e593      	b.n	d008146a <main+0xaa2>
d0081942:	f89b 0000 	ldrb.w	r0, [fp]
d0081946:	f89b 1001 	ldrb.w	r1, [fp, #1]
d008194a:	f89b 2002 	ldrb.w	r2, [fp, #2]
d008194e:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0081952:	f89b 3003 	ldrb.w	r3, [fp, #3]
d0081956:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008195a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d008195e:	6a1b      	ldr	r3, [r3, #32]
d0081960:	4798      	blx	r3
d0081962:	f000 0003 	and.w	r0, r0, #3
d0081966:	2803      	cmp	r0, #3
d0081968:	d0eb      	beq.n	d0081942 <main+0xf7a>
d008196a:	4b49      	ldr	r3, [pc, #292]	; (d0081a90 <main+0x10c8>)
d008196c:	2502      	movs	r5, #2
d008196e:	4849      	ldr	r0, [pc, #292]	; (d0081a94 <main+0x10cc>)
d0081970:	6819      	ldr	r1, [r3, #0]
d0081972:	f000 f95b 	bl	d0081c2c <iprintf>
d0081976:	f89b 300c 	ldrb.w	r3, [fp, #12]
d008197a:	f89b 200d 	ldrb.w	r2, [fp, #13]
d008197e:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0081982:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0081986:	f89b 200f 	ldrb.w	r2, [fp, #15]
d008198a:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d008198e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0081992:	681b      	ldr	r3, [r3, #0]
d0081994:	68db      	ldr	r3, [r3, #12]
d0081996:	4798      	blx	r3
d0081998:	f89b 400c 	ldrb.w	r4, [fp, #12]
d008199c:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00819a0:	f44f 73a0 	mov.w	r3, #320	; 0x140
d00819a4:	f89b 100e 	ldrb.w	r1, [fp, #14]
d00819a8:	ea44 2402 	orr.w	r4, r4, r2, lsl #8
d00819ac:	f89b 000f 	ldrb.w	r0, [fp, #15]
d00819b0:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d00819b4:	ea44 4401 	orr.w	r4, r4, r1, lsl #16
d00819b8:	4619      	mov	r1, r3
d00819ba:	ea44 6400 	orr.w	r4, r4, r0, lsl #24
d00819be:	4610      	mov	r0, r2
d00819c0:	6824      	ldr	r4, [r4, #0]
d00819c2:	9500      	str	r5, [sp, #0]
d00819c4:	6964      	ldr	r4, [r4, #20]
d00819c6:	47a0      	blx	r4
d00819c8:	f89b 3004 	ldrb.w	r3, [fp, #4]
d00819cc:	f89b 2005 	ldrb.w	r2, [fp, #5]
d00819d0:	f89b 1006 	ldrb.w	r1, [fp, #6]
d00819d4:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00819d8:	f89b 2007 	ldrb.w	r2, [fp, #7]
d00819dc:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00819e0:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00819e4:	685b      	ldr	r3, [r3, #4]
d00819e6:	4798      	blx	r3
d00819e8:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00819ec:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00819f0:	f89b 100e 	ldrb.w	r1, [fp, #14]
d00819f4:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00819f8:	f89b 200f 	ldrb.w	r2, [fp, #15]
d00819fc:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0081a00:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0081a04:	681b      	ldr	r3, [r3, #0]
d0081a06:	68db      	ldr	r3, [r3, #12]
d0081a08:	4798      	blx	r3
d0081a0a:	f89b 3000 	ldrb.w	r3, [fp]
d0081a0e:	f89b 2001 	ldrb.w	r2, [fp, #1]
d0081a12:	f89b 1002 	ldrb.w	r1, [fp, #2]
d0081a16:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0081a1a:	f89b 2003 	ldrb.w	r2, [fp, #3]
d0081a1e:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0081a22:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0081a26:	685b      	ldr	r3, [r3, #4]
d0081a28:	4798      	blx	r3
d0081a2a:	2000      	movs	r0, #0
d0081a2c:	b03d      	add	sp, #244	; 0xf4
d0081a2e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0081a32:	4d19      	ldr	r5, [pc, #100]	; (d0081a98 <main+0x10d0>)
d0081a34:	e599      	b.n	d008156a <main+0xba2>
d0081a36:	2001      	movs	r0, #1
d0081a38:	e6bb      	b.n	d00817b2 <main+0xdea>
d0081a3a:	f5c2 72a0 	rsb	r2, r2, #320	; 0x140
d0081a3e:	4293      	cmp	r3, r2
d0081a40:	f6ff ad8d 	blt.w	d008155e <main+0xb96>
d0081a44:	ddf5      	ble.n	d0081a32 <main+0x106a>
d0081a46:	f5b3 7fa0 	cmp.w	r3, #320	; 0x140
d0081a4a:	4d13      	ldr	r5, [pc, #76]	; (d0081a98 <main+0x10d0>)
d0081a4c:	f6bf ad8d 	bge.w	d008156a <main+0xba2>
d0081a50:	682b      	ldr	r3, [r5, #0]
d0081a52:	3301      	adds	r3, #1
d0081a54:	2b40      	cmp	r3, #64	; 0x40
d0081a56:	bfc8      	it	gt
d0081a58:	2340      	movgt	r3, #64	; 0x40
d0081a5a:	e585      	b.n	d0081568 <main+0xba0>
d0081a5c:	4b0f      	ldr	r3, [pc, #60]	; (d0081a9c <main+0x10d4>)
d0081a5e:	6818      	ldr	r0, [r3, #0]
d0081a60:	e536      	b.n	d00814d0 <main+0xb08>
d0081a62:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0081a66:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0081a6a:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0081a6e:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d0081a72:	490b      	ldr	r1, [pc, #44]	; (d0081aa0 <main+0x10d8>)
d0081a74:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0081a78:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d0081a7c:	6809      	ldr	r1, [r1, #0]
d0081a7e:	4807      	ldr	r0, [pc, #28]	; (d0081a9c <main+0x10d4>)
d0081a80:	e706      	b.n	d0081890 <main+0xec8>
d0081a82:	2101      	movs	r1, #1
d0081a84:	e6bb      	b.n	d00817fe <main+0xe36>
d0081a86:	2300      	movs	r3, #0
d0081a88:	602b      	str	r3, [r5, #0]
d0081a8a:	e56e      	b.n	d008156a <main+0xba2>
d0081a8c:	d00877d0 	.word	0xd00877d0
d0081a90:	d0088b94 	.word	0xd0088b94
d0081a94:	d0082b84 	.word	0xd0082b84
d0081a98:	d0087800 	.word	0xd0087800
d0081a9c:	d00886e0 	.word	0xd00886e0
d0081aa0:	d00886c0 	.word	0xd00886c0
d0081aa4:	d00877c8 	.word	0xd00877c8
d0081aa8:	d00877cc 	.word	0xd00877cc

d0081aac <__errno>:
d0081aac:	4b01      	ldr	r3, [pc, #4]	; (d0081ab4 <__errno+0x8>)
d0081aae:	6818      	ldr	r0, [r3, #0]
d0081ab0:	4770      	bx	lr
d0081ab2:	bf00      	nop
d0081ab4:	d008775c 	.word	0xd008775c

d0081ab8 <malloc>:
d0081ab8:	4b02      	ldr	r3, [pc, #8]	; (d0081ac4 <malloc+0xc>)
d0081aba:	4601      	mov	r1, r0
d0081abc:	6818      	ldr	r0, [r3, #0]
d0081abe:	f000 b85b 	b.w	d0081b78 <_malloc_r>
d0081ac2:	bf00      	nop
d0081ac4:	d008775c 	.word	0xd008775c

d0081ac8 <memset>:
d0081ac8:	4402      	add	r2, r0
d0081aca:	4603      	mov	r3, r0
d0081acc:	4293      	cmp	r3, r2
d0081ace:	d100      	bne.n	d0081ad2 <memset+0xa>
d0081ad0:	4770      	bx	lr
d0081ad2:	f803 1b01 	strb.w	r1, [r3], #1
d0081ad6:	e7f9      	b.n	d0081acc <memset+0x4>

d0081ad8 <_free_r>:
d0081ad8:	b537      	push	{r0, r1, r2, r4, r5, lr}
d0081ada:	2900      	cmp	r1, #0
d0081adc:	d048      	beq.n	d0081b70 <_free_r+0x98>
d0081ade:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0081ae2:	9001      	str	r0, [sp, #4]
d0081ae4:	2b00      	cmp	r3, #0
d0081ae6:	f1a1 0404 	sub.w	r4, r1, #4
d0081aea:	bfb8      	it	lt
d0081aec:	18e4      	addlt	r4, r4, r3
d0081aee:	f000 fba1 	bl	d0082234 <__malloc_lock>
d0081af2:	4a20      	ldr	r2, [pc, #128]	; (d0081b74 <_free_r+0x9c>)
d0081af4:	9801      	ldr	r0, [sp, #4]
d0081af6:	6813      	ldr	r3, [r2, #0]
d0081af8:	4615      	mov	r5, r2
d0081afa:	b933      	cbnz	r3, d0081b0a <_free_r+0x32>
d0081afc:	6063      	str	r3, [r4, #4]
d0081afe:	6014      	str	r4, [r2, #0]
d0081b00:	b003      	add	sp, #12
d0081b02:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d0081b06:	f000 bb9b 	b.w	d0082240 <__malloc_unlock>
d0081b0a:	42a3      	cmp	r3, r4
d0081b0c:	d90b      	bls.n	d0081b26 <_free_r+0x4e>
d0081b0e:	6821      	ldr	r1, [r4, #0]
d0081b10:	1862      	adds	r2, r4, r1
d0081b12:	4293      	cmp	r3, r2
d0081b14:	bf04      	itt	eq
d0081b16:	681a      	ldreq	r2, [r3, #0]
d0081b18:	685b      	ldreq	r3, [r3, #4]
d0081b1a:	6063      	str	r3, [r4, #4]
d0081b1c:	bf04      	itt	eq
d0081b1e:	1852      	addeq	r2, r2, r1
d0081b20:	6022      	streq	r2, [r4, #0]
d0081b22:	602c      	str	r4, [r5, #0]
d0081b24:	e7ec      	b.n	d0081b00 <_free_r+0x28>
d0081b26:	461a      	mov	r2, r3
d0081b28:	685b      	ldr	r3, [r3, #4]
d0081b2a:	b10b      	cbz	r3, d0081b30 <_free_r+0x58>
d0081b2c:	42a3      	cmp	r3, r4
d0081b2e:	d9fa      	bls.n	d0081b26 <_free_r+0x4e>
d0081b30:	6811      	ldr	r1, [r2, #0]
d0081b32:	1855      	adds	r5, r2, r1
d0081b34:	42a5      	cmp	r5, r4
d0081b36:	d10b      	bne.n	d0081b50 <_free_r+0x78>
d0081b38:	6824      	ldr	r4, [r4, #0]
d0081b3a:	4421      	add	r1, r4
d0081b3c:	1854      	adds	r4, r2, r1
d0081b3e:	42a3      	cmp	r3, r4
d0081b40:	6011      	str	r1, [r2, #0]
d0081b42:	d1dd      	bne.n	d0081b00 <_free_r+0x28>
d0081b44:	681c      	ldr	r4, [r3, #0]
d0081b46:	685b      	ldr	r3, [r3, #4]
d0081b48:	6053      	str	r3, [r2, #4]
d0081b4a:	4421      	add	r1, r4
d0081b4c:	6011      	str	r1, [r2, #0]
d0081b4e:	e7d7      	b.n	d0081b00 <_free_r+0x28>
d0081b50:	d902      	bls.n	d0081b58 <_free_r+0x80>
d0081b52:	230c      	movs	r3, #12
d0081b54:	6003      	str	r3, [r0, #0]
d0081b56:	e7d3      	b.n	d0081b00 <_free_r+0x28>
d0081b58:	6825      	ldr	r5, [r4, #0]
d0081b5a:	1961      	adds	r1, r4, r5
d0081b5c:	428b      	cmp	r3, r1
d0081b5e:	bf04      	itt	eq
d0081b60:	6819      	ldreq	r1, [r3, #0]
d0081b62:	685b      	ldreq	r3, [r3, #4]
d0081b64:	6063      	str	r3, [r4, #4]
d0081b66:	bf04      	itt	eq
d0081b68:	1949      	addeq	r1, r1, r5
d0081b6a:	6021      	streq	r1, [r4, #0]
d0081b6c:	6054      	str	r4, [r2, #4]
d0081b6e:	e7c7      	b.n	d0081b00 <_free_r+0x28>
d0081b70:	b003      	add	sp, #12
d0081b72:	bd30      	pop	{r4, r5, pc}
d0081b74:	d0089500 	.word	0xd0089500

d0081b78 <_malloc_r>:
d0081b78:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0081b7a:	1ccd      	adds	r5, r1, #3
d0081b7c:	f025 0503 	bic.w	r5, r5, #3
d0081b80:	3508      	adds	r5, #8
d0081b82:	2d0c      	cmp	r5, #12
d0081b84:	bf38      	it	cc
d0081b86:	250c      	movcc	r5, #12
d0081b88:	2d00      	cmp	r5, #0
d0081b8a:	4606      	mov	r6, r0
d0081b8c:	db01      	blt.n	d0081b92 <_malloc_r+0x1a>
d0081b8e:	42a9      	cmp	r1, r5
d0081b90:	d903      	bls.n	d0081b9a <_malloc_r+0x22>
d0081b92:	230c      	movs	r3, #12
d0081b94:	6033      	str	r3, [r6, #0]
d0081b96:	2000      	movs	r0, #0
d0081b98:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0081b9a:	f000 fb4b 	bl	d0082234 <__malloc_lock>
d0081b9e:	4921      	ldr	r1, [pc, #132]	; (d0081c24 <_malloc_r+0xac>)
d0081ba0:	680a      	ldr	r2, [r1, #0]
d0081ba2:	4614      	mov	r4, r2
d0081ba4:	b99c      	cbnz	r4, d0081bce <_malloc_r+0x56>
d0081ba6:	4f20      	ldr	r7, [pc, #128]	; (d0081c28 <_malloc_r+0xb0>)
d0081ba8:	683b      	ldr	r3, [r7, #0]
d0081baa:	b923      	cbnz	r3, d0081bb6 <_malloc_r+0x3e>
d0081bac:	4621      	mov	r1, r4
d0081bae:	4630      	mov	r0, r6
d0081bb0:	f7fe faa4 	bl	d00800fc <_sbrk_r>
d0081bb4:	6038      	str	r0, [r7, #0]
d0081bb6:	4629      	mov	r1, r5
d0081bb8:	4630      	mov	r0, r6
d0081bba:	f7fe fa9f 	bl	d00800fc <_sbrk_r>
d0081bbe:	1c43      	adds	r3, r0, #1
d0081bc0:	d123      	bne.n	d0081c0a <_malloc_r+0x92>
d0081bc2:	230c      	movs	r3, #12
d0081bc4:	6033      	str	r3, [r6, #0]
d0081bc6:	4630      	mov	r0, r6
d0081bc8:	f000 fb3a 	bl	d0082240 <__malloc_unlock>
d0081bcc:	e7e3      	b.n	d0081b96 <_malloc_r+0x1e>
d0081bce:	6823      	ldr	r3, [r4, #0]
d0081bd0:	1b5b      	subs	r3, r3, r5
d0081bd2:	d417      	bmi.n	d0081c04 <_malloc_r+0x8c>
d0081bd4:	2b0b      	cmp	r3, #11
d0081bd6:	d903      	bls.n	d0081be0 <_malloc_r+0x68>
d0081bd8:	6023      	str	r3, [r4, #0]
d0081bda:	441c      	add	r4, r3
d0081bdc:	6025      	str	r5, [r4, #0]
d0081bde:	e004      	b.n	d0081bea <_malloc_r+0x72>
d0081be0:	6863      	ldr	r3, [r4, #4]
d0081be2:	42a2      	cmp	r2, r4
d0081be4:	bf0c      	ite	eq
d0081be6:	600b      	streq	r3, [r1, #0]
d0081be8:	6053      	strne	r3, [r2, #4]
d0081bea:	4630      	mov	r0, r6
d0081bec:	f000 fb28 	bl	d0082240 <__malloc_unlock>
d0081bf0:	f104 000b 	add.w	r0, r4, #11
d0081bf4:	1d23      	adds	r3, r4, #4
d0081bf6:	f020 0007 	bic.w	r0, r0, #7
d0081bfa:	1ac2      	subs	r2, r0, r3
d0081bfc:	d0cc      	beq.n	d0081b98 <_malloc_r+0x20>
d0081bfe:	1a1b      	subs	r3, r3, r0
d0081c00:	50a3      	str	r3, [r4, r2]
d0081c02:	e7c9      	b.n	d0081b98 <_malloc_r+0x20>
d0081c04:	4622      	mov	r2, r4
d0081c06:	6864      	ldr	r4, [r4, #4]
d0081c08:	e7cc      	b.n	d0081ba4 <_malloc_r+0x2c>
d0081c0a:	1cc4      	adds	r4, r0, #3
d0081c0c:	f024 0403 	bic.w	r4, r4, #3
d0081c10:	42a0      	cmp	r0, r4
d0081c12:	d0e3      	beq.n	d0081bdc <_malloc_r+0x64>
d0081c14:	1a21      	subs	r1, r4, r0
d0081c16:	4630      	mov	r0, r6
d0081c18:	f7fe fa70 	bl	d00800fc <_sbrk_r>
d0081c1c:	3001      	adds	r0, #1
d0081c1e:	d1dd      	bne.n	d0081bdc <_malloc_r+0x64>
d0081c20:	e7cf      	b.n	d0081bc2 <_malloc_r+0x4a>
d0081c22:	bf00      	nop
d0081c24:	d0089500 	.word	0xd0089500
d0081c28:	d0089504 	.word	0xd0089504

d0081c2c <iprintf>:
d0081c2c:	b40f      	push	{r0, r1, r2, r3}
d0081c2e:	4b0a      	ldr	r3, [pc, #40]	; (d0081c58 <iprintf+0x2c>)
d0081c30:	b513      	push	{r0, r1, r4, lr}
d0081c32:	681c      	ldr	r4, [r3, #0]
d0081c34:	b124      	cbz	r4, d0081c40 <iprintf+0x14>
d0081c36:	69a3      	ldr	r3, [r4, #24]
d0081c38:	b913      	cbnz	r3, d0081c40 <iprintf+0x14>
d0081c3a:	4620      	mov	r0, r4
d0081c3c:	f000 f9f6 	bl	d008202c <__sinit>
d0081c40:	ab05      	add	r3, sp, #20
d0081c42:	9a04      	ldr	r2, [sp, #16]
d0081c44:	68a1      	ldr	r1, [r4, #8]
d0081c46:	9301      	str	r3, [sp, #4]
d0081c48:	4620      	mov	r0, r4
d0081c4a:	f000 fb29 	bl	d00822a0 <_vfiprintf_r>
d0081c4e:	b002      	add	sp, #8
d0081c50:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d0081c54:	b004      	add	sp, #16
d0081c56:	4770      	bx	lr
d0081c58:	d008775c 	.word	0xd008775c

d0081c5c <setbuf>:
d0081c5c:	2900      	cmp	r1, #0
d0081c5e:	f44f 6380 	mov.w	r3, #1024	; 0x400
d0081c62:	bf0c      	ite	eq
d0081c64:	2202      	moveq	r2, #2
d0081c66:	2200      	movne	r2, #0
d0081c68:	f000 b800 	b.w	d0081c6c <setvbuf>

d0081c6c <setvbuf>:
d0081c6c:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d0081c70:	461d      	mov	r5, r3
d0081c72:	4b5d      	ldr	r3, [pc, #372]	; (d0081de8 <setvbuf+0x17c>)
d0081c74:	681f      	ldr	r7, [r3, #0]
d0081c76:	4604      	mov	r4, r0
d0081c78:	460e      	mov	r6, r1
d0081c7a:	4690      	mov	r8, r2
d0081c7c:	b127      	cbz	r7, d0081c88 <setvbuf+0x1c>
d0081c7e:	69bb      	ldr	r3, [r7, #24]
d0081c80:	b913      	cbnz	r3, d0081c88 <setvbuf+0x1c>
d0081c82:	4638      	mov	r0, r7
d0081c84:	f000 f9d2 	bl	d008202c <__sinit>
d0081c88:	4b58      	ldr	r3, [pc, #352]	; (d0081dec <setvbuf+0x180>)
d0081c8a:	429c      	cmp	r4, r3
d0081c8c:	d167      	bne.n	d0081d5e <setvbuf+0xf2>
d0081c8e:	687c      	ldr	r4, [r7, #4]
d0081c90:	f1b8 0f02 	cmp.w	r8, #2
d0081c94:	d006      	beq.n	d0081ca4 <setvbuf+0x38>
d0081c96:	f1b8 0f01 	cmp.w	r8, #1
d0081c9a:	f200 809f 	bhi.w	d0081ddc <setvbuf+0x170>
d0081c9e:	2d00      	cmp	r5, #0
d0081ca0:	f2c0 809c 	blt.w	d0081ddc <setvbuf+0x170>
d0081ca4:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0081ca6:	07db      	lsls	r3, r3, #31
d0081ca8:	d405      	bmi.n	d0081cb6 <setvbuf+0x4a>
d0081caa:	89a3      	ldrh	r3, [r4, #12]
d0081cac:	0598      	lsls	r0, r3, #22
d0081cae:	d402      	bmi.n	d0081cb6 <setvbuf+0x4a>
d0081cb0:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0081cb2:	f000 fa59 	bl	d0082168 <__retarget_lock_acquire_recursive>
d0081cb6:	4621      	mov	r1, r4
d0081cb8:	4638      	mov	r0, r7
d0081cba:	f000 f923 	bl	d0081f04 <_fflush_r>
d0081cbe:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0081cc0:	b141      	cbz	r1, d0081cd4 <setvbuf+0x68>
d0081cc2:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0081cc6:	4299      	cmp	r1, r3
d0081cc8:	d002      	beq.n	d0081cd0 <setvbuf+0x64>
d0081cca:	4638      	mov	r0, r7
d0081ccc:	f7ff ff04 	bl	d0081ad8 <_free_r>
d0081cd0:	2300      	movs	r3, #0
d0081cd2:	6363      	str	r3, [r4, #52]	; 0x34
d0081cd4:	2300      	movs	r3, #0
d0081cd6:	61a3      	str	r3, [r4, #24]
d0081cd8:	6063      	str	r3, [r4, #4]
d0081cda:	89a3      	ldrh	r3, [r4, #12]
d0081cdc:	0619      	lsls	r1, r3, #24
d0081cde:	d503      	bpl.n	d0081ce8 <setvbuf+0x7c>
d0081ce0:	6921      	ldr	r1, [r4, #16]
d0081ce2:	4638      	mov	r0, r7
d0081ce4:	f7ff fef8 	bl	d0081ad8 <_free_r>
d0081ce8:	89a3      	ldrh	r3, [r4, #12]
d0081cea:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d0081cee:	f023 0303 	bic.w	r3, r3, #3
d0081cf2:	f1b8 0f02 	cmp.w	r8, #2
d0081cf6:	81a3      	strh	r3, [r4, #12]
d0081cf8:	d06c      	beq.n	d0081dd4 <setvbuf+0x168>
d0081cfa:	ab01      	add	r3, sp, #4
d0081cfc:	466a      	mov	r2, sp
d0081cfe:	4621      	mov	r1, r4
d0081d00:	4638      	mov	r0, r7
d0081d02:	f000 fa33 	bl	d008216c <__swhatbuf_r>
d0081d06:	89a3      	ldrh	r3, [r4, #12]
d0081d08:	4318      	orrs	r0, r3
d0081d0a:	81a0      	strh	r0, [r4, #12]
d0081d0c:	2d00      	cmp	r5, #0
d0081d0e:	d130      	bne.n	d0081d72 <setvbuf+0x106>
d0081d10:	9d00      	ldr	r5, [sp, #0]
d0081d12:	4628      	mov	r0, r5
d0081d14:	f7ff fed0 	bl	d0081ab8 <malloc>
d0081d18:	4606      	mov	r6, r0
d0081d1a:	2800      	cmp	r0, #0
d0081d1c:	d155      	bne.n	d0081dca <setvbuf+0x15e>
d0081d1e:	f8dd 9000 	ldr.w	r9, [sp]
d0081d22:	45a9      	cmp	r9, r5
d0081d24:	d14a      	bne.n	d0081dbc <setvbuf+0x150>
d0081d26:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0081d2a:	2200      	movs	r2, #0
d0081d2c:	60a2      	str	r2, [r4, #8]
d0081d2e:	f104 0247 	add.w	r2, r4, #71	; 0x47
d0081d32:	6022      	str	r2, [r4, #0]
d0081d34:	6122      	str	r2, [r4, #16]
d0081d36:	2201      	movs	r2, #1
d0081d38:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0081d3c:	6162      	str	r2, [r4, #20]
d0081d3e:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0081d40:	f043 0302 	orr.w	r3, r3, #2
d0081d44:	07d2      	lsls	r2, r2, #31
d0081d46:	81a3      	strh	r3, [r4, #12]
d0081d48:	d405      	bmi.n	d0081d56 <setvbuf+0xea>
d0081d4a:	f413 7f00 	tst.w	r3, #512	; 0x200
d0081d4e:	d102      	bne.n	d0081d56 <setvbuf+0xea>
d0081d50:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0081d52:	f000 fa0a 	bl	d008216a <__retarget_lock_release_recursive>
d0081d56:	4628      	mov	r0, r5
d0081d58:	b003      	add	sp, #12
d0081d5a:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0081d5e:	4b24      	ldr	r3, [pc, #144]	; (d0081df0 <setvbuf+0x184>)
d0081d60:	429c      	cmp	r4, r3
d0081d62:	d101      	bne.n	d0081d68 <setvbuf+0xfc>
d0081d64:	68bc      	ldr	r4, [r7, #8]
d0081d66:	e793      	b.n	d0081c90 <setvbuf+0x24>
d0081d68:	4b22      	ldr	r3, [pc, #136]	; (d0081df4 <setvbuf+0x188>)
d0081d6a:	429c      	cmp	r4, r3
d0081d6c:	bf08      	it	eq
d0081d6e:	68fc      	ldreq	r4, [r7, #12]
d0081d70:	e78e      	b.n	d0081c90 <setvbuf+0x24>
d0081d72:	2e00      	cmp	r6, #0
d0081d74:	d0cd      	beq.n	d0081d12 <setvbuf+0xa6>
d0081d76:	69bb      	ldr	r3, [r7, #24]
d0081d78:	b913      	cbnz	r3, d0081d80 <setvbuf+0x114>
d0081d7a:	4638      	mov	r0, r7
d0081d7c:	f000 f956 	bl	d008202c <__sinit>
d0081d80:	f1b8 0f01 	cmp.w	r8, #1
d0081d84:	bf08      	it	eq
d0081d86:	89a3      	ldrheq	r3, [r4, #12]
d0081d88:	6026      	str	r6, [r4, #0]
d0081d8a:	bf04      	itt	eq
d0081d8c:	f043 0301 	orreq.w	r3, r3, #1
d0081d90:	81a3      	strheq	r3, [r4, #12]
d0081d92:	89a2      	ldrh	r2, [r4, #12]
d0081d94:	f012 0308 	ands.w	r3, r2, #8
d0081d98:	e9c4 6504 	strd	r6, r5, [r4, #16]
d0081d9c:	d01c      	beq.n	d0081dd8 <setvbuf+0x16c>
d0081d9e:	07d3      	lsls	r3, r2, #31
d0081da0:	bf41      	itttt	mi
d0081da2:	2300      	movmi	r3, #0
d0081da4:	426d      	negmi	r5, r5
d0081da6:	60a3      	strmi	r3, [r4, #8]
d0081da8:	61a5      	strmi	r5, [r4, #24]
d0081daa:	bf58      	it	pl
d0081dac:	60a5      	strpl	r5, [r4, #8]
d0081dae:	6e65      	ldr	r5, [r4, #100]	; 0x64
d0081db0:	f015 0501 	ands.w	r5, r5, #1
d0081db4:	d115      	bne.n	d0081de2 <setvbuf+0x176>
d0081db6:	f412 7f00 	tst.w	r2, #512	; 0x200
d0081dba:	e7c8      	b.n	d0081d4e <setvbuf+0xe2>
d0081dbc:	4648      	mov	r0, r9
d0081dbe:	f7ff fe7b 	bl	d0081ab8 <malloc>
d0081dc2:	4606      	mov	r6, r0
d0081dc4:	2800      	cmp	r0, #0
d0081dc6:	d0ae      	beq.n	d0081d26 <setvbuf+0xba>
d0081dc8:	464d      	mov	r5, r9
d0081dca:	89a3      	ldrh	r3, [r4, #12]
d0081dcc:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0081dd0:	81a3      	strh	r3, [r4, #12]
d0081dd2:	e7d0      	b.n	d0081d76 <setvbuf+0x10a>
d0081dd4:	2500      	movs	r5, #0
d0081dd6:	e7a8      	b.n	d0081d2a <setvbuf+0xbe>
d0081dd8:	60a3      	str	r3, [r4, #8]
d0081dda:	e7e8      	b.n	d0081dae <setvbuf+0x142>
d0081ddc:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0081de0:	e7b9      	b.n	d0081d56 <setvbuf+0xea>
d0081de2:	2500      	movs	r5, #0
d0081de4:	e7b7      	b.n	d0081d56 <setvbuf+0xea>
d0081de6:	bf00      	nop
d0081de8:	d008775c 	.word	0xd008775c
d0081dec:	d00876d4 	.word	0xd00876d4
d0081df0:	d00876f4 	.word	0xd00876f4
d0081df4:	d00876b4 	.word	0xd00876b4

d0081df8 <__sflush_r>:
d0081df8:	898a      	ldrh	r2, [r1, #12]
d0081dfa:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0081dfe:	4605      	mov	r5, r0
d0081e00:	0710      	lsls	r0, r2, #28
d0081e02:	460c      	mov	r4, r1
d0081e04:	d458      	bmi.n	d0081eb8 <__sflush_r+0xc0>
d0081e06:	684b      	ldr	r3, [r1, #4]
d0081e08:	2b00      	cmp	r3, #0
d0081e0a:	dc05      	bgt.n	d0081e18 <__sflush_r+0x20>
d0081e0c:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d0081e0e:	2b00      	cmp	r3, #0
d0081e10:	dc02      	bgt.n	d0081e18 <__sflush_r+0x20>
d0081e12:	2000      	movs	r0, #0
d0081e14:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0081e18:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0081e1a:	2e00      	cmp	r6, #0
d0081e1c:	d0f9      	beq.n	d0081e12 <__sflush_r+0x1a>
d0081e1e:	2300      	movs	r3, #0
d0081e20:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d0081e24:	682f      	ldr	r7, [r5, #0]
d0081e26:	602b      	str	r3, [r5, #0]
d0081e28:	d032      	beq.n	d0081e90 <__sflush_r+0x98>
d0081e2a:	6d60      	ldr	r0, [r4, #84]	; 0x54
d0081e2c:	89a3      	ldrh	r3, [r4, #12]
d0081e2e:	075a      	lsls	r2, r3, #29
d0081e30:	d505      	bpl.n	d0081e3e <__sflush_r+0x46>
d0081e32:	6863      	ldr	r3, [r4, #4]
d0081e34:	1ac0      	subs	r0, r0, r3
d0081e36:	6b63      	ldr	r3, [r4, #52]	; 0x34
d0081e38:	b10b      	cbz	r3, d0081e3e <__sflush_r+0x46>
d0081e3a:	6c23      	ldr	r3, [r4, #64]	; 0x40
d0081e3c:	1ac0      	subs	r0, r0, r3
d0081e3e:	2300      	movs	r3, #0
d0081e40:	4602      	mov	r2, r0
d0081e42:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0081e44:	6a21      	ldr	r1, [r4, #32]
d0081e46:	4628      	mov	r0, r5
d0081e48:	47b0      	blx	r6
d0081e4a:	1c43      	adds	r3, r0, #1
d0081e4c:	89a3      	ldrh	r3, [r4, #12]
d0081e4e:	d106      	bne.n	d0081e5e <__sflush_r+0x66>
d0081e50:	6829      	ldr	r1, [r5, #0]
d0081e52:	291d      	cmp	r1, #29
d0081e54:	d82c      	bhi.n	d0081eb0 <__sflush_r+0xb8>
d0081e56:	4a2a      	ldr	r2, [pc, #168]	; (d0081f00 <__sflush_r+0x108>)
d0081e58:	40ca      	lsrs	r2, r1
d0081e5a:	07d6      	lsls	r6, r2, #31
d0081e5c:	d528      	bpl.n	d0081eb0 <__sflush_r+0xb8>
d0081e5e:	2200      	movs	r2, #0
d0081e60:	6062      	str	r2, [r4, #4]
d0081e62:	04d9      	lsls	r1, r3, #19
d0081e64:	6922      	ldr	r2, [r4, #16]
d0081e66:	6022      	str	r2, [r4, #0]
d0081e68:	d504      	bpl.n	d0081e74 <__sflush_r+0x7c>
d0081e6a:	1c42      	adds	r2, r0, #1
d0081e6c:	d101      	bne.n	d0081e72 <__sflush_r+0x7a>
d0081e6e:	682b      	ldr	r3, [r5, #0]
d0081e70:	b903      	cbnz	r3, d0081e74 <__sflush_r+0x7c>
d0081e72:	6560      	str	r0, [r4, #84]	; 0x54
d0081e74:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0081e76:	602f      	str	r7, [r5, #0]
d0081e78:	2900      	cmp	r1, #0
d0081e7a:	d0ca      	beq.n	d0081e12 <__sflush_r+0x1a>
d0081e7c:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0081e80:	4299      	cmp	r1, r3
d0081e82:	d002      	beq.n	d0081e8a <__sflush_r+0x92>
d0081e84:	4628      	mov	r0, r5
d0081e86:	f7ff fe27 	bl	d0081ad8 <_free_r>
d0081e8a:	2000      	movs	r0, #0
d0081e8c:	6360      	str	r0, [r4, #52]	; 0x34
d0081e8e:	e7c1      	b.n	d0081e14 <__sflush_r+0x1c>
d0081e90:	6a21      	ldr	r1, [r4, #32]
d0081e92:	2301      	movs	r3, #1
d0081e94:	4628      	mov	r0, r5
d0081e96:	47b0      	blx	r6
d0081e98:	1c41      	adds	r1, r0, #1
d0081e9a:	d1c7      	bne.n	d0081e2c <__sflush_r+0x34>
d0081e9c:	682b      	ldr	r3, [r5, #0]
d0081e9e:	2b00      	cmp	r3, #0
d0081ea0:	d0c4      	beq.n	d0081e2c <__sflush_r+0x34>
d0081ea2:	2b1d      	cmp	r3, #29
d0081ea4:	d001      	beq.n	d0081eaa <__sflush_r+0xb2>
d0081ea6:	2b16      	cmp	r3, #22
d0081ea8:	d101      	bne.n	d0081eae <__sflush_r+0xb6>
d0081eaa:	602f      	str	r7, [r5, #0]
d0081eac:	e7b1      	b.n	d0081e12 <__sflush_r+0x1a>
d0081eae:	89a3      	ldrh	r3, [r4, #12]
d0081eb0:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0081eb4:	81a3      	strh	r3, [r4, #12]
d0081eb6:	e7ad      	b.n	d0081e14 <__sflush_r+0x1c>
d0081eb8:	690f      	ldr	r7, [r1, #16]
d0081eba:	2f00      	cmp	r7, #0
d0081ebc:	d0a9      	beq.n	d0081e12 <__sflush_r+0x1a>
d0081ebe:	0793      	lsls	r3, r2, #30
d0081ec0:	680e      	ldr	r6, [r1, #0]
d0081ec2:	bf08      	it	eq
d0081ec4:	694b      	ldreq	r3, [r1, #20]
d0081ec6:	600f      	str	r7, [r1, #0]
d0081ec8:	bf18      	it	ne
d0081eca:	2300      	movne	r3, #0
d0081ecc:	eba6 0807 	sub.w	r8, r6, r7
d0081ed0:	608b      	str	r3, [r1, #8]
d0081ed2:	f1b8 0f00 	cmp.w	r8, #0
d0081ed6:	dd9c      	ble.n	d0081e12 <__sflush_r+0x1a>
d0081ed8:	6a21      	ldr	r1, [r4, #32]
d0081eda:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d0081edc:	4643      	mov	r3, r8
d0081ede:	463a      	mov	r2, r7
d0081ee0:	4628      	mov	r0, r5
d0081ee2:	47b0      	blx	r6
d0081ee4:	2800      	cmp	r0, #0
d0081ee6:	dc06      	bgt.n	d0081ef6 <__sflush_r+0xfe>
d0081ee8:	89a3      	ldrh	r3, [r4, #12]
d0081eea:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0081eee:	81a3      	strh	r3, [r4, #12]
d0081ef0:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0081ef4:	e78e      	b.n	d0081e14 <__sflush_r+0x1c>
d0081ef6:	4407      	add	r7, r0
d0081ef8:	eba8 0800 	sub.w	r8, r8, r0
d0081efc:	e7e9      	b.n	d0081ed2 <__sflush_r+0xda>
d0081efe:	bf00      	nop
d0081f00:	20400001 	.word	0x20400001

d0081f04 <_fflush_r>:
d0081f04:	b538      	push	{r3, r4, r5, lr}
d0081f06:	690b      	ldr	r3, [r1, #16]
d0081f08:	4605      	mov	r5, r0
d0081f0a:	460c      	mov	r4, r1
d0081f0c:	b913      	cbnz	r3, d0081f14 <_fflush_r+0x10>
d0081f0e:	2500      	movs	r5, #0
d0081f10:	4628      	mov	r0, r5
d0081f12:	bd38      	pop	{r3, r4, r5, pc}
d0081f14:	b118      	cbz	r0, d0081f1e <_fflush_r+0x1a>
d0081f16:	6983      	ldr	r3, [r0, #24]
d0081f18:	b90b      	cbnz	r3, d0081f1e <_fflush_r+0x1a>
d0081f1a:	f000 f887 	bl	d008202c <__sinit>
d0081f1e:	4b14      	ldr	r3, [pc, #80]	; (d0081f70 <_fflush_r+0x6c>)
d0081f20:	429c      	cmp	r4, r3
d0081f22:	d11b      	bne.n	d0081f5c <_fflush_r+0x58>
d0081f24:	686c      	ldr	r4, [r5, #4]
d0081f26:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0081f2a:	2b00      	cmp	r3, #0
d0081f2c:	d0ef      	beq.n	d0081f0e <_fflush_r+0xa>
d0081f2e:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0081f30:	07d0      	lsls	r0, r2, #31
d0081f32:	d404      	bmi.n	d0081f3e <_fflush_r+0x3a>
d0081f34:	0599      	lsls	r1, r3, #22
d0081f36:	d402      	bmi.n	d0081f3e <_fflush_r+0x3a>
d0081f38:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0081f3a:	f000 f915 	bl	d0082168 <__retarget_lock_acquire_recursive>
d0081f3e:	4628      	mov	r0, r5
d0081f40:	4621      	mov	r1, r4
d0081f42:	f7ff ff59 	bl	d0081df8 <__sflush_r>
d0081f46:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0081f48:	07da      	lsls	r2, r3, #31
d0081f4a:	4605      	mov	r5, r0
d0081f4c:	d4e0      	bmi.n	d0081f10 <_fflush_r+0xc>
d0081f4e:	89a3      	ldrh	r3, [r4, #12]
d0081f50:	059b      	lsls	r3, r3, #22
d0081f52:	d4dd      	bmi.n	d0081f10 <_fflush_r+0xc>
d0081f54:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0081f56:	f000 f908 	bl	d008216a <__retarget_lock_release_recursive>
d0081f5a:	e7d9      	b.n	d0081f10 <_fflush_r+0xc>
d0081f5c:	4b05      	ldr	r3, [pc, #20]	; (d0081f74 <_fflush_r+0x70>)
d0081f5e:	429c      	cmp	r4, r3
d0081f60:	d101      	bne.n	d0081f66 <_fflush_r+0x62>
d0081f62:	68ac      	ldr	r4, [r5, #8]
d0081f64:	e7df      	b.n	d0081f26 <_fflush_r+0x22>
d0081f66:	4b04      	ldr	r3, [pc, #16]	; (d0081f78 <_fflush_r+0x74>)
d0081f68:	429c      	cmp	r4, r3
d0081f6a:	bf08      	it	eq
d0081f6c:	68ec      	ldreq	r4, [r5, #12]
d0081f6e:	e7da      	b.n	d0081f26 <_fflush_r+0x22>
d0081f70:	d00876d4 	.word	0xd00876d4
d0081f74:	d00876f4 	.word	0xd00876f4
d0081f78:	d00876b4 	.word	0xd00876b4

d0081f7c <std>:
d0081f7c:	2300      	movs	r3, #0
d0081f7e:	b510      	push	{r4, lr}
d0081f80:	4604      	mov	r4, r0
d0081f82:	e9c0 3300 	strd	r3, r3, [r0]
d0081f86:	e9c0 3304 	strd	r3, r3, [r0, #16]
d0081f8a:	6083      	str	r3, [r0, #8]
d0081f8c:	8181      	strh	r1, [r0, #12]
d0081f8e:	6643      	str	r3, [r0, #100]	; 0x64
d0081f90:	81c2      	strh	r2, [r0, #14]
d0081f92:	6183      	str	r3, [r0, #24]
d0081f94:	4619      	mov	r1, r3
d0081f96:	2208      	movs	r2, #8
d0081f98:	305c      	adds	r0, #92	; 0x5c
d0081f9a:	f7ff fd95 	bl	d0081ac8 <memset>
d0081f9e:	4b05      	ldr	r3, [pc, #20]	; (d0081fb4 <std+0x38>)
d0081fa0:	6263      	str	r3, [r4, #36]	; 0x24
d0081fa2:	4b05      	ldr	r3, [pc, #20]	; (d0081fb8 <std+0x3c>)
d0081fa4:	62a3      	str	r3, [r4, #40]	; 0x28
d0081fa6:	4b05      	ldr	r3, [pc, #20]	; (d0081fbc <std+0x40>)
d0081fa8:	62e3      	str	r3, [r4, #44]	; 0x2c
d0081faa:	4b05      	ldr	r3, [pc, #20]	; (d0081fc0 <std+0x44>)
d0081fac:	6224      	str	r4, [r4, #32]
d0081fae:	6323      	str	r3, [r4, #48]	; 0x30
d0081fb0:	bd10      	pop	{r4, pc}
d0081fb2:	bf00      	nop
d0081fb4:	d0082829 	.word	0xd0082829
d0081fb8:	d008284b 	.word	0xd008284b
d0081fbc:	d0082883 	.word	0xd0082883
d0081fc0:	d00828a7 	.word	0xd00828a7

d0081fc4 <_cleanup_r>:
d0081fc4:	4901      	ldr	r1, [pc, #4]	; (d0081fcc <_cleanup_r+0x8>)
d0081fc6:	f000 b8af 	b.w	d0082128 <_fwalk_reent>
d0081fca:	bf00      	nop
d0081fcc:	d0081f05 	.word	0xd0081f05

d0081fd0 <__sfmoreglue>:
d0081fd0:	b570      	push	{r4, r5, r6, lr}
d0081fd2:	1e4a      	subs	r2, r1, #1
d0081fd4:	2568      	movs	r5, #104	; 0x68
d0081fd6:	4355      	muls	r5, r2
d0081fd8:	460e      	mov	r6, r1
d0081fda:	f105 0174 	add.w	r1, r5, #116	; 0x74
d0081fde:	f7ff fdcb 	bl	d0081b78 <_malloc_r>
d0081fe2:	4604      	mov	r4, r0
d0081fe4:	b140      	cbz	r0, d0081ff8 <__sfmoreglue+0x28>
d0081fe6:	2100      	movs	r1, #0
d0081fe8:	e9c0 1600 	strd	r1, r6, [r0]
d0081fec:	300c      	adds	r0, #12
d0081fee:	60a0      	str	r0, [r4, #8]
d0081ff0:	f105 0268 	add.w	r2, r5, #104	; 0x68
d0081ff4:	f7ff fd68 	bl	d0081ac8 <memset>
d0081ff8:	4620      	mov	r0, r4
d0081ffa:	bd70      	pop	{r4, r5, r6, pc}

d0081ffc <__sfp_lock_acquire>:
d0081ffc:	4801      	ldr	r0, [pc, #4]	; (d0082004 <__sfp_lock_acquire+0x8>)
d0081ffe:	f000 b8b3 	b.w	d0082168 <__retarget_lock_acquire_recursive>
d0082002:	bf00      	nop
d0082004:	d0089514 	.word	0xd0089514

d0082008 <__sfp_lock_release>:
d0082008:	4801      	ldr	r0, [pc, #4]	; (d0082010 <__sfp_lock_release+0x8>)
d008200a:	f000 b8ae 	b.w	d008216a <__retarget_lock_release_recursive>
d008200e:	bf00      	nop
d0082010:	d0089514 	.word	0xd0089514

d0082014 <__sinit_lock_acquire>:
d0082014:	4801      	ldr	r0, [pc, #4]	; (d008201c <__sinit_lock_acquire+0x8>)
d0082016:	f000 b8a7 	b.w	d0082168 <__retarget_lock_acquire_recursive>
d008201a:	bf00      	nop
d008201c:	d008950f 	.word	0xd008950f

d0082020 <__sinit_lock_release>:
d0082020:	4801      	ldr	r0, [pc, #4]	; (d0082028 <__sinit_lock_release+0x8>)
d0082022:	f000 b8a2 	b.w	d008216a <__retarget_lock_release_recursive>
d0082026:	bf00      	nop
d0082028:	d008950f 	.word	0xd008950f

d008202c <__sinit>:
d008202c:	b510      	push	{r4, lr}
d008202e:	4604      	mov	r4, r0
d0082030:	f7ff fff0 	bl	d0082014 <__sinit_lock_acquire>
d0082034:	69a3      	ldr	r3, [r4, #24]
d0082036:	b11b      	cbz	r3, d0082040 <__sinit+0x14>
d0082038:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d008203c:	f7ff bff0 	b.w	d0082020 <__sinit_lock_release>
d0082040:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d0082044:	6523      	str	r3, [r4, #80]	; 0x50
d0082046:	4b13      	ldr	r3, [pc, #76]	; (d0082094 <__sinit+0x68>)
d0082048:	4a13      	ldr	r2, [pc, #76]	; (d0082098 <__sinit+0x6c>)
d008204a:	681b      	ldr	r3, [r3, #0]
d008204c:	62a2      	str	r2, [r4, #40]	; 0x28
d008204e:	42a3      	cmp	r3, r4
d0082050:	bf04      	itt	eq
d0082052:	2301      	moveq	r3, #1
d0082054:	61a3      	streq	r3, [r4, #24]
d0082056:	4620      	mov	r0, r4
d0082058:	f000 f820 	bl	d008209c <__sfp>
d008205c:	6060      	str	r0, [r4, #4]
d008205e:	4620      	mov	r0, r4
d0082060:	f000 f81c 	bl	d008209c <__sfp>
d0082064:	60a0      	str	r0, [r4, #8]
d0082066:	4620      	mov	r0, r4
d0082068:	f000 f818 	bl	d008209c <__sfp>
d008206c:	2200      	movs	r2, #0
d008206e:	60e0      	str	r0, [r4, #12]
d0082070:	2104      	movs	r1, #4
d0082072:	6860      	ldr	r0, [r4, #4]
d0082074:	f7ff ff82 	bl	d0081f7c <std>
d0082078:	68a0      	ldr	r0, [r4, #8]
d008207a:	2201      	movs	r2, #1
d008207c:	2109      	movs	r1, #9
d008207e:	f7ff ff7d 	bl	d0081f7c <std>
d0082082:	68e0      	ldr	r0, [r4, #12]
d0082084:	2202      	movs	r2, #2
d0082086:	2112      	movs	r1, #18
d0082088:	f7ff ff78 	bl	d0081f7c <std>
d008208c:	2301      	movs	r3, #1
d008208e:	61a3      	str	r3, [r4, #24]
d0082090:	e7d2      	b.n	d0082038 <__sinit+0xc>
d0082092:	bf00      	nop
d0082094:	d00876b0 	.word	0xd00876b0
d0082098:	d0081fc5 	.word	0xd0081fc5

d008209c <__sfp>:
d008209c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008209e:	4607      	mov	r7, r0
d00820a0:	f7ff ffac 	bl	d0081ffc <__sfp_lock_acquire>
d00820a4:	4b1e      	ldr	r3, [pc, #120]	; (d0082120 <__sfp+0x84>)
d00820a6:	681e      	ldr	r6, [r3, #0]
d00820a8:	69b3      	ldr	r3, [r6, #24]
d00820aa:	b913      	cbnz	r3, d00820b2 <__sfp+0x16>
d00820ac:	4630      	mov	r0, r6
d00820ae:	f7ff ffbd 	bl	d008202c <__sinit>
d00820b2:	3648      	adds	r6, #72	; 0x48
d00820b4:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d00820b8:	3b01      	subs	r3, #1
d00820ba:	d503      	bpl.n	d00820c4 <__sfp+0x28>
d00820bc:	6833      	ldr	r3, [r6, #0]
d00820be:	b30b      	cbz	r3, d0082104 <__sfp+0x68>
d00820c0:	6836      	ldr	r6, [r6, #0]
d00820c2:	e7f7      	b.n	d00820b4 <__sfp+0x18>
d00820c4:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d00820c8:	b9d5      	cbnz	r5, d0082100 <__sfp+0x64>
d00820ca:	4b16      	ldr	r3, [pc, #88]	; (d0082124 <__sfp+0x88>)
d00820cc:	60e3      	str	r3, [r4, #12]
d00820ce:	f104 0058 	add.w	r0, r4, #88	; 0x58
d00820d2:	6665      	str	r5, [r4, #100]	; 0x64
d00820d4:	f000 f847 	bl	d0082166 <__retarget_lock_init_recursive>
d00820d8:	f7ff ff96 	bl	d0082008 <__sfp_lock_release>
d00820dc:	e9c4 5501 	strd	r5, r5, [r4, #4]
d00820e0:	e9c4 5504 	strd	r5, r5, [r4, #16]
d00820e4:	6025      	str	r5, [r4, #0]
d00820e6:	61a5      	str	r5, [r4, #24]
d00820e8:	2208      	movs	r2, #8
d00820ea:	4629      	mov	r1, r5
d00820ec:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d00820f0:	f7ff fcea 	bl	d0081ac8 <memset>
d00820f4:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d00820f8:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d00820fc:	4620      	mov	r0, r4
d00820fe:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0082100:	3468      	adds	r4, #104	; 0x68
d0082102:	e7d9      	b.n	d00820b8 <__sfp+0x1c>
d0082104:	2104      	movs	r1, #4
d0082106:	4638      	mov	r0, r7
d0082108:	f7ff ff62 	bl	d0081fd0 <__sfmoreglue>
d008210c:	4604      	mov	r4, r0
d008210e:	6030      	str	r0, [r6, #0]
d0082110:	2800      	cmp	r0, #0
d0082112:	d1d5      	bne.n	d00820c0 <__sfp+0x24>
d0082114:	f7ff ff78 	bl	d0082008 <__sfp_lock_release>
d0082118:	230c      	movs	r3, #12
d008211a:	603b      	str	r3, [r7, #0]
d008211c:	e7ee      	b.n	d00820fc <__sfp+0x60>
d008211e:	bf00      	nop
d0082120:	d00876b0 	.word	0xd00876b0
d0082124:	ffff0001 	.word	0xffff0001

d0082128 <_fwalk_reent>:
d0082128:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d008212c:	4606      	mov	r6, r0
d008212e:	4688      	mov	r8, r1
d0082130:	f100 0448 	add.w	r4, r0, #72	; 0x48
d0082134:	2700      	movs	r7, #0
d0082136:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d008213a:	f1b9 0901 	subs.w	r9, r9, #1
d008213e:	d505      	bpl.n	d008214c <_fwalk_reent+0x24>
d0082140:	6824      	ldr	r4, [r4, #0]
d0082142:	2c00      	cmp	r4, #0
d0082144:	d1f7      	bne.n	d0082136 <_fwalk_reent+0xe>
d0082146:	4638      	mov	r0, r7
d0082148:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d008214c:	89ab      	ldrh	r3, [r5, #12]
d008214e:	2b01      	cmp	r3, #1
d0082150:	d907      	bls.n	d0082162 <_fwalk_reent+0x3a>
d0082152:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d0082156:	3301      	adds	r3, #1
d0082158:	d003      	beq.n	d0082162 <_fwalk_reent+0x3a>
d008215a:	4629      	mov	r1, r5
d008215c:	4630      	mov	r0, r6
d008215e:	47c0      	blx	r8
d0082160:	4307      	orrs	r7, r0
d0082162:	3568      	adds	r5, #104	; 0x68
d0082164:	e7e9      	b.n	d008213a <_fwalk_reent+0x12>

d0082166 <__retarget_lock_init_recursive>:
d0082166:	4770      	bx	lr

d0082168 <__retarget_lock_acquire_recursive>:
d0082168:	4770      	bx	lr

d008216a <__retarget_lock_release_recursive>:
d008216a:	4770      	bx	lr

d008216c <__swhatbuf_r>:
d008216c:	b570      	push	{r4, r5, r6, lr}
d008216e:	460e      	mov	r6, r1
d0082170:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0082174:	2900      	cmp	r1, #0
d0082176:	b096      	sub	sp, #88	; 0x58
d0082178:	4614      	mov	r4, r2
d008217a:	461d      	mov	r5, r3
d008217c:	da07      	bge.n	d008218e <__swhatbuf_r+0x22>
d008217e:	2300      	movs	r3, #0
d0082180:	602b      	str	r3, [r5, #0]
d0082182:	89b3      	ldrh	r3, [r6, #12]
d0082184:	061a      	lsls	r2, r3, #24
d0082186:	d410      	bmi.n	d00821aa <__swhatbuf_r+0x3e>
d0082188:	f44f 6380 	mov.w	r3, #1024	; 0x400
d008218c:	e00e      	b.n	d00821ac <__swhatbuf_r+0x40>
d008218e:	466a      	mov	r2, sp
d0082190:	f000 fc5e 	bl	d0082a50 <_fstat_r>
d0082194:	2800      	cmp	r0, #0
d0082196:	dbf2      	blt.n	d008217e <__swhatbuf_r+0x12>
d0082198:	9a01      	ldr	r2, [sp, #4]
d008219a:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d008219e:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d00821a2:	425a      	negs	r2, r3
d00821a4:	415a      	adcs	r2, r3
d00821a6:	602a      	str	r2, [r5, #0]
d00821a8:	e7ee      	b.n	d0082188 <__swhatbuf_r+0x1c>
d00821aa:	2340      	movs	r3, #64	; 0x40
d00821ac:	2000      	movs	r0, #0
d00821ae:	6023      	str	r3, [r4, #0]
d00821b0:	b016      	add	sp, #88	; 0x58
d00821b2:	bd70      	pop	{r4, r5, r6, pc}

d00821b4 <__smakebuf_r>:
d00821b4:	898b      	ldrh	r3, [r1, #12]
d00821b6:	b573      	push	{r0, r1, r4, r5, r6, lr}
d00821b8:	079d      	lsls	r5, r3, #30
d00821ba:	4606      	mov	r6, r0
d00821bc:	460c      	mov	r4, r1
d00821be:	d507      	bpl.n	d00821d0 <__smakebuf_r+0x1c>
d00821c0:	f104 0347 	add.w	r3, r4, #71	; 0x47
d00821c4:	6023      	str	r3, [r4, #0]
d00821c6:	6123      	str	r3, [r4, #16]
d00821c8:	2301      	movs	r3, #1
d00821ca:	6163      	str	r3, [r4, #20]
d00821cc:	b002      	add	sp, #8
d00821ce:	bd70      	pop	{r4, r5, r6, pc}
d00821d0:	ab01      	add	r3, sp, #4
d00821d2:	466a      	mov	r2, sp
d00821d4:	f7ff ffca 	bl	d008216c <__swhatbuf_r>
d00821d8:	9900      	ldr	r1, [sp, #0]
d00821da:	4605      	mov	r5, r0
d00821dc:	4630      	mov	r0, r6
d00821de:	f7ff fccb 	bl	d0081b78 <_malloc_r>
d00821e2:	b948      	cbnz	r0, d00821f8 <__smakebuf_r+0x44>
d00821e4:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d00821e8:	059a      	lsls	r2, r3, #22
d00821ea:	d4ef      	bmi.n	d00821cc <__smakebuf_r+0x18>
d00821ec:	f023 0303 	bic.w	r3, r3, #3
d00821f0:	f043 0302 	orr.w	r3, r3, #2
d00821f4:	81a3      	strh	r3, [r4, #12]
d00821f6:	e7e3      	b.n	d00821c0 <__smakebuf_r+0xc>
d00821f8:	4b0d      	ldr	r3, [pc, #52]	; (d0082230 <__smakebuf_r+0x7c>)
d00821fa:	62b3      	str	r3, [r6, #40]	; 0x28
d00821fc:	89a3      	ldrh	r3, [r4, #12]
d00821fe:	6020      	str	r0, [r4, #0]
d0082200:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0082204:	81a3      	strh	r3, [r4, #12]
d0082206:	9b00      	ldr	r3, [sp, #0]
d0082208:	6163      	str	r3, [r4, #20]
d008220a:	9b01      	ldr	r3, [sp, #4]
d008220c:	6120      	str	r0, [r4, #16]
d008220e:	b15b      	cbz	r3, d0082228 <__smakebuf_r+0x74>
d0082210:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d0082214:	4630      	mov	r0, r6
d0082216:	f000 fc2d 	bl	d0082a74 <_isatty_r>
d008221a:	b128      	cbz	r0, d0082228 <__smakebuf_r+0x74>
d008221c:	89a3      	ldrh	r3, [r4, #12]
d008221e:	f023 0303 	bic.w	r3, r3, #3
d0082222:	f043 0301 	orr.w	r3, r3, #1
d0082226:	81a3      	strh	r3, [r4, #12]
d0082228:	89a0      	ldrh	r0, [r4, #12]
d008222a:	4305      	orrs	r5, r0
d008222c:	81a5      	strh	r5, [r4, #12]
d008222e:	e7cd      	b.n	d00821cc <__smakebuf_r+0x18>
d0082230:	d0081fc5 	.word	0xd0081fc5

d0082234 <__malloc_lock>:
d0082234:	4801      	ldr	r0, [pc, #4]	; (d008223c <__malloc_lock+0x8>)
d0082236:	f7ff bf97 	b.w	d0082168 <__retarget_lock_acquire_recursive>
d008223a:	bf00      	nop
d008223c:	d0089510 	.word	0xd0089510

d0082240 <__malloc_unlock>:
d0082240:	4801      	ldr	r0, [pc, #4]	; (d0082248 <__malloc_unlock+0x8>)
d0082242:	f7ff bf92 	b.w	d008216a <__retarget_lock_release_recursive>
d0082246:	bf00      	nop
d0082248:	d0089510 	.word	0xd0089510

d008224c <__sfputc_r>:
d008224c:	6893      	ldr	r3, [r2, #8]
d008224e:	3b01      	subs	r3, #1
d0082250:	2b00      	cmp	r3, #0
d0082252:	b410      	push	{r4}
d0082254:	6093      	str	r3, [r2, #8]
d0082256:	da08      	bge.n	d008226a <__sfputc_r+0x1e>
d0082258:	6994      	ldr	r4, [r2, #24]
d008225a:	42a3      	cmp	r3, r4
d008225c:	db01      	blt.n	d0082262 <__sfputc_r+0x16>
d008225e:	290a      	cmp	r1, #10
d0082260:	d103      	bne.n	d008226a <__sfputc_r+0x1e>
d0082262:	f85d 4b04 	ldr.w	r4, [sp], #4
d0082266:	f000 bb23 	b.w	d00828b0 <__swbuf_r>
d008226a:	6813      	ldr	r3, [r2, #0]
d008226c:	1c58      	adds	r0, r3, #1
d008226e:	6010      	str	r0, [r2, #0]
d0082270:	7019      	strb	r1, [r3, #0]
d0082272:	4608      	mov	r0, r1
d0082274:	f85d 4b04 	ldr.w	r4, [sp], #4
d0082278:	4770      	bx	lr

d008227a <__sfputs_r>:
d008227a:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008227c:	4606      	mov	r6, r0
d008227e:	460f      	mov	r7, r1
d0082280:	4614      	mov	r4, r2
d0082282:	18d5      	adds	r5, r2, r3
d0082284:	42ac      	cmp	r4, r5
d0082286:	d101      	bne.n	d008228c <__sfputs_r+0x12>
d0082288:	2000      	movs	r0, #0
d008228a:	e007      	b.n	d008229c <__sfputs_r+0x22>
d008228c:	f814 1b01 	ldrb.w	r1, [r4], #1
d0082290:	463a      	mov	r2, r7
d0082292:	4630      	mov	r0, r6
d0082294:	f7ff ffda 	bl	d008224c <__sfputc_r>
d0082298:	1c43      	adds	r3, r0, #1
d008229a:	d1f3      	bne.n	d0082284 <__sfputs_r+0xa>
d008229c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

d00822a0 <_vfiprintf_r>:
d00822a0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00822a4:	460d      	mov	r5, r1
d00822a6:	b09d      	sub	sp, #116	; 0x74
d00822a8:	4614      	mov	r4, r2
d00822aa:	4698      	mov	r8, r3
d00822ac:	4606      	mov	r6, r0
d00822ae:	b118      	cbz	r0, d00822b8 <_vfiprintf_r+0x18>
d00822b0:	6983      	ldr	r3, [r0, #24]
d00822b2:	b90b      	cbnz	r3, d00822b8 <_vfiprintf_r+0x18>
d00822b4:	f7ff feba 	bl	d008202c <__sinit>
d00822b8:	4b89      	ldr	r3, [pc, #548]	; (d00824e0 <_vfiprintf_r+0x240>)
d00822ba:	429d      	cmp	r5, r3
d00822bc:	d11b      	bne.n	d00822f6 <_vfiprintf_r+0x56>
d00822be:	6875      	ldr	r5, [r6, #4]
d00822c0:	6e6b      	ldr	r3, [r5, #100]	; 0x64
d00822c2:	07d9      	lsls	r1, r3, #31
d00822c4:	d405      	bmi.n	d00822d2 <_vfiprintf_r+0x32>
d00822c6:	89ab      	ldrh	r3, [r5, #12]
d00822c8:	059a      	lsls	r2, r3, #22
d00822ca:	d402      	bmi.n	d00822d2 <_vfiprintf_r+0x32>
d00822cc:	6da8      	ldr	r0, [r5, #88]	; 0x58
d00822ce:	f7ff ff4b 	bl	d0082168 <__retarget_lock_acquire_recursive>
d00822d2:	89ab      	ldrh	r3, [r5, #12]
d00822d4:	071b      	lsls	r3, r3, #28
d00822d6:	d501      	bpl.n	d00822dc <_vfiprintf_r+0x3c>
d00822d8:	692b      	ldr	r3, [r5, #16]
d00822da:	b9eb      	cbnz	r3, d0082318 <_vfiprintf_r+0x78>
d00822dc:	4629      	mov	r1, r5
d00822de:	4630      	mov	r0, r6
d00822e0:	f000 fb38 	bl	d0082954 <__swsetup_r>
d00822e4:	b1c0      	cbz	r0, d0082318 <_vfiprintf_r+0x78>
d00822e6:	6e6b      	ldr	r3, [r5, #100]	; 0x64
d00822e8:	07dc      	lsls	r4, r3, #31
d00822ea:	d50e      	bpl.n	d008230a <_vfiprintf_r+0x6a>
d00822ec:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00822f0:	b01d      	add	sp, #116	; 0x74
d00822f2:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00822f6:	4b7b      	ldr	r3, [pc, #492]	; (d00824e4 <_vfiprintf_r+0x244>)
d00822f8:	429d      	cmp	r5, r3
d00822fa:	d101      	bne.n	d0082300 <_vfiprintf_r+0x60>
d00822fc:	68b5      	ldr	r5, [r6, #8]
d00822fe:	e7df      	b.n	d00822c0 <_vfiprintf_r+0x20>
d0082300:	4b79      	ldr	r3, [pc, #484]	; (d00824e8 <_vfiprintf_r+0x248>)
d0082302:	429d      	cmp	r5, r3
d0082304:	bf08      	it	eq
d0082306:	68f5      	ldreq	r5, [r6, #12]
d0082308:	e7da      	b.n	d00822c0 <_vfiprintf_r+0x20>
d008230a:	89ab      	ldrh	r3, [r5, #12]
d008230c:	0598      	lsls	r0, r3, #22
d008230e:	d4ed      	bmi.n	d00822ec <_vfiprintf_r+0x4c>
d0082310:	6da8      	ldr	r0, [r5, #88]	; 0x58
d0082312:	f7ff ff2a 	bl	d008216a <__retarget_lock_release_recursive>
d0082316:	e7e9      	b.n	d00822ec <_vfiprintf_r+0x4c>
d0082318:	2300      	movs	r3, #0
d008231a:	9309      	str	r3, [sp, #36]	; 0x24
d008231c:	2320      	movs	r3, #32
d008231e:	f88d 3029 	strb.w	r3, [sp, #41]	; 0x29
d0082322:	f8cd 800c 	str.w	r8, [sp, #12]
d0082326:	2330      	movs	r3, #48	; 0x30
d0082328:	f8df 81c0 	ldr.w	r8, [pc, #448]	; d00824ec <_vfiprintf_r+0x24c>
d008232c:	f88d 302a 	strb.w	r3, [sp, #42]	; 0x2a
d0082330:	f04f 0901 	mov.w	r9, #1
d0082334:	4623      	mov	r3, r4
d0082336:	469a      	mov	sl, r3
d0082338:	f813 2b01 	ldrb.w	r2, [r3], #1
d008233c:	b10a      	cbz	r2, d0082342 <_vfiprintf_r+0xa2>
d008233e:	2a25      	cmp	r2, #37	; 0x25
d0082340:	d1f9      	bne.n	d0082336 <_vfiprintf_r+0x96>
d0082342:	ebba 0b04 	subs.w	fp, sl, r4
d0082346:	d00b      	beq.n	d0082360 <_vfiprintf_r+0xc0>
d0082348:	465b      	mov	r3, fp
d008234a:	4622      	mov	r2, r4
d008234c:	4629      	mov	r1, r5
d008234e:	4630      	mov	r0, r6
d0082350:	f7ff ff93 	bl	d008227a <__sfputs_r>
d0082354:	3001      	adds	r0, #1
d0082356:	f000 80aa 	beq.w	d00824ae <_vfiprintf_r+0x20e>
d008235a:	9a09      	ldr	r2, [sp, #36]	; 0x24
d008235c:	445a      	add	r2, fp
d008235e:	9209      	str	r2, [sp, #36]	; 0x24
d0082360:	f89a 3000 	ldrb.w	r3, [sl]
d0082364:	2b00      	cmp	r3, #0
d0082366:	f000 80a2 	beq.w	d00824ae <_vfiprintf_r+0x20e>
d008236a:	2300      	movs	r3, #0
d008236c:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d0082370:	e9cd 2305 	strd	r2, r3, [sp, #20]
d0082374:	f10a 0a01 	add.w	sl, sl, #1
d0082378:	9304      	str	r3, [sp, #16]
d008237a:	9307      	str	r3, [sp, #28]
d008237c:	f88d 3053 	strb.w	r3, [sp, #83]	; 0x53
d0082380:	931a      	str	r3, [sp, #104]	; 0x68
d0082382:	4654      	mov	r4, sl
d0082384:	2205      	movs	r2, #5
d0082386:	f814 1b01 	ldrb.w	r1, [r4], #1
d008238a:	4858      	ldr	r0, [pc, #352]	; (d00824ec <_vfiprintf_r+0x24c>)
d008238c:	f000 fb98 	bl	d0082ac0 <memchr>
d0082390:	9a04      	ldr	r2, [sp, #16]
d0082392:	b9d8      	cbnz	r0, d00823cc <_vfiprintf_r+0x12c>
d0082394:	06d1      	lsls	r1, r2, #27
d0082396:	bf44      	itt	mi
d0082398:	2320      	movmi	r3, #32
d008239a:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d008239e:	0713      	lsls	r3, r2, #28
d00823a0:	bf44      	itt	mi
d00823a2:	232b      	movmi	r3, #43	; 0x2b
d00823a4:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d00823a8:	f89a 3000 	ldrb.w	r3, [sl]
d00823ac:	2b2a      	cmp	r3, #42	; 0x2a
d00823ae:	d015      	beq.n	d00823dc <_vfiprintf_r+0x13c>
d00823b0:	9a07      	ldr	r2, [sp, #28]
d00823b2:	4654      	mov	r4, sl
d00823b4:	2000      	movs	r0, #0
d00823b6:	f04f 0c0a 	mov.w	ip, #10
d00823ba:	4621      	mov	r1, r4
d00823bc:	f811 3b01 	ldrb.w	r3, [r1], #1
d00823c0:	3b30      	subs	r3, #48	; 0x30
d00823c2:	2b09      	cmp	r3, #9
d00823c4:	d94e      	bls.n	d0082464 <_vfiprintf_r+0x1c4>
d00823c6:	b1b0      	cbz	r0, d00823f6 <_vfiprintf_r+0x156>
d00823c8:	9207      	str	r2, [sp, #28]
d00823ca:	e014      	b.n	d00823f6 <_vfiprintf_r+0x156>
d00823cc:	eba0 0308 	sub.w	r3, r0, r8
d00823d0:	fa09 f303 	lsl.w	r3, r9, r3
d00823d4:	4313      	orrs	r3, r2
d00823d6:	9304      	str	r3, [sp, #16]
d00823d8:	46a2      	mov	sl, r4
d00823da:	e7d2      	b.n	d0082382 <_vfiprintf_r+0xe2>
d00823dc:	9b03      	ldr	r3, [sp, #12]
d00823de:	1d19      	adds	r1, r3, #4
d00823e0:	681b      	ldr	r3, [r3, #0]
d00823e2:	9103      	str	r1, [sp, #12]
d00823e4:	2b00      	cmp	r3, #0
d00823e6:	bfbb      	ittet	lt
d00823e8:	425b      	neglt	r3, r3
d00823ea:	f042 0202 	orrlt.w	r2, r2, #2
d00823ee:	9307      	strge	r3, [sp, #28]
d00823f0:	9307      	strlt	r3, [sp, #28]
d00823f2:	bfb8      	it	lt
d00823f4:	9204      	strlt	r2, [sp, #16]
d00823f6:	7823      	ldrb	r3, [r4, #0]
d00823f8:	2b2e      	cmp	r3, #46	; 0x2e
d00823fa:	d10c      	bne.n	d0082416 <_vfiprintf_r+0x176>
d00823fc:	7863      	ldrb	r3, [r4, #1]
d00823fe:	2b2a      	cmp	r3, #42	; 0x2a
d0082400:	d135      	bne.n	d008246e <_vfiprintf_r+0x1ce>
d0082402:	9b03      	ldr	r3, [sp, #12]
d0082404:	1d1a      	adds	r2, r3, #4
d0082406:	681b      	ldr	r3, [r3, #0]
d0082408:	9203      	str	r2, [sp, #12]
d008240a:	2b00      	cmp	r3, #0
d008240c:	bfb8      	it	lt
d008240e:	f04f 33ff 	movlt.w	r3, #4294967295	; 0xffffffff
d0082412:	3402      	adds	r4, #2
d0082414:	9305      	str	r3, [sp, #20]
d0082416:	f8df a0e4 	ldr.w	sl, [pc, #228]	; d00824fc <_vfiprintf_r+0x25c>
d008241a:	7821      	ldrb	r1, [r4, #0]
d008241c:	2203      	movs	r2, #3
d008241e:	4650      	mov	r0, sl
d0082420:	f000 fb4e 	bl	d0082ac0 <memchr>
d0082424:	b140      	cbz	r0, d0082438 <_vfiprintf_r+0x198>
d0082426:	2340      	movs	r3, #64	; 0x40
d0082428:	eba0 000a 	sub.w	r0, r0, sl
d008242c:	fa03 f000 	lsl.w	r0, r3, r0
d0082430:	9b04      	ldr	r3, [sp, #16]
d0082432:	4303      	orrs	r3, r0
d0082434:	3401      	adds	r4, #1
d0082436:	9304      	str	r3, [sp, #16]
d0082438:	f814 1b01 	ldrb.w	r1, [r4], #1
d008243c:	482c      	ldr	r0, [pc, #176]	; (d00824f0 <_vfiprintf_r+0x250>)
d008243e:	f88d 1028 	strb.w	r1, [sp, #40]	; 0x28
d0082442:	2206      	movs	r2, #6
d0082444:	f000 fb3c 	bl	d0082ac0 <memchr>
d0082448:	2800      	cmp	r0, #0
d008244a:	d03f      	beq.n	d00824cc <_vfiprintf_r+0x22c>
d008244c:	4b29      	ldr	r3, [pc, #164]	; (d00824f4 <_vfiprintf_r+0x254>)
d008244e:	bb1b      	cbnz	r3, d0082498 <_vfiprintf_r+0x1f8>
d0082450:	9b03      	ldr	r3, [sp, #12]
d0082452:	3307      	adds	r3, #7
d0082454:	f023 0307 	bic.w	r3, r3, #7
d0082458:	3308      	adds	r3, #8
d008245a:	9303      	str	r3, [sp, #12]
d008245c:	9b09      	ldr	r3, [sp, #36]	; 0x24
d008245e:	443b      	add	r3, r7
d0082460:	9309      	str	r3, [sp, #36]	; 0x24
d0082462:	e767      	b.n	d0082334 <_vfiprintf_r+0x94>
d0082464:	fb0c 3202 	mla	r2, ip, r2, r3
d0082468:	460c      	mov	r4, r1
d008246a:	2001      	movs	r0, #1
d008246c:	e7a5      	b.n	d00823ba <_vfiprintf_r+0x11a>
d008246e:	2300      	movs	r3, #0
d0082470:	3401      	adds	r4, #1
d0082472:	9305      	str	r3, [sp, #20]
d0082474:	4619      	mov	r1, r3
d0082476:	f04f 0c0a 	mov.w	ip, #10
d008247a:	4620      	mov	r0, r4
d008247c:	f810 2b01 	ldrb.w	r2, [r0], #1
d0082480:	3a30      	subs	r2, #48	; 0x30
d0082482:	2a09      	cmp	r2, #9
d0082484:	d903      	bls.n	d008248e <_vfiprintf_r+0x1ee>
d0082486:	2b00      	cmp	r3, #0
d0082488:	d0c5      	beq.n	d0082416 <_vfiprintf_r+0x176>
d008248a:	9105      	str	r1, [sp, #20]
d008248c:	e7c3      	b.n	d0082416 <_vfiprintf_r+0x176>
d008248e:	fb0c 2101 	mla	r1, ip, r1, r2
d0082492:	4604      	mov	r4, r0
d0082494:	2301      	movs	r3, #1
d0082496:	e7f0      	b.n	d008247a <_vfiprintf_r+0x1da>
d0082498:	ab03      	add	r3, sp, #12
d008249a:	9300      	str	r3, [sp, #0]
d008249c:	462a      	mov	r2, r5
d008249e:	4b16      	ldr	r3, [pc, #88]	; (d00824f8 <_vfiprintf_r+0x258>)
d00824a0:	a904      	add	r1, sp, #16
d00824a2:	4630      	mov	r0, r6
d00824a4:	f3af 8000 	nop.w
d00824a8:	4607      	mov	r7, r0
d00824aa:	1c78      	adds	r0, r7, #1
d00824ac:	d1d6      	bne.n	d008245c <_vfiprintf_r+0x1bc>
d00824ae:	6e6b      	ldr	r3, [r5, #100]	; 0x64
d00824b0:	07d9      	lsls	r1, r3, #31
d00824b2:	d405      	bmi.n	d00824c0 <_vfiprintf_r+0x220>
d00824b4:	89ab      	ldrh	r3, [r5, #12]
d00824b6:	059a      	lsls	r2, r3, #22
d00824b8:	d402      	bmi.n	d00824c0 <_vfiprintf_r+0x220>
d00824ba:	6da8      	ldr	r0, [r5, #88]	; 0x58
d00824bc:	f7ff fe55 	bl	d008216a <__retarget_lock_release_recursive>
d00824c0:	89ab      	ldrh	r3, [r5, #12]
d00824c2:	065b      	lsls	r3, r3, #25
d00824c4:	f53f af12 	bmi.w	d00822ec <_vfiprintf_r+0x4c>
d00824c8:	9809      	ldr	r0, [sp, #36]	; 0x24
d00824ca:	e711      	b.n	d00822f0 <_vfiprintf_r+0x50>
d00824cc:	ab03      	add	r3, sp, #12
d00824ce:	9300      	str	r3, [sp, #0]
d00824d0:	462a      	mov	r2, r5
d00824d2:	4b09      	ldr	r3, [pc, #36]	; (d00824f8 <_vfiprintf_r+0x258>)
d00824d4:	a904      	add	r1, sp, #16
d00824d6:	4630      	mov	r0, r6
d00824d8:	f000 f880 	bl	d00825dc <_printf_i>
d00824dc:	e7e4      	b.n	d00824a8 <_vfiprintf_r+0x208>
d00824de:	bf00      	nop
d00824e0:	d00876d4 	.word	0xd00876d4
d00824e4:	d00876f4 	.word	0xd00876f4
d00824e8:	d00876b4 	.word	0xd00876b4
d00824ec:	d0087714 	.word	0xd0087714
d00824f0:	d008771e 	.word	0xd008771e
d00824f4:	00000000 	.word	0x00000000
d00824f8:	d008227b 	.word	0xd008227b
d00824fc:	d008771a 	.word	0xd008771a

d0082500 <_printf_common>:
d0082500:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d0082504:	4616      	mov	r6, r2
d0082506:	4699      	mov	r9, r3
d0082508:	688a      	ldr	r2, [r1, #8]
d008250a:	690b      	ldr	r3, [r1, #16]
d008250c:	f8dd 8020 	ldr.w	r8, [sp, #32]
d0082510:	4293      	cmp	r3, r2
d0082512:	bfb8      	it	lt
d0082514:	4613      	movlt	r3, r2
d0082516:	6033      	str	r3, [r6, #0]
d0082518:	f891 2043 	ldrb.w	r2, [r1, #67]	; 0x43
d008251c:	4607      	mov	r7, r0
d008251e:	460c      	mov	r4, r1
d0082520:	b10a      	cbz	r2, d0082526 <_printf_common+0x26>
d0082522:	3301      	adds	r3, #1
d0082524:	6033      	str	r3, [r6, #0]
d0082526:	6823      	ldr	r3, [r4, #0]
d0082528:	0699      	lsls	r1, r3, #26
d008252a:	bf42      	ittt	mi
d008252c:	6833      	ldrmi	r3, [r6, #0]
d008252e:	3302      	addmi	r3, #2
d0082530:	6033      	strmi	r3, [r6, #0]
d0082532:	6825      	ldr	r5, [r4, #0]
d0082534:	f015 0506 	ands.w	r5, r5, #6
d0082538:	d106      	bne.n	d0082548 <_printf_common+0x48>
d008253a:	f104 0a19 	add.w	sl, r4, #25
d008253e:	68e3      	ldr	r3, [r4, #12]
d0082540:	6832      	ldr	r2, [r6, #0]
d0082542:	1a9b      	subs	r3, r3, r2
d0082544:	42ab      	cmp	r3, r5
d0082546:	dc26      	bgt.n	d0082596 <_printf_common+0x96>
d0082548:	f894 2043 	ldrb.w	r2, [r4, #67]	; 0x43
d008254c:	1e13      	subs	r3, r2, #0
d008254e:	6822      	ldr	r2, [r4, #0]
d0082550:	bf18      	it	ne
d0082552:	2301      	movne	r3, #1
d0082554:	0692      	lsls	r2, r2, #26
d0082556:	d42b      	bmi.n	d00825b0 <_printf_common+0xb0>
d0082558:	f104 0243 	add.w	r2, r4, #67	; 0x43
d008255c:	4649      	mov	r1, r9
d008255e:	4638      	mov	r0, r7
d0082560:	47c0      	blx	r8
d0082562:	3001      	adds	r0, #1
d0082564:	d01e      	beq.n	d00825a4 <_printf_common+0xa4>
d0082566:	6823      	ldr	r3, [r4, #0]
d0082568:	68e5      	ldr	r5, [r4, #12]
d008256a:	6832      	ldr	r2, [r6, #0]
d008256c:	f003 0306 	and.w	r3, r3, #6
d0082570:	2b04      	cmp	r3, #4
d0082572:	bf08      	it	eq
d0082574:	1aad      	subeq	r5, r5, r2
d0082576:	68a3      	ldr	r3, [r4, #8]
d0082578:	6922      	ldr	r2, [r4, #16]
d008257a:	bf0c      	ite	eq
d008257c:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
d0082580:	2500      	movne	r5, #0
d0082582:	4293      	cmp	r3, r2
d0082584:	bfc4      	itt	gt
d0082586:	1a9b      	subgt	r3, r3, r2
d0082588:	18ed      	addgt	r5, r5, r3
d008258a:	2600      	movs	r6, #0
d008258c:	341a      	adds	r4, #26
d008258e:	42b5      	cmp	r5, r6
d0082590:	d11a      	bne.n	d00825c8 <_printf_common+0xc8>
d0082592:	2000      	movs	r0, #0
d0082594:	e008      	b.n	d00825a8 <_printf_common+0xa8>
d0082596:	2301      	movs	r3, #1
d0082598:	4652      	mov	r2, sl
d008259a:	4649      	mov	r1, r9
d008259c:	4638      	mov	r0, r7
d008259e:	47c0      	blx	r8
d00825a0:	3001      	adds	r0, #1
d00825a2:	d103      	bne.n	d00825ac <_printf_common+0xac>
d00825a4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00825a8:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d00825ac:	3501      	adds	r5, #1
d00825ae:	e7c6      	b.n	d008253e <_printf_common+0x3e>
d00825b0:	18e1      	adds	r1, r4, r3
d00825b2:	1c5a      	adds	r2, r3, #1
d00825b4:	2030      	movs	r0, #48	; 0x30
d00825b6:	f881 0043 	strb.w	r0, [r1, #67]	; 0x43
d00825ba:	4422      	add	r2, r4
d00825bc:	f894 1045 	ldrb.w	r1, [r4, #69]	; 0x45
d00825c0:	f882 1043 	strb.w	r1, [r2, #67]	; 0x43
d00825c4:	3302      	adds	r3, #2
d00825c6:	e7c7      	b.n	d0082558 <_printf_common+0x58>
d00825c8:	2301      	movs	r3, #1
d00825ca:	4622      	mov	r2, r4
d00825cc:	4649      	mov	r1, r9
d00825ce:	4638      	mov	r0, r7
d00825d0:	47c0      	blx	r8
d00825d2:	3001      	adds	r0, #1
d00825d4:	d0e6      	beq.n	d00825a4 <_printf_common+0xa4>
d00825d6:	3601      	adds	r6, #1
d00825d8:	e7d9      	b.n	d008258e <_printf_common+0x8e>
	...

d00825dc <_printf_i>:
d00825dc:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
d00825e0:	460c      	mov	r4, r1
d00825e2:	4691      	mov	r9, r2
d00825e4:	7e27      	ldrb	r7, [r4, #24]
d00825e6:	990c      	ldr	r1, [sp, #48]	; 0x30
d00825e8:	2f78      	cmp	r7, #120	; 0x78
d00825ea:	4680      	mov	r8, r0
d00825ec:	469a      	mov	sl, r3
d00825ee:	f104 0243 	add.w	r2, r4, #67	; 0x43
d00825f2:	d807      	bhi.n	d0082604 <_printf_i+0x28>
d00825f4:	2f62      	cmp	r7, #98	; 0x62
d00825f6:	d80a      	bhi.n	d008260e <_printf_i+0x32>
d00825f8:	2f00      	cmp	r7, #0
d00825fa:	f000 80d8 	beq.w	d00827ae <_printf_i+0x1d2>
d00825fe:	2f58      	cmp	r7, #88	; 0x58
d0082600:	f000 80a3 	beq.w	d008274a <_printf_i+0x16e>
d0082604:	f104 0642 	add.w	r6, r4, #66	; 0x42
d0082608:	f884 7042 	strb.w	r7, [r4, #66]	; 0x42
d008260c:	e03a      	b.n	d0082684 <_printf_i+0xa8>
d008260e:	f1a7 0363 	sub.w	r3, r7, #99	; 0x63
d0082612:	2b15      	cmp	r3, #21
d0082614:	d8f6      	bhi.n	d0082604 <_printf_i+0x28>
d0082616:	a001      	add	r0, pc, #4	; (adr r0, d008261c <_printf_i+0x40>)
d0082618:	f850 f023 	ldr.w	pc, [r0, r3, lsl #2]
d008261c:	d0082675 	.word	0xd0082675
d0082620:	d0082689 	.word	0xd0082689
d0082624:	d0082605 	.word	0xd0082605
d0082628:	d0082605 	.word	0xd0082605
d008262c:	d0082605 	.word	0xd0082605
d0082630:	d0082605 	.word	0xd0082605
d0082634:	d0082689 	.word	0xd0082689
d0082638:	d0082605 	.word	0xd0082605
d008263c:	d0082605 	.word	0xd0082605
d0082640:	d0082605 	.word	0xd0082605
d0082644:	d0082605 	.word	0xd0082605
d0082648:	d0082795 	.word	0xd0082795
d008264c:	d00826b9 	.word	0xd00826b9
d0082650:	d0082777 	.word	0xd0082777
d0082654:	d0082605 	.word	0xd0082605
d0082658:	d0082605 	.word	0xd0082605
d008265c:	d00827b7 	.word	0xd00827b7
d0082660:	d0082605 	.word	0xd0082605
d0082664:	d00826b9 	.word	0xd00826b9
d0082668:	d0082605 	.word	0xd0082605
d008266c:	d0082605 	.word	0xd0082605
d0082670:	d008277f 	.word	0xd008277f
d0082674:	680b      	ldr	r3, [r1, #0]
d0082676:	1d1a      	adds	r2, r3, #4
d0082678:	681b      	ldr	r3, [r3, #0]
d008267a:	600a      	str	r2, [r1, #0]
d008267c:	f104 0642 	add.w	r6, r4, #66	; 0x42
d0082680:	f884 3042 	strb.w	r3, [r4, #66]	; 0x42
d0082684:	2301      	movs	r3, #1
d0082686:	e0a3      	b.n	d00827d0 <_printf_i+0x1f4>
d0082688:	6825      	ldr	r5, [r4, #0]
d008268a:	6808      	ldr	r0, [r1, #0]
d008268c:	062e      	lsls	r6, r5, #24
d008268e:	f100 0304 	add.w	r3, r0, #4
d0082692:	d50a      	bpl.n	d00826aa <_printf_i+0xce>
d0082694:	6805      	ldr	r5, [r0, #0]
d0082696:	600b      	str	r3, [r1, #0]
d0082698:	2d00      	cmp	r5, #0
d008269a:	da03      	bge.n	d00826a4 <_printf_i+0xc8>
d008269c:	232d      	movs	r3, #45	; 0x2d
d008269e:	426d      	negs	r5, r5
d00826a0:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d00826a4:	485e      	ldr	r0, [pc, #376]	; (d0082820 <_printf_i+0x244>)
d00826a6:	230a      	movs	r3, #10
d00826a8:	e019      	b.n	d00826de <_printf_i+0x102>
d00826aa:	f015 0f40 	tst.w	r5, #64	; 0x40
d00826ae:	6805      	ldr	r5, [r0, #0]
d00826b0:	600b      	str	r3, [r1, #0]
d00826b2:	bf18      	it	ne
d00826b4:	b22d      	sxthne	r5, r5
d00826b6:	e7ef      	b.n	d0082698 <_printf_i+0xbc>
d00826b8:	680b      	ldr	r3, [r1, #0]
d00826ba:	6825      	ldr	r5, [r4, #0]
d00826bc:	1d18      	adds	r0, r3, #4
d00826be:	6008      	str	r0, [r1, #0]
d00826c0:	0628      	lsls	r0, r5, #24
d00826c2:	d501      	bpl.n	d00826c8 <_printf_i+0xec>
d00826c4:	681d      	ldr	r5, [r3, #0]
d00826c6:	e002      	b.n	d00826ce <_printf_i+0xf2>
d00826c8:	0669      	lsls	r1, r5, #25
d00826ca:	d5fb      	bpl.n	d00826c4 <_printf_i+0xe8>
d00826cc:	881d      	ldrh	r5, [r3, #0]
d00826ce:	4854      	ldr	r0, [pc, #336]	; (d0082820 <_printf_i+0x244>)
d00826d0:	2f6f      	cmp	r7, #111	; 0x6f
d00826d2:	bf0c      	ite	eq
d00826d4:	2308      	moveq	r3, #8
d00826d6:	230a      	movne	r3, #10
d00826d8:	2100      	movs	r1, #0
d00826da:	f884 1043 	strb.w	r1, [r4, #67]	; 0x43
d00826de:	6866      	ldr	r6, [r4, #4]
d00826e0:	60a6      	str	r6, [r4, #8]
d00826e2:	2e00      	cmp	r6, #0
d00826e4:	bfa2      	ittt	ge
d00826e6:	6821      	ldrge	r1, [r4, #0]
d00826e8:	f021 0104 	bicge.w	r1, r1, #4
d00826ec:	6021      	strge	r1, [r4, #0]
d00826ee:	b90d      	cbnz	r5, d00826f4 <_printf_i+0x118>
d00826f0:	2e00      	cmp	r6, #0
d00826f2:	d04d      	beq.n	d0082790 <_printf_i+0x1b4>
d00826f4:	4616      	mov	r6, r2
d00826f6:	fbb5 f1f3 	udiv	r1, r5, r3
d00826fa:	fb03 5711 	mls	r7, r3, r1, r5
d00826fe:	5dc7      	ldrb	r7, [r0, r7]
d0082700:	f806 7d01 	strb.w	r7, [r6, #-1]!
d0082704:	462f      	mov	r7, r5
d0082706:	42bb      	cmp	r3, r7
d0082708:	460d      	mov	r5, r1
d008270a:	d9f4      	bls.n	d00826f6 <_printf_i+0x11a>
d008270c:	2b08      	cmp	r3, #8
d008270e:	d10b      	bne.n	d0082728 <_printf_i+0x14c>
d0082710:	6823      	ldr	r3, [r4, #0]
d0082712:	07df      	lsls	r7, r3, #31
d0082714:	d508      	bpl.n	d0082728 <_printf_i+0x14c>
d0082716:	6923      	ldr	r3, [r4, #16]
d0082718:	6861      	ldr	r1, [r4, #4]
d008271a:	4299      	cmp	r1, r3
d008271c:	bfde      	ittt	le
d008271e:	2330      	movle	r3, #48	; 0x30
d0082720:	f806 3c01 	strble.w	r3, [r6, #-1]
d0082724:	f106 36ff 	addle.w	r6, r6, #4294967295	; 0xffffffff
d0082728:	1b92      	subs	r2, r2, r6
d008272a:	6122      	str	r2, [r4, #16]
d008272c:	f8cd a000 	str.w	sl, [sp]
d0082730:	464b      	mov	r3, r9
d0082732:	aa03      	add	r2, sp, #12
d0082734:	4621      	mov	r1, r4
d0082736:	4640      	mov	r0, r8
d0082738:	f7ff fee2 	bl	d0082500 <_printf_common>
d008273c:	3001      	adds	r0, #1
d008273e:	d14c      	bne.n	d00827da <_printf_i+0x1fe>
d0082740:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0082744:	b004      	add	sp, #16
d0082746:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d008274a:	4835      	ldr	r0, [pc, #212]	; (d0082820 <_printf_i+0x244>)
d008274c:	f884 7045 	strb.w	r7, [r4, #69]	; 0x45
d0082750:	6823      	ldr	r3, [r4, #0]
d0082752:	680e      	ldr	r6, [r1, #0]
d0082754:	061f      	lsls	r7, r3, #24
d0082756:	f856 5b04 	ldr.w	r5, [r6], #4
d008275a:	600e      	str	r6, [r1, #0]
d008275c:	d514      	bpl.n	d0082788 <_printf_i+0x1ac>
d008275e:	07d9      	lsls	r1, r3, #31
d0082760:	bf44      	itt	mi
d0082762:	f043 0320 	orrmi.w	r3, r3, #32
d0082766:	6023      	strmi	r3, [r4, #0]
d0082768:	b91d      	cbnz	r5, d0082772 <_printf_i+0x196>
d008276a:	6823      	ldr	r3, [r4, #0]
d008276c:	f023 0320 	bic.w	r3, r3, #32
d0082770:	6023      	str	r3, [r4, #0]
d0082772:	2310      	movs	r3, #16
d0082774:	e7b0      	b.n	d00826d8 <_printf_i+0xfc>
d0082776:	6823      	ldr	r3, [r4, #0]
d0082778:	f043 0320 	orr.w	r3, r3, #32
d008277c:	6023      	str	r3, [r4, #0]
d008277e:	2378      	movs	r3, #120	; 0x78
d0082780:	4828      	ldr	r0, [pc, #160]	; (d0082824 <_printf_i+0x248>)
d0082782:	f884 3045 	strb.w	r3, [r4, #69]	; 0x45
d0082786:	e7e3      	b.n	d0082750 <_printf_i+0x174>
d0082788:	065e      	lsls	r6, r3, #25
d008278a:	bf48      	it	mi
d008278c:	b2ad      	uxthmi	r5, r5
d008278e:	e7e6      	b.n	d008275e <_printf_i+0x182>
d0082790:	4616      	mov	r6, r2
d0082792:	e7bb      	b.n	d008270c <_printf_i+0x130>
d0082794:	680b      	ldr	r3, [r1, #0]
d0082796:	6826      	ldr	r6, [r4, #0]
d0082798:	6960      	ldr	r0, [r4, #20]
d008279a:	1d1d      	adds	r5, r3, #4
d008279c:	600d      	str	r5, [r1, #0]
d008279e:	0635      	lsls	r5, r6, #24
d00827a0:	681b      	ldr	r3, [r3, #0]
d00827a2:	d501      	bpl.n	d00827a8 <_printf_i+0x1cc>
d00827a4:	6018      	str	r0, [r3, #0]
d00827a6:	e002      	b.n	d00827ae <_printf_i+0x1d2>
d00827a8:	0671      	lsls	r1, r6, #25
d00827aa:	d5fb      	bpl.n	d00827a4 <_printf_i+0x1c8>
d00827ac:	8018      	strh	r0, [r3, #0]
d00827ae:	2300      	movs	r3, #0
d00827b0:	6123      	str	r3, [r4, #16]
d00827b2:	4616      	mov	r6, r2
d00827b4:	e7ba      	b.n	d008272c <_printf_i+0x150>
d00827b6:	680b      	ldr	r3, [r1, #0]
d00827b8:	1d1a      	adds	r2, r3, #4
d00827ba:	600a      	str	r2, [r1, #0]
d00827bc:	681e      	ldr	r6, [r3, #0]
d00827be:	6862      	ldr	r2, [r4, #4]
d00827c0:	2100      	movs	r1, #0
d00827c2:	4630      	mov	r0, r6
d00827c4:	f000 f97c 	bl	d0082ac0 <memchr>
d00827c8:	b108      	cbz	r0, d00827ce <_printf_i+0x1f2>
d00827ca:	1b80      	subs	r0, r0, r6
d00827cc:	6060      	str	r0, [r4, #4]
d00827ce:	6863      	ldr	r3, [r4, #4]
d00827d0:	6123      	str	r3, [r4, #16]
d00827d2:	2300      	movs	r3, #0
d00827d4:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d00827d8:	e7a8      	b.n	d008272c <_printf_i+0x150>
d00827da:	6923      	ldr	r3, [r4, #16]
d00827dc:	4632      	mov	r2, r6
d00827de:	4649      	mov	r1, r9
d00827e0:	4640      	mov	r0, r8
d00827e2:	47d0      	blx	sl
d00827e4:	3001      	adds	r0, #1
d00827e6:	d0ab      	beq.n	d0082740 <_printf_i+0x164>
d00827e8:	6823      	ldr	r3, [r4, #0]
d00827ea:	079b      	lsls	r3, r3, #30
d00827ec:	d413      	bmi.n	d0082816 <_printf_i+0x23a>
d00827ee:	68e0      	ldr	r0, [r4, #12]
d00827f0:	9b03      	ldr	r3, [sp, #12]
d00827f2:	4298      	cmp	r0, r3
d00827f4:	bfb8      	it	lt
d00827f6:	4618      	movlt	r0, r3
d00827f8:	e7a4      	b.n	d0082744 <_printf_i+0x168>
d00827fa:	2301      	movs	r3, #1
d00827fc:	4632      	mov	r2, r6
d00827fe:	4649      	mov	r1, r9
d0082800:	4640      	mov	r0, r8
d0082802:	47d0      	blx	sl
d0082804:	3001      	adds	r0, #1
d0082806:	d09b      	beq.n	d0082740 <_printf_i+0x164>
d0082808:	3501      	adds	r5, #1
d008280a:	68e3      	ldr	r3, [r4, #12]
d008280c:	9903      	ldr	r1, [sp, #12]
d008280e:	1a5b      	subs	r3, r3, r1
d0082810:	42ab      	cmp	r3, r5
d0082812:	dcf2      	bgt.n	d00827fa <_printf_i+0x21e>
d0082814:	e7eb      	b.n	d00827ee <_printf_i+0x212>
d0082816:	2500      	movs	r5, #0
d0082818:	f104 0619 	add.w	r6, r4, #25
d008281c:	e7f5      	b.n	d008280a <_printf_i+0x22e>
d008281e:	bf00      	nop
d0082820:	d0087725 	.word	0xd0087725
d0082824:	d0087736 	.word	0xd0087736

d0082828 <__sread>:
d0082828:	b510      	push	{r4, lr}
d008282a:	460c      	mov	r4, r1
d008282c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0082830:	f000 f996 	bl	d0082b60 <_read_r>
d0082834:	2800      	cmp	r0, #0
d0082836:	bfab      	itete	ge
d0082838:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d008283a:	89a3      	ldrhlt	r3, [r4, #12]
d008283c:	181b      	addge	r3, r3, r0
d008283e:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d0082842:	bfac      	ite	ge
d0082844:	6563      	strge	r3, [r4, #84]	; 0x54
d0082846:	81a3      	strhlt	r3, [r4, #12]
d0082848:	bd10      	pop	{r4, pc}

d008284a <__swrite>:
d008284a:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008284e:	461f      	mov	r7, r3
d0082850:	898b      	ldrh	r3, [r1, #12]
d0082852:	05db      	lsls	r3, r3, #23
d0082854:	4605      	mov	r5, r0
d0082856:	460c      	mov	r4, r1
d0082858:	4616      	mov	r6, r2
d008285a:	d505      	bpl.n	d0082868 <__swrite+0x1e>
d008285c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0082860:	2302      	movs	r3, #2
d0082862:	2200      	movs	r2, #0
d0082864:	f000 f916 	bl	d0082a94 <_lseek_r>
d0082868:	89a3      	ldrh	r3, [r4, #12]
d008286a:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d008286e:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d0082872:	81a3      	strh	r3, [r4, #12]
d0082874:	4632      	mov	r2, r6
d0082876:	463b      	mov	r3, r7
d0082878:	4628      	mov	r0, r5
d008287a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d008287e:	f7fd bbf7 	b.w	d0080070 <_write_r>

d0082882 <__sseek>:
d0082882:	b510      	push	{r4, lr}
d0082884:	460c      	mov	r4, r1
d0082886:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d008288a:	f000 f903 	bl	d0082a94 <_lseek_r>
d008288e:	1c43      	adds	r3, r0, #1
d0082890:	89a3      	ldrh	r3, [r4, #12]
d0082892:	bf15      	itete	ne
d0082894:	6560      	strne	r0, [r4, #84]	; 0x54
d0082896:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d008289a:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d008289e:	81a3      	strheq	r3, [r4, #12]
d00828a0:	bf18      	it	ne
d00828a2:	81a3      	strhne	r3, [r4, #12]
d00828a4:	bd10      	pop	{r4, pc}

d00828a6 <__sclose>:
d00828a6:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00828aa:	f000 b8c1 	b.w	d0082a30 <_close_r>
	...

d00828b0 <__swbuf_r>:
d00828b0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00828b2:	460e      	mov	r6, r1
d00828b4:	4614      	mov	r4, r2
d00828b6:	4605      	mov	r5, r0
d00828b8:	b118      	cbz	r0, d00828c2 <__swbuf_r+0x12>
d00828ba:	6983      	ldr	r3, [r0, #24]
d00828bc:	b90b      	cbnz	r3, d00828c2 <__swbuf_r+0x12>
d00828be:	f7ff fbb5 	bl	d008202c <__sinit>
d00828c2:	4b21      	ldr	r3, [pc, #132]	; (d0082948 <__swbuf_r+0x98>)
d00828c4:	429c      	cmp	r4, r3
d00828c6:	d12b      	bne.n	d0082920 <__swbuf_r+0x70>
d00828c8:	686c      	ldr	r4, [r5, #4]
d00828ca:	69a3      	ldr	r3, [r4, #24]
d00828cc:	60a3      	str	r3, [r4, #8]
d00828ce:	89a3      	ldrh	r3, [r4, #12]
d00828d0:	071a      	lsls	r2, r3, #28
d00828d2:	d52f      	bpl.n	d0082934 <__swbuf_r+0x84>
d00828d4:	6923      	ldr	r3, [r4, #16]
d00828d6:	b36b      	cbz	r3, d0082934 <__swbuf_r+0x84>
d00828d8:	6923      	ldr	r3, [r4, #16]
d00828da:	6820      	ldr	r0, [r4, #0]
d00828dc:	1ac0      	subs	r0, r0, r3
d00828de:	6963      	ldr	r3, [r4, #20]
d00828e0:	b2f6      	uxtb	r6, r6
d00828e2:	4283      	cmp	r3, r0
d00828e4:	4637      	mov	r7, r6
d00828e6:	dc04      	bgt.n	d00828f2 <__swbuf_r+0x42>
d00828e8:	4621      	mov	r1, r4
d00828ea:	4628      	mov	r0, r5
d00828ec:	f7ff fb0a 	bl	d0081f04 <_fflush_r>
d00828f0:	bb30      	cbnz	r0, d0082940 <__swbuf_r+0x90>
d00828f2:	68a3      	ldr	r3, [r4, #8]
d00828f4:	3b01      	subs	r3, #1
d00828f6:	60a3      	str	r3, [r4, #8]
d00828f8:	6823      	ldr	r3, [r4, #0]
d00828fa:	1c5a      	adds	r2, r3, #1
d00828fc:	6022      	str	r2, [r4, #0]
d00828fe:	701e      	strb	r6, [r3, #0]
d0082900:	6963      	ldr	r3, [r4, #20]
d0082902:	3001      	adds	r0, #1
d0082904:	4283      	cmp	r3, r0
d0082906:	d004      	beq.n	d0082912 <__swbuf_r+0x62>
d0082908:	89a3      	ldrh	r3, [r4, #12]
d008290a:	07db      	lsls	r3, r3, #31
d008290c:	d506      	bpl.n	d008291c <__swbuf_r+0x6c>
d008290e:	2e0a      	cmp	r6, #10
d0082910:	d104      	bne.n	d008291c <__swbuf_r+0x6c>
d0082912:	4621      	mov	r1, r4
d0082914:	4628      	mov	r0, r5
d0082916:	f7ff faf5 	bl	d0081f04 <_fflush_r>
d008291a:	b988      	cbnz	r0, d0082940 <__swbuf_r+0x90>
d008291c:	4638      	mov	r0, r7
d008291e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0082920:	4b0a      	ldr	r3, [pc, #40]	; (d008294c <__swbuf_r+0x9c>)
d0082922:	429c      	cmp	r4, r3
d0082924:	d101      	bne.n	d008292a <__swbuf_r+0x7a>
d0082926:	68ac      	ldr	r4, [r5, #8]
d0082928:	e7cf      	b.n	d00828ca <__swbuf_r+0x1a>
d008292a:	4b09      	ldr	r3, [pc, #36]	; (d0082950 <__swbuf_r+0xa0>)
d008292c:	429c      	cmp	r4, r3
d008292e:	bf08      	it	eq
d0082930:	68ec      	ldreq	r4, [r5, #12]
d0082932:	e7ca      	b.n	d00828ca <__swbuf_r+0x1a>
d0082934:	4621      	mov	r1, r4
d0082936:	4628      	mov	r0, r5
d0082938:	f000 f80c 	bl	d0082954 <__swsetup_r>
d008293c:	2800      	cmp	r0, #0
d008293e:	d0cb      	beq.n	d00828d8 <__swbuf_r+0x28>
d0082940:	f04f 37ff 	mov.w	r7, #4294967295	; 0xffffffff
d0082944:	e7ea      	b.n	d008291c <__swbuf_r+0x6c>
d0082946:	bf00      	nop
d0082948:	d00876d4 	.word	0xd00876d4
d008294c:	d00876f4 	.word	0xd00876f4
d0082950:	d00876b4 	.word	0xd00876b4

d0082954 <__swsetup_r>:
d0082954:	4b32      	ldr	r3, [pc, #200]	; (d0082a20 <__swsetup_r+0xcc>)
d0082956:	b570      	push	{r4, r5, r6, lr}
d0082958:	681d      	ldr	r5, [r3, #0]
d008295a:	4606      	mov	r6, r0
d008295c:	460c      	mov	r4, r1
d008295e:	b125      	cbz	r5, d008296a <__swsetup_r+0x16>
d0082960:	69ab      	ldr	r3, [r5, #24]
d0082962:	b913      	cbnz	r3, d008296a <__swsetup_r+0x16>
d0082964:	4628      	mov	r0, r5
d0082966:	f7ff fb61 	bl	d008202c <__sinit>
d008296a:	4b2e      	ldr	r3, [pc, #184]	; (d0082a24 <__swsetup_r+0xd0>)
d008296c:	429c      	cmp	r4, r3
d008296e:	d10f      	bne.n	d0082990 <__swsetup_r+0x3c>
d0082970:	686c      	ldr	r4, [r5, #4]
d0082972:	89a3      	ldrh	r3, [r4, #12]
d0082974:	f9b4 200c 	ldrsh.w	r2, [r4, #12]
d0082978:	0719      	lsls	r1, r3, #28
d008297a:	d42c      	bmi.n	d00829d6 <__swsetup_r+0x82>
d008297c:	06dd      	lsls	r5, r3, #27
d008297e:	d411      	bmi.n	d00829a4 <__swsetup_r+0x50>
d0082980:	2309      	movs	r3, #9
d0082982:	6033      	str	r3, [r6, #0]
d0082984:	f042 0340 	orr.w	r3, r2, #64	; 0x40
d0082988:	81a3      	strh	r3, [r4, #12]
d008298a:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008298e:	e03e      	b.n	d0082a0e <__swsetup_r+0xba>
d0082990:	4b25      	ldr	r3, [pc, #148]	; (d0082a28 <__swsetup_r+0xd4>)
d0082992:	429c      	cmp	r4, r3
d0082994:	d101      	bne.n	d008299a <__swsetup_r+0x46>
d0082996:	68ac      	ldr	r4, [r5, #8]
d0082998:	e7eb      	b.n	d0082972 <__swsetup_r+0x1e>
d008299a:	4b24      	ldr	r3, [pc, #144]	; (d0082a2c <__swsetup_r+0xd8>)
d008299c:	429c      	cmp	r4, r3
d008299e:	bf08      	it	eq
d00829a0:	68ec      	ldreq	r4, [r5, #12]
d00829a2:	e7e6      	b.n	d0082972 <__swsetup_r+0x1e>
d00829a4:	0758      	lsls	r0, r3, #29
d00829a6:	d512      	bpl.n	d00829ce <__swsetup_r+0x7a>
d00829a8:	6b61      	ldr	r1, [r4, #52]	; 0x34
d00829aa:	b141      	cbz	r1, d00829be <__swsetup_r+0x6a>
d00829ac:	f104 0344 	add.w	r3, r4, #68	; 0x44
d00829b0:	4299      	cmp	r1, r3
d00829b2:	d002      	beq.n	d00829ba <__swsetup_r+0x66>
d00829b4:	4630      	mov	r0, r6
d00829b6:	f7ff f88f 	bl	d0081ad8 <_free_r>
d00829ba:	2300      	movs	r3, #0
d00829bc:	6363      	str	r3, [r4, #52]	; 0x34
d00829be:	89a3      	ldrh	r3, [r4, #12]
d00829c0:	f023 0324 	bic.w	r3, r3, #36	; 0x24
d00829c4:	81a3      	strh	r3, [r4, #12]
d00829c6:	2300      	movs	r3, #0
d00829c8:	6063      	str	r3, [r4, #4]
d00829ca:	6923      	ldr	r3, [r4, #16]
d00829cc:	6023      	str	r3, [r4, #0]
d00829ce:	89a3      	ldrh	r3, [r4, #12]
d00829d0:	f043 0308 	orr.w	r3, r3, #8
d00829d4:	81a3      	strh	r3, [r4, #12]
d00829d6:	6923      	ldr	r3, [r4, #16]
d00829d8:	b94b      	cbnz	r3, d00829ee <__swsetup_r+0x9a>
d00829da:	89a3      	ldrh	r3, [r4, #12]
d00829dc:	f403 7320 	and.w	r3, r3, #640	; 0x280
d00829e0:	f5b3 7f00 	cmp.w	r3, #512	; 0x200
d00829e4:	d003      	beq.n	d00829ee <__swsetup_r+0x9a>
d00829e6:	4621      	mov	r1, r4
d00829e8:	4630      	mov	r0, r6
d00829ea:	f7ff fbe3 	bl	d00821b4 <__smakebuf_r>
d00829ee:	89a0      	ldrh	r0, [r4, #12]
d00829f0:	f9b4 200c 	ldrsh.w	r2, [r4, #12]
d00829f4:	f010 0301 	ands.w	r3, r0, #1
d00829f8:	d00a      	beq.n	d0082a10 <__swsetup_r+0xbc>
d00829fa:	2300      	movs	r3, #0
d00829fc:	60a3      	str	r3, [r4, #8]
d00829fe:	6963      	ldr	r3, [r4, #20]
d0082a00:	425b      	negs	r3, r3
d0082a02:	61a3      	str	r3, [r4, #24]
d0082a04:	6923      	ldr	r3, [r4, #16]
d0082a06:	b943      	cbnz	r3, d0082a1a <__swsetup_r+0xc6>
d0082a08:	f010 0080 	ands.w	r0, r0, #128	; 0x80
d0082a0c:	d1ba      	bne.n	d0082984 <__swsetup_r+0x30>
d0082a0e:	bd70      	pop	{r4, r5, r6, pc}
d0082a10:	0781      	lsls	r1, r0, #30
d0082a12:	bf58      	it	pl
d0082a14:	6963      	ldrpl	r3, [r4, #20]
d0082a16:	60a3      	str	r3, [r4, #8]
d0082a18:	e7f4      	b.n	d0082a04 <__swsetup_r+0xb0>
d0082a1a:	2000      	movs	r0, #0
d0082a1c:	e7f7      	b.n	d0082a0e <__swsetup_r+0xba>
d0082a1e:	bf00      	nop
d0082a20:	d008775c 	.word	0xd008775c
d0082a24:	d00876d4 	.word	0xd00876d4
d0082a28:	d00876f4 	.word	0xd00876f4
d0082a2c:	d00876b4 	.word	0xd00876b4

d0082a30 <_close_r>:
d0082a30:	b538      	push	{r3, r4, r5, lr}
d0082a32:	4d06      	ldr	r5, [pc, #24]	; (d0082a4c <_close_r+0x1c>)
d0082a34:	2300      	movs	r3, #0
d0082a36:	4604      	mov	r4, r0
d0082a38:	4608      	mov	r0, r1
d0082a3a:	602b      	str	r3, [r5, #0]
d0082a3c:	f7fd fb52 	bl	d00800e4 <_close>
d0082a40:	1c43      	adds	r3, r0, #1
d0082a42:	d102      	bne.n	d0082a4a <_close_r+0x1a>
d0082a44:	682b      	ldr	r3, [r5, #0]
d0082a46:	b103      	cbz	r3, d0082a4a <_close_r+0x1a>
d0082a48:	6023      	str	r3, [r4, #0]
d0082a4a:	bd38      	pop	{r3, r4, r5, pc}
d0082a4c:	d0089518 	.word	0xd0089518

d0082a50 <_fstat_r>:
d0082a50:	b538      	push	{r3, r4, r5, lr}
d0082a52:	4d07      	ldr	r5, [pc, #28]	; (d0082a70 <_fstat_r+0x20>)
d0082a54:	2300      	movs	r3, #0
d0082a56:	4604      	mov	r4, r0
d0082a58:	4608      	mov	r0, r1
d0082a5a:	4611      	mov	r1, r2
d0082a5c:	602b      	str	r3, [r5, #0]
d0082a5e:	f7fd fb45 	bl	d00800ec <_fstat>
d0082a62:	1c43      	adds	r3, r0, #1
d0082a64:	d102      	bne.n	d0082a6c <_fstat_r+0x1c>
d0082a66:	682b      	ldr	r3, [r5, #0]
d0082a68:	b103      	cbz	r3, d0082a6c <_fstat_r+0x1c>
d0082a6a:	6023      	str	r3, [r4, #0]
d0082a6c:	bd38      	pop	{r3, r4, r5, pc}
d0082a6e:	bf00      	nop
d0082a70:	d0089518 	.word	0xd0089518

d0082a74 <_isatty_r>:
d0082a74:	b538      	push	{r3, r4, r5, lr}
d0082a76:	4d06      	ldr	r5, [pc, #24]	; (d0082a90 <_isatty_r+0x1c>)
d0082a78:	2300      	movs	r3, #0
d0082a7a:	4604      	mov	r4, r0
d0082a7c:	4608      	mov	r0, r1
d0082a7e:	602b      	str	r3, [r5, #0]
d0082a80:	f7fd fb5c 	bl	d008013c <_isatty>
d0082a84:	1c43      	adds	r3, r0, #1
d0082a86:	d102      	bne.n	d0082a8e <_isatty_r+0x1a>
d0082a88:	682b      	ldr	r3, [r5, #0]
d0082a8a:	b103      	cbz	r3, d0082a8e <_isatty_r+0x1a>
d0082a8c:	6023      	str	r3, [r4, #0]
d0082a8e:	bd38      	pop	{r3, r4, r5, pc}
d0082a90:	d0089518 	.word	0xd0089518

d0082a94 <_lseek_r>:
d0082a94:	b538      	push	{r3, r4, r5, lr}
d0082a96:	4d07      	ldr	r5, [pc, #28]	; (d0082ab4 <_lseek_r+0x20>)
d0082a98:	4604      	mov	r4, r0
d0082a9a:	4608      	mov	r0, r1
d0082a9c:	4611      	mov	r1, r2
d0082a9e:	2200      	movs	r2, #0
d0082aa0:	602a      	str	r2, [r5, #0]
d0082aa2:	461a      	mov	r2, r3
d0082aa4:	f7fd fb28 	bl	d00800f8 <_lseek>
d0082aa8:	1c43      	adds	r3, r0, #1
d0082aaa:	d102      	bne.n	d0082ab2 <_lseek_r+0x1e>
d0082aac:	682b      	ldr	r3, [r5, #0]
d0082aae:	b103      	cbz	r3, d0082ab2 <_lseek_r+0x1e>
d0082ab0:	6023      	str	r3, [r4, #0]
d0082ab2:	bd38      	pop	{r3, r4, r5, pc}
d0082ab4:	d0089518 	.word	0xd0089518
	...

d0082ac0 <memchr>:
d0082ac0:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d0082ac4:	2a10      	cmp	r2, #16
d0082ac6:	db2b      	blt.n	d0082b20 <memchr+0x60>
d0082ac8:	f010 0f07 	tst.w	r0, #7
d0082acc:	d008      	beq.n	d0082ae0 <memchr+0x20>
d0082ace:	f810 3b01 	ldrb.w	r3, [r0], #1
d0082ad2:	3a01      	subs	r2, #1
d0082ad4:	428b      	cmp	r3, r1
d0082ad6:	d02d      	beq.n	d0082b34 <memchr+0x74>
d0082ad8:	f010 0f07 	tst.w	r0, #7
d0082adc:	b342      	cbz	r2, d0082b30 <memchr+0x70>
d0082ade:	d1f6      	bne.n	d0082ace <memchr+0xe>
d0082ae0:	b4f0      	push	{r4, r5, r6, r7}
d0082ae2:	ea41 2101 	orr.w	r1, r1, r1, lsl #8
d0082ae6:	ea41 4101 	orr.w	r1, r1, r1, lsl #16
d0082aea:	f022 0407 	bic.w	r4, r2, #7
d0082aee:	f07f 0700 	mvns.w	r7, #0
d0082af2:	2300      	movs	r3, #0
d0082af4:	e8f0 5602 	ldrd	r5, r6, [r0], #8
d0082af8:	3c08      	subs	r4, #8
d0082afa:	ea85 0501 	eor.w	r5, r5, r1
d0082afe:	ea86 0601 	eor.w	r6, r6, r1
d0082b02:	fa85 f547 	uadd8	r5, r5, r7
d0082b06:	faa3 f587 	sel	r5, r3, r7
d0082b0a:	fa86 f647 	uadd8	r6, r6, r7
d0082b0e:	faa5 f687 	sel	r6, r5, r7
d0082b12:	b98e      	cbnz	r6, d0082b38 <memchr+0x78>
d0082b14:	d1ee      	bne.n	d0082af4 <memchr+0x34>
d0082b16:	bcf0      	pop	{r4, r5, r6, r7}
d0082b18:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d0082b1c:	f002 0207 	and.w	r2, r2, #7
d0082b20:	b132      	cbz	r2, d0082b30 <memchr+0x70>
d0082b22:	f810 3b01 	ldrb.w	r3, [r0], #1
d0082b26:	3a01      	subs	r2, #1
d0082b28:	ea83 0301 	eor.w	r3, r3, r1
d0082b2c:	b113      	cbz	r3, d0082b34 <memchr+0x74>
d0082b2e:	d1f8      	bne.n	d0082b22 <memchr+0x62>
d0082b30:	2000      	movs	r0, #0
d0082b32:	4770      	bx	lr
d0082b34:	3801      	subs	r0, #1
d0082b36:	4770      	bx	lr
d0082b38:	2d00      	cmp	r5, #0
d0082b3a:	bf06      	itte	eq
d0082b3c:	4635      	moveq	r5, r6
d0082b3e:	3803      	subeq	r0, #3
d0082b40:	3807      	subne	r0, #7
d0082b42:	f015 0f01 	tst.w	r5, #1
d0082b46:	d107      	bne.n	d0082b58 <memchr+0x98>
d0082b48:	3001      	adds	r0, #1
d0082b4a:	f415 7f80 	tst.w	r5, #256	; 0x100
d0082b4e:	bf02      	ittt	eq
d0082b50:	3001      	addeq	r0, #1
d0082b52:	f415 3fc0 	tsteq.w	r5, #98304	; 0x18000
d0082b56:	3001      	addeq	r0, #1
d0082b58:	bcf0      	pop	{r4, r5, r6, r7}
d0082b5a:	3801      	subs	r0, #1
d0082b5c:	4770      	bx	lr
d0082b5e:	bf00      	nop

d0082b60 <_read_r>:
d0082b60:	b538      	push	{r3, r4, r5, lr}
d0082b62:	4d07      	ldr	r5, [pc, #28]	; (d0082b80 <_read_r+0x20>)
d0082b64:	4604      	mov	r4, r0
d0082b66:	4608      	mov	r0, r1
d0082b68:	4611      	mov	r1, r2
d0082b6a:	2200      	movs	r2, #0
d0082b6c:	602a      	str	r2, [r5, #0]
d0082b6e:	461a      	mov	r2, r3
d0082b70:	f7fd faae 	bl	d00800d0 <_read>
d0082b74:	1c43      	adds	r3, r0, #1
d0082b76:	d102      	bne.n	d0082b7e <_read_r+0x1e>
d0082b78:	682b      	ldr	r3, [r5, #0]
d0082b7a:	b103      	cbz	r3, d0082b7e <_read_r+0x1e>
d0082b7c:	6023      	str	r3, [r4, #0]
d0082b7e:	bd38      	pop	{r3, r4, r5, pc}
d0082b80:	d0089518 	.word	0xd0089518
d0082b84:	65627543 	.word	0x65627543
d0082b88:	65642079 	.word	0x65642079
d0082b8c:	65206f6d 	.word	0x65206f6d
d0082b90:	6465646e 	.word	0x6465646e
d0082b94:	20293a20 	.word	0x20293a20
d0082b98:	3d646f6d 	.word	0x3d646f6d
d0082b9c:	000a6425 	.word	0x000a6425
d0082ba0:	00000000 	.word	0x00000000
d0082ba4:	0000ffff 	.word	0x0000ffff
d0082ba8:	00000000 	.word	0x00000000
d0082bac:	00000001 	.word	0x00000001
d0082bb0:	ffff0000 	.word	0xffff0000
d0082bb4:	00000000 	.word	0x00000000
d0082bb8:	00010000 	.word	0x00010000
d0082bbc:	00000000 	.word	0x00000000
d0082bc0:	0000ffff 	.word	0x0000ffff
d0082bc4:	00000000 	.word	0x00000000
d0082bc8:	00000001 	.word	0x00000001
d0082bcc:	00000000 	.word	0x00000000
d0082bd0:	00010000 	.word	0x00010000
d0082bd4:	00000000 	.word	0x00000000
d0082bd8:	00000001 	.word	0x00000001
d0082bdc:	00000000 	.word	0x00000000
d0082be0:	00000001 	.word	0x00000001
	...
d0082bec:	00000001 	.word	0x00000001
d0082bf0:	00000000 	.word	0x00000000
d0082bf4:	00000001 	.word	0x00000001
d0082bf8:	00010000 	.word	0x00010000
d0082bfc:	00000000 	.word	0x00000000
d0082c00:	00000001 	.word	0x00000001
d0082c04:	00000000 	.word	0x00000000
d0082c08:	00010000 	.word	0x00010000
	...
d0082c14:	00000001 	.word	0x00000001
d0082c18:	00000001 	.word	0x00000001
d0082c1c:	00000000 	.word	0x00000000
d0082c20:	00010000 	.word	0x00010000
	...
d0082c2c:	00000001 	.word	0x00000001

d0082c30 <face_base_idx>:
d0082c30:	04030201 00000605                       ........

d0082c38 <message>:
d0082c38:	20202020 20202020 20202020 2a2a2a2a                 ****
d0082c48:	4c454820 2a204f4c 0a2a2a2a 2d2d2d0a      HELLO ****..---
d0082c58:	2d2d2d2d 2d2d2d2d 2d2d2d2d 2d2d2d2d     ----------------
d0082c68:	2d2d2d2d 2d2d2d2d 2d2d2d2d 2d2d2d2d     ----------------
d0082c78:	0a2d2d2d 6c65480a 202c6f6c 6f682049     ---..Hello, I ho
d0082c88:	74206570 20736968 6f6d6564 726f7720     pe this demo wor
d0082c98:	0a21736b 6968540a 73692073 65687420     ks!..This is the
d0082ca8:	646c6f20 63643320 74656275 20747365      old 3dcubetest 
d0082cb8:	61656469 6f700a0a 64657472 206f7420     idea..ported to 
d0082cc8:	20656874 6577656e 69532072 786f6264     the newer Sidbox
d0082cd8:	49504120 490a0a2e 72642074 20737761      API...It draws 
d0082ce8:	6f6d2061 69687072 7320676e 69646275     a morphing subdi
d0082cf8:	65646976 75632064 0a2c6562 6220610a     vided cube,..a b
d0082d08:	73206769 6c6f7263 676e696c 65686320     ig scrolling che
d0082d18:	72656b63 72616f62 616c2064 2c726579     ckerboard layer,
d0082d28:	6e610a0a 68742064 76207369 20797265     ..and this very 
d0082d38:	6f706d69 6e617472 63732074 6c6c6f72     important scroll
d0082d48:	65742079 0a2e7478 2d2d2d0a 2d2d2d2d     y text...-------
d0082d58:	2d2d2d2d 2d2d2d2d 2d2d2d2d 2d2d2d2d     ----------------
d0082d68:	2d2d2d2d 2d2d2d2d 2d2d2d2d 0a2d2d2d     ---------------.
d0082d78:	6568540a 646c6f20 6d656420 6f70206f     .The old demo po
d0082d88:	2064656b 20495041 75727473 72757463     ked API structur
d0082d98:	0a0a7365 65726964 796c7463 6854202e     es..directly. Th
d0082da8:	6f207369 7520656e 20736573 20656874     is one uses the 
d0082db8:	77203276 70706172 0a737265 646e610a     v2 wrappers..and
d0082dc8:	65656b20 74207370 74206568 20796e69      keeps the tiny 
d0082dd8:	61697274 656c676e 73617220 69726574     triangle rasteri
d0082de8:	0a72657a 636f6c0a 74206c61 6874206f     zer..local to th
d0082df8:	70612065 74656c70 2d0a0a2e 2d2d2d2d     e applet...-----
d0082e08:	2d2d2d2d 2d2d2d2d 2d2d2d2d 2d2d2d2d     ----------------
d0082e18:	2d2d2d2d 2d2d2d2d 2d2d2d2d 2d2d2d2d     ----------------
d0082e28:	480a0a2d 20646c6f 45524946 4f202b20     -..Hold FIRE + O
d0082e38:	6f74204b 69786520 0a0a2e74 20202020     K to exit...    
d0082e48:	20202020 20202020 65202020 6520646e                end e
d0082e58:	0a21646e 000a0a0a                       nd!.....

d0082e60 <tune>:
d0082e60:	696c6365 00657370 00000000 00000000     eclipse.........
d0082e70:	00000000 69482023 74694c2d 00000065     ....# Hi-Lite...
	...
d0082e88:	80020000 00004000 63280100 79622029     .....@....(c) by
d0082e98:	2d696820 6574696c 32392720 002e2e2e      hi-lite '92....
d0082ea8:	00000000 01000000 5c2f5c2f 5c2f5c2f     ......../\/\/\/\
d0082eb8:	5c2f5c2f 5c2f5c2f 5c2f5c2f 0001002f     /\/\/\/\/\/\/...
d0082ec8:	00004000 2e2e0100 6e612e2e 6568746f     .@........anothe
d0082ed8:	68632072 75747069 0021656e 4000d802     r chiptune!....@
d0082ee8:	01000000 73696874 656e6f20 73617720     ....this one was
d0082ef8:	64616d20 6e6f2065 96000000 09004000      made on.....@..
d0082f08:	68748d00 61642065 65772079 746f6720     ..the day we got
d0082f18:	72756f20 00000000 40001800 0e000a00      our.......@....
d0082f28:	74736165 206e7265 61636176 6e6f6974     eastern vacation
d0082f38:	6e692073 17000000 09004000 63730e00     s in.....@....sc
d0082f48:	6c6f6f68 616d2e20 20656279 74616874     hool .maybe that
d0082f58:	00007327 40001600 0e000800 20796877     's.....@....why 
d0082f68:	73696874 756f7320 2073646e 74616874     this sounds that
d0082f78:	15000000 07004000 61680e00 20797070     .....@....happy 
d0082f88:	3f2e2e2e 3f213f21 3f213f21 00213f21     ...?!?!?!?!?!?!.
d0082f98:	40001400 0e000600 206d7573 6c6c6568     ...@....sum hell
d0082fa8:	7420736f 2d3a206f 0000003e 12000000     os to :->.......
d0082fb8:	04004000 2e6a0e00 2e652e6f 6565722c     .@....j.o.e.,ree
d0082fc8:	2c6b6f62 61657264 0072656d 40000e00     bok,dreamer....@
d0082fd8:	0e000000 2c6c686a 68746f67 612c6369     ....jhl,gothic,a
d0082fe8:	2f636564 2e702173 1800002e 0a004000     dec/s!p......@..
d0082ff8:	72620e00 6d2c736f 65747361 79632f72     ..bros,master/cy
d0083008:	2e786174 002e2e2e 40001700 0e000900     tax........@....
d0083018:	69646f7a 762f6361 2e2e2e66 2e2e2e2e     zodiac/vf.......
d0083028:	2e2e2e2e 1600002e 08004000 61640e00     .........@....da
d0083038:	276c7972 6172206e 742f6576 2e2e6c73     ryl'n rave/tsl..
d0083048:	002e2e2e 40001500 0e000700 20646e61     .......@....and 
d0083058:	206c6c61 20656874 6568746f 00002072     all the other ..
d0083068:	14000000 06004000 696e0e00 67206563     .....@....nice g
d0083078:	20737975 6e6b2069 2e20776f 002e2e2e     uys i know .....
d0083088:	40001200 0e000400 6f63666f 65737275     ...@....ofcourse
d0083098:	206f6e20 65657267 74207a74 0e00006f      no greetz to...
d00830a8:	00004000 68740e00 2065736f 206f6877     .@....those who 
d00830b8:	6e657261 6e207427 00656369 00000000     aren't nice.....
d00830c8:	01000000 622e2e2e 6c206461 206b6375     .......bad luck 
d00830d8:	213f213f 2e2e2e3f 0000002e 00000000     ?!?!?...........
d00830e8:	20730100 20672069 2065206e 2d3a2064     ..s i g n e d :-
d00830f8:	0000003e 00000000 00000000 01000000     >...............
d0083108:	69682d3d 74696c2d 21732f65 72742f70     =-hi-lite/s!p/tr
d0083118:	3d2d6973 0000002d 00000000 32300100     si-=-.........02
d0083128:	2d34302d 20203239 20202020 34312020     -04-92        14
d0083138:	0032343a 00000000 01000000 00000000     :42.............
	...
d0083160:	00000100 00000000 00000000 00000000     ................
	...
d008317c:	01000000 00000000 00000000 00000000     ................
	...
d008319c:	00000100 00000000 00000000 00000000     ................
	...
d00831b8:	01000000 00000000 00000000 00000000     ................
	...
d00831d8:	00000100 00000000 00000000 00000000     ................
	...
d00831f4:	01000000 00000000 00000000 00000000     ................
	...
d0083214:	7f0f0100 03020100 07060504 0a090908     ................
d0083224:	000c0b0b 00000000 00000000 00000000     ................
	...
d0083298:	2e4b2e4d 0f3aa602 0f5a5301 040f0000     M.K...:..SZ.....
d00832a8:	00000000 0f0a0000 0f0a0000 00000000     ................
d00832b8:	00000000 2a1caa00 0f5a5301 00000000     .......*.SZ.....
d00832c8:	00000000 0f0a0000 0f0a0000 00000000     ................
d00832d8:	00000000 0e4a5301 0e5aaa00 00000000     .....SJ...Z.....
d00832e8:	00000000 0e0a0000 0e0a0000 00000000     ................
d00832f8:	00000000 201caa00 0e5a5301 00000000     ....... .SZ.....
d0083308:	00000000 0e0a0000 0e0a0000 00000000     ................
d0083318:	00000000 3a1caa00 0c5a5301 00000000     .......:.SZ.....
d0083328:	00000000 0c0a0000 0c0a0000 00000000     ................
d0083338:	00000000 0c3aa602 0c5aaa00 00000000     ......:...Z.....
d0083348:	00000000 0c0a0000 0c0a0000 00000000     ................
d0083358:	00000000 0b4a5301 0b5a5301 00000000     .....SJ..SZ.....
d0083368:	00000000 0b0a0000 0b0a0000 00000000     ................
d0083378:	00000000 201caa00 0b5abe00 00000000     ....... ..Z.....
d0083388:	00000000 0b0a0000 0b0a0000 00000000     ................
d0083398:	00000000 0a3aa602 0a5aaa00 00000000     ......:...Z.....
d00833a8:	00000000 0a0a0000 0a0a0000 00000000     ................
d00833b8:	00000000 2a1caa00 0a5a5301 00000000     .......*.SZ.....
d00833c8:	00000000 0a0a0000 0a0a0000 00000000     ................
d00833d8:	00000000 094a5301 095a5301 00000000     .....SJ..SZ.....
d00833e8:	00000000 090a0000 090a0000 00000000     ................
d00833f8:	00000000 201caa00 095aaa00 00000000     ....... ..Z.....
d0083408:	00000000 090a0000 090a0000 00000000     ................
d0083418:	00000000 081aaa00 085a5301 00000000     .........SZ.....
d0083428:	00000000 080a0000 080a0000 00000000     ................
d0083438:	00000000 083aa602 085a5301 00000000     ......:..SZ.....
d0083448:	00000000 080a0000 080a0000 00000000     ................
d0083458:	00000000 074a5301 075aaa00 00000000     .....SJ...Z.....
d0083468:	00000000 070a0000 070a0000 00000000     ................
d0083478:	00000000 2a1caa00 075abe00 00000000     .......*..Z.....
d0083488:	00000000 070a0000 070a0000 00000000     ................
d0083498:	00000000 063aa602 065a5301 00000000     ......:..SZ.....
d00834a8:	00000000 060a0000 060a0000 00000000     ................
d00834b8:	00000000 201caa00 065a5301 00000000     ....... .SZ.....
d00834c8:	00000000 060a0000 060a0000 00000000     ................
d00834d8:	00000000 054a5301 055aaa00 00000000     .....SJ...Z.....
d00834e8:	00000000 050a0000 050a0000 00000000     ................
d00834f8:	00000000 201caa00 055a5301 00000000     ....... .SZ.....
d0083508:	00000000 050a0000 050a0000 00000000     ................
d0083518:	00000000 041aaa00 045a5301 00000000     .........SZ.....
d0083528:	00000000 040a0000 040a0000 00000000     ................
d0083538:	00000000 043aa602 045aaa00 00000000     ......:...Z.....
d0083548:	00000000 040a0000 040a0000 00000000     ................
d0083558:	00000000 034a5301 035a5301 00000000     .....SJ..SZ.....
d0083568:	00000000 030a0000 030a0000 00000000     ................
d0083578:	00000000 2a1caa00 035abe00 00000000     .......*..Z.....
d0083588:	00000000 030a0000 030a0000 00000000     ................
d0083598:	00000000 023aa602 025aaa00 00000000     ......:...Z.....
d00835a8:	00000000 020a0000 020a0000 00000000     ................
d00835b8:	00000000 201caa00 025a5301 00000000     ....... .SZ.....
d00835c8:	00000000 020a0000 020a0000 00000000     ................
d00835d8:	00000000 014a5301 015a5301 00000000     .....SJ..SZ.....
d00835e8:	00000000 010a0000 010a0000 00000000     ................
d00835f8:	00000000 201caa00 015aaa00 00000000     ....... ..Z.....
d0083608:	00000000 010a0000 010a0000 00000000     ................
d0083618:	00000000 0010aa00 00505301 00000000     .........SP.....
	...
d008363c:	0030a602 00505301 00000000 00000000     ..0..SP.........
	...
d008365c:	2e4c5301 0050aa00 00000000 00000000     .SL...P.........
	...
d008367c:	00405301 0050be00 00000000 00000000     .S@...P.........
	...
d008369c:	043fa602 00505301 4760ac01 00000000     ..?..SP...`G....
	...
d00836b4:	47700000 00000000 2a1caa00 00505301     ..pG.......*.SP.
d00836c4:	47800000 00000000 00000000 00000000     ...G............
d00836d4:	47900000 00000000 00405301 0050aa00     ...G.....S@...P.
d00836e4:	47a00000 00000000 00000000 00000000     ...G............
d00836f4:	47b00000 00000000 201caa00 00505301     ...G....... .SP.
d0083704:	47c00000 00000000 00000000 00000000     ...G............
d0083714:	47b00000 00000000 3a1caa00 00505301     ...G.......:.SP.
d0083724:	47a00000 00000000 00000000 00000000     ...G............
d0083734:	47900000 00000000 0030a602 0050aa00     ...G......0...P.
d0083744:	47800000 00000000 00000000 00000000     ...G............
d0083754:	47700000 00000000 00405301 00505301     ..pG.....S@..SP.
d0083764:	47600000 00000000 00000000 00000000     ..`G............
d0083774:	47700000 00000000 201caa00 0050be00     ..pG....... ..P.
d0083784:	47800000 00000000 00000000 00000000     ...G............
d0083794:	47900000 00000000 0030a602 0050aa00     ...G......0...P.
d00837a4:	47a00000 00000000 00000000 00000000     ...G............
d00837b4:	47b00000 00000000 2a1caa00 00505301     ...G.......*.SP.
d00837c4:	47c00000 00000000 00000000 00000000     ...G............
d00837d4:	47b00000 00000000 00405301 00505301     ...G.....S@..SP.
d00837e4:	47a00000 00000000 00000000 00000000     ...G............
d00837f4:	47900000 00000000 201caa00 0050aa00     ...G....... ..P.
d0083804:	47800000 00000000 00000000 00000000     ...G............
d0083814:	47700000 00000000 0010aa00 00505301     ..pG.........SP.
d0083824:	47600000 00000000 00000000 00000000     ..`G............
d0083834:	47700000 00000000 0030a602 00505301     ..pG......0..SP.
d0083844:	47800000 00000000 00000000 00000000     ...G............
d0083854:	47900000 00000000 00405301 0050aa00     ...G.....S@...P.
d0083864:	47a00000 00000000 00000000 00000000     ...G............
d0083874:	47b00000 00000000 2a1caa00 0050be00     ...G.......*..P.
d0083884:	47c00000 00000000 00000000 00000000     ...G............
d0083894:	47b00000 00000000 0030a602 00505301     ...G......0..SP.
d00838a4:	59a00000 00000000 00000000 00000000     ...Y............
d00838b4:	59900000 00000000 201caa00 00505301     ...Y....... .SP.
d00838c4:	59800000 00000000 00000000 00000000     ...Y............
d00838d4:	59700000 00000000 00405301 0050aa00     ..pY.....S@...P.
d00838e4:	59600000 00000000 00000000 00000000     ..`Y............
d00838f4:	59700000 00000000 201caa00 00505301     ..pY....... .SP.
d0083904:	59800000 00000000 00000000 00000000     ...Y............
d0083914:	59900000 00000000 0010aa00 00505301     ...Y.........SP.
d0083924:	59a00000 00000000 00000000 00000000     ...Y............
d0083934:	59b00000 00000000 0030a602 0050aa00     ...Y......0...P.
d0083944:	59c00000 00000000 00000000 00000000     ...Y............
d0083954:	59b00000 00000000 00405301 00505301     ...Y.....S@..SP.
d0083964:	59a00000 00000000 00000000 00000000     ...Y............
d0083974:	59900000 00000000 2a1caa00 0050be00     ...Y.......*..P.
d0083984:	59800000 00000000 00000000 00000000     ...Y............
d0083994:	59700000 00000000 0030a602 0050aa00     ..pY......0...P.
d00839a4:	59600000 00000000 00000000 00000000     ..`Y............
d00839b4:	59700000 00000000 201caa00 00505301     ..pY....... .SP.
d00839c4:	59800000 00000000 00000000 00000000     ...Y............
d00839d4:	59900000 00000000 00405301 00505301     ...Y.....S@..SP.
d00839e4:	59a00000 00000000 00000000 00000000     ...Y............
d00839f4:	59b00000 00000000 201caa00 0050aa00     ...Y....... ..P.
d0083a04:	59c00000 00000000 00000000 00000000     ...Y............
d0083a14:	59b00000 00000000 0010aa00 00505301     ...Y.........SP.
d0083a24:	59a00000 00000000 00000000 00000000     ...Y............
d0083a34:	59900000 00000000 0030a602 00505301     ...Y......0..SP.
d0083a44:	59800000 00000000 00000000 00000000     ...Y............
d0083a54:	59700000 00000000 2e4c5301 0050aa00     ..pY.....SL...P.
d0083a64:	59600000 00000000 00000000 00000000     ..`Y............
d0083a74:	59700000 00000000 00405301 0050be00     ..pY.....S@...P.
d0083a84:	59800000 00000000 00000000 00000000     ...Y............
d0083a94:	59900000 00000000 043fa602 00500d01     ...Y......?...P.
d0083aa4:	37605301 00000000 00000000 00000000     .S`7............
d0083ab4:	37700000 00000000 2a1caa00 00500d01     ..p7.......*..P.
d0083ac4:	37800000 00000000 00000000 00000000     ...7............
d0083ad4:	37900000 00000000 00405301 00508700     ...7.....S@...P.
d0083ae4:	37a00000 00000000 00000000 00000000     ...7............
d0083af4:	37b00000 00000000 201caa00 00500d01     ...7....... ..P.
d0083b04:	37c00000 00000000 00000000 00000000     ...7............
d0083b14:	37b00000 00000000 3a1caa00 00500d01     ...7.......:..P.
d0083b24:	37a00000 00000000 00000000 00000000     ...7............
d0083b34:	37900000 00000000 0030a602 00508700     ...7......0...P.
d0083b44:	37800000 00000000 00000000 00000000     ...7............
d0083b54:	37700000 00000000 00405301 00500d01     ..p7.....S@...P.
d0083b64:	37600000 00000000 00000000 00000000     ..`7............
d0083b74:	37700000 00000000 201caa00 00509700     ..p7....... ..P.
d0083b84:	37800000 00000000 00000000 00000000     ...7............
d0083b94:	37900000 00000000 0030a602 00508700     ...7......0...P.
d0083ba4:	37a00000 00000000 00000000 00000000     ...7............
d0083bb4:	37b00000 00000000 2a1caa00 00500d01     ...7.......*..P.
d0083bc4:	37c00000 00000000 00000000 00000000     ...7............
d0083bd4:	37b00000 00000000 00405301 00500d01     ...7.....S@...P.
d0083be4:	37a00000 00000000 00000000 00000000     ...7............
d0083bf4:	37900000 00000000 201caa00 00508700     ...7....... ..P.
d0083c04:	37800000 00000000 00000000 00000000     ...7............
d0083c14:	37700000 00000000 0010aa00 00500d01     ..p7..........P.
d0083c24:	37600000 00000000 00000000 00000000     ..`7............
d0083c34:	37700000 00000000 0030a602 00500d01     ..p7......0...P.
d0083c44:	37800000 00000000 00000000 00000000     ...7............
d0083c54:	37900000 00000000 00405301 00508700     ...7.....S@...P.
d0083c64:	37a00000 00000000 00000000 00000000     ...7............
d0083c74:	37b00000 00000000 2a1caa00 00509700     ...7.......*..P.
d0083c84:	37c00000 00000000 00000000 00000000     ...7............
d0083c94:	37b00000 00000000 0030a602 00505301     ...7......0..SP.
d0083ca4:	47a0ac01 00000000 00000000 00000000     ...G............
d0083cb4:	47900000 00000000 201caa00 00505301     ...G....... .SP.
d0083cc4:	47800000 00000000 00000000 00000000     ...G............
d0083cd4:	47700000 00000000 00405301 0050aa00     ..pG.....S@...P.
d0083ce4:	47600000 00000000 00000000 00000000     ..`G............
d0083cf4:	47700000 00000000 201caa00 00505301     ..pG....... .SP.
d0083d04:	47800000 00000000 00000000 00000000     ...G............
d0083d14:	47900000 00000000 0010aa00 00505301     ...G.........SP.
d0083d24:	47a00000 00000000 00000000 00000000     ...G............
d0083d34:	47b00000 00000000 0030a602 0050aa00     ...G......0...P.
d0083d44:	47c00000 00000000 00000000 00000000     ...G............
d0083d54:	47b00000 00000000 00405301 00505301     ...G.....S@..SP.
d0083d64:	47a00000 00000000 00000000 00000000     ...G............
d0083d74:	47900000 00000000 2a1caa00 0050be00     ...G.......*..P.
d0083d84:	47800000 00000000 00000000 00000000     ...G............
d0083d94:	47700000 00000000 0030a602 0050aa00     ..pG......0...P.
d0083da4:	47600000 00000000 00000000 00000000     ..`G............
d0083db4:	47700000 00000000 201caa00 00505301     ..pG....... .SP.
d0083dc4:	47800000 00000000 00000000 00000000     ...G............
d0083dd4:	47900000 00000000 00405301 00505301     ...G.....S@..SP.
d0083de4:	47a00000 00000000 00000000 00000000     ...G............
d0083df4:	47b00000 00000000 201caa00 0050aa00     ...G....... ..P.
d0083e04:	47c00000 00000000 00000000 00000000     ...G............
d0083e14:	47b00000 00000000 0010aa00 00505301     ...G.........SP.
d0083e24:	47a00000 00000000 00000000 00000000     ...G............
d0083e34:	47900000 00000000 0030a602 00505301     ...G......0..SP.
d0083e44:	47800000 00000000 00000000 00000000     ...G............
d0083e54:	47700000 00000000 2e4c5301 0050aa00     ..pG.....SL...P.
d0083e64:	47600000 00000000 00000000 00000000     ..`G............
d0083e74:	47700000 00000000 00405301 0050be00     ..pG.....S@...P.
d0083e84:	47800000 00000000 00000000 00000000     ...G............
d0083e94:	47900000 00000000 043fa602 00505301     ...G......?..SP.
d0083ea4:	4760ac01 306c1d01 00000000 00000000     ..`G..l0........
d0083eb4:	47700000 400c0000 2a1caa00 00505301     ..pG...@...*.SP.
d0083ec4:	47800000 a2040000 00000000 00000000     ...G............
d0083ed4:	47900000 a2040000 00405301 0050aa00     ...G.....S@...P.
d0083ee4:	47a00000 a2040000 00000000 00000000     ...G............
d0083ef4:	47b00000 a2040000 201caa00 00505301     ...G....... .SP.
d0083f04:	47c00000 a2040000 00000000 00000000     ...G............
d0083f14:	47b00000 a2040000 3a1caa00 00505301     ...G.......:.SP.
d0083f24:	47a00000 ff734001 00000000 00000000     ...G.@s.........
d0083f34:	47900000 00000000 0030a602 0050aa00     ...G......0...P.
d0083f44:	47800000 ff835301 00000000 00000000     ...G.S..........
d0083f54:	47700000 00000000 00405301 00505301     ..pG.....S@..SP.
d0083f64:	47600000 200c0000 00000000 00000000     ..`G... ........
d0083f74:	47700000 106c5301 201caa00 0050be00     ..pG.Sl.... ..P.
d0083f84:	47800000 ff934001 00000000 00000000     ...G.@..........
d0083f94:	47900000 00000000 0030a602 0050aa00     ...G......0...P.
d0083fa4:	47a00000 a2040000 00000000 00000000     ...G............
d0083fb4:	47b00000 a2040000 2a1caa00 00505301     ...G.......*.SP.
d0083fc4:	47c00000 ffa34001 00000000 00000000     ...G.@..........
d0083fd4:	47b00000 00000000 00405301 00505301     ...G.....S@..SP.
d0083fe4:	47a00000 ffb35301 00000000 00000000     ...G.S..........
d0083ff4:	47900000 00000000 201caa00 0050aa00     ...G....... ..P.
d0084004:	47800000 200c0000 00000000 00000000     ...G... ........
d0084014:	47700000 00000000 0010aa00 00505301     ..pG.........SP.
d0084024:	47600000 ffc3ac01 00000000 00000000     ..`G............
d0084034:	47700000 ff030000 0030a602 00505301     ..pG......0..SP.
d0084044:	47800000 04060000 00000000 00000000     ...G............
d0084054:	47900000 04060000 00405301 0050aa00     ...G.....S@...P.
d0084064:	47a00000 25bc3a02 00000000 00000000     ...G.:.%........
d0084074:	47b00000 2a0c0000 2a1caa00 0050be00     ...G...*...*..P.
d0084084:	47c00000 350c0000 00000000 00000000     ...G...5........
d0084094:	47b00000 400c0000 0030a602 00505301     ...G...@..0..SP.
d00840a4:	59a00000 ffa31d01 00000000 00000000     ...Y............
d00840b4:	59900000 00000000 201caa00 00505301     ...Y....... .SP.
d00840c4:	59800000 a2040000 00000000 00000000     ...Y............
d00840d4:	59700000 a2040000 00405301 0050aa00     ..pY.....S@...P.
d00840e4:	59600000 a2040000 00000000 00000000     ..`Y............
d00840f4:	59700000 a2040000 201caa00 00505301     ..pY....... .SP.
d0084104:	59800000 02060000 00000000 00000000     ...Y............
d0084114:	59900000 02060000 0010aa00 00505301     ...Y.........SP.
d0084124:	59a00000 3f934001 00000000 00000000     ...Y.@.?........
d0084134:	59b00000 00000000 0030a602 0050aa00     ...Y......0...P.
d0084144:	59c00000 8f835301 00000000 00000000     ...Y.S..........
d0084154:	59b00000 00000000 00405301 00505301     ...Y.....S@..SP.
d0084164:	59a00000 200c0000 00000000 00000000     ...Y... ........
d0084174:	59900000 00000000 2a1caa00 0050be00     ...Y.......*..P.
d0084184:	59800000 00704001 00000000 00000000     ...Y.@p.........
d0084194:	59700000 00000000 0030a602 0050aa00     ..pY......0...P.
d00841a4:	59600000 a2040000 00000000 00000000     ..`Y............
d00841b4:	59700000 a2040000 201caa00 00505301     ..pY....... .SP.
d00841c4:	59800000 ff634001 00000000 00000000     ...Y.@c.........
d00841d4:	59900000 00000000 00405301 00505301     ...Y.....S@..SP.
d00841e4:	59a00000 4f735301 00000000 00000000     ...Y.SsO........
d00841f4:	59b00000 00000000 201caa00 0050aa00     ...Y....... ..P.
d0084204:	59c00000 a2040000 00000000 00000000     ...Y............
d0084214:	59b00000 a2040000 0010aa00 00505301     ...Y.........SP.
d0084224:	59a00000 0f83fe00 00000000 00000000     ...Y............
d0084234:	59900000 0f030000 0030a602 00505301     ...Y......0..SP.
d0084244:	59800000 a2040000 00000000 00000000     ...Y............
d0084254:	59700000 a2040000 2e4c5301 0050aa00     ..pY.....SL...P.
d0084264:	59600000 ff731d01 00000000 00000000     ..`Y..s.........
d0084274:	59700000 00000000 00405301 0050be00     ..pY.....S@...P.
d0084284:	59800000 02060000 00000000 00000000     ...Y............
d0084294:	59900000 02060000 043fa602 00500d01     ...Y......?...P.
d00842a4:	4760ac01 3f63e200 00000000 00000000     ..`G..c?........
d00842b4:	47700000 3f030000 2a1caa00 00500d01     ..pG...?...*..P.
d00842c4:	47800000 a2040000 00000000 00000000     ...G............
d00842d4:	47900000 a2040000 00405301 00508700     ...G.....S@...P.
d00842e4:	47a00000 a2040000 00000000 00000000     ...G............
d00842f4:	47b00000 a2040000 201caa00 00500d01     ...G....... ..P.
d0084304:	47c00000 a2040000 00000000 00000000     ...G............
d0084314:	47b00000 a2040000 3a1caa00 00500d01     ...G.......:..P.
d0084324:	47a00000 ff731d01 00000000 00000000     ...G..s.........
d0084334:	47900000 00000000 0030a602 00508700     ...G......0...P.
d0084344:	47800000 ff835301 00000000 00000000     ...G.S..........
d0084354:	47700000 00000000 00405301 00500d01     ..pG.....S@...P.
d0084364:	47600000 200c0000 00000000 00000000     ..`G... ........
d0084374:	47700000 109c5301 201caa00 00509700     ..pG.S..... ..P.
d0084384:	47800000 ff93e200 00000000 00000000     ...G............
d0084394:	47900000 00000000 0030a602 00508700     ...G......0...P.
d00843a4:	47a00000 a2040000 00000000 00000000     ...G............
d00843b4:	47b00000 a2040000 2a1caa00 00500d01     ...G.......*..P.
d00843c4:	47c00000 ffa31d01 00000000 00000000     ...G............
d00843d4:	47b00000 00000000 00405301 00500d01     ...G.....S@...P.
d00843e4:	47a00000 ffb35301 00000000 00000000     ...G.S..........
d00843f4:	47900000 00000000 201caa00 00508700     ...G....... ..P.
d0084404:	47800000 200c0000 00000000 00000000     ...G... ........
d0084414:	47700000 00000000 0010aa00 00500d01     ..pG..........P.
d0084424:	47600000 ffc3d600 00000000 00000000     ..`G............
d0084434:	47700000 ff030000 0030a602 00500d01     ..pG......0...P.
d0084444:	47800000 04060000 00000000 00000000     ...G............
d0084454:	47900000 04060000 00405301 00508700     ...G.....S@...P.
d0084464:	47a00000 25bce200 00000000 00000000     ...G...%........
d0084474:	47b00000 2a0c0000 2a1caa00 00509700     ...G...*...*..P.
d0084484:	47c00000 350c0000 00000000 00000000     ...G...5........
d0084494:	47b00000 400c0000 0030a602 0050fe00     ...G...@..0...P.
d00844a4:	47a04001 ffa3d600 00000000 00000000     .@.G............
d00844b4:	47900000 00000000 201caa00 0050fe00     ...G....... ..P.
d00844c4:	47800000 a2040000 00000000 00000000     ...G............
d00844d4:	47700000 a2040000 00405301 00507f00     ..pG.....S@...P.
d00844e4:	47600000 a2040000 00000000 00000000     ..`G............
d00844f4:	47700000 a2040000 201caa00 0050fe00     ..pG....... ..P.
d0084504:	47800000 02060000 00000000 00000000     ...G............
d0084514:	47900000 02060000 0010aa00 0050fe00     ...G..........P.
d0084524:	47a00000 3f93e200 00000000 00000000     ...G...?........
d0084534:	47b00000 00000000 0030a602 00507f00     ...G......0...P.
d0084544:	47c00000 8f831d01 00000000 00000000     ...G............
d0084554:	47b00000 00000000 00405301 0050fe00     ...G.....S@...P.
d0084564:	47a00000 200c0000 00000000 00000000     ...G... ........
d0084574:	47900000 00000000 2a1caa00 00508f00     ...G.......*..P.
d0084584:	47800000 0070d600 00000000 00000000     ...G..p.........
d0084594:	47700000 00000000 0030a602 0050aa00     ..pG......0...P.
d00845a4:	4760ac01 a2040000 00000000 00000000     ..`G............
d00845b4:	47700000 a2040000 201caa00 00505301     ..pG....... .SP.
d00845c4:	47800000 ff631d01 00000000 00000000     ...G..c.........
d00845d4:	47900000 00000000 00405301 00505301     ...G.....S@..SP.
d00845e4:	47a00000 4f734001 00000000 00000000     ...G.@sO........
d00845f4:	47b00000 00000000 201caa00 0050aa00     ...G....... ..P.
d0084604:	47c00000 a2040000 00000000 00000000     ...G............
d0084614:	47b00000 a2040000 0010aa00 00505301     ...G.........SP.
d0084624:	47a00000 0f835301 00000000 00000000     ...G.S..........
d0084634:	47900000 0f030000 0030a602 00505301     ...G......0..SP.
d0084644:	47800000 a2040000 00000000 00000000     ...G............
d0084654:	47700000 a2040000 2e4c5301 0050aa00     ..pG.....SL...P.
d0084664:	47600000 ff934001 00000000 00000000     ..`G.@..........
d0084674:	47700000 00000000 00405301 0050be00     ..pG.....S@...P.
d0084684:	47800000 02060000 00000000 00000000     ...G............
d0084694:	47900000 02060000 043fa602 00500d01     ...G......?...P.
d00846a4:	37605301 3f63e200 00000000 00000000     .S`7..c?........
d00846b4:	37700000 3f030000 2a1caa00 00500d01     ..p7...?...*..P.
d00846c4:	37800000 a2040000 00000000 00000000     ...7............
d00846d4:	37900000 a2040000 00405301 00508700     ...7.....S@...P.
d00846e4:	37a00000 a2040000 00000000 00000000     ...7............
d00846f4:	37b00000 a2040000 201caa00 00500d01     ...7....... ..P.
d0084704:	37c00000 a2040000 00000000 00000000     ...7............
d0084714:	37b00000 a2040000 3a1caa00 00500d01     ...7.......:..P.
d0084724:	37a00000 ff731d01 00000000 00000000     ...7..s.........
d0084734:	37900000 00000000 0030a602 00508700     ...7......0...P.
d0084744:	37800000 ff835301 00000000 00000000     ...7.S..........
d0084754:	37700000 00000000 00405301 00500d01     ..p7.....S@...P.
d0084764:	37600000 200c0000 00000000 00000000     ..`7... ........
d0084774:	37700000 109c5301 201caa00 00509700     ..p7.S..... ..P.
d0084784:	37800000 ff93e200 00000000 00000000     ...7............
d0084794:	37900000 00000000 0030a602 00508700     ...7......0...P.
d00847a4:	37a00000 a2040000 00000000 00000000     ...7............
d00847b4:	37b00000 a2040000 2a1caa00 00500d01     ...7.......*..P.
d00847c4:	37c00000 ffa31d01 00000000 00000000     ...7............
d00847d4:	37b00000 00000000 00405301 00500d01     ...7.....S@...P.
d00847e4:	37a00000 ffb35301 00000000 00000000     ...7.S..........
d00847f4:	37900000 00000000 201caa00 00508700     ...7....... ..P.
d0084804:	37800000 200c0000 00000000 00000000     ...7... ........
d0084814:	37700000 00000000 0010aa00 00500d01     ..p7..........P.
d0084824:	37600000 ffc3d600 00000000 00000000     ..`7............
d0084834:	37700000 ff030000 0030a602 00500d01     ..p7......0...P.
d0084844:	37800000 04060000 00000000 00000000     ...7............
d0084854:	37900000 04060000 00405301 00508700     ...7.....S@...P.
d0084864:	37a00000 25bce200 00000000 00000000     ...7...%........
d0084874:	37b00000 2a0c0000 2a1caa00 00509700     ...7...*...*..P.
d0084884:	37c00000 350c0000 00000000 00000000     ...7...5........
d0084894:	37b00000 400c0000 0030a602 00505301     ...7...@..0..SP.
d00848a4:	47a0ac01 ffa3ac01 00000000 00000000     ...G............
d00848b4:	47900000 00000000 201caa00 00505301     ...G....... .SP.
d00848c4:	47800000 a2040000 00000000 00000000     ...G............
d00848d4:	47700000 a2040000 00405301 0050aa00     ..pG.....S@...P.
d00848e4:	47600000 a2040000 00000000 00000000     ..`G............
d00848f4:	47700000 a2040000 201caa00 00505301     ..pG....... .SP.
d0084904:	47800000 a2040000 00000000 00000000     ...G............
d0084914:	47900000 a2040000 0010aa00 00505301     ...G.........SP.
d0084924:	47a00000 a2040000 00000000 00000000     ...G............
d0084934:	47b00000 a2040000 0030a602 0050aa00     ...G......0...P.
d0084944:	47c00000 a2040000 00000000 00000000     ...G............
d0084954:	47b00000 a2040000 00405301 00505301     ...G.....S@..SP.
d0084964:	47a00000 a2040000 00000000 00000000     ...G............
d0084974:	47900000 a2040000 2a1caa00 0050be00     ...G.......*..P.
d0084984:	47800000 a2040000 00000000 00000000     ...G............
d0084994:	47700000 a2040000 0030a602 0050aa00     ..pG......0...P.
d00849a4:	47600000 01060000 00000000 00000000     ..`G............
d00849b4:	47700000 01060000 201caa00 00505301     ..pG....... .SP.
d00849c4:	47800000 01060000 00000000 00000000     ...G............
d00849d4:	47900000 01060000 00405301 00505301     ...G.....S@..SP.
d00849e4:	47a00000 01060000 00000000 00000000     ...G............
d00849f4:	47b00000 01060000 201caa00 0050aa00     ...G....... ..P.
d0084a04:	47c00000 01060000 00000000 00000000     ...G............
d0084a14:	47b00000 01060000 0010aa00 00505301     ...G.........SP.
d0084a24:	47a00000 01060000 00000000 00000000     ...G............
d0084a34:	47900000 01060000 00405301 00505301     ...G.....S@..SP.
d0084a44:	47800000 01060000 00000000 00000000     ...G............
d0084a54:	47700000 01060000 2a4c5301 0050aa00     ..pG.....SL*..P.
d0084a64:	47600000 01060000 1a4c5301 00000000     ..`G.....SL.....
d0084a74:	47700000 01060000 3a4c5301 0050be00     ..pG.....SL:..P.
d0084a84:	47800000 01060000 00000000 00000000     ...G............
d0084a94:	47900000 01060000 00000000 00505301     ...G.........SP.
d0084aa4:	4760ac01 306c1d01 30dc1d01 00000000     ..`G..l0...0....
d0084ab4:	47700000 400c0000 400c0000 00505301     ..pG...@...@.SP.
d0084ac4:	47800000 a2040000 a2040000 00000000     ...G............
d0084ad4:	47900000 a2040000 a2040000 0050aa00     ...G..........P.
d0084ae4:	47a00000 a2040000 a2040000 00000000     ...G............
d0084af4:	47b00000 a2040000 a2040000 00505301     ...G.........SP.
d0084b04:	47c00000 a2040000 a2040000 00000000     ...G............
d0084b14:	47b00000 a2040000 a2040000 00505301     ...G.........SP.
d0084b24:	47a00000 ff734001 ffe34001 00000000     ...G.@s..@......
d0084b34:	47900000 00000000 00000000 0050aa00     ...G..........P.
d0084b44:	47800000 ff835301 fff35301 00000000     ...G.S...S......
d0084b54:	47700000 00000000 00000000 00505301     ..pG.........SP.
d0084b64:	47600000 200c0000 200c0000 00000000     ..`G... ... ....
d0084b74:	47700000 108c5301 10fc5301 0050be00     ..pG.S...S....P.
d0084b84:	47800000 ff934001 ff034011 00000000     ...G.@...@......
d0084b94:	47900000 00000000 00000000 0050aa00     ...G..........P.
d0084ba4:	47a00000 a2040000 a2040000 00000000     ...G............
d0084bb4:	47b00000 a2040000 a2040000 00505301     ...G.........SP.
d0084bc4:	47c00000 ffa34001 ff134011 00000000     ...G.@...@......
d0084bd4:	47b00000 00000000 00000000 00505301     ...G.........SP.
d0084be4:	47a00000 ffb35301 ff235311 00000000     ...G.S...S#.....
d0084bf4:	47900000 00000000 00000000 0050aa00     ...G..........P.
d0084c04:	47800000 200c0000 200c0000 00000000     ...G... ... ....
d0084c14:	47700000 00000000 00000000 00505301     ..pG.........SP.
d0084c24:	47600000 ffc3ac01 ff33ac11 00000000     ..`G......3.....
d0084c34:	47700000 ff030000 ff030000 00505301     ..pG.........SP.
d0084c44:	47800000 04060000 04060000 00000000     ...G............
d0084c54:	47900000 04060000 04060000 0050aa00     ...G..........P.
d0084c64:	47a00000 25bc3a02 252c3a12 00000000     ...G.:.%.:,%....
d0084c74:	47b00000 2a0c0000 2a0c0000 0050be00     ...G...*...*..P.
d0084c84:	47c00000 350c0000 350c0000 00000000     ...G...5...5....
d0084c94:	47b00000 400c0000 400c0000 00505301     ...G...@...@.SP.
d0084ca4:	59a00000 ffa31d01 ff131d11 00000000     ...Y............
d0084cb4:	59900000 00000000 00000000 00505301     ...Y.........SP.
d0084cc4:	59800000 a2040000 a2040000 00000000     ...Y............
d0084cd4:	59700000 a2040000 a2040000 0050aa00     ..pY..........P.
d0084ce4:	59600000 a2040000 a2040000 00000000     ..`Y............
d0084cf4:	59700000 a2040000 a2040000 00505301     ..pY.........SP.
d0084d04:	59800000 02060000 02060000 00000000     ...Y............
d0084d14:	59900000 02060000 02060000 00505301     ...Y.........SP.
d0084d24:	59a00000 3f934001 3f034011 00000000     ...Y.@.?.@.?....
d0084d34:	59b00000 00000000 00000000 0050aa00     ...Y..........P.
d0084d44:	59c00000 8f835301 8ff35301 00000000     ...Y.S...S......
d0084d54:	59b00000 00000000 00000000 00505301     ...Y.........SP.
d0084d64:	59a00000 200c0000 200c0000 00000000     ...Y... ... ....
d0084d74:	59900000 00000000 00000000 0050be00     ...Y..........P.
d0084d84:	59800000 ff734001 00e04001 00000000     ...Y.@s..@......
d0084d94:	59700000 00000000 00000000 0050aa00     ..pY..........P.
d0084da4:	59600000 a2040000 a2040000 00000000     ..`Y............
d0084db4:	59700000 a2040000 a2040000 00505301     ..pY.........SP.
d0084dc4:	59800000 ff634001 ffd34001 00000000     ...Y.@c..@......
d0084dd4:	59900000 00000000 00000000 00505301     ...Y.........SP.
d0084de4:	59a00000 4f735301 4fe35301 00000000     ...Y.SsO.S.O....
d0084df4:	59b00000 00000000 00000000 0050aa00     ...Y..........P.
d0084e04:	59c00000 a2040000 a2040000 00000000     ...Y............
d0084e14:	59b00000 a2040000 a2040000 00505301     ...Y.........SP.
d0084e24:	59a00000 0f83fe00 0ff3fe00 00000000     ...Y............
d0084e34:	59900000 0f030000 0f030000 00505301     ...Y.........SP.
d0084e44:	59800000 a2040000 a2040000 00000000     ...Y............
d0084e54:	59700000 a2040000 a2040000 0050aa00     ..pY..........P.
d0084e64:	59600000 ff731d01 ffe31d01 00000000     ..`Y..s.........
d0084e74:	59700000 00000000 00000000 0050be00     ..pY..........P.
d0084e84:	59800000 02060000 02060000 00000000     ...Y............
d0084e94:	59900000 02060000 00000000 00500d01     ...Y..........P.
d0084ea4:	4760ac01 3f63e200 3fd3e200 00000000     ..`G..c?...?....
d0084eb4:	47700000 3f030000 3f030000 00500d01     ..pG...?...?..P.
d0084ec4:	47800000 a2040000 a2040000 00000000     ...G............
d0084ed4:	47900000 a2040000 a2040000 00508700     ...G..........P.
d0084ee4:	47a00000 a2040000 a2040000 00000000     ...G............
d0084ef4:	47b00000 a2040000 a2040000 00500d01     ...G..........P.
d0084f04:	47c00000 a2040000 a2040000 00000000     ...G............
d0084f14:	47b00000 a2040000 a2040000 00500d01     ...G..........P.
d0084f24:	47a00000 ff731d01 ffe31d01 00000000     ...G..s.........
d0084f34:	47900000 00000000 00000000 00508700     ...G..........P.
d0084f44:	47800000 ff835301 fff35301 00000000     ...G.S...S......
d0084f54:	47700000 00000000 00000000 00500d01     ..pG..........P.
d0084f64:	47600000 200c0000 200c0000 00000000     ..`G... ... ....
d0084f74:	47700000 109c5301 100c5311 00509700     ..pG.S...S....P.
d0084f84:	47800000 ff93e200 ff03e210 00000000     ...G............
d0084f94:	47900000 00000000 00000000 00508700     ...G..........P.
d0084fa4:	47a00000 a2040000 a2040000 00000000     ...G............
d0084fb4:	47b00000 a2040000 a2040000 00500d01     ...G..........P.
d0084fc4:	47c00000 ffa31d01 ff131d11 00000000     ...G............
d0084fd4:	47b00000 00000000 00000000 00500d01     ...G..........P.
d0084fe4:	47a00000 ffb35301 ff235311 00000000     ...G.S...S#.....
d0084ff4:	47900000 00000000 00000000 00508700     ...G..........P.
d0085004:	47800000 200c0000 200c0000 00000000     ...G... ... ....
d0085014:	47700000 00000000 00000000 00500d01     ..pG..........P.
d0085024:	47600000 ffc3d600 ff33d610 00000000     ..`G......3.....
d0085034:	47700000 ff030000 ff030000 00500d01     ..pG..........P.
d0085044:	47800000 04060000 04060000 00000000     ...G............
d0085054:	47900000 04060000 04060000 00508700     ...G..........P.
d0085064:	47a00000 25bce200 252ce210 00000000     ...G...%..,%....
d0085074:	47b00000 2a0c0000 2a0c0000 00509700     ...G...*...*..P.
d0085084:	47c00000 350c0000 350c0000 00000000     ...G...5...5....
d0085094:	47b00000 400c0000 400c0000 0050fe00     ...G...@...@..P.
d00850a4:	47a04001 ffa3d600 ff13d610 00000000     .@.G............
d00850b4:	47900000 00000000 00000000 0050fe00     ...G..........P.
d00850c4:	47800000 a2040000 a2040000 00000000     ...G............
d00850d4:	47700000 a2040000 a2040000 00507f00     ..pG..........P.
d00850e4:	47600000 a2040000 a2040000 00000000     ..`G............
d00850f4:	47700000 a2040000 a2040000 0050fe00     ..pG..........P.
d0085104:	47800000 02060000 02060000 00000000     ...G............
d0085114:	47900000 02060000 02060000 0050fe00     ...G..........P.
d0085124:	47a00000 3f93e200 3f03e210 00000000     ...G...?...?....
d0085134:	47b00000 00000000 00000000 00507f00     ...G..........P.
d0085144:	47c00000 8f831d01 8ff31d01 00000000     ...G............
d0085154:	47b00000 00000000 00000000 0050fe00     ...G..........P.
d0085164:	47a00000 200c0000 200c0000 00000000     ...G... ... ....
d0085174:	47900000 00000000 00000000 00508f00     ...G..........P.
d0085184:	47800000 0070d600 00e0d600 00000000     ...G..p.........
d0085194:	47700000 00000000 00000000 0050aa00     ..pG..........P.
d00851a4:	4760ac01 a2040000 a2040000 00000000     ..`G............
d00851b4:	47700000 a2040000 a2040000 00505301     ..pG.........SP.
d00851c4:	47800000 ff631d01 ffd31d01 00000000     ...G..c.........
d00851d4:	47900000 00000000 00000000 00505301     ...G.........SP.
d00851e4:	47a00000 4f734001 4fe34001 00000000     ...G.@sO.@.O....
d00851f4:	47b00000 00000000 00000000 0050aa00     ...G..........P.
d0085204:	47c00000 a2040000 a2040000 00000000     ...G............
d0085214:	47b00000 a2040000 a2040000 00505301     ...G.........SP.
d0085224:	47a00000 0f835301 0ff35301 00000000     ...G.S...S......
d0085234:	47900000 0f030000 0f030000 00505301     ...G.........SP.
d0085244:	47800000 a2040000 a2040000 00000000     ...G............
d0085254:	47700000 a2040000 a2040000 0050aa00     ..pG..........P.
d0085264:	47600000 ff934001 ff134011 00000000     ..`G.@...@......
d0085274:	47700000 00000000 00000000 0050be00     ..pG..........P.
d0085284:	47800000 02060000 02060000 00000000     ...G............
d0085294:	47900000 02060000 00000000 00500d01     ...G..........P.
d00852a4:	37605301 3f63e200 3fd3e200 00000000     .S`7..c?...?....
d00852b4:	37700000 3f030000 3f030000 00500d01     ..p7...?...?..P.
d00852c4:	37800000 a2040000 a2040000 00000000     ...7............
d00852d4:	37900000 a2040000 a2040000 00508700     ...7..........P.
d00852e4:	37a00000 a2040000 a2040000 00000000     ...7............
d00852f4:	37b00000 a2040000 a2040000 00500d01     ...7..........P.
d0085304:	37c00000 a2040000 a2040000 00000000     ...7............
d0085314:	37b00000 a2040000 a2040000 00500d01     ...7..........P.
d0085324:	37a00000 ff731d01 ffe31d01 00000000     ...7..s.........
d0085334:	37900000 00000000 00000000 00508700     ...7..........P.
d0085344:	37800000 ff835301 fff35301 00000000     ...7.S...S......
d0085354:	37700000 00000000 00000000 00500d01     ..p7..........P.
d0085364:	37600000 200c0000 200c0000 00000000     ..`7... ... ....
d0085374:	37700000 109c5301 100c5311 00509700     ..p7.S...S....P.
d0085384:	37800000 ff93e200 ff03e210 00000000     ...7............
d0085394:	37900000 00000000 00000000 00508700     ...7..........P.
d00853a4:	37a00000 a2040000 a2040000 00000000     ...7............
d00853b4:	37b00000 a2040000 a2040000 00500d01     ...7..........P.
d00853c4:	37c00000 ffa31d01 ff131d11 00000000     ...7............
d00853d4:	37b00000 00000000 00000000 00500d01     ...7..........P.
d00853e4:	37a00000 ffb35301 ff235311 00000000     ...7.S...S#.....
d00853f4:	37900000 00000000 00000000 00508700     ...7..........P.
d0085404:	37800000 200c0000 200c0000 00000000     ...7... ... ....
d0085414:	37700000 00000000 00000000 00500d01     ..p7..........P.
d0085424:	37600000 ffc3d600 ff33d610 00000000     ..`7......3.....
d0085434:	37700000 ff030000 ff030000 00500d01     ..p7..........P.
d0085444:	37800000 04060000 04060000 00000000     ...7............
d0085454:	37900000 04060000 04060000 00508700     ...7..........P.
d0085464:	37a00000 25bce200 252ce210 00000000     ...7...%..,%....
d0085474:	37b00000 2a0c0000 2a0c0000 00509700     ...7...*...*..P.
d0085484:	37c00000 350c0000 350c0000 00000000     ...7...5...5....
d0085494:	37b00000 400c0000 400c0000 00505301     ...7...@...@.SP.
d00854a4:	47a0ac01 ffa3ac01 ff13ac11 00000000     ...G............
d00854b4:	47900000 00000000 00000000 00505301     ...G.........SP.
d00854c4:	47800000 a2040000 a2040000 00000000     ...G............
d00854d4:	47700000 a2040000 a2040000 0050aa00     ..pG..........P.
d00854e4:	47600000 a2040000 a2040000 00000000     ..`G............
d00854f4:	47700000 a2040000 a2040000 00505301     ..pG.........SP.
d0085504:	47800000 a2040000 a2040000 00000000     ...G............
d0085514:	47900000 a2040000 a2040000 00505301     ...G.........SP.
d0085524:	47a00000 a2040000 a2040000 00000000     ...G............
d0085534:	47b00000 a2040000 a2040000 0050aa00     ...G..........P.
d0085544:	47c00000 a2040000 a2040000 00000000     ...G............
d0085554:	47b00000 a2040000 a2040000 00505301     ...G.........SP.
d0085564:	47a00000 a2040000 a2040000 00000000     ...G............
d0085574:	47900000 a2040000 a2040000 0050be00     ...G..........P.
d0085584:	47800000 a2040000 a2040000 00000000     ...G............
d0085594:	47700000 a2040000 a2040000 0050aa00     ..pG..........P.
d00855a4:	47600000 01060000 01060000 00000000     ..`G............
d00855b4:	47700000 01060000 01060000 00505301     ..pG.........SP.
d00855c4:	47800000 01060000 01060000 00000000     ...G............
d00855d4:	47900000 01060000 01060000 00505301     ...G.........SP.
d00855e4:	47a00000 01060000 01060000 00000000     ...G............
d00855f4:	47b00000 01060000 01060000 0050aa00     ...G..........P.
d0085604:	47c00000 01060000 01060000 00000000     ...G............
d0085614:	47b00000 01060000 01060000 00505301     ...G.........SP.
d0085624:	47a00000 01060000 01060000 00000000     ...G............
d0085634:	47900000 01060000 3a3ca602 00505301     ...G......<:.SP.
d0085644:	47800000 01060000 00000000 00000000     ...G............
d0085654:	47700000 01060000 2a4c5301 0050aa00     ..pG.....SL*..P.
d0085664:	47600000 01060000 1a4c5301 00000000     ..`G.....SL.....
d0085674:	47700000 01060000 3a4c5301 0050be00     ..pG.....SL:..P.
d0085684:	47800000 01060000 00000000 00000000     ...G............
d0085694:	47900000 01060000 043fa602 00505301     ...G......?..SP.
d00856a4:	4760ac01 00601d01 00000000 00000000     ..`G..`.........
d00856b4:	47700000 108c5301 2a1caa00 00505301     ..pG.S.....*.SP.
d00856c4:	47800000 00704001 00000000 00000000     ...G.@p.........
d00856d4:	47900000 106c1d01 00405301 0050aa00     ...G..l..S@...P.
d00856e4:	47a00000 00805301 00000000 00000000     ...G.S..........
d00856f4:	47b00000 107c4001 201caa00 00505301     ...G.@|.... .SP.
d0085704:	47c00000 00901d01 00000000 00000000     ...G............
d0085714:	47b00000 108c5301 3a1caa00 00505301     ...G.S.....:.SP.
d0085724:	47a00000 00a04001 00000000 00000000     ...G.@..........
d0085734:	47900000 109c1d01 0030a602 0050aa00     ...G......0...P.
d0085744:	47800000 00b05301 00000000 00000000     ...G.S..........
d0085754:	47700000 10ac4001 00405301 00505301     ..pG.@...S@..SP.
d0085764:	47600000 00c01d01 00000000 00000000     ..`G............
d0085774:	47700000 10bc5301 201caa00 0050be00     ..pG.S..... ..P.
d0085784:	47800000 00b04001 00000000 00000000     ...G.@..........
d0085794:	47900000 10cc1d01 0030a602 0050aa00     ...G......0...P.
d00857a4:	47a00000 00a01d01 00000000 00000000     ...G............
d00857b4:	47b00000 10bc4001 2a1caa00 00505301     ...G.@.....*.SP.
d00857c4:	47c00000 00905301 00000000 00000000     ...G.S..........
d00857d4:	47b00000 10ac1d01 00405301 00505301     ...G.....S@..SP.
d00857e4:	47a00000 0080ac01 00000000 00000000     ...G............
d00857f4:	47900000 109c5301 201caa00 0050aa00     ...G.S..... ..P.
d0085804:	47800000 00701d01 00000000 00000000     ...G..p.........
d0085814:	47700000 108cac01 0010aa00 00505301     ..pG.........SP.
d0085824:	47600000 00605301 00000000 00000000     ..`G.S`.........
d0085834:	47700000 107c1d01 0030a602 00505301     ..pG..|...0..SP.
d0085844:	47800000 0070ac01 00000000 00000000     ...G..p.........
d0085854:	47900000 106c5301 00405301 0050aa00     ...G.Sl..S@...P.
d0085864:	47a00000 00801d01 00000000 00000000     ...G............
d0085874:	47b00000 107cac01 2a1caa00 0050be00     ...G..|....*..P.
d0085884:	47c00000 00905301 00000000 00000000     ...G.S..........
d0085894:	47b00000 108c1d01 0030a602 00505301     ...G......0..SP.
d00858a4:	59a00000 00a0fe00 00000000 00000000     ...Y............
d00858b4:	59900000 109c5301 201caa00 00505301     ...Y.S..... .SP.
d00858c4:	59800000 00b04001 00000000 00000000     ...Y.@..........
d00858d4:	59700000 10acfe00 00405301 0050aa00     ..pY.....S@...P.
d00858e4:	59600000 00c0ac01 00000000 00000000     ..`Y............
d00858f4:	59700000 10bc4001 201caa00 00505301     ..pY.@..... .SP.
d0085904:	59800000 00b0fe00 00000000 00000000     ...Y............
d0085914:	59900000 10ccac01 0010aa00 00505301     ...Y.........SP.
d0085924:	59a00000 00a04001 00000000 00000000     ...Y.@..........
d0085934:	59b00000 10bcfe00 0030a602 0050aa00     ...Y......0...P.
d0085944:	59c00000 0090ac01 00000000 00000000     ...Y............
d0085954:	59b00000 10ac4001 00405301 00505301     ...Y.@...S@..SP.
d0085964:	59a00000 0080fe00 00000000 00000000     ...Y............
d0085974:	59900000 109cac01 2a1caa00 0050be00     ...Y.......*..P.
d0085984:	59800000 00704001 00000000 00000000     ...Y.@p.........
d0085994:	59700000 108cfe00 0030a602 0050aa00     ..pY......0...P.
d00859a4:	59600000 00601d01 00000000 00000000     ..`Y..`.........
d00859b4:	59700000 107c4001 201caa00 00505301     ..pY.@|.... .SP.
d00859c4:	59800000 00705301 00000000 00000000     ...Y.Sp.........
d00859d4:	59900000 108c1d01 00405301 00505301     ...Y.....S@..SP.
d00859e4:	59a00000 0080ac01 00000000 00000000     ...Y............
d00859f4:	59b00000 109c5301 201caa00 0050aa00     ...Y.S..... ..P.
d0085a04:	59c00000 00901d01 00000000 00000000     ...Y............
d0085a14:	59b00000 10acac01 0010aa00 00505301     ...Y.........SP.
d0085a24:	59a00000 00a04001 00000000 00000000     ...Y.@..........
d0085a34:	59900000 109c1d01 0030a602 00505301     ...Y......0..SP.
d0085a44:	59800000 00905301 00000000 00000000     ...Y.S..........
d0085a54:	59700000 108c4001 2e4c5301 0050aa00     ..pY.@...SL...P.
d0085a64:	59600000 00807d01 00000000 00000000     ..`Y.}..........
d0085a74:	59700000 107c5301 00405301 0050be00     ..pY.S|..S@...P.
d0085a84:	59800000 00705301 00000000 00000000     ...Y.Sp.........
d0085a94:	59900000 107c7d01 043fa602 00500d01     ...Y.}|...?...P.
d0085aa4:	37605301 0060e200 00000000 00000000     .S`7..`.........
d0085ab4:	37700000 108c5301 2a1caa00 00500d01     ..p7.S.....*..P.
d0085ac4:	37800000 00701d01 00000000 00000000     ...7..p.........
d0085ad4:	37900000 106ce200 00405301 00508700     ...7..l..S@...P.
d0085ae4:	37a00000 00805301 00000000 00000000     ...7.S..........
d0085af4:	37b00000 107c1d01 201caa00 00500d01     ...7..|.... ..P.
d0085b04:	37c00000 00901d01 00000000 00000000     ...7............
d0085b14:	37b00000 108c5301 3a1caa00 00500d01     ...7.S.....:..P.
d0085b24:	37a00000 00a0e200 00000000 00000000     ...7............
d0085b34:	37900000 109c1d01 0030a602 00508700     ...7......0...P.
d0085b44:	37800000 00b01d01 00000000 00000000     ...7............
d0085b54:	37700000 10ace200 00405301 00500d01     ..p7.....S@...P.
d0085b64:	37600000 00c0d600 00000000 00000000     ..`7............
d0085b74:	37700000 10bc1d01 201caa00 00509700     ..p7....... ..P.
d0085b84:	37800000 00b01d01 00000000 00000000     ...7............
d0085b94:	37900000 10ccd600 0030a602 00508700     ...7......0...P.
d0085ba4:	37a00000 00a0e200 00000000 00000000     ...7............
d0085bb4:	37b00000 10bc1d01 2a1caa00 00500d01     ...7.......*..P.
d0085bc4:	37c00000 00901d01 00000000 00000000     ...7............
d0085bd4:	37b00000 10ace200 00405301 00500d01     ...7.....S@...P.
d0085be4:	37a00000 00805301 00000000 00000000     ...7.S..........
d0085bf4:	37900000 109c1d01 201caa00 00508700     ...7....... ..P.
d0085c04:	37800000 0070e200 00000000 00000000     ...7..p.........
d0085c14:	37700000 108c5301 0010aa00 00500d01     ..p7.S........P.
d0085c24:	37600000 00601d01 00000000 00000000     ..`7..`.........
d0085c34:	37700000 107ce200 0030a602 00500d01     ..p7..|...0...P.
d0085c44:	37800000 00705301 00000000 00000000     ...7.Sp.........
d0085c54:	37900000 106c1d01 00405301 00508700     ...7..l..S@...P.
d0085c64:	37a00000 0080e200 00000000 00000000     ...7............
d0085c74:	37b00000 107c5301 2a1caa00 00509700     ...7.S|....*..P.
d0085c84:	37c00000 00905301 00000000 00000000     ...7.S..........
d0085c94:	37b00000 108ce200 0030a602 00505301     ...7......0..SP.
d0085ca4:	47a0ac01 00a01d01 00000000 00000000     ...G............
d0085cb4:	47900000 109c5301 201caa00 00505301     ...G.S..... .SP.
d0085cc4:	47800000 00b05301 00000000 00000000     ...G.S..........
d0085cd4:	47700000 10ac1d01 00405301 0050aa00     ..pG.....S@...P.
d0085ce4:	47600000 00c0ac01 00000000 00000000     ..`G............
d0085cf4:	47700000 10bc5301 201caa00 00505301     ..pG.S..... .SP.
d0085d04:	47800000 00b01d01 00000000 00000000     ...G............
d0085d14:	47900000 10ccac01 0010aa00 00505301     ...G.........SP.
d0085d24:	47a00000 00a05301 00000000 00000000     ...G.S..........
d0085d34:	47b00000 10bc1d01 0030a602 0050aa00     ...G......0...P.
d0085d44:	47c00000 0090ac01 00000000 00000000     ...G............
d0085d54:	47b00000 10ac5301 00405301 00505301     ...G.S...S@..SP.
d0085d64:	47a00000 00801d01 00000000 00000000     ...G............
d0085d74:	47900000 109cac01 2a1caa00 0050be00     ...G.......*..P.
d0085d84:	47800000 00705301 00000000 00000000     ...G.Sp.........
d0085d94:	47700000 108c1d01 0030a602 0050aa00     ..pG......0...P.
d0085da4:	47600000 00601d01 00000000 00000000     ..`G..`.........
d0085db4:	47700000 107c5301 201caa00 00505301     ..pG.S|.... .SP.
d0085dc4:	47800000 00705301 00000000 00000000     ...G.Sp.........
d0085dd4:	47900000 106c1d01 00405301 00505301     ...G..l..S@..SP.
d0085de4:	47a00000 0080ac01 00000000 00000000     ...G............
d0085df4:	47b00000 107c5301 201caa00 0050aa00     ...G.S|.... ..P.
d0085e04:	47c00000 00905301 00000000 00000000     ...G.S..........
d0085e14:	47b00000 108cac01 0010aa00 00505301     ...G.........SP.
d0085e24:	47a00000 00a01d01 00000000 00000000     ...G............
d0085e34:	47900000 109c5301 0030a602 00505301     ...G.S....0..SP.
d0085e44:	47800000 00b04001 00000000 00000000     ...G.@..........
d0085e54:	47700000 10ac1d01 2e4c5301 0050aa00     ..pG.....SL...P.
d0085e64:	47600000 00c05301 00000000 00000000     ..`G.S..........
d0085e74:	47700000 10bc4001 00405301 0050be00     ..pG.@...S@...P.
d0085e84:	47800000 00b04001 00000000 00000000     ...G.@..........
d0085e94:	47900000 10cc5301 043fa602 00500d01     ...G.S....?...P.
d0085ea4:	4760ac01 0060e200 00000000 00000000     ..`G..`.........
d0085eb4:	47700000 107c5301 2a1caa00 00500d01     ..pG.S|....*..P.
d0085ec4:	47800000 00701d01 00000000 00000000     ...G..p.........
d0085ed4:	47900000 106ce200 00405301 00508700     ...G..l..S@...P.
d0085ee4:	47a00000 00805301 00000000 00000000     ...G.S..........
d0085ef4:	47b00000 107c1d01 201caa00 00500d01     ...G..|.... ..P.
d0085f04:	47c00000 0090e200 00000000 00000000     ...G............
d0085f14:	47b00000 108c5301 3a1caa00 00500d01     ...G.S.....:..P.
d0085f24:	47a00000 00a01d01 00000000 00000000     ...G............
d0085f34:	47900000 109ce200 0030a602 00508700     ...G......0...P.
d0085f44:	47800000 00b05301 00000000 00000000     ...G.S..........
d0085f54:	47700000 10ac1d01 00405301 00500d01     ..pG.....S@...P.
d0085f64:	47600000 00c0e200 00000000 00000000     ..`G............
d0085f74:	47700000 10bc5301 201caa00 00509700     ..pG.S..... ..P.
d0085f84:	47800000 00b01d01 00000000 00000000     ...G............
d0085f94:	47900000 10cce200 0030a602 00508700     ...G......0...P.
d0085fa4:	47a00000 00a0e200 00000000 00000000     ...G............
d0085fb4:	47b00000 10bc1d01 2a1caa00 00500d01     ...G.......*..P.
d0085fc4:	47c00000 00901d01 00000000 00000000     ...G............
d0085fd4:	47b00000 10ace200 00405301 00500d01     ...G.....S@...P.
d0085fe4:	47a00000 00805301 00000000 00000000     ...G.S..........
d0085ff4:	47900000 109c1d01 201caa00 00508700     ...G....... ..P.
d0086004:	47800000 0070e200 00000000 00000000     ...G..p.........
d0086014:	47700000 108c5301 0010aa00 00500d01     ..pG.S........P.
d0086024:	47600000 00601d01 00000000 00000000     ..`G..`.........
d0086034:	47700000 107ce200 0030a602 00500d01     ..pG..|...0...P.
d0086044:	47800000 00705301 00000000 00000000     ...G.Sp.........
d0086054:	47900000 106c1d01 00405301 00508700     ...G..l..S@...P.
d0086064:	47a00000 0080e200 00000000 00000000     ...G............
d0086074:	47b00000 107c5301 2a1caa00 00509700     ...G.S|....*..P.
d0086084:	47c00000 00901d01 00000000 00000000     ...G............
d0086094:	47b00000 108ce200 0030a602 0050fe00     ...G......0...P.
d00860a4:	47a04001 00a0d600 00000000 00000000     .@.G............
d00860b4:	47900000 109c1d01 201caa00 0050fe00     ...G....... ..P.
d00860c4:	47800000 00b0fe00 00000000 00000000     ...G............
d00860d4:	47700000 10acd600 00405301 00507f00     ..pG.....S@...P.
d00860e4:	47600000 00c04001 00000000 00000000     ..`G.@..........
d00860f4:	47700000 10bcfe00 201caa00 0050fe00     ..pG....... ..P.
d0086104:	47800000 00b0d600 00000000 00000000     ...G............
d0086114:	47900000 10cc4001 0010aa00 0050fe00     ...G.@........P.
d0086124:	47a00000 00a0fe00 00000000 00000000     ...G............
d0086134:	47b00000 10bcd600 0030a602 00507f00     ...G......0...P.
d0086144:	47c00000 00904001 00000000 00000000     ...G.@..........
d0086154:	47b00000 10acfe00 00405301 0050fe00     ...G.....S@...P.
d0086164:	47a00000 0080d600 00000000 00000000     ...G............
d0086174:	47900000 109c4001 2a1caa00 00508f00     ...G.@.....*..P.
d0086184:	47800000 0070fe00 00000000 00000000     ...G..p.........
d0086194:	47700000 108cd600 0030a602 0050aa00     ..pG......0...P.
d00861a4:	4760ac01 00601d01 00000000 00000000     ..`G..`.........
d00861b4:	47700000 107cfe00 201caa00 00505301     ..pG..|.... .SP.
d00861c4:	47800000 00705301 00000000 00000000     ...G.Sp.........
d00861d4:	47900000 106c1d01 00405301 00505301     ...G..l..S@..SP.
d00861e4:	47a00000 0080ac01 00000000 00000000     ...G............
d00861f4:	47b00000 107c5301 201caa00 0050aa00     ...G.S|.... ..P.
d0086204:	47c00000 00901d01 00000000 00000000     ...G............
d0086214:	47b00000 108cac01 0010aa00 00505301     ...G.........SP.
d0086224:	47a00000 00a05301 00000000 00000000     ...G.S..........
d0086234:	47900000 109c1d01 0030a602 00505301     ...G......0..SP.
d0086244:	47800000 0090ac01 00000000 00000000     ...G............
d0086254:	47700000 10ac5301 2e4c5301 0050aa00     ..pG.S...SL...P.
d0086264:	47600000 00801d01 00000000 00000000     ..`G............
d0086274:	47700000 109cac01 00405301 0050be00     ..pG.....S@...P.
d0086284:	47800000 00705301 00000000 00000000     ...G.Sp.........
d0086294:	47900000 108c1d01 043fa602 00500d01     ...G......?...P.
d00862a4:	37605301 0060e200 00000000 00000000     .S`7..`.........
d00862b4:	37700000 108c5301 2a1caa00 00500d01     ..p7.S.....*..P.
d00862c4:	37800000 00701d01 00000000 00000000     ...7..p.........
d00862d4:	37900000 106ce200 00405301 00508700     ...7..l..S@...P.
d00862e4:	37a00000 00805301 00000000 00000000     ...7.S..........
d00862f4:	37b00000 107c1d01 201caa00 00500d01     ...7..|.... ..P.
d0086304:	37c00000 0090e200 00000000 00000000     ...7............
d0086314:	37b00000 108c5301 3a1caa00 00500d01     ...7.S.....:..P.
d0086324:	37a00000 00a01d01 00000000 00000000     ...7............
d0086334:	37900000 109ce200 0030a602 00508700     ...7......0...P.
d0086344:	37800000 00b05301 00000000 00000000     ...7.S..........
d0086354:	37700000 10ac1d01 00405301 00500d01     ..p7.....S@...P.
d0086364:	37600000 00c0e200 00000000 00000000     ..`7............
d0086374:	37700000 10bc5301 201caa00 00509700     ..p7.S..... ..P.
d0086384:	37800000 00b01d01 00000000 00000000     ...7............
d0086394:	37900000 10cce200 0030a602 00508700     ...7......0...P.
d00863a4:	37a00000 00a0e200 00000000 00000000     ...7............
d00863b4:	37b00000 10bc1d01 2a1caa00 00500d01     ...7.......*..P.
d00863c4:	37c00000 00901d01 00000000 00000000     ...7............
d00863d4:	37b00000 10ace200 00405301 00500d01     ...7.....S@...P.
d00863e4:	37a00000 00805301 00000000 00000000     ...7.S..........
d00863f4:	37900000 109c1d01 201caa00 00508700     ...7....... ..P.
d0086404:	37800000 0070e200 00000000 00000000     ...7..p.........
d0086414:	37700000 108c5301 0010aa00 00500d01     ..p7.S........P.
d0086424:	37600000 00601d01 00000000 00000000     ..`7..`.........
d0086434:	37700000 107ce200 0030a602 00500d01     ..p7..|...0...P.
d0086444:	37800000 00705301 00000000 00000000     ...7.Sp.........
d0086454:	37900000 106c1d01 00405301 00508700     ...7..l..S@...P.
d0086464:	37a00000 0080e200 00000000 00000000     ...7............
d0086474:	37b00000 107c5301 2a1caa00 00509700     ...7.S|....*..P.
d0086484:	37c00000 00701d01 00000000 00000000     ...7..p.........
d0086494:	37b00000 108ce200 0030a602 00505301     ...7......0..SP.
d00864a4:	47a0ac01 00601d01 00000000 00000000     ...G..`.........
d00864b4:	47900000 107c1d01 201caa00 00505301     ...G..|.... .SP.
d00864c4:	47800000 00705301 00000000 00000000     ...G.Sp.........
d00864d4:	47700000 106c1d01 00405301 0050aa00     ..pG..l..S@...P.
d00864e4:	47600000 0080ac01 00000000 00000000     ..`G............
d00864f4:	47700000 107c5301 201caa00 00505301     ..pG.S|.... .SP.
d0086504:	47800000 00901d01 00000000 00000000     ...G............
d0086514:	47900000 108cac01 0010aa00 00505301     ...G.........SP.
d0086524:	47a00000 00a05301 00000000 00000000     ...G.S..........
d0086534:	47b00000 109c1d01 0030a602 0050aa00     ...G......0...P.
d0086544:	47c00000 00b0ac01 00000000 00000000     ...G............
d0086554:	47b00000 10ac5301 00405301 00505301     ...G.S...S@..SP.
d0086564:	47a00000 00c01d01 00000000 00000000     ...G............
d0086574:	47900000 10bcac01 2a1caa00 0050be00     ...G.......*..P.
d0086584:	47800000 00b05301 00000000 00000000     ...G.S..........
d0086594:	47700000 10cc1d01 0030a602 0050aa00     ..pG......0...P.
d00865a4:	47600000 00a0ac01 00000000 00000000     ..`G............
d00865b4:	47700000 10bc5301 201caa00 00505301     ..pG.S..... .SP.
d00865c4:	47800000 209cac01 00000000 00000000     ...G... ........
d00865d4:	47900000 0aac5301 00405301 00505301     ...G.S...S@..SP.
d00865e4:	47a00000 108cac01 00000000 00000000     ...G............
d00865f4:	47b00000 049c5301 201caa00 0050aa00     ...G.S..... ..P.
d0086604:	47c00000 057cac01 00000000 00000000     ...G..|.........
d0086614:	47b00000 038c5301 0010aa00 00505301     ...G.S.......SP.
d0086624:	47a00000 026cac01 00000000 00000000     ...G..l.........
d0086634:	47900000 017c5301 0030a602 00505301     ...G.S|...0..SP.
d0086644:	47800000 017cac01 00000000 00000000     ...G..|.........
d0086654:	47700000 016c5301 2a4c5301 0050aa00     ..pG.Sl..SL*..P.
d0086664:	47600000 3a8cac01 1a4c5301 00000000     ..`G...:.SL.....
d0086674:	47700000 2a0c0000 3a4c5301 0050be00     ..pG...*.SL:..P.
d0086684:	47800000 ff935301 00000000 030b0000     ...G.S..........
d0086694:	47900000 200c0000 00000000 01dd26bb     ...G... .....&..
d00866a4:	0000d010 fb0eeeeb e7dd00dd d900be10     ................
d00866b4:	2fbb0cef 02e621bb 0b00f800 f20000e7     .../.!..........
d00866c4:	00f8fb01 22f8f600 22cc22dd 0c0000dd     ......."."."....
d00866d4:	00eb1500 f81ddd11 ea0ae722 0021de21     ........"...!.!.
d00866e4:	f805f80b 19e70000 eee911ef 00ffef16     ................
d00866f4:	0cee06fc 00f222f8 00ed0008 11ee00fc     ....."..........
d0086704:	eb1000f8 de0ceb14 00eee714 f700f800     ................
d0086714:	19f815ea 0a002100 11fc2201 ee110003     .....!..."......
d0086724:	22e71b00 08f808ef 0ed41bcc d91000ef     ..."............
d0086734:	10e4fc10 fc11fce8 0bde19f9 e721ef02     ..............!.
d0086744:	07f200f8 15f6f800 f80010de 110bf82b     ............+...
d0086754:	cc2af6ee 0021df2a 21cd21d9 00cd2bde     ..*.*.!..!.!.+..
d0086764:	e020eee7 e407f203 0900dd10 090bf809     .. .............
d0086774:	17fc0208 de1900f3 0100ef21 0af800ef     ........!.......
d0086784:	0ddc19f8 0908ee03 dd11f8f4 ef21e611     ..............!.
d0086794:	21e30018 080000f1 f8ef00e7 0ce6fcfd     ...!............
d00867a4:	11e619dd 11de17f8 e31900e9 df2aca24     ............$.*.
d00867b4:	de10110e 11f80021 e60015ee 00e70000     ....!...........
d00867c4:	c011ecfd 08e70008 08f600f3 e30600e6     ................
d00867d4:	f8f80007 10ef0ef8 27f30200 f8010fde     ...........'....
d00867e4:	03ee0002 00080bed 22f30800 000500fc     ..........."....
d00867f4:	f300f8f8 f8010000 000cef17 0803ee11     ................
d0086804:	0000f800 000300f2 0000f600 05f2f800     ................
d0086814:	0000ef05 f400deee 08f70000 10ee0cee     ................
d0086824:	11feee03 f408f8ef de19e70a 04f20cfc     ................
d0086834:	08f308f8 e70cf8f2 f20af3fb ef17f707     ................
d0086844:	1401f814 15f81bf5 fcf411ea f8f80003     ................
d0086854:	00f400f8 00ee0000 f9f8eff8 f8f90cee     ................
d0086864:	f8000000 f6000003 08fc0008 00f600fd     ................
d0086874:	0000fef6 f8effef8 1008ee1d 000019f1     ................
d0086884:	0000010b ef05f811 fdfb000e f300fc00     ................
d0086894:	00effc01 f8f8eefb ea00f6f8 00f8ef12     ................
d00868a4:	0cf602f8 00ef0bec fbf510f1 0000f205     ................
d00868b4:	000bf205 f8000000 08000000 00f907f8     ................
d00868c4:	01fc04fa f30000fc 0000f607 ef00f6f8     ................
d00868d4:	f8fb0000 0003ef0a f900f200 fb00f600     ................
d00868e4:	eefe03f9 ef01f208 f406f602 00070007     ................
d00868f4:	00000bf6 0bf10800 00fc07f4 f50400fc     ................
d0086904:	0005fd00 03ee08f3 fef806f6 fd00f8fb     ................
d0086914:	f800f9f8 f50000f8 0000fd00 03fcfdf9     ................
d0086924:	fc0000fb f704fc00 f9ffff02 fffc0000     ................
d0086934:	fb07f900 fefe00fc 0000fe00 07f80300     ................
d0086944:	000000fe 0001f800 f60cf600 08ee01fc     ................
d0086954:	00fc08f8 06f200fc f401fbf3 f8fdfc00     ................
d0086964:	f803f802 03f8fd00 00fdf8fd fbff03f2     ................
d0086974:	fbfcff02 00f8ff00 0000f801 000000fb     ................
d0086984:	00f805fc 0007f40f 0300ff01 0006fb00     ................
d0086994:	fdf800fa f8fcf800 00fbf802 00fcef00     ................
d00869a4:	fbfb00f7 fefbfdfe fcfe00fa 0100f803     ................
d00869b4:	0005fd00 00fb04fe 00fb01fd 0006f604     ................
d00869c4:	fb05f805 00000000 00000000 00fdfe01     ................
d00869d4:	fdfe00fb fd00f800 fcfcfffa fef800fd     ................
d00869e4:	fc00fefe fb00f403 f903fdfe 00f800fe     ................
d00869f4:	00fe00fa 02fb0000 fb0100fc 00fe05ff     ................
d0086a04:	fe00fc02 fd00fd00 fdfefd00 fdfc00fd     ................
d0086a14:	fefdfdfd fd00fdfd 00f900fe f90000fe     ................
d0086a24:	fb00fb00 fdfbfe00 fefa00fc ff00fdfe     ................
d0086a34:	fc00fefc 00fc00fe fe00ff00 00000000     ................
d0086a44:	fd00feff fc0000ff fdfcfe00 ff00f900     ................
d0086a54:	fe0000fd fffc00fa fcfffefe fa00fc00     ................
d0086a64:	f800fb02 fb00f800 fdfdfffe fefd00fc     ................
d0086a74:	00fefdff fefe00fc 00fefdfd 00fe02fd     ................
d0086a84:	0000fe00 0002fd00 000000ff fffd01fe     ................
d0086a94:	fefdfffe fefcfffe f9fefbfc fdfdfdfe     ................
d0086aa4:	fefc00fb fefefdfc fdfefefc fefe00fe     ................
d0086ab4:	fffd00fe 00fd00fd 00fd00fd fefffffe     ................
d0086ac4:	ff00ff00 00ff0000 00fc00ff 00feff00     ................
d0086ad4:	fcfffdfe fcfdfdfd fcfdfbfd fbfdfcfd     ................
d0086ae4:	fd00fd00 00fe00fe fefd00fc 00fcfe00     ................
d0086af4:	00fefeff fffefffe 00fd00fd feff00fd     ................
d0086b04:	fe00fe00 fc00fd00 fb00fd00 fefdfe00     ................
d0086b14:	fffdfefe 00fdfefd fd00fefc fefefffc     ................
d0086b24:	fffefefe fd00fefe fe00fd00 00ff00fd     ................
d0086b34:	0000fefe fefe00fe fe00fdff fdfefefc     ................
d0086b44:	fefdfdfd fd00fcfe fffefd00 fd00fefe     ................
d0086b54:	fe00fd00 0000ff00 fd00fd00 fd00fc00     ................
d0086b64:	fefcfefe 00fdfdfc fffdfefd fdfffefd     ................
d0086b74:	00fdfd00 fefd00fc fffdfdfe ff00fdfe     ................
d0086b84:	fffefffe 0000fe00 0000fe00 00fe00fe     ................
d0086b94:	00fe00ff 00feffff 00000000 e4d9ff28     ............(...
d0086ba4:	0dbdb244 1e2500ba 1f27141d 0e39282d     D.....%...'.-(9.
d0086bb4:	583c0064 e7f808ee abbec7d4 99969d92     d.<X............
d0086bc4:	b8aea398 eddfccbd 4b1cfaf2 5a4a4b32     ...........K2KJZ
d0086bd4:	7f7e7b73 767d7f7f 515a6e6e 212d394b     s{~...}vnnZQK9-!
d0086be4:	e8f40312 b3b6cdd7 809f97a7 808a809a     ................
d0086bf4:	83808080 a49c948c d9c3bcb5 07fbefe4     ................
d0086c04:	44382416 7e696155 7f7f7f7f 7f7f7f7f     .$8DUai~........
d0086c14:	70797f7f 4d4b5a6a 1e25383c eaff050c     ..ypjZKM<8%.....
d0086c24:	beccd6dc 99a2b3ba 808d8590 8480808b     ................
d0086c34:	908a8780 aaa29d98 d2c2bbb2 f8ede1d8     ................
d0086c44:	1b0d0cff 39383022 4e504949 5a585656     ...."089IIPNVVXZ
d0086c54:	56615c5c 56555955 49515055 3e42484b     \\aVUYUVUPQIKHB>
d0086c64:	3034383c 1a22222c 040d1013 edf8f9fe     <840,"".........
d0086c74:	dbdee4ec c3c7cdd3 b2b3b3bd a4a5a6ac     ................
d0086c84:	9c9ba09d 9c9b9b9a aba6a3a0 c3bbb6b0     ................
d0086c94:	e1d9cfc9 fdf7f1e5 1b130d03 3a332c21     ............!,3:
d0086ca4:	59504a43 6a67635e 7272716f 696f7072     CJPY^cgjoqrrrpoi
d0086cb4:	565b6066 3a42494f 1d262d33 01080f16     f`[VOIB:3-&.....
d0086cc4:	e7eef7fc cfd6dbe3 bcc1c4cb b2b2b6ba     ................
d0086cd4:	afafb0b1 b6b2b2b0 c2bdbbb7 d2cec9c6     ................
d0086ce4:	e5e1dbd7 f8f3eeea 0502fffc 110f0d08     ................
d0086cf4:	1c1a1814 21211e1d 24222221 21222224     ......!!!""$$""!
d0086d04:	1d1f1f21 191a1b1c 13131618 0e0f1011     !...............
d0086d14:	08090c0d 04040506 ff010203 feffffff     ................
d0086d24:	fbfcfcfd f8f8f9fa f4f4f7f8 f3f3f4f4     ................
d0086d34:	f3f2f2f2 f1f2f2f2 f3f3f2f2 f3f3f3f3     ................
d0086d44:	f7f7f4f4 f8f8f8f7 f9f9f9f9 fcfbfbfa     ................
d0086d54:	fdfdfcfc fffefefe ffffffff 0201ffff     ................
d0086d64:	02020202 04030303 04040303 04040404     ................
d0086d74:	04040404 04040404 03040304 02030303     ................
d0086d84:	02020303 01020102 01ff0101 ffffffff     ................
d0086d94:	ffffffff ffffffff e4320000 bf101ff8     ..........2.....
d0086da4:	407f7fed 93f8ce28 80808096 d6808080     ...@(...........
d0086db4:	aa7f0df2 7f7f747f 737f7f7f cde630f0     .....t.....s.0..
d0086dc4:	98f8178e 802c8020 ff80807f 80a58093     .... .,.........
d0086dd4:	9530c1db 166bf855 7f7f297f 7f7f7f45     ..0.U.k..)..E...
d0086de4:	6a7f7f65 e907763f bd9980c0 a380a180     e..j?v..........
d0086df4:	aa80a180 80808080 87808080 33d4bcf6     ...............3
d0086e04:	517b1d58 7f7f747f 7f7f7f7f 5b7f7f7f     X.{Q.t.........[
d0086e14:	22706969 af78062a cf03db35 d1b7eba3     iip"*.x.5.......
d0086e24:	b8b6fbd4 b20cd410 f4d3d205 bc0dbece     ................
d0086e34:	cacbe7c7 ddbec6b5 c4a5cf91 ca12c9cf     ................
d0086e44:	f648b12f f61b2df2 540a2e13 4b49672d     /.H..-.....T-gIK
d0086e54:	3a7c3360 6cf84f7f d86ff466 c349293a     `3|:.O.lf.o.:)I.
d0086e64:	e8182d00 0ef2fdfd f7e1f8de c61bedbd     .-..............
d0086e74:	e215cad7 f58048b6 cda1bd0c 90c1cfee     .....H..........
d0086e84:	86beb9aa 80a38596 809a8f91 8bb39f91     ................
d0086e94:	b1d0bd9e e60ececb 162efb31 6a687066     ........1...fphj
d0086ea4:	7f7f7e7f 7f7f7f7f 7f7f7f7f 7f7f7f7f     .~..............
d0086eb4:	7f7f7f7f 4b7c6f7f 611f227f cf0e270d     .....o|K.".a.'..
d0086ec4:	9cb19513 808083a1 80808080 80808080     ................
d0086ed4:	80808080 80808080 99808080 a9948080     ................
d0086ee4:	9bacb394 e912a511 70e8201a 3c421231     ......... .p1.B<
d0086ef4:	65646655 347f724a 5c5d7d62 446d5471     UfdeJr.4b}]\qTmD
d0086f04:	19456a4b 69cc697f 28343a31 29303acd     KjE..i.i1:4(.:0)
d0086f14:	3f5318ff 415d55f0 3a585812 7b365039     ..S?.U]A.XX:9P6{
d0086f24:	4e5a343a 09207bf5 dd48ff4f ecd84901     :4ZN.{ .O.H..I..
d0086f34:	d3c5cde0 9081cb90 9f8097ab 80808b88     ................
d0086f44:	80808080 a1808080 af808f80 a8d480ac     ................
d0086f54:	aef2a3af ede3c2d4 daf129d1 e4043a04     .........)...:..
d0086f64:	4731f852 3f331055 7f563366 757f582c     R.1GU.3?f3V.,X.u
d0086f74:	667f6b6b 7f79527f 547f287f 624b503e     kk.f.Ry..(.T>PKb
d0086f84:	494bf74a 22030549 053af113 1f01d812     J.KII.."..:.....
d0086f94:	e505dd08 b71509fa b40e03f7 0ff1bb13     ................
d0086fa4:	c6fac8cc 0ad7c9d0 9ceaf3b8 db01803f     ............?...
d0086fb4:	baf0cdd7 a7d0dce2 e4c6dae3 fdf3c1b9     ................
d0086fc4:	dbd0e9c2 bac40bb0 c8069d02 fbeeaffb     ................
d0086fd4:	fee7e9f0 01e8fbee 2efaf526 47e04318     ........&....C.G
d0086fe4:	0e0e1935 101e6a2c 1a0c2e7c 61363469     5...,j..|...i46a
d0086ff4:	3f1b570c fff4211f e32a0d02 34c72ce0     .W.?.!....*..,.4
d0087004:	d4e428cb df25f21f e1fec60e e7080010     .(....%.........
d0087014:	d90034c7 1ee3fa38 0812f53e 29f20210     .4..8...>......)
d0087024:	e4d210ed ee17e0fe 30da1601 2bce0cdb     ...........0...+
d0087034:	120bc800 d3f51ce7 fc13e228 e1eef8c2     ........(.......
d0087044:	21bca1f5 daeedfc6 07c70dcd c4b1f807     ...!............
d0087054:	1bcbfa1e 56dc1ee7 0d4811ef 3b471f40     .......V..H.@.G;
d0087064:	20e83441 0d002328 31f0f3ed f2de21b4     A4. (#.....1.!..
d0087074:	c706f90a fbf9fa20 f1dde6fb 14d80eee     .... ...........
d0087084:	0d02c41c 35ea25f9 35d62be1 e119fdf3     .....%.5.+.5....
d0087094:	de0b0c1a f4ca170a 1a0405ee 2e2adaf8     ..............*.
d00870a4:	0e1c4fde fc23ff0f 13e12616 e52aeefb     .O....#..&....*.
d00870b4:	07ecd6f0 e0d0c8f2 f0d2c5ec d5e018ef     ................
d00870c4:	d92bc81b f4f511fb 05f92605 0644171d     ..+......&....D.
d00870d4:	4c1c1d16 2c2d1cf2 021b09ed ea1bf3ef     ...L..-,........
d00870e4:	f6cd000c 11d7fcfd c01ede01 f8beec1b     ................
d00870f4:	fce5f0db f5f9e402 29f8d819 1dec0df2     ...........)....
d0087104:	fb1b1fd3 efe40f15 f931f127 2cf81916     ........'.1....,
d0087114:	21ca26fe 08f3ea0e 020502eb 0606fd0e     .&.!............
d0087124:	210af71b 15181ed6 10f6aefc 04cd06e3     ...!............
d0087134:	f4d00dcc f4fc0fec 06f8df06 e4ec1804     ................
d0087144:	28e90710 271d0301 02220214 1def2730     ...(...'..".0'..
d0087154:	011cfa0f 0212d51c cf1600dd 1ddb0dff     ................
d0087164:	ed1fdad6 02fbb40a fdffe000 fff602e7     ................
d0087174:	1bc30401 f5f50006 0dff0332 fb1cf61a     ........2.......
d0087184:	1410ec00 15f61ef6 f10702eb 2501fb06     ...............%
d0087194:	041bf107 00e8eb1d df041fef fadf100d     ................
d00871a4:	d607ffce e3f0ff09 2214da15 ebdc25e6     ...........".%..
d00871b4:	e608f501 ef08f6ec 26fb1b16 17e74edb     ...........&.N..
d00871c4:	db32101e 30012618 2212effa 0a0200ef     ..2..&.0..."....
d00871d4:	fc0df8ee ff1ae9ff f8e31cd5 0ec605fb     ................
d00871e4:	05e9f8d5 1bd9efc9 e6c50fc7 11dce60d     ................
d00871f4:	22dc26e8 23f31716 03223805 14061efc     .&."...#.8".....
d0087204:	3002290a 1e0e14e4 fafb08f1 f401ed16     .).0............
d0087214:	0be5ef0c ebebf8e5 10d615e1 05d9f8ee     ................
d0087224:	dfffdf17 ef1afe08 040404fb 1fff0911     ................
d0087234:	f52afffd fdf90d0d 000efe30 17fb0304     ..*.....0.......
d0087244:	0d020be4 cd0f1dd9 f4ef0b0f fdfdf8e7     ................
d0087254:	00fbf1f2 0bf1ee04 02e709f6 fc02f60f     ................
d0087264:	00e816e9 de1d05f7 17ee021b 0117f8f1     ................
d0087274:	02eff20f efe80f0b fbf5090b 0e140314     ................
d0087284:	fc140c09 031a0efe f2e40107 faf513fc     ................
d0087294:	09faecff fb05e5f7 f7ee02eb e80adb02     ................
d00872a4:	f60305fd 18f605f6 020417fe 03121c00     ................
d00872b4:	fc1812f5 f7061007 db10021f 00fa0a0b     ................
d00872c4:	080305f6 fffd0ade 0406fcfc ec03fcf3     ................
d00872d4:	16dcf616 e400f700 f200ef0f f610d0f6     ................
d00872e4:	fbd2fbfb 050dee13 ef1ff3fd 01030512     ................
d00872f4:	f2fc25fa 0b100f0b f722ff0a 1afe0e21     .%........".!...
d0087304:	ed01fefa 0af7ea0d d114d901 f6f8e804     ................
d0087314:	08f9dd15 e311f2f0 00f5f80f 010a0003     ................
d0087324:	f110f805 e6170916 000f22fa f70725f4     ........."...%..
d0087334:	fffc26f1 19fdfa14 fc000ffb e71ff7e1     .&..............
d0087344:	ec0af201 0500eb02 23250000 13181a1d     ..........%#....
d0087354:	080b0e10 06050606 38281a0d 454d4f47     ..........(8GOME
d0087364:	e6011d34 8086a2c1 80808080 80808080     4...............
d0087374:	b99b8180 3816ffd9 6b69614f 49566469     .......8OaikidVI
d0087384:	0b1a2a3a eef2fa00 fbf5f0ee 1a120801     :*..............
d0087394:	38322d23 4747453d 3f434547 282d343c     #-28=EGGGEC?<4-(
d00873a4:	0d121a23 f8fd0106 e5e6eaf2 d9dbdfe1     #...............
d00873b4:	cbccd0d3 c3c4c8cb bbbdbec1 b7b7b9b9     ................
d00873c4:	b9b7b7b7 bebebdbb c1c1c1be bbbdbec1     ................
d00873d4:	b9b9b9bb c1bebbb9 d1ccc8c4 f5e8dbd6     ................
d00873e4:	1b1608ff 181d2321 fa010b10 d8dde6ee     ....!#..........
d00873f4:	d0ccccd0 ede1d9d1 160d00f8 4a3f3427     ............'4?J
d0087404:	71696158 7f7f7c79 7f7f7f7f 74797e7f     Xaiqy|.......~yt
d0087414:	64656b72 494f525a 343a3d43 23272d30     rkedZROIC=:40-'#
d0087424:	161a1d21 0d0e1012 0606080b 231b120d     !..............#
d0087434:	32342f2a 0518232d b7cee1f8 808294a2     */42-#..........
d0087444:	80808080 80808080 ccb39b87 2310ffe5     ...............#
d0087454:	4f473d32 50525452 3842474d 1d232a30     2=GORTRPMGB80*#.
d0087464:	0e10161a 0806080b 12100d0b 211d1a16     ...............!
d0087474:	25252323 00000000 19243044 c1c90913     ##%%....D0$.....
d0087484:	8daf9aea d0bec7a0 ece7e3dc 04fcf6f1     ................
d0087494:	7f2a0f09 707f4734 0f143c51 47503914     ..*.4G.pQ<...9PG
d00874a4:	1d07172e 00000000 19243044 c1c90913     ........D0$.....
d00874b4:	8daf9aea d0bec7a0 ece7e3dc 04fcf6f1     ................
d00874c4:	7f2a0f09 707f4734 0f143c51 47503914     ..*.4G.pQ<...9PG
d00874d4:	0000172e 30440000 09131924 9aeac1c9     ......D0$.......
d00874e4:	c7a08daf e3dcd0be f6f1ece7 0f0904fc     ................
d00874f4:	47347f2a 3c51707f 39140f14 00004750     *.4G.pQ<...9PG..
d0087504:	30440000 09131924 9aeac1c9 c7a08daf     ..D0$...........
d0087514:	e3dcd0be f6f1ece7 0f0904fc 47347f2a     ............*.4G
d0087524:	3c51707f 39140f14 00000000 19243044     .pQ<...9....D0$.
d0087534:	c1c90913 8daf9aea d0bec7a0 ece7e3dc     ................
d0087544:	04fcf6f1 7f2a0f09 707f4734 0f143c51     ......*.4G.pQ<..
d0087554:	00000000 19243044 c1c90913 8daf9aea     ....D0$.........
d0087564:	d0bec7a0 ece7e3dc 04fcf6f1 7f2a0f09     ..............*.
d0087574:	707f4734 00000000 83868a8d 81818182     4G.p............
d0087584:	81818181 81818181 81818181 81818181     ................
d0087594:	00000000 0d131924 dfe3040a c2d5caf5     ....$...........
d00875a4:	e7dde2cc f6f3f1ed 01fffcf9 45160704     ...............E
d00875b4:	3c45261c 070a202b 262b1e0a 0f030c18     .&E<+ ....+&....
d00875c4:	00000000 0d131924 dfe3040a c2d5caf5     ....$...........
d00875d4:	e7dde2cc f5f3f1ed 01fffcf9 45160704     ...............E
d00875e4:	3c45261c 070a202b 262b1e0a 00000c18     .&E<+ ....+&....
d00875f4:	19240000 040a0d13 caf5dfe3 e2ccc2d5     ..$.............
d0087604:	f1ede7dd fcf9f6f3 070401ff 261c4516     .............E.&
d0087614:	202b3c45 1e0a070a 0000262b 19240000     E<+ ....+&....$.
d0087624:	040a0d13 caf5dfe3 e2ccc2d5 f1ede7dd     ................
d0087634:	fcf9f6f3 070401ff 261c4516 202b3c45     .........E.&E<+ 
d0087644:	1e0a070a 00000000 0d131926 dfe3040a     ........&.......
d0087654:	c2d5caf4 e7dde2cb f6f3f1ec 01fffcf9     ................
d0087664:	45160704 3c45261d 070a202c 00000000     ...E.&E<, ......
d0087674:	0d131924 dfe3040a c2d5caf5 e7dce2cc     $...............
d0087684:	f6f3f1ed 01fffcf9 45160704 3c45261c     ...........E.&E<
d0087694:	00000000 bcbec1c2 bbbbbbbc bbbabbbb     ................
d00876a4:	bbbbbbbb bbbbbbbb bbbbbbbb              ............

d00876b0 <_global_impure_ptr>:
d00876b0:	d0087760                                `w..

d00876b4 <__sf_fake_stderr>:
	...

d00876d4 <__sf_fake_stdin>:
	...

d00876f4 <__sf_fake_stdout>:
	...
d0087714:	2b302d23 6c680020 6665004c 47464567     #-0+ .hlL.efgEFG
d0087724:	32313000 36353433 41393837 45444342     .0123456789ABCDE
d0087734:	31300046 35343332 39383736 64636261     F.0123456789abcd
d0087744:	                                         ef.

Disassembly of section .init:

d0087748 <_init>:
d0087748:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008774a:	bf00      	nop

Disassembly of section .fini:

d008774c <_fini>:
d008774c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008774e:	bf00      	nop
