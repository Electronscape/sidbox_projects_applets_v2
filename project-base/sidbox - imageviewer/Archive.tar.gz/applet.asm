
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0001010 <applet_entry>:
d0001010:	b570      	push	{r4, r5, r6, lr}
d0001012:	4e09      	ldr	r6, [pc, #36]	; (d0001038 <applet_entry+0x28>)
d0001014:	460d      	mov	r5, r1
d0001016:	4604      	mov	r4, r0
d0001018:	2100      	movs	r1, #0
d000101a:	6833      	ldr	r3, [r6, #0]
d000101c:	6898      	ldr	r0, [r3, #8]
d000101e:	f00b fa27 	bl	d000c470 <setbuf>
d0001022:	6833      	ldr	r3, [r6, #0]
d0001024:	2100      	movs	r1, #0
d0001026:	68d8      	ldr	r0, [r3, #12]
d0001028:	f00b fa22 	bl	d000c470 <setbuf>
d000102c:	4629      	mov	r1, r5
d000102e:	4620      	mov	r0, r4
d0001030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0001034:	f008 bc10 	b.w	d0009858 <main>
d0001038:	d000de58 	.word	0xd000de58

d000103c <gfx_createBitmap>:
d000103c:	b510      	push	{r4, lr}
d000103e:	4604      	mov	r4, r0
d0001040:	fb01 f002 	mul.w	r0, r1, r2
d0001044:	b292      	uxth	r2, r2
d0001046:	80a1      	strh	r1, [r4, #4]
d0001048:	60e0      	str	r0, [r4, #12]
d000104a:	80e2      	strh	r2, [r4, #6]
d000104c:	8122      	strh	r2, [r4, #8]
d000104e:	f00a fdbd 	bl	d000bbcc <malloc>
d0001052:	6020      	str	r0, [r4, #0]
d0001054:	bd10      	pop	{r4, pc}
d0001056:	bf00      	nop

d0001058 <initMalloc>:
d0001058:	4902      	ldr	r1, [pc, #8]	; (d0001064 <initMalloc+0xc>)
d000105a:	4b03      	ldr	r3, [pc, #12]	; (d0001068 <initMalloc+0x10>)
d000105c:	4a03      	ldr	r2, [pc, #12]	; (d000106c <initMalloc+0x14>)
d000105e:	1a5b      	subs	r3, r3, r1
d0001060:	6013      	str	r3, [r2, #0]
d0001062:	4770      	bx	lr
d0001064:	d0011138 	.word	0xd0011138
d0001068:	d0600000 	.word	0xd0600000
d000106c:	d000f0c0 	.word	0xd000f0c0

d0001070 <_write_r>:
d0001070:	3901      	subs	r1, #1
d0001072:	2901      	cmp	r1, #1
d0001074:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0001076:	d81f      	bhi.n	d00010b8 <_write_r+0x48>
d0001078:	b1e2      	cbz	r2, d00010b4 <_write_r+0x44>
d000107a:	461c      	mov	r4, r3
d000107c:	b1d3      	cbz	r3, d00010b4 <_write_r+0x44>
d000107e:	4d12      	ldr	r5, [pc, #72]	; (d00010c8 <_write_r+0x58>)
d0001080:	682e      	ldr	r6, [r5, #0]
d0001082:	b9ae      	cbnz	r6, d00010b0 <_write_r+0x40>
d0001084:	4f11      	ldr	r7, [pc, #68]	; (d00010cc <_write_r+0x5c>)
d0001086:	2301      	movs	r3, #1
d0001088:	4611      	mov	r1, r2
d000108a:	4630      	mov	r0, r6
d000108c:	602b      	str	r3, [r5, #0]
d000108e:	4622      	mov	r2, r4
d0001090:	7a3b      	ldrb	r3, [r7, #8]
d0001092:	f897 c009 	ldrb.w	ip, [r7, #9]
d0001096:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d000109a:	f897 c00a 	ldrb.w	ip, [r7, #10]
d000109e:	7aff      	ldrb	r7, [r7, #11]
d00010a0:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d00010a4:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d00010a8:	681b      	ldr	r3, [r3, #0]
d00010aa:	685b      	ldr	r3, [r3, #4]
d00010ac:	4798      	blx	r3
d00010ae:	602e      	str	r6, [r5, #0]
d00010b0:	4620      	mov	r0, r4
d00010b2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00010b4:	2000      	movs	r0, #0
d00010b6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00010b8:	f00a fd70 	bl	d000bb9c <__errno>
d00010bc:	2209      	movs	r2, #9
d00010be:	4603      	mov	r3, r0
d00010c0:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00010c4:	601a      	str	r2, [r3, #0]
d00010c6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00010c8:	d000dec4 	.word	0xd000dec4
d00010cc:	2001f000 	.word	0x2001f000

d00010d0 <_read>:
d00010d0:	b508      	push	{r3, lr}
d00010d2:	f00a fd63 	bl	d000bb9c <__errno>
d00010d6:	2258      	movs	r2, #88	; 0x58
d00010d8:	4603      	mov	r3, r0
d00010da:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00010de:	601a      	str	r2, [r3, #0]
d00010e0:	bd08      	pop	{r3, pc}
d00010e2:	bf00      	nop

d00010e4 <_close>:
d00010e4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00010e8:	4770      	bx	lr
d00010ea:	bf00      	nop

d00010ec <_fstat>:
d00010ec:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d00010f0:	2000      	movs	r0, #0
d00010f2:	604b      	str	r3, [r1, #4]
d00010f4:	4770      	bx	lr
d00010f6:	bf00      	nop

d00010f8 <_lseek>:
d00010f8:	2000      	movs	r0, #0
d00010fa:	4770      	bx	lr

d00010fc <_sbrk_r>:
d00010fc:	4b0c      	ldr	r3, [pc, #48]	; (d0001130 <_sbrk_r+0x34>)
d00010fe:	4a0d      	ldr	r2, [pc, #52]	; (d0001134 <_sbrk_r+0x38>)
d0001100:	6818      	ldr	r0, [r3, #0]
d0001102:	b510      	push	{r4, lr}
d0001104:	b918      	cbnz	r0, d000110e <_sbrk_r+0x12>
d0001106:	1dd0      	adds	r0, r2, #7
d0001108:	f020 0007 	bic.w	r0, r0, #7
d000110c:	6018      	str	r0, [r3, #0]
d000110e:	4401      	add	r1, r0
d0001110:	4c09      	ldr	r4, [pc, #36]	; (d0001138 <_sbrk_r+0x3c>)
d0001112:	42a1      	cmp	r1, r4
d0001114:	d803      	bhi.n	d000111e <_sbrk_r+0x22>
d0001116:	4291      	cmp	r1, r2
d0001118:	d301      	bcc.n	d000111e <_sbrk_r+0x22>
d000111a:	6019      	str	r1, [r3, #0]
d000111c:	bd10      	pop	{r4, pc}
d000111e:	f00a fd3d 	bl	d000bb9c <__errno>
d0001122:	220c      	movs	r2, #12
d0001124:	4603      	mov	r3, r0
d0001126:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000112a:	601a      	str	r2, [r3, #0]
d000112c:	bd10      	pop	{r4, pc}
d000112e:	bf00      	nop
d0001130:	d000dec0 	.word	0xd000dec0
d0001134:	d0011138 	.word	0xd0011138
d0001138:	d0600000 	.word	0xd0600000

d000113c <_isatty>:
d000113c:	2001      	movs	r0, #1
d000113e:	4770      	bx	lr

d0001140 <_exit>:
d0001140:	e7fe      	b.n	d0001140 <_exit>
d0001142:	bf00      	nop

d0001144 <_getpid>:
d0001144:	2001      	movs	r0, #1
d0001146:	4770      	bx	lr

d0001148 <_kill>:
d0001148:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000114c:	4770      	bx	lr
d000114e:	bf00      	nop

d0001150 <stbi__idct_block>:
d0001150:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0001154:	f102 0310 	add.w	r3, r2, #16
d0001158:	b0c7      	sub	sp, #284	; 0x11c
d000115a:	4690      	mov	r8, r2
d000115c:	f10d 0e18 	add.w	lr, sp, #24
d0001160:	9005      	str	r0, [sp, #20]
d0001162:	9104      	str	r1, [sp, #16]
d0001164:	9303      	str	r3, [sp, #12]
d0001166:	e09c      	b.n	d00012a2 <stbi__idct_block+0x152>
d0001168:	2f00      	cmp	r7, #0
d000116a:	f040 80a6 	bne.w	d00012ba <stbi__idct_block+0x16a>
d000116e:	f1b9 0f00 	cmp.w	r9, #0
d0001172:	f040 80a2 	bne.w	d00012ba <stbi__idct_block+0x16a>
d0001176:	f9b8 3050 	ldrsh.w	r3, [r8, #80]	; 0x50
d000117a:	9301      	str	r3, [sp, #4]
d000117c:	f1bb 0f00 	cmp.w	fp, #0
d0001180:	f000 81dc 	beq.w	d000153c <stbi__idct_block+0x3ec>
d0001184:	464f      	mov	r7, r9
d0001186:	f9b8 3060 	ldrsh.w	r3, [r8, #96]	; 0x60
d000118a:	4619      	mov	r1, r3
d000118c:	f9b8 3070 	ldrsh.w	r3, [r8, #112]	; 0x70
d0001190:	461d      	mov	r5, r3
d0001192:	9302      	str	r3, [sp, #8]
d0001194:	187c      	adds	r4, r7, r1
d0001196:	eb05 0c09 	add.w	ip, r5, r9
d000119a:	e9dd 2300 	ldrd	r2, r3, [sp]
d000119e:	1898      	adds	r0, r3, r2
d00011a0:	460a      	mov	r2, r1
d00011a2:	f640 01a9 	movw	r1, #2217	; 0x8a9
d00011a6:	461e      	mov	r6, r3
d00011a8:	eb0c 0300 	add.w	r3, ip, r0
d00011ac:	fb01 f404 	mul.w	r4, r1, r4
d00011b0:	9900      	ldr	r1, [sp, #0]
d00011b2:	444e      	add	r6, r9
d00011b4:	440d      	add	r5, r1
d00011b6:	f241 21d0 	movw	r1, #4816	; 0x12d0
d00011ba:	fb01 fa03 	mul.w	sl, r1, r3
d00011be:	49db      	ldr	r1, [pc, #876]	; (d000152c <stbi__idct_block+0x3dc>)
d00011c0:	f9b8 3000 	ldrsh.w	r3, [r8]
d00011c4:	fb01 fc0c 	mul.w	ip, r1, ip
d00011c8:	49d9      	ldr	r1, [pc, #868]	; (d0001530 <stbi__idct_block+0x3e0>)
d00011ca:	fb01 f000 	mul.w	r0, r1, r0
d00011ce:	f46f 5124 	mvn.w	r1, #10496	; 0x2900
d00011d2:	fb01 a606 	mla	r6, r1, r6, sl
d00011d6:	f640 413f 	movw	r1, #3135	; 0xc3f
d00011da:	fb17 4701 	smlabb	r7, r7, r1, r4
d00011de:	49d5      	ldr	r1, [pc, #852]	; (d0001534 <stbi__idct_block+0x3e4>)
d00011e0:	fb01 a505 	mla	r5, r1, r5, sl
d00011e4:	f24e 2171 	movw	r1, #57969	; 0xe271
d00011e8:	fb12 4401 	smlabb	r4, r2, r1, r4
d00011ec:	eb05 0a00 	add.w	sl, r5, r0
d00011f0:	eb03 010b 	add.w	r1, r3, fp
d00011f4:	4430      	add	r0, r6
d00011f6:	eba3 030b 	sub.w	r3, r3, fp
d00011fa:	4466      	add	r6, ip
d00011fc:	4465      	add	r5, ip
d00011fe:	f641 0b05 	movw	fp, #6149	; 0x1805
d0001202:	f243 1c2a 	movw	ip, #12586	; 0x312a
d0001206:	9a00      	ldr	r2, [sp, #0]
d0001208:	fb19 660c 	smlabb	r6, r9, ip, r6
d000120c:	eb07 3901 	add.w	r9, r7, r1, lsl #12
d0001210:	fb12 a20b 	smlabb	r2, r2, fp, sl
d0001214:	eb04 3c03 	add.w	ip, r4, r3, lsl #12
d0001218:	f242 0bda 	movw	fp, #8410	; 0x20da
d000121c:	f240 4ac7 	movw	sl, #1223	; 0x4c7
d0001220:	ebc7 3101 	rsb	r1, r7, r1, lsl #12
d0001224:	9f01      	ldr	r7, [sp, #4]
d0001226:	ebc4 3303 	rsb	r3, r4, r3, lsl #12
d000122a:	9c02      	ldr	r4, [sp, #8]
d000122c:	fb17 000b 	smlabb	r0, r7, fp, r0
d0001230:	f509 7900 	add.w	r9, r9, #512	; 0x200
d0001234:	fb14 550a 	smlabb	r5, r4, sl, r5
d0001238:	f503 7300 	add.w	r3, r3, #512	; 0x200
d000123c:	f501 7100 	add.w	r1, r1, #512	; 0x200
d0001240:	f50c 7c00 	add.w	ip, ip, #512	; 0x200
d0001244:	eb02 0409 	add.w	r4, r2, r9
d0001248:	eb00 0b03 	add.w	fp, r0, r3
d000124c:	eb06 0a0c 	add.w	sl, r6, ip
d0001250:	186f      	adds	r7, r5, r1
d0001252:	1a18      	subs	r0, r3, r0
d0001254:	1b49      	subs	r1, r1, r5
d0001256:	eba9 0202 	sub.w	r2, r9, r2
d000125a:	ebac 0c06 	sub.w	ip, ip, r6
d000125e:	12a4      	asrs	r4, r4, #10
d0001260:	1292      	asrs	r2, r2, #10
d0001262:	ea4f 25aa 	mov.w	r5, sl, asr #10
d0001266:	f8ce 4000 	str.w	r4, [lr]
d000126a:	ea4f 26ac 	mov.w	r6, ip, asr #10
d000126e:	f8ce 20e0 	str.w	r2, [lr, #224]	; 0xe0
d0001272:	ea4f 23ab 	mov.w	r3, fp, asr #10
d0001276:	f8ce 5020 	str.w	r5, [lr, #32]
d000127a:	1280      	asrs	r0, r0, #10
d000127c:	f8ce 60c0 	str.w	r6, [lr, #192]	; 0xc0
d0001280:	12bf      	asrs	r7, r7, #10
d0001282:	f8ce 3040 	str.w	r3, [lr, #64]	; 0x40
d0001286:	1289      	asrs	r1, r1, #10
d0001288:	f8ce 00a0 	str.w	r0, [lr, #160]	; 0xa0
d000128c:	f8ce 7060 	str.w	r7, [lr, #96]	; 0x60
d0001290:	f8ce 1080 	str.w	r1, [lr, #128]	; 0x80
d0001294:	f108 0802 	add.w	r8, r8, #2
d0001298:	9b03      	ldr	r3, [sp, #12]
d000129a:	f10e 0e04 	add.w	lr, lr, #4
d000129e:	4543      	cmp	r3, r8
d00012a0:	d00f      	beq.n	d00012c2 <stbi__idct_block+0x172>
d00012a2:	f9b8 3010 	ldrsh.w	r3, [r8, #16]
d00012a6:	f9b8 7020 	ldrsh.w	r7, [r8, #32]
d00012aa:	f9b8 9030 	ldrsh.w	r9, [r8, #48]	; 0x30
d00012ae:	f9b8 b040 	ldrsh.w	fp, [r8, #64]	; 0x40
d00012b2:	9300      	str	r3, [sp, #0]
d00012b4:	2b00      	cmp	r3, #0
d00012b6:	f43f af57 	beq.w	d0001168 <stbi__idct_block+0x18>
d00012ba:	f9b8 3050 	ldrsh.w	r3, [r8, #80]	; 0x50
d00012be:	9301      	str	r3, [sp, #4]
d00012c0:	e761      	b.n	d0001186 <stbi__idct_block+0x36>
d00012c2:	f10d 0c38 	add.w	ip, sp, #56	; 0x38
d00012c6:	9905      	ldr	r1, [sp, #20]
d00012c8:	e064      	b.n	d0001394 <stbi__idct_block+0x244>
d00012ca:	ebab 0b04 	sub.w	fp, fp, r4
d00012ce:	2800      	cmp	r0, #0
d00012d0:	bfac      	ite	ge
d00012d2:	20ff      	movge	r0, #255	; 0xff
d00012d4:	2000      	movlt	r0, #0
d00012d6:	f1bb 7f00 	cmp.w	fp, #33554432	; 0x2000000
d00012da:	ea4f 446b 	mov.w	r4, fp, asr #17
d00012de:	7008      	strb	r0, [r1, #0]
d00012e0:	f0c0 80de 	bcc.w	d00014a0 <stbi__idct_block+0x350>
d00012e4:	eb0a 0007 	add.w	r0, sl, r7
d00012e8:	2c00      	cmp	r4, #0
d00012ea:	bfac      	ite	ge
d00012ec:	24ff      	movge	r4, #255	; 0xff
d00012ee:	2400      	movlt	r4, #0
d00012f0:	f1b0 7f00 	cmp.w	r0, #33554432	; 0x2000000
d00012f4:	71cc      	strb	r4, [r1, #7]
d00012f6:	ea4f 4460 	mov.w	r4, r0, asr #17
d00012fa:	f0c0 80db 	bcc.w	d00014b4 <stbi__idct_block+0x364>
d00012fe:	ebaa 0707 	sub.w	r7, sl, r7
d0001302:	2c00      	cmp	r4, #0
d0001304:	bfac      	ite	ge
d0001306:	20ff      	movge	r0, #255	; 0xff
d0001308:	2000      	movlt	r0, #0
d000130a:	f1b7 7f00 	cmp.w	r7, #33554432	; 0x2000000
d000130e:	ea4f 4467 	mov.w	r4, r7, asr #17
d0001312:	7048      	strb	r0, [r1, #1]
d0001314:	f0c0 80d8 	bcc.w	d00014c8 <stbi__idct_block+0x378>
d0001318:	eb03 0008 	add.w	r0, r3, r8
d000131c:	2c00      	cmp	r4, #0
d000131e:	bfac      	ite	ge
d0001320:	24ff      	movge	r4, #255	; 0xff
d0001322:	2400      	movlt	r4, #0
d0001324:	f1b0 7f00 	cmp.w	r0, #33554432	; 0x2000000
d0001328:	718c      	strb	r4, [r1, #6]
d000132a:	ea4f 4460 	mov.w	r4, r0, asr #17
d000132e:	f0c0 80d5 	bcc.w	d00014dc <stbi__idct_block+0x38c>
d0001332:	eba3 0808 	sub.w	r8, r3, r8
d0001336:	2c00      	cmp	r4, #0
d0001338:	bfac      	ite	ge
d000133a:	20ff      	movge	r0, #255	; 0xff
d000133c:	2000      	movlt	r0, #0
d000133e:	f1b8 7f00 	cmp.w	r8, #33554432	; 0x2000000
d0001342:	7088      	strb	r0, [r1, #2]
d0001344:	ea4f 4068 	mov.w	r0, r8, asr #17
d0001348:	f0c0 80d2 	bcc.w	d00014f0 <stbi__idct_block+0x3a0>
d000134c:	18b3      	adds	r3, r6, r2
d000134e:	2800      	cmp	r0, #0
d0001350:	bfac      	ite	ge
d0001352:	20ff      	movge	r0, #255	; 0xff
d0001354:	2000      	movlt	r0, #0
d0001356:	f1b3 7f00 	cmp.w	r3, #33554432	; 0x2000000
d000135a:	7148      	strb	r0, [r1, #5]
d000135c:	ea4f 4063 	mov.w	r0, r3, asr #17
d0001360:	f0c0 80cf 	bcc.w	d0001502 <stbi__idct_block+0x3b2>
d0001364:	1ab2      	subs	r2, r6, r2
d0001366:	2800      	cmp	r0, #0
d0001368:	bfac      	ite	ge
d000136a:	23ff      	movge	r3, #255	; 0xff
d000136c:	2300      	movlt	r3, #0
d000136e:	f1b2 7f00 	cmp.w	r2, #33554432	; 0x2000000
d0001372:	70cb      	strb	r3, [r1, #3]
d0001374:	ea4f 4362 	mov.w	r3, r2, asr #17
d0001378:	f0c0 80cc 	bcc.w	d0001514 <stbi__idct_block+0x3c4>
d000137c:	43db      	mvns	r3, r3
d000137e:	f10c 0c20 	add.w	ip, ip, #32
d0001382:	0fdb      	lsrs	r3, r3, #31
d0001384:	425b      	negs	r3, r3
d0001386:	710b      	strb	r3, [r1, #4]
d0001388:	9b04      	ldr	r3, [sp, #16]
d000138a:	4419      	add	r1, r3
d000138c:	ab4e      	add	r3, sp, #312	; 0x138
d000138e:	4563      	cmp	r3, ip
d0001390:	f000 80c9 	beq.w	d0001526 <stbi__idct_block+0x3d6>
d0001394:	f85c 3c1c 	ldr.w	r3, [ip, #-28]
d0001398:	f46f 5824 	mvn.w	r8, #10496	; 0x2900
d000139c:	f85c 0c0c 	ldr.w	r0, [ip, #-12]
d00013a0:	f641 0a05 	movw	sl, #6149	; 0x1805
d00013a4:	9300      	str	r3, [sp, #0]
d00013a6:	f243 192a 	movw	r9, #12586	; 0x312a
d00013aa:	f85c 3c14 	ldr.w	r3, [ip, #-20]
d00013ae:	f85c 2c04 	ldr.w	r2, [ip, #-4]
d00013b2:	4d5f      	ldr	r5, [pc, #380]	; (d0001530 <stbi__idct_block+0x3e0>)
d00013b4:	189a      	adds	r2, r3, r2
d00013b6:	4403      	add	r3, r0
d00013b8:	f85c 4c08 	ldr.w	r4, [ip, #-8]
d00013bc:	9301      	str	r3, [sp, #4]
d00013be:	9b00      	ldr	r3, [sp, #0]
d00013c0:	f85c 6c18 	ldr.w	r6, [ip, #-24]
d00013c4:	4418      	add	r0, r3
d00013c6:	19a7      	adds	r7, r4, r6
d00013c8:	eb00 0b02 	add.w	fp, r0, r2
d00013cc:	fb05 f000 	mul.w	r0, r5, r0
d00013d0:	f241 25d0 	movw	r5, #4816	; 0x12d0
d00013d4:	fb05 fb0b 	mul.w	fp, r5, fp
d00013d8:	f640 05a9 	movw	r5, #2217	; 0x8a9
d00013dc:	fb05 f707 	mul.w	r7, r5, r7
d00013e0:	f85c 5c04 	ldr.w	r5, [ip, #-4]
d00013e4:	eb03 0e05 	add.w	lr, r3, r5
d00013e8:	4d50      	ldr	r5, [pc, #320]	; (d000152c <stbi__idct_block+0x3dc>)
d00013ea:	9b01      	ldr	r3, [sp, #4]
d00013ec:	fb05 f202 	mul.w	r2, r5, r2
d00013f0:	4d50      	ldr	r5, [pc, #320]	; (d0001534 <stbi__idct_block+0x3e4>)
d00013f2:	fb08 b803 	mla	r8, r8, r3, fp
d00013f6:	f85c 3c10 	ldr.w	r3, [ip, #-16]
d00013fa:	fb05 be0e 	mla	lr, r5, lr, fp
d00013fe:	f640 453f 	movw	r5, #3135	; 0xc3f
d0001402:	eb00 0b0e 	add.w	fp, r0, lr
d0001406:	4440      	add	r0, r8
d0001408:	fb05 7606 	mla	r6, r5, r6, r7
d000140c:	4d4a      	ldr	r5, [pc, #296]	; (d0001538 <stbi__idct_block+0x3e8>)
d000140e:	9001      	str	r0, [sp, #4]
d0001410:	9800      	ldr	r0, [sp, #0]
d0001412:	fb05 7504 	mla	r5, r5, r4, r7
d0001416:	eb02 0708 	add.w	r7, r2, r8
d000141a:	4472      	add	r2, lr
d000141c:	fb0a b400 	mla	r4, sl, r0, fp
d0001420:	f85c 0c20 	ldr.w	r0, [ip, #-32]
d0001424:	eb03 0800 	add.w	r8, r3, r0
d0001428:	1ac3      	subs	r3, r0, r3
d000142a:	f85c 0c14 	ldr.w	r0, [ip, #-20]
d000142e:	eb06 3b08 	add.w	fp, r6, r8, lsl #12
d0001432:	eb05 3a03 	add.w	sl, r5, r3, lsl #12
d0001436:	fb09 7700 	mla	r7, r9, r0, r7
d000143a:	f10b 7b80 	add.w	fp, fp, #16777216	; 0x1000000
d000143e:	ebc6 3608 	rsb	r6, r6, r8, lsl #12
d0001442:	ebc5 3303 	rsb	r3, r5, r3, lsl #12
d0001446:	f85c 0c04 	ldr.w	r0, [ip, #-4]
d000144a:	f50b 3b80 	add.w	fp, fp, #65536	; 0x10000
d000144e:	f240 45c7 	movw	r5, #1223	; 0x4c7
d0001452:	f242 08da 	movw	r8, #8410	; 0x20da
d0001456:	f106 7680 	add.w	r6, r6, #16777216	; 0x1000000
d000145a:	eb0b 0e04 	add.w	lr, fp, r4
d000145e:	fb05 2200 	mla	r2, r5, r0, r2
d0001462:	f10a 7a80 	add.w	sl, sl, #16777216	; 0x1000000
d0001466:	f85c 0c0c 	ldr.w	r0, [ip, #-12]
d000146a:	9d01      	ldr	r5, [sp, #4]
d000146c:	f103 7380 	add.w	r3, r3, #16777216	; 0x1000000
d0001470:	f1be 7f00 	cmp.w	lr, #33554432	; 0x2000000
d0001474:	f506 3680 	add.w	r6, r6, #65536	; 0x10000
d0001478:	fb08 5800 	mla	r8, r8, r0, r5
d000147c:	f50a 3a80 	add.w	sl, sl, #65536	; 0x10000
d0001480:	ea4f 406e 	mov.w	r0, lr, asr #17
d0001484:	f503 3380 	add.w	r3, r3, #65536	; 0x10000
d0001488:	f4bf af1f 	bcs.w	d00012ca <stbi__idct_block+0x17a>
d000148c:	ebab 0b04 	sub.w	fp, fp, r4
d0001490:	b2c0      	uxtb	r0, r0
d0001492:	f1bb 7f00 	cmp.w	fp, #33554432	; 0x2000000
d0001496:	ea4f 446b 	mov.w	r4, fp, asr #17
d000149a:	7008      	strb	r0, [r1, #0]
d000149c:	f4bf af22 	bcs.w	d00012e4 <stbi__idct_block+0x194>
d00014a0:	eb0a 0007 	add.w	r0, sl, r7
d00014a4:	b2e4      	uxtb	r4, r4
d00014a6:	f1b0 7f00 	cmp.w	r0, #33554432	; 0x2000000
d00014aa:	71cc      	strb	r4, [r1, #7]
d00014ac:	ea4f 4460 	mov.w	r4, r0, asr #17
d00014b0:	f4bf af25 	bcs.w	d00012fe <stbi__idct_block+0x1ae>
d00014b4:	ebaa 0707 	sub.w	r7, sl, r7
d00014b8:	b2e0      	uxtb	r0, r4
d00014ba:	f1b7 7f00 	cmp.w	r7, #33554432	; 0x2000000
d00014be:	ea4f 4467 	mov.w	r4, r7, asr #17
d00014c2:	7048      	strb	r0, [r1, #1]
d00014c4:	f4bf af28 	bcs.w	d0001318 <stbi__idct_block+0x1c8>
d00014c8:	eb03 0008 	add.w	r0, r3, r8
d00014cc:	b2e4      	uxtb	r4, r4
d00014ce:	f1b0 7f00 	cmp.w	r0, #33554432	; 0x2000000
d00014d2:	718c      	strb	r4, [r1, #6]
d00014d4:	ea4f 4460 	mov.w	r4, r0, asr #17
d00014d8:	f4bf af2b 	bcs.w	d0001332 <stbi__idct_block+0x1e2>
d00014dc:	eba3 0808 	sub.w	r8, r3, r8
d00014e0:	b2e0      	uxtb	r0, r4
d00014e2:	f1b8 7f00 	cmp.w	r8, #33554432	; 0x2000000
d00014e6:	7088      	strb	r0, [r1, #2]
d00014e8:	ea4f 4068 	mov.w	r0, r8, asr #17
d00014ec:	f4bf af2e 	bcs.w	d000134c <stbi__idct_block+0x1fc>
d00014f0:	18b3      	adds	r3, r6, r2
d00014f2:	b2c0      	uxtb	r0, r0
d00014f4:	f1b3 7f00 	cmp.w	r3, #33554432	; 0x2000000
d00014f8:	7148      	strb	r0, [r1, #5]
d00014fa:	ea4f 4063 	mov.w	r0, r3, asr #17
d00014fe:	f4bf af31 	bcs.w	d0001364 <stbi__idct_block+0x214>
d0001502:	1ab2      	subs	r2, r6, r2
d0001504:	b2c3      	uxtb	r3, r0
d0001506:	f1b2 7f00 	cmp.w	r2, #33554432	; 0x2000000
d000150a:	70cb      	strb	r3, [r1, #3]
d000150c:	ea4f 4362 	mov.w	r3, r2, asr #17
d0001510:	f4bf af34 	bcs.w	d000137c <stbi__idct_block+0x22c>
d0001514:	710b      	strb	r3, [r1, #4]
d0001516:	f10c 0c20 	add.w	ip, ip, #32
d000151a:	9b04      	ldr	r3, [sp, #16]
d000151c:	4419      	add	r1, r3
d000151e:	ab4e      	add	r3, sp, #312	; 0x138
d0001520:	4563      	cmp	r3, ip
d0001522:	f47f af37 	bne.w	d0001394 <stbi__idct_block+0x244>
d0001526:	b047      	add	sp, #284	; 0x11c
d0001528:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000152c:	ffffe09e 	.word	0xffffe09e
d0001530:	fffff9c3 	.word	0xfffff9c3
d0001534:	fffff19b 	.word	0xfffff19b
d0001538:	ffffe271 	.word	0xffffe271
d000153c:	b9db      	cbnz	r3, d0001576 <stbi__idct_block+0x426>
d000153e:	f9b8 3060 	ldrsh.w	r3, [r8, #96]	; 0x60
d0001542:	4619      	mov	r1, r3
d0001544:	bb0b      	cbnz	r3, d000158a <stbi__idct_block+0x43a>
d0001546:	f9b8 3070 	ldrsh.w	r3, [r8, #112]	; 0x70
d000154a:	9302      	str	r3, [sp, #8]
d000154c:	bb2b      	cbnz	r3, d000159a <stbi__idct_block+0x44a>
d000154e:	f9b8 3000 	ldrsh.w	r3, [r8]
d0001552:	009b      	lsls	r3, r3, #2
d0001554:	f8ce 30e0 	str.w	r3, [lr, #224]	; 0xe0
d0001558:	f8ce 30c0 	str.w	r3, [lr, #192]	; 0xc0
d000155c:	f8ce 30a0 	str.w	r3, [lr, #160]	; 0xa0
d0001560:	f8ce 3080 	str.w	r3, [lr, #128]	; 0x80
d0001564:	f8ce 3060 	str.w	r3, [lr, #96]	; 0x60
d0001568:	f8ce 3040 	str.w	r3, [lr, #64]	; 0x40
d000156c:	f8ce 3020 	str.w	r3, [lr, #32]
d0001570:	f8ce 3000 	str.w	r3, [lr]
d0001574:	e68e      	b.n	d0001294 <stbi__idct_block+0x144>
d0001576:	f9b8 3060 	ldrsh.w	r3, [r8, #96]	; 0x60
d000157a:	46d9      	mov	r9, fp
d000157c:	465f      	mov	r7, fp
d000157e:	4619      	mov	r1, r3
d0001580:	f9b8 3070 	ldrsh.w	r3, [r8, #112]	; 0x70
d0001584:	461d      	mov	r5, r3
d0001586:	9302      	str	r3, [sp, #8]
d0001588:	e604      	b.n	d0001194 <stbi__idct_block+0x44>
d000158a:	f9b8 3070 	ldrsh.w	r3, [r8, #112]	; 0x70
d000158e:	9f01      	ldr	r7, [sp, #4]
d0001590:	461d      	mov	r5, r3
d0001592:	9302      	str	r3, [sp, #8]
d0001594:	46bb      	mov	fp, r7
d0001596:	46b9      	mov	r9, r7
d0001598:	e5fc      	b.n	d0001194 <stbi__idct_block+0x44>
d000159a:	460f      	mov	r7, r1
d000159c:	468b      	mov	fp, r1
d000159e:	4689      	mov	r9, r1
d00015a0:	9d02      	ldr	r5, [sp, #8]
d00015a2:	9101      	str	r1, [sp, #4]
d00015a4:	e5f6      	b.n	d0001194 <stbi__idct_block+0x44>
d00015a6:	bf00      	nop

d00015a8 <resample_row_1>:
d00015a8:	4608      	mov	r0, r1
d00015aa:	4770      	bx	lr

d00015ac <stbi__resample_row_v_2>:
d00015ac:	2b00      	cmp	r3, #0
d00015ae:	dd15      	ble.n	d00015dc <stbi__resample_row_v_2+0x30>
d00015b0:	3901      	subs	r1, #1
d00015b2:	3a01      	subs	r2, #1
d00015b4:	b4f0      	push	{r4, r5, r6, r7}
d00015b6:	1e44      	subs	r4, r0, #1
d00015b8:	2703      	movs	r7, #3
d00015ba:	18ce      	adds	r6, r1, r3
d00015bc:	f811 3f01 	ldrb.w	r3, [r1, #1]!
d00015c0:	f812 5f01 	ldrb.w	r5, [r2, #1]!
d00015c4:	428e      	cmp	r6, r1
d00015c6:	fb17 5303 	smlabb	r3, r7, r3, r5
d00015ca:	f103 0302 	add.w	r3, r3, #2
d00015ce:	ea4f 03a3 	mov.w	r3, r3, asr #2
d00015d2:	f804 3f01 	strb.w	r3, [r4, #1]!
d00015d6:	d1f1      	bne.n	d00015bc <stbi__resample_row_v_2+0x10>
d00015d8:	bcf0      	pop	{r4, r5, r6, r7}
d00015da:	4770      	bx	lr
d00015dc:	4770      	bx	lr
d00015de:	bf00      	nop

d00015e0 <stbi__resample_row_hv_2>:
d00015e0:	2b01      	cmp	r3, #1
d00015e2:	d034      	beq.n	d000164e <stbi__resample_row_hv_2+0x6e>
d00015e4:	f04f 0c03 	mov.w	ip, #3
d00015e8:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d00015ec:	7814      	ldrb	r4, [r2, #0]
d00015ee:	780e      	ldrb	r6, [r1, #0]
d00015f0:	fb1c 4606 	smlabb	r6, ip, r6, r4
d00015f4:	f106 0402 	add.w	r4, r6, #2
d00015f8:	f3c4 0487 	ubfx	r4, r4, #2, #8
d00015fc:	7004      	strb	r4, [r0, #0]
d00015fe:	dd20      	ble.n	d0001642 <stbi__resample_row_hv_2+0x62>
d0001600:	f101 3eff 	add.w	lr, r1, #4294967295	; 0xffffffff
d0001604:	4607      	mov	r7, r0
d0001606:	449e      	add	lr, r3
d0001608:	f811 4f01 	ldrb.w	r4, [r1, #1]!
d000160c:	46b0      	mov	r8, r6
d000160e:	f812 6f01 	ldrb.w	r6, [r2, #1]!
d0001612:	eb08 0548 	add.w	r5, r8, r8, lsl #1
d0001616:	458e      	cmp	lr, r1
d0001618:	fb1c 6604 	smlabb	r6, ip, r4, r6
d000161c:	eb06 0446 	add.w	r4, r6, r6, lsl #1
d0001620:	4435      	add	r5, r6
d0001622:	4444      	add	r4, r8
d0001624:	f105 0508 	add.w	r5, r5, #8
d0001628:	f104 0408 	add.w	r4, r4, #8
d000162c:	ea4f 1525 	mov.w	r5, r5, asr #4
d0001630:	ea4f 1424 	mov.w	r4, r4, asr #4
d0001634:	707d      	strb	r5, [r7, #1]
d0001636:	f807 4f02 	strb.w	r4, [r7, #2]!
d000163a:	d1e5      	bne.n	d0001608 <stbi__resample_row_hv_2+0x28>
d000163c:	3602      	adds	r6, #2
d000163e:	f3c6 0487 	ubfx	r4, r6, #2, #8
d0001642:	eb00 0343 	add.w	r3, r0, r3, lsl #1
d0001646:	f803 4c01 	strb.w	r4, [r3, #-1]
d000164a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d000164e:	7809      	ldrb	r1, [r1, #0]
d0001650:	2303      	movs	r3, #3
d0001652:	7812      	ldrb	r2, [r2, #0]
d0001654:	fb13 2301 	smlabb	r3, r3, r1, r2
d0001658:	3302      	adds	r3, #2
d000165a:	f3c3 0387 	ubfx	r3, r3, #2, #8
d000165e:	7043      	strb	r3, [r0, #1]
d0001660:	7003      	strb	r3, [r0, #0]
d0001662:	4770      	bx	lr

d0001664 <stbi__resample_row_generic>:
d0001664:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0001668:	2b00      	cmp	r3, #0
d000166a:	b089      	sub	sp, #36	; 0x24
d000166c:	9f12      	ldr	r7, [sp, #72]	; 0x48
d000166e:	9007      	str	r0, [sp, #28]
d0001670:	dd5a      	ble.n	d0001728 <stbi__resample_row_generic+0xc4>
d0001672:	2f00      	cmp	r7, #0
d0001674:	dd58      	ble.n	d0001728 <stbi__resample_row_generic+0xc4>
d0001676:	4602      	mov	r2, r0
d0001678:	f027 0903 	bic.w	r9, r7, #3
d000167c:	eb01 0803 	add.w	r8, r1, r3
d0001680:	eb00 0a07 	add.w	sl, r0, r7
d0001684:	4613      	mov	r3, r2
d0001686:	f109 0001 	add.w	r0, r9, #1
d000168a:	f109 0402 	add.w	r4, r9, #2
d000168e:	f107 3bff 	add.w	fp, r7, #4294967295	; 0xffffffff
d0001692:	444b      	add	r3, r9
d0001694:	9002      	str	r0, [sp, #8]
d0001696:	9404      	str	r4, [sp, #16]
d0001698:	9303      	str	r3, [sp, #12]
d000169a:	1813      	adds	r3, r2, r0
d000169c:	4610      	mov	r0, r2
d000169e:	f8cd 9004 	str.w	r9, [sp, #4]
d00016a2:	9305      	str	r3, [sp, #20]
d00016a4:	1913      	adds	r3, r2, r4
d00016a6:	4654      	mov	r4, sl
d00016a8:	9306      	str	r3, [sp, #24]
d00016aa:	ea40 0301 	orr.w	r3, r0, r1
d00016ae:	460d      	mov	r5, r1
d00016b0:	3101      	adds	r1, #1
d00016b2:	eba4 0e0a 	sub.w	lr, r4, sl
d00016b6:	f013 0f03 	tst.w	r3, #3
d00016ba:	4603      	mov	r3, r0
d00016bc:	bf0c      	ite	eq
d00016be:	2601      	moveq	r6, #1
d00016c0:	2600      	movne	r6, #0
d00016c2:	4288      	cmp	r0, r1
d00016c4:	bf38      	it	cc
d00016c6:	42a5      	cmpcc	r5, r4
d00016c8:	bf2c      	ite	cs
d00016ca:	2201      	movcs	r2, #1
d00016cc:	2200      	movcc	r2, #0
d00016ce:	4216      	tst	r6, r2
d00016d0:	d02e      	beq.n	d0001730 <stbi__resample_row_generic+0xcc>
d00016d2:	f1bb 0f08 	cmp.w	fp, #8
d00016d6:	d92b      	bls.n	d0001730 <stbi__resample_row_generic+0xcc>
d00016d8:	f895 c000 	ldrb.w	ip, [r5]
d00016dc:	2200      	movs	r2, #0
d00016de:	9e01      	ldr	r6, [sp, #4]
d00016e0:	f36c 0207 	bfi	r2, ip, #0, #8
d00016e4:	1986      	adds	r6, r0, r6
d00016e6:	f36c 220f 	bfi	r2, ip, #8, #8
d00016ea:	f36c 4217 	bfi	r2, ip, #16, #8
d00016ee:	f36c 621f 	bfi	r2, ip, #24, #8
d00016f2:	f843 2b04 	str.w	r2, [r3], #4
d00016f6:	429e      	cmp	r6, r3
d00016f8:	d1fb      	bne.n	d00016f2 <stbi__resample_row_generic+0x8e>
d00016fa:	45b9      	cmp	r9, r7
d00016fc:	d010      	beq.n	d0001720 <stbi__resample_row_generic+0xbc>
d00016fe:	9a03      	ldr	r2, [sp, #12]
d0001700:	782b      	ldrb	r3, [r5, #0]
d0001702:	f802 300e 	strb.w	r3, [r2, lr]
d0001706:	9a02      	ldr	r2, [sp, #8]
d0001708:	4297      	cmp	r7, r2
d000170a:	dd09      	ble.n	d0001720 <stbi__resample_row_generic+0xbc>
d000170c:	9a05      	ldr	r2, [sp, #20]
d000170e:	f802 300e 	strb.w	r3, [r2, lr]
d0001712:	9b04      	ldr	r3, [sp, #16]
d0001714:	429f      	cmp	r7, r3
d0001716:	dd03      	ble.n	d0001720 <stbi__resample_row_generic+0xbc>
d0001718:	782b      	ldrb	r3, [r5, #0]
d000171a:	9a06      	ldr	r2, [sp, #24]
d000171c:	f802 300e 	strb.w	r3, [r2, lr]
d0001720:	4541      	cmp	r1, r8
d0001722:	4438      	add	r0, r7
d0001724:	443c      	add	r4, r7
d0001726:	d1c0      	bne.n	d00016aa <stbi__resample_row_generic+0x46>
d0001728:	9807      	ldr	r0, [sp, #28]
d000172a:	b009      	add	sp, #36	; 0x24
d000172c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0001730:	4603      	mov	r3, r0
d0001732:	782a      	ldrb	r2, [r5, #0]
d0001734:	f803 2b01 	strb.w	r2, [r3], #1
d0001738:	42a3      	cmp	r3, r4
d000173a:	d1fa      	bne.n	d0001732 <stbi__resample_row_generic+0xce>
d000173c:	e7f0      	b.n	d0001720 <stbi__resample_row_generic+0xbc>
d000173e:	bf00      	nop

d0001740 <stbi__YCbCr_to_RGB_row>:
d0001740:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0001744:	b083      	sub	sp, #12
d0001746:	9c0c      	ldr	r4, [sp, #48]	; 0x30
d0001748:	2c00      	cmp	r4, #0
d000174a:	dd4b      	ble.n	d00017e4 <stbi__YCbCr_to_RGB_row+0xa4>
d000174c:	1e4d      	subs	r5, r1, #1
d000174e:	1e56      	subs	r6, r2, #1
d0001750:	1e5f      	subs	r7, r3, #1
d0001752:	f8df b0a0 	ldr.w	fp, [pc, #160]	; d00017f4 <stbi__YCbCr_to_RGB_row+0xb4>
d0001756:	eb05 0e04 	add.w	lr, r5, r4
d000175a:	f8df a09c 	ldr.w	sl, [pc, #156]	; d00017f8 <stbi__YCbCr_to_RGB_row+0xb8>
d000175e:	f8df 909c 	ldr.w	r9, [pc, #156]	; d00017fc <stbi__YCbCr_to_RGB_row+0xbc>
d0001762:	f04f 08ff 	mov.w	r8, #255	; 0xff
d0001766:	9601      	str	r6, [sp, #4]
d0001768:	9a01      	ldr	r2, [sp, #4]
d000176a:	f815 3f01 	ldrb.w	r3, [r5, #1]!
d000176e:	f812 4f01 	ldrb.w	r4, [r2, #1]!
d0001772:	051b      	lsls	r3, r3, #20
d0001774:	f817 1f01 	ldrb.w	r1, [r7, #1]!
d0001778:	3c80      	subs	r4, #128	; 0x80
d000177a:	4e1c      	ldr	r6, [pc, #112]	; (d00017ec <stbi__YCbCr_to_RGB_row+0xac>)
d000177c:	f503 2300 	add.w	r3, r3, #524288	; 0x80000
d0001780:	3980      	subs	r1, #128	; 0x80
d0001782:	9201      	str	r2, [sp, #4]
d0001784:	fb0a f204 	mul.w	r2, sl, r4
d0001788:	fb06 3c01 	mla	ip, r6, r1, r3
d000178c:	4e18      	ldr	r6, [pc, #96]	; (d00017f0 <stbi__YCbCr_to_RGB_row+0xb0>)
d000178e:	fb0b 3101 	mla	r1, fp, r1, r3
d0001792:	ea02 0209 	and.w	r2, r2, r9
d0001796:	fb06 3304 	mla	r3, r6, r4, r3
d000179a:	4462      	add	r2, ip
d000179c:	150c      	asrs	r4, r1, #20
d000179e:	f1b1 5f80 	cmp.w	r1, #268435456	; 0x10000000
d00017a2:	ea4f 5323 	mov.w	r3, r3, asr #20
d00017a6:	ea4f 5222 	mov.w	r2, r2, asr #20
d00017aa:	b2e1      	uxtb	r1, r4
d00017ac:	d303      	bcc.n	d00017b6 <stbi__YCbCr_to_RGB_row+0x76>
d00017ae:	2c00      	cmp	r4, #0
d00017b0:	bfac      	ite	ge
d00017b2:	21ff      	movge	r1, #255	; 0xff
d00017b4:	2100      	movlt	r1, #0
d00017b6:	2aff      	cmp	r2, #255	; 0xff
d00017b8:	b2d4      	uxtb	r4, r2
d00017ba:	d903      	bls.n	d00017c4 <stbi__YCbCr_to_RGB_row+0x84>
d00017bc:	2a00      	cmp	r2, #0
d00017be:	bfac      	ite	ge
d00017c0:	24ff      	movge	r4, #255	; 0xff
d00017c2:	2400      	movlt	r4, #0
d00017c4:	2bff      	cmp	r3, #255	; 0xff
d00017c6:	b2da      	uxtb	r2, r3
d00017c8:	d903      	bls.n	d00017d2 <stbi__YCbCr_to_RGB_row+0x92>
d00017ca:	2b00      	cmp	r3, #0
d00017cc:	bfac      	ite	ge
d00017ce:	22ff      	movge	r2, #255	; 0xff
d00017d0:	2200      	movlt	r2, #0
d00017d2:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d00017d4:	45ae      	cmp	lr, r5
d00017d6:	f880 8003 	strb.w	r8, [r0, #3]
d00017da:	7001      	strb	r1, [r0, #0]
d00017dc:	7044      	strb	r4, [r0, #1]
d00017de:	7082      	strb	r2, [r0, #2]
d00017e0:	4418      	add	r0, r3
d00017e2:	d1c1      	bne.n	d0001768 <stbi__YCbCr_to_RGB_row+0x28>
d00017e4:	b003      	add	sp, #12
d00017e6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00017ea:	bf00      	nop
d00017ec:	fff49300 	.word	0xfff49300
d00017f0:	001c5a00 	.word	0x001c5a00
d00017f4:	00166f00 	.word	0x00166f00
d00017f8:	fffa7e00 	.word	0xfffa7e00
d00017fc:	ffff0000 	.word	0xffff0000

d0001800 <stbi__vertical_flip>:
d0001800:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0001804:	fb03 f901 	mul.w	r9, r3, r1
d0001808:	1053      	asrs	r3, r2, #1
d000180a:	f6ad 0d0c 	subw	sp, sp, #2060	; 0x80c
d000180e:	2b00      	cmp	r3, #0
d0001810:	9301      	str	r3, [sp, #4]
d0001812:	dd2d      	ble.n	d0001870 <stbi__vertical_flip+0x70>
d0001814:	f1b9 0f00 	cmp.w	r9, #0
d0001818:	d02a      	beq.n	d0001870 <stbi__vertical_flip+0x70>
d000181a:	3a01      	subs	r2, #1
d000181c:	4680      	mov	r8, r0
d000181e:	f04f 0a00 	mov.w	sl, #0
d0001822:	fb09 0702 	mla	r7, r9, r2, r0
d0001826:	4646      	mov	r6, r8
d0001828:	463d      	mov	r5, r7
d000182a:	46cb      	mov	fp, r9
d000182c:	f5bb 6f00 	cmp.w	fp, #2048	; 0x800
d0001830:	465c      	mov	r4, fp
d0001832:	4631      	mov	r1, r6
d0001834:	a802      	add	r0, sp, #8
d0001836:	bf28      	it	cs
d0001838:	f44f 6400 	movcs.w	r4, #2048	; 0x800
d000183c:	4622      	mov	r2, r4
d000183e:	f00a f9e3 	bl	d000bc08 <memcpy>
d0001842:	4629      	mov	r1, r5
d0001844:	4622      	mov	r2, r4
d0001846:	4630      	mov	r0, r6
d0001848:	f00a f9de 	bl	d000bc08 <memcpy>
d000184c:	4628      	mov	r0, r5
d000184e:	4622      	mov	r2, r4
d0001850:	a902      	add	r1, sp, #8
d0001852:	f00a f9d9 	bl	d000bc08 <memcpy>
d0001856:	ebbb 0b04 	subs.w	fp, fp, r4
d000185a:	4426      	add	r6, r4
d000185c:	4425      	add	r5, r4
d000185e:	d1e5      	bne.n	d000182c <stbi__vertical_flip+0x2c>
d0001860:	f10a 0a01 	add.w	sl, sl, #1
d0001864:	9b01      	ldr	r3, [sp, #4]
d0001866:	44c8      	add	r8, r9
d0001868:	eba7 0709 	sub.w	r7, r7, r9
d000186c:	459a      	cmp	sl, r3
d000186e:	d1da      	bne.n	d0001826 <stbi__vertical_flip+0x26>
d0001870:	f60d 0d0c 	addw	sp, sp, #2060	; 0x80c
d0001874:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}

d0001878 <stbi__resample_row_h_2>:
d0001878:	2b01      	cmp	r3, #1
d000187a:	d039      	beq.n	d00018f0 <stbi__resample_row_h_2+0x78>
d000187c:	780a      	ldrb	r2, [r1, #0]
d000187e:	2b02      	cmp	r3, #2
d0001880:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0001884:	7002      	strb	r2, [r0, #0]
d0001886:	f04f 0703 	mov.w	r7, #3
d000188a:	784c      	ldrb	r4, [r1, #1]
d000188c:	fb17 4202 	smlabb	r2, r7, r2, r4
d0001890:	f102 0202 	add.w	r2, r2, #2
d0001894:	ea4f 02a2 	mov.w	r2, r2, asr #2
d0001898:	7042      	strb	r2, [r0, #1]
d000189a:	dd2d      	ble.n	d00018f8 <stbi__resample_row_h_2+0x80>
d000189c:	f1a3 0c02 	sub.w	ip, r3, #2
d00018a0:	460d      	mov	r5, r1
d00018a2:	4606      	mov	r6, r0
d00018a4:	f04f 0e02 	mov.w	lr, #2
d00018a8:	448c      	add	ip, r1
d00018aa:	462c      	mov	r4, r5
d00018ac:	f815 2f01 	ldrb.w	r2, [r5, #1]!
d00018b0:	3602      	adds	r6, #2
d00018b2:	7824      	ldrb	r4, [r4, #0]
d00018b4:	fb17 e802 	smlabb	r8, r7, r2, lr
d00018b8:	45ac      	cmp	ip, r5
d00018ba:	4444      	add	r4, r8
d00018bc:	ea4f 04a4 	mov.w	r4, r4, asr #2
d00018c0:	7034      	strb	r4, [r6, #0]
d00018c2:	786a      	ldrb	r2, [r5, #1]
d00018c4:	4442      	add	r2, r8
d00018c6:	ea4f 02a2 	mov.w	r2, r2, asr #2
d00018ca:	7072      	strb	r2, [r6, #1]
d00018cc:	d1ed      	bne.n	d00018aa <stbi__resample_row_h_2+0x32>
d00018ce:	1e5c      	subs	r4, r3, #1
d00018d0:	0065      	lsls	r5, r4, #1
d00018d2:	1c6f      	adds	r7, r5, #1
d00018d4:	440b      	add	r3, r1
d00018d6:	5d0e      	ldrb	r6, [r1, r4]
d00018d8:	2203      	movs	r2, #3
d00018da:	f813 3c02 	ldrb.w	r3, [r3, #-2]
d00018de:	fb12 6303 	smlabb	r3, r2, r3, r6
d00018e2:	3302      	adds	r3, #2
d00018e4:	109b      	asrs	r3, r3, #2
d00018e6:	5543      	strb	r3, [r0, r5]
d00018e8:	5d0b      	ldrb	r3, [r1, r4]
d00018ea:	55c3      	strb	r3, [r0, r7]
d00018ec:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d00018f0:	780b      	ldrb	r3, [r1, #0]
d00018f2:	7043      	strb	r3, [r0, #1]
d00018f4:	7003      	strb	r3, [r0, #0]
d00018f6:	4770      	bx	lr
d00018f8:	2502      	movs	r5, #2
d00018fa:	1e5c      	subs	r4, r3, #1
d00018fc:	e7ea      	b.n	d00018d4 <stbi__resample_row_h_2+0x5c>
d00018fe:	bf00      	nop

d0001900 <stbi__build_huffman>:
d0001900:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0001904:	3904      	subs	r1, #4
d0001906:	f04f 0e01 	mov.w	lr, #1
d000190a:	2500      	movs	r5, #0
d000190c:	4606      	mov	r6, r0
d000190e:	f851 3f04 	ldr.w	r3, [r1, #4]!
d0001912:	2b00      	cmp	r3, #0
d0001914:	dd17      	ble.n	d0001946 <stbi__build_huffman+0x46>
d0001916:	fa5f f08e 	uxtb.w	r0, lr
d000191a:	1973      	adds	r3, r6, r5
d000191c:	2dff      	cmp	r5, #255	; 0xff
d000191e:	f883 0500 	strb.w	r0, [r3, #1280]	; 0x500
d0001922:	dc4c      	bgt.n	d00019be <stbi__build_huffman+0xbe>
d0001924:	f205 5201 	addw	r2, r5, #1281	; 0x501
d0001928:	f5c5 7c80 	rsb	ip, r5, #256	; 0x100
d000192c:	1c6f      	adds	r7, r5, #1
d000192e:	2300      	movs	r3, #0
d0001930:	4432      	add	r2, r6
d0001932:	e003      	b.n	d000193c <stbi__build_huffman+0x3c>
d0001934:	4563      	cmp	r3, ip
d0001936:	f802 0b01 	strb.w	r0, [r2], #1
d000193a:	d040      	beq.n	d00019be <stbi__build_huffman+0xbe>
d000193c:	18fd      	adds	r5, r7, r3
d000193e:	680c      	ldr	r4, [r1, #0]
d0001940:	3301      	adds	r3, #1
d0001942:	429c      	cmp	r4, r3
d0001944:	dcf6      	bgt.n	d0001934 <stbi__build_huffman+0x34>
d0001946:	f10e 0e01 	add.w	lr, lr, #1
d000194a:	f1be 0f11 	cmp.w	lr, #17
d000194e:	d1de      	bne.n	d000190e <stbi__build_huffman+0xe>
d0001950:	2100      	movs	r1, #0
d0001952:	4435      	add	r5, r6
d0001954:	f206 674c 	addw	r7, r6, #1612	; 0x64c
d0001958:	2201      	movs	r2, #1
d000195a:	460b      	mov	r3, r1
d000195c:	460c      	mov	r4, r1
d000195e:	f885 1500 	strb.w	r1, [r5, #1280]	; 0x500
d0001962:	e00a      	b.n	d000197a <stbi__build_huffman+0x7a>
d0001964:	f1c2 0110 	rsb	r1, r2, #16
d0001968:	3201      	adds	r2, #1
d000196a:	fa03 f101 	lsl.w	r1, r3, r1
d000196e:	2a11      	cmp	r2, #17
d0001970:	ea4f 0343 	mov.w	r3, r3, lsl #1
d0001974:	f847 1c48 	str.w	r1, [r7, #-72]
d0001978:	d027      	beq.n	d00019ca <stbi__build_huffman+0xca>
d000197a:	1ae0      	subs	r0, r4, r3
d000197c:	1931      	adds	r1, r6, r4
d000197e:	f847 0f04 	str.w	r0, [r7, #4]!
d0001982:	f891 1500 	ldrb.w	r1, [r1, #1280]	; 0x500
d0001986:	4291      	cmp	r1, r2
d0001988:	d1ec      	bne.n	d0001964 <stbi__build_huffman+0x64>
d000198a:	f504 7580 	add.w	r5, r4, #256	; 0x100
d000198e:	f204 5101 	addw	r1, r4, #1281	; 0x501
d0001992:	eb06 0545 	add.w	r5, r6, r5, lsl #1
d0001996:	4431      	add	r1, r6
d0001998:	469e      	mov	lr, r3
d000199a:	3301      	adds	r3, #1
d000199c:	f103 3cff 	add.w	ip, r3, #4294967295	; 0xffffffff
d00019a0:	18c4      	adds	r4, r0, r3
d00019a2:	f825 cb02 	strh.w	ip, [r5], #2
d00019a6:	f811 cb01 	ldrb.w	ip, [r1], #1
d00019aa:	4594      	cmp	ip, r2
d00019ac:	d0f4      	beq.n	d0001998 <stbi__build_huffman+0x98>
d00019ae:	fa3e f102 	lsrs.w	r1, lr, r2
d00019b2:	d0d7      	beq.n	d0001964 <stbi__build_huffman+0x64>
d00019b4:	4b1a      	ldr	r3, [pc, #104]	; (d0001a20 <stbi__build_huffman+0x120>)
d00019b6:	2000      	movs	r0, #0
d00019b8:	4a1a      	ldr	r2, [pc, #104]	; (d0001a24 <stbi__build_huffman+0x124>)
d00019ba:	601a      	str	r2, [r3, #0]
d00019bc:	e003      	b.n	d00019c6 <stbi__build_huffman+0xc6>
d00019be:	4b18      	ldr	r3, [pc, #96]	; (d0001a20 <stbi__build_huffman+0x120>)
d00019c0:	2000      	movs	r0, #0
d00019c2:	4a19      	ldr	r2, [pc, #100]	; (d0001a28 <stbi__build_huffman+0x128>)
d00019c4:	601a      	str	r2, [r3, #0]
d00019c6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d00019ca:	f04f 33ff 	mov.w	r3, #4294967295	; 0xffffffff
d00019ce:	f44f 7200 	mov.w	r2, #512	; 0x200
d00019d2:	21ff      	movs	r1, #255	; 0xff
d00019d4:	4630      	mov	r0, r6
d00019d6:	f8c6 3648 	str.w	r3, [r6, #1608]	; 0x648
d00019da:	f00a f923 	bl	d000bc24 <memset>
d00019de:	b1e4      	cbz	r4, d0001a1a <stbi__build_huffman+0x11a>
d00019e0:	f506 69a0 	add.w	r9, r6, #1280	; 0x500
d00019e4:	4f11      	ldr	r7, [pc, #68]	; (d0001a2c <stbi__build_huffman+0x12c>)
d00019e6:	f04f 0801 	mov.w	r8, #1
d00019ea:	444c      	add	r4, r9
d00019ec:	464d      	mov	r5, r9
d00019ee:	1bbf      	subs	r7, r7, r6
d00019f0:	e002      	b.n	d00019f8 <stbi__build_huffman+0xf8>
d00019f2:	3501      	adds	r5, #1
d00019f4:	42ac      	cmp	r4, r5
d00019f6:	d010      	beq.n	d0001a1a <stbi__build_huffman+0x11a>
d00019f8:	782b      	ldrb	r3, [r5, #0]
d00019fa:	2b09      	cmp	r3, #9
d00019fc:	dcf9      	bgt.n	d00019f2 <stbi__build_huffman+0xf2>
d00019fe:	f1c3 0309 	rsb	r3, r3, #9
d0001a02:	f837 0015 	ldrh.w	r0, [r7, r5, lsl #1]
d0001a06:	eba5 0109 	sub.w	r1, r5, r9
d0001a0a:	4098      	lsls	r0, r3
d0001a0c:	fa08 f203 	lsl.w	r2, r8, r3
d0001a10:	b2c9      	uxtb	r1, r1
d0001a12:	4430      	add	r0, r6
d0001a14:	f00a f906 	bl	d000bc24 <memset>
d0001a18:	e7eb      	b.n	d00019f2 <stbi__build_huffman+0xf2>
d0001a1a:	2001      	movs	r0, #1
d0001a1c:	e7d3      	b.n	d00019c6 <stbi__build_huffman+0xc6>
d0001a1e:	bf00      	nop
d0001a20:	d000dec8 	.word	0xd000dec8
d0001a24:	d000d274 	.word	0xd000d274
d0001a28:	d000d264 	.word	0xd000d264
d0001a2c:	fffff800 	.word	0xfffff800

d0001a30 <stbi__free_jpeg_components.constprop.0>:
d0001a30:	2900      	cmp	r1, #0
d0001a32:	dd1f      	ble.n	d0001a74 <stbi__free_jpeg_components.constprop.0+0x44>
d0001a34:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
d0001a38:	f244 63c8 	movw	r3, #18120	; 0x46c8
d0001a3c:	b570      	push	{r4, r5, r6, lr}
d0001a3e:	eb00 05c1 	add.w	r5, r0, r1, lsl #3
d0001a42:	2600      	movs	r6, #0
d0001a44:	18c4      	adds	r4, r0, r3
d0001a46:	441d      	add	r5, r3
d0001a48:	6860      	ldr	r0, [r4, #4]
d0001a4a:	b118      	cbz	r0, d0001a54 <stbi__free_jpeg_components.constprop.0+0x24>
d0001a4c:	f00a f8c6 	bl	d000bbdc <free>
d0001a50:	6066      	str	r6, [r4, #4]
d0001a52:	6026      	str	r6, [r4, #0]
d0001a54:	68a0      	ldr	r0, [r4, #8]
d0001a56:	b118      	cbz	r0, d0001a60 <stbi__free_jpeg_components.constprop.0+0x30>
d0001a58:	f00a f8c0 	bl	d000bbdc <free>
d0001a5c:	60a6      	str	r6, [r4, #8]
d0001a5e:	6126      	str	r6, [r4, #16]
d0001a60:	68e0      	ldr	r0, [r4, #12]
d0001a62:	b110      	cbz	r0, d0001a6a <stbi__free_jpeg_components.constprop.0+0x3a>
d0001a64:	f00a f8ba 	bl	d000bbdc <free>
d0001a68:	60e6      	str	r6, [r4, #12]
d0001a6a:	3448      	adds	r4, #72	; 0x48
d0001a6c:	42ac      	cmp	r4, r5
d0001a6e:	d1eb      	bne.n	d0001a48 <stbi__free_jpeg_components.constprop.0+0x18>
d0001a70:	2000      	movs	r0, #0
d0001a72:	bd70      	pop	{r4, r5, r6, pc}
d0001a74:	2000      	movs	r0, #0
d0001a76:	4770      	bx	lr

d0001a78 <stbi__get16be>:
d0001a78:	b570      	push	{r4, r5, r6, lr}
d0001a7a:	f8d0 30ac 	ldr.w	r3, [r0, #172]	; 0xac
d0001a7e:	4604      	mov	r4, r0
d0001a80:	f8d0 60b0 	ldr.w	r6, [r0, #176]	; 0xb0
d0001a84:	42b3      	cmp	r3, r6
d0001a86:	d303      	bcc.n	d0001a90 <stbi__get16be+0x18>
d0001a88:	6a05      	ldr	r5, [r0, #32]
d0001a8a:	bb85      	cbnz	r5, d0001aee <stbi__get16be+0x76>
d0001a8c:	4628      	mov	r0, r5
d0001a8e:	bd70      	pop	{r4, r5, r6, pc}
d0001a90:	1c5a      	adds	r2, r3, #1
d0001a92:	f8c0 20ac 	str.w	r2, [r0, #172]	; 0xac
d0001a96:	781d      	ldrb	r5, [r3, #0]
d0001a98:	022d      	lsls	r5, r5, #8
d0001a9a:	42b2      	cmp	r2, r6
d0001a9c:	d206      	bcs.n	d0001aac <stbi__get16be+0x34>
d0001a9e:	1c53      	adds	r3, r2, #1
d0001aa0:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0001aa4:	7813      	ldrb	r3, [r2, #0]
d0001aa6:	441d      	add	r5, r3
d0001aa8:	4628      	mov	r0, r5
d0001aaa:	bd70      	pop	{r4, r5, r6, pc}
d0001aac:	6a23      	ldr	r3, [r4, #32]
d0001aae:	2b00      	cmp	r3, #0
d0001ab0:	d0ec      	beq.n	d0001a8c <stbi__get16be+0x14>
d0001ab2:	f104 0628 	add.w	r6, r4, #40	; 0x28
d0001ab6:	6923      	ldr	r3, [r4, #16]
d0001ab8:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0001aba:	4631      	mov	r1, r6
d0001abc:	69e0      	ldr	r0, [r4, #28]
d0001abe:	4798      	blx	r3
d0001ac0:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0001ac4:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0001ac8:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0001acc:	1a52      	subs	r2, r2, r1
d0001ace:	4413      	add	r3, r2
d0001ad0:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0001ad4:	bb48      	cbnz	r0, d0001b2a <stbi__get16be+0xb2>
d0001ad6:	f104 0629 	add.w	r6, r4, #41	; 0x29
d0001ada:	6220      	str	r0, [r4, #32]
d0001adc:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0001ae0:	4633      	mov	r3, r6
d0001ae2:	4628      	mov	r0, r5
d0001ae4:	f8c4 60b0 	str.w	r6, [r4, #176]	; 0xb0
d0001ae8:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0001aec:	bd70      	pop	{r4, r5, r6, pc}
d0001aee:	f100 0628 	add.w	r6, r0, #40	; 0x28
d0001af2:	6903      	ldr	r3, [r0, #16]
d0001af4:	6a42      	ldr	r2, [r0, #36]	; 0x24
d0001af6:	4631      	mov	r1, r6
d0001af8:	69c0      	ldr	r0, [r0, #28]
d0001afa:	4798      	blx	r3
d0001afc:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0001b00:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0001b04:	4605      	mov	r5, r0
d0001b06:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0001b0a:	1a52      	subs	r2, r2, r1
d0001b0c:	4413      	add	r3, r2
d0001b0e:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0001b12:	b988      	cbnz	r0, d0001b38 <stbi__get16be+0xc0>
d0001b14:	f104 0629 	add.w	r6, r4, #41	; 0x29
d0001b18:	6220      	str	r0, [r4, #32]
d0001b1a:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0001b1e:	4632      	mov	r2, r6
d0001b20:	f8c4 60b0 	str.w	r6, [r4, #176]	; 0xb0
d0001b24:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0001b28:	e7b7      	b.n	d0001a9a <stbi__get16be+0x22>
d0001b2a:	f894 2028 	ldrb.w	r2, [r4, #40]	; 0x28
d0001b2e:	4406      	add	r6, r0
d0001b30:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0001b34:	4415      	add	r5, r2
d0001b36:	e7d4      	b.n	d0001ae2 <stbi__get16be+0x6a>
d0001b38:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0001b3c:	4406      	add	r6, r0
d0001b3e:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0001b42:	021d      	lsls	r5, r3, #8
d0001b44:	e7ec      	b.n	d0001b20 <stbi__get16be+0xa8>
d0001b46:	bf00      	nop

d0001b48 <stbi__get_marker.isra.0>:
d0001b48:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0001b4c:	780c      	ldrb	r4, [r1, #0]
d0001b4e:	2cff      	cmp	r4, #255	; 0xff
d0001b50:	d004      	beq.n	d0001b5c <stbi__get_marker.isra.0+0x14>
d0001b52:	23ff      	movs	r3, #255	; 0xff
d0001b54:	700b      	strb	r3, [r1, #0]
d0001b56:	4620      	mov	r0, r4
d0001b58:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0001b5c:	6805      	ldr	r5, [r0, #0]
d0001b5e:	4606      	mov	r6, r0
d0001b60:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0001b64:	f8d5 20b0 	ldr.w	r2, [r5, #176]	; 0xb0
d0001b68:	4293      	cmp	r3, r2
d0001b6a:	d31f      	bcc.n	d0001bac <stbi__get_marker.isra.0+0x64>
d0001b6c:	6a2b      	ldr	r3, [r5, #32]
d0001b6e:	2b00      	cmp	r3, #0
d0001b70:	d0f1      	beq.n	d0001b56 <stbi__get_marker.isra.0+0xe>
d0001b72:	f105 0828 	add.w	r8, r5, #40	; 0x28
d0001b76:	692b      	ldr	r3, [r5, #16]
d0001b78:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0001b7a:	4641      	mov	r1, r8
d0001b7c:	69e8      	ldr	r0, [r5, #28]
d0001b7e:	4798      	blx	r3
d0001b80:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0001b84:	f8d5 70b4 	ldr.w	r7, [r5, #180]	; 0xb4
d0001b88:	f8d5 30a8 	ldr.w	r3, [r5, #168]	; 0xa8
d0001b8c:	1bd2      	subs	r2, r2, r7
d0001b8e:	4413      	add	r3, r2
d0001b90:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d0001b94:	2800      	cmp	r0, #0
d0001b96:	d147      	bne.n	d0001c28 <stbi__get_marker.isra.0+0xe0>
d0001b98:	f105 0329 	add.w	r3, r5, #41	; 0x29
d0001b9c:	6228      	str	r0, [r5, #32]
d0001b9e:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0001ba2:	f8c5 30b0 	str.w	r3, [r5, #176]	; 0xb0
d0001ba6:	f8c5 30ac 	str.w	r3, [r5, #172]	; 0xac
d0001baa:	e7d4      	b.n	d0001b56 <stbi__get_marker.isra.0+0xe>
d0001bac:	1c5a      	adds	r2, r3, #1
d0001bae:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d0001bb2:	781b      	ldrb	r3, [r3, #0]
d0001bb4:	2bff      	cmp	r3, #255	; 0xff
d0001bb6:	d1ce      	bne.n	d0001b56 <stbi__get_marker.isra.0+0xe>
d0001bb8:	6835      	ldr	r5, [r6, #0]
d0001bba:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0001bbe:	f8d5 20b0 	ldr.w	r2, [r5, #176]	; 0xb0
d0001bc2:	4293      	cmp	r3, r2
d0001bc4:	d322      	bcc.n	d0001c0c <stbi__get_marker.isra.0+0xc4>
d0001bc6:	6a2c      	ldr	r4, [r5, #32]
d0001bc8:	2c00      	cmp	r4, #0
d0001bca:	d0c4      	beq.n	d0001b56 <stbi__get_marker.isra.0+0xe>
d0001bcc:	f105 0428 	add.w	r4, r5, #40	; 0x28
d0001bd0:	692b      	ldr	r3, [r5, #16]
d0001bd2:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0001bd4:	f105 0729 	add.w	r7, r5, #41	; 0x29
d0001bd8:	4621      	mov	r1, r4
d0001bda:	69e8      	ldr	r0, [r5, #28]
d0001bdc:	4798      	blx	r3
d0001bde:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0001be2:	f8d5 20b4 	ldr.w	r2, [r5, #180]	; 0xb4
d0001be6:	1821      	adds	r1, r4, r0
d0001be8:	1a9a      	subs	r2, r3, r2
d0001bea:	f8d5 30a8 	ldr.w	r3, [r5, #168]	; 0xa8
d0001bee:	4413      	add	r3, r2
d0001bf0:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d0001bf4:	b988      	cbnz	r0, d0001c1a <stbi__get_marker.isra.0+0xd2>
d0001bf6:	4604      	mov	r4, r0
d0001bf8:	6228      	str	r0, [r5, #32]
d0001bfa:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0001bfe:	f8c5 70b0 	str.w	r7, [r5, #176]	; 0xb0
d0001c02:	4620      	mov	r0, r4
d0001c04:	f8c5 70ac 	str.w	r7, [r5, #172]	; 0xac
d0001c08:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0001c0c:	1c5a      	adds	r2, r3, #1
d0001c0e:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d0001c12:	781c      	ldrb	r4, [r3, #0]
d0001c14:	2cff      	cmp	r4, #255	; 0xff
d0001c16:	d0cf      	beq.n	d0001bb8 <stbi__get_marker.isra.0+0x70>
d0001c18:	e79d      	b.n	d0001b56 <stbi__get_marker.isra.0+0xe>
d0001c1a:	f895 4028 	ldrb.w	r4, [r5, #40]	; 0x28
d0001c1e:	f8c5 10b0 	str.w	r1, [r5, #176]	; 0xb0
d0001c22:	f8c5 70ac 	str.w	r7, [r5, #172]	; 0xac
d0001c26:	e7f5      	b.n	d0001c14 <stbi__get_marker.isra.0+0xcc>
d0001c28:	4440      	add	r0, r8
d0001c2a:	f105 0229 	add.w	r2, r5, #41	; 0x29
d0001c2e:	f895 3028 	ldrb.w	r3, [r5, #40]	; 0x28
d0001c32:	f8c5 00b0 	str.w	r0, [r5, #176]	; 0xb0
d0001c36:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d0001c3a:	e7bb      	b.n	d0001bb4 <stbi__get_marker.isra.0+0x6c>

d0001c3c <stbi__grow_buffer_unsafe>:
d0001c3c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0001c40:	f244 77c8 	movw	r7, #18376	; 0x47c8
d0001c44:	f244 76c0 	movw	r6, #18368	; 0x47c0
d0001c48:	4605      	mov	r5, r0
d0001c4a:	4407      	add	r7, r0
d0001c4c:	4406      	add	r6, r0
d0001c4e:	e00f      	b.n	d0001c70 <stbi__grow_buffer_unsafe+0x34>
d0001c50:	2400      	movs	r4, #0
d0001c52:	6833      	ldr	r3, [r6, #0]
d0001c54:	f244 71bc 	movw	r1, #18364	; 0x47bc
d0001c58:	f1c3 0018 	rsb	r0, r3, #24
d0001c5c:	586a      	ldr	r2, [r5, r1]
d0001c5e:	3308      	adds	r3, #8
d0001c60:	4084      	lsls	r4, r0
d0001c62:	2b18      	cmp	r3, #24
d0001c64:	ea44 0402 	orr.w	r4, r4, r2
d0001c68:	506c      	str	r4, [r5, r1]
d0001c6a:	6033      	str	r3, [r6, #0]
d0001c6c:	f300 80a3 	bgt.w	d0001db6 <stbi__grow_buffer_unsafe+0x17a>
d0001c70:	683b      	ldr	r3, [r7, #0]
d0001c72:	2b00      	cmp	r3, #0
d0001c74:	d1ec      	bne.n	d0001c50 <stbi__grow_buffer_unsafe+0x14>
d0001c76:	f8d5 8000 	ldr.w	r8, [r5]
d0001c7a:	f8d8 30ac 	ldr.w	r3, [r8, #172]	; 0xac
d0001c7e:	f8d8 20b0 	ldr.w	r2, [r8, #176]	; 0xb0
d0001c82:	4293      	cmp	r3, r2
d0001c84:	d325      	bcc.n	d0001cd2 <stbi__grow_buffer_unsafe+0x96>
d0001c86:	f8d8 4020 	ldr.w	r4, [r8, #32]
d0001c8a:	2c00      	cmp	r4, #0
d0001c8c:	d0e1      	beq.n	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001c8e:	f108 0928 	add.w	r9, r8, #40	; 0x28
d0001c92:	f8d8 3010 	ldr.w	r3, [r8, #16]
d0001c96:	f8d8 2024 	ldr.w	r2, [r8, #36]	; 0x24
d0001c9a:	4649      	mov	r1, r9
d0001c9c:	f8d8 001c 	ldr.w	r0, [r8, #28]
d0001ca0:	4798      	blx	r3
d0001ca2:	f8d8 20ac 	ldr.w	r2, [r8, #172]	; 0xac
d0001ca6:	f8d8 10b4 	ldr.w	r1, [r8, #180]	; 0xb4
d0001caa:	f8d8 30a8 	ldr.w	r3, [r8, #168]	; 0xa8
d0001cae:	1a52      	subs	r2, r2, r1
d0001cb0:	4413      	add	r3, r2
d0001cb2:	f8c8 30a8 	str.w	r3, [r8, #168]	; 0xa8
d0001cb6:	2800      	cmp	r0, #0
d0001cb8:	d17f      	bne.n	d0001dba <stbi__grow_buffer_unsafe+0x17e>
d0001cba:	f108 0329 	add.w	r3, r8, #41	; 0x29
d0001cbe:	4604      	mov	r4, r0
d0001cc0:	f8c8 0020 	str.w	r0, [r8, #32]
d0001cc4:	f888 0028 	strb.w	r0, [r8, #40]	; 0x28
d0001cc8:	f8c8 30b0 	str.w	r3, [r8, #176]	; 0xb0
d0001ccc:	f8c8 30ac 	str.w	r3, [r8, #172]	; 0xac
d0001cd0:	e7bf      	b.n	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001cd2:	1c5a      	adds	r2, r3, #1
d0001cd4:	f8c8 20ac 	str.w	r2, [r8, #172]	; 0xac
d0001cd8:	781c      	ldrb	r4, [r3, #0]
d0001cda:	2cff      	cmp	r4, #255	; 0xff
d0001cdc:	d1b9      	bne.n	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001cde:	f8d5 8000 	ldr.w	r8, [r5]
d0001ce2:	f8d8 30ac 	ldr.w	r3, [r8, #172]	; 0xac
d0001ce6:	f8d8 20b0 	ldr.w	r2, [r8, #176]	; 0xb0
d0001cea:	4293      	cmp	r3, r2
d0001cec:	d324      	bcc.n	d0001d38 <stbi__grow_buffer_unsafe+0xfc>
d0001cee:	f8d8 3020 	ldr.w	r3, [r8, #32]
d0001cf2:	2b00      	cmp	r3, #0
d0001cf4:	d0ad      	beq.n	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001cf6:	f108 0928 	add.w	r9, r8, #40	; 0x28
d0001cfa:	f8d8 3010 	ldr.w	r3, [r8, #16]
d0001cfe:	f8d8 2024 	ldr.w	r2, [r8, #36]	; 0x24
d0001d02:	4649      	mov	r1, r9
d0001d04:	f8d8 001c 	ldr.w	r0, [r8, #28]
d0001d08:	4798      	blx	r3
d0001d0a:	f8d8 20ac 	ldr.w	r2, [r8, #172]	; 0xac
d0001d0e:	f8d8 10b4 	ldr.w	r1, [r8, #180]	; 0xb4
d0001d12:	f8d8 30a8 	ldr.w	r3, [r8, #168]	; 0xa8
d0001d16:	1a52      	subs	r2, r2, r1
d0001d18:	4413      	add	r3, r2
d0001d1a:	f8c8 30a8 	str.w	r3, [r8, #168]	; 0xa8
d0001d1e:	2800      	cmp	r0, #0
d0001d20:	d15c      	bne.n	d0001ddc <stbi__grow_buffer_unsafe+0x1a0>
d0001d22:	f108 0329 	add.w	r3, r8, #41	; 0x29
d0001d26:	f8c8 0020 	str.w	r0, [r8, #32]
d0001d2a:	f888 0028 	strb.w	r0, [r8, #40]	; 0x28
d0001d2e:	f8c8 30b0 	str.w	r3, [r8, #176]	; 0xb0
d0001d32:	f8c8 30ac 	str.w	r3, [r8, #172]	; 0xac
d0001d36:	e78c      	b.n	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001d38:	1c5a      	adds	r2, r3, #1
d0001d3a:	f8c8 20ac 	str.w	r2, [r8, #172]	; 0xac
d0001d3e:	781b      	ldrb	r3, [r3, #0]
d0001d40:	2bff      	cmp	r3, #255	; 0xff
d0001d42:	d12e      	bne.n	d0001da2 <stbi__grow_buffer_unsafe+0x166>
d0001d44:	f8d5 8000 	ldr.w	r8, [r5]
d0001d48:	f8d8 30ac 	ldr.w	r3, [r8, #172]	; 0xac
d0001d4c:	f8d8 20b0 	ldr.w	r2, [r8, #176]	; 0xb0
d0001d50:	4293      	cmp	r3, r2
d0001d52:	d3f1      	bcc.n	d0001d38 <stbi__grow_buffer_unsafe+0xfc>
d0001d54:	f8d8 3020 	ldr.w	r3, [r8, #32]
d0001d58:	2b00      	cmp	r3, #0
d0001d5a:	f43f af7a 	beq.w	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001d5e:	f108 0928 	add.w	r9, r8, #40	; 0x28
d0001d62:	f8d8 3010 	ldr.w	r3, [r8, #16]
d0001d66:	f8d8 2024 	ldr.w	r2, [r8, #36]	; 0x24
d0001d6a:	4649      	mov	r1, r9
d0001d6c:	f8d8 001c 	ldr.w	r0, [r8, #28]
d0001d70:	4798      	blx	r3
d0001d72:	f8d8 20b4 	ldr.w	r2, [r8, #180]	; 0xb4
d0001d76:	f8d8 30ac 	ldr.w	r3, [r8, #172]	; 0xac
d0001d7a:	f108 0c29 	add.w	ip, r8, #41	; 0x29
d0001d7e:	f8d8 10a8 	ldr.w	r1, [r8, #168]	; 0xa8
d0001d82:	1a9b      	subs	r3, r3, r2
d0001d84:	eb09 0200 	add.w	r2, r9, r0
d0001d88:	4419      	add	r1, r3
d0001d8a:	f8c8 10a8 	str.w	r1, [r8, #168]	; 0xa8
d0001d8e:	b9f0      	cbnz	r0, d0001dce <stbi__grow_buffer_unsafe+0x192>
d0001d90:	f8c8 0020 	str.w	r0, [r8, #32]
d0001d94:	f888 0028 	strb.w	r0, [r8, #40]	; 0x28
d0001d98:	f8c8 c0b0 	str.w	ip, [r8, #176]	; 0xb0
d0001d9c:	f8c8 c0ac 	str.w	ip, [r8, #172]	; 0xac
d0001da0:	e757      	b.n	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001da2:	2b00      	cmp	r3, #0
d0001da4:	f43f af55 	beq.w	d0001c52 <stbi__grow_buffer_unsafe+0x16>
d0001da8:	f244 70c4 	movw	r0, #18372	; 0x47c4
d0001dac:	f244 72c8 	movw	r2, #18376	; 0x47c8
d0001db0:	2101      	movs	r1, #1
d0001db2:	542b      	strb	r3, [r5, r0]
d0001db4:	50a9      	str	r1, [r5, r2]
d0001db6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d0001dba:	4448      	add	r0, r9
d0001dbc:	f108 0329 	add.w	r3, r8, #41	; 0x29
d0001dc0:	f898 4028 	ldrb.w	r4, [r8, #40]	; 0x28
d0001dc4:	f8c8 00b0 	str.w	r0, [r8, #176]	; 0xb0
d0001dc8:	f8c8 30ac 	str.w	r3, [r8, #172]	; 0xac
d0001dcc:	e785      	b.n	d0001cda <stbi__grow_buffer_unsafe+0x9e>
d0001dce:	f898 3028 	ldrb.w	r3, [r8, #40]	; 0x28
d0001dd2:	f8c8 20b0 	str.w	r2, [r8, #176]	; 0xb0
d0001dd6:	f8c8 c0ac 	str.w	ip, [r8, #172]	; 0xac
d0001dda:	e7b1      	b.n	d0001d40 <stbi__grow_buffer_unsafe+0x104>
d0001ddc:	4448      	add	r0, r9
d0001dde:	f108 0229 	add.w	r2, r8, #41	; 0x29
d0001de2:	f898 3028 	ldrb.w	r3, [r8, #40]	; 0x28
d0001de6:	f8c8 00b0 	str.w	r0, [r8, #176]	; 0xb0
d0001dea:	f8c8 20ac 	str.w	r2, [r8, #172]	; 0xac
d0001dee:	e7a7      	b.n	d0001d40 <stbi__grow_buffer_unsafe+0x104>

d0001df0 <stbi__jpeg_huff_decode>:
d0001df0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0001df2:	f244 76c0 	movw	r6, #18368	; 0x47c0
d0001df6:	4604      	mov	r4, r0
d0001df8:	460d      	mov	r5, r1
d0001dfa:	5982      	ldr	r2, [r0, r6]
d0001dfc:	2a0f      	cmp	r2, #15
d0001dfe:	dd39      	ble.n	d0001e74 <stbi__jpeg_huff_decode+0x84>
d0001e00:	f244 76bc 	movw	r6, #18364	; 0x47bc
d0001e04:	59a3      	ldr	r3, [r4, r6]
d0001e06:	0dd9      	lsrs	r1, r3, #23
d0001e08:	5c69      	ldrb	r1, [r5, r1]
d0001e0a:	29ff      	cmp	r1, #255	; 0xff
d0001e0c:	d00d      	beq.n	d0001e2a <stbi__jpeg_huff_decode+0x3a>
d0001e0e:	4429      	add	r1, r5
d0001e10:	f891 0500 	ldrb.w	r0, [r1, #1280]	; 0x500
d0001e14:	4290      	cmp	r0, r2
d0001e16:	dc68      	bgt.n	d0001eea <stbi__jpeg_huff_decode+0xfa>
d0001e18:	4083      	lsls	r3, r0
d0001e1a:	1a12      	subs	r2, r2, r0
d0001e1c:	f244 70c0 	movw	r0, #18368	; 0x47c0
d0001e20:	51a3      	str	r3, [r4, r6]
d0001e22:	5022      	str	r2, [r4, r0]
d0001e24:	f891 0400 	ldrb.w	r0, [r1, #1024]	; 0x400
d0001e28:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0001e2a:	f8d5 062c 	ldr.w	r0, [r5, #1580]	; 0x62c
d0001e2e:	0c19      	lsrs	r1, r3, #16
d0001e30:	ebb0 4f13 	cmp.w	r0, r3, lsr #16
d0001e34:	d84f      	bhi.n	d0001ed6 <stbi__jpeg_huff_decode+0xe6>
d0001e36:	f8d5 0630 	ldr.w	r0, [r5, #1584]	; 0x630
d0001e3a:	4281      	cmp	r1, r0
d0001e3c:	d34d      	bcc.n	d0001eda <stbi__jpeg_huff_decode+0xea>
d0001e3e:	f8d5 0634 	ldr.w	r0, [r5, #1588]	; 0x634
d0001e42:	4281      	cmp	r1, r0
d0001e44:	d34b      	bcc.n	d0001ede <stbi__jpeg_huff_decode+0xee>
d0001e46:	f8d5 0638 	ldr.w	r0, [r5, #1592]	; 0x638
d0001e4a:	4281      	cmp	r1, r0
d0001e4c:	d316      	bcc.n	d0001e7c <stbi__jpeg_huff_decode+0x8c>
d0001e4e:	f8d5 063c 	ldr.w	r0, [r5, #1596]	; 0x63c
d0001e52:	4281      	cmp	r1, r0
d0001e54:	d345      	bcc.n	d0001ee2 <stbi__jpeg_huff_decode+0xf2>
d0001e56:	f8d5 0640 	ldr.w	r0, [r5, #1600]	; 0x640
d0001e5a:	4281      	cmp	r1, r0
d0001e5c:	d343      	bcc.n	d0001ee6 <stbi__jpeg_huff_decode+0xf6>
d0001e5e:	f8d5 0644 	ldr.w	r0, [r5, #1604]	; 0x644
d0001e62:	4281      	cmp	r1, r0
d0001e64:	d344      	bcc.n	d0001ef0 <stbi__jpeg_huff_decode+0x100>
d0001e66:	3a10      	subs	r2, #16
d0001e68:	f244 73c0 	movw	r3, #18368	; 0x47c0
d0001e6c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0001e70:	50e2      	str	r2, [r4, r3]
d0001e72:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0001e74:	f7ff fee2 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0001e78:	59a2      	ldr	r2, [r4, r6]
d0001e7a:	e7c1      	b.n	d0001e00 <stbi__jpeg_huff_decode+0x10>
d0001e7c:	200d      	movs	r0, #13
d0001e7e:	4290      	cmp	r0, r2
d0001e80:	dc33      	bgt.n	d0001eea <stbi__jpeg_huff_decode+0xfa>
d0001e82:	f1c0 0120 	rsb	r1, r0, #32
d0001e86:	4e1f      	ldr	r6, [pc, #124]	; (d0001f04 <stbi__jpeg_huff_decode+0x114>)
d0001e88:	eb05 0c80 	add.w	ip, r5, r0, lsl #2
d0001e8c:	fa23 f101 	lsr.w	r1, r3, r1
d0001e90:	f856 7020 	ldr.w	r7, [r6, r0, lsl #2]
d0001e94:	f8dc c64c 	ldr.w	ip, [ip, #1612]	; 0x64c
d0001e98:	4039      	ands	r1, r7
d0001e9a:	4461      	add	r1, ip
d0001e9c:	29ff      	cmp	r1, #255	; 0xff
d0001e9e:	d824      	bhi.n	d0001eea <stbi__jpeg_huff_decode+0xfa>
d0001ea0:	186f      	adds	r7, r5, r1
d0001ea2:	f501 7180 	add.w	r1, r1, #256	; 0x100
d0001ea6:	f897 c500 	ldrb.w	ip, [r7, #1280]	; 0x500
d0001eaa:	f835 5011 	ldrh.w	r5, [r5, r1, lsl #1]
d0001eae:	f1cc 0120 	rsb	r1, ip, #32
d0001eb2:	f856 602c 	ldr.w	r6, [r6, ip, lsl #2]
d0001eb6:	fa23 f101 	lsr.w	r1, r3, r1
d0001eba:	4031      	ands	r1, r6
d0001ebc:	42a9      	cmp	r1, r5
d0001ebe:	d119      	bne.n	d0001ef4 <stbi__jpeg_huff_decode+0x104>
d0001ec0:	1a12      	subs	r2, r2, r0
d0001ec2:	4083      	lsls	r3, r0
d0001ec4:	f244 71bc 	movw	r1, #18364	; 0x47bc
d0001ec8:	f244 70c0 	movw	r0, #18368	; 0x47c0
d0001ecc:	5022      	str	r2, [r4, r0]
d0001ece:	5063      	str	r3, [r4, r1]
d0001ed0:	f897 0400 	ldrb.w	r0, [r7, #1024]	; 0x400
d0001ed4:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0001ed6:	200a      	movs	r0, #10
d0001ed8:	e7d1      	b.n	d0001e7e <stbi__jpeg_huff_decode+0x8e>
d0001eda:	200b      	movs	r0, #11
d0001edc:	e7cf      	b.n	d0001e7e <stbi__jpeg_huff_decode+0x8e>
d0001ede:	200c      	movs	r0, #12
d0001ee0:	e7cd      	b.n	d0001e7e <stbi__jpeg_huff_decode+0x8e>
d0001ee2:	200e      	movs	r0, #14
d0001ee4:	e7cb      	b.n	d0001e7e <stbi__jpeg_huff_decode+0x8e>
d0001ee6:	200f      	movs	r0, #15
d0001ee8:	e7c9      	b.n	d0001e7e <stbi__jpeg_huff_decode+0x8e>
d0001eea:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0001eee:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0001ef0:	2010      	movs	r0, #16
d0001ef2:	e7c4      	b.n	d0001e7e <stbi__jpeg_huff_decode+0x8e>
d0001ef4:	4b04      	ldr	r3, [pc, #16]	; (d0001f08 <stbi__jpeg_huff_decode+0x118>)
d0001ef6:	f640 015c 	movw	r1, #2140	; 0x85c
d0001efa:	4a04      	ldr	r2, [pc, #16]	; (d0001f0c <stbi__jpeg_huff_decode+0x11c>)
d0001efc:	4804      	ldr	r0, [pc, #16]	; (d0001f10 <stbi__jpeg_huff_decode+0x120>)
d0001efe:	f009 fe27 	bl	d000bb50 <__assert_func>
d0001f02:	bf00      	nop
d0001f04:	d000d4c4 	.word	0xd000d4c4
d0001f08:	d000d288 	.word	0xd000d288
d0001f0c:	d000d4a8 	.word	0xd000d4a8
d0001f10:	d000d2dc 	.word	0xd000d2dc

d0001f14 <stbi__jpeg_decode_block>:
d0001f14:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0001f18:	f244 74c0 	movw	r4, #18368	; 0x47c0
d0001f1c:	460f      	mov	r7, r1
d0001f1e:	4611      	mov	r1, r2
d0001f20:	4606      	mov	r6, r0
d0001f22:	5902      	ldr	r2, [r0, r4]
d0001f24:	4698      	mov	r8, r3
d0001f26:	ed2d 8b02 	vpush	{d8}
d0001f2a:	2a0f      	cmp	r2, #15
d0001f2c:	b083      	sub	sp, #12
d0001f2e:	9c0f      	ldr	r4, [sp, #60]	; 0x3c
d0001f30:	f340 80bf 	ble.w	d00020b2 <stbi__jpeg_decode_block+0x19e>
d0001f34:	4630      	mov	r0, r6
d0001f36:	f7ff ff5b 	bl	d0001df0 <stbi__jpeg_huff_decode>
d0001f3a:	280f      	cmp	r0, #15
d0001f3c:	4605      	mov	r5, r0
d0001f3e:	d908      	bls.n	d0001f52 <stbi__jpeg_decode_block+0x3e>
d0001f40:	4b9b      	ldr	r3, [pc, #620]	; (d00021b0 <stbi__jpeg_decode_block+0x29c>)
d0001f42:	2000      	movs	r0, #0
d0001f44:	4a9b      	ldr	r2, [pc, #620]	; (d00021b4 <stbi__jpeg_decode_block+0x2a0>)
d0001f46:	601a      	str	r2, [r3, #0]
d0001f48:	b003      	add	sp, #12
d0001f4a:	ecbd 8b02 	vpop	{d8}
d0001f4e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0001f52:	2280      	movs	r2, #128	; 0x80
d0001f54:	2100      	movs	r1, #0
d0001f56:	4638      	mov	r0, r7
d0001f58:	f009 fe64 	bl	d000bc24 <memset>
d0001f5c:	2d00      	cmp	r5, #0
d0001f5e:	f040 80b9 	bne.w	d00020d4 <stbi__jpeg_decode_block+0x1c0>
d0001f62:	eb04 04c4 	add.w	r4, r4, r4, lsl #3
d0001f66:	f244 63b4 	movw	r3, #18100	; 0x46b4
d0001f6a:	eb06 04c4 	add.w	r4, r6, r4, lsl #3
d0001f6e:	58e2      	ldr	r2, [r4, r3]
d0001f70:	9b10      	ldr	r3, [sp, #64]	; 0x40
d0001f72:	2a00      	cmp	r2, #0
d0001f74:	881b      	ldrh	r3, [r3, #0]
d0001f76:	f280 80a1 	bge.w	d00020bc <stbi__jpeg_decode_block+0x1a8>
d0001f7a:	b17b      	cbz	r3, d0001f9c <stbi__jpeg_decode_block+0x88>
d0001f7c:	488e      	ldr	r0, [pc, #568]	; (d00021b8 <stbi__jpeg_decode_block+0x2a4>)
d0001f7e:	fb90 f0f3 	sdiv	r0, r0, r3
d0001f82:	4282      	cmp	r2, r0
d0001f84:	bfb4      	ite	lt
d0001f86:	2000      	movlt	r0, #0
d0001f88:	2001      	movge	r0, #1
d0001f8a:	b938      	cbnz	r0, d0001f9c <stbi__jpeg_decode_block+0x88>
d0001f8c:	4b88      	ldr	r3, [pc, #544]	; (d00021b0 <stbi__jpeg_decode_block+0x29c>)
d0001f8e:	4a8b      	ldr	r2, [pc, #556]	; (d00021bc <stbi__jpeg_decode_block+0x2a8>)
d0001f90:	601a      	str	r2, [r3, #0]
d0001f92:	b003      	add	sp, #12
d0001f94:	ecbd 8b02 	vpop	{d8}
d0001f98:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0001f9c:	f244 7ac0 	movw	sl, #18368	; 0x47c0
d0001fa0:	f244 7bbc 	movw	fp, #18364	; 0x47bc
d0001fa4:	fb12 f303 	smulbb	r3, r2, r3
d0001fa8:	ee08 8a10 	vmov	s16, r8
d0001fac:	44b2      	add	sl, r6
d0001fae:	44b3      	add	fp, r6
d0001fb0:	803b      	strh	r3, [r7, #0]
d0001fb2:	2401      	movs	r4, #1
d0001fb4:	4653      	mov	r3, sl
d0001fb6:	f8df 9214 	ldr.w	r9, [pc, #532]	; d00021cc <stbi__jpeg_decode_block+0x2b8>
d0001fba:	46da      	mov	sl, fp
d0001fbc:	f8dd 8038 	ldr.w	r8, [sp, #56]	; 0x38
d0001fc0:	469b      	mov	fp, r3
d0001fc2:	e021      	b.n	d0002008 <stbi__jpeg_decode_block+0xf4>
d0001fc4:	f8da 3000 	ldr.w	r3, [sl]
d0001fc8:	0dd9      	lsrs	r1, r3, #23
d0001fca:	f938 5011 	ldrsh.w	r5, [r8, r1, lsl #1]
d0001fce:	b34d      	cbz	r5, d0002024 <stbi__jpeg_decode_block+0x110>
d0001fd0:	f005 000f 	and.w	r0, r5, #15
d0001fd4:	f8db 1000 	ldr.w	r1, [fp]
d0001fd8:	f3c5 1c03 	ubfx	ip, r5, #4, #4
d0001fdc:	4281      	cmp	r1, r0
d0001fde:	4464      	add	r4, ip
d0001fe0:	dbae      	blt.n	d0001f40 <stbi__jpeg_decode_block+0x2c>
d0001fe2:	f819 c004 	ldrb.w	ip, [r9, r4]
d0001fe6:	4083      	lsls	r3, r0
d0001fe8:	9a10      	ldr	r2, [sp, #64]	; 0x40
d0001fea:	1a09      	subs	r1, r1, r0
d0001fec:	122d      	asrs	r5, r5, #8
d0001fee:	3401      	adds	r4, #1
d0001ff0:	f832 001c 	ldrh.w	r0, [r2, ip, lsl #1]
d0001ff4:	f8ca 3000 	str.w	r3, [sl]
d0001ff8:	fb10 f505 	smulbb	r5, r0, r5
d0001ffc:	f8cb 1000 	str.w	r1, [fp]
d0002000:	f827 501c 	strh.w	r5, [r7, ip, lsl #1]
d0002004:	2c3f      	cmp	r4, #63	; 0x3f
d0002006:	dc1c      	bgt.n	d0002042 <stbi__jpeg_decode_block+0x12e>
d0002008:	f8db 3000 	ldr.w	r3, [fp]
d000200c:	2b0f      	cmp	r3, #15
d000200e:	dcd9      	bgt.n	d0001fc4 <stbi__jpeg_decode_block+0xb0>
d0002010:	4630      	mov	r0, r6
d0002012:	f7ff fe13 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0002016:	f8da 3000 	ldr.w	r3, [sl]
d000201a:	0dd9      	lsrs	r1, r3, #23
d000201c:	f938 5011 	ldrsh.w	r5, [r8, r1, lsl #1]
d0002020:	2d00      	cmp	r5, #0
d0002022:	d1d5      	bne.n	d0001fd0 <stbi__jpeg_decode_block+0xbc>
d0002024:	ee18 1a10 	vmov	r1, s16
d0002028:	4630      	mov	r0, r6
d000202a:	f7ff fee1 	bl	d0001df0 <stbi__jpeg_huff_decode>
d000202e:	2800      	cmp	r0, #0
d0002030:	db86      	blt.n	d0001f40 <stbi__jpeg_decode_block+0x2c>
d0002032:	f010 010f 	ands.w	r1, r0, #15
d0002036:	d10a      	bne.n	d000204e <stbi__jpeg_decode_block+0x13a>
d0002038:	28f0      	cmp	r0, #240	; 0xf0
d000203a:	d102      	bne.n	d0002042 <stbi__jpeg_decode_block+0x12e>
d000203c:	3410      	adds	r4, #16
d000203e:	2c3f      	cmp	r4, #63	; 0x3f
d0002040:	dde2      	ble.n	d0002008 <stbi__jpeg_decode_block+0xf4>
d0002042:	2001      	movs	r0, #1
d0002044:	b003      	add	sp, #12
d0002046:	ecbd 8b02 	vpop	{d8}
d000204a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000204e:	f8db 3000 	ldr.w	r3, [fp]
d0002052:	eb04 1020 	add.w	r0, r4, r0, asr #4
d0002056:	4299      	cmp	r1, r3
d0002058:	f100 0401 	add.w	r4, r0, #1
d000205c:	f819 2000 	ldrb.w	r2, [r9, r0]
d0002060:	dc79      	bgt.n	d0002156 <stbi__jpeg_decode_block+0x242>
d0002062:	f8da c000 	ldr.w	ip, [sl]
d0002066:	eba3 0e01 	sub.w	lr, r3, r1
d000206a:	4d55      	ldr	r5, [pc, #340]	; (d00021c0 <stbi__jpeg_decode_block+0x2ac>)
d000206c:	f1c1 0020 	rsb	r0, r1, #32
d0002070:	ea4f 73dc 	mov.w	r3, ip, lsr #31
d0002074:	f855 5021 	ldr.w	r5, [r5, r1, lsl #2]
d0002078:	fa6c f000 	ror.w	r0, ip, r0
d000207c:	9300      	str	r3, [sp, #0]
d000207e:	4b51      	ldr	r3, [pc, #324]	; (d00021c4 <stbi__jpeg_decode_block+0x2b0>)
d0002080:	ea00 0c05 	and.w	ip, r0, r5
d0002084:	ea20 0005 	bic.w	r0, r0, r5
d0002088:	f853 1021 	ldr.w	r1, [r3, r1, lsl #2]
d000208c:	9b00      	ldr	r3, [sp, #0]
d000208e:	f8ca 0000 	str.w	r0, [sl]
d0002092:	3b01      	subs	r3, #1
d0002094:	f8cb e000 	str.w	lr, [fp]
d0002098:	ea03 0501 	and.w	r5, r3, r1
d000209c:	4465      	add	r5, ip
d000209e:	b2ad      	uxth	r5, r5
d00020a0:	b213      	sxth	r3, r2
d00020a2:	9a10      	ldr	r2, [sp, #64]	; 0x40
d00020a4:	f832 c013 	ldrh.w	ip, [r2, r3, lsl #1]
d00020a8:	fb1c f505 	smulbb	r5, ip, r5
d00020ac:	f827 5013 	strh.w	r5, [r7, r3, lsl #1]
d00020b0:	e7a8      	b.n	d0002004 <stbi__jpeg_decode_block+0xf0>
d00020b2:	9100      	str	r1, [sp, #0]
d00020b4:	f7ff fdc2 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00020b8:	9900      	ldr	r1, [sp, #0]
d00020ba:	e73b      	b.n	d0001f34 <stbi__jpeg_decode_block+0x20>
d00020bc:	2b00      	cmp	r3, #0
d00020be:	f43f af6d 	beq.w	d0001f9c <stbi__jpeg_decode_block+0x88>
d00020c2:	f647 70ff 	movw	r0, #32767	; 0x7fff
d00020c6:	fbb0 f0f3 	udiv	r0, r0, r3
d00020ca:	4290      	cmp	r0, r2
d00020cc:	bfb4      	ite	lt
d00020ce:	2000      	movlt	r0, #0
d00020d0:	2001      	movge	r0, #1
d00020d2:	e75a      	b.n	d0001f8a <stbi__jpeg_decode_block+0x76>
d00020d4:	f244 79c0 	movw	r9, #18368	; 0x47c0
d00020d8:	f856 2009 	ldr.w	r2, [r6, r9]
d00020dc:	4295      	cmp	r5, r2
d00020de:	dc46      	bgt.n	d000216e <stbi__jpeg_decode_block+0x25a>
d00020e0:	f244 70bc 	movw	r0, #18364	; 0x47bc
d00020e4:	f1c5 0120 	rsb	r1, r5, #32
d00020e8:	f8df c0d4 	ldr.w	ip, [pc, #212]	; d00021c0 <stbi__jpeg_decode_block+0x2ac>
d00020ec:	1b52      	subs	r2, r2, r5
d00020ee:	5833      	ldr	r3, [r6, r0]
d00020f0:	eb04 0ac4 	add.w	sl, r4, r4, lsl #3
d00020f4:	f8df 90cc 	ldr.w	r9, [pc, #204]	; d00021c4 <stbi__jpeg_decode_block+0x2b0>
d00020f8:	f244 7ec0 	movw	lr, #18368	; 0x47c0
d00020fc:	fa63 f101 	ror.w	r1, r3, r1
d0002100:	0fdb      	lsrs	r3, r3, #31
d0002102:	f85c c025 	ldr.w	ip, [ip, r5, lsl #2]
d0002106:	eb06 0aca 	add.w	sl, r6, sl, lsl #3
d000210a:	f859 5025 	ldr.w	r5, [r9, r5, lsl #2]
d000210e:	3b01      	subs	r3, #1
d0002110:	f846 200e 	str.w	r2, [r6, lr]
d0002114:	ea21 020c 	bic.w	r2, r1, ip
d0002118:	402b      	ands	r3, r5
d000211a:	ea01 010c 	and.w	r1, r1, ip
d000211e:	f244 65b4 	movw	r5, #18100	; 0x46b4
d0002122:	5032      	str	r2, [r6, r0]
d0002124:	440b      	add	r3, r1
d0002126:	00e1      	lsls	r1, r4, #3
d0002128:	f85a 2005 	ldr.w	r2, [sl, r5]
d000212c:	43dd      	mvns	r5, r3
d000212e:	43d0      	mvns	r0, r2
d0002130:	0fed      	lsrs	r5, r5, #31
d0002132:	0fc0      	lsrs	r0, r0, #31
d0002134:	4285      	cmp	r5, r0
d0002136:	d123      	bne.n	d0002180 <stbi__jpeg_decode_block+0x26c>
d0002138:	2a00      	cmp	r2, #0
d000213a:	da30      	bge.n	d000219e <stbi__jpeg_decode_block+0x28a>
d000213c:	2b00      	cmp	r3, #0
d000213e:	da2e      	bge.n	d000219e <stbi__jpeg_decode_block+0x28a>
d0002140:	f1c3 4000 	rsb	r0, r3, #2147483648	; 0x80000000
d0002144:	4282      	cmp	r2, r0
d0002146:	bfb4      	ite	lt
d0002148:	2000      	movlt	r0, #0
d000214a:	2001      	movge	r0, #1
d000214c:	b9c0      	cbnz	r0, d0002180 <stbi__jpeg_decode_block+0x26c>
d000214e:	4b18      	ldr	r3, [pc, #96]	; (d00021b0 <stbi__jpeg_decode_block+0x29c>)
d0002150:	4a1d      	ldr	r2, [pc, #116]	; (d00021c8 <stbi__jpeg_decode_block+0x2b4>)
d0002152:	601a      	str	r2, [r3, #0]
d0002154:	e6f8      	b.n	d0001f48 <stbi__jpeg_decode_block+0x34>
d0002156:	4630      	mov	r0, r6
d0002158:	9101      	str	r1, [sp, #4]
d000215a:	9200      	str	r2, [sp, #0]
d000215c:	f7ff fd6e 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0002160:	f8db 3000 	ldr.w	r3, [fp]
d0002164:	9901      	ldr	r1, [sp, #4]
d0002166:	9a00      	ldr	r2, [sp, #0]
d0002168:	4299      	cmp	r1, r3
d000216a:	dc99      	bgt.n	d00020a0 <stbi__jpeg_decode_block+0x18c>
d000216c:	e779      	b.n	d0002062 <stbi__jpeg_decode_block+0x14e>
d000216e:	4630      	mov	r0, r6
d0002170:	f7ff fd64 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0002174:	f856 2009 	ldr.w	r2, [r6, r9]
d0002178:	4295      	cmp	r5, r2
d000217a:	f73f aef2 	bgt.w	d0001f62 <stbi__jpeg_decode_block+0x4e>
d000217e:	e7af      	b.n	d00020e0 <stbi__jpeg_decode_block+0x1cc>
d0002180:	441a      	add	r2, r3
d0002182:	4421      	add	r1, r4
d0002184:	9b10      	ldr	r3, [sp, #64]	; 0x40
d0002186:	f244 60b4 	movw	r0, #18100	; 0x46b4
d000218a:	eb06 01c1 	add.w	r1, r6, r1, lsl #3
d000218e:	881b      	ldrh	r3, [r3, #0]
d0002190:	500a      	str	r2, [r1, r0]
d0002192:	2b00      	cmp	r3, #0
d0002194:	f43f af02 	beq.w	d0001f9c <stbi__jpeg_decode_block+0x88>
d0002198:	2a00      	cmp	r2, #0
d000219a:	da92      	bge.n	d00020c2 <stbi__jpeg_decode_block+0x1ae>
d000219c:	e6ee      	b.n	d0001f7c <stbi__jpeg_decode_block+0x68>
d000219e:	f06f 4000 	mvn.w	r0, #2147483648	; 0x80000000
d00021a2:	1ac0      	subs	r0, r0, r3
d00021a4:	4282      	cmp	r2, r0
d00021a6:	bfcc      	ite	gt
d00021a8:	2000      	movgt	r0, #0
d00021aa:	2001      	movle	r0, #1
d00021ac:	e7ce      	b.n	d000214c <stbi__jpeg_decode_block+0x238>
d00021ae:	bf00      	nop
d00021b0:	d000dec8 	.word	0xd000dec8
d00021b4:	d000d2f0 	.word	0xd000d2f0
d00021b8:	ffff8000 	.word	0xffff8000
d00021bc:	d000d310 	.word	0xd000d310
d00021c0:	d000d4c4 	.word	0xd000d4c4
d00021c4:	d000d508 	.word	0xd000d508
d00021c8:	d000d304 	.word	0xd000d304
d00021cc:	d000d548 	.word	0xd000d548

d00021d0 <stbi__jpeg_decode_block_prog_dc>:
d00021d0:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d00021d4:	f244 75d4 	movw	r5, #18388	; 0x47d4
d00021d8:	5945      	ldr	r5, [r0, r5]
d00021da:	2d00      	cmp	r5, #0
d00021dc:	d149      	bne.n	d0002272 <stbi__jpeg_decode_block_prog_dc+0xa2>
d00021de:	461e      	mov	r6, r3
d00021e0:	f244 73c0 	movw	r3, #18368	; 0x47c0
d00021e4:	4604      	mov	r4, r0
d00021e6:	460f      	mov	r7, r1
d00021e8:	58c3      	ldr	r3, [r0, r3]
d00021ea:	4690      	mov	r8, r2
d00021ec:	2b0f      	cmp	r3, #15
d00021ee:	dd62      	ble.n	d00022b6 <stbi__jpeg_decode_block_prog_dc+0xe6>
d00021f0:	f244 73d8 	movw	r3, #18392	; 0x47d8
d00021f4:	58e5      	ldr	r5, [r4, r3]
d00021f6:	2d00      	cmp	r5, #0
d00021f8:	d141      	bne.n	d000227e <stbi__jpeg_decode_block_prog_dc+0xae>
d00021fa:	2280      	movs	r2, #128	; 0x80
d00021fc:	4629      	mov	r1, r5
d00021fe:	4638      	mov	r0, r7
d0002200:	f009 fd10 	bl	d000bc24 <memset>
d0002204:	4641      	mov	r1, r8
d0002206:	4620      	mov	r0, r4
d0002208:	f7ff fdf2 	bl	d0001df0 <stbi__jpeg_huff_decode>
d000220c:	280f      	cmp	r0, #15
d000220e:	4680      	mov	r8, r0
d0002210:	d82f      	bhi.n	d0002272 <stbi__jpeg_decode_block_prog_dc+0xa2>
d0002212:	2800      	cmp	r0, #0
d0002214:	d157      	bne.n	d00022c6 <stbi__jpeg_decode_block_prog_dc+0xf6>
d0002216:	eb06 02c6 	add.w	r2, r6, r6, lsl #3
d000221a:	f244 61b4 	movw	r1, #18100	; 0x46b4
d000221e:	00f3      	lsls	r3, r6, #3
d0002220:	eb04 02c2 	add.w	r2, r4, r2, lsl #3
d0002224:	5852      	ldr	r2, [r2, r1]
d0002226:	2a00      	cmp	r2, #0
d0002228:	f280 8098 	bge.w	d000235c <stbi__jpeg_decode_block_prog_dc+0x18c>
d000222c:	f244 70dc 	movw	r0, #18396	; 0x47dc
d0002230:	2501      	movs	r5, #1
d0002232:	4433      	add	r3, r6
d0002234:	f244 61b4 	movw	r1, #18100	; 0x46b4
d0002238:	5820      	ldr	r0, [r4, r0]
d000223a:	eb04 04c3 	add.w	r4, r4, r3, lsl #3
d000223e:	fa05 f300 	lsl.w	r3, r5, r0
d0002242:	5062      	str	r2, [r4, r1]
d0002244:	1959      	adds	r1, r3, r5
d0002246:	42a9      	cmp	r1, r5
d0002248:	d90d      	bls.n	d0002266 <stbi__jpeg_decode_block_prog_dc+0x96>
d000224a:	43d9      	mvns	r1, r3
d000224c:	0fc9      	lsrs	r1, r1, #31
d000224e:	ebb1 7fd2 	cmp.w	r1, r2, lsr #31
d0002252:	f000 8085 	beq.w	d0002360 <stbi__jpeg_decode_block_prog_dc+0x190>
d0002256:	f647 71ff 	movw	r1, #32767	; 0x7fff
d000225a:	4101      	asrs	r1, r0
d000225c:	4291      	cmp	r1, r2
d000225e:	bfb4      	ite	lt
d0002260:	2100      	movlt	r1, #0
d0002262:	2101      	movge	r1, #1
d0002264:	b129      	cbz	r1, d0002272 <stbi__jpeg_decode_block_prog_dc+0xa2>
d0002266:	fb12 f303 	smulbb	r3, r2, r3
d000226a:	2001      	movs	r0, #1
d000226c:	803b      	strh	r3, [r7, #0]
d000226e:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d0002272:	4b4b      	ldr	r3, [pc, #300]	; (d00023a0 <stbi__jpeg_decode_block_prog_dc+0x1d0>)
d0002274:	2000      	movs	r0, #0
d0002276:	4a4b      	ldr	r2, [pc, #300]	; (d00023a4 <stbi__jpeg_decode_block_prog_dc+0x1d4>)
d0002278:	601a      	str	r2, [r3, #0]
d000227a:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d000227e:	f244 75c0 	movw	r5, #18368	; 0x47c0
d0002282:	5963      	ldr	r3, [r4, r5]
d0002284:	2b00      	cmp	r3, #0
d0002286:	dd60      	ble.n	d000234a <stbi__jpeg_decode_block_prog_dc+0x17a>
d0002288:	f244 71bc 	movw	r1, #18364	; 0x47bc
d000228c:	3b01      	subs	r3, #1
d000228e:	f244 70c0 	movw	r0, #18368	; 0x47c0
d0002292:	5862      	ldr	r2, [r4, r1]
d0002294:	5023      	str	r3, [r4, r0]
d0002296:	2a00      	cmp	r2, #0
d0002298:	ea4f 0342 	mov.w	r3, r2, lsl #1
d000229c:	5063      	str	r3, [r4, r1]
d000229e:	da5a      	bge.n	d0002356 <stbi__jpeg_decode_block_prog_dc+0x186>
d00022a0:	f244 71dc 	movw	r1, #18396	; 0x47dc
d00022a4:	2301      	movs	r3, #1
d00022a6:	883a      	ldrh	r2, [r7, #0]
d00022a8:	5861      	ldr	r1, [r4, r1]
d00022aa:	4618      	mov	r0, r3
d00022ac:	408b      	lsls	r3, r1
d00022ae:	4413      	add	r3, r2
d00022b0:	803b      	strh	r3, [r7, #0]
d00022b2:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d00022b6:	f7ff fcc1 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00022ba:	f244 73d8 	movw	r3, #18392	; 0x47d8
d00022be:	58e5      	ldr	r5, [r4, r3]
d00022c0:	2d00      	cmp	r5, #0
d00022c2:	d1dc      	bne.n	d000227e <stbi__jpeg_decode_block_prog_dc+0xae>
d00022c4:	e799      	b.n	d00021fa <stbi__jpeg_decode_block_prog_dc+0x2a>
d00022c6:	f244 79c0 	movw	r9, #18368	; 0x47c0
d00022ca:	f854 1009 	ldr.w	r1, [r4, r9]
d00022ce:	4288      	cmp	r0, r1
d00022d0:	dc50      	bgt.n	d0002374 <stbi__jpeg_decode_block_prog_dc+0x1a4>
d00022d2:	f244 7cbc 	movw	ip, #18364	; 0x47bc
d00022d6:	f1c8 0e20 	rsb	lr, r8, #32
d00022da:	4d33      	ldr	r5, [pc, #204]	; (d00023a8 <stbi__jpeg_decode_block_prog_dc+0x1d8>)
d00022dc:	eba1 0108 	sub.w	r1, r1, r8
d00022e0:	f854 200c 	ldr.w	r2, [r4, ip]
d00022e4:	eb06 00c6 	add.w	r0, r6, r6, lsl #3
d00022e8:	f855 5028 	ldr.w	r5, [r5, r8, lsl #2]
d00022ec:	f244 79c0 	movw	r9, #18368	; 0x47c0
d00022f0:	fa62 f30e 	ror.w	r3, r2, lr
d00022f4:	0fd2      	lsrs	r2, r2, #31
d00022f6:	f8df e0bc 	ldr.w	lr, [pc, #188]	; d00023b4 <stbi__jpeg_decode_block_prog_dc+0x1e4>
d00022fa:	eb04 00c0 	add.w	r0, r4, r0, lsl #3
d00022fe:	3a01      	subs	r2, #1
d0002300:	f844 1009 	str.w	r1, [r4, r9]
d0002304:	f85e e028 	ldr.w	lr, [lr, r8, lsl #2]
d0002308:	ea23 0105 	bic.w	r1, r3, r5
d000230c:	402b      	ands	r3, r5
d000230e:	ea02 050e 	and.w	r5, r2, lr
d0002312:	f244 62b4 	movw	r2, #18100	; 0x46b4
d0002316:	f844 100c 	str.w	r1, [r4, ip]
d000231a:	441d      	add	r5, r3
d000231c:	5882      	ldr	r2, [r0, r2]
d000231e:	00f3      	lsls	r3, r6, #3
d0002320:	43e9      	mvns	r1, r5
d0002322:	43d0      	mvns	r0, r2
d0002324:	0fc9      	lsrs	r1, r1, #31
d0002326:	0fc0      	lsrs	r0, r0, #31
d0002328:	4288      	cmp	r0, r1
d000232a:	d117      	bne.n	d000235c <stbi__jpeg_decode_block_prog_dc+0x18c>
d000232c:	2a00      	cmp	r2, #0
d000232e:	da2f      	bge.n	d0002390 <stbi__jpeg_decode_block_prog_dc+0x1c0>
d0002330:	2d00      	cmp	r5, #0
d0002332:	da2d      	bge.n	d0002390 <stbi__jpeg_decode_block_prog_dc+0x1c0>
d0002334:	f1c5 4000 	rsb	r0, r5, #2147483648	; 0x80000000
d0002338:	4282      	cmp	r2, r0
d000233a:	bfb4      	ite	lt
d000233c:	2000      	movlt	r0, #0
d000233e:	2001      	movge	r0, #1
d0002340:	b960      	cbnz	r0, d000235c <stbi__jpeg_decode_block_prog_dc+0x18c>
d0002342:	4b17      	ldr	r3, [pc, #92]	; (d00023a0 <stbi__jpeg_decode_block_prog_dc+0x1d0>)
d0002344:	4a19      	ldr	r2, [pc, #100]	; (d00023ac <stbi__jpeg_decode_block_prog_dc+0x1dc>)
d0002346:	601a      	str	r2, [r3, #0]
d0002348:	e797      	b.n	d000227a <stbi__jpeg_decode_block_prog_dc+0xaa>
d000234a:	4620      	mov	r0, r4
d000234c:	f7ff fc76 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0002350:	5963      	ldr	r3, [r4, r5]
d0002352:	2b00      	cmp	r3, #0
d0002354:	dc98      	bgt.n	d0002288 <stbi__jpeg_decode_block_prog_dc+0xb8>
d0002356:	2001      	movs	r0, #1
d0002358:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d000235c:	442a      	add	r2, r5
d000235e:	e765      	b.n	d000222c <stbi__jpeg_decode_block_prog_dc+0x5c>
d0002360:	4913      	ldr	r1, [pc, #76]	; (d00023b0 <stbi__jpeg_decode_block_prog_dc+0x1e0>)
d0002362:	2b00      	cmp	r3, #0
d0002364:	fb91 f1f3 	sdiv	r1, r1, r3
d0002368:	db0d      	blt.n	d0002386 <stbi__jpeg_decode_block_prog_dc+0x1b6>
d000236a:	4291      	cmp	r1, r2
d000236c:	bfcc      	ite	gt
d000236e:	2100      	movgt	r1, #0
d0002370:	2101      	movle	r1, #1
d0002372:	e777      	b.n	d0002264 <stbi__jpeg_decode_block_prog_dc+0x94>
d0002374:	4620      	mov	r0, r4
d0002376:	f7ff fc61 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d000237a:	f854 1009 	ldr.w	r1, [r4, r9]
d000237e:	4588      	cmp	r8, r1
d0002380:	f73f af49 	bgt.w	d0002216 <stbi__jpeg_decode_block_prog_dc+0x46>
d0002384:	e7a5      	b.n	d00022d2 <stbi__jpeg_decode_block_prog_dc+0x102>
d0002386:	4291      	cmp	r1, r2
d0002388:	bfb4      	ite	lt
d000238a:	2100      	movlt	r1, #0
d000238c:	2101      	movge	r1, #1
d000238e:	e769      	b.n	d0002264 <stbi__jpeg_decode_block_prog_dc+0x94>
d0002390:	f06f 4000 	mvn.w	r0, #2147483648	; 0x80000000
d0002394:	1b40      	subs	r0, r0, r5
d0002396:	4282      	cmp	r2, r0
d0002398:	bfcc      	ite	gt
d000239a:	2000      	movgt	r0, #0
d000239c:	2001      	movle	r0, #1
d000239e:	e7cf      	b.n	d0002340 <stbi__jpeg_decode_block_prog_dc+0x170>
d00023a0:	d000dec8 	.word	0xd000dec8
d00023a4:	d000d310 	.word	0xd000d310
d00023a8:	d000d4c4 	.word	0xd000d4c4
d00023ac:	d000d304 	.word	0xd000d304
d00023b0:	ffff8000 	.word	0xffff8000
d00023b4:	d000d508 	.word	0xd000d508

d00023b8 <stbi__process_marker>:
d00023b8:	29dd      	cmp	r1, #221	; 0xdd
d00023ba:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00023be:	4681      	mov	r9, r0
d00023c0:	b095      	sub	sp, #84	; 0x54
d00023c2:	f000 81a2 	beq.w	d000270a <stbi__process_marker+0x352>
d00023c6:	460c      	mov	r4, r1
d00023c8:	f300 80dc 	bgt.w	d0002584 <stbi__process_marker+0x1cc>
d00023cc:	29c4      	cmp	r1, #196	; 0xc4
d00023ce:	f000 8125 	beq.w	d000261c <stbi__process_marker+0x264>
d00023d2:	29db      	cmp	r1, #219	; 0xdb
d00023d4:	f040 81b4 	bne.w	d0002740 <stbi__process_marker+0x388>
d00023d8:	6800      	ldr	r0, [r0, #0]
d00023da:	f7ff fb4d 	bl	d0001a78 <stbi__get16be>
d00023de:	1e83      	subs	r3, r0, #2
d00023e0:	2b00      	cmp	r3, #0
d00023e2:	9301      	str	r3, [sp, #4]
d00023e4:	f340 80c7 	ble.w	d0002576 <stbi__process_marker+0x1be>
d00023e8:	f8d9 4000 	ldr.w	r4, [r9]
d00023ec:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00023f0:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d00023f4:	4293      	cmp	r3, r2
d00023f6:	f0c0 80dc 	bcc.w	d00025b2 <stbi__process_marker+0x1fa>
d00023fa:	6a26      	ldr	r6, [r4, #32]
d00023fc:	2e00      	cmp	r6, #0
d00023fe:	f040 80ed 	bne.w	d00025dc <stbi__process_marker+0x224>
d0002402:	4637      	mov	r7, r6
d0002404:	4dc7      	ldr	r5, [pc, #796]	; (d0002724 <stbi__process_marker+0x36c>)
d0002406:	01bf      	lsls	r7, r7, #6
d0002408:	f105 0840 	add.w	r8, r5, #64	; 0x40
d000240c:	b1e6      	cbz	r6, d0002448 <stbi__process_marker+0x90>
d000240e:	4293      	cmp	r3, r2
d0002410:	d321      	bcc.n	d0002456 <stbi__process_marker+0x9e>
d0002412:	f8d4 b020 	ldr.w	fp, [r4, #32]
d0002416:	f1bb 0f00 	cmp.w	fp, #0
d000241a:	d131      	bne.n	d0002480 <stbi__process_marker+0xc8>
d000241c:	fa1f fb8b 	uxth.w	fp, fp
d0002420:	f815 3f01 	ldrb.w	r3, [r5, #1]!
d0002424:	443b      	add	r3, r7
d0002426:	45a8      	cmp	r8, r5
d0002428:	f503 53d2 	add.w	r3, r3, #6720	; 0x1a40
d000242c:	eb09 0343 	add.w	r3, r9, r3, lsl #1
d0002430:	f8a3 b004 	strh.w	fp, [r3, #4]
d0002434:	f000 8098 	beq.w	d0002568 <stbi__process_marker+0x1b0>
d0002438:	f8d9 4000 	ldr.w	r4, [r9]
d000243c:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002440:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002444:	2e00      	cmp	r6, #0
d0002446:	d1e2      	bne.n	d000240e <stbi__process_marker+0x56>
d0002448:	4293      	cmp	r3, r2
d000244a:	d313      	bcc.n	d0002474 <stbi__process_marker+0xbc>
d000244c:	6a23      	ldr	r3, [r4, #32]
d000244e:	2b00      	cmp	r3, #0
d0002450:	d15c      	bne.n	d000250c <stbi__process_marker+0x154>
d0002452:	46b3      	mov	fp, r6
d0002454:	e7e4      	b.n	d0002420 <stbi__process_marker+0x68>
d0002456:	1c59      	adds	r1, r3, #1
d0002458:	f8c4 10ac 	str.w	r1, [r4, #172]	; 0xac
d000245c:	4291      	cmp	r1, r2
d000245e:	f893 b000 	ldrb.w	fp, [r3]
d0002462:	ea4f 2b0b 	mov.w	fp, fp, lsl #8
d0002466:	d22e      	bcs.n	d00024c6 <stbi__process_marker+0x10e>
d0002468:	1c4b      	adds	r3, r1, #1
d000246a:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d000246e:	780b      	ldrb	r3, [r1, #0]
d0002470:	449b      	add	fp, r3
d0002472:	e7d3      	b.n	d000241c <stbi__process_marker+0x64>
d0002474:	1c5a      	adds	r2, r3, #1
d0002476:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d000247a:	f893 b000 	ldrb.w	fp, [r3]
d000247e:	e7cf      	b.n	d0002420 <stbi__process_marker+0x68>
d0002480:	f104 0a28 	add.w	sl, r4, #40	; 0x28
d0002484:	6923      	ldr	r3, [r4, #16]
d0002486:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002488:	4651      	mov	r1, sl
d000248a:	69e0      	ldr	r0, [r4, #28]
d000248c:	4798      	blx	r3
d000248e:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002492:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002496:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d000249a:	1a52      	subs	r2, r2, r1
d000249c:	4413      	add	r3, r2
d000249e:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d00024a2:	2800      	cmp	r0, #0
d00024a4:	d150      	bne.n	d0002548 <stbi__process_marker+0x190>
d00024a6:	f104 0229 	add.w	r2, r4, #41	; 0x29
d00024aa:	6220      	str	r0, [r4, #32]
d00024ac:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d00024b0:	4611      	mov	r1, r2
d00024b2:	f894 b028 	ldrb.w	fp, [r4, #40]	; 0x28
d00024b6:	4291      	cmp	r1, r2
d00024b8:	f8c4 20b0 	str.w	r2, [r4, #176]	; 0xb0
d00024bc:	ea4f 2b0b 	mov.w	fp, fp, lsl #8
d00024c0:	f8c4 10ac 	str.w	r1, [r4, #172]	; 0xac
d00024c4:	d3d0      	bcc.n	d0002468 <stbi__process_marker+0xb0>
d00024c6:	6a23      	ldr	r3, [r4, #32]
d00024c8:	2b00      	cmp	r3, #0
d00024ca:	d0a7      	beq.n	d000241c <stbi__process_marker+0x64>
d00024cc:	f104 0a28 	add.w	sl, r4, #40	; 0x28
d00024d0:	6923      	ldr	r3, [r4, #16]
d00024d2:	6a62      	ldr	r2, [r4, #36]	; 0x24
d00024d4:	4651      	mov	r1, sl
d00024d6:	69e0      	ldr	r0, [r4, #28]
d00024d8:	4798      	blx	r3
d00024da:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d00024de:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d00024e2:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d00024e6:	1a52      	subs	r2, r2, r1
d00024e8:	4413      	add	r3, r2
d00024ea:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d00024ee:	bbb0      	cbnz	r0, d000255e <stbi__process_marker+0x1a6>
d00024f0:	f104 0129 	add.w	r1, r4, #41	; 0x29
d00024f4:	6220      	str	r0, [r4, #32]
d00024f6:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d00024fa:	460a      	mov	r2, r1
d00024fc:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002500:	f8c4 10b0 	str.w	r1, [r4, #176]	; 0xb0
d0002504:	449b      	add	fp, r3
d0002506:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d000250a:	e787      	b.n	d000241c <stbi__process_marker+0x64>
d000250c:	f104 0a28 	add.w	sl, r4, #40	; 0x28
d0002510:	6923      	ldr	r3, [r4, #16]
d0002512:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002514:	4651      	mov	r1, sl
d0002516:	69e0      	ldr	r0, [r4, #28]
d0002518:	4798      	blx	r3
d000251a:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d000251e:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002522:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002526:	1a52      	subs	r2, r2, r1
d0002528:	4413      	add	r3, r2
d000252a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d000252e:	b980      	cbnz	r0, d0002552 <stbi__process_marker+0x19a>
d0002530:	f104 0029 	add.w	r0, r4, #41	; 0x29
d0002534:	46b3      	mov	fp, r6
d0002536:	6226      	str	r6, [r4, #32]
d0002538:	4603      	mov	r3, r0
d000253a:	f884 6028 	strb.w	r6, [r4, #40]	; 0x28
d000253e:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0002542:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002546:	e76b      	b.n	d0002420 <stbi__process_marker+0x68>
d0002548:	eb0a 0200 	add.w	r2, sl, r0
d000254c:	f104 0129 	add.w	r1, r4, #41	; 0x29
d0002550:	e7af      	b.n	d00024b2 <stbi__process_marker+0xfa>
d0002552:	4450      	add	r0, sl
d0002554:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002558:	f894 b028 	ldrb.w	fp, [r4, #40]	; 0x28
d000255c:	e7ef      	b.n	d000253e <stbi__process_marker+0x186>
d000255e:	eb0a 0100 	add.w	r1, sl, r0
d0002562:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002566:	e7c9      	b.n	d00024fc <stbi__process_marker+0x144>
d0002568:	9b01      	ldr	r3, [sp, #4]
d000256a:	b1ae      	cbz	r6, d0002598 <stbi__process_marker+0x1e0>
d000256c:	3b81      	subs	r3, #129	; 0x81
d000256e:	2b00      	cmp	r3, #0
d0002570:	9301      	str	r3, [sp, #4]
d0002572:	f73f af39 	bgt.w	d00023e8 <stbi__process_marker+0x30>
d0002576:	9b01      	ldr	r3, [sp, #4]
d0002578:	fab3 f083 	clz	r0, r3
d000257c:	0940      	lsrs	r0, r0, #5
d000257e:	b015      	add	sp, #84	; 0x54
d0002580:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0002584:	29ff      	cmp	r1, #255	; 0xff
d0002586:	f040 80d5 	bne.w	d0002734 <stbi__process_marker+0x37c>
d000258a:	4b67      	ldr	r3, [pc, #412]	; (d0002728 <stbi__process_marker+0x370>)
d000258c:	2000      	movs	r0, #0
d000258e:	4a67      	ldr	r2, [pc, #412]	; (d000272c <stbi__process_marker+0x374>)
d0002590:	601a      	str	r2, [r3, #0]
d0002592:	b015      	add	sp, #84	; 0x54
d0002594:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0002598:	3b41      	subs	r3, #65	; 0x41
d000259a:	2b00      	cmp	r3, #0
d000259c:	9301      	str	r3, [sp, #4]
d000259e:	ddea      	ble.n	d0002576 <stbi__process_marker+0x1be>
d00025a0:	f8d9 4000 	ldr.w	r4, [r9]
d00025a4:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00025a8:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d00025ac:	4293      	cmp	r3, r2
d00025ae:	f4bf af24 	bcs.w	d00023fa <stbi__process_marker+0x42>
d00025b2:	1c5a      	adds	r2, r3, #1
d00025b4:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d00025b8:	781b      	ldrb	r3, [r3, #0]
d00025ba:	111e      	asrs	r6, r3, #4
d00025bc:	f003 070f 	and.w	r7, r3, #15
d00025c0:	2e01      	cmp	r6, #1
d00025c2:	f300 81f6 	bgt.w	d00029b2 <stbi__process_marker+0x5fa>
d00025c6:	f013 0f0c 	tst.w	r3, #12
d00025ca:	f040 81f7 	bne.w	d00029bc <stbi__process_marker+0x604>
d00025ce:	f8d9 4000 	ldr.w	r4, [r9]
d00025d2:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00025d6:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d00025da:	e713      	b.n	d0002404 <stbi__process_marker+0x4c>
d00025dc:	f104 0528 	add.w	r5, r4, #40	; 0x28
d00025e0:	6923      	ldr	r3, [r4, #16]
d00025e2:	6a62      	ldr	r2, [r4, #36]	; 0x24
d00025e4:	4629      	mov	r1, r5
d00025e6:	69e0      	ldr	r0, [r4, #28]
d00025e8:	4798      	blx	r3
d00025ea:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d00025ee:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d00025f2:	4606      	mov	r6, r0
d00025f4:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d00025f8:	1a52      	subs	r2, r2, r1
d00025fa:	4413      	add	r3, r2
d00025fc:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002600:	2800      	cmp	r0, #0
d0002602:	f040 80a4 	bne.w	d000274e <stbi__process_marker+0x396>
d0002606:	f104 0329 	add.w	r3, r4, #41	; 0x29
d000260a:	4607      	mov	r7, r0
d000260c:	6220      	str	r0, [r4, #32]
d000260e:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002612:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002616:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d000261a:	e7d8      	b.n	d00025ce <stbi__process_marker+0x216>
d000261c:	6800      	ldr	r0, [r0, #0]
d000261e:	f7ff fa2b 	bl	d0001a78 <stbi__get16be>
d0002622:	f1a0 0b02 	sub.w	fp, r0, #2
d0002626:	f1bb 0f00 	cmp.w	fp, #0
d000262a:	f340 814b 	ble.w	d00028c4 <stbi__process_marker+0x50c>
d000262e:	f04f 0a00 	mov.w	sl, #0
d0002632:	f8d9 4000 	ldr.w	r4, [r9]
d0002636:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d000263a:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d000263e:	4293      	cmp	r3, r2
d0002640:	f0c0 815e 	bcc.w	d0002900 <stbi__process_marker+0x548>
d0002644:	6a21      	ldr	r1, [r4, #32]
d0002646:	9101      	str	r1, [sp, #4]
d0002648:	2900      	cmp	r1, #0
d000264a:	f040 8173 	bne.w	d0002934 <stbi__process_marker+0x57c>
d000264e:	4688      	mov	r8, r1
d0002650:	9102      	str	r1, [sp, #8]
d0002652:	ad03      	add	r5, sp, #12
d0002654:	2600      	movs	r6, #0
d0002656:	e00e      	b.n	d0002676 <stbi__process_marker+0x2be>
d0002658:	6a20      	ldr	r0, [r4, #32]
d000265a:	2800      	cmp	r0, #0
d000265c:	f040 80a0 	bne.w	d00027a0 <stbi__process_marker+0x3e8>
d0002660:	ab13      	add	r3, sp, #76	; 0x4c
d0002662:	f845 0f04 	str.w	r0, [r5, #4]!
d0002666:	42ab      	cmp	r3, r5
d0002668:	d011      	beq.n	d000268e <stbi__process_marker+0x2d6>
d000266a:	f8d9 4000 	ldr.w	r4, [r9]
d000266e:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002672:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002676:	429a      	cmp	r2, r3
d0002678:	d9ee      	bls.n	d0002658 <stbi__process_marker+0x2a0>
d000267a:	1c5a      	adds	r2, r3, #1
d000267c:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002680:	7818      	ldrb	r0, [r3, #0]
d0002682:	ab13      	add	r3, sp, #76	; 0x4c
d0002684:	f845 0f04 	str.w	r0, [r5, #4]!
d0002688:	42ab      	cmp	r3, r5
d000268a:	4406      	add	r6, r0
d000268c:	d1ed      	bne.n	d000266a <stbi__process_marker+0x2b2>
d000268e:	f5b6 7f80 	cmp.w	r6, #256	; 0x100
d0002692:	f300 816e 	bgt.w	d0002972 <stbi__process_marker+0x5ba>
d0002696:	f1ab 0311 	sub.w	r3, fp, #17
d000269a:	f44f 64d2 	mov.w	r4, #1680	; 0x690
d000269e:	9303      	str	r3, [sp, #12]
d00026a0:	9b01      	ldr	r3, [sp, #4]
d00026a2:	2b00      	cmp	r3, #0
d00026a4:	f040 8116 	bne.w	d00028d4 <stbi__process_marker+0x51c>
d00026a8:	f109 0004 	add.w	r0, r9, #4
d00026ac:	fb04 fb08 	mul.w	fp, r4, r8
d00026b0:	a904      	add	r1, sp, #16
d00026b2:	4458      	add	r0, fp
d00026b4:	f7ff f924 	bl	d0001900 <stbi__build_huffman>
d00026b8:	2800      	cmp	r0, #0
d00026ba:	f000 815d 	beq.w	d0002978 <stbi__process_marker+0x5c0>
d00026be:	9b02      	ldr	r3, [sp, #8]
d00026c0:	fb04 9403 	mla	r4, r4, r3, r9
d00026c4:	f204 4804 	addw	r8, r4, #1028	; 0x404
d00026c8:	2e00      	cmp	r6, #0
d00026ca:	f000 80f4 	beq.w	d00028b6 <stbi__process_marker+0x4fe>
d00026ce:	f108 35ff 	add.w	r5, r8, #4294967295	; 0xffffffff
d00026d2:	e00d      	b.n	d00026f0 <stbi__process_marker+0x338>
d00026d4:	6a23      	ldr	r3, [r4, #32]
d00026d6:	461a      	mov	r2, r3
d00026d8:	2b00      	cmp	r3, #0
d00026da:	f040 8083 	bne.w	d00027e4 <stbi__process_marker+0x42c>
d00026de:	1cab      	adds	r3, r5, #2
d00026e0:	1c69      	adds	r1, r5, #1
d00026e2:	706a      	strb	r2, [r5, #1]
d00026e4:	eba3 0308 	sub.w	r3, r3, r8
d00026e8:	460d      	mov	r5, r1
d00026ea:	429e      	cmp	r6, r3
d00026ec:	f340 8099 	ble.w	d0002822 <stbi__process_marker+0x46a>
d00026f0:	f8d9 4000 	ldr.w	r4, [r9]
d00026f4:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00026f8:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d00026fc:	4293      	cmp	r3, r2
d00026fe:	d2e9      	bcs.n	d00026d4 <stbi__process_marker+0x31c>
d0002700:	1c5a      	adds	r2, r3, #1
d0002702:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002706:	781a      	ldrb	r2, [r3, #0]
d0002708:	e7e9      	b.n	d00026de <stbi__process_marker+0x326>
d000270a:	6800      	ldr	r0, [r0, #0]
d000270c:	f7ff f9b4 	bl	d0001a78 <stbi__get16be>
d0002710:	2804      	cmp	r0, #4
d0002712:	d029      	beq.n	d0002768 <stbi__process_marker+0x3b0>
d0002714:	4b04      	ldr	r3, [pc, #16]	; (d0002728 <stbi__process_marker+0x370>)
d0002716:	2000      	movs	r0, #0
d0002718:	4a05      	ldr	r2, [pc, #20]	; (d0002730 <stbi__process_marker+0x378>)
d000271a:	601a      	str	r2, [r3, #0]
d000271c:	b015      	add	sp, #84	; 0x54
d000271e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0002722:	bf00      	nop
d0002724:	d000d547 	.word	0xd000d547
d0002728:	d000dec8 	.word	0xd000dec8
d000272c:	d000d328 	.word	0xd000d328
d0002730:	d000d338 	.word	0xd000d338
d0002734:	f1a1 03e0 	sub.w	r3, r1, #224	; 0xe0
d0002738:	2b0f      	cmp	r3, #15
d000273a:	d920      	bls.n	d000277e <stbi__process_marker+0x3c6>
d000273c:	29fe      	cmp	r1, #254	; 0xfe
d000273e:	d01e      	beq.n	d000277e <stbi__process_marker+0x3c6>
d0002740:	4ba1      	ldr	r3, [pc, #644]	; (d00029c8 <stbi__process_marker+0x610>)
d0002742:	2000      	movs	r0, #0
d0002744:	4aa1      	ldr	r2, [pc, #644]	; (d00029cc <stbi__process_marker+0x614>)
d0002746:	601a      	str	r2, [r3, #0]
d0002748:	b015      	add	sp, #84	; 0x54
d000274a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000274e:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002752:	4405      	add	r5, r0
d0002754:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002758:	111e      	asrs	r6, r3, #4
d000275a:	f003 070f 	and.w	r7, r3, #15
d000275e:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0002762:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002766:	e72b      	b.n	d00025c0 <stbi__process_marker+0x208>
d0002768:	f8d9 0000 	ldr.w	r0, [r9]
d000276c:	f7ff f984 	bl	d0001a78 <stbi__get16be>
d0002770:	f644 0304 	movw	r3, #18436	; 0x4804
d0002774:	4602      	mov	r2, r0
d0002776:	2001      	movs	r0, #1
d0002778:	f849 2003 	str.w	r2, [r9, r3]
d000277c:	e6ff      	b.n	d000257e <stbi__process_marker+0x1c6>
d000277e:	f8d9 0000 	ldr.w	r0, [r9]
d0002782:	f7ff f979 	bl	d0001a78 <stbi__get16be>
d0002786:	2801      	cmp	r0, #1
d0002788:	4606      	mov	r6, r0
d000278a:	f300 812b 	bgt.w	d00029e4 <stbi__process_marker+0x62c>
d000278e:	2cfe      	cmp	r4, #254	; 0xfe
d0002790:	4b8d      	ldr	r3, [pc, #564]	; (d00029c8 <stbi__process_marker+0x610>)
d0002792:	f04f 0000 	mov.w	r0, #0
d0002796:	bf0c      	ite	eq
d0002798:	4a8d      	ldreq	r2, [pc, #564]	; (d00029d0 <stbi__process_marker+0x618>)
d000279a:	4a8e      	ldrne	r2, [pc, #568]	; (d00029d4 <stbi__process_marker+0x61c>)
d000279c:	601a      	str	r2, [r3, #0]
d000279e:	e6ee      	b.n	d000257e <stbi__process_marker+0x1c6>
d00027a0:	f104 0728 	add.w	r7, r4, #40	; 0x28
d00027a4:	6923      	ldr	r3, [r4, #16]
d00027a6:	6a62      	ldr	r2, [r4, #36]	; 0x24
d00027a8:	4639      	mov	r1, r7
d00027aa:	69e0      	ldr	r0, [r4, #28]
d00027ac:	4798      	blx	r3
d00027ae:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00027b2:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d00027b6:	f104 0129 	add.w	r1, r4, #41	; 0x29
d00027ba:	1a9a      	subs	r2, r3, r2
d00027bc:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d00027c0:	468c      	mov	ip, r1
d00027c2:	4413      	add	r3, r2
d00027c4:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d00027c8:	b938      	cbnz	r0, d00027da <stbi__process_marker+0x422>
d00027ca:	6220      	str	r0, [r4, #32]
d00027cc:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d00027d0:	f8c4 10b0 	str.w	r1, [r4, #176]	; 0xb0
d00027d4:	f8c4 c0ac 	str.w	ip, [r4, #172]	; 0xac
d00027d8:	e742      	b.n	d0002660 <stbi__process_marker+0x2a8>
d00027da:	1839      	adds	r1, r7, r0
d00027dc:	f894 0028 	ldrb.w	r0, [r4, #40]	; 0x28
d00027e0:	4406      	add	r6, r0
d00027e2:	e7f5      	b.n	d00027d0 <stbi__process_marker+0x418>
d00027e4:	f104 0728 	add.w	r7, r4, #40	; 0x28
d00027e8:	6923      	ldr	r3, [r4, #16]
d00027ea:	6a62      	ldr	r2, [r4, #36]	; 0x24
d00027ec:	4639      	mov	r1, r7
d00027ee:	69e0      	ldr	r0, [r4, #28]
d00027f0:	4798      	blx	r3
d00027f2:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00027f6:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d00027fa:	f104 0129 	add.w	r1, r4, #41	; 0x29
d00027fe:	1a9a      	subs	r2, r3, r2
d0002800:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002804:	468c      	mov	ip, r1
d0002806:	4413      	add	r3, r2
d0002808:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d000280c:	2800      	cmp	r0, #0
d000280e:	d15d      	bne.n	d00028cc <stbi__process_marker+0x514>
d0002810:	4602      	mov	r2, r0
d0002812:	6220      	str	r0, [r4, #32]
d0002814:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002818:	f8c4 c0ac 	str.w	ip, [r4, #172]	; 0xac
d000281c:	f8c4 10b0 	str.w	r1, [r4, #176]	; 0xb0
d0002820:	e75d      	b.n	d00026de <stbi__process_marker+0x326>
d0002822:	9b01      	ldr	r3, [sp, #4]
d0002824:	2b00      	cmp	r3, #0
d0002826:	d046      	beq.n	d00028b6 <stbi__process_marker+0x4fe>
d0002828:	f641 2744 	movw	r7, #6724	; 0x1a44
d000282c:	444f      	add	r7, r9
d000282e:	445f      	add	r7, fp
d0002830:	9b02      	ldr	r3, [sp, #8]
d0002832:	f243 6582 	movw	r5, #13954	; 0x3682
d0002836:	f207 1bff 	addw	fp, r7, #511	; 0x1ff
d000283a:	f1c7 0801 	rsb	r8, r7, #1
d000283e:	eb09 2283 	add.w	r2, r9, r3, lsl #10
d0002842:	1e7b      	subs	r3, r7, #1
d0002844:	9601      	str	r6, [sp, #4]
d0002846:	4415      	add	r5, r2
d0002848:	eb08 0203 	add.w	r2, r8, r3
d000284c:	f813 1f01 	ldrb.w	r1, [r3, #1]!
d0002850:	f825 af02 	strh.w	sl, [r5, #2]!
d0002854:	29ff      	cmp	r1, #255	; 0xff
d0002856:	eb07 0401 	add.w	r4, r7, r1
d000285a:	d029      	beq.n	d00028b0 <stbi__process_marker+0x4f8>
d000285c:	f894 1400 	ldrb.w	r1, [r4, #1024]	; 0x400
d0002860:	f011 000f 	ands.w	r0, r1, #15
d0002864:	d024      	beq.n	d00028b0 <stbi__process_marker+0x4f8>
d0002866:	f894 4500 	ldrb.w	r4, [r4, #1280]	; 0x500
d000286a:	f1c0 0c09 	rsb	ip, r0, #9
d000286e:	f100 3eff 	add.w	lr, r0, #4294967295	; 0xffffffff
d0002872:	2601      	movs	r6, #1
d0002874:	40a2      	lsls	r2, r4
d0002876:	4404      	add	r4, r0
d0002878:	fa06 fe0e 	lsl.w	lr, r6, lr
d000287c:	f3c2 0208 	ubfx	r2, r2, #0, #9
d0002880:	2c09      	cmp	r4, #9
d0002882:	fa42 f20c 	asr.w	r2, r2, ip
d0002886:	dc13      	bgt.n	d00028b0 <stbi__process_marker+0x4f8>
d0002888:	f04f 36ff 	mov.w	r6, #4294967295	; 0xffffffff
d000288c:	4572      	cmp	r2, lr
d000288e:	ea4f 1121 	mov.w	r1, r1, asr #4
d0002892:	fa06 f000 	lsl.w	r0, r6, r0
d0002896:	f100 0001 	add.w	r0, r0, #1
d000289a:	bfb8      	it	lt
d000289c:	1812      	addlt	r2, r2, r0
d000289e:	f102 0080 	add.w	r0, r2, #128	; 0x80
d00028a2:	eb01 1202 	add.w	r2, r1, r2, lsl #4
d00028a6:	28ff      	cmp	r0, #255	; 0xff
d00028a8:	eb04 1402 	add.w	r4, r4, r2, lsl #4
d00028ac:	bf98      	it	ls
d00028ae:	802c      	strhls	r4, [r5, #0]
d00028b0:	455b      	cmp	r3, fp
d00028b2:	d1c9      	bne.n	d0002848 <stbi__process_marker+0x490>
d00028b4:	9e01      	ldr	r6, [sp, #4]
d00028b6:	9b03      	ldr	r3, [sp, #12]
d00028b8:	eba3 0b06 	sub.w	fp, r3, r6
d00028bc:	f1bb 0f00 	cmp.w	fp, #0
d00028c0:	f73f aeb7 	bgt.w	d0002632 <stbi__process_marker+0x27a>
d00028c4:	fabb f08b 	clz	r0, fp
d00028c8:	0940      	lsrs	r0, r0, #5
d00028ca:	e658      	b.n	d000257e <stbi__process_marker+0x1c6>
d00028cc:	1839      	adds	r1, r7, r0
d00028ce:	f894 2028 	ldrb.w	r2, [r4, #40]	; 0x28
d00028d2:	e7a1      	b.n	d0002818 <stbi__process_marker+0x460>
d00028d4:	f641 2744 	movw	r7, #6724	; 0x1a44
d00028d8:	fb04 fb08 	mul.w	fp, r4, r8
d00028dc:	a904      	add	r1, sp, #16
d00028de:	444f      	add	r7, r9
d00028e0:	445f      	add	r7, fp
d00028e2:	4638      	mov	r0, r7
d00028e4:	f7ff f80c 	bl	d0001900 <stbi__build_huffman>
d00028e8:	2800      	cmp	r0, #0
d00028ea:	d045      	beq.n	d0002978 <stbi__process_marker+0x5c0>
d00028ec:	9b02      	ldr	r3, [sp, #8]
d00028ee:	f641 6844 	movw	r8, #7748	; 0x1e44
d00028f2:	fb04 9403 	mla	r4, r4, r3, r9
d00028f6:	44a0      	add	r8, r4
d00028f8:	2e00      	cmp	r6, #0
d00028fa:	f47f aee8 	bne.w	d00026ce <stbi__process_marker+0x316>
d00028fe:	e797      	b.n	d0002830 <stbi__process_marker+0x478>
d0002900:	1c5a      	adds	r2, r3, #1
d0002902:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002906:	781b      	ldrb	r3, [r3, #0]
d0002908:	f003 020c 	and.w	r2, r3, #12
d000290c:	f003 080f 	and.w	r8, r3, #15
d0002910:	1119      	asrs	r1, r3, #4
d0002912:	2b1f      	cmp	r3, #31
d0002914:	bf98      	it	ls
d0002916:	2a00      	cmpls	r2, #0
d0002918:	f8cd 8008 	str.w	r8, [sp, #8]
d000291c:	9101      	str	r1, [sp, #4]
d000291e:	bf14      	ite	ne
d0002920:	2301      	movne	r3, #1
d0002922:	2300      	moveq	r3, #0
d0002924:	bb2b      	cbnz	r3, d0002972 <stbi__process_marker+0x5ba>
d0002926:	f8d9 4000 	ldr.w	r4, [r9]
d000292a:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d000292e:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002932:	e68e      	b.n	d0002652 <stbi__process_marker+0x29a>
d0002934:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0002938:	6923      	ldr	r3, [r4, #16]
d000293a:	6a62      	ldr	r2, [r4, #36]	; 0x24
d000293c:	4629      	mov	r1, r5
d000293e:	69e0      	ldr	r0, [r4, #28]
d0002940:	4798      	blx	r3
d0002942:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002946:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d000294a:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d000294e:	1a52      	subs	r2, r2, r1
d0002950:	9001      	str	r0, [sp, #4]
d0002952:	4413      	add	r3, r2
d0002954:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002958:	b990      	cbnz	r0, d0002980 <stbi__process_marker+0x5c8>
d000295a:	f104 0329 	add.w	r3, r4, #41	; 0x29
d000295e:	4680      	mov	r8, r0
d0002960:	6220      	str	r0, [r4, #32]
d0002962:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002966:	9002      	str	r0, [sp, #8]
d0002968:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d000296c:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002970:	e7d9      	b.n	d0002926 <stbi__process_marker+0x56e>
d0002972:	4b15      	ldr	r3, [pc, #84]	; (d00029c8 <stbi__process_marker+0x610>)
d0002974:	4a18      	ldr	r2, [pc, #96]	; (d00029d8 <stbi__process_marker+0x620>)
d0002976:	601a      	str	r2, [r3, #0]
d0002978:	2000      	movs	r0, #0
d000297a:	b015      	add	sp, #84	; 0x54
d000297c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0002980:	f894 2028 	ldrb.w	r2, [r4, #40]	; 0x28
d0002984:	4405      	add	r5, r0
d0002986:	f104 0129 	add.w	r1, r4, #41	; 0x29
d000298a:	f002 080f 	and.w	r8, r2, #15
d000298e:	1113      	asrs	r3, r2, #4
d0002990:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0002994:	f1b8 0f03 	cmp.w	r8, #3
d0002998:	9301      	str	r3, [sp, #4]
d000299a:	f8cd 8008 	str.w	r8, [sp, #8]
d000299e:	bfd4      	ite	le
d00029a0:	2300      	movle	r3, #0
d00029a2:	2301      	movgt	r3, #1
d00029a4:	f8c4 10ac 	str.w	r1, [r4, #172]	; 0xac
d00029a8:	2a1f      	cmp	r2, #31
d00029aa:	bf88      	it	hi
d00029ac:	f043 0301 	orrhi.w	r3, r3, #1
d00029b0:	e7b8      	b.n	d0002924 <stbi__process_marker+0x56c>
d00029b2:	4b05      	ldr	r3, [pc, #20]	; (d00029c8 <stbi__process_marker+0x610>)
d00029b4:	2000      	movs	r0, #0
d00029b6:	4a09      	ldr	r2, [pc, #36]	; (d00029dc <stbi__process_marker+0x624>)
d00029b8:	601a      	str	r2, [r3, #0]
d00029ba:	e5e0      	b.n	d000257e <stbi__process_marker+0x1c6>
d00029bc:	4b02      	ldr	r3, [pc, #8]	; (d00029c8 <stbi__process_marker+0x610>)
d00029be:	2000      	movs	r0, #0
d00029c0:	4a07      	ldr	r2, [pc, #28]	; (d00029e0 <stbi__process_marker+0x628>)
d00029c2:	601a      	str	r2, [r3, #0]
d00029c4:	e5db      	b.n	d000257e <stbi__process_marker+0x1c6>
d00029c6:	bf00      	nop
d00029c8:	d000dec8 	.word	0xd000dec8
d00029cc:	d000d38c 	.word	0xd000d38c
d00029d0:	d000d374 	.word	0xd000d374
d00029d4:	d000d380 	.word	0xd000d380
d00029d8:	d000d364 	.word	0xd000d364
d00029dc:	d000d344 	.word	0xd000d344
d00029e0:	d000d354 	.word	0xd000d354
d00029e4:	2ce0      	cmp	r4, #224	; 0xe0
d00029e6:	f1a0 0302 	sub.w	r3, r0, #2
d00029ea:	d158      	bne.n	d0002a9e <stbi__process_marker+0x6e6>
d00029ec:	2b04      	cmp	r3, #4
d00029ee:	dd56      	ble.n	d0002a9e <stbi__process_marker+0x6e6>
d00029f0:	f8d9 4000 	ldr.w	r4, [r9]
d00029f4:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00029f8:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d00029fc:	429a      	cmp	r2, r3
d00029fe:	f200 80f0 	bhi.w	d0002be2 <stbi__process_marker+0x82a>
d0002a02:	6a25      	ldr	r5, [r4, #32]
d0002a04:	2d00      	cmp	r5, #0
d0002a06:	f040 80c8 	bne.w	d0002b9a <stbi__process_marker+0x7e2>
d0002a0a:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002a0e:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002a12:	429a      	cmp	r2, r3
d0002a14:	f200 81b5 	bhi.w	d0002d82 <stbi__process_marker+0x9ca>
d0002a18:	f8d4 8020 	ldr.w	r8, [r4, #32]
d0002a1c:	f1b8 0f00 	cmp.w	r8, #0
d0002a20:	f040 818b 	bne.w	d0002d3a <stbi__process_marker+0x982>
d0002a24:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002a28:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002a2c:	429a      	cmp	r2, r3
d0002a2e:	f200 8173 	bhi.w	d0002d18 <stbi__process_marker+0x960>
d0002a32:	6a27      	ldr	r7, [r4, #32]
d0002a34:	2f00      	cmp	r7, #0
d0002a36:	f040 814c 	bne.w	d0002cd2 <stbi__process_marker+0x91a>
d0002a3a:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002a3e:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002a42:	429a      	cmp	r2, r3
d0002a44:	f200 8134 	bhi.w	d0002cb0 <stbi__process_marker+0x8f8>
d0002a48:	6a25      	ldr	r5, [r4, #32]
d0002a4a:	2d00      	cmp	r5, #0
d0002a4c:	f040 810d 	bne.w	d0002c6a <stbi__process_marker+0x8b2>
d0002a50:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002a54:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002a58:	4293      	cmp	r3, r2
d0002a5a:	f0c0 80f1 	bcc.w	d0002c40 <stbi__process_marker+0x888>
d0002a5e:	6a23      	ldr	r3, [r4, #32]
d0002a60:	2b00      	cmp	r3, #0
d0002a62:	f040 80cf 	bne.w	d0002c04 <stbi__process_marker+0x84c>
d0002a66:	1ff3      	subs	r3, r6, #7
d0002a68:	b125      	cbz	r5, d0002a74 <stbi__process_marker+0x6bc>
d0002a6a:	f244 72e4 	movw	r2, #18404	; 0x47e4
d0002a6e:	2101      	movs	r1, #1
d0002a70:	f849 1002 	str.w	r1, [r9, r2]
d0002a74:	2b00      	cmp	r3, #0
d0002a76:	f000 8089 	beq.w	d0002b8c <stbi__process_marker+0x7d4>
d0002a7a:	f2c0 8193 	blt.w	d0002da4 <stbi__process_marker+0x9ec>
d0002a7e:	6922      	ldr	r2, [r4, #16]
d0002a80:	2a00      	cmp	r2, #0
d0002a82:	f000 823d 	beq.w	d0002f00 <stbi__process_marker+0xb48>
d0002a86:	f8d4 00b0 	ldr.w	r0, [r4, #176]	; 0xb0
d0002a8a:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002a8e:	1a81      	subs	r1, r0, r2
d0002a90:	4299      	cmp	r1, r3
d0002a92:	db75      	blt.n	d0002b80 <stbi__process_marker+0x7c8>
d0002a94:	4413      	add	r3, r2
d0002a96:	2001      	movs	r0, #1
d0002a98:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002a9c:	e56f      	b.n	d000257e <stbi__process_marker+0x1c6>
d0002a9e:	2cee      	cmp	r4, #238	; 0xee
d0002aa0:	d176      	bne.n	d0002b90 <stbi__process_marker+0x7d8>
d0002aa2:	2b0b      	cmp	r3, #11
d0002aa4:	dd74      	ble.n	d0002b90 <stbi__process_marker+0x7d8>
d0002aa6:	f8d9 4000 	ldr.w	r4, [r9]
d0002aaa:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002aae:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002ab2:	4293      	cmp	r3, r2
d0002ab4:	f0c0 817d 	bcc.w	d0002db2 <stbi__process_marker+0x9fa>
d0002ab8:	6a25      	ldr	r5, [r4, #32]
d0002aba:	2d00      	cmp	r5, #0
d0002abc:	f040 818c 	bne.w	d0002dd8 <stbi__process_marker+0xa20>
d0002ac0:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002ac4:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002ac8:	4293      	cmp	r3, r2
d0002aca:	f0c0 817c 	bcc.w	d0002dc6 <stbi__process_marker+0xa0e>
d0002ace:	6a27      	ldr	r7, [r4, #32]
d0002ad0:	2f00      	cmp	r7, #0
d0002ad2:	f040 81b3 	bne.w	d0002e3c <stbi__process_marker+0xa84>
d0002ad6:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002ada:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002ade:	4293      	cmp	r3, r2
d0002ae0:	f0c0 81a3 	bcc.w	d0002e2a <stbi__process_marker+0xa72>
d0002ae4:	6a25      	ldr	r5, [r4, #32]
d0002ae6:	2d00      	cmp	r5, #0
d0002ae8:	f040 81c7 	bne.w	d0002e7a <stbi__process_marker+0xac2>
d0002aec:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002af0:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002af4:	4293      	cmp	r3, r2
d0002af6:	f0c0 818f 	bcc.w	d0002e18 <stbi__process_marker+0xa60>
d0002afa:	6a27      	ldr	r7, [r4, #32]
d0002afc:	2f00      	cmp	r7, #0
d0002afe:	f040 828d 	bne.w	d000301c <stbi__process_marker+0xc64>
d0002b02:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002b06:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002b0a:	4293      	cmp	r3, r2
d0002b0c:	f0c0 827d 	bcc.w	d000300a <stbi__process_marker+0xc52>
d0002b10:	6a25      	ldr	r5, [r4, #32]
d0002b12:	2d00      	cmp	r5, #0
d0002b14:	f040 82a1 	bne.w	d000305a <stbi__process_marker+0xca2>
d0002b18:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002b1c:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002b20:	4293      	cmp	r3, r2
d0002b22:	f0c0 826d 	bcc.w	d0003000 <stbi__process_marker+0xc48>
d0002b26:	6a23      	ldr	r3, [r4, #32]
d0002b28:	2b00      	cmp	r3, #0
d0002b2a:	f040 81ec 	bne.w	d0002f06 <stbi__process_marker+0xb4e>
d0002b2e:	2d00      	cmp	r5, #0
d0002b30:	f000 8236 	beq.w	d0002fa0 <stbi__process_marker+0xbe8>
d0002b34:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002b38:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002b3c:	4293      	cmp	r3, r2
d0002b3e:	f0c0 823b 	bcc.w	d0002fb8 <stbi__process_marker+0xc00>
d0002b42:	6a23      	ldr	r3, [r4, #32]
d0002b44:	2b00      	cmp	r3, #0
d0002b46:	f040 823b 	bne.w	d0002fc0 <stbi__process_marker+0xc08>
d0002b4a:	4620      	mov	r0, r4
d0002b4c:	f7fe ff94 	bl	d0001a78 <stbi__get16be>
d0002b50:	f8d9 0000 	ldr.w	r0, [r9]
d0002b54:	f7fe ff90 	bl	d0001a78 <stbi__get16be>
d0002b58:	f8d9 4000 	ldr.w	r4, [r9]
d0002b5c:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002b60:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0002b64:	4293      	cmp	r3, r2
d0002b66:	f0c0 8222 	bcc.w	d0002fae <stbi__process_marker+0xbf6>
d0002b6a:	6a22      	ldr	r2, [r4, #32]
d0002b6c:	2a00      	cmp	r2, #0
d0002b6e:	f040 81e8 	bne.w	d0002f42 <stbi__process_marker+0xb8a>
d0002b72:	f244 71e8 	movw	r1, #18408	; 0x47e8
d0002b76:	f1a6 030e 	sub.w	r3, r6, #14
d0002b7a:	f849 2001 	str.w	r2, [r9, r1]
d0002b7e:	e779      	b.n	d0002a74 <stbi__process_marker+0x6bc>
d0002b80:	1a59      	subs	r1, r3, r1
d0002b82:	f8c4 00ac 	str.w	r0, [r4, #172]	; 0xac
d0002b86:	6963      	ldr	r3, [r4, #20]
d0002b88:	69e0      	ldr	r0, [r4, #28]
d0002b8a:	4798      	blx	r3
d0002b8c:	2001      	movs	r0, #1
d0002b8e:	e4f6      	b.n	d000257e <stbi__process_marker+0x1c6>
d0002b90:	2b00      	cmp	r3, #0
d0002b92:	d0fb      	beq.n	d0002b8c <stbi__process_marker+0x7d4>
d0002b94:	f8d9 4000 	ldr.w	r4, [r9]
d0002b98:	e771      	b.n	d0002a7e <stbi__process_marker+0x6c6>
d0002b9a:	f104 0728 	add.w	r7, r4, #40	; 0x28
d0002b9e:	6923      	ldr	r3, [r4, #16]
d0002ba0:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002ba2:	4639      	mov	r1, r7
d0002ba4:	69e0      	ldr	r0, [r4, #28]
d0002ba6:	4798      	blx	r3
d0002ba8:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002bac:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002bb0:	4605      	mov	r5, r0
d0002bb2:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002bb6:	1a52      	subs	r2, r2, r1
d0002bb8:	4413      	add	r3, r2
d0002bba:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002bbe:	b1a8      	cbz	r0, d0002bec <stbi__process_marker+0x834>
d0002bc0:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002bc4:	4407      	add	r7, r0
d0002bc6:	f894 5028 	ldrb.w	r5, [r4, #40]	; 0x28
d0002bca:	f8c4 70b0 	str.w	r7, [r4, #176]	; 0xb0
d0002bce:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002bd2:	f8d9 4000 	ldr.w	r4, [r9]
d0002bd6:	f1a5 054a 	sub.w	r5, r5, #74	; 0x4a
d0002bda:	fab5 f585 	clz	r5, r5
d0002bde:	096d      	lsrs	r5, r5, #5
d0002be0:	e713      	b.n	d0002a0a <stbi__process_marker+0x652>
d0002be2:	1c5a      	adds	r2, r3, #1
d0002be4:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002be8:	781d      	ldrb	r5, [r3, #0]
d0002bea:	e7f4      	b.n	d0002bd6 <stbi__process_marker+0x81e>
d0002bec:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002bf0:	6220      	str	r0, [r4, #32]
d0002bf2:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002bf6:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002bfa:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002bfe:	f8d9 4000 	ldr.w	r4, [r9]
d0002c02:	e702      	b.n	d0002a0a <stbi__process_marker+0x652>
d0002c04:	f104 0828 	add.w	r8, r4, #40	; 0x28
d0002c08:	6923      	ldr	r3, [r4, #16]
d0002c0a:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002c0c:	4641      	mov	r1, r8
d0002c0e:	69e0      	ldr	r0, [r4, #28]
d0002c10:	4798      	blx	r3
d0002c12:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002c16:	f8d4 70b4 	ldr.w	r7, [r4, #180]	; 0xb4
d0002c1a:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002c1e:	1bd2      	subs	r2, r2, r7
d0002c20:	4413      	add	r3, r2
d0002c22:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002c26:	b9a0      	cbnz	r0, d0002c52 <stbi__process_marker+0x89a>
d0002c28:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002c2c:	6220      	str	r0, [r4, #32]
d0002c2e:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002c32:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002c36:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002c3a:	f8d9 4000 	ldr.w	r4, [r9]
d0002c3e:	e712      	b.n	d0002a66 <stbi__process_marker+0x6ae>
d0002c40:	1c5a      	adds	r2, r3, #1
d0002c42:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002c46:	781b      	ldrb	r3, [r3, #0]
d0002c48:	2b00      	cmp	r3, #0
d0002c4a:	f43f af0c 	beq.w	d0002a66 <stbi__process_marker+0x6ae>
d0002c4e:	1ff3      	subs	r3, r6, #7
d0002c50:	e710      	b.n	d0002a74 <stbi__process_marker+0x6bc>
d0002c52:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002c56:	4440      	add	r0, r8
d0002c58:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002c5c:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0002c60:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002c64:	f8d9 4000 	ldr.w	r4, [r9]
d0002c68:	e7ee      	b.n	d0002c48 <stbi__process_marker+0x890>
d0002c6a:	f104 0828 	add.w	r8, r4, #40	; 0x28
d0002c6e:	6923      	ldr	r3, [r4, #16]
d0002c70:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002c72:	4641      	mov	r1, r8
d0002c74:	69e0      	ldr	r0, [r4, #28]
d0002c76:	4798      	blx	r3
d0002c78:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002c7c:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002c80:	4605      	mov	r5, r0
d0002c82:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002c86:	1a52      	subs	r2, r2, r1
d0002c88:	4413      	add	r3, r2
d0002c8a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002c8e:	b1a0      	cbz	r0, d0002cba <stbi__process_marker+0x902>
d0002c90:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002c94:	4445      	add	r5, r8
d0002c96:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002c9a:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0002c9e:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002ca2:	f8d9 4000 	ldr.w	r4, [r9]
d0002ca6:	2b46      	cmp	r3, #70	; 0x46
d0002ca8:	bf0c      	ite	eq
d0002caa:	463d      	moveq	r5, r7
d0002cac:	2500      	movne	r5, #0
d0002cae:	e6cf      	b.n	d0002a50 <stbi__process_marker+0x698>
d0002cb0:	1c5a      	adds	r2, r3, #1
d0002cb2:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002cb6:	781b      	ldrb	r3, [r3, #0]
d0002cb8:	e7f5      	b.n	d0002ca6 <stbi__process_marker+0x8ee>
d0002cba:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002cbe:	6220      	str	r0, [r4, #32]
d0002cc0:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002cc4:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002cc8:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002ccc:	f8d9 4000 	ldr.w	r4, [r9]
d0002cd0:	e6be      	b.n	d0002a50 <stbi__process_marker+0x698>
d0002cd2:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0002cd6:	6923      	ldr	r3, [r4, #16]
d0002cd8:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002cda:	4629      	mov	r1, r5
d0002cdc:	69e0      	ldr	r0, [r4, #28]
d0002cde:	4798      	blx	r3
d0002ce0:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002ce4:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002ce8:	4607      	mov	r7, r0
d0002cea:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002cee:	1a52      	subs	r2, r2, r1
d0002cf0:	4413      	add	r3, r2
d0002cf2:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002cf6:	b1a0      	cbz	r0, d0002d22 <stbi__process_marker+0x96a>
d0002cf8:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002cfc:	442f      	add	r7, r5
d0002cfe:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002d02:	f8c4 70b0 	str.w	r7, [r4, #176]	; 0xb0
d0002d06:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002d0a:	f8d9 4000 	ldr.w	r4, [r9]
d0002d0e:	2b49      	cmp	r3, #73	; 0x49
d0002d10:	bf0c      	ite	eq
d0002d12:	4647      	moveq	r7, r8
d0002d14:	2700      	movne	r7, #0
d0002d16:	e690      	b.n	d0002a3a <stbi__process_marker+0x682>
d0002d18:	1c5a      	adds	r2, r3, #1
d0002d1a:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002d1e:	781b      	ldrb	r3, [r3, #0]
d0002d20:	e7f5      	b.n	d0002d0e <stbi__process_marker+0x956>
d0002d22:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002d26:	6220      	str	r0, [r4, #32]
d0002d28:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002d2c:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002d30:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002d34:	f8d9 4000 	ldr.w	r4, [r9]
d0002d38:	e67f      	b.n	d0002a3a <stbi__process_marker+0x682>
d0002d3a:	f104 0728 	add.w	r7, r4, #40	; 0x28
d0002d3e:	6923      	ldr	r3, [r4, #16]
d0002d40:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002d42:	4639      	mov	r1, r7
d0002d44:	69e0      	ldr	r0, [r4, #28]
d0002d46:	4798      	blx	r3
d0002d48:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002d4c:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002d50:	4680      	mov	r8, r0
d0002d52:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002d56:	1a52      	subs	r2, r2, r1
d0002d58:	4413      	add	r3, r2
d0002d5a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002d5e:	b1a8      	cbz	r0, d0002d8c <stbi__process_marker+0x9d4>
d0002d60:	f104 0129 	add.w	r1, r4, #41	; 0x29
d0002d64:	183b      	adds	r3, r7, r0
d0002d66:	f894 2028 	ldrb.w	r2, [r4, #40]	; 0x28
d0002d6a:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002d6e:	f8c4 10ac 	str.w	r1, [r4, #172]	; 0xac
d0002d72:	f8d9 4000 	ldr.w	r4, [r9]
d0002d76:	2a46      	cmp	r2, #70	; 0x46
d0002d78:	bf0c      	ite	eq
d0002d7a:	46a8      	moveq	r8, r5
d0002d7c:	f04f 0800 	movne.w	r8, #0
d0002d80:	e650      	b.n	d0002a24 <stbi__process_marker+0x66c>
d0002d82:	1c5a      	adds	r2, r3, #1
d0002d84:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002d88:	781a      	ldrb	r2, [r3, #0]
d0002d8a:	e7f4      	b.n	d0002d76 <stbi__process_marker+0x9be>
d0002d8c:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002d90:	6220      	str	r0, [r4, #32]
d0002d92:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002d96:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002d9a:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002d9e:	f8d9 4000 	ldr.w	r4, [r9]
d0002da2:	e63f      	b.n	d0002a24 <stbi__process_marker+0x66c>
d0002da4:	f8d4 30b0 	ldr.w	r3, [r4, #176]	; 0xb0
d0002da8:	2001      	movs	r0, #1
d0002daa:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002dae:	f7ff bbe6 	b.w	d000257e <stbi__process_marker+0x1c6>
d0002db2:	1c5a      	adds	r2, r3, #1
d0002db4:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002db8:	781d      	ldrb	r5, [r3, #0]
d0002dba:	f1a5 0541 	sub.w	r5, r5, #65	; 0x41
d0002dbe:	fab5 f585 	clz	r5, r5
d0002dc2:	096d      	lsrs	r5, r5, #5
d0002dc4:	e67c      	b.n	d0002ac0 <stbi__process_marker+0x708>
d0002dc6:	1c5a      	adds	r2, r3, #1
d0002dc8:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002dcc:	781b      	ldrb	r3, [r3, #0]
d0002dce:	2b64      	cmp	r3, #100	; 0x64
d0002dd0:	bf0c      	ite	eq
d0002dd2:	462f      	moveq	r7, r5
d0002dd4:	2700      	movne	r7, #0
d0002dd6:	e67e      	b.n	d0002ad6 <stbi__process_marker+0x71e>
d0002dd8:	f104 0728 	add.w	r7, r4, #40	; 0x28
d0002ddc:	6923      	ldr	r3, [r4, #16]
d0002dde:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002de0:	4639      	mov	r1, r7
d0002de2:	69e0      	ldr	r0, [r4, #28]
d0002de4:	4798      	blx	r3
d0002de6:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002dea:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002dee:	4605      	mov	r5, r0
d0002df0:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002df4:	1a52      	subs	r2, r2, r1
d0002df6:	4413      	add	r3, r2
d0002df8:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002dfc:	2800      	cmp	r0, #0
d0002dfe:	d05b      	beq.n	d0002eb8 <stbi__process_marker+0xb00>
d0002e00:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002e04:	4407      	add	r7, r0
d0002e06:	f894 5028 	ldrb.w	r5, [r4, #40]	; 0x28
d0002e0a:	f8c4 70b0 	str.w	r7, [r4, #176]	; 0xb0
d0002e0e:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002e12:	f8d9 4000 	ldr.w	r4, [r9]
d0002e16:	e7d0      	b.n	d0002dba <stbi__process_marker+0xa02>
d0002e18:	1c5a      	adds	r2, r3, #1
d0002e1a:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002e1e:	781b      	ldrb	r3, [r3, #0]
d0002e20:	2b62      	cmp	r3, #98	; 0x62
d0002e22:	bf0c      	ite	eq
d0002e24:	462f      	moveq	r7, r5
d0002e26:	2700      	movne	r7, #0
d0002e28:	e66b      	b.n	d0002b02 <stbi__process_marker+0x74a>
d0002e2a:	1c5a      	adds	r2, r3, #1
d0002e2c:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002e30:	781b      	ldrb	r3, [r3, #0]
d0002e32:	2b6f      	cmp	r3, #111	; 0x6f
d0002e34:	bf0c      	ite	eq
d0002e36:	463d      	moveq	r5, r7
d0002e38:	2500      	movne	r5, #0
d0002e3a:	e657      	b.n	d0002aec <stbi__process_marker+0x734>
d0002e3c:	f104 0828 	add.w	r8, r4, #40	; 0x28
d0002e40:	6923      	ldr	r3, [r4, #16]
d0002e42:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002e44:	4641      	mov	r1, r8
d0002e46:	69e0      	ldr	r0, [r4, #28]
d0002e48:	4798      	blx	r3
d0002e4a:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002e4e:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002e52:	4607      	mov	r7, r0
d0002e54:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002e58:	1a52      	subs	r2, r2, r1
d0002e5a:	4413      	add	r3, r2
d0002e5c:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002e60:	b3b0      	cbz	r0, d0002ed0 <stbi__process_marker+0xb18>
d0002e62:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002e66:	4447      	add	r7, r8
d0002e68:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002e6c:	f8c4 70b0 	str.w	r7, [r4, #176]	; 0xb0
d0002e70:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002e74:	f8d9 4000 	ldr.w	r4, [r9]
d0002e78:	e7a9      	b.n	d0002dce <stbi__process_marker+0xa16>
d0002e7a:	f104 0828 	add.w	r8, r4, #40	; 0x28
d0002e7e:	6923      	ldr	r3, [r4, #16]
d0002e80:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002e82:	4641      	mov	r1, r8
d0002e84:	69e0      	ldr	r0, [r4, #28]
d0002e86:	4798      	blx	r3
d0002e88:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002e8c:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0002e90:	4605      	mov	r5, r0
d0002e92:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002e96:	1a52      	subs	r2, r2, r1
d0002e98:	4413      	add	r3, r2
d0002e9a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002e9e:	b318      	cbz	r0, d0002ee8 <stbi__process_marker+0xb30>
d0002ea0:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002ea4:	4445      	add	r5, r8
d0002ea6:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002eaa:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0002eae:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002eb2:	f8d9 4000 	ldr.w	r4, [r9]
d0002eb6:	e7bc      	b.n	d0002e32 <stbi__process_marker+0xa7a>
d0002eb8:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002ebc:	6220      	str	r0, [r4, #32]
d0002ebe:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002ec2:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002ec6:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002eca:	f8d9 4000 	ldr.w	r4, [r9]
d0002ece:	e5f7      	b.n	d0002ac0 <stbi__process_marker+0x708>
d0002ed0:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002ed4:	6220      	str	r0, [r4, #32]
d0002ed6:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002eda:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002ede:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002ee2:	f8d9 4000 	ldr.w	r4, [r9]
d0002ee6:	e5f6      	b.n	d0002ad6 <stbi__process_marker+0x71e>
d0002ee8:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002eec:	6220      	str	r0, [r4, #32]
d0002eee:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002ef2:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002ef6:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002efa:	f8d9 4000 	ldr.w	r4, [r9]
d0002efe:	e5f5      	b.n	d0002aec <stbi__process_marker+0x734>
d0002f00:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002f04:	e5c6      	b.n	d0002a94 <stbi__process_marker+0x6dc>
d0002f06:	f104 0828 	add.w	r8, r4, #40	; 0x28
d0002f0a:	6923      	ldr	r3, [r4, #16]
d0002f0c:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002f0e:	4641      	mov	r1, r8
d0002f10:	69e0      	ldr	r0, [r4, #28]
d0002f12:	4798      	blx	r3
d0002f14:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0002f18:	f8d4 70b4 	ldr.w	r7, [r4, #180]	; 0xb4
d0002f1c:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0002f20:	1bd2      	subs	r2, r2, r7
d0002f22:	4413      	add	r3, r2
d0002f24:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0002f28:	bb60      	cbnz	r0, d0002f84 <stbi__process_marker+0xbcc>
d0002f2a:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002f2e:	6220      	str	r0, [r4, #32]
d0002f30:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002f34:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0002f38:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002f3c:	f8d9 4000 	ldr.w	r4, [r9]
d0002f40:	e5f5      	b.n	d0002b2e <stbi__process_marker+0x776>
d0002f42:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0002f46:	6923      	ldr	r3, [r4, #16]
d0002f48:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002f4a:	4629      	mov	r1, r5
d0002f4c:	69e0      	ldr	r0, [r4, #28]
d0002f4e:	4798      	blx	r3
d0002f50:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002f54:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d0002f58:	f8d4 10a8 	ldr.w	r1, [r4, #168]	; 0xa8
d0002f5c:	1a9b      	subs	r3, r3, r2
d0002f5e:	4419      	add	r1, r3
d0002f60:	f8c4 10a8 	str.w	r1, [r4, #168]	; 0xa8
d0002f64:	b9f8      	cbnz	r0, d0002fa6 <stbi__process_marker+0xbee>
d0002f66:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002f6a:	6220      	str	r0, [r4, #32]
d0002f6c:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002f70:	4618      	mov	r0, r3
d0002f72:	f894 2028 	ldrb.w	r2, [r4, #40]	; 0x28
d0002f76:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0002f7a:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002f7e:	f8d9 4000 	ldr.w	r4, [r9]
d0002f82:	e5f6      	b.n	d0002b72 <stbi__process_marker+0x7ba>
d0002f84:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0002f88:	4440      	add	r0, r8
d0002f8a:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0002f8e:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0002f92:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002f96:	f8d9 4000 	ldr.w	r4, [r9]
d0002f9a:	2b00      	cmp	r3, #0
d0002f9c:	f43f adc7 	beq.w	d0002b2e <stbi__process_marker+0x776>
d0002fa0:	f1a6 0308 	sub.w	r3, r6, #8
d0002fa4:	e566      	b.n	d0002a74 <stbi__process_marker+0x6bc>
d0002fa6:	4428      	add	r0, r5
d0002fa8:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002fac:	e7e1      	b.n	d0002f72 <stbi__process_marker+0xbba>
d0002fae:	1c5a      	adds	r2, r3, #1
d0002fb0:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0002fb4:	781a      	ldrb	r2, [r3, #0]
d0002fb6:	e5dc      	b.n	d0002b72 <stbi__process_marker+0x7ba>
d0002fb8:	3301      	adds	r3, #1
d0002fba:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002fbe:	e5c4      	b.n	d0002b4a <stbi__process_marker+0x792>
d0002fc0:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0002fc4:	6923      	ldr	r3, [r4, #16]
d0002fc6:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0002fc8:	4629      	mov	r1, r5
d0002fca:	69e0      	ldr	r0, [r4, #28]
d0002fcc:	4798      	blx	r3
d0002fce:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0002fd2:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d0002fd6:	f8d4 10a8 	ldr.w	r1, [r4, #168]	; 0xa8
d0002fda:	1a9b      	subs	r3, r3, r2
d0002fdc:	4419      	add	r1, r3
d0002fde:	f8c4 10a8 	str.w	r1, [r4, #168]	; 0xa8
d0002fe2:	2800      	cmp	r0, #0
d0002fe4:	d158      	bne.n	d0003098 <stbi__process_marker+0xce0>
d0002fe6:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0002fea:	6220      	str	r0, [r4, #32]
d0002fec:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0002ff0:	4618      	mov	r0, r3
d0002ff2:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0002ff6:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0002ffa:	f8d9 4000 	ldr.w	r4, [r9]
d0002ffe:	e5a4      	b.n	d0002b4a <stbi__process_marker+0x792>
d0003000:	1c5a      	adds	r2, r3, #1
d0003002:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0003006:	781b      	ldrb	r3, [r3, #0]
d0003008:	e7c7      	b.n	d0002f9a <stbi__process_marker+0xbe2>
d000300a:	1c5a      	adds	r2, r3, #1
d000300c:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0003010:	781b      	ldrb	r3, [r3, #0]
d0003012:	2b65      	cmp	r3, #101	; 0x65
d0003014:	bf0c      	ite	eq
d0003016:	463d      	moveq	r5, r7
d0003018:	2500      	movne	r5, #0
d000301a:	e57d      	b.n	d0002b18 <stbi__process_marker+0x760>
d000301c:	f104 0828 	add.w	r8, r4, #40	; 0x28
d0003020:	6923      	ldr	r3, [r4, #16]
d0003022:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0003024:	4641      	mov	r1, r8
d0003026:	69e0      	ldr	r0, [r4, #28]
d0003028:	4798      	blx	r3
d000302a:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d000302e:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0003032:	4607      	mov	r7, r0
d0003034:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0003038:	1a52      	subs	r2, r2, r1
d000303a:	4413      	add	r3, r2
d000303c:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0003040:	b370      	cbz	r0, d00030a0 <stbi__process_marker+0xce8>
d0003042:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0003046:	4447      	add	r7, r8
d0003048:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d000304c:	f8c4 70b0 	str.w	r7, [r4, #176]	; 0xb0
d0003050:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0003054:	f8d9 4000 	ldr.w	r4, [r9]
d0003058:	e6e2      	b.n	d0002e20 <stbi__process_marker+0xa68>
d000305a:	f104 0828 	add.w	r8, r4, #40	; 0x28
d000305e:	6923      	ldr	r3, [r4, #16]
d0003060:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0003062:	4641      	mov	r1, r8
d0003064:	69e0      	ldr	r0, [r4, #28]
d0003066:	4798      	blx	r3
d0003068:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d000306c:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0003070:	4605      	mov	r5, r0
d0003072:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0003076:	1a52      	subs	r2, r2, r1
d0003078:	4413      	add	r3, r2
d000307a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d000307e:	b1d8      	cbz	r0, d00030b8 <stbi__process_marker+0xd00>
d0003080:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0003084:	4445      	add	r5, r8
d0003086:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d000308a:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d000308e:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0003092:	f8d9 4000 	ldr.w	r4, [r9]
d0003096:	e7bc      	b.n	d0003012 <stbi__process_marker+0xc5a>
d0003098:	4428      	add	r0, r5
d000309a:	f104 0329 	add.w	r3, r4, #41	; 0x29
d000309e:	e7a8      	b.n	d0002ff2 <stbi__process_marker+0xc3a>
d00030a0:	f104 0329 	add.w	r3, r4, #41	; 0x29
d00030a4:	6220      	str	r0, [r4, #32]
d00030a6:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d00030aa:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d00030ae:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d00030b2:	f8d9 4000 	ldr.w	r4, [r9]
d00030b6:	e524      	b.n	d0002b02 <stbi__process_marker+0x74a>
d00030b8:	f104 0329 	add.w	r3, r4, #41	; 0x29
d00030bc:	6220      	str	r0, [r4, #32]
d00030be:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d00030c2:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d00030c6:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d00030ca:	f8d9 4000 	ldr.w	r4, [r9]
d00030ce:	e523      	b.n	d0002b18 <stbi__process_marker+0x760>

d00030d0 <stbi__decode_jpeg_header>:
d00030d0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00030d4:	f04f 33ff 	mov.w	r3, #4294967295	; 0xffffffff
d00030d8:	4604      	mov	r4, r0
d00030da:	f244 76c4 	movw	r6, #18372	; 0x47c4
d00030de:	f244 72e4 	movw	r2, #18404	; 0x47e4
d00030e2:	2000      	movs	r0, #0
d00030e4:	460d      	mov	r5, r1
d00030e6:	55a3      	strb	r3, [r4, r6]
d00030e8:	f244 71e8 	movw	r1, #18408	; 0x47e8
d00030ec:	6826      	ldr	r6, [r4, #0]
d00030ee:	b087      	sub	sp, #28
d00030f0:	50a0      	str	r0, [r4, r2]
d00030f2:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d00030f6:	5063      	str	r3, [r4, r1]
d00030f8:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d00030fc:	429a      	cmp	r2, r3
d00030fe:	d30a      	bcc.n	d0003116 <stbi__decode_jpeg_header+0x46>
d0003100:	6a33      	ldr	r3, [r6, #32]
d0003102:	2b00      	cmp	r3, #0
d0003104:	f040 8105 	bne.w	d0003312 <stbi__decode_jpeg_header+0x242>
d0003108:	4bb1      	ldr	r3, [pc, #708]	; (d00033d0 <stbi__decode_jpeg_header+0x300>)
d000310a:	2000      	movs	r0, #0
d000310c:	4ab1      	ldr	r2, [pc, #708]	; (d00033d4 <stbi__decode_jpeg_header+0x304>)
d000310e:	601a      	str	r2, [r3, #0]
d0003110:	b007      	add	sp, #28
d0003112:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0003116:	1c53      	adds	r3, r2, #1
d0003118:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d000311c:	7813      	ldrb	r3, [r2, #0]
d000311e:	2bff      	cmp	r3, #255	; 0xff
d0003120:	d1f2      	bne.n	d0003108 <stbi__decode_jpeg_header+0x38>
d0003122:	6826      	ldr	r6, [r4, #0]
d0003124:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d0003128:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d000312c:	4293      	cmp	r3, r2
d000312e:	d321      	bcc.n	d0003174 <stbi__decode_jpeg_header+0xa4>
d0003130:	6a33      	ldr	r3, [r6, #32]
d0003132:	2b00      	cmp	r3, #0
d0003134:	d0e8      	beq.n	d0003108 <stbi__decode_jpeg_header+0x38>
d0003136:	f106 0728 	add.w	r7, r6, #40	; 0x28
d000313a:	6933      	ldr	r3, [r6, #16]
d000313c:	6a72      	ldr	r2, [r6, #36]	; 0x24
d000313e:	4639      	mov	r1, r7
d0003140:	69f0      	ldr	r0, [r6, #28]
d0003142:	4798      	blx	r3
d0003144:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d0003148:	f8d6 20b4 	ldr.w	r2, [r6, #180]	; 0xb4
d000314c:	f106 0129 	add.w	r1, r6, #41	; 0x29
d0003150:	4407      	add	r7, r0
d0003152:	1a9a      	subs	r2, r3, r2
d0003154:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0003158:	4413      	add	r3, r2
d000315a:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d000315e:	2800      	cmp	r0, #0
d0003160:	f040 80d0 	bne.w	d0003304 <stbi__decode_jpeg_header+0x234>
d0003164:	6230      	str	r0, [r6, #32]
d0003166:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000316a:	f8c6 10b0 	str.w	r1, [r6, #176]	; 0xb0
d000316e:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d0003172:	e7c9      	b.n	d0003108 <stbi__decode_jpeg_header+0x38>
d0003174:	1c5a      	adds	r2, r3, #1
d0003176:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000317a:	781b      	ldrb	r3, [r3, #0]
d000317c:	2bff      	cmp	r3, #255	; 0xff
d000317e:	d0d0      	beq.n	d0003122 <stbi__decode_jpeg_header+0x52>
d0003180:	2bd8      	cmp	r3, #216	; 0xd8
d0003182:	d1c1      	bne.n	d0003108 <stbi__decode_jpeg_header+0x38>
d0003184:	2d01      	cmp	r5, #1
d0003186:	d07a      	beq.n	d000327e <stbi__decode_jpeg_header+0x1ae>
d0003188:	f244 77c4 	movw	r7, #18372	; 0x47c4
d000318c:	4620      	mov	r0, r4
d000318e:	4427      	add	r7, r4
d0003190:	4639      	mov	r1, r7
d0003192:	f7fe fcd9 	bl	d0001b48 <stbi__get_marker.isra.0>
d0003196:	f1a0 03c0 	sub.w	r3, r0, #192	; 0xc0
d000319a:	2b02      	cmp	r3, #2
d000319c:	d927      	bls.n	d00031ee <stbi__decode_jpeg_header+0x11e>
d000319e:	f04f 08ff 	mov.w	r8, #255	; 0xff
d00031a2:	4601      	mov	r1, r0
d00031a4:	4620      	mov	r0, r4
d00031a6:	f7ff f907 	bl	d00023b8 <stbi__process_marker>
d00031aa:	2800      	cmp	r0, #0
d00031ac:	d0b0      	beq.n	d0003110 <stbi__decode_jpeg_header+0x40>
d00031ae:	4639      	mov	r1, r7
d00031b0:	4620      	mov	r0, r4
d00031b2:	f7fe fcc9 	bl	d0001b48 <stbi__get_marker.isra.0>
d00031b6:	28ff      	cmp	r0, #255	; 0xff
d00031b8:	f040 8092 	bne.w	d00032e0 <stbi__decode_jpeg_header+0x210>
d00031bc:	6826      	ldr	r6, [r4, #0]
d00031be:	6933      	ldr	r3, [r6, #16]
d00031c0:	b133      	cbz	r3, d00031d0 <stbi__decode_jpeg_header+0x100>
d00031c2:	69b3      	ldr	r3, [r6, #24]
d00031c4:	69f0      	ldr	r0, [r6, #28]
d00031c6:	4798      	blx	r3
d00031c8:	b140      	cbz	r0, d00031dc <stbi__decode_jpeg_header+0x10c>
d00031ca:	6a33      	ldr	r3, [r6, #32]
d00031cc:	2b00      	cmp	r3, #0
d00031ce:	d04f      	beq.n	d0003270 <stbi__decode_jpeg_header+0x1a0>
d00031d0:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d00031d4:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d00031d8:	429a      	cmp	r2, r3
d00031da:	d249      	bcs.n	d0003270 <stbi__decode_jpeg_header+0x1a0>
d00031dc:	7838      	ldrb	r0, [r7, #0]
d00031de:	28ff      	cmp	r0, #255	; 0xff
d00031e0:	d01e      	beq.n	d0003220 <stbi__decode_jpeg_header+0x150>
d00031e2:	f1a0 03c0 	sub.w	r3, r0, #192	; 0xc0
d00031e6:	f887 8000 	strb.w	r8, [r7]
d00031ea:	2b02      	cmp	r3, #2
d00031ec:	d8d9      	bhi.n	d00031a2 <stbi__decode_jpeg_header+0xd2>
d00031ee:	f1a0 00c2 	sub.w	r0, r0, #194	; 0xc2
d00031f2:	6826      	ldr	r6, [r4, #0]
d00031f4:	f244 73cc 	movw	r3, #18380	; 0x47cc
d00031f8:	fab0 f080 	clz	r0, r0
d00031fc:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003200:	0940      	lsrs	r0, r0, #5
d0003202:	50e0      	str	r0, [r4, r3]
d0003204:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d0003208:	429a      	cmp	r2, r3
d000320a:	f0c0 80b3 	bcc.w	d0003374 <stbi__decode_jpeg_header+0x2a4>
d000320e:	6a33      	ldr	r3, [r6, #32]
d0003210:	2b00      	cmp	r3, #0
d0003212:	f040 810c 	bne.w	d000342e <stbi__decode_jpeg_header+0x35e>
d0003216:	4b6e      	ldr	r3, [pc, #440]	; (d00033d0 <stbi__decode_jpeg_header+0x300>)
d0003218:	2000      	movs	r0, #0
d000321a:	4a6f      	ldr	r2, [pc, #444]	; (d00033d8 <stbi__decode_jpeg_header+0x308>)
d000321c:	601a      	str	r2, [r3, #0]
d000321e:	e777      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d0003220:	6826      	ldr	r6, [r4, #0]
d0003222:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d0003226:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d000322a:	4293      	cmp	r3, r2
d000322c:	d32b      	bcc.n	d0003286 <stbi__decode_jpeg_header+0x1b6>
d000322e:	6a33      	ldr	r3, [r6, #32]
d0003230:	2b00      	cmp	r3, #0
d0003232:	d0c4      	beq.n	d00031be <stbi__decode_jpeg_header+0xee>
d0003234:	f106 0928 	add.w	r9, r6, #40	; 0x28
d0003238:	6933      	ldr	r3, [r6, #16]
d000323a:	6a72      	ldr	r2, [r6, #36]	; 0x24
d000323c:	4649      	mov	r1, r9
d000323e:	69f0      	ldr	r0, [r6, #28]
d0003240:	4798      	blx	r3
d0003242:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003246:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d000324a:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d000324e:	1a52      	subs	r2, r2, r1
d0003250:	4413      	add	r3, r2
d0003252:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003256:	2800      	cmp	r0, #0
d0003258:	d177      	bne.n	d000334a <stbi__decode_jpeg_header+0x27a>
d000325a:	f106 0329 	add.w	r3, r6, #41	; 0x29
d000325e:	6230      	str	r0, [r6, #32]
d0003260:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d0003264:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d0003268:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d000326c:	6826      	ldr	r6, [r4, #0]
d000326e:	e7a6      	b.n	d00031be <stbi__decode_jpeg_header+0xee>
d0003270:	4b57      	ldr	r3, [pc, #348]	; (d00033d0 <stbi__decode_jpeg_header+0x300>)
d0003272:	2000      	movs	r0, #0
d0003274:	4a59      	ldr	r2, [pc, #356]	; (d00033dc <stbi__decode_jpeg_header+0x30c>)
d0003276:	601a      	str	r2, [r3, #0]
d0003278:	b007      	add	sp, #28
d000327a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000327e:	2001      	movs	r0, #1
d0003280:	b007      	add	sp, #28
d0003282:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0003286:	1c5a      	adds	r2, r3, #1
d0003288:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000328c:	781b      	ldrb	r3, [r3, #0]
d000328e:	2bff      	cmp	r3, #255	; 0xff
d0003290:	d195      	bne.n	d00031be <stbi__decode_jpeg_header+0xee>
d0003292:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d0003296:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d000329a:	4293      	cmp	r3, r2
d000329c:	d323      	bcc.n	d00032e6 <stbi__decode_jpeg_header+0x216>
d000329e:	6a30      	ldr	r0, [r6, #32]
d00032a0:	2800      	cmp	r0, #0
d00032a2:	f43f af7e 	beq.w	d00031a2 <stbi__decode_jpeg_header+0xd2>
d00032a6:	f106 0928 	add.w	r9, r6, #40	; 0x28
d00032aa:	6933      	ldr	r3, [r6, #16]
d00032ac:	6a72      	ldr	r2, [r6, #36]	; 0x24
d00032ae:	4649      	mov	r1, r9
d00032b0:	69f0      	ldr	r0, [r6, #28]
d00032b2:	4798      	blx	r3
d00032b4:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d00032b8:	f8d6 20b4 	ldr.w	r2, [r6, #180]	; 0xb4
d00032bc:	f106 0c29 	add.w	ip, r6, #41	; 0x29
d00032c0:	eb09 0100 	add.w	r1, r9, r0
d00032c4:	1a9a      	subs	r2, r3, r2
d00032c6:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d00032ca:	4413      	add	r3, r2
d00032cc:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d00032d0:	b988      	cbnz	r0, d00032f6 <stbi__decode_jpeg_header+0x226>
d00032d2:	6230      	str	r0, [r6, #32]
d00032d4:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d00032d8:	f8c6 c0b0 	str.w	ip, [r6, #176]	; 0xb0
d00032dc:	f8c6 c0ac 	str.w	ip, [r6, #172]	; 0xac
d00032e0:	f1a0 03c0 	sub.w	r3, r0, #192	; 0xc0
d00032e4:	e781      	b.n	d00031ea <stbi__decode_jpeg_header+0x11a>
d00032e6:	1c5a      	adds	r2, r3, #1
d00032e8:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d00032ec:	7818      	ldrb	r0, [r3, #0]
d00032ee:	28ff      	cmp	r0, #255	; 0xff
d00032f0:	d1f6      	bne.n	d00032e0 <stbi__decode_jpeg_header+0x210>
d00032f2:	6826      	ldr	r6, [r4, #0]
d00032f4:	e7cd      	b.n	d0003292 <stbi__decode_jpeg_header+0x1c2>
d00032f6:	f896 0028 	ldrb.w	r0, [r6, #40]	; 0x28
d00032fa:	f8c6 10b0 	str.w	r1, [r6, #176]	; 0xb0
d00032fe:	f8c6 c0ac 	str.w	ip, [r6, #172]	; 0xac
d0003302:	e7f4      	b.n	d00032ee <stbi__decode_jpeg_header+0x21e>
d0003304:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d0003308:	f8c6 70b0 	str.w	r7, [r6, #176]	; 0xb0
d000330c:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d0003310:	e734      	b.n	d000317c <stbi__decode_jpeg_header+0xac>
d0003312:	f106 0828 	add.w	r8, r6, #40	; 0x28
d0003316:	6933      	ldr	r3, [r6, #16]
d0003318:	6a72      	ldr	r2, [r6, #36]	; 0x24
d000331a:	4641      	mov	r1, r8
d000331c:	69f0      	ldr	r0, [r6, #28]
d000331e:	4798      	blx	r3
d0003320:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003324:	f8d6 70b4 	ldr.w	r7, [r6, #180]	; 0xb4
d0003328:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d000332c:	1bd2      	subs	r2, r2, r7
d000332e:	4413      	add	r3, r2
d0003330:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003334:	b9a0      	cbnz	r0, d0003360 <stbi__decode_jpeg_header+0x290>
d0003336:	f106 0329 	add.w	r3, r6, #41	; 0x29
d000333a:	6230      	str	r0, [r6, #32]
d000333c:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d0003340:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d0003344:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d0003348:	e6de      	b.n	d0003108 <stbi__decode_jpeg_header+0x38>
d000334a:	f106 0229 	add.w	r2, r6, #41	; 0x29
d000334e:	4448      	add	r0, r9
d0003350:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d0003354:	f8c6 00b0 	str.w	r0, [r6, #176]	; 0xb0
d0003358:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000335c:	6826      	ldr	r6, [r4, #0]
d000335e:	e796      	b.n	d000328e <stbi__decode_jpeg_header+0x1be>
d0003360:	4440      	add	r0, r8
d0003362:	f106 0229 	add.w	r2, r6, #41	; 0x29
d0003366:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d000336a:	f8c6 00b0 	str.w	r0, [r6, #176]	; 0xb0
d000336e:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d0003372:	e6d4      	b.n	d000311e <stbi__decode_jpeg_header+0x4e>
d0003374:	1c51      	adds	r1, r2, #1
d0003376:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d000337a:	7817      	ldrb	r7, [r2, #0]
d000337c:	4299      	cmp	r1, r3
d000337e:	ea4f 2707 	mov.w	r7, r7, lsl #8
d0003382:	d219      	bcs.n	d00033b8 <stbi__decode_jpeg_header+0x2e8>
d0003384:	1c4a      	adds	r2, r1, #1
d0003386:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000338a:	7809      	ldrb	r1, [r1, #0]
d000338c:	440f      	add	r7, r1
d000338e:	2f0a      	cmp	r7, #10
d0003390:	f77f af41 	ble.w	d0003216 <stbi__decode_jpeg_header+0x146>
d0003394:	429a      	cmp	r2, r3
d0003396:	d227      	bcs.n	d00033e8 <stbi__decode_jpeg_header+0x318>
d0003398:	1c53      	adds	r3, r2, #1
d000339a:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d000339e:	7813      	ldrb	r3, [r2, #0]
d00033a0:	2b08      	cmp	r3, #8
d00033a2:	d10f      	bne.n	d00033c4 <stbi__decode_jpeg_header+0x2f4>
d00033a4:	4630      	mov	r0, r6
d00033a6:	f7fe fb67 	bl	d0001a78 <stbi__get16be>
d00033aa:	6070      	str	r0, [r6, #4]
d00033ac:	2800      	cmp	r0, #0
d00033ae:	d17e      	bne.n	d00034ae <stbi__decode_jpeg_header+0x3de>
d00033b0:	4b07      	ldr	r3, [pc, #28]	; (d00033d0 <stbi__decode_jpeg_header+0x300>)
d00033b2:	4a0b      	ldr	r2, [pc, #44]	; (d00033e0 <stbi__decode_jpeg_header+0x310>)
d00033b4:	601a      	str	r2, [r3, #0]
d00033b6:	e6ab      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d00033b8:	6a33      	ldr	r3, [r6, #32]
d00033ba:	2b00      	cmp	r3, #0
d00033bc:	d158      	bne.n	d0003470 <stbi__decode_jpeg_header+0x3a0>
d00033be:	2f0a      	cmp	r7, #10
d00033c0:	f77f af29 	ble.w	d0003216 <stbi__decode_jpeg_header+0x146>
d00033c4:	4b02      	ldr	r3, [pc, #8]	; (d00033d0 <stbi__decode_jpeg_header+0x300>)
d00033c6:	2000      	movs	r0, #0
d00033c8:	4a06      	ldr	r2, [pc, #24]	; (d00033e4 <stbi__decode_jpeg_header+0x314>)
d00033ca:	601a      	str	r2, [r3, #0]
d00033cc:	e6a0      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d00033ce:	bf00      	nop
d00033d0:	d000dec8 	.word	0xd000dec8
d00033d4:	d000d39c 	.word	0xd000d39c
d00033d8:	d000d3ac 	.word	0xd000d3ac
d00033dc:	d000d3a4 	.word	0xd000d3a4
d00033e0:	d000d3c4 	.word	0xd000d3c4
d00033e4:	d000d3b8 	.word	0xd000d3b8
d00033e8:	6a33      	ldr	r3, [r6, #32]
d00033ea:	2b00      	cmp	r3, #0
d00033ec:	d0ea      	beq.n	d00033c4 <stbi__decode_jpeg_header+0x2f4>
d00033ee:	f106 0828 	add.w	r8, r6, #40	; 0x28
d00033f2:	6933      	ldr	r3, [r6, #16]
d00033f4:	6a72      	ldr	r2, [r6, #36]	; 0x24
d00033f6:	4641      	mov	r1, r8
d00033f8:	69f0      	ldr	r0, [r6, #28]
d00033fa:	4798      	blx	r3
d00033fc:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003400:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0003404:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0003408:	1a52      	subs	r2, r2, r1
d000340a:	4413      	add	r3, r2
d000340c:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003410:	2800      	cmp	r0, #0
d0003412:	d16f      	bne.n	d00034f4 <stbi__decode_jpeg_header+0x424>
d0003414:	f106 0229 	add.w	r2, r6, #41	; 0x29
d0003418:	6230      	str	r0, [r6, #32]
d000341a:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000341e:	4610      	mov	r0, r2
d0003420:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d0003424:	f8c6 00b0 	str.w	r0, [r6, #176]	; 0xb0
d0003428:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000342c:	e7b8      	b.n	d00033a0 <stbi__decode_jpeg_header+0x2d0>
d000342e:	f106 0728 	add.w	r7, r6, #40	; 0x28
d0003432:	6933      	ldr	r3, [r6, #16]
d0003434:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0003436:	4639      	mov	r1, r7
d0003438:	69f0      	ldr	r0, [r6, #28]
d000343a:	4798      	blx	r3
d000343c:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d0003440:	f8d6 20b4 	ldr.w	r2, [r6, #180]	; 0xb4
d0003444:	f8d6 10a8 	ldr.w	r1, [r6, #168]	; 0xa8
d0003448:	1a9b      	subs	r3, r3, r2
d000344a:	4419      	add	r1, r3
d000344c:	f8c6 10a8 	str.w	r1, [r6, #168]	; 0xa8
d0003450:	2800      	cmp	r0, #0
d0003452:	d146      	bne.n	d00034e2 <stbi__decode_jpeg_header+0x412>
d0003454:	f106 0229 	add.w	r2, r6, #41	; 0x29
d0003458:	6230      	str	r0, [r6, #32]
d000345a:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000345e:	4613      	mov	r3, r2
d0003460:	4611      	mov	r1, r2
d0003462:	f896 7028 	ldrb.w	r7, [r6, #40]	; 0x28
d0003466:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d000346a:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000346e:	e785      	b.n	d000337c <stbi__decode_jpeg_header+0x2ac>
d0003470:	f106 0828 	add.w	r8, r6, #40	; 0x28
d0003474:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0003476:	6933      	ldr	r3, [r6, #16]
d0003478:	4641      	mov	r1, r8
d000347a:	69f0      	ldr	r0, [r6, #28]
d000347c:	4798      	blx	r3
d000347e:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003482:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0003486:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d000348a:	1a52      	subs	r2, r2, r1
d000348c:	4413      	add	r3, r2
d000348e:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003492:	bb50      	cbnz	r0, d00034ea <stbi__decode_jpeg_header+0x41a>
d0003494:	f106 0329 	add.w	r3, r6, #41	; 0x29
d0003498:	6230      	str	r0, [r6, #32]
d000349a:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000349e:	461a      	mov	r2, r3
d00034a0:	f896 1028 	ldrb.w	r1, [r6, #40]	; 0x28
d00034a4:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d00034a8:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d00034ac:	e76e      	b.n	d000338c <stbi__decode_jpeg_header+0x2bc>
d00034ae:	4630      	mov	r0, r6
d00034b0:	f7fe fae2 	bl	d0001a78 <stbi__get16be>
d00034b4:	6030      	str	r0, [r6, #0]
d00034b6:	b330      	cbz	r0, d0003506 <stbi__decode_jpeg_header+0x436>
d00034b8:	6873      	ldr	r3, [r6, #4]
d00034ba:	f1b3 7f80 	cmp.w	r3, #16777216	; 0x1000000
d00034be:	d81d      	bhi.n	d00034fc <stbi__decode_jpeg_header+0x42c>
d00034c0:	f1b0 7f80 	cmp.w	r0, #16777216	; 0x1000000
d00034c4:	d81a      	bhi.n	d00034fc <stbi__decode_jpeg_header+0x42c>
d00034c6:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d00034ca:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d00034ce:	4293      	cmp	r3, r2
d00034d0:	f0c0 8113 	bcc.w	d00036fa <stbi__decode_jpeg_header+0x62a>
d00034d4:	6a33      	ldr	r3, [r6, #32]
d00034d6:	b9d3      	cbnz	r3, d000350e <stbi__decode_jpeg_header+0x43e>
d00034d8:	4bab      	ldr	r3, [pc, #684]	; (d0003788 <stbi__decode_jpeg_header+0x6b8>)
d00034da:	2000      	movs	r0, #0
d00034dc:	4aab      	ldr	r2, [pc, #684]	; (d000378c <stbi__decode_jpeg_header+0x6bc>)
d00034de:	601a      	str	r2, [r3, #0]
d00034e0:	e616      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d00034e2:	183b      	adds	r3, r7, r0
d00034e4:	f106 0229 	add.w	r2, r6, #41	; 0x29
d00034e8:	e7ba      	b.n	d0003460 <stbi__decode_jpeg_header+0x390>
d00034ea:	eb08 0300 	add.w	r3, r8, r0
d00034ee:	f106 0229 	add.w	r2, r6, #41	; 0x29
d00034f2:	e7d5      	b.n	d00034a0 <stbi__decode_jpeg_header+0x3d0>
d00034f4:	4440      	add	r0, r8
d00034f6:	f106 0229 	add.w	r2, r6, #41	; 0x29
d00034fa:	e791      	b.n	d0003420 <stbi__decode_jpeg_header+0x350>
d00034fc:	4ba2      	ldr	r3, [pc, #648]	; (d0003788 <stbi__decode_jpeg_header+0x6b8>)
d00034fe:	2000      	movs	r0, #0
d0003500:	4aa3      	ldr	r2, [pc, #652]	; (d0003790 <stbi__decode_jpeg_header+0x6c0>)
d0003502:	601a      	str	r2, [r3, #0]
d0003504:	e604      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d0003506:	4ba0      	ldr	r3, [pc, #640]	; (d0003788 <stbi__decode_jpeg_header+0x6b8>)
d0003508:	4aa2      	ldr	r2, [pc, #648]	; (d0003794 <stbi__decode_jpeg_header+0x6c4>)
d000350a:	601a      	str	r2, [r3, #0]
d000350c:	e600      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d000350e:	f106 0828 	add.w	r8, r6, #40	; 0x28
d0003512:	6933      	ldr	r3, [r6, #16]
d0003514:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0003516:	4641      	mov	r1, r8
d0003518:	69f0      	ldr	r0, [r6, #28]
d000351a:	4798      	blx	r3
d000351c:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003520:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0003524:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0003528:	1a52      	subs	r2, r2, r1
d000352a:	4413      	add	r3, r2
d000352c:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003530:	2800      	cmp	r0, #0
d0003532:	f040 80de 	bne.w	d00036f2 <stbi__decode_jpeg_header+0x622>
d0003536:	f106 0229 	add.w	r2, r6, #41	; 0x29
d000353a:	6230      	str	r0, [r6, #32]
d000353c:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d0003540:	4610      	mov	r0, r2
d0003542:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d0003546:	f8c6 00b0 	str.w	r0, [r6, #176]	; 0xb0
d000354a:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d000354e:	1eda      	subs	r2, r3, #3
d0003550:	2a01      	cmp	r2, #1
d0003552:	d901      	bls.n	d0003558 <stbi__decode_jpeg_header+0x488>
d0003554:	2b01      	cmp	r3, #1
d0003556:	d1bf      	bne.n	d00034d8 <stbi__decode_jpeg_header+0x408>
d0003558:	f244 62c8 	movw	r2, #18120	; 0x46c8
d000355c:	2100      	movs	r1, #0
d000355e:	60b3      	str	r3, [r6, #8]
d0003560:	4422      	add	r2, r4
d0003562:	4608      	mov	r0, r1
d0003564:	e003      	b.n	d000356e <stbi__decode_jpeg_header+0x49e>
d0003566:	f842 0c48 	str.w	r0, [r2, #-72]
d000356a:	f842 0c3c 	str.w	r0, [r2, #-60]
d000356e:	428b      	cmp	r3, r1
d0003570:	f102 0248 	add.w	r2, r2, #72	; 0x48
d0003574:	f101 0101 	add.w	r1, r1, #1
d0003578:	dcf5      	bgt.n	d0003566 <stbi__decode_jpeg_header+0x496>
d000357a:	2203      	movs	r2, #3
d000357c:	2108      	movs	r1, #8
d000357e:	fb12 1303 	smlabb	r3, r2, r3, r1
d0003582:	42bb      	cmp	r3, r7
d0003584:	f47f ae47 	bne.w	d0003216 <stbi__decode_jpeg_header+0x146>
d0003588:	f244 73ec 	movw	r3, #18412	; 0x47ec
d000358c:	f106 0929 	add.w	r9, r6, #41	; 0x29
d0003590:	2700      	movs	r7, #0
d0003592:	f244 689c 	movw	r8, #18076	; 0x469c
d0003596:	f8df a20c 	ldr.w	sl, [pc, #524]	; d00037a4 <stbi__decode_jpeg_header+0x6d4>
d000359a:	50e7      	str	r7, [r4, r3]
d000359c:	464b      	mov	r3, r9
d000359e:	44a0      	add	r8, r4
d00035a0:	46a9      	mov	r9, r5
d00035a2:	461d      	mov	r5, r3
d00035a4:	68b3      	ldr	r3, [r6, #8]
d00035a6:	429f      	cmp	r7, r3
d00035a8:	f280 80ac 	bge.w	d0003704 <stbi__decode_jpeg_header+0x634>
d00035ac:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d00035b0:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d00035b4:	429a      	cmp	r2, r3
d00035b6:	d318      	bcc.n	d00035ea <stbi__decode_jpeg_header+0x51a>
d00035b8:	6a30      	ldr	r0, [r6, #32]
d00035ba:	2800      	cmp	r0, #0
d00035bc:	d158      	bne.n	d0003670 <stbi__decode_jpeg_header+0x5a0>
d00035be:	f8c8 0000 	str.w	r0, [r8]
d00035c2:	68b1      	ldr	r1, [r6, #8]
d00035c4:	2903      	cmp	r1, #3
d00035c6:	d037      	beq.n	d0003638 <stbi__decode_jpeg_header+0x568>
d00035c8:	429a      	cmp	r2, r3
d00035ca:	d314      	bcc.n	d00035f6 <stbi__decode_jpeg_header+0x526>
d00035cc:	6a33      	ldr	r3, [r6, #32]
d00035ce:	2b00      	cmp	r3, #0
d00035d0:	f040 8176 	bne.w	d00038c0 <stbi__decode_jpeg_header+0x7f0>
d00035d4:	2148      	movs	r1, #72	; 0x48
d00035d6:	f244 62a0 	movw	r2, #18080	; 0x46a0
d00035da:	fb01 4407 	mla	r4, r1, r7, r4
d00035de:	50a3      	str	r3, [r4, r2]
d00035e0:	4b69      	ldr	r3, [pc, #420]	; (d0003788 <stbi__decode_jpeg_header+0x6b8>)
d00035e2:	2000      	movs	r0, #0
d00035e4:	4a6c      	ldr	r2, [pc, #432]	; (d0003798 <stbi__decode_jpeg_header+0x6c8>)
d00035e6:	601a      	str	r2, [r3, #0]
d00035e8:	e592      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d00035ea:	1c51      	adds	r1, r2, #1
d00035ec:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d00035f0:	7810      	ldrb	r0, [r2, #0]
d00035f2:	460a      	mov	r2, r1
d00035f4:	e7e3      	b.n	d00035be <stbi__decode_jpeg_header+0x4ee>
d00035f6:	1c53      	adds	r3, r2, #1
d00035f8:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d00035fc:	7813      	ldrb	r3, [r2, #0]
d00035fe:	111a      	asrs	r2, r3, #4
d0003600:	f8c8 2004 	str.w	r2, [r8, #4]
d0003604:	2a00      	cmp	r2, #0
d0003606:	d0eb      	beq.n	d00035e0 <stbi__decode_jpeg_header+0x510>
d0003608:	2a04      	cmp	r2, #4
d000360a:	dce9      	bgt.n	d00035e0 <stbi__decode_jpeg_header+0x510>
d000360c:	f003 030f 	and.w	r3, r3, #15
d0003610:	1e5a      	subs	r2, r3, #1
d0003612:	f8c8 3008 	str.w	r3, [r8, #8]
d0003616:	2a03      	cmp	r2, #3
d0003618:	d825      	bhi.n	d0003666 <stbi__decode_jpeg_header+0x596>
d000361a:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d000361e:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d0003622:	4293      	cmp	r3, r2
d0003624:	d312      	bcc.n	d000364c <stbi__decode_jpeg_header+0x57c>
d0003626:	6a33      	ldr	r3, [r6, #32]
d0003628:	2b00      	cmp	r3, #0
d000362a:	d13f      	bne.n	d00036ac <stbi__decode_jpeg_header+0x5dc>
d000362c:	f8c8 300c 	str.w	r3, [r8, #12]
d0003630:	3701      	adds	r7, #1
d0003632:	f108 0848 	add.w	r8, r8, #72	; 0x48
d0003636:	e7b5      	b.n	d00035a4 <stbi__decode_jpeg_header+0x4d4>
d0003638:	f817 100a 	ldrb.w	r1, [r7, sl]
d000363c:	4288      	cmp	r0, r1
d000363e:	d1c3      	bne.n	d00035c8 <stbi__decode_jpeg_header+0x4f8>
d0003640:	f244 70ec 	movw	r0, #18412	; 0x47ec
d0003644:	5821      	ldr	r1, [r4, r0]
d0003646:	3101      	adds	r1, #1
d0003648:	5021      	str	r1, [r4, r0]
d000364a:	e7bd      	b.n	d00035c8 <stbi__decode_jpeg_header+0x4f8>
d000364c:	1c5a      	adds	r2, r3, #1
d000364e:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d0003652:	781a      	ldrb	r2, [r3, #0]
d0003654:	2a03      	cmp	r2, #3
d0003656:	f8c8 200c 	str.w	r2, [r8, #12]
d000365a:	dde9      	ble.n	d0003630 <stbi__decode_jpeg_header+0x560>
d000365c:	4b4a      	ldr	r3, [pc, #296]	; (d0003788 <stbi__decode_jpeg_header+0x6b8>)
d000365e:	2000      	movs	r0, #0
d0003660:	4a4e      	ldr	r2, [pc, #312]	; (d000379c <stbi__decode_jpeg_header+0x6cc>)
d0003662:	601a      	str	r2, [r3, #0]
d0003664:	e554      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d0003666:	4b48      	ldr	r3, [pc, #288]	; (d0003788 <stbi__decode_jpeg_header+0x6b8>)
d0003668:	2000      	movs	r0, #0
d000366a:	4a4d      	ldr	r2, [pc, #308]	; (d00037a0 <stbi__decode_jpeg_header+0x6d0>)
d000366c:	601a      	str	r2, [r3, #0]
d000366e:	e54f      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d0003670:	f106 0b28 	add.w	fp, r6, #40	; 0x28
d0003674:	6933      	ldr	r3, [r6, #16]
d0003676:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0003678:	4659      	mov	r1, fp
d000367a:	69f0      	ldr	r0, [r6, #28]
d000367c:	4798      	blx	r3
d000367e:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003682:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0003686:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d000368a:	1a52      	subs	r2, r2, r1
d000368c:	4413      	add	r3, r2
d000368e:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003692:	bb40      	cbnz	r0, d00036e6 <stbi__decode_jpeg_header+0x616>
d0003694:	462b      	mov	r3, r5
d0003696:	6230      	str	r0, [r6, #32]
d0003698:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000369c:	462a      	mov	r2, r5
d000369e:	f896 0028 	ldrb.w	r0, [r6, #40]	; 0x28
d00036a2:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d00036a6:	f8c6 50ac 	str.w	r5, [r6, #172]	; 0xac
d00036aa:	e788      	b.n	d00035be <stbi__decode_jpeg_header+0x4ee>
d00036ac:	f106 0b28 	add.w	fp, r6, #40	; 0x28
d00036b0:	6933      	ldr	r3, [r6, #16]
d00036b2:	6a72      	ldr	r2, [r6, #36]	; 0x24
d00036b4:	4659      	mov	r1, fp
d00036b6:	69f0      	ldr	r0, [r6, #28]
d00036b8:	4798      	blx	r3
d00036ba:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d00036be:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d00036c2:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d00036c6:	1a52      	subs	r2, r2, r1
d00036c8:	4413      	add	r3, r2
d00036ca:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d00036ce:	b968      	cbnz	r0, d00036ec <stbi__decode_jpeg_header+0x61c>
d00036d0:	462b      	mov	r3, r5
d00036d2:	6230      	str	r0, [r6, #32]
d00036d4:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d00036d8:	f896 2028 	ldrb.w	r2, [r6, #40]	; 0x28
d00036dc:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d00036e0:	f8c6 50ac 	str.w	r5, [r6, #172]	; 0xac
d00036e4:	e7b6      	b.n	d0003654 <stbi__decode_jpeg_header+0x584>
d00036e6:	eb0b 0300 	add.w	r3, fp, r0
d00036ea:	e7d7      	b.n	d000369c <stbi__decode_jpeg_header+0x5cc>
d00036ec:	eb0b 0300 	add.w	r3, fp, r0
d00036f0:	e7f2      	b.n	d00036d8 <stbi__decode_jpeg_header+0x608>
d00036f2:	4440      	add	r0, r8
d00036f4:	f106 0229 	add.w	r2, r6, #41	; 0x29
d00036f8:	e723      	b.n	d0003542 <stbi__decode_jpeg_header+0x472>
d00036fa:	1c5a      	adds	r2, r3, #1
d00036fc:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d0003700:	781b      	ldrb	r3, [r3, #0]
d0003702:	e724      	b.n	d000354e <stbi__decode_jpeg_header+0x47e>
d0003704:	464d      	mov	r5, r9
d0003706:	469b      	mov	fp, r3
d0003708:	2d00      	cmp	r5, #0
d000370a:	f47f adb8 	bne.w	d000327e <stbi__decode_jpeg_header+0x1ae>
d000370e:	f8d6 a000 	ldr.w	sl, [r6]
d0003712:	6871      	ldr	r1, [r6, #4]
d0003714:	f1ba 0f00 	cmp.w	sl, #0
d0003718:	f6ff aef0 	blt.w	d00034fc <stbi__decode_jpeg_header+0x42c>
d000371c:	2900      	cmp	r1, #0
d000371e:	f6ff aeed 	blt.w	d00034fc <stbi__decode_jpeg_header+0x42c>
d0003722:	b131      	cbz	r1, d0003732 <stbi__decode_jpeg_header+0x662>
d0003724:	f06f 4300 	mvn.w	r3, #2147483648	; 0x80000000
d0003728:	fb93 f3f1 	sdiv	r3, r3, r1
d000372c:	459a      	cmp	sl, r3
d000372e:	f73f aee5 	bgt.w	d00034fc <stbi__decode_jpeg_header+0x42c>
d0003732:	f1bb 0f00 	cmp.w	fp, #0
d0003736:	f6ff aee1 	blt.w	d00034fc <stbi__decode_jpeg_header+0x42c>
d000373a:	f000 80de 	beq.w	d00038fa <stbi__decode_jpeg_header+0x82a>
d000373e:	f06f 4300 	mvn.w	r3, #2147483648	; 0x80000000
d0003742:	fb01 f20a 	mul.w	r2, r1, sl
d0003746:	fb93 f3fb 	sdiv	r3, r3, fp
d000374a:	429a      	cmp	r2, r3
d000374c:	f73f aed6 	bgt.w	d00034fc <stbi__decode_jpeg_header+0x42c>
d0003750:	f244 66a0 	movw	r6, #18080	; 0x46a0
d0003754:	f04f 0801 	mov.w	r8, #1
d0003758:	2700      	movs	r7, #0
d000375a:	4426      	add	r6, r4
d000375c:	46c1      	mov	r9, r8
d000375e:	4630      	mov	r0, r6
d0003760:	e009      	b.n	d0003776 <stbi__decode_jpeg_header+0x6a6>
d0003762:	f850 2c48 	ldr.w	r2, [r0, #-72]
d0003766:	f850 3c44 	ldr.w	r3, [r0, #-68]
d000376a:	4591      	cmp	r9, r2
d000376c:	bfb8      	it	lt
d000376e:	4691      	movlt	r9, r2
d0003770:	4598      	cmp	r8, r3
d0003772:	bfb8      	it	lt
d0003774:	4698      	movlt	r8, r3
d0003776:	45bb      	cmp	fp, r7
d0003778:	f100 0048 	add.w	r0, r0, #72	; 0x48
d000377c:	f107 0701 	add.w	r7, r7, #1
d0003780:	d1ef      	bne.n	d0003762 <stbi__decode_jpeg_header+0x692>
d0003782:	2200      	movs	r2, #0
d0003784:	4633      	mov	r3, r6
d0003786:	e021      	b.n	d00037cc <stbi__decode_jpeg_header+0x6fc>
d0003788:	d000dec8 	.word	0xd000dec8
d000378c:	d000d3ec 	.word	0xd000d3ec
d0003790:	d000d3e0 	.word	0xd000d3e0
d0003794:	d000d3d8 	.word	0xd000d3d8
d0003798:	d000d400 	.word	0xd000d400
d000379c:	d000d410 	.word	0xd000d410
d00037a0:	d000d408 	.word	0xd000d408
d00037a4:	d000d4c0 	.word	0xd000d4c0
d00037a8:	681f      	ldr	r7, [r3, #0]
d00037aa:	3348      	adds	r3, #72	; 0x48
d00037ac:	fb99 f0f7 	sdiv	r0, r9, r7
d00037b0:	fb07 9010 	mls	r0, r7, r0, r9
d00037b4:	2800      	cmp	r0, #0
d00037b6:	f47f af13 	bne.w	d00035e0 <stbi__decode_jpeg_header+0x510>
d00037ba:	f8dc 7004 	ldr.w	r7, [ip, #4]
d00037be:	fb98 f0f7 	sdiv	r0, r8, r7
d00037c2:	fb07 8010 	mls	r0, r7, r0, r8
d00037c6:	2800      	cmp	r0, #0
d00037c8:	f47f af4d 	bne.w	d0003666 <stbi__decode_jpeg_header+0x596>
d00037cc:	4593      	cmp	fp, r2
d00037ce:	469c      	mov	ip, r3
d00037d0:	f102 0201 	add.w	r2, r2, #1
d00037d4:	d1e8      	bne.n	d00037a8 <stbi__decode_jpeg_header+0x6d8>
d00037d6:	ea4f 03c8 	mov.w	r3, r8, lsl #3
d00037da:	1e4a      	subs	r2, r1, #1
d00037dc:	ea4f 00c9 	mov.w	r0, r9, lsl #3
d00037e0:	f10a 3cff 	add.w	ip, sl, #4294967295	; 0xffffffff
d00037e4:	441a      	add	r2, r3
d00037e6:	f244 6794 	movw	r7, #18068	; 0x4694
d00037ea:	4484      	add	ip, r0
d00037ec:	9105      	str	r1, [sp, #20]
d00037ee:	51e0      	str	r0, [r4, r7]
d00037f0:	f244 678c 	movw	r7, #18060	; 0x468c
d00037f4:	9401      	str	r4, [sp, #4]
d00037f6:	fbb2 f2f3 	udiv	r2, r2, r3
d00037fa:	fbbc f0f0 	udiv	r0, ip, r0
d00037fe:	9202      	str	r2, [sp, #8]
d0003800:	f244 6298 	movw	r2, #18072	; 0x4698
d0003804:	51e0      	str	r0, [r4, r7]
d0003806:	f244 6790 	movw	r7, #18064	; 0x4690
d000380a:	50a3      	str	r3, [r4, r2]
d000380c:	f244 6388 	movw	r3, #18056	; 0x4688
d0003810:	9a02      	ldr	r2, [sp, #8]
d0003812:	9003      	str	r0, [sp, #12]
d0003814:	f244 6084 	movw	r0, #18052	; 0x4684
d0003818:	51e2      	str	r2, [r4, r7]
d000381a:	f244 72cc 	movw	r2, #18380	; 0x47cc
d000381e:	f844 9000 	str.w	r9, [r4, r0]
d0003822:	f844 8003 	str.w	r8, [r4, r3]
d0003826:	18a3      	adds	r3, r4, r2
d0003828:	9304      	str	r3, [sp, #16]
d000382a:	462b      	mov	r3, r5
d000382c:	4645      	mov	r5, r8
d000382e:	46c8      	mov	r8, r9
d0003830:	4699      	mov	r9, r3
d0003832:	45cb      	cmp	fp, r9
d0003834:	f43f ad23 	beq.w	d000327e <stbi__decode_jpeg_header+0x1ae>
d0003838:	6834      	ldr	r4, [r6, #0]
d000383a:	f108 30ff 	add.w	r0, r8, #4294967295	; 0xffffffff
d000383e:	6877      	ldr	r7, [r6, #4]
d0003840:	1e6b      	subs	r3, r5, #1
d0003842:	fb0a 0004 	mla	r0, sl, r4, r0
d0003846:	9a05      	ldr	r2, [sp, #20]
d0003848:	fbb0 f0f8 	udiv	r0, r0, r8
d000384c:	fb02 3307 	mla	r3, r2, r7, r3
d0003850:	9a03      	ldr	r2, [sp, #12]
d0003852:	61b0      	str	r0, [r6, #24]
d0003854:	2000      	movs	r0, #0
d0003856:	fb04 f402 	mul.w	r4, r4, r2
d000385a:	9a02      	ldr	r2, [sp, #8]
d000385c:	63b0      	str	r0, [r6, #56]	; 0x38
d000385e:	00e4      	lsls	r4, r4, #3
d0003860:	fb07 f702 	mul.w	r7, r7, r2
d0003864:	6330      	str	r0, [r6, #48]	; 0x30
d0003866:	00ff      	lsls	r7, r7, #3
d0003868:	4284      	cmp	r4, r0
d000386a:	6234      	str	r4, [r6, #32]
d000386c:	6277      	str	r7, [r6, #36]	; 0x24
d000386e:	6370      	str	r0, [r6, #52]	; 0x34
d0003870:	fbb3 f3f5 	udiv	r3, r3, r5
d0003874:	61f3      	str	r3, [r6, #28]
d0003876:	db5d      	blt.n	d0003934 <stbi__decode_jpeg_header+0x864>
d0003878:	ea5f 7cd7 	movs.w	ip, r7, lsr #31
d000387c:	d15a      	bne.n	d0003934 <stbi__decode_jpeg_header+0x864>
d000387e:	2f00      	cmp	r7, #0
d0003880:	d045      	beq.n	d000390e <stbi__decode_jpeg_header+0x83e>
d0003882:	f06f 4300 	mvn.w	r3, #2147483648	; 0x80000000
d0003886:	fb93 f3f7 	sdiv	r3, r3, r7
d000388a:	429c      	cmp	r4, r3
d000388c:	dc04      	bgt.n	d0003898 <stbi__decode_jpeg_header+0x7c8>
d000388e:	fb07 f004 	mul.w	r0, r7, r4
d0003892:	4b44      	ldr	r3, [pc, #272]	; (d00039a4 <stbi__decode_jpeg_header+0x8d4>)
d0003894:	4298      	cmp	r0, r3
d0003896:	dd3b      	ble.n	d0003910 <stbi__decode_jpeg_header+0x840>
d0003898:	9c01      	ldr	r4, [sp, #4]
d000389a:	2348      	movs	r3, #72	; 0x48
d000389c:	f244 62cc 	movw	r2, #18124	; 0x46cc
d00038a0:	464d      	mov	r5, r9
d00038a2:	fb03 4309 	mla	r3, r3, r9, r4
d00038a6:	f843 c002 	str.w	ip, [r3, r2]
d00038aa:	4b3f      	ldr	r3, [pc, #252]	; (d00039a8 <stbi__decode_jpeg_header+0x8d8>)
d00038ac:	1c69      	adds	r1, r5, #1
d00038ae:	4a3f      	ldr	r2, [pc, #252]	; (d00039ac <stbi__decode_jpeg_header+0x8dc>)
d00038b0:	4620      	mov	r0, r4
d00038b2:	601a      	str	r2, [r3, #0]
d00038b4:	f7fe f8bc 	bl	d0001a30 <stbi__free_jpeg_components.constprop.0>
d00038b8:	3800      	subs	r0, #0
d00038ba:	bf18      	it	ne
d00038bc:	2001      	movne	r0, #1
d00038be:	e427      	b.n	d0003110 <stbi__decode_jpeg_header+0x40>
d00038c0:	f106 0b28 	add.w	fp, r6, #40	; 0x28
d00038c4:	6933      	ldr	r3, [r6, #16]
d00038c6:	6a72      	ldr	r2, [r6, #36]	; 0x24
d00038c8:	4659      	mov	r1, fp
d00038ca:	69f0      	ldr	r0, [r6, #28]
d00038cc:	4798      	blx	r3
d00038ce:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d00038d2:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d00038d6:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d00038da:	1a52      	subs	r2, r2, r1
d00038dc:	4413      	add	r3, r2
d00038de:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d00038e2:	b988      	cbnz	r0, d0003908 <stbi__decode_jpeg_header+0x838>
d00038e4:	462a      	mov	r2, r5
d00038e6:	6230      	str	r0, [r6, #32]
d00038e8:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d00038ec:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d00038f0:	f8c6 20b0 	str.w	r2, [r6, #176]	; 0xb0
d00038f4:	f8c6 50ac 	str.w	r5, [r6, #172]	; 0xac
d00038f8:	e681      	b.n	d00035fe <stbi__decode_jpeg_header+0x52e>
d00038fa:	f04f 0801 	mov.w	r8, #1
d00038fe:	f244 66a0 	movw	r6, #18080	; 0x46a0
d0003902:	46c1      	mov	r9, r8
d0003904:	4426      	add	r6, r4
d0003906:	e73c      	b.n	d0003782 <stbi__decode_jpeg_header+0x6b2>
d0003908:	eb0b 0200 	add.w	r2, fp, r0
d000390c:	e7ee      	b.n	d00038ec <stbi__decode_jpeg_header+0x81c>
d000390e:	4638      	mov	r0, r7
d0003910:	300f      	adds	r0, #15
d0003912:	f008 f95b 	bl	d000bbcc <malloc>
d0003916:	62f0      	str	r0, [r6, #44]	; 0x2c
d0003918:	2800      	cmp	r0, #0
d000391a:	d040      	beq.n	d000399e <stbi__decode_jpeg_header+0x8ce>
d000391c:	f100 030f 	add.w	r3, r0, #15
d0003920:	9a04      	ldr	r2, [sp, #16]
d0003922:	f023 030f 	bic.w	r3, r3, #15
d0003926:	6810      	ldr	r0, [r2, #0]
d0003928:	62b3      	str	r3, [r6, #40]	; 0x28
d000392a:	b968      	cbnz	r0, d0003948 <stbi__decode_jpeg_header+0x878>
d000392c:	f109 0901 	add.w	r9, r9, #1
d0003930:	3648      	adds	r6, #72	; 0x48
d0003932:	e77e      	b.n	d0003832 <stbi__decode_jpeg_header+0x762>
d0003934:	9c01      	ldr	r4, [sp, #4]
d0003936:	2348      	movs	r3, #72	; 0x48
d0003938:	f244 62cc 	movw	r2, #18124	; 0x46cc
d000393c:	2100      	movs	r1, #0
d000393e:	fb03 4309 	mla	r3, r3, r9, r4
d0003942:	464d      	mov	r5, r9
d0003944:	5099      	str	r1, [r3, r2]
d0003946:	e7b0      	b.n	d00038aa <stbi__decode_jpeg_header+0x7da>
d0003948:	10e0      	asrs	r0, r4, #3
d000394a:	10fb      	asrs	r3, r7, #3
d000394c:	63f0      	str	r0, [r6, #60]	; 0x3c
d000394e:	6433      	str	r3, [r6, #64]	; 0x40
d0003950:	b1cf      	cbz	r7, d0003986 <stbi__decode_jpeg_header+0x8b6>
d0003952:	f06f 4300 	mvn.w	r3, #2147483648	; 0x80000000
d0003956:	fb93 f3f7 	sdiv	r3, r3, r7
d000395a:	429c      	cmp	r4, r3
d000395c:	dc04      	bgt.n	d0003968 <stbi__decode_jpeg_header+0x898>
d000395e:	fb07 f304 	mul.w	r3, r7, r4
d0003962:	f1b3 4f80 	cmp.w	r3, #1073741824	; 0x40000000
d0003966:	db09      	blt.n	d000397c <stbi__decode_jpeg_header+0x8ac>
d0003968:	9c01      	ldr	r4, [sp, #4]
d000396a:	2348      	movs	r3, #72	; 0x48
d000396c:	f244 62d0 	movw	r2, #18128	; 0x46d0
d0003970:	2100      	movs	r1, #0
d0003972:	fb03 4309 	mla	r3, r3, r9, r4
d0003976:	464d      	mov	r5, r9
d0003978:	5099      	str	r1, [r3, r2]
d000397a:	e796      	b.n	d00038aa <stbi__decode_jpeg_header+0x7da>
d000397c:	4a09      	ldr	r2, [pc, #36]	; (d00039a4 <stbi__decode_jpeg_header+0x8d4>)
d000397e:	005f      	lsls	r7, r3, #1
d0003980:	ebb2 0f43 	cmp.w	r2, r3, lsl #1
d0003984:	dbf0      	blt.n	d0003968 <stbi__decode_jpeg_header+0x898>
d0003986:	f107 000f 	add.w	r0, r7, #15
d000398a:	f008 f91f 	bl	d000bbcc <malloc>
d000398e:	6330      	str	r0, [r6, #48]	; 0x30
d0003990:	b128      	cbz	r0, d000399e <stbi__decode_jpeg_header+0x8ce>
d0003992:	f100 030f 	add.w	r3, r0, #15
d0003996:	f023 030f 	bic.w	r3, r3, #15
d000399a:	63b3      	str	r3, [r6, #56]	; 0x38
d000399c:	e7c6      	b.n	d000392c <stbi__decode_jpeg_header+0x85c>
d000399e:	9c01      	ldr	r4, [sp, #4]
d00039a0:	464d      	mov	r5, r9
d00039a2:	e782      	b.n	d00038aa <stbi__decode_jpeg_header+0x7da>
d00039a4:	7ffffff0 	.word	0x7ffffff0
d00039a8:	d000dec8 	.word	0xd000dec8
d00039ac:	d000d418 	.word	0xd000d418

d00039b0 <load_jpeg_image.constprop.0>:
d00039b0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00039b4:	ed2d 8b02 	vpush	{d8}
d00039b8:	b0c5      	sub	sp, #276	; 0x114
d00039ba:	2400      	movs	r4, #0
d00039bc:	931d      	str	r3, [sp, #116]	; 0x74
d00039be:	9b50      	ldr	r3, [sp, #320]	; 0x140
d00039c0:	911b      	str	r1, [sp, #108]	; 0x6c
d00039c2:	2b04      	cmp	r3, #4
d00039c4:	6801      	ldr	r1, [r0, #0]
d00039c6:	921c      	str	r2, [sp, #112]	; 0x70
d00039c8:	608c      	str	r4, [r1, #8]
d00039ca:	f200 82e4 	bhi.w	d0003f96 <load_jpeg_image.constprop.0+0x5e6>
d00039ce:	f244 63cc 	movw	r3, #18124	; 0x46cc
d00039d2:	f244 65d0 	movw	r5, #18128	; 0x46d0
d00039d6:	f244 7114 	movw	r1, #18196	; 0x4714
d00039da:	f244 7218 	movw	r2, #18200	; 0x4718
d00039de:	50c4      	str	r4, [r0, r3]
d00039e0:	f244 735c 	movw	r3, #18268	; 0x475c
d00039e4:	5144      	str	r4, [r0, r5]
d00039e6:	f244 7560 	movw	r5, #18272	; 0x4760
d00039ea:	5044      	str	r4, [r0, r1]
d00039ec:	f244 71a4 	movw	r1, #18340	; 0x47a4
d00039f0:	5084      	str	r4, [r0, r2]
d00039f2:	f244 72a8 	movw	r2, #18344	; 0x47a8
d00039f6:	50c4      	str	r4, [r0, r3]
d00039f8:	f644 0304 	movw	r3, #18436	; 0x4804
d00039fc:	5144      	str	r4, [r0, r5]
d00039fe:	4682      	mov	sl, r0
d0003a00:	5044      	str	r4, [r0, r1]
d0003a02:	4621      	mov	r1, r4
d0003a04:	5084      	str	r4, [r0, r2]
d0003a06:	50c4      	str	r4, [r0, r3]
d0003a08:	f7ff fb62 	bl	d00030d0 <stbi__decode_jpeg_header>
d0003a0c:	bb50      	cbnz	r0, d0003a64 <load_jpeg_image.constprop.0+0xb4>
d0003a0e:	f8da 3000 	ldr.w	r3, [sl]
d0003a12:	f8d3 c008 	ldr.w	ip, [r3, #8]
d0003a16:	f1bc 0f00 	cmp.w	ip, #0
d0003a1a:	dd1b      	ble.n	d0003a54 <load_jpeg_image.constprop.0+0xa4>
d0003a1c:	f244 64c8 	movw	r4, #18120	; 0x46c8
d0003a20:	eb0c 0ccc 	add.w	ip, ip, ip, lsl #3
d0003a24:	2500      	movs	r5, #0
d0003a26:	4454      	add	r4, sl
d0003a28:	eb04 06cc 	add.w	r6, r4, ip, lsl #3
d0003a2c:	6860      	ldr	r0, [r4, #4]
d0003a2e:	b118      	cbz	r0, d0003a38 <load_jpeg_image.constprop.0+0x88>
d0003a30:	f008 f8d4 	bl	d000bbdc <free>
d0003a34:	6065      	str	r5, [r4, #4]
d0003a36:	6025      	str	r5, [r4, #0]
d0003a38:	68a0      	ldr	r0, [r4, #8]
d0003a3a:	b118      	cbz	r0, d0003a44 <load_jpeg_image.constprop.0+0x94>
d0003a3c:	f008 f8ce 	bl	d000bbdc <free>
d0003a40:	60a5      	str	r5, [r4, #8]
d0003a42:	6125      	str	r5, [r4, #16]
d0003a44:	68e0      	ldr	r0, [r4, #12]
d0003a46:	b110      	cbz	r0, d0003a4e <load_jpeg_image.constprop.0+0x9e>
d0003a48:	f008 f8c8 	bl	d000bbdc <free>
d0003a4c:	60e5      	str	r5, [r4, #12]
d0003a4e:	3448      	adds	r4, #72	; 0x48
d0003a50:	42b4      	cmp	r4, r6
d0003a52:	d1eb      	bne.n	d0003a2c <load_jpeg_image.constprop.0+0x7c>
d0003a54:	2300      	movs	r3, #0
d0003a56:	9308      	str	r3, [sp, #32]
d0003a58:	9808      	ldr	r0, [sp, #32]
d0003a5a:	b045      	add	sp, #276	; 0x114
d0003a5c:	ecbd 8b02 	vpop	{d8}
d0003a60:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0003a64:	f244 73c4 	movw	r3, #18372	; 0x47c4
d0003a68:	4650      	mov	r0, sl
d0003a6a:	4453      	add	r3, sl
d0003a6c:	4619      	mov	r1, r3
d0003a6e:	9305      	str	r3, [sp, #20]
d0003a70:	f7fe f86a 	bl	d0001b48 <stbi__get_marker.isra.0>
d0003a74:	4601      	mov	r1, r0
d0003a76:	e025      	b.n	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0003a78:	f8da 5000 	ldr.w	r5, [sl]
d0003a7c:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0003a80:	f8d5 60b0 	ldr.w	r6, [r5, #176]	; 0xb0
d0003a84:	42b2      	cmp	r2, r6
d0003a86:	f0c0 810e 	bcc.w	d0003ca6 <load_jpeg_image.constprop.0+0x2f6>
d0003a8a:	6a2c      	ldr	r4, [r5, #32]
d0003a8c:	2c00      	cmp	r4, #0
d0003a8e:	f040 82af 	bne.w	d0003ff0 <load_jpeg_image.constprop.0+0x640>
d0003a92:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0003a96:	f8d5 30b0 	ldr.w	r3, [r5, #176]	; 0xb0
d0003a9a:	429a      	cmp	r2, r3
d0003a9c:	f0c0 80f2 	bcc.w	d0003c84 <load_jpeg_image.constprop.0+0x2d4>
d0003aa0:	6a2e      	ldr	r6, [r5, #32]
d0003aa2:	2e00      	cmp	r6, #0
d0003aa4:	f040 82c4 	bne.w	d0004030 <load_jpeg_image.constprop.0+0x680>
d0003aa8:	2c04      	cmp	r4, #4
d0003aaa:	f041 834b 	bne.w	d0005144 <load_jpeg_image.constprop.0+0x1794>
d0003aae:	686b      	ldr	r3, [r5, #4]
d0003ab0:	429e      	cmp	r6, r3
d0003ab2:	f041 834e 	bne.w	d0005152 <load_jpeg_image.constprop.0+0x17a2>
d0003ab6:	9a05      	ldr	r2, [sp, #20]
d0003ab8:	7811      	ldrb	r1, [r2, #0]
d0003aba:	29ff      	cmp	r1, #255	; 0xff
d0003abc:	f000 8103 	beq.w	d0003cc6 <load_jpeg_image.constprop.0+0x316>
d0003ac0:	23ff      	movs	r3, #255	; 0xff
d0003ac2:	7013      	strb	r3, [r2, #0]
d0003ac4:	29d9      	cmp	r1, #217	; 0xd9
d0003ac6:	f000 8617 	beq.w	d00046f8 <load_jpeg_image.constprop.0+0xd48>
d0003aca:	29da      	cmp	r1, #218	; 0xda
d0003acc:	f000 80b8 	beq.w	d0003c40 <load_jpeg_image.constprop.0+0x290>
d0003ad0:	29dc      	cmp	r1, #220	; 0xdc
d0003ad2:	d0d1      	beq.n	d0003a78 <load_jpeg_image.constprop.0+0xc8>
d0003ad4:	4650      	mov	r0, sl
d0003ad6:	f7fe fc6f 	bl	d00023b8 <stbi__process_marker>
d0003ada:	b1b0      	cbz	r0, d0003b0a <load_jpeg_image.constprop.0+0x15a>
d0003adc:	9a05      	ldr	r2, [sp, #20]
d0003ade:	7811      	ldrb	r1, [r2, #0]
d0003ae0:	29ff      	cmp	r1, #255	; 0xff
d0003ae2:	d1ed      	bne.n	d0003ac0 <load_jpeg_image.constprop.0+0x110>
d0003ae4:	f8da 4000 	ldr.w	r4, [sl]
d0003ae8:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0003aec:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0003af0:	4293      	cmp	r3, r2
d0003af2:	f0c0 81b5 	bcc.w	d0003e60 <load_jpeg_image.constprop.0+0x4b0>
d0003af6:	6a23      	ldr	r3, [r4, #32]
d0003af8:	2b00      	cmp	r3, #0
d0003afa:	f040 85dc 	bne.w	d00046b6 <load_jpeg_image.constprop.0+0xd06>
d0003afe:	21ff      	movs	r1, #255	; 0xff
d0003b00:	4650      	mov	r0, sl
d0003b02:	f7fe fc59 	bl	d00023b8 <stbi__process_marker>
d0003b06:	2800      	cmp	r0, #0
d0003b08:	d1e8      	bne.n	d0003adc <load_jpeg_image.constprop.0+0x12c>
d0003b0a:	f8da 4000 	ldr.w	r4, [sl]
d0003b0e:	68a3      	ldr	r3, [r4, #8]
d0003b10:	9304      	str	r3, [sp, #16]
d0003b12:	9b50      	ldr	r3, [sp, #320]	; 0x140
d0003b14:	b92b      	cbnz	r3, d0003b22 <load_jpeg_image.constprop.0+0x172>
d0003b16:	9b04      	ldr	r3, [sp, #16]
d0003b18:	2b02      	cmp	r3, #2
d0003b1a:	f340 85c8 	ble.w	d00046ae <load_jpeg_image.constprop.0+0xcfe>
d0003b1e:	2303      	movs	r3, #3
d0003b20:	9350      	str	r3, [sp, #320]	; 0x140
d0003b22:	9b04      	ldr	r3, [sp, #16]
d0003b24:	2b03      	cmp	r3, #3
d0003b26:	f000 852d 	beq.w	d0004584 <load_jpeg_image.constprop.0+0xbd4>
d0003b2a:	9b04      	ldr	r3, [sp, #16]
d0003b2c:	2b00      	cmp	r3, #0
d0003b2e:	dd91      	ble.n	d0003a54 <load_jpeg_image.constprop.0+0xa4>
d0003b30:	9306      	str	r3, [sp, #24]
d0003b32:	2300      	movs	r3, #0
d0003b34:	930a      	str	r3, [sp, #40]	; 0x28
d0003b36:	f244 6b84 	movw	fp, #18052	; 0x4684
d0003b3a:	2300      	movs	r3, #0
d0003b3c:	6825      	ldr	r5, [r4, #0]
d0003b3e:	f244 69a0 	movw	r9, #18080	; 0x46a0
d0003b42:	44d3      	add	fp, sl
d0003b44:	9405      	str	r4, [sp, #20]
d0003b46:	f105 0803 	add.w	r8, r5, #3
d0003b4a:	44d1      	add	r9, sl
d0003b4c:	465c      	mov	r4, fp
d0003b4e:	ae24      	add	r6, sp, #144	; 0x90
d0003b50:	469b      	mov	fp, r3
d0003b52:	9f06      	ldr	r7, [sp, #24]
d0003b54:	e9cd 3320 	strd	r3, r3, [sp, #128]	; 0x80
d0003b58:	e9cd 3322 	strd	r3, r3, [sp, #136]	; 0x88
d0003b5c:	e00b      	b.n	d0003b76 <load_jpeg_image.constprop.0+0x1c6>
d0003b5e:	2b02      	cmp	r3, #2
d0003b60:	f000 8317 	beq.w	d0004192 <load_jpeg_image.constprop.0+0x7e2>
d0003b64:	4bb9      	ldr	r3, [pc, #740]	; (d0003e4c <load_jpeg_image.constprop.0+0x49c>)
d0003b66:	6033      	str	r3, [r6, #0]
d0003b68:	f10b 0b01 	add.w	fp, fp, #1
d0003b6c:	f109 0948 	add.w	r9, r9, #72	; 0x48
d0003b70:	3620      	adds	r6, #32
d0003b72:	45bb      	cmp	fp, r7
d0003b74:	d037      	beq.n	d0003be6 <load_jpeg_image.constprop.0+0x236>
d0003b76:	4640      	mov	r0, r8
d0003b78:	f008 f828 	bl	d000bbcc <malloc>
d0003b7c:	f8c9 0034 	str.w	r0, [r9, #52]	; 0x34
d0003b80:	2800      	cmp	r0, #0
d0003b82:	f001 8367 	beq.w	d0005254 <load_jpeg_image.constprop.0+0x18a4>
d0003b86:	6821      	ldr	r1, [r4, #0]
d0003b88:	f244 6c88 	movw	ip, #18056	; 0x4688
d0003b8c:	f8d9 3000 	ldr.w	r3, [r9]
d0003b90:	1e68      	subs	r0, r5, #1
d0003b92:	f85a 200c 	ldr.w	r2, [sl, ip]
d0003b96:	fb91 f3f3 	sdiv	r3, r1, r3
d0003b9a:	f8d9 1004 	ldr.w	r1, [r9, #4]
d0003b9e:	4418      	add	r0, r3
d0003ba0:	2b01      	cmp	r3, #1
d0003ba2:	60f3      	str	r3, [r6, #12]
d0003ba4:	fb92 f2f1 	sdiv	r2, r2, r1
d0003ba8:	fbb0 f0f3 	udiv	r0, r0, r3
d0003bac:	ea4f 0c62 	mov.w	ip, r2, asr #1
d0003bb0:	f04f 0100 	mov.w	r1, #0
d0003bb4:	6170      	str	r0, [r6, #20]
d0003bb6:	f8d9 0028 	ldr.w	r0, [r9, #40]	; 0x28
d0003bba:	6132      	str	r2, [r6, #16]
d0003bbc:	f8c6 c018 	str.w	ip, [r6, #24]
d0003bc0:	61f1      	str	r1, [r6, #28]
d0003bc2:	60b0      	str	r0, [r6, #8]
d0003bc4:	6070      	str	r0, [r6, #4]
d0003bc6:	d1ca      	bne.n	d0003b5e <load_jpeg_image.constprop.0+0x1ae>
d0003bc8:	2a01      	cmp	r2, #1
d0003bca:	f000 82ed 	beq.w	d00041a8 <load_jpeg_image.constprop.0+0x7f8>
d0003bce:	2a02      	cmp	r2, #2
d0003bd0:	d1c8      	bne.n	d0003b64 <load_jpeg_image.constprop.0+0x1b4>
d0003bd2:	f10b 0b01 	add.w	fp, fp, #1
d0003bd6:	4b9e      	ldr	r3, [pc, #632]	; (d0003e50 <load_jpeg_image.constprop.0+0x4a0>)
d0003bd8:	f109 0948 	add.w	r9, r9, #72	; 0x48
d0003bdc:	3620      	adds	r6, #32
d0003bde:	45bb      	cmp	fp, r7
d0003be0:	f846 3c20 	str.w	r3, [r6, #-32]
d0003be4:	d1c7      	bne.n	d0003b76 <load_jpeg_image.constprop.0+0x1c6>
d0003be6:	2d00      	cmp	r5, #0
d0003be8:	9c05      	ldr	r4, [sp, #20]
d0003bea:	db1a      	blt.n	d0003c22 <load_jpeg_image.constprop.0+0x272>
d0003bec:	d006      	beq.n	d0003bfc <load_jpeg_image.constprop.0+0x24c>
d0003bee:	f06f 4300 	mvn.w	r3, #2147483648	; 0x80000000
d0003bf2:	9a50      	ldr	r2, [sp, #320]	; 0x140
d0003bf4:	fb93 f3f5 	sdiv	r3, r3, r5
d0003bf8:	4293      	cmp	r3, r2
d0003bfa:	db12      	blt.n	d0003c22 <load_jpeg_image.constprop.0+0x272>
d0003bfc:	6866      	ldr	r6, [r4, #4]
d0003bfe:	2e00      	cmp	r6, #0
d0003c00:	db0f      	blt.n	d0003c22 <load_jpeg_image.constprop.0+0x272>
d0003c02:	9b50      	ldr	r3, [sp, #320]	; 0x140
d0003c04:	fb03 f005 	mul.w	r0, r3, r5
d0003c08:	f000 86ea 	beq.w	d00049e0 <load_jpeg_image.constprop.0+0x1030>
d0003c0c:	f06f 4300 	mvn.w	r3, #2147483648	; 0x80000000
d0003c10:	fb93 f2f6 	sdiv	r2, r3, r6
d0003c14:	4290      	cmp	r0, r2
d0003c16:	dc04      	bgt.n	d0003c22 <load_jpeg_image.constprop.0+0x272>
d0003c18:	fb00 f006 	mul.w	r0, r0, r6
d0003c1c:	4298      	cmp	r0, r3
d0003c1e:	f040 82d3 	bne.w	d00041c8 <load_jpeg_image.constprop.0+0x818>
d0003c22:	9904      	ldr	r1, [sp, #16]
d0003c24:	4650      	mov	r0, sl
d0003c26:	f7fd ff03 	bl	d0001a30 <stbi__free_jpeg_components.constprop.0>
d0003c2a:	2100      	movs	r1, #0
d0003c2c:	4b89      	ldr	r3, [pc, #548]	; (d0003e54 <load_jpeg_image.constprop.0+0x4a4>)
d0003c2e:	9108      	str	r1, [sp, #32]
d0003c30:	4a89      	ldr	r2, [pc, #548]	; (d0003e58 <load_jpeg_image.constprop.0+0x4a8>)
d0003c32:	9808      	ldr	r0, [sp, #32]
d0003c34:	601a      	str	r2, [r3, #0]
d0003c36:	b045      	add	sp, #276	; 0x114
d0003c38:	ecbd 8b02 	vpop	{d8}
d0003c3c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0003c40:	f8da 5000 	ldr.w	r5, [sl]
d0003c44:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0003c48:	f8d5 30b0 	ldr.w	r3, [r5, #176]	; 0xb0
d0003c4c:	429a      	cmp	r2, r3
d0003c4e:	f0c0 80ec 	bcc.w	d0003e2a <load_jpeg_image.constprop.0+0x47a>
d0003c52:	6a2c      	ldr	r4, [r5, #32]
d0003c54:	2c00      	cmp	r4, #0
d0003c56:	f040 84de 	bne.w	d0004616 <load_jpeg_image.constprop.0+0xc66>
d0003c5a:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0003c5e:	462e      	mov	r6, r5
d0003c60:	f8d5 20b0 	ldr.w	r2, [r5, #176]	; 0xb0
d0003c64:	4293      	cmp	r3, r2
d0003c66:	d357      	bcc.n	d0003d18 <load_jpeg_image.constprop.0+0x368>
d0003c68:	6a2b      	ldr	r3, [r5, #32]
d0003c6a:	2b00      	cmp	r3, #0
d0003c6c:	f040 84ac 	bne.w	d00045c8 <load_jpeg_image.constprop.0+0xc18>
d0003c70:	f244 72f0 	movw	r2, #18416	; 0x47f0
d0003c74:	f8d5 c008 	ldr.w	ip, [r5, #8]
d0003c78:	f84a 3002 	str.w	r3, [sl, r2]
d0003c7c:	4b75      	ldr	r3, [pc, #468]	; (d0003e54 <load_jpeg_image.constprop.0+0x4a4>)
d0003c7e:	4a77      	ldr	r2, [pc, #476]	; (d0003e5c <load_jpeg_image.constprop.0+0x4ac>)
d0003c80:	601a      	str	r2, [r3, #0]
d0003c82:	e6c8      	b.n	d0003a16 <load_jpeg_image.constprop.0+0x66>
d0003c84:	1c51      	adds	r1, r2, #1
d0003c86:	f8c5 10ac 	str.w	r1, [r5, #172]	; 0xac
d0003c8a:	4299      	cmp	r1, r3
d0003c8c:	7816      	ldrb	r6, [r2, #0]
d0003c8e:	ea4f 2606 	mov.w	r6, r6, lsl #8
d0003c92:	f080 81f0 	bcs.w	d0004076 <load_jpeg_image.constprop.0+0x6c6>
d0003c96:	1c4b      	adds	r3, r1, #1
d0003c98:	f8c5 30ac 	str.w	r3, [r5, #172]	; 0xac
d0003c9c:	780b      	ldrb	r3, [r1, #0]
d0003c9e:	f8da 5000 	ldr.w	r5, [sl]
d0003ca2:	441e      	add	r6, r3
d0003ca4:	e700      	b.n	d0003aa8 <load_jpeg_image.constprop.0+0xf8>
d0003ca6:	1c51      	adds	r1, r2, #1
d0003ca8:	f8c5 10ac 	str.w	r1, [r5, #172]	; 0xac
d0003cac:	7814      	ldrb	r4, [r2, #0]
d0003cae:	0224      	lsls	r4, r4, #8
d0003cb0:	42b1      	cmp	r1, r6
d0003cb2:	f080 817a 	bcs.w	d0003faa <load_jpeg_image.constprop.0+0x5fa>
d0003cb6:	1c4b      	adds	r3, r1, #1
d0003cb8:	f8c5 30ac 	str.w	r3, [r5, #172]	; 0xac
d0003cbc:	780b      	ldrb	r3, [r1, #0]
d0003cbe:	f8da 5000 	ldr.w	r5, [sl]
d0003cc2:	441c      	add	r4, r3
d0003cc4:	e6e5      	b.n	d0003a92 <load_jpeg_image.constprop.0+0xe2>
d0003cc6:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0003cca:	f8d5 20b0 	ldr.w	r2, [r5, #176]	; 0xb0
d0003cce:	4293      	cmp	r3, r2
d0003cd0:	f0c0 81f4 	bcc.w	d00040bc <load_jpeg_image.constprop.0+0x70c>
d0003cd4:	6a2b      	ldr	r3, [r5, #32]
d0003cd6:	2b00      	cmp	r3, #0
d0003cd8:	f43f af11 	beq.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0003cdc:	f105 0628 	add.w	r6, r5, #40	; 0x28
d0003ce0:	692b      	ldr	r3, [r5, #16]
d0003ce2:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0003ce4:	4631      	mov	r1, r6
d0003ce6:	69e8      	ldr	r0, [r5, #28]
d0003ce8:	4798      	blx	r3
d0003cea:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0003cee:	f8d5 40b4 	ldr.w	r4, [r5, #180]	; 0xb4
d0003cf2:	f8d5 30a8 	ldr.w	r3, [r5, #168]	; 0xa8
d0003cf6:	1b12      	subs	r2, r2, r4
d0003cf8:	4413      	add	r3, r2
d0003cfa:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d0003cfe:	2800      	cmp	r0, #0
d0003d00:	f040 8677 	bne.w	d00049f2 <load_jpeg_image.constprop.0+0x1042>
d0003d04:	f105 0329 	add.w	r3, r5, #41	; 0x29
d0003d08:	6228      	str	r0, [r5, #32]
d0003d0a:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0003d0e:	f8c5 30b0 	str.w	r3, [r5, #176]	; 0xb0
d0003d12:	f8c5 30ac 	str.w	r3, [r5, #172]	; 0xac
d0003d16:	e6f2      	b.n	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0003d18:	1c5a      	adds	r2, r3, #1
d0003d1a:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d0003d1e:	781b      	ldrb	r3, [r3, #0]
d0003d20:	1e5a      	subs	r2, r3, #1
d0003d22:	f244 71f0 	movw	r1, #18416	; 0x47f0
d0003d26:	2a03      	cmp	r2, #3
d0003d28:	f84a 3001 	str.w	r3, [sl, r1]
d0003d2c:	4451      	add	r1, sl
d0003d2e:	910d      	str	r1, [sp, #52]	; 0x34
d0003d30:	f200 846d 	bhi.w	d000460e <load_jpeg_image.constprop.0+0xc5e>
d0003d34:	f8d6 c008 	ldr.w	ip, [r6, #8]
d0003d38:	459c      	cmp	ip, r3
d0003d3a:	db9f      	blt.n	d0003c7c <load_jpeg_image.constprop.0+0x2cc>
d0003d3c:	1cda      	adds	r2, r3, #3
d0003d3e:	ebb4 0f42 	cmp.w	r4, r2, lsl #1
d0003d42:	f040 8124 	bne.w	d0003f8e <load_jpeg_image.constprop.0+0x5de>
d0003d46:	2b00      	cmp	r3, #0
d0003d48:	f000 85e2 	beq.w	d0004910 <load_jpeg_image.constprop.0+0xf60>
d0003d4c:	f244 75f4 	movw	r5, #18420	; 0x47f4
d0003d50:	2400      	movs	r4, #0
d0003d52:	4689      	mov	r9, r1
d0003d54:	f244 679c 	movw	r7, #18076	; 0x469c
d0003d58:	4455      	add	r5, sl
d0003d5a:	46a0      	mov	r8, r4
d0003d5c:	e04e      	b.n	d0003dfc <load_jpeg_image.constprop.0+0x44c>
d0003d5e:	6a34      	ldr	r4, [r6, #32]
d0003d60:	2c00      	cmp	r4, #0
d0003d62:	f040 80c4 	bne.w	d0003eee <load_jpeg_image.constprop.0+0x53e>
d0003d66:	4620      	mov	r0, r4
d0003d68:	4622      	mov	r2, r4
d0003d6a:	68b1      	ldr	r1, [r6, #8]
d0003d6c:	2900      	cmp	r1, #0
d0003d6e:	dd5a      	ble.n	d0003e26 <load_jpeg_image.constprop.0+0x476>
d0003d70:	f85a 3007 	ldr.w	r3, [sl, r7]
d0003d74:	429c      	cmp	r4, r3
d0003d76:	f000 84bc 	beq.w	d00046f2 <load_jpeg_image.constprop.0+0xd42>
d0003d7a:	2901      	cmp	r1, #1
d0003d7c:	f000 8105 	beq.w	d0003f8a <load_jpeg_image.constprop.0+0x5da>
d0003d80:	f244 63e4 	movw	r3, #18148	; 0x46e4
d0003d84:	f85a 3003 	ldr.w	r3, [sl, r3]
d0003d88:	429c      	cmp	r4, r3
d0003d8a:	f000 850d 	beq.w	d00047a8 <load_jpeg_image.constprop.0+0xdf8>
d0003d8e:	2902      	cmp	r1, #2
d0003d90:	f000 80fb 	beq.w	d0003f8a <load_jpeg_image.constprop.0+0x5da>
d0003d94:	f244 732c 	movw	r3, #18220	; 0x472c
d0003d98:	f85a 3003 	ldr.w	r3, [sl, r3]
d0003d9c:	42a3      	cmp	r3, r4
d0003d9e:	f000 8511 	beq.w	d00047c4 <load_jpeg_image.constprop.0+0xe14>
d0003da2:	2903      	cmp	r1, #3
d0003da4:	f000 80f1 	beq.w	d0003f8a <load_jpeg_image.constprop.0+0x5da>
d0003da8:	f244 7374 	movw	r3, #18292	; 0x4774
d0003dac:	f85a 3003 	ldr.w	r3, [sl, r3]
d0003db0:	42a3      	cmp	r3, r4
d0003db2:	f000 8594 	beq.w	d00048de <load_jpeg_image.constprop.0+0xf2e>
d0003db6:	2404      	movs	r4, #4
d0003db8:	42a1      	cmp	r1, r4
d0003dba:	f000 8602 	beq.w	d00049c2 <load_jpeg_image.constprop.0+0x1012>
d0003dbe:	1100      	asrs	r0, r0, #4
d0003dc0:	f244 6cac 	movw	ip, #18092	; 0x46ac
d0003dc4:	eb04 03c4 	add.w	r3, r4, r4, lsl #3
d0003dc8:	2803      	cmp	r0, #3
d0003dca:	eb0a 03c3 	add.w	r3, sl, r3, lsl #3
d0003dce:	f843 000c 	str.w	r0, [r3, ip]
d0003dd2:	f300 85f9 	bgt.w	d00049c8 <load_jpeg_image.constprop.0+0x1018>
d0003dd6:	f244 60b0 	movw	r0, #18096	; 0x46b0
d0003dda:	f002 0c0f 	and.w	ip, r2, #15
d0003dde:	f012 0f0c 	tst.w	r2, #12
d0003de2:	f843 c000 	str.w	ip, [r3, r0]
d0003de6:	f040 85f5 	bne.w	d00049d4 <load_jpeg_image.constprop.0+0x1024>
d0003dea:	f108 0801 	add.w	r8, r8, #1
d0003dee:	f845 4b04 	str.w	r4, [r5], #4
d0003df2:	f8d9 3000 	ldr.w	r3, [r9]
d0003df6:	4598      	cmp	r8, r3
d0003df8:	f280 858a 	bge.w	d0004910 <load_jpeg_image.constprop.0+0xf60>
d0003dfc:	f8d6 30ac 	ldr.w	r3, [r6, #172]	; 0xac
d0003e00:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d0003e04:	4293      	cmp	r3, r2
d0003e06:	d2aa      	bcs.n	d0003d5e <load_jpeg_image.constprop.0+0x3ae>
d0003e08:	1c59      	adds	r1, r3, #1
d0003e0a:	4291      	cmp	r1, r2
d0003e0c:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d0003e10:	781c      	ldrb	r4, [r3, #0]
d0003e12:	f080 8094 	bcs.w	d0003f3e <load_jpeg_image.constprop.0+0x58e>
d0003e16:	1c4b      	adds	r3, r1, #1
d0003e18:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d0003e1c:	780a      	ldrb	r2, [r1, #0]
d0003e1e:	68b1      	ldr	r1, [r6, #8]
d0003e20:	4610      	mov	r0, r2
d0003e22:	2900      	cmp	r1, #0
d0003e24:	dca4      	bgt.n	d0003d70 <load_jpeg_image.constprop.0+0x3c0>
d0003e26:	2400      	movs	r4, #0
d0003e28:	e7c6      	b.n	d0003db8 <load_jpeg_image.constprop.0+0x408>
d0003e2a:	1c51      	adds	r1, r2, #1
d0003e2c:	f8c5 10ac 	str.w	r1, [r5, #172]	; 0xac
d0003e30:	4299      	cmp	r1, r3
d0003e32:	7814      	ldrb	r4, [r2, #0]
d0003e34:	ea4f 2404 	mov.w	r4, r4, lsl #8
d0003e38:	f080 8412 	bcs.w	d0004660 <load_jpeg_image.constprop.0+0xcb0>
d0003e3c:	1c4b      	adds	r3, r1, #1
d0003e3e:	f8c5 30ac 	str.w	r3, [r5, #172]	; 0xac
d0003e42:	780b      	ldrb	r3, [r1, #0]
d0003e44:	f8da 5000 	ldr.w	r5, [sl]
d0003e48:	441c      	add	r4, r3
d0003e4a:	e706      	b.n	d0003c5a <load_jpeg_image.constprop.0+0x2aa>
d0003e4c:	d0001665 	.word	0xd0001665
d0003e50:	d00015ad 	.word	0xd00015ad
d0003e54:	d000dec8 	.word	0xd000dec8
d0003e58:	d000d418 	.word	0xd000d418
d0003e5c:	d000d434 	.word	0xd000d434
d0003e60:	1c5a      	adds	r2, r3, #1
d0003e62:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0003e66:	781b      	ldrb	r3, [r3, #0]
d0003e68:	2bff      	cmp	r3, #255	; 0xff
d0003e6a:	f47f ae48 	bne.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0003e6e:	f8da 4000 	ldr.w	r4, [sl]
d0003e72:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0003e76:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0003e7a:	4293      	cmp	r3, r2
d0003e7c:	d329      	bcc.n	d0003ed2 <load_jpeg_image.constprop.0+0x522>
d0003e7e:	6a21      	ldr	r1, [r4, #32]
d0003e80:	2900      	cmp	r1, #0
d0003e82:	f43f ae27 	beq.w	d0003ad4 <load_jpeg_image.constprop.0+0x124>
d0003e86:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0003e8a:	6923      	ldr	r3, [r4, #16]
d0003e8c:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0003e8e:	f104 0629 	add.w	r6, r4, #41	; 0x29
d0003e92:	4629      	mov	r1, r5
d0003e94:	69e0      	ldr	r0, [r4, #28]
d0003e96:	4798      	blx	r3
d0003e98:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0003e9c:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d0003ea0:	4405      	add	r5, r0
d0003ea2:	1a9a      	subs	r2, r3, r2
d0003ea4:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0003ea8:	4413      	add	r3, r2
d0003eaa:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0003eae:	b1a8      	cbz	r0, d0003edc <load_jpeg_image.constprop.0+0x52c>
d0003eb0:	f894 1028 	ldrb.w	r1, [r4, #40]	; 0x28
d0003eb4:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0003eb8:	f8c4 60ac 	str.w	r6, [r4, #172]	; 0xac
d0003ebc:	29ff      	cmp	r1, #255	; 0xff
d0003ebe:	f47f ae01 	bne.w	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0003ec2:	f8da 4000 	ldr.w	r4, [sl]
d0003ec6:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0003eca:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0003ece:	4293      	cmp	r3, r2
d0003ed0:	d2d5      	bcs.n	d0003e7e <load_jpeg_image.constprop.0+0x4ce>
d0003ed2:	1c5a      	adds	r2, r3, #1
d0003ed4:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0003ed8:	7819      	ldrb	r1, [r3, #0]
d0003eda:	e7ef      	b.n	d0003ebc <load_jpeg_image.constprop.0+0x50c>
d0003edc:	4601      	mov	r1, r0
d0003ede:	6220      	str	r0, [r4, #32]
d0003ee0:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0003ee4:	f8c4 60b0 	str.w	r6, [r4, #176]	; 0xb0
d0003ee8:	f8c4 60ac 	str.w	r6, [r4, #172]	; 0xac
d0003eec:	e5ea      	b.n	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0003eee:	f106 0b28 	add.w	fp, r6, #40	; 0x28
d0003ef2:	6933      	ldr	r3, [r6, #16]
d0003ef4:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0003ef6:	4659      	mov	r1, fp
d0003ef8:	69f0      	ldr	r0, [r6, #28]
d0003efa:	4798      	blx	r3
d0003efc:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003f00:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0003f04:	4604      	mov	r4, r0
d0003f06:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0003f0a:	1a52      	subs	r2, r2, r1
d0003f0c:	4413      	add	r3, r2
d0003f0e:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003f12:	2800      	cmp	r0, #0
d0003f14:	f000 811a 	beq.w	d000414c <load_jpeg_image.constprop.0+0x79c>
d0003f18:	eb0b 0300 	add.w	r3, fp, r0
d0003f1c:	f106 0229 	add.w	r2, r6, #41	; 0x29
d0003f20:	f896 4028 	ldrb.w	r4, [r6, #40]	; 0x28
d0003f24:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d0003f28:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d0003f2c:	f8da 6000 	ldr.w	r6, [sl]
d0003f30:	f8d6 10ac 	ldr.w	r1, [r6, #172]	; 0xac
d0003f34:	f8d6 20b0 	ldr.w	r2, [r6, #176]	; 0xb0
d0003f38:	4291      	cmp	r1, r2
d0003f3a:	f4ff af6c 	bcc.w	d0003e16 <load_jpeg_image.constprop.0+0x466>
d0003f3e:	6a30      	ldr	r0, [r6, #32]
d0003f40:	2800      	cmp	r0, #0
d0003f42:	f001 8574 	beq.w	d0005a2e <load_jpeg_image.constprop.0+0x207e>
d0003f46:	f106 0b28 	add.w	fp, r6, #40	; 0x28
d0003f4a:	6933      	ldr	r3, [r6, #16]
d0003f4c:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0003f4e:	4659      	mov	r1, fp
d0003f50:	69f0      	ldr	r0, [r6, #28]
d0003f52:	4798      	blx	r3
d0003f54:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0003f58:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0003f5c:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0003f60:	1a52      	subs	r2, r2, r1
d0003f62:	4413      	add	r3, r2
d0003f64:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0003f68:	2800      	cmp	r0, #0
d0003f6a:	f000 80e7 	beq.w	d000413c <load_jpeg_image.constprop.0+0x78c>
d0003f6e:	f896 2028 	ldrb.w	r2, [r6, #40]	; 0x28
d0003f72:	eb0b 0300 	add.w	r3, fp, r0
d0003f76:	f106 0129 	add.w	r1, r6, #41	; 0x29
d0003f7a:	4610      	mov	r0, r2
d0003f7c:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d0003f80:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d0003f84:	f8da 6000 	ldr.w	r6, [sl]
d0003f88:	e6ef      	b.n	d0003d6a <load_jpeg_image.constprop.0+0x3ba>
d0003f8a:	460c      	mov	r4, r1
d0003f8c:	e714      	b.n	d0003db8 <load_jpeg_image.constprop.0+0x408>
d0003f8e:	4b89      	ldr	r3, [pc, #548]	; (d00041b4 <load_jpeg_image.constprop.0+0x804>)
d0003f90:	4a89      	ldr	r2, [pc, #548]	; (d00041b8 <load_jpeg_image.constprop.0+0x808>)
d0003f92:	601a      	str	r2, [r3, #0]
d0003f94:	e53f      	b.n	d0003a16 <load_jpeg_image.constprop.0+0x66>
d0003f96:	4b87      	ldr	r3, [pc, #540]	; (d00041b4 <load_jpeg_image.constprop.0+0x804>)
d0003f98:	4a88      	ldr	r2, [pc, #544]	; (d00041bc <load_jpeg_image.constprop.0+0x80c>)
d0003f9a:	9408      	str	r4, [sp, #32]
d0003f9c:	601a      	str	r2, [r3, #0]
d0003f9e:	9808      	ldr	r0, [sp, #32]
d0003fa0:	b045      	add	sp, #276	; 0x114
d0003fa2:	ecbd 8b02 	vpop	{d8}
d0003fa6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0003faa:	6a2b      	ldr	r3, [r5, #32]
d0003fac:	b1eb      	cbz	r3, d0003fea <load_jpeg_image.constprop.0+0x63a>
d0003fae:	f105 0728 	add.w	r7, r5, #40	; 0x28
d0003fb2:	692b      	ldr	r3, [r5, #16]
d0003fb4:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0003fb6:	4639      	mov	r1, r7
d0003fb8:	69e8      	ldr	r0, [r5, #28]
d0003fba:	4798      	blx	r3
d0003fbc:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0003fc0:	f8d5 60b4 	ldr.w	r6, [r5, #180]	; 0xb4
d0003fc4:	f8d5 30a8 	ldr.w	r3, [r5, #168]	; 0xa8
d0003fc8:	1b92      	subs	r2, r2, r6
d0003fca:	4413      	add	r3, r2
d0003fcc:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d0003fd0:	2800      	cmp	r0, #0
d0003fd2:	f000 80d7 	beq.w	d0004184 <load_jpeg_image.constprop.0+0x7d4>
d0003fd6:	f895 2028 	ldrb.w	r2, [r5, #40]	; 0x28
d0003fda:	4407      	add	r7, r0
d0003fdc:	f105 0329 	add.w	r3, r5, #41	; 0x29
d0003fe0:	4414      	add	r4, r2
d0003fe2:	f8c5 70b0 	str.w	r7, [r5, #176]	; 0xb0
d0003fe6:	f8c5 30ac 	str.w	r3, [r5, #172]	; 0xac
d0003fea:	f8da 5000 	ldr.w	r5, [sl]
d0003fee:	e550      	b.n	d0003a92 <load_jpeg_image.constprop.0+0xe2>
d0003ff0:	f105 0628 	add.w	r6, r5, #40	; 0x28
d0003ff4:	692b      	ldr	r3, [r5, #16]
d0003ff6:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0003ff8:	4631      	mov	r1, r6
d0003ffa:	69e8      	ldr	r0, [r5, #28]
d0003ffc:	4798      	blx	r3
d0003ffe:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0004002:	f8d5 10b4 	ldr.w	r1, [r5, #180]	; 0xb4
d0004006:	4604      	mov	r4, r0
d0004008:	f8d5 20a8 	ldr.w	r2, [r5, #168]	; 0xa8
d000400c:	1a5b      	subs	r3, r3, r1
d000400e:	4413      	add	r3, r2
d0004010:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d0004014:	2800      	cmp	r0, #0
d0004016:	f000 80ae 	beq.w	d0004176 <load_jpeg_image.constprop.0+0x7c6>
d000401a:	f895 2028 	ldrb.w	r2, [r5, #40]	; 0x28
d000401e:	4406      	add	r6, r0
d0004020:	f105 0129 	add.w	r1, r5, #41	; 0x29
d0004024:	0214      	lsls	r4, r2, #8
d0004026:	f8c5 60b0 	str.w	r6, [r5, #176]	; 0xb0
d000402a:	f8c5 10ac 	str.w	r1, [r5, #172]	; 0xac
d000402e:	e63f      	b.n	d0003cb0 <load_jpeg_image.constprop.0+0x300>
d0004030:	f105 0828 	add.w	r8, r5, #40	; 0x28
d0004034:	692e      	ldr	r6, [r5, #16]
d0004036:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0004038:	4641      	mov	r1, r8
d000403a:	69e8      	ldr	r0, [r5, #28]
d000403c:	47b0      	blx	r6
d000403e:	f8d5 70ac 	ldr.w	r7, [r5, #172]	; 0xac
d0004042:	f8d5 30b4 	ldr.w	r3, [r5, #180]	; 0xb4
d0004046:	4606      	mov	r6, r0
d0004048:	f8d5 20a8 	ldr.w	r2, [r5, #168]	; 0xa8
d000404c:	1aff      	subs	r7, r7, r3
d000404e:	443a      	add	r2, r7
d0004050:	f8c5 20a8 	str.w	r2, [r5, #168]	; 0xa8
d0004054:	2800      	cmp	r0, #0
d0004056:	f000 8087 	beq.w	d0004168 <load_jpeg_image.constprop.0+0x7b8>
d000405a:	f895 2028 	ldrb.w	r2, [r5, #40]	; 0x28
d000405e:	eb08 0300 	add.w	r3, r8, r0
d0004062:	f105 0129 	add.w	r1, r5, #41	; 0x29
d0004066:	0216      	lsls	r6, r2, #8
d0004068:	4299      	cmp	r1, r3
d000406a:	f8c5 30b0 	str.w	r3, [r5, #176]	; 0xb0
d000406e:	f8c5 10ac 	str.w	r1, [r5, #172]	; 0xac
d0004072:	f4ff ae10 	bcc.w	d0003c96 <load_jpeg_image.constprop.0+0x2e6>
d0004076:	6a2b      	ldr	r3, [r5, #32]
d0004078:	b1eb      	cbz	r3, d00040b6 <load_jpeg_image.constprop.0+0x706>
d000407a:	f105 0828 	add.w	r8, r5, #40	; 0x28
d000407e:	692b      	ldr	r3, [r5, #16]
d0004080:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d0004082:	4641      	mov	r1, r8
d0004084:	69e8      	ldr	r0, [r5, #28]
d0004086:	4798      	blx	r3
d0004088:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d000408c:	f8d5 70b4 	ldr.w	r7, [r5, #180]	; 0xb4
d0004090:	f8d5 30a8 	ldr.w	r3, [r5, #168]	; 0xa8
d0004094:	1bd2      	subs	r2, r2, r7
d0004096:	4413      	add	r3, r2
d0004098:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d000409c:	2800      	cmp	r0, #0
d000409e:	d05c      	beq.n	d000415a <load_jpeg_image.constprop.0+0x7aa>
d00040a0:	f895 1028 	ldrb.w	r1, [r5, #40]	; 0x28
d00040a4:	eb08 0300 	add.w	r3, r8, r0
d00040a8:	f105 0229 	add.w	r2, r5, #41	; 0x29
d00040ac:	440e      	add	r6, r1
d00040ae:	f8c5 30b0 	str.w	r3, [r5, #176]	; 0xb0
d00040b2:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d00040b6:	f8da 5000 	ldr.w	r5, [sl]
d00040ba:	e4f5      	b.n	d0003aa8 <load_jpeg_image.constprop.0+0xf8>
d00040bc:	1c5a      	adds	r2, r3, #1
d00040be:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d00040c2:	781b      	ldrb	r3, [r3, #0]
d00040c4:	2bff      	cmp	r3, #255	; 0xff
d00040c6:	f47f ad1a 	bne.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d00040ca:	f8da 4000 	ldr.w	r4, [sl]
d00040ce:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00040d2:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d00040d6:	4293      	cmp	r3, r2
d00040d8:	d32b      	bcc.n	d0004132 <load_jpeg_image.constprop.0+0x782>
d00040da:	6a21      	ldr	r1, [r4, #32]
d00040dc:	2900      	cmp	r1, #0
d00040de:	f43f acf9 	beq.w	d0003ad4 <load_jpeg_image.constprop.0+0x124>
d00040e2:	f104 0528 	add.w	r5, r4, #40	; 0x28
d00040e6:	6923      	ldr	r3, [r4, #16]
d00040e8:	6a62      	ldr	r2, [r4, #36]	; 0x24
d00040ea:	f104 0629 	add.w	r6, r4, #41	; 0x29
d00040ee:	4629      	mov	r1, r5
d00040f0:	69e0      	ldr	r0, [r4, #28]
d00040f2:	4798      	blx	r3
d00040f4:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d00040f8:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d00040fc:	4405      	add	r5, r0
d00040fe:	1a9a      	subs	r2, r3, r2
d0004100:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0004104:	4413      	add	r3, r2
d0004106:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d000410a:	2800      	cmp	r0, #0
d000410c:	f43f aee6 	beq.w	d0003edc <load_jpeg_image.constprop.0+0x52c>
d0004110:	f894 1028 	ldrb.w	r1, [r4, #40]	; 0x28
d0004114:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0004118:	f8c4 60ac 	str.w	r6, [r4, #172]	; 0xac
d000411c:	29ff      	cmp	r1, #255	; 0xff
d000411e:	f47f acd1 	bne.w	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0004122:	f8da 4000 	ldr.w	r4, [sl]
d0004126:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d000412a:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d000412e:	4293      	cmp	r3, r2
d0004130:	d2d3      	bcs.n	d00040da <load_jpeg_image.constprop.0+0x72a>
d0004132:	1c5a      	adds	r2, r3, #1
d0004134:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0004138:	7819      	ldrb	r1, [r3, #0]
d000413a:	e7ef      	b.n	d000411c <load_jpeg_image.constprop.0+0x76c>
d000413c:	f106 0329 	add.w	r3, r6, #41	; 0x29
d0004140:	4602      	mov	r2, r0
d0004142:	6230      	str	r0, [r6, #32]
d0004144:	4619      	mov	r1, r3
d0004146:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000414a:	e717      	b.n	d0003f7c <load_jpeg_image.constprop.0+0x5cc>
d000414c:	f106 0329 	add.w	r3, r6, #41	; 0x29
d0004150:	6230      	str	r0, [r6, #32]
d0004152:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d0004156:	461a      	mov	r2, r3
d0004158:	e6e4      	b.n	d0003f24 <load_jpeg_image.constprop.0+0x574>
d000415a:	f105 0329 	add.w	r3, r5, #41	; 0x29
d000415e:	6228      	str	r0, [r5, #32]
d0004160:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0004164:	461a      	mov	r2, r3
d0004166:	e7a2      	b.n	d00040ae <load_jpeg_image.constprop.0+0x6fe>
d0004168:	f105 0329 	add.w	r3, r5, #41	; 0x29
d000416c:	6228      	str	r0, [r5, #32]
d000416e:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0004172:	4619      	mov	r1, r3
d0004174:	e778      	b.n	d0004068 <load_jpeg_image.constprop.0+0x6b8>
d0004176:	f105 0629 	add.w	r6, r5, #41	; 0x29
d000417a:	6228      	str	r0, [r5, #32]
d000417c:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0004180:	4631      	mov	r1, r6
d0004182:	e750      	b.n	d0004026 <load_jpeg_image.constprop.0+0x676>
d0004184:	f105 0729 	add.w	r7, r5, #41	; 0x29
d0004188:	6228      	str	r0, [r5, #32]
d000418a:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d000418e:	463b      	mov	r3, r7
d0004190:	e727      	b.n	d0003fe2 <load_jpeg_image.constprop.0+0x632>
d0004192:	2a01      	cmp	r2, #1
d0004194:	d00b      	beq.n	d00041ae <load_jpeg_image.constprop.0+0x7fe>
d0004196:	2a02      	cmp	r2, #2
d0004198:	f47f ace4 	bne.w	d0003b64 <load_jpeg_image.constprop.0+0x1b4>
d000419c:	f644 0314 	movw	r3, #18452	; 0x4814
d00041a0:	f85a 3003 	ldr.w	r3, [sl, r3]
d00041a4:	6033      	str	r3, [r6, #0]
d00041a6:	e4df      	b.n	d0003b68 <load_jpeg_image.constprop.0+0x1b8>
d00041a8:	4b05      	ldr	r3, [pc, #20]	; (d00041c0 <load_jpeg_image.constprop.0+0x810>)
d00041aa:	6033      	str	r3, [r6, #0]
d00041ac:	e4dc      	b.n	d0003b68 <load_jpeg_image.constprop.0+0x1b8>
d00041ae:	4b05      	ldr	r3, [pc, #20]	; (d00041c4 <load_jpeg_image.constprop.0+0x814>)
d00041b0:	6033      	str	r3, [r6, #0]
d00041b2:	e4d9      	b.n	d0003b68 <load_jpeg_image.constprop.0+0x1b8>
d00041b4:	d000dec8 	.word	0xd000dec8
d00041b8:	d000d44c 	.word	0xd000d44c
d00041bc:	d000d424 	.word	0xd000d424
d00041c0:	d00015a9 	.word	0xd00015a9
d00041c4:	d0001879 	.word	0xd0001879
d00041c8:	3001      	adds	r0, #1
d00041ca:	f007 fcff 	bl	d000bbcc <malloc>
d00041ce:	9008      	str	r0, [sp, #32]
d00041d0:	2800      	cmp	r0, #0
d00041d2:	f43f ad26 	beq.w	d0003c22 <load_jpeg_image.constprop.0+0x272>
d00041d6:	2300      	movs	r3, #0
d00041d8:	f244 62bc 	movw	r2, #18108	; 0x46bc
d00041dc:	9906      	ldr	r1, [sp, #24]
d00041de:	a824      	add	r0, sp, #144	; 0x90
d00041e0:	9305      	str	r3, [sp, #20]
d00041e2:	9306      	str	r3, [sp, #24]
d00041e4:	eb0a 0302 	add.w	r3, sl, r2
d00041e8:	eb00 1141 	add.w	r1, r0, r1, lsl #5
d00041ec:	f8cd a01c 	str.w	sl, [sp, #28]
d00041f0:	9309      	str	r3, [sp, #36]	; 0x24
d00041f2:	9b05      	ldr	r3, [sp, #20]
d00041f4:	9104      	str	r1, [sp, #16]
d00041f6:	9a08      	ldr	r2, [sp, #32]
d00041f8:	f10d 0a80 	add.w	sl, sp, #128	; 0x80
d00041fc:	9f09      	ldr	r7, [sp, #36]	; 0x24
d00041fe:	ac24      	add	r4, sp, #144	; 0x90
d0004200:	fb05 2503 	mla	r5, r5, r3, r2
d0004204:	46ab      	mov	fp, r5
d0004206:	69a6      	ldr	r6, [r4, #24]
d0004208:	f8d4 8010 	ldr.w	r8, [r4, #16]
d000420c:	6861      	ldr	r1, [r4, #4]
d000420e:	ebb6 0f68 	cmp.w	r6, r8, asr #1
d0004212:	68a5      	ldr	r5, [r4, #8]
d0004214:	68e3      	ldr	r3, [r4, #12]
d0004216:	f106 0601 	add.w	r6, r6, #1
d000421a:	460a      	mov	r2, r1
d000421c:	f8d4 9000 	ldr.w	r9, [r4]
d0004220:	69b8      	ldr	r0, [r7, #24]
d0004222:	bfac      	ite	ge
d0004224:	4629      	movge	r1, r5
d0004226:	462a      	movlt	r2, r5
d0004228:	9300      	str	r3, [sp, #0]
d000422a:	6963      	ldr	r3, [r4, #20]
d000422c:	47c8      	blx	r9
d000422e:	45b0      	cmp	r8, r6
d0004230:	f84a 0b04 	str.w	r0, [sl], #4
d0004234:	dd38      	ble.n	d00042a8 <load_jpeg_image.constprop.0+0x8f8>
d0004236:	61a6      	str	r6, [r4, #24]
d0004238:	3420      	adds	r4, #32
d000423a:	9b04      	ldr	r3, [sp, #16]
d000423c:	3748      	adds	r7, #72	; 0x48
d000423e:	429c      	cmp	r4, r3
d0004240:	d1e1      	bne.n	d0004206 <load_jpeg_image.constprop.0+0x856>
d0004242:	9b50      	ldr	r3, [sp, #320]	; 0x140
d0004244:	465d      	mov	r5, fp
d0004246:	2b02      	cmp	r3, #2
d0004248:	dd3b      	ble.n	d00042c2 <load_jpeg_image.constprop.0+0x912>
d000424a:	9b07      	ldr	r3, [sp, #28]
d000424c:	9920      	ldr	r1, [sp, #128]	; 0x80
d000424e:	681c      	ldr	r4, [r3, #0]
d0004250:	68a3      	ldr	r3, [r4, #8]
d0004252:	2b03      	cmp	r3, #3
d0004254:	f000 8086 	beq.w	d0004364 <load_jpeg_image.constprop.0+0x9b4>
d0004258:	2b04      	cmp	r3, #4
d000425a:	f040 80a5 	bne.w	d00043a8 <load_jpeg_image.constprop.0+0x9f8>
d000425e:	f244 73e8 	movw	r3, #18408	; 0x47e8
d0004262:	9a07      	ldr	r2, [sp, #28]
d0004264:	58d3      	ldr	r3, [r2, r3]
d0004266:	2b00      	cmp	r3, #0
d0004268:	f000 8152 	beq.w	d0004510 <load_jpeg_image.constprop.0+0xb60>
d000426c:	2b02      	cmp	r3, #2
d000426e:	f000 82f4 	beq.w	d000485a <load_jpeg_image.constprop.0+0xeaa>
d0004272:	9b50      	ldr	r3, [sp, #320]	; 0x140
d0004274:	f644 0210 	movw	r2, #18448	; 0x4810
d0004278:	4628      	mov	r0, r5
d000427a:	9d07      	ldr	r5, [sp, #28]
d000427c:	9301      	str	r3, [sp, #4]
d000427e:	6823      	ldr	r3, [r4, #0]
d0004280:	58ac      	ldr	r4, [r5, r2]
d0004282:	9300      	str	r3, [sp, #0]
d0004284:	9a21      	ldr	r2, [sp, #132]	; 0x84
d0004286:	9b22      	ldr	r3, [sp, #136]	; 0x88
d0004288:	47a0      	blx	r4
d000428a:	682c      	ldr	r4, [r5, #0]
d000428c:	9b06      	ldr	r3, [sp, #24]
d000428e:	9a05      	ldr	r2, [sp, #20]
d0004290:	3301      	adds	r3, #1
d0004292:	6866      	ldr	r6, [r4, #4]
d0004294:	9950      	ldr	r1, [sp, #320]	; 0x140
d0004296:	42b3      	cmp	r3, r6
d0004298:	9306      	str	r3, [sp, #24]
d000429a:	440a      	add	r2, r1
d000429c:	9205      	str	r2, [sp, #20]
d000429e:	f080 8099 	bcs.w	d00043d4 <load_jpeg_image.constprop.0+0xa24>
d00042a2:	6825      	ldr	r5, [r4, #0]
d00042a4:	4613      	mov	r3, r2
d00042a6:	e7a6      	b.n	d00041f6 <load_jpeg_image.constprop.0+0x846>
d00042a8:	69e3      	ldr	r3, [r4, #28]
d00042aa:	2100      	movs	r1, #0
d00042ac:	683a      	ldr	r2, [r7, #0]
d00042ae:	3301      	adds	r3, #1
d00042b0:	61a1      	str	r1, [r4, #24]
d00042b2:	6065      	str	r5, [r4, #4]
d00042b4:	4293      	cmp	r3, r2
d00042b6:	61e3      	str	r3, [r4, #28]
d00042b8:	dabe      	bge.n	d0004238 <load_jpeg_image.constprop.0+0x888>
d00042ba:	687b      	ldr	r3, [r7, #4]
d00042bc:	441d      	add	r5, r3
d00042be:	60a5      	str	r5, [r4, #8]
d00042c0:	e7ba      	b.n	d0004238 <load_jpeg_image.constprop.0+0x888>
d00042c2:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d00042c4:	b383      	cbz	r3, d0004328 <load_jpeg_image.constprop.0+0x978>
d00042c6:	9b50      	ldr	r3, [sp, #320]	; 0x140
d00042c8:	2b01      	cmp	r3, #1
d00042ca:	9b07      	ldr	r3, [sp, #28]
d00042cc:	681c      	ldr	r4, [r3, #0]
d00042ce:	6823      	ldr	r3, [r4, #0]
d00042d0:	f000 80e7 	beq.w	d00044a2 <load_jpeg_image.constprop.0+0xaf2>
d00042d4:	2b00      	cmp	r3, #0
d00042d6:	d0d9      	beq.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00042d8:	9b20      	ldr	r3, [sp, #128]	; 0x80
d00042da:	2100      	movs	r1, #0
d00042dc:	9e21      	ldr	r6, [sp, #132]	; 0x84
d00042de:	1c6f      	adds	r7, r5, #1
d00042e0:	9822      	ldr	r0, [sp, #136]	; 0x88
d00042e2:	f103 3cff 	add.w	ip, r3, #4294967295	; 0xffffffff
d00042e6:	3e01      	subs	r6, #1
d00042e8:	f04f 0e4d 	mov.w	lr, #77	; 0x4d
d00042ec:	3801      	subs	r0, #1
d00042ee:	f04f 081d 	mov.w	r8, #29
d00042f2:	f816 3f01 	ldrb.w	r3, [r6, #1]!
d00042f6:	f81c 2f01 	ldrb.w	r2, [ip, #1]!
d00042fa:	eb03 0383 	add.w	r3, r3, r3, lsl #2
d00042fe:	f810 9f01 	ldrb.w	r9, [r0, #1]!
d0004302:	ebc3 1303 	rsb	r3, r3, r3, lsl #4
d0004306:	005b      	lsls	r3, r3, #1
d0004308:	fb1e 3302 	smlabb	r3, lr, r2, r3
d000430c:	fb18 3309 	smlabb	r3, r8, r9, r3
d0004310:	121b      	asrs	r3, r3, #8
d0004312:	f805 3011 	strb.w	r3, [r5, r1, lsl #1]
d0004316:	f04f 33ff 	mov.w	r3, #4294967295	; 0xffffffff
d000431a:	f807 3011 	strb.w	r3, [r7, r1, lsl #1]
d000431e:	3101      	adds	r1, #1
d0004320:	6823      	ldr	r3, [r4, #0]
d0004322:	4299      	cmp	r1, r3
d0004324:	d3e5      	bcc.n	d00042f2 <load_jpeg_image.constprop.0+0x942>
d0004326:	e7b1      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004328:	9b07      	ldr	r3, [sp, #28]
d000432a:	681c      	ldr	r4, [r3, #0]
d000432c:	68a3      	ldr	r3, [r4, #8]
d000432e:	2b04      	cmp	r3, #4
d0004330:	f000 808b 	beq.w	d000444a <load_jpeg_image.constprop.0+0xa9a>
d0004334:	9b50      	ldr	r3, [sp, #320]	; 0x140
d0004336:	9920      	ldr	r1, [sp, #128]	; 0x80
d0004338:	2b01      	cmp	r3, #1
d000433a:	6823      	ldr	r3, [r4, #0]
d000433c:	f000 80d8 	beq.w	d00044f0 <load_jpeg_image.constprop.0+0xb40>
d0004340:	2b00      	cmp	r3, #0
d0004342:	d0a3      	beq.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004344:	3901      	subs	r1, #1
d0004346:	2300      	movs	r3, #0
d0004348:	1c6f      	adds	r7, r5, #1
d000434a:	f811 2f01 	ldrb.w	r2, [r1, #1]!
d000434e:	f805 2013 	strb.w	r2, [r5, r3, lsl #1]
d0004352:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d0004356:	f807 2013 	strb.w	r2, [r7, r3, lsl #1]
d000435a:	3301      	adds	r3, #1
d000435c:	6822      	ldr	r2, [r4, #0]
d000435e:	4293      	cmp	r3, r2
d0004360:	d3f3      	bcc.n	d000434a <load_jpeg_image.constprop.0+0x99a>
d0004362:	e793      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004364:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d0004366:	2b00      	cmp	r3, #0
d0004368:	d083      	beq.n	d0004272 <load_jpeg_image.constprop.0+0x8c2>
d000436a:	6823      	ldr	r3, [r4, #0]
d000436c:	2b00      	cmp	r3, #0
d000436e:	d08d      	beq.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004370:	9a21      	ldr	r2, [sp, #132]	; 0x84
d0004372:	1e4e      	subs	r6, r1, #1
d0004374:	9b22      	ldr	r3, [sp, #136]	; 0x88
d0004376:	3a01      	subs	r2, #1
d0004378:	f8dd c140 	ldr.w	ip, [sp, #320]	; 0x140
d000437c:	1e5f      	subs	r7, r3, #1
d000437e:	4633      	mov	r3, r6
d0004380:	f816 0f01 	ldrb.w	r0, [r6, #1]!
d0004384:	f04f 3eff 	mov.w	lr, #4294967295	; 0xffffffff
d0004388:	7028      	strb	r0, [r5, #0]
d000438a:	3302      	adds	r3, #2
d000438c:	f812 0f01 	ldrb.w	r0, [r2, #1]!
d0004390:	1a5b      	subs	r3, r3, r1
d0004392:	7068      	strb	r0, [r5, #1]
d0004394:	f817 0f01 	ldrb.w	r0, [r7, #1]!
d0004398:	f885 e003 	strb.w	lr, [r5, #3]
d000439c:	70a8      	strb	r0, [r5, #2]
d000439e:	4465      	add	r5, ip
d00043a0:	6820      	ldr	r0, [r4, #0]
d00043a2:	4298      	cmp	r0, r3
d00043a4:	d8eb      	bhi.n	d000437e <load_jpeg_image.constprop.0+0x9ce>
d00043a6:	e771      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00043a8:	6823      	ldr	r3, [r4, #0]
d00043aa:	2b00      	cmp	r3, #0
d00043ac:	f43f af6e 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00043b0:	1e48      	subs	r0, r1, #1
d00043b2:	9e50      	ldr	r6, [sp, #320]	; 0x140
d00043b4:	4603      	mov	r3, r0
d00043b6:	f04f 37ff 	mov.w	r7, #4294967295	; 0xffffffff
d00043ba:	f810 2f01 	ldrb.w	r2, [r0, #1]!
d00043be:	3302      	adds	r3, #2
d00043c0:	70ef      	strb	r7, [r5, #3]
d00043c2:	70aa      	strb	r2, [r5, #2]
d00043c4:	706a      	strb	r2, [r5, #1]
d00043c6:	1a5b      	subs	r3, r3, r1
d00043c8:	702a      	strb	r2, [r5, #0]
d00043ca:	4435      	add	r5, r6
d00043cc:	6822      	ldr	r2, [r4, #0]
d00043ce:	429a      	cmp	r2, r3
d00043d0:	d8f0      	bhi.n	d00043b4 <load_jpeg_image.constprop.0+0xa04>
d00043d2:	e75b      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00043d4:	68a3      	ldr	r3, [r4, #8]
d00043d6:	f8dd a01c 	ldr.w	sl, [sp, #28]
d00043da:	9304      	str	r3, [sp, #16]
d00043dc:	9b04      	ldr	r3, [sp, #16]
d00043de:	2b00      	cmp	r3, #0
d00043e0:	dd1e      	ble.n	d0004420 <load_jpeg_image.constprop.0+0xa70>
d00043e2:	f244 64c8 	movw	r4, #18120	; 0x46c8
d00043e6:	eb03 06c3 	add.w	r6, r3, r3, lsl #3
d00043ea:	2500      	movs	r5, #0
d00043ec:	4454      	add	r4, sl
d00043ee:	eb04 06c6 	add.w	r6, r4, r6, lsl #3
d00043f2:	6860      	ldr	r0, [r4, #4]
d00043f4:	b118      	cbz	r0, d00043fe <load_jpeg_image.constprop.0+0xa4e>
d00043f6:	f007 fbf1 	bl	d000bbdc <free>
d00043fa:	6065      	str	r5, [r4, #4]
d00043fc:	6025      	str	r5, [r4, #0]
d00043fe:	68a0      	ldr	r0, [r4, #8]
d0004400:	b118      	cbz	r0, d000440a <load_jpeg_image.constprop.0+0xa5a>
d0004402:	f007 fbeb 	bl	d000bbdc <free>
d0004406:	60a5      	str	r5, [r4, #8]
d0004408:	6125      	str	r5, [r4, #16]
d000440a:	68e0      	ldr	r0, [r4, #12]
d000440c:	b110      	cbz	r0, d0004414 <load_jpeg_image.constprop.0+0xa64>
d000440e:	f007 fbe5 	bl	d000bbdc <free>
d0004412:	60e5      	str	r5, [r4, #12]
d0004414:	3448      	adds	r4, #72	; 0x48
d0004416:	42b4      	cmp	r4, r6
d0004418:	d1eb      	bne.n	d00043f2 <load_jpeg_image.constprop.0+0xa42>
d000441a:	f8da 4000 	ldr.w	r4, [sl]
d000441e:	6866      	ldr	r6, [r4, #4]
d0004420:	6823      	ldr	r3, [r4, #0]
d0004422:	9a1b      	ldr	r2, [sp, #108]	; 0x6c
d0004424:	6013      	str	r3, [r2, #0]
d0004426:	9b1c      	ldr	r3, [sp, #112]	; 0x70
d0004428:	9a1d      	ldr	r2, [sp, #116]	; 0x74
d000442a:	601e      	str	r6, [r3, #0]
d000442c:	2a00      	cmp	r2, #0
d000442e:	f43f adb6 	beq.w	d0003f9e <load_jpeg_image.constprop.0+0x5ee>
d0004432:	68a3      	ldr	r3, [r4, #8]
d0004434:	9808      	ldr	r0, [sp, #32]
d0004436:	2b02      	cmp	r3, #2
d0004438:	bfcc      	ite	gt
d000443a:	2303      	movgt	r3, #3
d000443c:	2301      	movle	r3, #1
d000443e:	6013      	str	r3, [r2, #0]
d0004440:	b045      	add	sp, #276	; 0x114
d0004442:	ecbd 8b02 	vpop	{d8}
d0004446:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000444a:	f244 73e8 	movw	r3, #18408	; 0x47e8
d000444e:	9a07      	ldr	r2, [sp, #28]
d0004450:	58d3      	ldr	r3, [r2, r3]
d0004452:	2b00      	cmp	r3, #0
d0004454:	f000 81b9 	beq.w	d00047ca <load_jpeg_image.constprop.0+0xe1a>
d0004458:	2b02      	cmp	r3, #2
d000445a:	f47f af6b 	bne.w	d0004334 <load_jpeg_image.constprop.0+0x984>
d000445e:	6823      	ldr	r3, [r4, #0]
d0004460:	2b00      	cmp	r3, #0
d0004462:	f43f af13 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004466:	9e20      	ldr	r6, [sp, #128]	; 0x80
d0004468:	9823      	ldr	r0, [sp, #140]	; 0x8c
d000446a:	1e71      	subs	r1, r6, #1
d000446c:	9f50      	ldr	r7, [sp, #320]	; 0x140
d000446e:	3801      	subs	r0, #1
d0004470:	460a      	mov	r2, r1
d0004472:	f811 3f01 	ldrb.w	r3, [r1, #1]!
d0004476:	f810 cf01 	ldrb.w	ip, [r0, #1]!
d000447a:	f04f 3eff 	mov.w	lr, #4294967295	; 0xffffffff
d000447e:	43db      	mvns	r3, r3
d0004480:	3202      	adds	r2, #2
d0004482:	f885 e001 	strb.w	lr, [r5, #1]
d0004486:	b2db      	uxtb	r3, r3
d0004488:	1b92      	subs	r2, r2, r6
d000448a:	fb13 f30c 	smulbb	r3, r3, ip
d000448e:	3380      	adds	r3, #128	; 0x80
d0004490:	eb03 2313 	add.w	r3, r3, r3, lsr #8
d0004494:	0a1b      	lsrs	r3, r3, #8
d0004496:	702b      	strb	r3, [r5, #0]
d0004498:	443d      	add	r5, r7
d000449a:	6823      	ldr	r3, [r4, #0]
d000449c:	4293      	cmp	r3, r2
d000449e:	d8e7      	bhi.n	d0004470 <load_jpeg_image.constprop.0+0xac0>
d00044a0:	e6f4      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00044a2:	2b00      	cmp	r3, #0
d00044a4:	f43f aef2 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00044a8:	9e20      	ldr	r6, [sp, #128]	; 0x80
d00044aa:	f04f 0c4d 	mov.w	ip, #77	; 0x4d
d00044ae:	9a21      	ldr	r2, [sp, #132]	; 0x84
d00044b0:	271d      	movs	r7, #29
d00044b2:	9b22      	ldr	r3, [sp, #136]	; 0x88
d00044b4:	1e70      	subs	r0, r6, #1
d00044b6:	f102 3eff 	add.w	lr, r2, #4294967295	; 0xffffffff
d00044ba:	f103 38ff 	add.w	r8, r3, #4294967295	; 0xffffffff
d00044be:	f81e 3f01 	ldrb.w	r3, [lr, #1]!
d00044c2:	4602      	mov	r2, r0
d00044c4:	f810 1f01 	ldrb.w	r1, [r0, #1]!
d00044c8:	eb03 0383 	add.w	r3, r3, r3, lsl #2
d00044cc:	f818 9f01 	ldrb.w	r9, [r8, #1]!
d00044d0:	3202      	adds	r2, #2
d00044d2:	ebc3 1303 	rsb	r3, r3, r3, lsl #4
d00044d6:	1b92      	subs	r2, r2, r6
d00044d8:	005b      	lsls	r3, r3, #1
d00044da:	fb1c 3301 	smlabb	r3, ip, r1, r3
d00044de:	fb17 3309 	smlabb	r3, r7, r9, r3
d00044e2:	121b      	asrs	r3, r3, #8
d00044e4:	f805 3b01 	strb.w	r3, [r5], #1
d00044e8:	6823      	ldr	r3, [r4, #0]
d00044ea:	4293      	cmp	r3, r2
d00044ec:	d8e7      	bhi.n	d00044be <load_jpeg_image.constprop.0+0xb0e>
d00044ee:	e6cd      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00044f0:	2b00      	cmp	r3, #0
d00044f2:	f43f aecb 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00044f6:	3d01      	subs	r5, #1
d00044f8:	1e48      	subs	r0, r1, #1
d00044fa:	4603      	mov	r3, r0
d00044fc:	f810 2f01 	ldrb.w	r2, [r0, #1]!
d0004500:	3302      	adds	r3, #2
d0004502:	f805 2f01 	strb.w	r2, [r5, #1]!
d0004506:	6822      	ldr	r2, [r4, #0]
d0004508:	1a5b      	subs	r3, r3, r1
d000450a:	429a      	cmp	r2, r3
d000450c:	d8f5      	bhi.n	d00044fa <load_jpeg_image.constprop.0+0xb4a>
d000450e:	e6bd      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004510:	6823      	ldr	r3, [r4, #0]
d0004512:	2b00      	cmp	r3, #0
d0004514:	f43f aeba 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004518:	9f23      	ldr	r7, [sp, #140]	; 0x8c
d000451a:	1e4a      	subs	r2, r1, #1
d000451c:	9b22      	ldr	r3, [sp, #136]	; 0x88
d000451e:	9921      	ldr	r1, [sp, #132]	; 0x84
d0004520:	1e7e      	subs	r6, r7, #1
d0004522:	f103 3eff 	add.w	lr, r3, #4294967295	; 0xffffffff
d0004526:	9850      	ldr	r0, [sp, #320]	; 0x140
d0004528:	f101 3cff 	add.w	ip, r1, #4294967295	; 0xffffffff
d000452c:	f812 3f01 	ldrb.w	r3, [r2, #1]!
d0004530:	4631      	mov	r1, r6
d0004532:	f816 9f01 	ldrb.w	r9, [r6, #1]!
d0004536:	3102      	adds	r1, #2
d0004538:	fb13 f309 	smulbb	r3, r3, r9
d000453c:	1bc9      	subs	r1, r1, r7
d000453e:	3380      	adds	r3, #128	; 0x80
d0004540:	eb03 2313 	add.w	r3, r3, r3, lsr #8
d0004544:	0a1b      	lsrs	r3, r3, #8
d0004546:	702b      	strb	r3, [r5, #0]
d0004548:	f81c 8f01 	ldrb.w	r8, [ip, #1]!
d000454c:	fb18 f809 	smulbb	r8, r8, r9
d0004550:	f108 0880 	add.w	r8, r8, #128	; 0x80
d0004554:	eb08 2818 	add.w	r8, r8, r8, lsr #8
d0004558:	ea4f 2818 	mov.w	r8, r8, lsr #8
d000455c:	f885 8001 	strb.w	r8, [r5, #1]
d0004560:	f04f 38ff 	mov.w	r8, #4294967295	; 0xffffffff
d0004564:	f81e 3f01 	ldrb.w	r3, [lr, #1]!
d0004568:	f885 8003 	strb.w	r8, [r5, #3]
d000456c:	fb13 f309 	smulbb	r3, r3, r9
d0004570:	3380      	adds	r3, #128	; 0x80
d0004572:	eb03 2313 	add.w	r3, r3, r3, lsr #8
d0004576:	0a1b      	lsrs	r3, r3, #8
d0004578:	70ab      	strb	r3, [r5, #2]
d000457a:	4405      	add	r5, r0
d000457c:	6823      	ldr	r3, [r4, #0]
d000457e:	428b      	cmp	r3, r1
d0004580:	d8d4      	bhi.n	d000452c <load_jpeg_image.constprop.0+0xb7c>
d0004582:	e683      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d0004584:	f244 73ec 	movw	r3, #18412	; 0x47ec
d0004588:	f85a 3003 	ldr.w	r3, [sl, r3]
d000458c:	2b03      	cmp	r3, #3
d000458e:	9306      	str	r3, [sp, #24]
d0004590:	d00b      	beq.n	d00045aa <load_jpeg_image.constprop.0+0xbfa>
d0004592:	f244 73e8 	movw	r3, #18408	; 0x47e8
d0004596:	f85a 3003 	ldr.w	r3, [sl, r3]
d000459a:	b953      	cbnz	r3, d00045b2 <load_jpeg_image.constprop.0+0xc02>
d000459c:	f244 73e4 	movw	r3, #18404	; 0x47e4
d00045a0:	f85a 3003 	ldr.w	r3, [sl, r3]
d00045a4:	b92b      	cbnz	r3, d00045b2 <load_jpeg_image.constprop.0+0xc02>
d00045a6:	9b04      	ldr	r3, [sp, #16]
d00045a8:	9306      	str	r3, [sp, #24]
d00045aa:	2301      	movs	r3, #1
d00045ac:	930a      	str	r3, [sp, #40]	; 0x28
d00045ae:	f7ff bac2 	b.w	d0003b36 <load_jpeg_image.constprop.0+0x186>
d00045b2:	9b50      	ldr	r3, [sp, #320]	; 0x140
d00045b4:	2b02      	cmp	r3, #2
d00045b6:	f04f 0300 	mov.w	r3, #0
d00045ba:	930a      	str	r3, [sp, #40]	; 0x28
d00045bc:	bfcc      	ite	gt
d00045be:	2303      	movgt	r3, #3
d00045c0:	2301      	movle	r3, #1
d00045c2:	9306      	str	r3, [sp, #24]
d00045c4:	f7ff bab7 	b.w	d0003b36 <load_jpeg_image.constprop.0+0x186>
d00045c8:	f105 0728 	add.w	r7, r5, #40	; 0x28
d00045cc:	692b      	ldr	r3, [r5, #16]
d00045ce:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d00045d0:	69e8      	ldr	r0, [r5, #28]
d00045d2:	4639      	mov	r1, r7
d00045d4:	4798      	blx	r3
d00045d6:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d00045da:	f8d5 50b4 	ldr.w	r5, [r5, #180]	; 0xb4
d00045de:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d00045e2:	1b52      	subs	r2, r2, r5
d00045e4:	4413      	add	r3, r2
d00045e6:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d00045ea:	2800      	cmp	r0, #0
d00045ec:	f040 817a 	bne.w	d00048e4 <load_jpeg_image.constprop.0+0xf34>
d00045f0:	f106 0329 	add.w	r3, r6, #41	; 0x29
d00045f4:	f244 72f0 	movw	r2, #18416	; 0x47f0
d00045f8:	6230      	str	r0, [r6, #32]
d00045fa:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d00045fe:	f8c6 30b0 	str.w	r3, [r6, #176]	; 0xb0
d0004602:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d0004606:	f8da 6000 	ldr.w	r6, [sl]
d000460a:	f84a 0002 	str.w	r0, [sl, r2]
d000460e:	f8d6 c008 	ldr.w	ip, [r6, #8]
d0004612:	f7ff bb33 	b.w	d0003c7c <load_jpeg_image.constprop.0+0x2cc>
d0004616:	f105 0428 	add.w	r4, r5, #40	; 0x28
d000461a:	692b      	ldr	r3, [r5, #16]
d000461c:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d000461e:	4621      	mov	r1, r4
d0004620:	69e8      	ldr	r0, [r5, #28]
d0004622:	4798      	blx	r3
d0004624:	f8d5 30ac 	ldr.w	r3, [r5, #172]	; 0xac
d0004628:	f8d5 20b4 	ldr.w	r2, [r5, #180]	; 0xb4
d000462c:	f8d5 10a8 	ldr.w	r1, [r5, #168]	; 0xa8
d0004630:	1a9b      	subs	r3, r3, r2
d0004632:	4419      	add	r1, r3
d0004634:	f8c5 10a8 	str.w	r1, [r5, #168]	; 0xa8
d0004638:	2800      	cmp	r0, #0
d000463a:	f040 8165 	bne.w	d0004908 <load_jpeg_image.constprop.0+0xf58>
d000463e:	f105 0329 	add.w	r3, r5, #41	; 0x29
d0004642:	6228      	str	r0, [r5, #32]
d0004644:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0004648:	4619      	mov	r1, r3
d000464a:	f895 4028 	ldrb.w	r4, [r5, #40]	; 0x28
d000464e:	4299      	cmp	r1, r3
d0004650:	f8c5 30b0 	str.w	r3, [r5, #176]	; 0xb0
d0004654:	ea4f 2404 	mov.w	r4, r4, lsl #8
d0004658:	f8c5 10ac 	str.w	r1, [r5, #172]	; 0xac
d000465c:	f4ff abee 	bcc.w	d0003e3c <load_jpeg_image.constprop.0+0x48c>
d0004660:	6a2b      	ldr	r3, [r5, #32]
d0004662:	b303      	cbz	r3, d00046a6 <load_jpeg_image.constprop.0+0xcf6>
d0004664:	f105 0728 	add.w	r7, r5, #40	; 0x28
d0004668:	692b      	ldr	r3, [r5, #16]
d000466a:	6a6a      	ldr	r2, [r5, #36]	; 0x24
d000466c:	4639      	mov	r1, r7
d000466e:	69e8      	ldr	r0, [r5, #28]
d0004670:	4798      	blx	r3
d0004672:	f8d5 20ac 	ldr.w	r2, [r5, #172]	; 0xac
d0004676:	f8d5 60b4 	ldr.w	r6, [r5, #180]	; 0xb4
d000467a:	f8d5 30a8 	ldr.w	r3, [r5, #168]	; 0xa8
d000467e:	1b92      	subs	r2, r2, r6
d0004680:	4413      	add	r3, r2
d0004682:	f8c5 30a8 	str.w	r3, [r5, #168]	; 0xa8
d0004686:	2800      	cmp	r0, #0
d0004688:	f040 813a 	bne.w	d0004900 <load_jpeg_image.constprop.0+0xf50>
d000468c:	f105 0729 	add.w	r7, r5, #41	; 0x29
d0004690:	6228      	str	r0, [r5, #32]
d0004692:	f885 0028 	strb.w	r0, [r5, #40]	; 0x28
d0004696:	463a      	mov	r2, r7
d0004698:	f895 3028 	ldrb.w	r3, [r5, #40]	; 0x28
d000469c:	f8c5 70b0 	str.w	r7, [r5, #176]	; 0xb0
d00046a0:	441c      	add	r4, r3
d00046a2:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d00046a6:	f8da 5000 	ldr.w	r5, [sl]
d00046aa:	f7ff bad6 	b.w	d0003c5a <load_jpeg_image.constprop.0+0x2aa>
d00046ae:	2301      	movs	r3, #1
d00046b0:	9350      	str	r3, [sp, #320]	; 0x140
d00046b2:	f7ff ba3a 	b.w	d0003b2a <load_jpeg_image.constprop.0+0x17a>
d00046b6:	f104 0528 	add.w	r5, r4, #40	; 0x28
d00046ba:	6923      	ldr	r3, [r4, #16]
d00046bc:	6a62      	ldr	r2, [r4, #36]	; 0x24
d00046be:	4629      	mov	r1, r5
d00046c0:	69e0      	ldr	r0, [r4, #28]
d00046c2:	4798      	blx	r3
d00046c4:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d00046c8:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d00046cc:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d00046d0:	1a52      	subs	r2, r2, r1
d00046d2:	4413      	add	r3, r2
d00046d4:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d00046d8:	2800      	cmp	r0, #0
d00046da:	d068      	beq.n	d00047ae <load_jpeg_image.constprop.0+0xdfe>
d00046dc:	4428      	add	r0, r5
d00046de:	f104 0229 	add.w	r2, r4, #41	; 0x29
d00046e2:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d00046e6:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d00046ea:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d00046ee:	f7ff bbbb 	b.w	d0003e68 <load_jpeg_image.constprop.0+0x4b8>
d00046f2:	2400      	movs	r4, #0
d00046f4:	f7ff bb63 	b.w	d0003dbe <load_jpeg_image.constprop.0+0x40e>
d00046f8:	f244 73cc 	movw	r3, #18380	; 0x47cc
d00046fc:	f85a 3003 	ldr.w	r3, [sl, r3]
d0004700:	2b00      	cmp	r3, #0
d0004702:	f43f aa02 	beq.w	d0003b0a <load_jpeg_image.constprop.0+0x15a>
d0004706:	f8da 5000 	ldr.w	r5, [sl]
d000470a:	68a9      	ldr	r1, [r5, #8]
d000470c:	462c      	mov	r4, r5
d000470e:	2900      	cmp	r1, #0
d0004710:	9104      	str	r1, [sp, #16]
d0004712:	f77f a9fe 	ble.w	d0003b12 <load_jpeg_image.constprop.0+0x162>
d0004716:	f244 66a8 	movw	r6, #18088	; 0x46a8
d000471a:	f644 090c 	movw	r9, #18444	; 0x480c
d000471e:	f04f 0b00 	mov.w	fp, #0
d0004722:	4456      	add	r6, sl
d0004724:	44d1      	add	r9, sl
d0004726:	6972      	ldr	r2, [r6, #20]
d0004728:	6933      	ldr	r3, [r6, #16]
d000472a:	3207      	adds	r2, #7
d000472c:	3307      	adds	r3, #7
d000472e:	ea4f 08e2 	mov.w	r8, r2, asr #3
d0004732:	10df      	asrs	r7, r3, #3
d0004734:	f1b8 0f00 	cmp.w	r8, #0
d0004738:	dd2e      	ble.n	d0004798 <load_jpeg_image.constprop.0+0xde8>
d000473a:	2f00      	cmp	r7, #0
d000473c:	dd2a      	ble.n	d0004794 <load_jpeg_image.constprop.0+0xde4>
d000473e:	2500      	movs	r5, #0
d0004740:	2400      	movs	r4, #0
d0004742:	6b73      	ldr	r3, [r6, #52]	; 0x34
d0004744:	f243 4082 	movw	r0, #13442	; 0x3482
d0004748:	6b32      	ldr	r2, [r6, #48]	; 0x30
d000474a:	fb03 4105 	mla	r1, r3, r5, r4
d000474e:	6833      	ldr	r3, [r6, #0]
d0004750:	eb02 12c1 	add.w	r2, r2, r1, lsl #7
d0004754:	eb0a 11c3 	add.w	r1, sl, r3, lsl #7
d0004758:	f102 0c7e 	add.w	ip, r2, #126	; 0x7e
d000475c:	1e93      	subs	r3, r2, #2
d000475e:	4408      	add	r0, r1
d0004760:	f833 1f02 	ldrh.w	r1, [r3, #2]!
d0004764:	f830 ef02 	ldrh.w	lr, [r0, #2]!
d0004768:	4563      	cmp	r3, ip
d000476a:	fb11 f10e 	smulbb	r1, r1, lr
d000476e:	8019      	strh	r1, [r3, #0]
d0004770:	d1f6      	bne.n	d0004760 <load_jpeg_image.constprop.0+0xdb0>
d0004772:	69b1      	ldr	r1, [r6, #24]
d0004774:	6a30      	ldr	r0, [r6, #32]
d0004776:	fb05 4c01 	mla	ip, r5, r1, r4
d000477a:	3401      	adds	r4, #1
d000477c:	f8d9 3000 	ldr.w	r3, [r9]
d0004780:	eb00 00cc 	add.w	r0, r0, ip, lsl #3
d0004784:	4798      	blx	r3
d0004786:	42a7      	cmp	r7, r4
d0004788:	d1db      	bne.n	d0004742 <load_jpeg_image.constprop.0+0xd92>
d000478a:	3501      	adds	r5, #1
d000478c:	45a8      	cmp	r8, r5
d000478e:	d1d7      	bne.n	d0004740 <load_jpeg_image.constprop.0+0xd90>
d0004790:	f8da 5000 	ldr.w	r5, [sl]
d0004794:	462c      	mov	r4, r5
d0004796:	68a9      	ldr	r1, [r5, #8]
d0004798:	f10b 0b01 	add.w	fp, fp, #1
d000479c:	3648      	adds	r6, #72	; 0x48
d000479e:	458b      	cmp	fp, r1
d00047a0:	dbc1      	blt.n	d0004726 <load_jpeg_image.constprop.0+0xd76>
d00047a2:	9104      	str	r1, [sp, #16]
d00047a4:	f7ff b9b5 	b.w	d0003b12 <load_jpeg_image.constprop.0+0x162>
d00047a8:	2401      	movs	r4, #1
d00047aa:	f7ff bb08 	b.w	d0003dbe <load_jpeg_image.constprop.0+0x40e>
d00047ae:	f104 0329 	add.w	r3, r4, #41	; 0x29
d00047b2:	6220      	str	r0, [r4, #32]
d00047b4:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d00047b8:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d00047bc:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d00047c0:	f7ff b99d 	b.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d00047c4:	2402      	movs	r4, #2
d00047c6:	f7ff bafa 	b.w	d0003dbe <load_jpeg_image.constprop.0+0x40e>
d00047ca:	6823      	ldr	r3, [r4, #0]
d00047cc:	2b00      	cmp	r3, #0
d00047ce:	f43f ad5d 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00047d2:	f8dd 908c 	ldr.w	r9, [sp, #140]	; 0x8c
d00047d6:	f04f 0b96 	mov.w	fp, #150	; 0x96
d00047da:	9a20      	ldr	r2, [sp, #128]	; 0x80
d00047dc:	9b21      	ldr	r3, [sp, #132]	; 0x84
d00047de:	f109 30ff 	add.w	r0, r9, #4294967295	; 0xffffffff
d00047e2:	9922      	ldr	r1, [sp, #136]	; 0x88
d00047e4:	3a01      	subs	r2, #1
d00047e6:	1e5e      	subs	r6, r3, #1
d00047e8:	f101 38ff 	add.w	r8, r1, #4294967295	; 0xffffffff
d00047ec:	f816 cf01 	ldrb.w	ip, [r6, #1]!
d00047f0:	4601      	mov	r1, r0
d00047f2:	f818 7f01 	ldrb.w	r7, [r8, #1]!
d00047f6:	f04f 3aff 	mov.w	sl, #4294967295	; 0xffffffff
d00047fa:	f810 3f01 	ldrb.w	r3, [r0, #1]!
d00047fe:	3102      	adds	r1, #2
d0004800:	f812 ef01 	ldrb.w	lr, [r2, #1]!
d0004804:	fb1c fc03 	smulbb	ip, ip, r3
d0004808:	f885 a001 	strb.w	sl, [r5, #1]
d000480c:	fb17 f703 	smulbb	r7, r7, r3
d0004810:	f04f 0a4d 	mov.w	sl, #77	; 0x4d
d0004814:	fb1e f303 	smulbb	r3, lr, r3
d0004818:	f10c 0c80 	add.w	ip, ip, #128	; 0x80
d000481c:	3780      	adds	r7, #128	; 0x80
d000481e:	eba1 0109 	sub.w	r1, r1, r9
d0004822:	eb0c 2c1c 	add.w	ip, ip, ip, lsr #8
d0004826:	3380      	adds	r3, #128	; 0x80
d0004828:	eb07 2717 	add.w	r7, r7, r7, lsr #8
d000482c:	ea4f 2c1c 	mov.w	ip, ip, lsr #8
d0004830:	0a3f      	lsrs	r7, r7, #8
d0004832:	eb03 2313 	add.w	r3, r3, r3, lsr #8
d0004836:	fb0b fc0c 	mul.w	ip, fp, ip
d000483a:	ebc7 0ec7 	rsb	lr, r7, r7, lsl #3
d000483e:	0a1b      	lsrs	r3, r3, #8
d0004840:	eb07 078e 	add.w	r7, r7, lr, lsl #2
d0004844:	fb0a c303 	mla	r3, sl, r3, ip
d0004848:	443b      	add	r3, r7
d000484a:	121b      	asrs	r3, r3, #8
d000484c:	702b      	strb	r3, [r5, #0]
d000484e:	9b50      	ldr	r3, [sp, #320]	; 0x140
d0004850:	441d      	add	r5, r3
d0004852:	6823      	ldr	r3, [r4, #0]
d0004854:	428b      	cmp	r3, r1
d0004856:	d8c9      	bhi.n	d00047ec <load_jpeg_image.constprop.0+0xe3c>
d0004858:	e518      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d000485a:	9b50      	ldr	r3, [sp, #320]	; 0x140
d000485c:	4616      	mov	r6, r2
d000485e:	f644 0210 	movw	r2, #18448	; 0x4810
d0004862:	4658      	mov	r0, fp
d0004864:	9301      	str	r3, [sp, #4]
d0004866:	6823      	ldr	r3, [r4, #0]
d0004868:	58b4      	ldr	r4, [r6, r2]
d000486a:	9300      	str	r3, [sp, #0]
d000486c:	9a21      	ldr	r2, [sp, #132]	; 0x84
d000486e:	9b22      	ldr	r3, [sp, #136]	; 0x88
d0004870:	47a0      	blx	r4
d0004872:	6834      	ldr	r4, [r6, #0]
d0004874:	6823      	ldr	r3, [r4, #0]
d0004876:	2b00      	cmp	r3, #0
d0004878:	f43f ad08 	beq.w	d000428c <load_jpeg_image.constprop.0+0x8dc>
d000487c:	9f23      	ldr	r7, [sp, #140]	; 0x8c
d000487e:	9950      	ldr	r1, [sp, #320]	; 0x140
d0004880:	1e7e      	subs	r6, r7, #1
d0004882:	f895 c000 	ldrb.w	ip, [r5]
d0004886:	4630      	mov	r0, r6
d0004888:	786a      	ldrb	r2, [r5, #1]
d000488a:	78ab      	ldrb	r3, [r5, #2]
d000488c:	ea6f 0c0c 	mvn.w	ip, ip
d0004890:	43d2      	mvns	r2, r2
d0004892:	f816 ef01 	ldrb.w	lr, [r6, #1]!
d0004896:	43db      	mvns	r3, r3
d0004898:	fa5f fc8c 	uxtb.w	ip, ip
d000489c:	b2d2      	uxtb	r2, r2
d000489e:	3002      	adds	r0, #2
d00048a0:	fb1c fc0e 	smulbb	ip, ip, lr
d00048a4:	b2db      	uxtb	r3, r3
d00048a6:	fb12 f20e 	smulbb	r2, r2, lr
d00048aa:	1bc0      	subs	r0, r0, r7
d00048ac:	fb13 f30e 	smulbb	r3, r3, lr
d00048b0:	f10c 0c80 	add.w	ip, ip, #128	; 0x80
d00048b4:	3280      	adds	r2, #128	; 0x80
d00048b6:	3380      	adds	r3, #128	; 0x80
d00048b8:	eb0c 2c1c 	add.w	ip, ip, ip, lsr #8
d00048bc:	eb02 2212 	add.w	r2, r2, r2, lsr #8
d00048c0:	eb03 2313 	add.w	r3, r3, r3, lsr #8
d00048c4:	ea4f 2c1c 	mov.w	ip, ip, lsr #8
d00048c8:	0a1b      	lsrs	r3, r3, #8
d00048ca:	0a12      	lsrs	r2, r2, #8
d00048cc:	f885 c000 	strb.w	ip, [r5]
d00048d0:	70ab      	strb	r3, [r5, #2]
d00048d2:	706a      	strb	r2, [r5, #1]
d00048d4:	440d      	add	r5, r1
d00048d6:	6823      	ldr	r3, [r4, #0]
d00048d8:	4283      	cmp	r3, r0
d00048da:	d8d2      	bhi.n	d0004882 <load_jpeg_image.constprop.0+0xed2>
d00048dc:	e4d6      	b.n	d000428c <load_jpeg_image.constprop.0+0x8dc>
d00048de:	2403      	movs	r4, #3
d00048e0:	f7ff ba6d 	b.w	d0003dbe <load_jpeg_image.constprop.0+0x40e>
d00048e4:	f106 0229 	add.w	r2, r6, #41	; 0x29
d00048e8:	f896 3028 	ldrb.w	r3, [r6, #40]	; 0x28
d00048ec:	4438      	add	r0, r7
d00048ee:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d00048f2:	1e5a      	subs	r2, r3, #1
d00048f4:	f8c6 00b0 	str.w	r0, [r6, #176]	; 0xb0
d00048f8:	f8da 6000 	ldr.w	r6, [sl]
d00048fc:	f7ff ba11 	b.w	d0003d22 <load_jpeg_image.constprop.0+0x372>
d0004900:	4407      	add	r7, r0
d0004902:	f105 0229 	add.w	r2, r5, #41	; 0x29
d0004906:	e6c7      	b.n	d0004698 <load_jpeg_image.constprop.0+0xce8>
d0004908:	1823      	adds	r3, r4, r0
d000490a:	f105 0129 	add.w	r1, r5, #41	; 0x29
d000490e:	e69c      	b.n	d000464a <load_jpeg_image.constprop.0+0xc9a>
d0004910:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0004914:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d0004918:	429a      	cmp	r2, r3
d000491a:	f0c0 8421 	bcc.w	d0005160 <load_jpeg_image.constprop.0+0x17b0>
d000491e:	6a33      	ldr	r3, [r6, #32]
d0004920:	2b00      	cmp	r3, #0
d0004922:	d171      	bne.n	d0004a08 <load_jpeg_image.constprop.0+0x1058>
d0004924:	f244 72d0 	movw	r2, #18384	; 0x47d0
d0004928:	f84a 3002 	str.w	r3, [sl, r2]
d000492c:	eb0a 0302 	add.w	r3, sl, r2
d0004930:	9310      	str	r3, [sp, #64]	; 0x40
d0004932:	6a33      	ldr	r3, [r6, #32]
d0004934:	2b00      	cmp	r3, #0
d0004936:	f040 8468 	bne.w	d000520a <load_jpeg_image.constprop.0+0x185a>
d000493a:	f244 72d4 	movw	r2, #18388	; 0x47d4
d000493e:	f84a 3002 	str.w	r3, [sl, r2]
d0004942:	eb0a 0302 	add.w	r3, sl, r2
d0004946:	9307      	str	r3, [sp, #28]
d0004948:	6a30      	ldr	r0, [r6, #32]
d000494a:	2800      	cmp	r0, #0
d000494c:	f040 843b 	bne.w	d00051c6 <load_jpeg_image.constprop.0+0x1816>
d0004950:	4605      	mov	r5, r0
d0004952:	4603      	mov	r3, r0
d0004954:	f244 71d8 	movw	r1, #18392	; 0x47d8
d0004958:	f244 72dc 	movw	r2, #18396	; 0x47dc
d000495c:	f244 74cc 	movw	r4, #18380	; 0x47cc
d0004960:	eb0a 0601 	add.w	r6, sl, r1
d0004964:	f85a 4004 	ldr.w	r4, [sl, r4]
d0004968:	f84a 0001 	str.w	r0, [sl, r1]
d000496c:	eb0a 0102 	add.w	r1, sl, r2
d0004970:	f84a 5002 	str.w	r5, [sl, r2]
d0004974:	9618      	str	r6, [sp, #96]	; 0x60
d0004976:	9a10      	ldr	r2, [sp, #64]	; 0x40
d0004978:	911a      	str	r1, [sp, #104]	; 0x68
d000497a:	2c00      	cmp	r4, #0
d000497c:	f000 8087 	beq.w	d0004a8e <load_jpeg_image.constprop.0+0x10de>
d0004980:	6811      	ldr	r1, [r2, #0]
d0004982:	293f      	cmp	r1, #63	; 0x3f
d0004984:	dc14      	bgt.n	d00049b0 <load_jpeg_image.constprop.0+0x1000>
d0004986:	9a07      	ldr	r2, [sp, #28]
d0004988:	6812      	ldr	r2, [r2, #0]
d000498a:	4291      	cmp	r1, r2
d000498c:	bfd8      	it	le
d000498e:	2a3f      	cmple	r2, #63	; 0x3f
d0004990:	bfcc      	ite	gt
d0004992:	2201      	movgt	r2, #1
d0004994:	2200      	movle	r2, #0
d0004996:	280d      	cmp	r0, #13
d0004998:	bfd4      	ite	le
d000499a:	4610      	movle	r0, r2
d000499c:	f042 0001 	orrgt.w	r0, r2, #1
d00049a0:	b930      	cbnz	r0, d00049b0 <load_jpeg_image.constprop.0+0x1000>
d00049a2:	2b0d      	cmp	r3, #13
d00049a4:	bf94      	ite	ls
d00049a6:	2300      	movls	r3, #0
d00049a8:	2301      	movhi	r3, #1
d00049aa:	2b00      	cmp	r3, #0
d00049ac:	f000 847c 	beq.w	d00052a8 <load_jpeg_image.constprop.0+0x18f8>
d00049b0:	4ab1      	ldr	r2, [pc, #708]	; (d0004c78 <load_jpeg_image.constprop.0+0x12c8>)
d00049b2:	49b2      	ldr	r1, [pc, #712]	; (d0004c7c <load_jpeg_image.constprop.0+0x12cc>)
d00049b4:	f8da 3000 	ldr.w	r3, [sl]
d00049b8:	6011      	str	r1, [r2, #0]
d00049ba:	f8d3 c008 	ldr.w	ip, [r3, #8]
d00049be:	f7ff b82a 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d00049c2:	46a4      	mov	ip, r4
d00049c4:	f7ff b827 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d00049c8:	4bab      	ldr	r3, [pc, #684]	; (d0004c78 <load_jpeg_image.constprop.0+0x12c8>)
d00049ca:	468c      	mov	ip, r1
d00049cc:	4aac      	ldr	r2, [pc, #688]	; (d0004c80 <load_jpeg_image.constprop.0+0x12d0>)
d00049ce:	601a      	str	r2, [r3, #0]
d00049d0:	f7ff b821 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d00049d4:	4ba8      	ldr	r3, [pc, #672]	; (d0004c78 <load_jpeg_image.constprop.0+0x12c8>)
d00049d6:	468c      	mov	ip, r1
d00049d8:	4aaa      	ldr	r2, [pc, #680]	; (d0004c84 <load_jpeg_image.constprop.0+0x12d4>)
d00049da:	601a      	str	r2, [r3, #0]
d00049dc:	f7ff b81b 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d00049e0:	2001      	movs	r0, #1
d00049e2:	f007 f8f3 	bl	d000bbcc <malloc>
d00049e6:	9008      	str	r0, [sp, #32]
d00049e8:	2800      	cmp	r0, #0
d00049ea:	f47f acf7 	bne.w	d00043dc <load_jpeg_image.constprop.0+0xa2c>
d00049ee:	f7ff b918 	b.w	d0003c22 <load_jpeg_image.constprop.0+0x272>
d00049f2:	4430      	add	r0, r6
d00049f4:	f105 0229 	add.w	r2, r5, #41	; 0x29
d00049f8:	f895 3028 	ldrb.w	r3, [r5, #40]	; 0x28
d00049fc:	f8c5 00b0 	str.w	r0, [r5, #176]	; 0xb0
d0004a00:	f8c5 20ac 	str.w	r2, [r5, #172]	; 0xac
d0004a04:	f7ff bb5e 	b.w	d00040c4 <load_jpeg_image.constprop.0+0x714>
d0004a08:	f106 0528 	add.w	r5, r6, #40	; 0x28
d0004a0c:	6933      	ldr	r3, [r6, #16]
d0004a0e:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0004a10:	4629      	mov	r1, r5
d0004a12:	69f0      	ldr	r0, [r6, #28]
d0004a14:	4798      	blx	r3
d0004a16:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d0004a1a:	f8d6 40b4 	ldr.w	r4, [r6, #180]	; 0xb4
d0004a1e:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0004a22:	1b12      	subs	r2, r2, r4
d0004a24:	4413      	add	r3, r2
d0004a26:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d0004a2a:	2800      	cmp	r0, #0
d0004a2c:	f040 87c7 	bne.w	d00059be <load_jpeg_image.constprop.0+0x200e>
d0004a30:	f106 0529 	add.w	r5, r6, #41	; 0x29
d0004a34:	6230      	str	r0, [r6, #32]
d0004a36:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d0004a3a:	462b      	mov	r3, r5
d0004a3c:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d0004a40:	f8c6 50b0 	str.w	r5, [r6, #176]	; 0xb0
d0004a44:	f8da 6000 	ldr.w	r6, [sl]
d0004a48:	f8d6 10ac 	ldr.w	r1, [r6, #172]	; 0xac
d0004a4c:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d0004a50:	f244 72d0 	movw	r2, #18384	; 0x47d0
d0004a54:	4299      	cmp	r1, r3
d0004a56:	f84a 0002 	str.w	r0, [sl, r2]
d0004a5a:	4452      	add	r2, sl
d0004a5c:	9210      	str	r2, [sp, #64]	; 0x40
d0004a5e:	f4bf af68 	bcs.w	d0004932 <load_jpeg_image.constprop.0+0xf82>
d0004a62:	1c4a      	adds	r2, r1, #1
d0004a64:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d0004a68:	7808      	ldrb	r0, [r1, #0]
d0004a6a:	f244 71d4 	movw	r1, #18388	; 0x47d4
d0004a6e:	429a      	cmp	r2, r3
d0004a70:	f84a 0001 	str.w	r0, [sl, r1]
d0004a74:	4451      	add	r1, sl
d0004a76:	9107      	str	r1, [sp, #28]
d0004a78:	f4bf af66 	bcs.w	d0004948 <load_jpeg_image.constprop.0+0xf98>
d0004a7c:	1c53      	adds	r3, r2, #1
d0004a7e:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d0004a82:	7810      	ldrb	r0, [r2, #0]
d0004a84:	f000 030f 	and.w	r3, r0, #15
d0004a88:	1100      	asrs	r0, r0, #4
d0004a8a:	461d      	mov	r5, r3
d0004a8c:	e762      	b.n	d0004954 <load_jpeg_image.constprop.0+0xfa4>
d0004a8e:	6812      	ldr	r2, [r2, #0]
d0004a90:	9208      	str	r2, [sp, #32]
d0004a92:	2a00      	cmp	r2, #0
d0004a94:	d18c      	bne.n	d00049b0 <load_jpeg_image.constprop.0+0x1000>
d0004a96:	2800      	cmp	r0, #0
d0004a98:	d18a      	bne.n	d00049b0 <load_jpeg_image.constprop.0+0x1000>
d0004a9a:	2b00      	cmp	r3, #0
d0004a9c:	d188      	bne.n	d00049b0 <load_jpeg_image.constprop.0+0x1000>
d0004a9e:	233f      	movs	r3, #63	; 0x3f
d0004aa0:	9c07      	ldr	r4, [sp, #28]
d0004aa2:	f244 77c0 	movw	r7, #18368	; 0x47c0
d0004aa6:	f244 76bc 	movw	r6, #18364	; 0x47bc
d0004aaa:	6023      	str	r3, [r4, #0]
d0004aac:	f244 75c8 	movw	r5, #18376	; 0x47c8
d0004ab0:	9c08      	ldr	r4, [sp, #32]
d0004ab2:	f244 7e8c 	movw	lr, #18316	; 0x478c
d0004ab6:	f244 7044 	movw	r0, #18244	; 0x4744
d0004aba:	f244 61fc 	movw	r1, #18172	; 0x46fc
d0004abe:	f84a 4007 	str.w	r4, [sl, r7]
d0004ac2:	eb0a 0907 	add.w	r9, sl, r7
d0004ac6:	4627      	mov	r7, r4
d0004ac8:	f84a 4006 	str.w	r4, [sl, r6]
d0004acc:	f84a 4005 	str.w	r4, [sl, r5]
d0004ad0:	f244 62b4 	movw	r2, #18100	; 0x46b4
d0004ad4:	f84a 400e 	str.w	r4, [sl, lr]
d0004ad8:	f644 0304 	movw	r3, #18436	; 0x4804
d0004adc:	f84a 7000 	str.w	r7, [sl, r0]
d0004ae0:	eb0a 0405 	add.w	r4, sl, r5
d0004ae4:	f84a 7001 	str.w	r7, [sl, r1]
d0004ae8:	4451      	add	r1, sl
d0004aea:	f04f 0cff 	mov.w	ip, #255	; 0xff
d0004aee:	f84a 7002 	str.w	r7, [sl, r2]
d0004af2:	9113      	str	r1, [sp, #76]	; 0x4c
d0004af4:	4450      	add	r0, sl
d0004af6:	9905      	ldr	r1, [sp, #20]
d0004af8:	4452      	add	r2, sl
d0004afa:	9416      	str	r4, [sp, #88]	; 0x58
d0004afc:	eb0a 040e 	add.w	r4, sl, lr
d0004b00:	f881 c000 	strb.w	ip, [r1]
d0004b04:	eb0a 0b06 	add.w	fp, sl, r6
d0004b08:	f85a 1003 	ldr.w	r1, [sl, r3]
d0004b0c:	4453      	add	r3, sl
d0004b0e:	9415      	str	r4, [sp, #84]	; 0x54
d0004b10:	9014      	str	r0, [sp, #80]	; 0x50
d0004b12:	9212      	str	r2, [sp, #72]	; 0x48
d0004b14:	9317      	str	r3, [sp, #92]	; 0x5c
d0004b16:	2900      	cmp	r1, #0
d0004b18:	f000 83c1 	beq.w	d000529e <load_jpeg_image.constprop.0+0x18ee>
d0004b1c:	f644 0208 	movw	r2, #18440	; 0x4808
d0004b20:	f84a 1002 	str.w	r1, [sl, r2]
d0004b24:	4452      	add	r2, sl
d0004b26:	f244 73e0 	movw	r3, #18400	; 0x47e0
d0004b2a:	920c      	str	r2, [sp, #48]	; 0x30
d0004b2c:	9a08      	ldr	r2, [sp, #32]
d0004b2e:	f84a 2003 	str.w	r2, [sl, r3]
d0004b32:	4453      	add	r3, sl
d0004b34:	9309      	str	r3, [sp, #36]	; 0x24
d0004b36:	f244 73f0 	movw	r3, #18416	; 0x47f0
d0004b3a:	f85a 3003 	ldr.w	r3, [sl, r3]
d0004b3e:	2b01      	cmp	r3, #1
d0004b40:	f000 8230 	beq.w	d0004fa4 <load_jpeg_image.constprop.0+0x15f4>
d0004b44:	f244 6390 	movw	r3, #18064	; 0x4690
d0004b48:	f85a 2003 	ldr.w	r2, [sl, r3]
d0004b4c:	4453      	add	r3, sl
d0004b4e:	2a00      	cmp	r2, #0
d0004b50:	9310      	str	r3, [sp, #64]	; 0x40
d0004b52:	f340 80ce 	ble.w	d0004cf2 <load_jpeg_image.constprop.0+0x1342>
d0004b56:	f244 638c 	movw	r3, #18060	; 0x468c
d0004b5a:	2000      	movs	r0, #0
d0004b5c:	f641 2144 	movw	r1, #6724	; 0x1a44
d0004b60:	f8cd b064 	str.w	fp, [sp, #100]	; 0x64
d0004b64:	900a      	str	r0, [sp, #40]	; 0x28
d0004b66:	46d3      	mov	fp, sl
d0004b68:	eb0a 0003 	add.w	r0, sl, r3
d0004b6c:	4451      	add	r1, sl
d0004b6e:	f85a 3003 	ldr.w	r3, [sl, r3]
d0004b72:	900f      	str	r0, [sp, #60]	; 0x3c
d0004b74:	910b      	str	r1, [sp, #44]	; 0x2c
d0004b76:	f8cd 9060 	str.w	r9, [sp, #96]	; 0x60
d0004b7a:	2b00      	cmp	r3, #0
d0004b7c:	f340 80a3 	ble.w	d0004cc6 <load_jpeg_image.constprop.0+0x1316>
d0004b80:	2300      	movs	r3, #0
d0004b82:	9308      	str	r3, [sp, #32]
d0004b84:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d0004b86:	681a      	ldr	r2, [r3, #0]
d0004b88:	2a00      	cmp	r2, #0
d0004b8a:	f340 808b 	ble.w	d0004ca4 <load_jpeg_image.constprop.0+0x12f4>
d0004b8e:	f244 73f4 	movw	r3, #18420	; 0x47f4
d0004b92:	2100      	movs	r1, #0
d0004b94:	445b      	add	r3, fp
d0004b96:	9111      	str	r1, [sp, #68]	; 0x44
d0004b98:	930e      	str	r3, [sp, #56]	; 0x38
d0004b9a:	990e      	ldr	r1, [sp, #56]	; 0x38
d0004b9c:	f851 3b04 	ldr.w	r3, [r1], #4
d0004ba0:	9307      	str	r3, [sp, #28]
d0004ba2:	eb03 03c3 	add.w	r3, r3, r3, lsl #3
d0004ba6:	910e      	str	r1, [sp, #56]	; 0x38
d0004ba8:	f244 61a4 	movw	r1, #18084	; 0x46a4
d0004bac:	eb0b 03c3 	add.w	r3, fp, r3, lsl #3
d0004bb0:	585d      	ldr	r5, [r3, r1]
d0004bb2:	2d00      	cmp	r5, #0
d0004bb4:	dd70      	ble.n	d0004c98 <load_jpeg_image.constprop.0+0x12e8>
d0004bb6:	f244 62a0 	movw	r2, #18080	; 0x46a0
d0004bba:	2100      	movs	r1, #0
d0004bbc:	461e      	mov	r6, r3
d0004bbe:	589c      	ldr	r4, [r3, r2]
d0004bc0:	9104      	str	r1, [sp, #16]
d0004bc2:	2c00      	cmp	r4, #0
d0004bc4:	dd61      	ble.n	d0004c8a <load_jpeg_image.constprop.0+0x12da>
d0004bc6:	f244 6ab0 	movw	sl, #18096	; 0x46b0
d0004bca:	f244 69ac 	movw	r9, #18092	; 0x46ac
d0004bce:	f10b 0304 	add.w	r3, fp, #4
d0004bd2:	2700      	movs	r7, #0
d0004bd4:	44b2      	add	sl, r6
d0004bd6:	44b1      	add	r9, r6
d0004bd8:	f10d 0890 	add.w	r8, sp, #144	; 0x90
d0004bdc:	46ae      	mov	lr, r5
d0004bde:	9306      	str	r3, [sp, #24]
d0004be0:	e013      	b.n	d0004c0a <load_jpeg_image.constprop.0+0x125a>
d0004be2:	5871      	ldr	r1, [r6, r1]
d0004be4:	f856 000c 	ldr.w	r0, [r6, ip]
d0004be8:	fb01 f505 	mul.w	r5, r1, r5
d0004bec:	f85b 3003 	ldr.w	r3, [fp, r3]
d0004bf0:	eb04 04c5 	add.w	r4, r4, r5, lsl #3
d0004bf4:	4420      	add	r0, r4
d0004bf6:	4798      	blx	r3
d0004bf8:	f244 63a0 	movw	r3, #18080	; 0x46a0
d0004bfc:	58f4      	ldr	r4, [r6, r3]
d0004bfe:	f244 63a4 	movw	r3, #18084	; 0x46a4
d0004c02:	42bc      	cmp	r4, r7
d0004c04:	dd40      	ble.n	d0004c88 <load_jpeg_image.constprop.0+0x12d8>
d0004c06:	f856 e003 	ldr.w	lr, [r6, r3]
d0004c0a:	f244 62a8 	movw	r2, #18088	; 0x46a8
d0004c0e:	f8da 3000 	ldr.w	r3, [sl]
d0004c12:	9d08      	ldr	r5, [sp, #32]
d0004c14:	f243 4184 	movw	r1, #13444	; 0x3484
d0004c18:	58b2      	ldr	r2, [r6, r2]
d0004c1a:	eb0b 2c83 	add.w	ip, fp, r3, lsl #10
d0004c1e:	fb05 7404 	mla	r4, r5, r4, r7
d0004c22:	f243 6084 	movw	r0, #13956	; 0x3684
d0004c26:	9d07      	ldr	r5, [sp, #28]
d0004c28:	eb0b 12c2 	add.w	r2, fp, r2, lsl #7
d0004c2c:	4460      	add	r0, ip
d0004c2e:	f8d9 c000 	ldr.w	ip, [r9]
d0004c32:	4411      	add	r1, r2
d0004c34:	9501      	str	r5, [sp, #4]
d0004c36:	f44f 62d2 	mov.w	r2, #1680	; 0x690
d0004c3a:	9d0b      	ldr	r5, [sp, #44]	; 0x2c
d0004c3c:	9102      	str	r1, [sp, #8]
d0004c3e:	4641      	mov	r1, r8
d0004c40:	fb02 5303 	mla	r3, r2, r3, r5
d0004c44:	9d06      	ldr	r5, [sp, #24]
d0004c46:	9000      	str	r0, [sp, #0]
d0004c48:	4658      	mov	r0, fp
d0004c4a:	fb02 520c 	mla	r2, r2, ip, r5
d0004c4e:	9d0a      	ldr	r5, [sp, #40]	; 0x28
d0004c50:	00e4      	lsls	r4, r4, #3
d0004c52:	3701      	adds	r7, #1
d0004c54:	46ac      	mov	ip, r5
d0004c56:	9d04      	ldr	r5, [sp, #16]
d0004c58:	fb0e 550c 	mla	r5, lr, ip, r5
d0004c5c:	f7fd f95a 	bl	d0001f14 <stbi__jpeg_decode_block>
d0004c60:	f244 61c0 	movw	r1, #18112	; 0x46c0
d0004c64:	f244 6cc8 	movw	ip, #18120	; 0x46c8
d0004c68:	f644 030c 	movw	r3, #18444	; 0x480c
d0004c6c:	4642      	mov	r2, r8
d0004c6e:	2800      	cmp	r0, #0
d0004c70:	d1b7      	bne.n	d0004be2 <load_jpeg_image.constprop.0+0x1232>
d0004c72:	46da      	mov	sl, fp
d0004c74:	f7fe becb 	b.w	d0003a0e <load_jpeg_image.constprop.0+0x5e>
d0004c78:	d000dec8 	.word	0xd000dec8
d0004c7c:	d000d470 	.word	0xd000d470
d0004c80:	d000d458 	.word	0xd000d458
d0004c84:	d000d464 	.word	0xd000d464
d0004c88:	58f5      	ldr	r5, [r6, r3]
d0004c8a:	9b04      	ldr	r3, [sp, #16]
d0004c8c:	3301      	adds	r3, #1
d0004c8e:	42ab      	cmp	r3, r5
d0004c90:	9304      	str	r3, [sp, #16]
d0004c92:	db96      	blt.n	d0004bc2 <load_jpeg_image.constprop.0+0x1212>
d0004c94:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d0004c96:	681a      	ldr	r2, [r3, #0]
d0004c98:	9b11      	ldr	r3, [sp, #68]	; 0x44
d0004c9a:	3301      	adds	r3, #1
d0004c9c:	4293      	cmp	r3, r2
d0004c9e:	9311      	str	r3, [sp, #68]	; 0x44
d0004ca0:	f6ff af7b 	blt.w	d0004b9a <load_jpeg_image.constprop.0+0x11ea>
d0004ca4:	9a0c      	ldr	r2, [sp, #48]	; 0x30
d0004ca6:	6813      	ldr	r3, [r2, #0]
d0004ca8:	3b01      	subs	r3, #1
d0004caa:	2b00      	cmp	r3, #0
d0004cac:	6013      	str	r3, [r2, #0]
d0004cae:	f340 8262 	ble.w	d0005176 <load_jpeg_image.constprop.0+0x17c6>
d0004cb2:	9a08      	ldr	r2, [sp, #32]
d0004cb4:	9b0f      	ldr	r3, [sp, #60]	; 0x3c
d0004cb6:	3201      	adds	r2, #1
d0004cb8:	681b      	ldr	r3, [r3, #0]
d0004cba:	9208      	str	r2, [sp, #32]
d0004cbc:	429a      	cmp	r2, r3
d0004cbe:	f6ff af61 	blt.w	d0004b84 <load_jpeg_image.constprop.0+0x11d4>
d0004cc2:	9a10      	ldr	r2, [sp, #64]	; 0x40
d0004cc4:	6812      	ldr	r2, [r2, #0]
d0004cc6:	990a      	ldr	r1, [sp, #40]	; 0x28
d0004cc8:	3101      	adds	r1, #1
d0004cca:	4291      	cmp	r1, r2
d0004ccc:	910a      	str	r1, [sp, #40]	; 0x28
d0004cce:	f6ff af54 	blt.w	d0004b7a <load_jpeg_image.constprop.0+0x11ca>
d0004cd2:	46da      	mov	sl, fp
d0004cd4:	9b05      	ldr	r3, [sp, #20]
d0004cd6:	781b      	ldrb	r3, [r3, #0]
d0004cd8:	2bff      	cmp	r3, #255	; 0xff
d0004cda:	d00a      	beq.n	d0004cf2 <load_jpeg_image.constprop.0+0x1342>
d0004cdc:	f1a3 02d0 	sub.w	r2, r3, #208	; 0xd0
d0004ce0:	21ff      	movs	r1, #255	; 0xff
d0004ce2:	9805      	ldr	r0, [sp, #20]
d0004ce4:	2a07      	cmp	r2, #7
d0004ce6:	7001      	strb	r1, [r0, #0]
d0004ce8:	f240 80d7 	bls.w	d0004e9a <load_jpeg_image.constprop.0+0x14ea>
d0004cec:	4619      	mov	r1, r3
d0004cee:	f7fe bee9 	b.w	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0004cf2:	f8da 4000 	ldr.w	r4, [sl]
d0004cf6:	6923      	ldr	r3, [r4, #16]
d0004cf8:	b133      	cbz	r3, d0004d08 <load_jpeg_image.constprop.0+0x1358>
d0004cfa:	69a3      	ldr	r3, [r4, #24]
d0004cfc:	69e0      	ldr	r0, [r4, #28]
d0004cfe:	4798      	blx	r3
d0004d00:	b140      	cbz	r0, d0004d14 <load_jpeg_image.constprop.0+0x1364>
d0004d02:	6a23      	ldr	r3, [r4, #32]
d0004d04:	2b00      	cmp	r3, #0
d0004d06:	d07a      	beq.n	d0004dfe <load_jpeg_image.constprop.0+0x144e>
d0004d08:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0004d0c:	f8d4 30b0 	ldr.w	r3, [r4, #176]	; 0xb0
d0004d10:	429a      	cmp	r2, r3
d0004d12:	d274      	bcs.n	d0004dfe <load_jpeg_image.constprop.0+0x144e>
d0004d14:	f8da 4000 	ldr.w	r4, [sl]
d0004d18:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004d1c:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004d20:	4293      	cmp	r3, r2
d0004d22:	f0c0 81f9 	bcc.w	d0005118 <load_jpeg_image.constprop.0+0x1768>
d0004d26:	6a23      	ldr	r3, [r4, #32]
d0004d28:	2b00      	cmp	r3, #0
d0004d2a:	d0e4      	beq.n	d0004cf6 <load_jpeg_image.constprop.0+0x1346>
d0004d2c:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0004d30:	6923      	ldr	r3, [r4, #16]
d0004d32:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0004d34:	4629      	mov	r1, r5
d0004d36:	69e0      	ldr	r0, [r4, #28]
d0004d38:	4798      	blx	r3
d0004d3a:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0004d3e:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0004d42:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0004d46:	1a52      	subs	r2, r2, r1
d0004d48:	4413      	add	r3, r2
d0004d4a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0004d4e:	2800      	cmp	r0, #0
d0004d50:	f040 820b 	bne.w	d000516a <load_jpeg_image.constprop.0+0x17ba>
d0004d54:	f104 0529 	add.w	r5, r4, #41	; 0x29
d0004d58:	4603      	mov	r3, r0
d0004d5a:	6220      	str	r0, [r4, #32]
d0004d5c:	4629      	mov	r1, r5
d0004d5e:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0004d62:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0004d66:	f8c4 10ac 	str.w	r1, [r4, #172]	; 0xac
d0004d6a:	f8da 4000 	ldr.w	r4, [sl]
d0004d6e:	2bff      	cmp	r3, #255	; 0xff
d0004d70:	d1c1      	bne.n	d0004cf6 <load_jpeg_image.constprop.0+0x1346>
d0004d72:	6923      	ldr	r3, [r4, #16]
d0004d74:	b133      	cbz	r3, d0004d84 <load_jpeg_image.constprop.0+0x13d4>
d0004d76:	69a3      	ldr	r3, [r4, #24]
d0004d78:	69e0      	ldr	r0, [r4, #28]
d0004d7a:	4798      	blx	r3
d0004d7c:	b140      	cbz	r0, d0004d90 <load_jpeg_image.constprop.0+0x13e0>
d0004d7e:	6a23      	ldr	r3, [r4, #32]
d0004d80:	2b00      	cmp	r3, #0
d0004d82:	d03c      	beq.n	d0004dfe <load_jpeg_image.constprop.0+0x144e>
d0004d84:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0004d88:	f8d4 30b0 	ldr.w	r3, [r4, #176]	; 0xb0
d0004d8c:	429a      	cmp	r2, r3
d0004d8e:	d236      	bcs.n	d0004dfe <load_jpeg_image.constprop.0+0x144e>
d0004d90:	f8da 4000 	ldr.w	r4, [sl]
d0004d94:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004d98:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004d9c:	4293      	cmp	r3, r2
d0004d9e:	d322      	bcc.n	d0004de6 <load_jpeg_image.constprop.0+0x1436>
d0004da0:	6a23      	ldr	r3, [r4, #32]
d0004da2:	2b00      	cmp	r3, #0
d0004da4:	d0a7      	beq.n	d0004cf6 <load_jpeg_image.constprop.0+0x1346>
d0004da6:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0004daa:	6923      	ldr	r3, [r4, #16]
d0004dac:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0004dae:	4629      	mov	r1, r5
d0004db0:	69e0      	ldr	r0, [r4, #28]
d0004db2:	4798      	blx	r3
d0004db4:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0004db8:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0004dbc:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0004dc0:	1a52      	subs	r2, r2, r1
d0004dc2:	4413      	add	r3, r2
d0004dc4:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0004dc8:	2800      	cmp	r0, #0
d0004dca:	f040 81aa 	bne.w	d0005122 <load_jpeg_image.constprop.0+0x1772>
d0004dce:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0004dd2:	6220      	str	r0, [r4, #32]
d0004dd4:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0004dd8:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0004ddc:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0004de0:	f8da 4000 	ldr.w	r4, [sl]
d0004de4:	e787      	b.n	d0004cf6 <load_jpeg_image.constprop.0+0x1346>
d0004de6:	1c5a      	adds	r2, r3, #1
d0004de8:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0004dec:	781b      	ldrb	r3, [r3, #0]
d0004dee:	1e5a      	subs	r2, r3, #1
d0004df0:	b2d2      	uxtb	r2, r2
d0004df2:	2afd      	cmp	r2, #253	; 0xfd
d0004df4:	f240 818a 	bls.w	d000510c <load_jpeg_image.constprop.0+0x175c>
d0004df8:	f8da 4000 	ldr.w	r4, [sl]
d0004dfc:	e7b7      	b.n	d0004d6e <load_jpeg_image.constprop.0+0x13be>
d0004dfe:	23ff      	movs	r3, #255	; 0xff
d0004e00:	9a05      	ldr	r2, [sp, #20]
d0004e02:	7013      	strb	r3, [r2, #0]
d0004e04:	f8da 4000 	ldr.w	r4, [sl]
d0004e08:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004e0c:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004e10:	4293      	cmp	r3, r2
d0004e12:	f0c0 8176 	bcc.w	d0005102 <load_jpeg_image.constprop.0+0x1752>
d0004e16:	6a23      	ldr	r3, [r4, #32]
d0004e18:	2b00      	cmp	r3, #0
d0004e1a:	f43e ae70 	beq.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0004e1e:	f104 0628 	add.w	r6, r4, #40	; 0x28
d0004e22:	6923      	ldr	r3, [r4, #16]
d0004e24:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0004e26:	4631      	mov	r1, r6
d0004e28:	69e0      	ldr	r0, [r4, #28]
d0004e2a:	4798      	blx	r3
d0004e2c:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0004e30:	f8d4 50b4 	ldr.w	r5, [r4, #180]	; 0xb4
d0004e34:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0004e38:	1b52      	subs	r2, r2, r5
d0004e3a:	4413      	add	r3, r2
d0004e3c:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0004e40:	2800      	cmp	r0, #0
d0004e42:	f43f acb4 	beq.w	d00047ae <load_jpeg_image.constprop.0+0xdfe>
d0004e46:	4430      	add	r0, r6
d0004e48:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0004e4c:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0004e50:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0004e54:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0004e58:	2bff      	cmp	r3, #255	; 0xff
d0004e5a:	f47e ae50 	bne.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0004e5e:	f8da 4000 	ldr.w	r4, [sl]
d0004e62:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004e66:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004e6a:	4293      	cmp	r3, r2
d0004e6c:	d305      	bcc.n	d0004e7a <load_jpeg_image.constprop.0+0x14ca>
d0004e6e:	6a23      	ldr	r3, [r4, #32]
d0004e70:	2b00      	cmp	r3, #0
d0004e72:	d178      	bne.n	d0004f66 <load_jpeg_image.constprop.0+0x15b6>
d0004e74:	2100      	movs	r1, #0
d0004e76:	f7fe be2d 	b.w	d0003ad4 <load_jpeg_image.constprop.0+0x124>
d0004e7a:	1c5a      	adds	r2, r3, #1
d0004e7c:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0004e80:	7819      	ldrb	r1, [r3, #0]
d0004e82:	29ff      	cmp	r1, #255	; 0xff
d0004e84:	d0eb      	beq.n	d0004e5e <load_jpeg_image.constprop.0+0x14ae>
d0004e86:	f1a1 03d0 	sub.w	r3, r1, #208	; 0xd0
d0004e8a:	2b07      	cmp	r3, #7
d0004e8c:	f63e ae1a 	bhi.w	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0004e90:	9a05      	ldr	r2, [sp, #20]
d0004e92:	7811      	ldrb	r1, [r2, #0]
d0004e94:	29ff      	cmp	r1, #255	; 0xff
d0004e96:	f47e ae13 	bne.w	d0003ac0 <load_jpeg_image.constprop.0+0x110>
d0004e9a:	f8da 4000 	ldr.w	r4, [sl]
d0004e9e:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004ea2:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004ea6:	4293      	cmp	r3, r2
d0004ea8:	f0c0 8147 	bcc.w	d000513a <load_jpeg_image.constprop.0+0x178a>
d0004eac:	6a23      	ldr	r3, [r4, #32]
d0004eae:	2b00      	cmp	r3, #0
d0004eb0:	f43e ae25 	beq.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0004eb4:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0004eb8:	6923      	ldr	r3, [r4, #16]
d0004eba:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0004ebc:	4629      	mov	r1, r5
d0004ebe:	69e0      	ldr	r0, [r4, #28]
d0004ec0:	4798      	blx	r3
d0004ec2:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004ec6:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d0004eca:	f8d4 10a8 	ldr.w	r1, [r4, #168]	; 0xa8
d0004ece:	1a9b      	subs	r3, r3, r2
d0004ed0:	4419      	add	r1, r3
d0004ed2:	f8c4 10a8 	str.w	r1, [r4, #168]	; 0xa8
d0004ed6:	2800      	cmp	r0, #0
d0004ed8:	f43f ac69 	beq.w	d00047ae <load_jpeg_image.constprop.0+0xdfe>
d0004edc:	4428      	add	r0, r5
d0004ede:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0004ee2:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0004ee6:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0004eea:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0004eee:	2bff      	cmp	r3, #255	; 0xff
d0004ef0:	f47e ae05 	bne.w	d0003afe <load_jpeg_image.constprop.0+0x14e>
d0004ef4:	f8da 4000 	ldr.w	r4, [sl]
d0004ef8:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004efc:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004f00:	4293      	cmp	r3, r2
d0004f02:	d32b      	bcc.n	d0004f5c <load_jpeg_image.constprop.0+0x15ac>
d0004f04:	6a21      	ldr	r1, [r4, #32]
d0004f06:	2900      	cmp	r1, #0
d0004f08:	f43e ade4 	beq.w	d0003ad4 <load_jpeg_image.constprop.0+0x124>
d0004f0c:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0004f10:	6923      	ldr	r3, [r4, #16]
d0004f12:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0004f14:	f104 0629 	add.w	r6, r4, #41	; 0x29
d0004f18:	4629      	mov	r1, r5
d0004f1a:	69e0      	ldr	r0, [r4, #28]
d0004f1c:	4798      	blx	r3
d0004f1e:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004f22:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d0004f26:	4405      	add	r5, r0
d0004f28:	1a9a      	subs	r2, r3, r2
d0004f2a:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0004f2e:	4413      	add	r3, r2
d0004f30:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0004f34:	2800      	cmp	r0, #0
d0004f36:	f43e afd1 	beq.w	d0003edc <load_jpeg_image.constprop.0+0x52c>
d0004f3a:	f894 1028 	ldrb.w	r1, [r4, #40]	; 0x28
d0004f3e:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d0004f42:	f8c4 60ac 	str.w	r6, [r4, #172]	; 0xac
d0004f46:	29ff      	cmp	r1, #255	; 0xff
d0004f48:	f47e adbc 	bne.w	d0003ac4 <load_jpeg_image.constprop.0+0x114>
d0004f4c:	f8da 4000 	ldr.w	r4, [sl]
d0004f50:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004f54:	f8d4 20b0 	ldr.w	r2, [r4, #176]	; 0xb0
d0004f58:	4293      	cmp	r3, r2
d0004f5a:	d2d3      	bcs.n	d0004f04 <load_jpeg_image.constprop.0+0x1554>
d0004f5c:	1c5a      	adds	r2, r3, #1
d0004f5e:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0004f62:	7819      	ldrb	r1, [r3, #0]
d0004f64:	e7ef      	b.n	d0004f46 <load_jpeg_image.constprop.0+0x1596>
d0004f66:	f104 0528 	add.w	r5, r4, #40	; 0x28
d0004f6a:	6923      	ldr	r3, [r4, #16]
d0004f6c:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0004f6e:	f104 0629 	add.w	r6, r4, #41	; 0x29
d0004f72:	4629      	mov	r1, r5
d0004f74:	69e0      	ldr	r0, [r4, #28]
d0004f76:	4798      	blx	r3
d0004f78:	f8d4 30ac 	ldr.w	r3, [r4, #172]	; 0xac
d0004f7c:	f8d4 20b4 	ldr.w	r2, [r4, #180]	; 0xb4
d0004f80:	4405      	add	r5, r0
d0004f82:	1a9a      	subs	r2, r3, r2
d0004f84:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0004f88:	4413      	add	r3, r2
d0004f8a:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0004f8e:	2800      	cmp	r0, #0
d0004f90:	f040 80b0 	bne.w	d00050f4 <load_jpeg_image.constprop.0+0x1744>
d0004f94:	6220      	str	r0, [r4, #32]
d0004f96:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0004f9a:	f8c4 60b0 	str.w	r6, [r4, #176]	; 0xb0
d0004f9e:	f8c4 60ac 	str.w	r6, [r4, #172]	; 0xac
d0004fa2:	e767      	b.n	d0004e74 <load_jpeg_image.constprop.0+0x14c4>
d0004fa4:	f244 71f4 	movw	r1, #18420	; 0x47f4
d0004fa8:	f244 62bc 	movw	r2, #18108	; 0x46bc
d0004fac:	f244 63b8 	movw	r3, #18104	; 0x46b8
d0004fb0:	f85a 1001 	ldr.w	r1, [sl, r1]
d0004fb4:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
d0004fb8:	9106      	str	r1, [sp, #24]
d0004fba:	eb0a 05c5 	add.w	r5, sl, r5, lsl #3
d0004fbe:	58aa      	ldr	r2, [r5, r2]
d0004fc0:	58eb      	ldr	r3, [r5, r3]
d0004fc2:	3207      	adds	r2, #7
d0004fc4:	3307      	adds	r3, #7
d0004fc6:	10d2      	asrs	r2, r2, #3
d0004fc8:	10db      	asrs	r3, r3, #3
d0004fca:	2a00      	cmp	r2, #0
d0004fcc:	920e      	str	r2, [sp, #56]	; 0x38
d0004fce:	930d      	str	r3, [sp, #52]	; 0x34
d0004fd0:	f77f ae8f 	ble.w	d0004cf2 <load_jpeg_image.constprop.0+0x1342>
d0004fd4:	00db      	lsls	r3, r3, #3
d0004fd6:	9e0c      	ldr	r6, [sp, #48]	; 0x30
d0004fd8:	f8cd b02c 	str.w	fp, [sp, #44]	; 0x2c
d0004fdc:	9307      	str	r3, [sp, #28]
d0004fde:	f8cd 9028 	str.w	r9, [sp, #40]	; 0x28
d0004fe2:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d0004fe4:	2b00      	cmp	r3, #0
d0004fe6:	dd79      	ble.n	d00050dc <load_jpeg_image.constprop.0+0x172c>
d0004fe8:	f641 2b44 	movw	fp, #6724	; 0x1a44
d0004fec:	f244 69b0 	movw	r9, #18096	; 0x46b0
d0004ff0:	f244 68ac 	movw	r8, #18092	; 0x46ac
d0004ff4:	f10a 0304 	add.w	r3, sl, #4
d0004ff8:	af24      	add	r7, sp, #144	; 0x90
d0004ffa:	44d3      	add	fp, sl
d0004ffc:	44a9      	add	r9, r5
d0004ffe:	44a8      	add	r8, r5
d0005000:	2400      	movs	r4, #0
d0005002:	ee08 7a10 	vmov	s16, r7
d0005006:	9304      	str	r3, [sp, #16]
d0005008:	e002      	b.n	d0005010 <load_jpeg_image.constprop.0+0x1660>
d000500a:	9b07      	ldr	r3, [sp, #28]
d000500c:	429c      	cmp	r4, r3
d000500e:	d065      	beq.n	d00050dc <load_jpeg_image.constprop.0+0x172c>
d0005010:	f244 62a8 	movw	r2, #18088	; 0x46a8
d0005014:	f8d9 3000 	ldr.w	r3, [r9]
d0005018:	9f06      	ldr	r7, [sp, #24]
d000501a:	f243 4184 	movw	r1, #13444	; 0x3484
d000501e:	58aa      	ldr	r2, [r5, r2]
d0005020:	eb0a 2c83 	add.w	ip, sl, r3, lsl #10
d0005024:	f243 6084 	movw	r0, #13956	; 0x3684
d0005028:	eb0a 12c2 	add.w	r2, sl, r2, lsl #7
d000502c:	4460      	add	r0, ip
d000502e:	f8d8 c000 	ldr.w	ip, [r8]
d0005032:	4411      	add	r1, r2
d0005034:	9701      	str	r7, [sp, #4]
d0005036:	f44f 62d2 	mov.w	r2, #1680	; 0x690
d000503a:	9f04      	ldr	r7, [sp, #16]
d000503c:	9102      	str	r1, [sp, #8]
d000503e:	ee18 1a10 	vmov	r1, s16
d0005042:	fb02 b303 	mla	r3, r2, r3, fp
d0005046:	9000      	str	r0, [sp, #0]
d0005048:	4650      	mov	r0, sl
d000504a:	fb02 720c 	mla	r2, r2, ip, r7
d000504e:	f7fc ff61 	bl	d0001f14 <stbi__jpeg_decode_block>
d0005052:	f244 61c0 	movw	r1, #18112	; 0x46c0
d0005056:	f244 6cc8 	movw	ip, #18120	; 0x46c8
d000505a:	f644 030c 	movw	r3, #18444	; 0x480c
d000505e:	ee18 2a10 	vmov	r2, s16
d0005062:	2800      	cmp	r0, #0
d0005064:	f43e acd3 	beq.w	d0003a0e <load_jpeg_image.constprop.0+0x5e>
d0005068:	5869      	ldr	r1, [r5, r1]
d000506a:	9f08      	ldr	r7, [sp, #32]
d000506c:	f855 000c 	ldr.w	r0, [r5, ip]
d0005070:	fb07 fc01 	mul.w	ip, r7, r1
d0005074:	f85a 3003 	ldr.w	r3, [sl, r3]
d0005078:	eb04 0ccc 	add.w	ip, r4, ip, lsl #3
d000507c:	3408      	adds	r4, #8
d000507e:	4460      	add	r0, ip
d0005080:	4798      	blx	r3
d0005082:	6833      	ldr	r3, [r6, #0]
d0005084:	3b01      	subs	r3, #1
d0005086:	2b00      	cmp	r3, #0
d0005088:	6033      	str	r3, [r6, #0]
d000508a:	dcbe      	bgt.n	d000500a <load_jpeg_image.constprop.0+0x165a>
d000508c:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d000508e:	681b      	ldr	r3, [r3, #0]
d0005090:	2b17      	cmp	r3, #23
d0005092:	dd2b      	ble.n	d00050ec <load_jpeg_image.constprop.0+0x173c>
d0005094:	9805      	ldr	r0, [sp, #20]
d0005096:	2300      	movs	r3, #0
d0005098:	21ff      	movs	r1, #255	; 0xff
d000509a:	7802      	ldrb	r2, [r0, #0]
d000509c:	3230      	adds	r2, #48	; 0x30
d000509e:	b2d2      	uxtb	r2, r2
d00050a0:	2a07      	cmp	r2, #7
d00050a2:	f63f ae17 	bhi.w	d0004cd4 <load_jpeg_image.constprop.0+0x1324>
d00050a6:	9a0a      	ldr	r2, [sp, #40]	; 0x28
d00050a8:	6013      	str	r3, [r2, #0]
d00050aa:	9a0b      	ldr	r2, [sp, #44]	; 0x2c
d00050ac:	6013      	str	r3, [r2, #0]
d00050ae:	9a16      	ldr	r2, [sp, #88]	; 0x58
d00050b0:	6013      	str	r3, [r2, #0]
d00050b2:	9a15      	ldr	r2, [sp, #84]	; 0x54
d00050b4:	6013      	str	r3, [r2, #0]
d00050b6:	9a14      	ldr	r2, [sp, #80]	; 0x50
d00050b8:	6013      	str	r3, [r2, #0]
d00050ba:	9a13      	ldr	r2, [sp, #76]	; 0x4c
d00050bc:	6013      	str	r3, [r2, #0]
d00050be:	9a12      	ldr	r2, [sp, #72]	; 0x48
d00050c0:	6013      	str	r3, [r2, #0]
d00050c2:	9a17      	ldr	r2, [sp, #92]	; 0x5c
d00050c4:	7001      	strb	r1, [r0, #0]
d00050c6:	6812      	ldr	r2, [r2, #0]
d00050c8:	429a      	cmp	r2, r3
d00050ca:	bf08      	it	eq
d00050cc:	f06f 4200 	mvneq.w	r2, #2147483648	; 0x80000000
d00050d0:	6032      	str	r2, [r6, #0]
d00050d2:	9a09      	ldr	r2, [sp, #36]	; 0x24
d00050d4:	6013      	str	r3, [r2, #0]
d00050d6:	9b07      	ldr	r3, [sp, #28]
d00050d8:	429c      	cmp	r4, r3
d00050da:	d199      	bne.n	d0005010 <load_jpeg_image.constprop.0+0x1660>
d00050dc:	9b08      	ldr	r3, [sp, #32]
d00050de:	9a0e      	ldr	r2, [sp, #56]	; 0x38
d00050e0:	3301      	adds	r3, #1
d00050e2:	429a      	cmp	r2, r3
d00050e4:	9308      	str	r3, [sp, #32]
d00050e6:	f47f af7c 	bne.w	d0004fe2 <load_jpeg_image.constprop.0+0x1632>
d00050ea:	e5f3      	b.n	d0004cd4 <load_jpeg_image.constprop.0+0x1324>
d00050ec:	4650      	mov	r0, sl
d00050ee:	f7fc fda5 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00050f2:	e7cf      	b.n	d0005094 <load_jpeg_image.constprop.0+0x16e4>
d00050f4:	f894 1028 	ldrb.w	r1, [r4, #40]	; 0x28
d00050f8:	f8c4 50b0 	str.w	r5, [r4, #176]	; 0xb0
d00050fc:	f8c4 60ac 	str.w	r6, [r4, #172]	; 0xac
d0005100:	e6bf      	b.n	d0004e82 <load_jpeg_image.constprop.0+0x14d2>
d0005102:	1c5a      	adds	r2, r3, #1
d0005104:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0005108:	781b      	ldrb	r3, [r3, #0]
d000510a:	e6a5      	b.n	d0004e58 <load_jpeg_image.constprop.0+0x14a8>
d000510c:	9a05      	ldr	r2, [sp, #20]
d000510e:	2bff      	cmp	r3, #255	; 0xff
d0005110:	7013      	strb	r3, [r2, #0]
d0005112:	f43f ae77 	beq.w	d0004e04 <load_jpeg_image.constprop.0+0x1454>
d0005116:	e5e1      	b.n	d0004cdc <load_jpeg_image.constprop.0+0x132c>
d0005118:	1c5a      	adds	r2, r3, #1
d000511a:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d000511e:	781b      	ldrb	r3, [r3, #0]
d0005120:	e625      	b.n	d0004d6e <load_jpeg_image.constprop.0+0x13be>
d0005122:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0005126:	4428      	add	r0, r5
d0005128:	f104 0129 	add.w	r1, r4, #41	; 0x29
d000512c:	1e5a      	subs	r2, r3, #1
d000512e:	f8c4 00b0 	str.w	r0, [r4, #176]	; 0xb0
d0005132:	f8c4 10ac 	str.w	r1, [r4, #172]	; 0xac
d0005136:	b2d2      	uxtb	r2, r2
d0005138:	e65b      	b.n	d0004df2 <load_jpeg_image.constprop.0+0x1442>
d000513a:	1c5a      	adds	r2, r3, #1
d000513c:	f8c4 20ac 	str.w	r2, [r4, #172]	; 0xac
d0005140:	781b      	ldrb	r3, [r3, #0]
d0005142:	e6d4      	b.n	d0004eee <load_jpeg_image.constprop.0+0x153e>
d0005144:	4bb3      	ldr	r3, [pc, #716]	; (d0005414 <load_jpeg_image.constprop.0+0x1a64>)
d0005146:	4ab4      	ldr	r2, [pc, #720]	; (d0005418 <load_jpeg_image.constprop.0+0x1a68>)
d0005148:	f8d5 c008 	ldr.w	ip, [r5, #8]
d000514c:	601a      	str	r2, [r3, #0]
d000514e:	f7fe bc62 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d0005152:	4bb0      	ldr	r3, [pc, #704]	; (d0005414 <load_jpeg_image.constprop.0+0x1a64>)
d0005154:	4ab1      	ldr	r2, [pc, #708]	; (d000541c <load_jpeg_image.constprop.0+0x1a6c>)
d0005156:	f8d5 c008 	ldr.w	ip, [r5, #8]
d000515a:	601a      	str	r2, [r3, #0]
d000515c:	f7fe bc5b 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d0005160:	1c51      	adds	r1, r2, #1
d0005162:	f8c6 10ac 	str.w	r1, [r6, #172]	; 0xac
d0005166:	7810      	ldrb	r0, [r2, #0]
d0005168:	e472      	b.n	d0004a50 <load_jpeg_image.constprop.0+0x10a0>
d000516a:	4405      	add	r5, r0
d000516c:	f894 3028 	ldrb.w	r3, [r4, #40]	; 0x28
d0005170:	f104 0129 	add.w	r1, r4, #41	; 0x29
d0005174:	e5f5      	b.n	d0004d62 <load_jpeg_image.constprop.0+0x13b2>
d0005176:	9b18      	ldr	r3, [sp, #96]	; 0x60
d0005178:	681b      	ldr	r3, [r3, #0]
d000517a:	2b17      	cmp	r3, #23
d000517c:	f340 8426 	ble.w	d00059cc <load_jpeg_image.constprop.0+0x201c>
d0005180:	9905      	ldr	r1, [sp, #20]
d0005182:	780b      	ldrb	r3, [r1, #0]
d0005184:	3330      	adds	r3, #48	; 0x30
d0005186:	b2db      	uxtb	r3, r3
d0005188:	2b07      	cmp	r3, #7
d000518a:	f63f ada2 	bhi.w	d0004cd2 <load_jpeg_image.constprop.0+0x1322>
d000518e:	2300      	movs	r3, #0
d0005190:	9818      	ldr	r0, [sp, #96]	; 0x60
d0005192:	22ff      	movs	r2, #255	; 0xff
d0005194:	6003      	str	r3, [r0, #0]
d0005196:	9819      	ldr	r0, [sp, #100]	; 0x64
d0005198:	6003      	str	r3, [r0, #0]
d000519a:	9816      	ldr	r0, [sp, #88]	; 0x58
d000519c:	6003      	str	r3, [r0, #0]
d000519e:	9815      	ldr	r0, [sp, #84]	; 0x54
d00051a0:	6003      	str	r3, [r0, #0]
d00051a2:	9814      	ldr	r0, [sp, #80]	; 0x50
d00051a4:	6003      	str	r3, [r0, #0]
d00051a6:	9813      	ldr	r0, [sp, #76]	; 0x4c
d00051a8:	6003      	str	r3, [r0, #0]
d00051aa:	9812      	ldr	r0, [sp, #72]	; 0x48
d00051ac:	6003      	str	r3, [r0, #0]
d00051ae:	700a      	strb	r2, [r1, #0]
d00051b0:	9a17      	ldr	r2, [sp, #92]	; 0x5c
d00051b2:	990c      	ldr	r1, [sp, #48]	; 0x30
d00051b4:	6812      	ldr	r2, [r2, #0]
d00051b6:	429a      	cmp	r2, r3
d00051b8:	bf08      	it	eq
d00051ba:	f06f 4200 	mvneq.w	r2, #2147483648	; 0x80000000
d00051be:	600a      	str	r2, [r1, #0]
d00051c0:	9a09      	ldr	r2, [sp, #36]	; 0x24
d00051c2:	6013      	str	r3, [r2, #0]
d00051c4:	e575      	b.n	d0004cb2 <load_jpeg_image.constprop.0+0x1302>
d00051c6:	f106 0428 	add.w	r4, r6, #40	; 0x28
d00051ca:	6933      	ldr	r3, [r6, #16]
d00051cc:	6a72      	ldr	r2, [r6, #36]	; 0x24
d00051ce:	4621      	mov	r1, r4
d00051d0:	69f0      	ldr	r0, [r6, #28]
d00051d2:	4798      	blx	r3
d00051d4:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d00051d8:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d00051dc:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d00051e0:	1a52      	subs	r2, r2, r1
d00051e2:	4413      	add	r3, r2
d00051e4:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d00051e8:	2800      	cmp	r0, #0
d00051ea:	f040 83f4 	bne.w	d00059d6 <load_jpeg_image.constprop.0+0x2026>
d00051ee:	f106 0429 	add.w	r4, r6, #41	; 0x29
d00051f2:	4605      	mov	r5, r0
d00051f4:	4603      	mov	r3, r0
d00051f6:	6230      	str	r0, [r6, #32]
d00051f8:	4622      	mov	r2, r4
d00051fa:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d00051fe:	f8c6 40b0 	str.w	r4, [r6, #176]	; 0xb0
d0005202:	f8c6 20ac 	str.w	r2, [r6, #172]	; 0xac
d0005206:	f7ff bba5 	b.w	d0004954 <load_jpeg_image.constprop.0+0xfa4>
d000520a:	f106 0428 	add.w	r4, r6, #40	; 0x28
d000520e:	6933      	ldr	r3, [r6, #16]
d0005210:	6a72      	ldr	r2, [r6, #36]	; 0x24
d0005212:	4621      	mov	r1, r4
d0005214:	69f0      	ldr	r0, [r6, #28]
d0005216:	4798      	blx	r3
d0005218:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d000521c:	f8d6 10b4 	ldr.w	r1, [r6, #180]	; 0xb4
d0005220:	f8d6 30a8 	ldr.w	r3, [r6, #168]	; 0xa8
d0005224:	1a52      	subs	r2, r2, r1
d0005226:	4413      	add	r3, r2
d0005228:	f8c6 30a8 	str.w	r3, [r6, #168]	; 0xa8
d000522c:	2800      	cmp	r0, #0
d000522e:	f040 83e0 	bne.w	d00059f2 <load_jpeg_image.constprop.0+0x2042>
d0005232:	f106 0429 	add.w	r4, r6, #41	; 0x29
d0005236:	6230      	str	r0, [r6, #32]
d0005238:	f886 0028 	strb.w	r0, [r6, #40]	; 0x28
d000523c:	4623      	mov	r3, r4
d000523e:	f8c6 30ac 	str.w	r3, [r6, #172]	; 0xac
d0005242:	f8c6 40b0 	str.w	r4, [r6, #176]	; 0xb0
d0005246:	f8da 6000 	ldr.w	r6, [sl]
d000524a:	f8d6 20ac 	ldr.w	r2, [r6, #172]	; 0xac
d000524e:	f8d6 30b0 	ldr.w	r3, [r6, #176]	; 0xb0
d0005252:	e40a      	b.n	d0004a6a <load_jpeg_image.constprop.0+0x10ba>
d0005254:	9b04      	ldr	r3, [sp, #16]
d0005256:	9008      	str	r0, [sp, #32]
d0005258:	2b00      	cmp	r3, #0
d000525a:	dd1b      	ble.n	d0005294 <load_jpeg_image.constprop.0+0x18e4>
d000525c:	f244 64c8 	movw	r4, #18120	; 0x46c8
d0005260:	eb03 06c3 	add.w	r6, r3, r3, lsl #3
d0005264:	4605      	mov	r5, r0
d0005266:	4454      	add	r4, sl
d0005268:	eb04 06c6 	add.w	r6, r4, r6, lsl #3
d000526c:	6860      	ldr	r0, [r4, #4]
d000526e:	b118      	cbz	r0, d0005278 <load_jpeg_image.constprop.0+0x18c8>
d0005270:	f006 fcb4 	bl	d000bbdc <free>
d0005274:	6065      	str	r5, [r4, #4]
d0005276:	6025      	str	r5, [r4, #0]
d0005278:	68a0      	ldr	r0, [r4, #8]
d000527a:	b118      	cbz	r0, d0005284 <load_jpeg_image.constprop.0+0x18d4>
d000527c:	f006 fcae 	bl	d000bbdc <free>
d0005280:	60a5      	str	r5, [r4, #8]
d0005282:	6125      	str	r5, [r4, #16]
d0005284:	68e0      	ldr	r0, [r4, #12]
d0005286:	b110      	cbz	r0, d000528e <load_jpeg_image.constprop.0+0x18de>
d0005288:	f006 fca8 	bl	d000bbdc <free>
d000528c:	60e5      	str	r5, [r4, #12]
d000528e:	3448      	adds	r4, #72	; 0x48
d0005290:	42b4      	cmp	r4, r6
d0005292:	d1eb      	bne.n	d000526c <load_jpeg_image.constprop.0+0x18bc>
d0005294:	4b5f      	ldr	r3, [pc, #380]	; (d0005414 <load_jpeg_image.constprop.0+0x1a64>)
d0005296:	4a62      	ldr	r2, [pc, #392]	; (d0005420 <load_jpeg_image.constprop.0+0x1a70>)
d0005298:	601a      	str	r2, [r3, #0]
d000529a:	f7fe be80 	b.w	d0003f9e <load_jpeg_image.constprop.0+0x5ee>
d000529e:	f644 0208 	movw	r2, #18440	; 0x4808
d00052a2:	f06f 4100 	mvn.w	r1, #2147483648	; 0x80000000
d00052a6:	e43b      	b.n	d0004b20 <load_jpeg_image.constprop.0+0x1170>
d00052a8:	f244 75c0 	movw	r5, #18368	; 0x47c0
d00052ac:	f244 74bc 	movw	r4, #18364	; 0x47bc
d00052b0:	f244 70c8 	movw	r0, #18376	; 0x47c8
d00052b4:	f244 718c 	movw	r1, #18316	; 0x478c
d00052b8:	f244 7244 	movw	r2, #18244	; 0x4744
d00052bc:	f84a 3005 	str.w	r3, [sl, r5]
d00052c0:	f244 66fc 	movw	r6, #18172	; 0x46fc
d00052c4:	f84a 3004 	str.w	r3, [sl, r4]
d00052c8:	f84a 3000 	str.w	r3, [sl, r0]
d00052cc:	f244 67b4 	movw	r7, #18100	; 0x46b4
d00052d0:	f84a 3001 	str.w	r3, [sl, r1]
d00052d4:	f04f 0eff 	mov.w	lr, #255	; 0xff
d00052d8:	f84a 3002 	str.w	r3, [sl, r2]
d00052dc:	4452      	add	r2, sl
d00052de:	f644 0c04 	movw	ip, #18436	; 0x4804
d00052e2:	4451      	add	r1, sl
d00052e4:	9214      	str	r2, [sp, #80]	; 0x50
d00052e6:	eb0a 0206 	add.w	r2, sl, r6
d00052ea:	f84a 3006 	str.w	r3, [sl, r6]
d00052ee:	4450      	add	r0, sl
d00052f0:	9213      	str	r2, [sp, #76]	; 0x4c
d00052f2:	eb0a 0905 	add.w	r9, sl, r5
d00052f6:	9a05      	ldr	r2, [sp, #20]
d00052f8:	eb0a 0b04 	add.w	fp, sl, r4
d00052fc:	f84a 3007 	str.w	r3, [sl, r7]
d0005300:	f882 e000 	strb.w	lr, [r2]
d0005304:	eb0a 0207 	add.w	r2, sl, r7
d0005308:	9115      	str	r1, [sp, #84]	; 0x54
d000530a:	eb0a 010c 	add.w	r1, sl, ip
d000530e:	9212      	str	r2, [sp, #72]	; 0x48
d0005310:	f85a 200c 	ldr.w	r2, [sl, ip]
d0005314:	9016      	str	r0, [sp, #88]	; 0x58
d0005316:	9117      	str	r1, [sp, #92]	; 0x5c
d0005318:	2a00      	cmp	r2, #0
d000531a:	f040 8370 	bne.w	d00059fe <load_jpeg_image.constprop.0+0x204e>
d000531e:	f644 0108 	movw	r1, #18440	; 0x4808
d0005322:	f244 73e0 	movw	r3, #18400	; 0x47e0
d0005326:	f06f 4000 	mvn.w	r0, #2147483648	; 0x80000000
d000532a:	f84a 0001 	str.w	r0, [sl, r1]
d000532e:	4451      	add	r1, sl
d0005330:	f84a 2003 	str.w	r2, [sl, r3]
d0005334:	4453      	add	r3, sl
d0005336:	910c      	str	r1, [sp, #48]	; 0x30
d0005338:	9309      	str	r3, [sp, #36]	; 0x24
d000533a:	f244 73f0 	movw	r3, #18416	; 0x47f0
d000533e:	f85a 3003 	ldr.w	r3, [sl, r3]
d0005342:	2b01      	cmp	r3, #1
d0005344:	f000 808d 	beq.w	d0005462 <load_jpeg_image.constprop.0+0x1ab2>
d0005348:	f244 6390 	movw	r3, #18064	; 0x4690
d000534c:	f85a 2003 	ldr.w	r2, [sl, r3]
d0005350:	4453      	add	r3, sl
d0005352:	2a00      	cmp	r2, #0
d0005354:	9310      	str	r3, [sp, #64]	; 0x40
d0005356:	f77f accc 	ble.w	d0004cf2 <load_jpeg_image.constprop.0+0x1342>
d000535a:	f244 638c 	movw	r3, #18060	; 0x468c
d000535e:	2100      	movs	r1, #0
d0005360:	f8cd b02c 	str.w	fp, [sp, #44]	; 0x2c
d0005364:	9106      	str	r1, [sp, #24]
d0005366:	eb0a 0103 	add.w	r1, sl, r3
d000536a:	f85a 3003 	ldr.w	r3, [sl, r3]
d000536e:	910f      	str	r1, [sp, #60]	; 0x3c
d0005370:	f8cd 9028 	str.w	r9, [sp, #40]	; 0x28
d0005374:	2b00      	cmp	r3, #0
d0005376:	dd6e      	ble.n	d0005456 <load_jpeg_image.constprop.0+0x1aa6>
d0005378:	f04f 0b00 	mov.w	fp, #0
d000537c:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d000537e:	681a      	ldr	r2, [r3, #0]
d0005380:	2a00      	cmp	r2, #0
d0005382:	dd59      	ble.n	d0005438 <load_jpeg_image.constprop.0+0x1a88>
d0005384:	f244 73f4 	movw	r3, #18420	; 0x47f4
d0005388:	f244 69a4 	movw	r9, #18084	; 0x46a4
d000538c:	4453      	add	r3, sl
d000538e:	9307      	str	r3, [sp, #28]
d0005390:	2300      	movs	r3, #0
d0005392:	9308      	str	r3, [sp, #32]
d0005394:	9907      	ldr	r1, [sp, #28]
d0005396:	f851 3b04 	ldr.w	r3, [r1], #4
d000539a:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
d000539e:	9107      	str	r1, [sp, #28]
d00053a0:	eb0a 05c5 	add.w	r5, sl, r5, lsl #3
d00053a4:	f855 1009 	ldr.w	r1, [r5, r9]
d00053a8:	2900      	cmp	r1, #0
d00053aa:	dd40      	ble.n	d000542e <load_jpeg_image.constprop.0+0x1a7e>
d00053ac:	f244 62a0 	movw	r2, #18080	; 0x46a0
d00053b0:	2700      	movs	r7, #0
d00053b2:	58aa      	ldr	r2, [r5, r2]
d00053b4:	2a00      	cmp	r2, #0
d00053b6:	dd35      	ble.n	d0005424 <load_jpeg_image.constprop.0+0x1a74>
d00053b8:	f244 66d8 	movw	r6, #18136	; 0x46d8
d00053bc:	f244 68ac 	movw	r8, #18092	; 0x46ac
d00053c0:	2400      	movs	r4, #0
d00053c2:	44a8      	add	r8, r5
d00053c4:	442e      	add	r6, r5
d00053c6:	e006      	b.n	d00053d6 <load_jpeg_image.constprop.0+0x1a26>
d00053c8:	f244 62a0 	movw	r2, #18080	; 0x46a0
d00053cc:	f855 1009 	ldr.w	r1, [r5, r9]
d00053d0:	58aa      	ldr	r2, [r5, r2]
d00053d2:	42a2      	cmp	r2, r4
d00053d4:	dd26      	ble.n	d0005424 <load_jpeg_image.constprop.0+0x1a74>
d00053d6:	9806      	ldr	r0, [sp, #24]
d00053d8:	f244 6cdc 	movw	ip, #18140	; 0x46dc
d00053dc:	fb02 420b 	mla	r2, r2, fp, r4
d00053e0:	3401      	adds	r4, #1
d00053e2:	fb01 7100 	mla	r1, r1, r0, r7
d00053e6:	f855 000c 	ldr.w	r0, [r5, ip]
d00053ea:	f44f 6cd2 	mov.w	ip, #1680	; 0x690
d00053ee:	9304      	str	r3, [sp, #16]
d00053f0:	fb00 2101 	mla	r1, r0, r1, r2
d00053f4:	f8d8 2000 	ldr.w	r2, [r8]
d00053f8:	6830      	ldr	r0, [r6, #0]
d00053fa:	fb0c a202 	mla	r2, ip, r2, sl
d00053fe:	eb00 11c1 	add.w	r1, r0, r1, lsl #7
d0005402:	4650      	mov	r0, sl
d0005404:	3204      	adds	r2, #4
d0005406:	f7fc fee3 	bl	d00021d0 <stbi__jpeg_decode_block_prog_dc>
d000540a:	9b04      	ldr	r3, [sp, #16]
d000540c:	2800      	cmp	r0, #0
d000540e:	d1db      	bne.n	d00053c8 <load_jpeg_image.constprop.0+0x1a18>
d0005410:	f7fe bafd 	b.w	d0003a0e <load_jpeg_image.constprop.0+0x5e>
d0005414:	d000dec8 	.word	0xd000dec8
d0005418:	d000d478 	.word	0xd000d478
d000541c:	d000d484 	.word	0xd000d484
d0005420:	d000d418 	.word	0xd000d418
d0005424:	3701      	adds	r7, #1
d0005426:	428f      	cmp	r7, r1
d0005428:	dbc4      	blt.n	d00053b4 <load_jpeg_image.constprop.0+0x1a04>
d000542a:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d000542c:	681a      	ldr	r2, [r3, #0]
d000542e:	9b08      	ldr	r3, [sp, #32]
d0005430:	3301      	adds	r3, #1
d0005432:	4293      	cmp	r3, r2
d0005434:	9308      	str	r3, [sp, #32]
d0005436:	dbad      	blt.n	d0005394 <load_jpeg_image.constprop.0+0x19e4>
d0005438:	9a0c      	ldr	r2, [sp, #48]	; 0x30
d000543a:	6813      	ldr	r3, [r2, #0]
d000543c:	3b01      	subs	r3, #1
d000543e:	2b00      	cmp	r3, #0
d0005440:	6013      	str	r3, [r2, #0]
d0005442:	f340 8288 	ble.w	d0005956 <load_jpeg_image.constprop.0+0x1fa6>
d0005446:	9b0f      	ldr	r3, [sp, #60]	; 0x3c
d0005448:	f10b 0b01 	add.w	fp, fp, #1
d000544c:	681b      	ldr	r3, [r3, #0]
d000544e:	459b      	cmp	fp, r3
d0005450:	db94      	blt.n	d000537c <load_jpeg_image.constprop.0+0x19cc>
d0005452:	9a10      	ldr	r2, [sp, #64]	; 0x40
d0005454:	6812      	ldr	r2, [r2, #0]
d0005456:	9906      	ldr	r1, [sp, #24]
d0005458:	3101      	adds	r1, #1
d000545a:	4291      	cmp	r1, r2
d000545c:	9106      	str	r1, [sp, #24]
d000545e:	db89      	blt.n	d0005374 <load_jpeg_image.constprop.0+0x19c4>
d0005460:	e438      	b.n	d0004cd4 <load_jpeg_image.constprop.0+0x1324>
d0005462:	f244 73f4 	movw	r3, #18420	; 0x47f4
d0005466:	f244 62bc 	movw	r2, #18108	; 0x46bc
d000546a:	f244 61b8 	movw	r1, #18104	; 0x46b8
d000546e:	f85a 0003 	ldr.w	r0, [sl, r3]
d0005472:	eb00 03c0 	add.w	r3, r0, r0, lsl #3
d0005476:	ee08 0a90 	vmov	s17, r0
d000547a:	00c0      	lsls	r0, r0, #3
d000547c:	eb0a 03c3 	add.w	r3, sl, r3, lsl #3
d0005480:	901e      	str	r0, [sp, #120]	; 0x78
d0005482:	589a      	ldr	r2, [r3, r2]
d0005484:	585b      	ldr	r3, [r3, r1]
d0005486:	3207      	adds	r2, #7
d0005488:	3307      	adds	r3, #7
d000548a:	10d2      	asrs	r2, r2, #3
d000548c:	10db      	asrs	r3, r3, #3
d000548e:	2a00      	cmp	r2, #0
d0005490:	921f      	str	r2, [sp, #124]	; 0x7c
d0005492:	930b      	str	r3, [sp, #44]	; 0x2c
d0005494:	f77f ac2d 	ble.w	d0004cf2 <load_jpeg_image.constprop.0+0x1342>
d0005498:	2300      	movs	r3, #0
d000549a:	46c8      	mov	r8, r9
d000549c:	46d9      	mov	r9, fp
d000549e:	930a      	str	r3, [sp, #40]	; 0x28
d00054a0:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d00054a2:	2b00      	cmp	r3, #0
d00054a4:	f340 8222 	ble.w	d00058ec <load_jpeg_image.constprop.0+0x1f3c>
d00054a8:	ee18 2a90 	vmov	r2, s17
d00054ac:	9b1e      	ldr	r3, [sp, #120]	; 0x78
d00054ae:	f244 61dc 	movw	r1, #18140	; 0x46dc
d00054b2:	2000      	movs	r0, #0
d00054b4:	4413      	add	r3, r2
d00054b6:	f244 62d8 	movw	r2, #18136	; 0x46d8
d00054ba:	9004      	str	r0, [sp, #16]
d00054bc:	eb0a 03c3 	add.w	r3, sl, r3, lsl #3
d00054c0:	189a      	adds	r2, r3, r2
d00054c2:	930f      	str	r3, [sp, #60]	; 0x3c
d00054c4:	440b      	add	r3, r1
d00054c6:	920d      	str	r2, [sp, #52]	; 0x34
d00054c8:	930e      	str	r3, [sp, #56]	; 0x38
d00054ca:	e01e      	b.n	d000550a <load_jpeg_image.constprop.0+0x1b5a>
d00054cc:	980f      	ldr	r0, [sp, #60]	; 0x3c
d00054ce:	f244 62ac 	movw	r2, #18092	; 0x46ac
d00054d2:	f44f 64d2 	mov.w	r4, #1680	; 0x690
d00054d6:	4629      	mov	r1, r5
d00054d8:	5882      	ldr	r2, [r0, r2]
d00054da:	ee18 3a90 	vmov	r3, s17
d00054de:	4650      	mov	r0, sl
d00054e0:	fb04 a202 	mla	r2, r4, r2, sl
d00054e4:	3204      	adds	r2, #4
d00054e6:	f7fc fe73 	bl	d00021d0 <stbi__jpeg_decode_block_prog_dc>
d00054ea:	2800      	cmp	r0, #0
d00054ec:	f43e aa8f 	beq.w	d0003a0e <load_jpeg_image.constprop.0+0x5e>
d00054f0:	9a0c      	ldr	r2, [sp, #48]	; 0x30
d00054f2:	6813      	ldr	r3, [r2, #0]
d00054f4:	3b01      	subs	r3, #1
d00054f6:	2b00      	cmp	r3, #0
d00054f8:	6013      	str	r3, [r2, #0]
d00054fa:	dd77      	ble.n	d00055ec <load_jpeg_image.constprop.0+0x1c3c>
d00054fc:	9b04      	ldr	r3, [sp, #16]
d00054fe:	9a0b      	ldr	r2, [sp, #44]	; 0x2c
d0005500:	3301      	adds	r3, #1
d0005502:	429a      	cmp	r2, r3
d0005504:	9304      	str	r3, [sp, #16]
d0005506:	f000 81f1 	beq.w	d00058ec <load_jpeg_image.constprop.0+0x1f3c>
d000550a:	9a0d      	ldr	r2, [sp, #52]	; 0x34
d000550c:	9b0e      	ldr	r3, [sp, #56]	; 0x38
d000550e:	6815      	ldr	r5, [r2, #0]
d0005510:	681b      	ldr	r3, [r3, #0]
d0005512:	9a0a      	ldr	r2, [sp, #40]	; 0x28
d0005514:	9904      	ldr	r1, [sp, #16]
d0005516:	fb03 1302 	mla	r3, r3, r2, r1
d000551a:	9a10      	ldr	r2, [sp, #64]	; 0x40
d000551c:	6814      	ldr	r4, [r2, #0]
d000551e:	eb05 15c3 	add.w	r5, r5, r3, lsl #7
d0005522:	2c00      	cmp	r4, #0
d0005524:	d0d2      	beq.n	d00054cc <load_jpeg_image.constprop.0+0x1b1c>
d0005526:	f244 62b0 	movw	r2, #18096	; 0x46b0
d000552a:	9e0f      	ldr	r6, [sp, #60]	; 0x3c
d000552c:	f44f 61d2 	mov.w	r1, #1680	; 0x690
d0005530:	f641 2044 	movw	r0, #6724	; 0x1a44
d0005534:	58b2      	ldr	r2, [r6, r2]
d0005536:	9b18      	ldr	r3, [sp, #96]	; 0x60
d0005538:	fb01 a102 	mla	r1, r1, r2, sl
d000553c:	681b      	ldr	r3, [r3, #0]
d000553e:	4401      	add	r1, r0
d0005540:	ee08 1a10 	vmov	s16, r1
d0005544:	2b00      	cmp	r3, #0
d0005546:	f040 80a8 	bne.w	d000569a <load_jpeg_image.constprop.0+0x1cea>
d000554a:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000554c:	681b      	ldr	r3, [r3, #0]
d000554e:	2b00      	cmp	r3, #0
d0005550:	f040 81c8 	bne.w	d00058e4 <load_jpeg_image.constprop.0+0x1f34>
d0005554:	9b1a      	ldr	r3, [sp, #104]	; 0x68
d0005556:	2101      	movs	r1, #1
d0005558:	f243 6784 	movw	r7, #13956	; 0x3684
d000555c:	f8dd b01c 	ldr.w	fp, [sp, #28]
d0005560:	681b      	ldr	r3, [r3, #0]
d0005562:	eb07 2782 	add.w	r7, r7, r2, lsl #10
d0005566:	fa01 f303 	lsl.w	r3, r1, r3
d000556a:	b29b      	uxth	r3, r3
d000556c:	9306      	str	r3, [sp, #24]
d000556e:	e023      	b.n	d00055b8 <load_jpeg_image.constprop.0+0x1c08>
d0005570:	f8d9 2000 	ldr.w	r2, [r9]
d0005574:	0dd3      	lsrs	r3, r2, #23
d0005576:	eb0a 0343 	add.w	r3, sl, r3, lsl #1
d000557a:	5fde      	ldrsh	r6, [r3, r7]
d000557c:	b326      	cbz	r6, d00055c8 <load_jpeg_image.constprop.0+0x1c18>
d000557e:	f006 030f 	and.w	r3, r6, #15
d0005582:	f8d8 1000 	ldr.w	r1, [r8]
d0005586:	f3c6 1003 	ubfx	r0, r6, #4, #4
d000558a:	428b      	cmp	r3, r1
d000558c:	4404      	add	r4, r0
d000558e:	f300 8121 	bgt.w	d00057d4 <load_jpeg_image.constprop.0+0x1e24>
d0005592:	409a      	lsls	r2, r3
d0005594:	1acb      	subs	r3, r1, r3
d0005596:	49c2      	ldr	r1, [pc, #776]	; (d00058a0 <load_jpeg_image.constprop.0+0x1ef0>)
d0005598:	1236      	asrs	r6, r6, #8
d000559a:	f8c9 2000 	str.w	r2, [r9]
d000559e:	5d08      	ldrb	r0, [r1, r4]
d00055a0:	3401      	adds	r4, #1
d00055a2:	9906      	ldr	r1, [sp, #24]
d00055a4:	f8c8 3000 	str.w	r3, [r8]
d00055a8:	fb16 f601 	smulbb	r6, r6, r1
d00055ac:	f825 6010 	strh.w	r6, [r5, r0, lsl #1]
d00055b0:	f8db 3000 	ldr.w	r3, [fp]
d00055b4:	42a3      	cmp	r3, r4
d00055b6:	db9b      	blt.n	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d00055b8:	f8d8 3000 	ldr.w	r3, [r8]
d00055bc:	2b0f      	cmp	r3, #15
d00055be:	dcd7      	bgt.n	d0005570 <load_jpeg_image.constprop.0+0x1bc0>
d00055c0:	4650      	mov	r0, sl
d00055c2:	f7fc fb3b 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00055c6:	e7d3      	b.n	d0005570 <load_jpeg_image.constprop.0+0x1bc0>
d00055c8:	ee18 1a10 	vmov	r1, s16
d00055cc:	4650      	mov	r0, sl
d00055ce:	f7fc fc0f 	bl	d0001df0 <stbi__jpeg_huff_decode>
d00055d2:	2800      	cmp	r0, #0
d00055d4:	f2c0 80fe 	blt.w	d00057d4 <load_jpeg_image.constprop.0+0x1e24>
d00055d8:	f010 010f 	ands.w	r1, r0, #15
d00055dc:	ea4f 1320 	mov.w	r3, r0, asr #4
d00055e0:	d12d      	bne.n	d000563e <load_jpeg_image.constprop.0+0x1c8e>
d00055e2:	2b0e      	cmp	r3, #14
d00055e4:	f340 8197 	ble.w	d0005916 <load_jpeg_image.constprop.0+0x1f66>
d00055e8:	3410      	adds	r4, #16
d00055ea:	e7e1      	b.n	d00055b0 <load_jpeg_image.constprop.0+0x1c00>
d00055ec:	f8d8 3000 	ldr.w	r3, [r8]
d00055f0:	2b17      	cmp	r3, #23
d00055f2:	f340 80ea 	ble.w	d00057ca <load_jpeg_image.constprop.0+0x1e1a>
d00055f6:	9905      	ldr	r1, [sp, #20]
d00055f8:	780b      	ldrb	r3, [r1, #0]
d00055fa:	f103 0230 	add.w	r2, r3, #48	; 0x30
d00055fe:	b2d2      	uxtb	r2, r2
d0005600:	2a07      	cmp	r2, #7
d0005602:	f63f ab69 	bhi.w	d0004cd8 <load_jpeg_image.constprop.0+0x1328>
d0005606:	2300      	movs	r3, #0
d0005608:	9816      	ldr	r0, [sp, #88]	; 0x58
d000560a:	22ff      	movs	r2, #255	; 0xff
d000560c:	f8c8 3000 	str.w	r3, [r8]
d0005610:	f8c9 3000 	str.w	r3, [r9]
d0005614:	6003      	str	r3, [r0, #0]
d0005616:	9815      	ldr	r0, [sp, #84]	; 0x54
d0005618:	6003      	str	r3, [r0, #0]
d000561a:	9814      	ldr	r0, [sp, #80]	; 0x50
d000561c:	6003      	str	r3, [r0, #0]
d000561e:	9813      	ldr	r0, [sp, #76]	; 0x4c
d0005620:	6003      	str	r3, [r0, #0]
d0005622:	9812      	ldr	r0, [sp, #72]	; 0x48
d0005624:	6003      	str	r3, [r0, #0]
d0005626:	700a      	strb	r2, [r1, #0]
d0005628:	9a17      	ldr	r2, [sp, #92]	; 0x5c
d000562a:	990c      	ldr	r1, [sp, #48]	; 0x30
d000562c:	6812      	ldr	r2, [r2, #0]
d000562e:	429a      	cmp	r2, r3
d0005630:	bf08      	it	eq
d0005632:	f06f 4200 	mvneq.w	r2, #2147483648	; 0x80000000
d0005636:	600a      	str	r2, [r1, #0]
d0005638:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000563a:	6013      	str	r3, [r2, #0]
d000563c:	e75e      	b.n	d00054fc <load_jpeg_image.constprop.0+0x1b4c>
d000563e:	f8d8 0000 	ldr.w	r0, [r8]
d0005642:	4423      	add	r3, r4
d0005644:	4a96      	ldr	r2, [pc, #600]	; (d00058a0 <load_jpeg_image.constprop.0+0x1ef0>)
d0005646:	4281      	cmp	r1, r0
d0005648:	f103 0401 	add.w	r4, r3, #1
d000564c:	5cd2      	ldrb	r2, [r2, r3]
d000564e:	f300 8131 	bgt.w	d00058b4 <load_jpeg_image.constprop.0+0x1f04>
d0005652:	f8d9 e000 	ldr.w	lr, [r9]
d0005656:	f1c1 0620 	rsb	r6, r1, #32
d000565a:	4b92      	ldr	r3, [pc, #584]	; (d00058a4 <load_jpeg_image.constprop.0+0x1ef4>)
d000565c:	1a40      	subs	r0, r0, r1
d000565e:	fa6e f606 	ror.w	r6, lr, r6
d0005662:	f853 c021 	ldr.w	ip, [r3, r1, lsl #2]
d0005666:	ea4f 73de 	mov.w	r3, lr, lsr #31
d000566a:	9308      	str	r3, [sp, #32]
d000566c:	ea06 0e0c 	and.w	lr, r6, ip
d0005670:	4b8d      	ldr	r3, [pc, #564]	; (d00058a8 <load_jpeg_image.constprop.0+0x1ef8>)
d0005672:	ea26 060c 	bic.w	r6, r6, ip
d0005676:	f853 1021 	ldr.w	r1, [r3, r1, lsl #2]
d000567a:	9b08      	ldr	r3, [sp, #32]
d000567c:	f8c9 6000 	str.w	r6, [r9]
d0005680:	3b01      	subs	r3, #1
d0005682:	f8c8 0000 	str.w	r0, [r8]
d0005686:	400b      	ands	r3, r1
d0005688:	eb03 060e 	add.w	r6, r3, lr
d000568c:	9b06      	ldr	r3, [sp, #24]
d000568e:	fb16 f603 	smulbb	r6, r6, r3
d0005692:	b236      	sxth	r6, r6
d0005694:	f825 6012 	strh.w	r6, [r5, r2, lsl #1]
d0005698:	e78a      	b.n	d00055b0 <load_jpeg_image.constprop.0+0x1c00>
d000569a:	9b1a      	ldr	r3, [sp, #104]	; 0x68
d000569c:	2101      	movs	r1, #1
d000569e:	681a      	ldr	r2, [r3, #0]
d00056a0:	9b09      	ldr	r3, [sp, #36]	; 0x24
d00056a2:	fa01 f202 	lsl.w	r2, r1, r2
d00056a6:	681b      	ldr	r3, [r3, #0]
d00056a8:	9211      	str	r2, [sp, #68]	; 0x44
d00056aa:	b212      	sxth	r2, r2
d00056ac:	9206      	str	r2, [sp, #24]
d00056ae:	2b00      	cmp	r3, #0
d00056b0:	f040 8099 	bne.w	d00057e6 <load_jpeg_image.constprop.0+0x1e36>
d00056b4:	4253      	negs	r3, r2
d00056b6:	46d3      	mov	fp, sl
d00056b8:	46ca      	mov	sl, r9
d00056ba:	46c1      	mov	r9, r8
d00056bc:	46a8      	mov	r8, r5
d00056be:	9319      	str	r3, [sp, #100]	; 0x64
d00056c0:	ee18 1a10 	vmov	r1, s16
d00056c4:	4658      	mov	r0, fp
d00056c6:	f7fc fb93 	bl	d0001df0 <stbi__jpeg_huff_decode>
d00056ca:	2800      	cmp	r0, #0
d00056cc:	f2c0 8081 	blt.w	d00057d2 <load_jpeg_image.constprop.0+0x1e22>
d00056d0:	f010 010f 	ands.w	r1, r0, #15
d00056d4:	ea4f 1620 	mov.w	r6, r0, asr #4
d00056d8:	d15c      	bne.n	d0005794 <load_jpeg_image.constprop.0+0x1de4>
d00056da:	2e0e      	cmp	r6, #14
d00056dc:	dc09      	bgt.n	d00056f2 <load_jpeg_image.constprop.0+0x1d42>
d00056de:	2001      	movs	r0, #1
d00056e0:	9b09      	ldr	r3, [sp, #36]	; 0x24
d00056e2:	40b0      	lsls	r0, r6
d00056e4:	3801      	subs	r0, #1
d00056e6:	6018      	str	r0, [r3, #0]
d00056e8:	2e00      	cmp	r6, #0
d00056ea:	f040 80bd 	bne.w	d0005868 <load_jpeg_image.constprop.0+0x1eb8>
d00056ee:	4631      	mov	r1, r6
d00056f0:	2640      	movs	r6, #64	; 0x40
d00056f2:	9b07      	ldr	r3, [sp, #28]
d00056f4:	6818      	ldr	r0, [r3, #0]
d00056f6:	4284      	cmp	r4, r0
d00056f8:	dc3d      	bgt.n	d0005776 <load_jpeg_image.constprop.0+0x1dc6>
d00056fa:	4b69      	ldr	r3, [pc, #420]	; (d00058a0 <load_jpeg_image.constprop.0+0x1ef0>)
d00056fc:	1e65      	subs	r5, r4, #1
d00056fe:	9108      	str	r1, [sp, #32]
d0005700:	441d      	add	r5, r3
d0005702:	464b      	mov	r3, r9
d0005704:	46d1      	mov	r9, sl
d0005706:	46aa      	mov	sl, r5
d0005708:	465d      	mov	r5, fp
d000570a:	469b      	mov	fp, r3
d000570c:	e003      	b.n	d0005716 <load_jpeg_image.constprop.0+0x1d66>
d000570e:	b356      	cbz	r6, d0005766 <load_jpeg_image.constprop.0+0x1db6>
d0005710:	3e01      	subs	r6, #1
d0005712:	4284      	cmp	r4, r0
d0005714:	dc24      	bgt.n	d0005760 <load_jpeg_image.constprop.0+0x1db0>
d0005716:	f81a 7f01 	ldrb.w	r7, [sl, #1]!
d000571a:	3401      	adds	r4, #1
d000571c:	f938 3017 	ldrsh.w	r3, [r8, r7, lsl #1]
d0005720:	eb08 0c47 	add.w	ip, r8, r7, lsl #1
d0005724:	2b00      	cmp	r3, #0
d0005726:	d0f2      	beq.n	d000570e <load_jpeg_image.constprop.0+0x1d5e>
d0005728:	f8db 3000 	ldr.w	r3, [fp]
d000572c:	2b00      	cmp	r3, #0
d000572e:	dd26      	ble.n	d000577e <load_jpeg_image.constprop.0+0x1dce>
d0005730:	f8d9 2000 	ldr.w	r2, [r9]
d0005734:	3b01      	subs	r3, #1
d0005736:	0051      	lsls	r1, r2, #1
d0005738:	2a00      	cmp	r2, #0
d000573a:	f8c9 1000 	str.w	r1, [r9]
d000573e:	f8cb 3000 	str.w	r3, [fp]
d0005742:	dae6      	bge.n	d0005712 <load_jpeg_image.constprop.0+0x1d62>
d0005744:	f938 3017 	ldrsh.w	r3, [r8, r7, lsl #1]
d0005748:	9a06      	ldr	r2, [sp, #24]
d000574a:	421a      	tst	r2, r3
d000574c:	d1e1      	bne.n	d0005712 <load_jpeg_image.constprop.0+0x1d62>
d000574e:	2b00      	cmp	r3, #0
d0005750:	9a11      	ldr	r2, [sp, #68]	; 0x44
d0005752:	bfcc      	ite	gt
d0005754:	189b      	addgt	r3, r3, r2
d0005756:	1a9b      	suble	r3, r3, r2
d0005758:	4284      	cmp	r4, r0
d000575a:	f828 3017 	strh.w	r3, [r8, r7, lsl #1]
d000575e:	ddda      	ble.n	d0005716 <load_jpeg_image.constprop.0+0x1d66>
d0005760:	46aa      	mov	sl, r5
d0005762:	46d8      	mov	r8, fp
d0005764:	e6c4      	b.n	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d0005766:	9908      	ldr	r1, [sp, #32]
d0005768:	4284      	cmp	r4, r0
d000576a:	46ca      	mov	sl, r9
d000576c:	46d9      	mov	r9, fp
d000576e:	f8ac 1000 	strh.w	r1, [ip]
d0005772:	46ab      	mov	fp, r5
d0005774:	dda4      	ble.n	d00056c0 <load_jpeg_image.constprop.0+0x1d10>
d0005776:	46c8      	mov	r8, r9
d0005778:	46d1      	mov	r9, sl
d000577a:	46da      	mov	sl, fp
d000577c:	e6b8      	b.n	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d000577e:	4628      	mov	r0, r5
d0005780:	f7fc fa5c 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0005784:	f8db 3000 	ldr.w	r3, [fp]
d0005788:	2b00      	cmp	r3, #0
d000578a:	f300 814d 	bgt.w	d0005a28 <load_jpeg_image.constprop.0+0x2078>
d000578e:	9b07      	ldr	r3, [sp, #28]
d0005790:	6818      	ldr	r0, [r3, #0]
d0005792:	e7be      	b.n	d0005712 <load_jpeg_image.constprop.0+0x1d62>
d0005794:	2901      	cmp	r1, #1
d0005796:	d11c      	bne.n	d00057d2 <load_jpeg_image.constprop.0+0x1e22>
d0005798:	f8d9 3000 	ldr.w	r3, [r9]
d000579c:	2b00      	cmp	r3, #0
d000579e:	dd0b      	ble.n	d00057b8 <load_jpeg_image.constprop.0+0x1e08>
d00057a0:	f8da 1000 	ldr.w	r1, [sl]
d00057a4:	3b01      	subs	r3, #1
d00057a6:	0048      	lsls	r0, r1, #1
d00057a8:	2900      	cmp	r1, #0
d00057aa:	f8ca 0000 	str.w	r0, [sl]
d00057ae:	f8c9 3000 	str.w	r3, [r9]
d00057b2:	da08      	bge.n	d00057c6 <load_jpeg_image.constprop.0+0x1e16>
d00057b4:	9906      	ldr	r1, [sp, #24]
d00057b6:	e79c      	b.n	d00056f2 <load_jpeg_image.constprop.0+0x1d42>
d00057b8:	4658      	mov	r0, fp
d00057ba:	f7fc fa3f 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00057be:	f8d9 3000 	ldr.w	r3, [r9]
d00057c2:	2b00      	cmp	r3, #0
d00057c4:	dcec      	bgt.n	d00057a0 <load_jpeg_image.constprop.0+0x1df0>
d00057c6:	9919      	ldr	r1, [sp, #100]	; 0x64
d00057c8:	e793      	b.n	d00056f2 <load_jpeg_image.constprop.0+0x1d42>
d00057ca:	4650      	mov	r0, sl
d00057cc:	f7fc fa36 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00057d0:	e711      	b.n	d00055f6 <load_jpeg_image.constprop.0+0x1c46>
d00057d2:	46da      	mov	sl, fp
d00057d4:	4a35      	ldr	r2, [pc, #212]	; (d00058ac <load_jpeg_image.constprop.0+0x1efc>)
d00057d6:	4936      	ldr	r1, [pc, #216]	; (d00058b0 <load_jpeg_image.constprop.0+0x1f00>)
d00057d8:	f8da 3000 	ldr.w	r3, [sl]
d00057dc:	6011      	str	r1, [r2, #0]
d00057de:	f8d3 c008 	ldr.w	ip, [r3, #8]
d00057e2:	f7fe b918 	b.w	d0003a16 <load_jpeg_image.constprop.0+0x66>
d00057e6:	9a07      	ldr	r2, [sp, #28]
d00057e8:	3b01      	subs	r3, #1
d00057ea:	9909      	ldr	r1, [sp, #36]	; 0x24
d00057ec:	6812      	ldr	r2, [r2, #0]
d00057ee:	600b      	str	r3, [r1, #0]
d00057f0:	4294      	cmp	r4, r2
d00057f2:	f73f ae7d 	bgt.w	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d00057f6:	4b2a      	ldr	r3, [pc, #168]	; (d00058a0 <load_jpeg_image.constprop.0+0x1ef0>)
d00057f8:	3c01      	subs	r4, #1
d00057fa:	441c      	add	r4, r3
d00057fc:	4643      	mov	r3, r8
d00057fe:	46d0      	mov	r8, sl
d0005800:	46ca      	mov	sl, r9
d0005802:	4699      	mov	r9, r3
d0005804:	e004      	b.n	d0005810 <load_jpeg_image.constprop.0+0x1e60>
d0005806:	3602      	adds	r6, #2
d0005808:	4b25      	ldr	r3, [pc, #148]	; (d00058a0 <load_jpeg_image.constprop.0+0x1ef0>)
d000580a:	1af6      	subs	r6, r6, r3
d000580c:	4296      	cmp	r6, r2
d000580e:	dc26      	bgt.n	d000585e <load_jpeg_image.constprop.0+0x1eae>
d0005810:	4626      	mov	r6, r4
d0005812:	f814 7f01 	ldrb.w	r7, [r4, #1]!
d0005816:	f935 3017 	ldrsh.w	r3, [r5, r7, lsl #1]
d000581a:	2b00      	cmp	r3, #0
d000581c:	d0f3      	beq.n	d0005806 <load_jpeg_image.constprop.0+0x1e56>
d000581e:	f8d9 3000 	ldr.w	r3, [r9]
d0005822:	2b00      	cmp	r3, #0
d0005824:	dd53      	ble.n	d00058ce <load_jpeg_image.constprop.0+0x1f1e>
d0005826:	f8da 1000 	ldr.w	r1, [sl]
d000582a:	3b01      	subs	r3, #1
d000582c:	0048      	lsls	r0, r1, #1
d000582e:	2900      	cmp	r1, #0
d0005830:	f8ca 0000 	str.w	r0, [sl]
d0005834:	f8c9 3000 	str.w	r3, [r9]
d0005838:	dae5      	bge.n	d0005806 <load_jpeg_image.constprop.0+0x1e56>
d000583a:	f935 3017 	ldrsh.w	r3, [r5, r7, lsl #1]
d000583e:	9906      	ldr	r1, [sp, #24]
d0005840:	4219      	tst	r1, r3
d0005842:	d1e0      	bne.n	d0005806 <load_jpeg_image.constprop.0+0x1e56>
d0005844:	2b00      	cmp	r3, #0
d0005846:	9911      	ldr	r1, [sp, #68]	; 0x44
d0005848:	f106 0602 	add.w	r6, r6, #2
d000584c:	bfcc      	ite	gt
d000584e:	185b      	addgt	r3, r3, r1
d0005850:	1a5b      	suble	r3, r3, r1
d0005852:	f825 3017 	strh.w	r3, [r5, r7, lsl #1]
d0005856:	4b12      	ldr	r3, [pc, #72]	; (d00058a0 <load_jpeg_image.constprop.0+0x1ef0>)
d0005858:	1af6      	subs	r6, r6, r3
d000585a:	4296      	cmp	r6, r2
d000585c:	ddd8      	ble.n	d0005810 <load_jpeg_image.constprop.0+0x1e60>
d000585e:	464b      	mov	r3, r9
d0005860:	46d1      	mov	r9, sl
d0005862:	46c2      	mov	sl, r8
d0005864:	4698      	mov	r8, r3
d0005866:	e643      	b.n	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d0005868:	f8d9 5000 	ldr.w	r5, [r9]
d000586c:	42ae      	cmp	r6, r5
d000586e:	dc46      	bgt.n	d00058fe <load_jpeg_image.constprop.0+0x1f4e>
d0005870:	f8da 3000 	ldr.w	r3, [sl]
d0005874:	f1c6 0c20 	rsb	ip, r6, #32
d0005878:	4a0a      	ldr	r2, [pc, #40]	; (d00058a4 <load_jpeg_image.constprop.0+0x1ef4>)
d000587a:	1bad      	subs	r5, r5, r6
d000587c:	fa63 f30c 	ror.w	r3, r3, ip
d0005880:	f852 7026 	ldr.w	r7, [r2, r6, lsl #2]
d0005884:	ea03 0607 	and.w	r6, r3, r7
d0005888:	ea23 0307 	bic.w	r3, r3, r7
d000588c:	4430      	add	r0, r6
d000588e:	f8ca 3000 	str.w	r3, [sl]
d0005892:	f8c9 5000 	str.w	r5, [r9]
d0005896:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0005898:	2640      	movs	r6, #64	; 0x40
d000589a:	6018      	str	r0, [r3, #0]
d000589c:	e729      	b.n	d00056f2 <load_jpeg_image.constprop.0+0x1d42>
d000589e:	bf00      	nop
d00058a0:	d000d548 	.word	0xd000d548
d00058a4:	d000d4c4 	.word	0xd000d4c4
d00058a8:	d000d508 	.word	0xd000d508
d00058ac:	d000dec8 	.word	0xd000dec8
d00058b0:	d000d2f0 	.word	0xd000d2f0
d00058b4:	4650      	mov	r0, sl
d00058b6:	9211      	str	r2, [sp, #68]	; 0x44
d00058b8:	9108      	str	r1, [sp, #32]
d00058ba:	f7fc f9bf 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00058be:	f8d8 0000 	ldr.w	r0, [r8]
d00058c2:	9908      	ldr	r1, [sp, #32]
d00058c4:	9a11      	ldr	r2, [sp, #68]	; 0x44
d00058c6:	4281      	cmp	r1, r0
d00058c8:	f73f aee4 	bgt.w	d0005694 <load_jpeg_image.constprop.0+0x1ce4>
d00058cc:	e6c1      	b.n	d0005652 <load_jpeg_image.constprop.0+0x1ca2>
d00058ce:	4640      	mov	r0, r8
d00058d0:	f7fc f9b4 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00058d4:	f8d9 3000 	ldr.w	r3, [r9]
d00058d8:	2b00      	cmp	r3, #0
d00058da:	f300 80a2 	bgt.w	d0005a22 <load_jpeg_image.constprop.0+0x2072>
d00058de:	9b07      	ldr	r3, [sp, #28]
d00058e0:	681a      	ldr	r2, [r3, #0]
d00058e2:	e790      	b.n	d0005806 <load_jpeg_image.constprop.0+0x1e56>
d00058e4:	3b01      	subs	r3, #1
d00058e6:	9a09      	ldr	r2, [sp, #36]	; 0x24
d00058e8:	6013      	str	r3, [r2, #0]
d00058ea:	e601      	b.n	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d00058ec:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d00058ee:	9a1f      	ldr	r2, [sp, #124]	; 0x7c
d00058f0:	3301      	adds	r3, #1
d00058f2:	429a      	cmp	r2, r3
d00058f4:	930a      	str	r3, [sp, #40]	; 0x28
d00058f6:	f47f add3 	bne.w	d00054a0 <load_jpeg_image.constprop.0+0x1af0>
d00058fa:	f7ff b9eb 	b.w	d0004cd4 <load_jpeg_image.constprop.0+0x1324>
d00058fe:	4658      	mov	r0, fp
d0005900:	9108      	str	r1, [sp, #32]
d0005902:	f7fc f99b 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d0005906:	f8d9 5000 	ldr.w	r5, [r9]
d000590a:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000590c:	42ae      	cmp	r6, r5
d000590e:	9908      	ldr	r1, [sp, #32]
d0005910:	6818      	ldr	r0, [r3, #0]
d0005912:	dcc0      	bgt.n	d0005896 <load_jpeg_image.constprop.0+0x1ee6>
d0005914:	e7ac      	b.n	d0005870 <load_jpeg_image.constprop.0+0x1ec0>
d0005916:	2201      	movs	r2, #1
d0005918:	9909      	ldr	r1, [sp, #36]	; 0x24
d000591a:	409a      	lsls	r2, r3
d000591c:	600a      	str	r2, [r1, #0]
d000591e:	b91b      	cbnz	r3, d0005928 <load_jpeg_image.constprop.0+0x1f78>
d0005920:	3a01      	subs	r2, #1
d0005922:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0005924:	601a      	str	r2, [r3, #0]
d0005926:	e5e3      	b.n	d00054f0 <load_jpeg_image.constprop.0+0x1b40>
d0005928:	f8d8 5000 	ldr.w	r5, [r8]
d000592c:	42ab      	cmp	r3, r5
d000592e:	dc3a      	bgt.n	d00059a6 <load_jpeg_image.constprop.0+0x1ff6>
d0005930:	f8d9 1000 	ldr.w	r1, [r9]
d0005934:	f1c3 0420 	rsb	r4, r3, #32
d0005938:	483e      	ldr	r0, [pc, #248]	; (d0005a34 <load_jpeg_image.constprop.0+0x2084>)
d000593a:	41e1      	rors	r1, r4
d000593c:	f850 0023 	ldr.w	r0, [r0, r3, lsl #2]
d0005940:	1aeb      	subs	r3, r5, r3
d0005942:	ea01 0400 	and.w	r4, r1, r0
d0005946:	ea21 0100 	bic.w	r1, r1, r0
d000594a:	4422      	add	r2, r4
d000594c:	f8c9 1000 	str.w	r1, [r9]
d0005950:	f8c8 3000 	str.w	r3, [r8]
d0005954:	e7e4      	b.n	d0005920 <load_jpeg_image.constprop.0+0x1f70>
d0005956:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d0005958:	681b      	ldr	r3, [r3, #0]
d000595a:	2b17      	cmp	r3, #23
d000595c:	dd45      	ble.n	d00059ea <load_jpeg_image.constprop.0+0x203a>
d000595e:	9905      	ldr	r1, [sp, #20]
d0005960:	780b      	ldrb	r3, [r1, #0]
d0005962:	f103 0230 	add.w	r2, r3, #48	; 0x30
d0005966:	b2d2      	uxtb	r2, r2
d0005968:	2a07      	cmp	r2, #7
d000596a:	f63f a9b5 	bhi.w	d0004cd8 <load_jpeg_image.constprop.0+0x1328>
d000596e:	2300      	movs	r3, #0
d0005970:	980a      	ldr	r0, [sp, #40]	; 0x28
d0005972:	22ff      	movs	r2, #255	; 0xff
d0005974:	6003      	str	r3, [r0, #0]
d0005976:	980b      	ldr	r0, [sp, #44]	; 0x2c
d0005978:	6003      	str	r3, [r0, #0]
d000597a:	9816      	ldr	r0, [sp, #88]	; 0x58
d000597c:	6003      	str	r3, [r0, #0]
d000597e:	9815      	ldr	r0, [sp, #84]	; 0x54
d0005980:	6003      	str	r3, [r0, #0]
d0005982:	9814      	ldr	r0, [sp, #80]	; 0x50
d0005984:	6003      	str	r3, [r0, #0]
d0005986:	9813      	ldr	r0, [sp, #76]	; 0x4c
d0005988:	6003      	str	r3, [r0, #0]
d000598a:	9812      	ldr	r0, [sp, #72]	; 0x48
d000598c:	6003      	str	r3, [r0, #0]
d000598e:	700a      	strb	r2, [r1, #0]
d0005990:	9a17      	ldr	r2, [sp, #92]	; 0x5c
d0005992:	990c      	ldr	r1, [sp, #48]	; 0x30
d0005994:	6812      	ldr	r2, [r2, #0]
d0005996:	429a      	cmp	r2, r3
d0005998:	bf08      	it	eq
d000599a:	f06f 4200 	mvneq.w	r2, #2147483648	; 0x80000000
d000599e:	600a      	str	r2, [r1, #0]
d00059a0:	9a09      	ldr	r2, [sp, #36]	; 0x24
d00059a2:	6013      	str	r3, [r2, #0]
d00059a4:	e54f      	b.n	d0005446 <load_jpeg_image.constprop.0+0x1a96>
d00059a6:	4650      	mov	r0, sl
d00059a8:	9306      	str	r3, [sp, #24]
d00059aa:	f7fc f947 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00059ae:	f8d8 5000 	ldr.w	r5, [r8]
d00059b2:	9b06      	ldr	r3, [sp, #24]
d00059b4:	42ab      	cmp	r3, r5
d00059b6:	dd31      	ble.n	d0005a1c <load_jpeg_image.constprop.0+0x206c>
d00059b8:	9b09      	ldr	r3, [sp, #36]	; 0x24
d00059ba:	681a      	ldr	r2, [r3, #0]
d00059bc:	e7b0      	b.n	d0005920 <load_jpeg_image.constprop.0+0x1f70>
d00059be:	4405      	add	r5, r0
d00059c0:	f106 0329 	add.w	r3, r6, #41	; 0x29
d00059c4:	f896 0028 	ldrb.w	r0, [r6, #40]	; 0x28
d00059c8:	f7ff b838 	b.w	d0004a3c <load_jpeg_image.constprop.0+0x108c>
d00059cc:	4658      	mov	r0, fp
d00059ce:	f7fc f935 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00059d2:	f7ff bbd5 	b.w	d0005180 <load_jpeg_image.constprop.0+0x17d0>
d00059d6:	f896 1028 	ldrb.w	r1, [r6, #40]	; 0x28
d00059da:	4404      	add	r4, r0
d00059dc:	f106 0229 	add.w	r2, r6, #41	; 0x29
d00059e0:	f001 030f 	and.w	r3, r1, #15
d00059e4:	1108      	asrs	r0, r1, #4
d00059e6:	461d      	mov	r5, r3
d00059e8:	e409      	b.n	d00051fe <load_jpeg_image.constprop.0+0x184e>
d00059ea:	4650      	mov	r0, sl
d00059ec:	f7fc f926 	bl	d0001c3c <stbi__grow_buffer_unsafe>
d00059f0:	e7b5      	b.n	d000595e <load_jpeg_image.constprop.0+0x1fae>
d00059f2:	4404      	add	r4, r0
d00059f4:	f106 0329 	add.w	r3, r6, #41	; 0x29
d00059f8:	f896 0028 	ldrb.w	r0, [r6, #40]	; 0x28
d00059fc:	e41f      	b.n	d000523e <load_jpeg_image.constprop.0+0x188e>
d00059fe:	f644 0008 	movw	r0, #18440	; 0x4808
d0005a02:	f244 71e0 	movw	r1, #18400	; 0x47e0
d0005a06:	f84a 2000 	str.w	r2, [sl, r0]
d0005a0a:	eb0a 0200 	add.w	r2, sl, r0
d0005a0e:	f84a 3001 	str.w	r3, [sl, r1]
d0005a12:	eb0a 0301 	add.w	r3, sl, r1
d0005a16:	920c      	str	r2, [sp, #48]	; 0x30
d0005a18:	9309      	str	r3, [sp, #36]	; 0x24
d0005a1a:	e48e      	b.n	d000533a <load_jpeg_image.constprop.0+0x198a>
d0005a1c:	9a09      	ldr	r2, [sp, #36]	; 0x24
d0005a1e:	6812      	ldr	r2, [r2, #0]
d0005a20:	e786      	b.n	d0005930 <load_jpeg_image.constprop.0+0x1f80>
d0005a22:	9a07      	ldr	r2, [sp, #28]
d0005a24:	6812      	ldr	r2, [r2, #0]
d0005a26:	e6fe      	b.n	d0005826 <load_jpeg_image.constprop.0+0x1e76>
d0005a28:	9a07      	ldr	r2, [sp, #28]
d0005a2a:	6810      	ldr	r0, [r2, #0]
d0005a2c:	e680      	b.n	d0005730 <load_jpeg_image.constprop.0+0x1d80>
d0005a2e:	4602      	mov	r2, r0
d0005a30:	f7fe b99b 	b.w	d0003d6a <load_jpeg_image.constprop.0+0x3ba>
d0005a34:	d000d4c4 	.word	0xd000d4c4

d0005a38 <stbi__load_and_postprocess_8bit>:
d0005a38:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0005a3c:	4604      	mov	r4, r0
d0005a3e:	b087      	sub	sp, #28
d0005a40:	460e      	mov	r6, r1
d0005a42:	f644 0018 	movw	r0, #18456	; 0x4818
d0005a46:	2101      	movs	r1, #1
d0005a48:	4617      	mov	r7, r2
d0005a4a:	469b      	mov	fp, r3
d0005a4c:	f006 f89e 	bl	d000bb8c <calloc>
d0005a50:	b3a0      	cbz	r0, d0005abc <stbi__load_and_postprocess_8bit+0x84>
d0005a52:	4605      	mov	r5, r0
d0005a54:	f8df a1dc 	ldr.w	sl, [pc, #476]	; d0005c34 <stbi__load_and_postprocess_8bit+0x1fc>
d0005a58:	f644 000c 	movw	r0, #18444	; 0x480c
d0005a5c:	f644 0210 	movw	r2, #18448	; 0x4810
d0005a60:	602c      	str	r4, [r5, #0]
d0005a62:	f644 0314 	movw	r3, #18452	; 0x4814
d0005a66:	f845 a000 	str.w	sl, [r5, r0]
d0005a6a:	f244 71e4 	movw	r1, #18404	; 0x47e4
d0005a6e:	f8df 91c8 	ldr.w	r9, [pc, #456]	; d0005c38 <stbi__load_and_postprocess_8bit+0x200>
d0005a72:	2000      	movs	r0, #0
d0005a74:	f8df 81c4 	ldr.w	r8, [pc, #452]	; d0005c3c <stbi__load_and_postprocess_8bit+0x204>
d0005a78:	f845 9002 	str.w	r9, [r5, r2]
d0005a7c:	f244 72e8 	movw	r2, #18408	; 0x47e8
d0005a80:	f845 8003 	str.w	r8, [r5, r3]
d0005a84:	f04f 33ff 	mov.w	r3, #4294967295	; 0xffffffff
d0005a88:	5068      	str	r0, [r5, r1]
d0005a8a:	f244 71c4 	movw	r1, #18372	; 0x47c4
d0005a8e:	50ab      	str	r3, [r5, r2]
d0005a90:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0005a94:	546b      	strb	r3, [r5, r1]
d0005a96:	f8d4 10b0 	ldr.w	r1, [r4, #176]	; 0xb0
d0005a9a:	428a      	cmp	r2, r1
d0005a9c:	d316      	bcc.n	d0005acc <stbi__load_and_postprocess_8bit+0x94>
d0005a9e:	6a23      	ldr	r3, [r4, #32]
d0005aa0:	2b00      	cmp	r3, #0
d0005aa2:	f040 809c 	bne.w	d0005bde <stbi__load_and_postprocess_8bit+0x1a6>
d0005aa6:	f8d4 20b8 	ldr.w	r2, [r4, #184]	; 0xb8
d0005aaa:	4628      	mov	r0, r5
d0005aac:	f8d4 30b4 	ldr.w	r3, [r4, #180]	; 0xb4
d0005ab0:	f8c4 20b0 	str.w	r2, [r4, #176]	; 0xb0
d0005ab4:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0005ab8:	f006 f890 	bl	d000bbdc <free>
d0005abc:	4b59      	ldr	r3, [pc, #356]	; (d0005c24 <stbi__load_and_postprocess_8bit+0x1ec>)
d0005abe:	2500      	movs	r5, #0
d0005ac0:	4a59      	ldr	r2, [pc, #356]	; (d0005c28 <stbi__load_and_postprocess_8bit+0x1f0>)
d0005ac2:	601a      	str	r2, [r3, #0]
d0005ac4:	4628      	mov	r0, r5
d0005ac6:	b007      	add	sp, #28
d0005ac8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0005acc:	1c53      	adds	r3, r2, #1
d0005ace:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0005ad2:	7812      	ldrb	r2, [r2, #0]
d0005ad4:	2aff      	cmp	r2, #255	; 0xff
d0005ad6:	d1e6      	bne.n	d0005aa6 <stbi__load_and_postprocess_8bit+0x6e>
d0005ad8:	f104 0229 	add.w	r2, r4, #41	; 0x29
d0005adc:	f104 0028 	add.w	r0, r4, #40	; 0x28
d0005ae0:	9603      	str	r6, [sp, #12]
d0005ae2:	9205      	str	r2, [sp, #20]
d0005ae4:	4606      	mov	r6, r0
d0005ae6:	9704      	str	r7, [sp, #16]
d0005ae8:	460a      	mov	r2, r1
d0005aea:	9f05      	ldr	r7, [sp, #20]
d0005aec:	4293      	cmp	r3, r2
d0005aee:	d365      	bcc.n	d0005bbc <stbi__load_and_postprocess_8bit+0x184>
d0005af0:	6a23      	ldr	r3, [r4, #32]
d0005af2:	2b00      	cmp	r3, #0
d0005af4:	d0d7      	beq.n	d0005aa6 <stbi__load_and_postprocess_8bit+0x6e>
d0005af6:	6923      	ldr	r3, [r4, #16]
d0005af8:	4631      	mov	r1, r6
d0005afa:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0005afc:	69e0      	ldr	r0, [r4, #28]
d0005afe:	4798      	blx	r3
d0005b00:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0005b04:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0005b08:	463b      	mov	r3, r7
d0005b0a:	eba2 0c01 	sub.w	ip, r2, r1
d0005b0e:	f8d4 10a8 	ldr.w	r1, [r4, #168]	; 0xa8
d0005b12:	1832      	adds	r2, r6, r0
d0005b14:	4461      	add	r1, ip
d0005b16:	f8c4 10a8 	str.w	r1, [r4, #168]	; 0xa8
d0005b1a:	2800      	cmp	r0, #0
d0005b1c:	d055      	beq.n	d0005bca <stbi__load_and_postprocess_8bit+0x192>
d0005b1e:	f894 c028 	ldrb.w	ip, [r4, #40]	; 0x28
d0005b22:	f8c4 20b0 	str.w	r2, [r4, #176]	; 0xb0
d0005b26:	f8c4 70ac 	str.w	r7, [r4, #172]	; 0xac
d0005b2a:	f1bc 0fff 	cmp.w	ip, #255	; 0xff
d0005b2e:	d0dd      	beq.n	d0005aec <stbi__load_and_postprocess_8bit+0xb4>
d0005b30:	4662      	mov	r2, ip
d0005b32:	9e03      	ldr	r6, [sp, #12]
d0005b34:	9f04      	ldr	r7, [sp, #16]
d0005b36:	2ad8      	cmp	r2, #216	; 0xd8
d0005b38:	d1b5      	bne.n	d0005aa6 <stbi__load_and_postprocess_8bit+0x6e>
d0005b3a:	f8d4 20b8 	ldr.w	r2, [r4, #184]	; 0xb8
d0005b3e:	4628      	mov	r0, r5
d0005b40:	f8d4 30b4 	ldr.w	r3, [r4, #180]	; 0xb4
d0005b44:	f8c4 20b0 	str.w	r2, [r4, #176]	; 0xb0
d0005b48:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0005b4c:	f006 f846 	bl	d000bbdc <free>
d0005b50:	2101      	movs	r1, #1
d0005b52:	f644 0018 	movw	r0, #18456	; 0x4818
d0005b56:	f006 f819 	bl	d000bb8c <calloc>
d0005b5a:	4605      	mov	r5, r0
d0005b5c:	2800      	cmp	r0, #0
d0005b5e:	d05c      	beq.n	d0005c1a <stbi__load_and_postprocess_8bit+0x1e2>
d0005b60:	6004      	str	r4, [r0, #0]
d0005b62:	f644 030c 	movw	r3, #18444	; 0x480c
d0005b66:	f644 0210 	movw	r2, #18448	; 0x4810
d0005b6a:	f644 0114 	movw	r1, #18452	; 0x4814
d0005b6e:	9c10      	ldr	r4, [sp, #64]	; 0x40
d0005b70:	f840 a003 	str.w	sl, [r0, r3]
d0005b74:	465b      	mov	r3, fp
d0005b76:	f840 9002 	str.w	r9, [r0, r2]
d0005b7a:	463a      	mov	r2, r7
d0005b7c:	f840 8001 	str.w	r8, [r0, r1]
d0005b80:	4631      	mov	r1, r6
d0005b82:	9400      	str	r4, [sp, #0]
d0005b84:	f7fd ff14 	bl	d00039b0 <load_jpeg_image.constprop.0>
d0005b88:	4603      	mov	r3, r0
d0005b8a:	4628      	mov	r0, r5
d0005b8c:	461d      	mov	r5, r3
d0005b8e:	f006 f825 	bl	d000bbdc <free>
d0005b92:	2d00      	cmp	r5, #0
d0005b94:	d096      	beq.n	d0005ac4 <stbi__load_and_postprocess_8bit+0x8c>
d0005b96:	4b25      	ldr	r3, [pc, #148]	; (d0005c2c <stbi__load_and_postprocess_8bit+0x1f4>)
d0005b98:	681b      	ldr	r3, [r3, #0]
d0005b9a:	2b00      	cmp	r3, #0
d0005b9c:	d092      	beq.n	d0005ac4 <stbi__load_and_postprocess_8bit+0x8c>
d0005b9e:	9b10      	ldr	r3, [sp, #64]	; 0x40
d0005ba0:	b913      	cbnz	r3, d0005ba8 <stbi__load_and_postprocess_8bit+0x170>
d0005ba2:	f8db 3000 	ldr.w	r3, [fp]
d0005ba6:	9310      	str	r3, [sp, #64]	; 0x40
d0005ba8:	4628      	mov	r0, r5
d0005baa:	9b10      	ldr	r3, [sp, #64]	; 0x40
d0005bac:	683a      	ldr	r2, [r7, #0]
d0005bae:	6831      	ldr	r1, [r6, #0]
d0005bb0:	f7fb fe26 	bl	d0001800 <stbi__vertical_flip>
d0005bb4:	4628      	mov	r0, r5
d0005bb6:	b007      	add	sp, #28
d0005bb8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0005bbc:	1c58      	adds	r0, r3, #1
d0005bbe:	f8c4 00ac 	str.w	r0, [r4, #172]	; 0xac
d0005bc2:	f893 c000 	ldrb.w	ip, [r3]
d0005bc6:	4603      	mov	r3, r0
d0005bc8:	e7af      	b.n	d0005b2a <stbi__load_and_postprocess_8bit+0xf2>
d0005bca:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0005bce:	6220      	str	r0, [r4, #32]
d0005bd0:	f884 0028 	strb.w	r0, [r4, #40]	; 0x28
d0005bd4:	f8c4 30b0 	str.w	r3, [r4, #176]	; 0xb0
d0005bd8:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0005bdc:	e763      	b.n	d0005aa6 <stbi__load_and_postprocess_8bit+0x6e>
d0005bde:	f104 0128 	add.w	r1, r4, #40	; 0x28
d0005be2:	6923      	ldr	r3, [r4, #16]
d0005be4:	6a62      	ldr	r2, [r4, #36]	; 0x24
d0005be6:	69e0      	ldr	r0, [r4, #28]
d0005be8:	9103      	str	r1, [sp, #12]
d0005bea:	4798      	blx	r3
d0005bec:	f8d4 10b4 	ldr.w	r1, [r4, #180]	; 0xb4
d0005bf0:	f8d4 20ac 	ldr.w	r2, [r4, #172]	; 0xac
d0005bf4:	f8d4 30a8 	ldr.w	r3, [r4, #168]	; 0xa8
d0005bf8:	1a52      	subs	r2, r2, r1
d0005bfa:	9903      	ldr	r1, [sp, #12]
d0005bfc:	4413      	add	r3, r2
d0005bfe:	f8c4 30a8 	str.w	r3, [r4, #168]	; 0xa8
d0005c02:	2800      	cmp	r0, #0
d0005c04:	d0e1      	beq.n	d0005bca <stbi__load_and_postprocess_8bit+0x192>
d0005c06:	4401      	add	r1, r0
d0005c08:	f104 0329 	add.w	r3, r4, #41	; 0x29
d0005c0c:	f894 2028 	ldrb.w	r2, [r4, #40]	; 0x28
d0005c10:	f8c4 10b0 	str.w	r1, [r4, #176]	; 0xb0
d0005c14:	f8c4 30ac 	str.w	r3, [r4, #172]	; 0xac
d0005c18:	e75c      	b.n	d0005ad4 <stbi__load_and_postprocess_8bit+0x9c>
d0005c1a:	4b02      	ldr	r3, [pc, #8]	; (d0005c24 <stbi__load_and_postprocess_8bit+0x1ec>)
d0005c1c:	4a04      	ldr	r2, [pc, #16]	; (d0005c30 <stbi__load_and_postprocess_8bit+0x1f8>)
d0005c1e:	601a      	str	r2, [r3, #0]
d0005c20:	e750      	b.n	d0005ac4 <stbi__load_and_postprocess_8bit+0x8c>
d0005c22:	bf00      	nop
d0005c24:	d000dec8 	.word	0xd000dec8
d0005c28:	d000d494 	.word	0xd000d494
d0005c2c:	d000decc 	.word	0xd000decc
d0005c30:	d000d418 	.word	0xd000d418
d0005c34:	d0001151 	.word	0xd0001151
d0005c38:	d0001741 	.word	0xd0001741
d0005c3c:	d00015e1 	.word	0xd00015e1

d0005c40 <stbi_image_free>:
d0005c40:	f005 bfcc 	b.w	d000bbdc <free>

d0005c44 <stbi_load_from_memory>:
d0005c44:	b570      	push	{r4, r5, r6, lr}
d0005c46:	b0b2      	sub	sp, #200	; 0xc8
d0005c48:	4604      	mov	r4, r0
d0005c4a:	460d      	mov	r5, r1
d0005c4c:	2600      	movs	r6, #0
d0005c4e:	9837      	ldr	r0, [sp, #220]	; 0xdc
d0005c50:	4611      	mov	r1, r2
d0005c52:	4425      	add	r5, r4
d0005c54:	461a      	mov	r2, r3
d0005c56:	9b36      	ldr	r3, [sp, #216]	; 0xd8
d0005c58:	9000      	str	r0, [sp, #0]
d0005c5a:	a803      	add	r0, sp, #12
d0005c5c:	9430      	str	r4, [sp, #192]	; 0xc0
d0005c5e:	942e      	str	r4, [sp, #184]	; 0xb8
d0005c60:	9531      	str	r5, [sp, #196]	; 0xc4
d0005c62:	952f      	str	r5, [sp, #188]	; 0xbc
d0005c64:	9607      	str	r6, [sp, #28]
d0005c66:	960b      	str	r6, [sp, #44]	; 0x2c
d0005c68:	962d      	str	r6, [sp, #180]	; 0xb4
d0005c6a:	f7ff fee5 	bl	d0005a38 <stbi__load_and_postprocess_8bit>
d0005c6e:	b032      	add	sp, #200	; 0xc8
d0005c70:	bd70      	pop	{r4, r5, r6, pc}
d0005c72:	bf00      	nop

d0005c74 <upsampleCb>:
d0005c74:	4b73      	ldr	r3, [pc, #460]	; (d0005e44 <upsampleCb+0x1d0>)
d0005c76:	4a74      	ldr	r2, [pc, #464]	; (d0005e48 <upsampleCb+0x1d4>)
d0005c78:	eb03 0040 	add.w	r0, r3, r0, lsl #1
d0005c7c:	eb02 0c01 	add.w	ip, r2, r1
d0005c80:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
d0005c84:	4f71      	ldr	r7, [pc, #452]	; (d0005e4c <upsampleCb+0x1d8>)
d0005c86:	f100 0608 	add.w	r6, r0, #8
d0005c8a:	f100 0e48 	add.w	lr, r0, #72	; 0x48
d0005c8e:	440f      	add	r7, r1
d0005c90:	f1a6 0508 	sub.w	r5, r6, #8
d0005c94:	f10c 0402 	add.w	r4, ip, #2
d0005c98:	1cb8      	adds	r0, r7, #2
d0005c9a:	f935 3b02 	ldrsh.w	r3, [r5], #2
d0005c9e:	f814 8c02 	ldrb.w	r8, [r4, #-2]
d0005ca2:	b2d9      	uxtb	r1, r3
d0005ca4:	eb01 0281 	add.w	r2, r1, r1, lsl #2
d0005ca8:	460b      	mov	r3, r1
d0005caa:	eb01 0242 	add.w	r2, r1, r2, lsl #1
d0005cae:	0952      	lsrs	r2, r2, #5
d0005cb0:	3a2c      	subs	r2, #44	; 0x2c
d0005cb2:	b292      	uxth	r2, r2
d0005cb4:	eba8 0802 	sub.w	r8, r8, r2
d0005cb8:	fa1f f888 	uxth.w	r8, r8
d0005cbc:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0005cc0:	d909      	bls.n	d0005cd6 <upsampleCb+0x62>
d0005cc2:	fa0f f988 	sxth.w	r9, r8
d0005cc6:	f1b9 0f00 	cmp.w	r9, #0
d0005cca:	f2c0 8093 	blt.w	d0005df4 <upsampleCb+0x180>
d0005cce:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d0005cd2:	f300 80b1 	bgt.w	d0005e38 <upsampleCb+0x1c4>
d0005cd6:	fa5f f988 	uxtb.w	r9, r8
d0005cda:	f814 8c01 	ldrb.w	r8, [r4, #-1]
d0005cde:	f804 9c02 	strb.w	r9, [r4, #-2]
d0005ce2:	eba8 0802 	sub.w	r8, r8, r2
d0005ce6:	fa1f f888 	uxth.w	r8, r8
d0005cea:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0005cee:	d908      	bls.n	d0005d02 <upsampleCb+0x8e>
d0005cf0:	fa0f f988 	sxth.w	r9, r8
d0005cf4:	f1b9 0f00 	cmp.w	r9, #0
d0005cf8:	db7f      	blt.n	d0005dfa <upsampleCb+0x186>
d0005cfa:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d0005cfe:	f300 809e 	bgt.w	d0005e3e <upsampleCb+0x1ca>
d0005d02:	fa5f f988 	uxtb.w	r9, r8
d0005d06:	f894 8006 	ldrb.w	r8, [r4, #6]
d0005d0a:	f804 9c01 	strb.w	r9, [r4, #-1]
d0005d0e:	eba8 0802 	sub.w	r8, r8, r2
d0005d12:	fa1f f888 	uxth.w	r8, r8
d0005d16:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0005d1a:	d907      	bls.n	d0005d2c <upsampleCb+0xb8>
d0005d1c:	fa0f f988 	sxth.w	r9, r8
d0005d20:	f1b9 0f00 	cmp.w	r9, #0
d0005d24:	db6c      	blt.n	d0005e00 <upsampleCb+0x18c>
d0005d26:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d0005d2a:	dc7f      	bgt.n	d0005e2c <upsampleCb+0x1b8>
d0005d2c:	fa5f f988 	uxtb.w	r9, r8
d0005d30:	f894 8007 	ldrb.w	r8, [r4, #7]
d0005d34:	f884 9006 	strb.w	r9, [r4, #6]
d0005d38:	eba8 0202 	sub.w	r2, r8, r2
d0005d3c:	b292      	uxth	r2, r2
d0005d3e:	2aff      	cmp	r2, #255	; 0xff
d0005d40:	d907      	bls.n	d0005d52 <upsampleCb+0xde>
d0005d42:	fa0f f882 	sxth.w	r8, r2
d0005d46:	f1b8 0f00 	cmp.w	r8, #0
d0005d4a:	db5c      	blt.n	d0005e06 <upsampleCb+0x192>
d0005d4c:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0005d50:	dc6f      	bgt.n	d0005e32 <upsampleCb+0x1be>
d0005d52:	fa5f f882 	uxtb.w	r8, r2
d0005d56:	eb01 0141 	add.w	r1, r1, r1, lsl #1
d0005d5a:	3be3      	subs	r3, #227	; 0xe3
d0005d5c:	f810 2c02 	ldrb.w	r2, [r0, #-2]
d0005d60:	eb01 1141 	add.w	r1, r1, r1, lsl #5
d0005d64:	f884 8007 	strb.w	r8, [r4, #7]
d0005d68:	eb03 11d1 	add.w	r1, r3, r1, lsr #7
d0005d6c:	b28b      	uxth	r3, r1
d0005d6e:	441a      	add	r2, r3
d0005d70:	b292      	uxth	r2, r2
d0005d72:	2aff      	cmp	r2, #255	; 0xff
d0005d74:	d904      	bls.n	d0005d80 <upsampleCb+0x10c>
d0005d76:	b211      	sxth	r1, r2
d0005d78:	2900      	cmp	r1, #0
d0005d7a:	db47      	blt.n	d0005e0c <upsampleCb+0x198>
d0005d7c:	29ff      	cmp	r1, #255	; 0xff
d0005d7e:	dc51      	bgt.n	d0005e24 <upsampleCb+0x1b0>
d0005d80:	b2d1      	uxtb	r1, r2
d0005d82:	f810 2c01 	ldrb.w	r2, [r0, #-1]
d0005d86:	f800 1c02 	strb.w	r1, [r0, #-2]
d0005d8a:	441a      	add	r2, r3
d0005d8c:	b292      	uxth	r2, r2
d0005d8e:	2aff      	cmp	r2, #255	; 0xff
d0005d90:	d904      	bls.n	d0005d9c <upsampleCb+0x128>
d0005d92:	b211      	sxth	r1, r2
d0005d94:	2900      	cmp	r1, #0
d0005d96:	db3b      	blt.n	d0005e10 <upsampleCb+0x19c>
d0005d98:	29ff      	cmp	r1, #255	; 0xff
d0005d9a:	dc45      	bgt.n	d0005e28 <upsampleCb+0x1b4>
d0005d9c:	b2d1      	uxtb	r1, r2
d0005d9e:	7982      	ldrb	r2, [r0, #6]
d0005da0:	f800 1c01 	strb.w	r1, [r0, #-1]
d0005da4:	441a      	add	r2, r3
d0005da6:	b292      	uxth	r2, r2
d0005da8:	2aff      	cmp	r2, #255	; 0xff
d0005daa:	d904      	bls.n	d0005db6 <upsampleCb+0x142>
d0005dac:	b211      	sxth	r1, r2
d0005dae:	2900      	cmp	r1, #0
d0005db0:	db30      	blt.n	d0005e14 <upsampleCb+0x1a0>
d0005db2:	29ff      	cmp	r1, #255	; 0xff
d0005db4:	dc32      	bgt.n	d0005e1c <upsampleCb+0x1a8>
d0005db6:	b2d2      	uxtb	r2, r2
d0005db8:	79c1      	ldrb	r1, [r0, #7]
d0005dba:	7182      	strb	r2, [r0, #6]
d0005dbc:	440b      	add	r3, r1
d0005dbe:	b29b      	uxth	r3, r3
d0005dc0:	2bff      	cmp	r3, #255	; 0xff
d0005dc2:	d904      	bls.n	d0005dce <upsampleCb+0x15a>
d0005dc4:	b21a      	sxth	r2, r3
d0005dc6:	2a00      	cmp	r2, #0
d0005dc8:	db26      	blt.n	d0005e18 <upsampleCb+0x1a4>
d0005dca:	2aff      	cmp	r2, #255	; 0xff
d0005dcc:	dc28      	bgt.n	d0005e20 <upsampleCb+0x1ac>
d0005dce:	b2db      	uxtb	r3, r3
d0005dd0:	42b5      	cmp	r5, r6
d0005dd2:	71c3      	strb	r3, [r0, #7]
d0005dd4:	f104 0402 	add.w	r4, r4, #2
d0005dd8:	f100 0002 	add.w	r0, r0, #2
d0005ddc:	f47f af5d 	bne.w	d0005c9a <upsampleCb+0x26>
d0005de0:	f105 0610 	add.w	r6, r5, #16
d0005de4:	f10c 0c10 	add.w	ip, ip, #16
d0005de8:	3710      	adds	r7, #16
d0005dea:	4576      	cmp	r6, lr
d0005dec:	f47f af50 	bne.w	d0005c90 <upsampleCb+0x1c>
d0005df0:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0005df4:	f04f 0900 	mov.w	r9, #0
d0005df8:	e76f      	b.n	d0005cda <upsampleCb+0x66>
d0005dfa:	f04f 0900 	mov.w	r9, #0
d0005dfe:	e782      	b.n	d0005d06 <upsampleCb+0x92>
d0005e00:	f04f 0900 	mov.w	r9, #0
d0005e04:	e794      	b.n	d0005d30 <upsampleCb+0xbc>
d0005e06:	f04f 0800 	mov.w	r8, #0
d0005e0a:	e7a4      	b.n	d0005d56 <upsampleCb+0xe2>
d0005e0c:	2100      	movs	r1, #0
d0005e0e:	e7b8      	b.n	d0005d82 <upsampleCb+0x10e>
d0005e10:	2100      	movs	r1, #0
d0005e12:	e7c4      	b.n	d0005d9e <upsampleCb+0x12a>
d0005e14:	2200      	movs	r2, #0
d0005e16:	e7cf      	b.n	d0005db8 <upsampleCb+0x144>
d0005e18:	2300      	movs	r3, #0
d0005e1a:	e7d9      	b.n	d0005dd0 <upsampleCb+0x15c>
d0005e1c:	22ff      	movs	r2, #255	; 0xff
d0005e1e:	e7cb      	b.n	d0005db8 <upsampleCb+0x144>
d0005e20:	23ff      	movs	r3, #255	; 0xff
d0005e22:	e7d5      	b.n	d0005dd0 <upsampleCb+0x15c>
d0005e24:	21ff      	movs	r1, #255	; 0xff
d0005e26:	e7ac      	b.n	d0005d82 <upsampleCb+0x10e>
d0005e28:	21ff      	movs	r1, #255	; 0xff
d0005e2a:	e7b8      	b.n	d0005d9e <upsampleCb+0x12a>
d0005e2c:	f04f 09ff 	mov.w	r9, #255	; 0xff
d0005e30:	e77e      	b.n	d0005d30 <upsampleCb+0xbc>
d0005e32:	f04f 08ff 	mov.w	r8, #255	; 0xff
d0005e36:	e78e      	b.n	d0005d56 <upsampleCb+0xe2>
d0005e38:	f04f 09ff 	mov.w	r9, #255	; 0xff
d0005e3c:	e74d      	b.n	d0005cda <upsampleCb+0x66>
d0005e3e:	f04f 09ff 	mov.w	r9, #255	; 0xff
d0005e42:	e760      	b.n	d0005d06 <upsampleCb+0x92>
d0005e44:	d000ded4 	.word	0xd000ded4
d0005e48:	d000e4e4 	.word	0xd000e4e4
d0005e4c:	d000e3e4 	.word	0xd000e3e4

d0005e50 <upsampleCbH>:
d0005e50:	4b4d      	ldr	r3, [pc, #308]	; (d0005f88 <upsampleCbH+0x138>)
d0005e52:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
d0005e56:	eb03 0040 	add.w	r0, r3, r0, lsl #1
d0005e5a:	4e4c      	ldr	r6, [pc, #304]	; (d0005f8c <upsampleCbH+0x13c>)
d0005e5c:	4d4c      	ldr	r5, [pc, #304]	; (d0005f90 <upsampleCbH+0x140>)
d0005e5e:	440e      	add	r6, r1
d0005e60:	f100 0408 	add.w	r4, r0, #8
d0005e64:	440d      	add	r5, r1
d0005e66:	f100 0788 	add.w	r7, r0, #136	; 0x88
d0005e6a:	f1a4 0008 	sub.w	r0, r4, #8
d0005e6e:	1cb1      	adds	r1, r6, #2
d0005e70:	1caa      	adds	r2, r5, #2
d0005e72:	f930 3b02 	ldrsh.w	r3, [r0], #2
d0005e76:	f811 8c02 	ldrb.w	r8, [r1, #-2]
d0005e7a:	fa5f fc83 	uxtb.w	ip, r3
d0005e7e:	eb0c 0e8c 	add.w	lr, ip, ip, lsl #2
d0005e82:	4663      	mov	r3, ip
d0005e84:	eb0c 0e4e 	add.w	lr, ip, lr, lsl #1
d0005e88:	ea4f 1e5e 	mov.w	lr, lr, lsr #5
d0005e8c:	f1ae 0e2c 	sub.w	lr, lr, #44	; 0x2c
d0005e90:	fa1f fe8e 	uxth.w	lr, lr
d0005e94:	eba8 080e 	sub.w	r8, r8, lr
d0005e98:	fa1f f888 	uxth.w	r8, r8
d0005e9c:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0005ea0:	d907      	bls.n	d0005eb2 <upsampleCbH+0x62>
d0005ea2:	fa0f f988 	sxth.w	r9, r8
d0005ea6:	f1b9 0f00 	cmp.w	r9, #0
d0005eaa:	db57      	blt.n	d0005f5c <upsampleCbH+0x10c>
d0005eac:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d0005eb0:	dc64      	bgt.n	d0005f7c <upsampleCbH+0x12c>
d0005eb2:	fa5f f988 	uxtb.w	r9, r8
d0005eb6:	f811 8c01 	ldrb.w	r8, [r1, #-1]
d0005eba:	f801 9c02 	strb.w	r9, [r1, #-2]
d0005ebe:	eba8 0e0e 	sub.w	lr, r8, lr
d0005ec2:	fa1f fe8e 	uxth.w	lr, lr
d0005ec6:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d0005eca:	d907      	bls.n	d0005edc <upsampleCbH+0x8c>
d0005ecc:	fa0f f88e 	sxth.w	r8, lr
d0005ed0:	f1b8 0f00 	cmp.w	r8, #0
d0005ed4:	db45      	blt.n	d0005f62 <upsampleCbH+0x112>
d0005ed6:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0005eda:	dc52      	bgt.n	d0005f82 <upsampleCbH+0x132>
d0005edc:	fa5f fe8e 	uxtb.w	lr, lr
d0005ee0:	eb0c 0c4c 	add.w	ip, ip, ip, lsl #1
d0005ee4:	3be3      	subs	r3, #227	; 0xe3
d0005ee6:	f812 8c02 	ldrb.w	r8, [r2, #-2]
d0005eea:	eb0c 1c4c 	add.w	ip, ip, ip, lsl #5
d0005eee:	f801 ec01 	strb.w	lr, [r1, #-1]
d0005ef2:	eb03 13dc 	add.w	r3, r3, ip, lsr #7
d0005ef6:	b29b      	uxth	r3, r3
d0005ef8:	eb03 0c08 	add.w	ip, r3, r8
d0005efc:	fa1f fc8c 	uxth.w	ip, ip
d0005f00:	f1bc 0fff 	cmp.w	ip, #255	; 0xff
d0005f04:	d907      	bls.n	d0005f16 <upsampleCbH+0xc6>
d0005f06:	fa0f fe8c 	sxth.w	lr, ip
d0005f0a:	f1be 0f00 	cmp.w	lr, #0
d0005f0e:	db2b      	blt.n	d0005f68 <upsampleCbH+0x118>
d0005f10:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d0005f14:	dc2d      	bgt.n	d0005f72 <upsampleCbH+0x122>
d0005f16:	fa5f fc8c 	uxtb.w	ip, ip
d0005f1a:	f812 ec01 	ldrb.w	lr, [r2, #-1]
d0005f1e:	f802 cc02 	strb.w	ip, [r2, #-2]
d0005f22:	4473      	add	r3, lr
d0005f24:	b29b      	uxth	r3, r3
d0005f26:	2bff      	cmp	r3, #255	; 0xff
d0005f28:	d907      	bls.n	d0005f3a <upsampleCbH+0xea>
d0005f2a:	fa0f fc83 	sxth.w	ip, r3
d0005f2e:	f1bc 0f00 	cmp.w	ip, #0
d0005f32:	db1c      	blt.n	d0005f6e <upsampleCbH+0x11e>
d0005f34:	f1bc 0fff 	cmp.w	ip, #255	; 0xff
d0005f38:	dc1e      	bgt.n	d0005f78 <upsampleCbH+0x128>
d0005f3a:	b2db      	uxtb	r3, r3
d0005f3c:	42a0      	cmp	r0, r4
d0005f3e:	f802 3c01 	strb.w	r3, [r2, #-1]
d0005f42:	f101 0102 	add.w	r1, r1, #2
d0005f46:	f102 0202 	add.w	r2, r2, #2
d0005f4a:	d192      	bne.n	d0005e72 <upsampleCbH+0x22>
d0005f4c:	f100 0410 	add.w	r4, r0, #16
d0005f50:	3608      	adds	r6, #8
d0005f52:	3508      	adds	r5, #8
d0005f54:	42a7      	cmp	r7, r4
d0005f56:	d188      	bne.n	d0005e6a <upsampleCbH+0x1a>
d0005f58:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0005f5c:	f04f 0900 	mov.w	r9, #0
d0005f60:	e7a9      	b.n	d0005eb6 <upsampleCbH+0x66>
d0005f62:	f04f 0e00 	mov.w	lr, #0
d0005f66:	e7bb      	b.n	d0005ee0 <upsampleCbH+0x90>
d0005f68:	f04f 0c00 	mov.w	ip, #0
d0005f6c:	e7d5      	b.n	d0005f1a <upsampleCbH+0xca>
d0005f6e:	2300      	movs	r3, #0
d0005f70:	e7e4      	b.n	d0005f3c <upsampleCbH+0xec>
d0005f72:	f04f 0cff 	mov.w	ip, #255	; 0xff
d0005f76:	e7d0      	b.n	d0005f1a <upsampleCbH+0xca>
d0005f78:	23ff      	movs	r3, #255	; 0xff
d0005f7a:	e7df      	b.n	d0005f3c <upsampleCbH+0xec>
d0005f7c:	f04f 09ff 	mov.w	r9, #255	; 0xff
d0005f80:	e799      	b.n	d0005eb6 <upsampleCbH+0x66>
d0005f82:	f04f 0eff 	mov.w	lr, #255	; 0xff
d0005f86:	e7ab      	b.n	d0005ee0 <upsampleCbH+0x90>
d0005f88:	d000ded4 	.word	0xd000ded4
d0005f8c:	d000e4e4 	.word	0xd000e4e4
d0005f90:	d000e3e4 	.word	0xd000e3e4

d0005f94 <upsampleCbV>:
d0005f94:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0005f98:	4b50      	ldr	r3, [pc, #320]	; (d00060dc <upsampleCbV+0x148>)
d0005f9a:	4f51      	ldr	r7, [pc, #324]	; (d00060e0 <upsampleCbV+0x14c>)
d0005f9c:	eb03 0040 	add.w	r0, r3, r0, lsl #1
d0005fa0:	4b50      	ldr	r3, [pc, #320]	; (d00060e4 <upsampleCbV+0x150>)
d0005fa2:	440f      	add	r7, r1
d0005fa4:	f100 0610 	add.w	r6, r0, #16
d0005fa8:	eb03 0c01 	add.w	ip, r3, r1
d0005fac:	f107 0e40 	add.w	lr, r7, #64	; 0x40
d0005fb0:	f1a6 0210 	sub.w	r2, r6, #16
d0005fb4:	1e7d      	subs	r5, r7, #1
d0005fb6:	f10c 34ff 	add.w	r4, ip, #4294967295	; 0xffffffff
d0005fba:	1df8      	adds	r0, r7, #7
d0005fbc:	f10c 0107 	add.w	r1, ip, #7
d0005fc0:	e04c      	b.n	d000605c <upsampleCbV+0xc8>
d0005fc2:	f1bb 0fff 	cmp.w	fp, #255	; 0xff
d0005fc6:	f300 8081 	bgt.w	d00060cc <upsampleCbV+0x138>
d0005fca:	fa5f fa8a 	uxtb.w	sl, sl
d0005fce:	f885 a000 	strb.w	sl, [r5]
d0005fd2:	f890 a001 	ldrb.w	sl, [r0, #1]
d0005fd6:	ebaa 0909 	sub.w	r9, sl, r9
d0005fda:	fa1f f989 	uxth.w	r9, r9
d0005fde:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d0005fe2:	d907      	bls.n	d0005ff4 <upsampleCbV+0x60>
d0005fe4:	fa0f fa89 	sxth.w	sl, r9
d0005fe8:	f1ba 0f00 	cmp.w	sl, #0
d0005fec:	db68      	blt.n	d00060c0 <upsampleCbV+0x12c>
d0005fee:	f1ba 0fff 	cmp.w	sl, #255	; 0xff
d0005ff2:	dc68      	bgt.n	d00060c6 <upsampleCbV+0x132>
d0005ff4:	fa5f f989 	uxtb.w	r9, r9
d0005ff8:	eb03 0343 	add.w	r3, r3, r3, lsl #1
d0005ffc:	f1a8 0ae3 	sub.w	sl, r8, #227	; 0xe3
d0006000:	f894 8001 	ldrb.w	r8, [r4, #1]
d0006004:	eb03 1343 	add.w	r3, r3, r3, lsl #5
d0006008:	f800 9f01 	strb.w	r9, [r0, #1]!
d000600c:	eb0a 13d3 	add.w	r3, sl, r3, lsr #7
d0006010:	b29b      	uxth	r3, r3
d0006012:	4498      	add	r8, r3
d0006014:	fa1f f888 	uxth.w	r8, r8
d0006018:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d000601c:	d907      	bls.n	d000602e <upsampleCbV+0x9a>
d000601e:	fa0f f988 	sxth.w	r9, r8
d0006022:	f1b9 0f00 	cmp.w	r9, #0
d0006026:	db39      	blt.n	d000609c <upsampleCbV+0x108>
d0006028:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d000602c:	dc51      	bgt.n	d00060d2 <upsampleCbV+0x13e>
d000602e:	fa5f f888 	uxtb.w	r8, r8
d0006032:	f804 8f01 	strb.w	r8, [r4, #1]!
d0006036:	f891 8001 	ldrb.w	r8, [r1, #1]
d000603a:	4443      	add	r3, r8
d000603c:	b29b      	uxth	r3, r3
d000603e:	2bff      	cmp	r3, #255	; 0xff
d0006040:	d907      	bls.n	d0006052 <upsampleCbV+0xbe>
d0006042:	fa0f f883 	sxth.w	r8, r3
d0006046:	f1b8 0f00 	cmp.w	r8, #0
d000604a:	db2a      	blt.n	d00060a2 <upsampleCbV+0x10e>
d000604c:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0006050:	dc42      	bgt.n	d00060d8 <upsampleCbV+0x144>
d0006052:	b2db      	uxtb	r3, r3
d0006054:	42b2      	cmp	r2, r6
d0006056:	f801 3f01 	strb.w	r3, [r1, #1]!
d000605a:	d027      	beq.n	d00060ac <upsampleCbV+0x118>
d000605c:	f932 8b02 	ldrsh.w	r8, [r2], #2
d0006060:	f815 af01 	ldrb.w	sl, [r5, #1]!
d0006064:	fa5f f388 	uxtb.w	r3, r8
d0006068:	eb03 0983 	add.w	r9, r3, r3, lsl #2
d000606c:	4698      	mov	r8, r3
d000606e:	eb03 0949 	add.w	r9, r3, r9, lsl #1
d0006072:	ea4f 1959 	mov.w	r9, r9, lsr #5
d0006076:	f1a9 092c 	sub.w	r9, r9, #44	; 0x2c
d000607a:	fa1f f989 	uxth.w	r9, r9
d000607e:	ebaa 0a09 	sub.w	sl, sl, r9
d0006082:	fa1f fa8a 	uxth.w	sl, sl
d0006086:	f1ba 0fff 	cmp.w	sl, #255	; 0xff
d000608a:	d99e      	bls.n	d0005fca <upsampleCbV+0x36>
d000608c:	fa0f fb8a 	sxth.w	fp, sl
d0006090:	f1bb 0f00 	cmp.w	fp, #0
d0006094:	da95      	bge.n	d0005fc2 <upsampleCbV+0x2e>
d0006096:	f04f 0a00 	mov.w	sl, #0
d000609a:	e798      	b.n	d0005fce <upsampleCbV+0x3a>
d000609c:	f04f 0800 	mov.w	r8, #0
d00060a0:	e7c7      	b.n	d0006032 <upsampleCbV+0x9e>
d00060a2:	2300      	movs	r3, #0
d00060a4:	42b2      	cmp	r2, r6
d00060a6:	f801 3f01 	strb.w	r3, [r1, #1]!
d00060aa:	d1d7      	bne.n	d000605c <upsampleCbV+0xc8>
d00060ac:	3710      	adds	r7, #16
d00060ae:	f10c 0c10 	add.w	ip, ip, #16
d00060b2:	f102 0610 	add.w	r6, r2, #16
d00060b6:	45be      	cmp	lr, r7
d00060b8:	f47f af7a 	bne.w	d0005fb0 <upsampleCbV+0x1c>
d00060bc:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00060c0:	f04f 0900 	mov.w	r9, #0
d00060c4:	e798      	b.n	d0005ff8 <upsampleCbV+0x64>
d00060c6:	f04f 09ff 	mov.w	r9, #255	; 0xff
d00060ca:	e795      	b.n	d0005ff8 <upsampleCbV+0x64>
d00060cc:	f04f 0aff 	mov.w	sl, #255	; 0xff
d00060d0:	e77d      	b.n	d0005fce <upsampleCbV+0x3a>
d00060d2:	f04f 08ff 	mov.w	r8, #255	; 0xff
d00060d6:	e7ac      	b.n	d0006032 <upsampleCbV+0x9e>
d00060d8:	23ff      	movs	r3, #255	; 0xff
d00060da:	e7bb      	b.n	d0006054 <upsampleCbV+0xc0>
d00060dc:	d000ded4 	.word	0xd000ded4
d00060e0:	d000e4e4 	.word	0xd000e4e4
d00060e4:	d000e3e4 	.word	0xd000e3e4

d00060e8 <upsampleCr>:
d00060e8:	4b75      	ldr	r3, [pc, #468]	; (d00062c0 <upsampleCr+0x1d8>)
d00060ea:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d00060ee:	eb03 0040 	add.w	r0, r3, r0, lsl #1
d00060f2:	4f74      	ldr	r7, [pc, #464]	; (d00062c4 <upsampleCr+0x1dc>)
d00060f4:	4e74      	ldr	r6, [pc, #464]	; (d00062c8 <upsampleCr+0x1e0>)
d00060f6:	440f      	add	r7, r1
d00060f8:	f100 0508 	add.w	r5, r0, #8
d00060fc:	440e      	add	r6, r1
d00060fe:	f100 0c48 	add.w	ip, r0, #72	; 0x48
d0006102:	f1a5 0408 	sub.w	r4, r5, #8
d0006106:	1cb8      	adds	r0, r7, #2
d0006108:	1cb1      	adds	r1, r6, #2
d000610a:	f934 3b02 	ldrsh.w	r3, [r4], #2
d000610e:	f810 2c02 	ldrb.w	r2, [r0, #-2]
d0006112:	fa5f fe83 	uxtb.w	lr, r3
d0006116:	eb0e 084e 	add.w	r8, lr, lr, lsl #1
d000611a:	f1ae 03b3 	sub.w	r3, lr, #179	; 0xb3
d000611e:	eb08 1808 	add.w	r8, r8, r8, lsl #4
d0006122:	eb0e 0848 	add.w	r8, lr, r8, lsl #1
d0006126:	eb03 2318 	add.w	r3, r3, r8, lsr #8
d000612a:	b29b      	uxth	r3, r3
d000612c:	441a      	add	r2, r3
d000612e:	b292      	uxth	r2, r2
d0006130:	2aff      	cmp	r2, #255	; 0xff
d0006132:	d909      	bls.n	d0006148 <upsampleCr+0x60>
d0006134:	fa0f f882 	sxth.w	r8, r2
d0006138:	f1b8 0f00 	cmp.w	r8, #0
d000613c:	f2c0 8095 	blt.w	d000626a <upsampleCr+0x182>
d0006140:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0006144:	f300 80b5 	bgt.w	d00062b2 <upsampleCr+0x1ca>
d0006148:	fa5f f882 	uxtb.w	r8, r2
d000614c:	f810 2c01 	ldrb.w	r2, [r0, #-1]
d0006150:	f800 8c02 	strb.w	r8, [r0, #-2]
d0006154:	441a      	add	r2, r3
d0006156:	b292      	uxth	r2, r2
d0006158:	2aff      	cmp	r2, #255	; 0xff
d000615a:	d909      	bls.n	d0006170 <upsampleCr+0x88>
d000615c:	fa0f f882 	sxth.w	r8, r2
d0006160:	f1b8 0f00 	cmp.w	r8, #0
d0006164:	f2c0 8084 	blt.w	d0006270 <upsampleCr+0x188>
d0006168:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d000616c:	f300 80a4 	bgt.w	d00062b8 <upsampleCr+0x1d0>
d0006170:	fa5f f882 	uxtb.w	r8, r2
d0006174:	7982      	ldrb	r2, [r0, #6]
d0006176:	f800 8c01 	strb.w	r8, [r0, #-1]
d000617a:	441a      	add	r2, r3
d000617c:	b292      	uxth	r2, r2
d000617e:	2aff      	cmp	r2, #255	; 0xff
d0006180:	d908      	bls.n	d0006194 <upsampleCr+0xac>
d0006182:	fa0f f882 	sxth.w	r8, r2
d0006186:	f1b8 0f00 	cmp.w	r8, #0
d000618a:	db74      	blt.n	d0006276 <upsampleCr+0x18e>
d000618c:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0006190:	f300 808b 	bgt.w	d00062aa <upsampleCr+0x1c2>
d0006194:	b2d2      	uxtb	r2, r2
d0006196:	f890 8007 	ldrb.w	r8, [r0, #7]
d000619a:	7182      	strb	r2, [r0, #6]
d000619c:	eb03 0208 	add.w	r2, r3, r8
d00061a0:	b292      	uxth	r2, r2
d00061a2:	2aff      	cmp	r2, #255	; 0xff
d00061a4:	d904      	bls.n	d00061b0 <upsampleCr+0xc8>
d00061a6:	b213      	sxth	r3, r2
d00061a8:	2b00      	cmp	r3, #0
d00061aa:	db66      	blt.n	d000627a <upsampleCr+0x192>
d00061ac:	2bff      	cmp	r3, #255	; 0xff
d00061ae:	dc7e      	bgt.n	d00062ae <upsampleCr+0x1c6>
d00061b0:	b2d2      	uxtb	r2, r2
d00061b2:	ebce 130e 	rsb	r3, lr, lr, lsl #4
d00061b6:	f811 8c02 	ldrb.w	r8, [r1, #-2]
d00061ba:	71c2      	strb	r2, [r0, #7]
d00061bc:	eb0e 0383 	add.w	r3, lr, r3, lsl #2
d00061c0:	ebc3 0383 	rsb	r3, r3, r3, lsl #2
d00061c4:	0a1b      	lsrs	r3, r3, #8
d00061c6:	3b5b      	subs	r3, #91	; 0x5b
d00061c8:	b29b      	uxth	r3, r3
d00061ca:	eba8 0803 	sub.w	r8, r8, r3
d00061ce:	fa1f f888 	uxth.w	r8, r8
d00061d2:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d00061d6:	d905      	bls.n	d00061e4 <upsampleCr+0xfc>
d00061d8:	fa0f f288 	sxth.w	r2, r8
d00061dc:	2a00      	cmp	r2, #0
d00061de:	db4e      	blt.n	d000627e <upsampleCr+0x196>
d00061e0:	2aff      	cmp	r2, #255	; 0xff
d00061e2:	dc5c      	bgt.n	d000629e <upsampleCr+0x1b6>
d00061e4:	fa5f f888 	uxtb.w	r8, r8
d00061e8:	f811 2c01 	ldrb.w	r2, [r1, #-1]
d00061ec:	f801 8c02 	strb.w	r8, [r1, #-2]
d00061f0:	1ad2      	subs	r2, r2, r3
d00061f2:	b292      	uxth	r2, r2
d00061f4:	2aff      	cmp	r2, #255	; 0xff
d00061f6:	d907      	bls.n	d0006208 <upsampleCr+0x120>
d00061f8:	fa0f fe82 	sxth.w	lr, r2
d00061fc:	f1be 0f00 	cmp.w	lr, #0
d0006200:	db40      	blt.n	d0006284 <upsampleCr+0x19c>
d0006202:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d0006206:	dc4d      	bgt.n	d00062a4 <upsampleCr+0x1bc>
d0006208:	fa5f fe82 	uxtb.w	lr, r2
d000620c:	798a      	ldrb	r2, [r1, #6]
d000620e:	f801 ec01 	strb.w	lr, [r1, #-1]
d0006212:	1ad2      	subs	r2, r2, r3
d0006214:	b292      	uxth	r2, r2
d0006216:	2aff      	cmp	r2, #255	; 0xff
d0006218:	d907      	bls.n	d000622a <upsampleCr+0x142>
d000621a:	fa0f fe82 	sxth.w	lr, r2
d000621e:	f1be 0f00 	cmp.w	lr, #0
d0006222:	db32      	blt.n	d000628a <upsampleCr+0x1a2>
d0006224:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d0006228:	dc34      	bgt.n	d0006294 <upsampleCr+0x1ac>
d000622a:	fa5f fe82 	uxtb.w	lr, r2
d000622e:	79ca      	ldrb	r2, [r1, #7]
d0006230:	f881 e006 	strb.w	lr, [r1, #6]
d0006234:	1ad3      	subs	r3, r2, r3
d0006236:	b29b      	uxth	r3, r3
d0006238:	2bff      	cmp	r3, #255	; 0xff
d000623a:	d904      	bls.n	d0006246 <upsampleCr+0x15e>
d000623c:	b21a      	sxth	r2, r3
d000623e:	2a00      	cmp	r2, #0
d0006240:	db26      	blt.n	d0006290 <upsampleCr+0x1a8>
d0006242:	2aff      	cmp	r2, #255	; 0xff
d0006244:	dc29      	bgt.n	d000629a <upsampleCr+0x1b2>
d0006246:	b2db      	uxtb	r3, r3
d0006248:	42ac      	cmp	r4, r5
d000624a:	71cb      	strb	r3, [r1, #7]
d000624c:	f100 0002 	add.w	r0, r0, #2
d0006250:	f101 0102 	add.w	r1, r1, #2
d0006254:	f47f af59 	bne.w	d000610a <upsampleCr+0x22>
d0006258:	f104 0510 	add.w	r5, r4, #16
d000625c:	3710      	adds	r7, #16
d000625e:	3610      	adds	r6, #16
d0006260:	4565      	cmp	r5, ip
d0006262:	f47f af4e 	bne.w	d0006102 <upsampleCr+0x1a>
d0006266:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d000626a:	f04f 0800 	mov.w	r8, #0
d000626e:	e76d      	b.n	d000614c <upsampleCr+0x64>
d0006270:	f04f 0800 	mov.w	r8, #0
d0006274:	e77e      	b.n	d0006174 <upsampleCr+0x8c>
d0006276:	2200      	movs	r2, #0
d0006278:	e78d      	b.n	d0006196 <upsampleCr+0xae>
d000627a:	2200      	movs	r2, #0
d000627c:	e799      	b.n	d00061b2 <upsampleCr+0xca>
d000627e:	f04f 0800 	mov.w	r8, #0
d0006282:	e7b1      	b.n	d00061e8 <upsampleCr+0x100>
d0006284:	f04f 0e00 	mov.w	lr, #0
d0006288:	e7c0      	b.n	d000620c <upsampleCr+0x124>
d000628a:	f04f 0e00 	mov.w	lr, #0
d000628e:	e7ce      	b.n	d000622e <upsampleCr+0x146>
d0006290:	2300      	movs	r3, #0
d0006292:	e7d9      	b.n	d0006248 <upsampleCr+0x160>
d0006294:	f04f 0eff 	mov.w	lr, #255	; 0xff
d0006298:	e7c9      	b.n	d000622e <upsampleCr+0x146>
d000629a:	23ff      	movs	r3, #255	; 0xff
d000629c:	e7d4      	b.n	d0006248 <upsampleCr+0x160>
d000629e:	f04f 08ff 	mov.w	r8, #255	; 0xff
d00062a2:	e7a1      	b.n	d00061e8 <upsampleCr+0x100>
d00062a4:	f04f 0eff 	mov.w	lr, #255	; 0xff
d00062a8:	e7b0      	b.n	d000620c <upsampleCr+0x124>
d00062aa:	22ff      	movs	r2, #255	; 0xff
d00062ac:	e773      	b.n	d0006196 <upsampleCr+0xae>
d00062ae:	22ff      	movs	r2, #255	; 0xff
d00062b0:	e77f      	b.n	d00061b2 <upsampleCr+0xca>
d00062b2:	f04f 08ff 	mov.w	r8, #255	; 0xff
d00062b6:	e749      	b.n	d000614c <upsampleCr+0x64>
d00062b8:	f04f 08ff 	mov.w	r8, #255	; 0xff
d00062bc:	e75a      	b.n	d0006174 <upsampleCr+0x8c>
d00062be:	bf00      	nop
d00062c0:	d000ded4 	.word	0xd000ded4
d00062c4:	d000e5e4 	.word	0xd000e5e4
d00062c8:	d000e4e4 	.word	0xd000e4e4

d00062cc <upsampleCrH>:
d00062cc:	4b47      	ldr	r3, [pc, #284]	; (d00063ec <upsampleCrH+0x120>)
d00062ce:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d00062d2:	eb03 0040 	add.w	r0, r3, r0, lsl #1
d00062d6:	4f46      	ldr	r7, [pc, #280]	; (d00063f0 <upsampleCrH+0x124>)
d00062d8:	4e46      	ldr	r6, [pc, #280]	; (d00063f4 <upsampleCrH+0x128>)
d00062da:	440f      	add	r7, r1
d00062dc:	f100 0508 	add.w	r5, r0, #8
d00062e0:	440e      	add	r6, r1
d00062e2:	f100 0c88 	add.w	ip, r0, #136	; 0x88
d00062e6:	f1a5 0408 	sub.w	r4, r5, #8
d00062ea:	1cb8      	adds	r0, r7, #2
d00062ec:	1cb1      	adds	r1, r6, #2
d00062ee:	f934 2b02 	ldrsh.w	r2, [r4], #2
d00062f2:	f810 ec02 	ldrb.w	lr, [r0, #-2]
d00062f6:	b2d3      	uxtb	r3, r2
d00062f8:	eb03 0843 	add.w	r8, r3, r3, lsl #1
d00062fc:	f1a3 02b3 	sub.w	r2, r3, #179	; 0xb3
d0006300:	eb08 1808 	add.w	r8, r8, r8, lsl #4
d0006304:	eb03 0848 	add.w	r8, r3, r8, lsl #1
d0006308:	eb02 2218 	add.w	r2, r2, r8, lsr #8
d000630c:	b292      	uxth	r2, r2
d000630e:	4496      	add	lr, r2
d0006310:	fa1f fe8e 	uxth.w	lr, lr
d0006314:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d0006318:	d907      	bls.n	d000632a <upsampleCrH+0x5e>
d000631a:	fa0f f88e 	sxth.w	r8, lr
d000631e:	f1b8 0f00 	cmp.w	r8, #0
d0006322:	db4f      	blt.n	d00063c4 <upsampleCrH+0xf8>
d0006324:	f1b8 0fff 	cmp.w	r8, #255	; 0xff
d0006328:	dc5b      	bgt.n	d00063e2 <upsampleCrH+0x116>
d000632a:	fa5f fe8e 	uxtb.w	lr, lr
d000632e:	f810 8c01 	ldrb.w	r8, [r0, #-1]
d0006332:	f800 ec02 	strb.w	lr, [r0, #-2]
d0006336:	4442      	add	r2, r8
d0006338:	b292      	uxth	r2, r2
d000633a:	2aff      	cmp	r2, #255	; 0xff
d000633c:	d907      	bls.n	d000634e <upsampleCrH+0x82>
d000633e:	fa0f fe82 	sxth.w	lr, r2
d0006342:	f1be 0f00 	cmp.w	lr, #0
d0006346:	db40      	blt.n	d00063ca <upsampleCrH+0xfe>
d0006348:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d000634c:	dc4c      	bgt.n	d00063e8 <upsampleCrH+0x11c>
d000634e:	b2d2      	uxtb	r2, r2
d0006350:	ebc3 1803 	rsb	r8, r3, r3, lsl #4
d0006354:	f811 ec02 	ldrb.w	lr, [r1, #-2]
d0006358:	f800 2c01 	strb.w	r2, [r0, #-1]
d000635c:	eb03 0388 	add.w	r3, r3, r8, lsl #2
d0006360:	ebc3 0383 	rsb	r3, r3, r3, lsl #2
d0006364:	0a1b      	lsrs	r3, r3, #8
d0006366:	3b5b      	subs	r3, #91	; 0x5b
d0006368:	b29b      	uxth	r3, r3
d000636a:	ebae 0e03 	sub.w	lr, lr, r3
d000636e:	fa1f fe8e 	uxth.w	lr, lr
d0006372:	f1be 0fff 	cmp.w	lr, #255	; 0xff
d0006376:	d905      	bls.n	d0006384 <upsampleCrH+0xb8>
d0006378:	fa0f f28e 	sxth.w	r2, lr
d000637c:	2a00      	cmp	r2, #0
d000637e:	db26      	blt.n	d00063ce <upsampleCrH+0x102>
d0006380:	2aff      	cmp	r2, #255	; 0xff
d0006382:	dc29      	bgt.n	d00063d8 <upsampleCrH+0x10c>
d0006384:	fa5f fe8e 	uxtb.w	lr, lr
d0006388:	f811 2c01 	ldrb.w	r2, [r1, #-1]
d000638c:	f801 ec02 	strb.w	lr, [r1, #-2]
d0006390:	1ad3      	subs	r3, r2, r3
d0006392:	b29b      	uxth	r3, r3
d0006394:	2bff      	cmp	r3, #255	; 0xff
d0006396:	d904      	bls.n	d00063a2 <upsampleCrH+0xd6>
d0006398:	b21a      	sxth	r2, r3
d000639a:	2a00      	cmp	r2, #0
d000639c:	db1a      	blt.n	d00063d4 <upsampleCrH+0x108>
d000639e:	2aff      	cmp	r2, #255	; 0xff
d00063a0:	dc1d      	bgt.n	d00063de <upsampleCrH+0x112>
d00063a2:	b2db      	uxtb	r3, r3
d00063a4:	42ac      	cmp	r4, r5
d00063a6:	f801 3c01 	strb.w	r3, [r1, #-1]
d00063aa:	f100 0002 	add.w	r0, r0, #2
d00063ae:	f101 0102 	add.w	r1, r1, #2
d00063b2:	d19c      	bne.n	d00062ee <upsampleCrH+0x22>
d00063b4:	f104 0510 	add.w	r5, r4, #16
d00063b8:	3708      	adds	r7, #8
d00063ba:	3608      	adds	r6, #8
d00063bc:	45ac      	cmp	ip, r5
d00063be:	d192      	bne.n	d00062e6 <upsampleCrH+0x1a>
d00063c0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d00063c4:	f04f 0e00 	mov.w	lr, #0
d00063c8:	e7b1      	b.n	d000632e <upsampleCrH+0x62>
d00063ca:	2200      	movs	r2, #0
d00063cc:	e7c0      	b.n	d0006350 <upsampleCrH+0x84>
d00063ce:	f04f 0e00 	mov.w	lr, #0
d00063d2:	e7d9      	b.n	d0006388 <upsampleCrH+0xbc>
d00063d4:	2300      	movs	r3, #0
d00063d6:	e7e5      	b.n	d00063a4 <upsampleCrH+0xd8>
d00063d8:	f04f 0eff 	mov.w	lr, #255	; 0xff
d00063dc:	e7d4      	b.n	d0006388 <upsampleCrH+0xbc>
d00063de:	23ff      	movs	r3, #255	; 0xff
d00063e0:	e7e0      	b.n	d00063a4 <upsampleCrH+0xd8>
d00063e2:	f04f 0eff 	mov.w	lr, #255	; 0xff
d00063e6:	e7a2      	b.n	d000632e <upsampleCrH+0x62>
d00063e8:	22ff      	movs	r2, #255	; 0xff
d00063ea:	e7b1      	b.n	d0006350 <upsampleCrH+0x84>
d00063ec:	d000ded4 	.word	0xd000ded4
d00063f0:	d000e5e4 	.word	0xd000e5e4
d00063f4:	d000e4e4 	.word	0xd000e4e4

d00063f8 <upsampleCrV>:
d00063f8:	4b4c      	ldr	r3, [pc, #304]	; (d000652c <upsampleCrV+0x134>)
d00063fa:	4a4d      	ldr	r2, [pc, #308]	; (d0006530 <upsampleCrV+0x138>)
d00063fc:	eb03 0040 	add.w	r0, r3, r0, lsl #1
d0006400:	4b4c      	ldr	r3, [pc, #304]	; (d0006534 <upsampleCrV+0x13c>)
d0006402:	eb02 0c01 	add.w	ip, r2, r1
d0006406:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d000640a:	f100 0710 	add.w	r7, r0, #16
d000640e:	eb03 0e01 	add.w	lr, r3, r1
d0006412:	f10c 0840 	add.w	r8, ip, #64	; 0x40
d0006416:	f1a7 0110 	sub.w	r1, r7, #16
d000641a:	f10c 36ff 	add.w	r6, ip, #4294967295	; 0xffffffff
d000641e:	f10e 35ff 	add.w	r5, lr, #4294967295	; 0xffffffff
d0006422:	f10c 0407 	add.w	r4, ip, #7
d0006426:	f10e 0007 	add.w	r0, lr, #7
d000642a:	e042      	b.n	d00064b2 <upsampleCrV+0xba>
d000642c:	f1ba 0fff 	cmp.w	sl, #255	; 0xff
d0006430:	dc73      	bgt.n	d000651a <upsampleCrV+0x122>
d0006432:	fa5f f989 	uxtb.w	r9, r9
d0006436:	f886 9000 	strb.w	r9, [r6]
d000643a:	f894 9001 	ldrb.w	r9, [r4, #1]
d000643e:	444a      	add	r2, r9
d0006440:	b292      	uxth	r2, r2
d0006442:	2aff      	cmp	r2, #255	; 0xff
d0006444:	d907      	bls.n	d0006456 <upsampleCrV+0x5e>
d0006446:	fa0f f982 	sxth.w	r9, r2
d000644a:	f1b9 0f00 	cmp.w	r9, #0
d000644e:	db60      	blt.n	d0006512 <upsampleCrV+0x11a>
d0006450:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d0006454:	dc5f      	bgt.n	d0006516 <upsampleCrV+0x11e>
d0006456:	b2d2      	uxtb	r2, r2
d0006458:	ebc3 1a03 	rsb	sl, r3, r3, lsl #4
d000645c:	f895 9001 	ldrb.w	r9, [r5, #1]
d0006460:	f804 2f01 	strb.w	r2, [r4, #1]!
d0006464:	eb03 038a 	add.w	r3, r3, sl, lsl #2
d0006468:	ebc3 0383 	rsb	r3, r3, r3, lsl #2
d000646c:	0a1b      	lsrs	r3, r3, #8
d000646e:	3b5b      	subs	r3, #91	; 0x5b
d0006470:	b29b      	uxth	r3, r3
d0006472:	eba9 0903 	sub.w	r9, r9, r3
d0006476:	fa1f f989 	uxth.w	r9, r9
d000647a:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d000647e:	d905      	bls.n	d000648c <upsampleCrV+0x94>
d0006480:	fa0f f289 	sxth.w	r2, r9
d0006484:	2a00      	cmp	r2, #0
d0006486:	db32      	blt.n	d00064ee <upsampleCrV+0xf6>
d0006488:	2aff      	cmp	r2, #255	; 0xff
d000648a:	dc49      	bgt.n	d0006520 <upsampleCrV+0x128>
d000648c:	fa5f f989 	uxtb.w	r9, r9
d0006490:	f805 9f01 	strb.w	r9, [r5, #1]!
d0006494:	7842      	ldrb	r2, [r0, #1]
d0006496:	1ad3      	subs	r3, r2, r3
d0006498:	b29b      	uxth	r3, r3
d000649a:	2bff      	cmp	r3, #255	; 0xff
d000649c:	d904      	bls.n	d00064a8 <upsampleCrV+0xb0>
d000649e:	b21a      	sxth	r2, r3
d00064a0:	2a00      	cmp	r2, #0
d00064a2:	db27      	blt.n	d00064f4 <upsampleCrV+0xfc>
d00064a4:	2aff      	cmp	r2, #255	; 0xff
d00064a6:	dc3e      	bgt.n	d0006526 <upsampleCrV+0x12e>
d00064a8:	b2db      	uxtb	r3, r3
d00064aa:	42b9      	cmp	r1, r7
d00064ac:	f800 3f01 	strb.w	r3, [r0, #1]!
d00064b0:	d025      	beq.n	d00064fe <upsampleCrV+0x106>
d00064b2:	f931 2b02 	ldrsh.w	r2, [r1], #2
d00064b6:	f816 9f01 	ldrb.w	r9, [r6, #1]!
d00064ba:	b2d3      	uxtb	r3, r2
d00064bc:	eb03 0a43 	add.w	sl, r3, r3, lsl #1
d00064c0:	f1a3 02b3 	sub.w	r2, r3, #179	; 0xb3
d00064c4:	eb0a 1a0a 	add.w	sl, sl, sl, lsl #4
d00064c8:	eb03 0a4a 	add.w	sl, r3, sl, lsl #1
d00064cc:	eb02 221a 	add.w	r2, r2, sl, lsr #8
d00064d0:	b292      	uxth	r2, r2
d00064d2:	4491      	add	r9, r2
d00064d4:	fa1f f989 	uxth.w	r9, r9
d00064d8:	f1b9 0fff 	cmp.w	r9, #255	; 0xff
d00064dc:	d9a9      	bls.n	d0006432 <upsampleCrV+0x3a>
d00064de:	fa0f fa89 	sxth.w	sl, r9
d00064e2:	f1ba 0f00 	cmp.w	sl, #0
d00064e6:	daa1      	bge.n	d000642c <upsampleCrV+0x34>
d00064e8:	f04f 0900 	mov.w	r9, #0
d00064ec:	e7a3      	b.n	d0006436 <upsampleCrV+0x3e>
d00064ee:	f04f 0900 	mov.w	r9, #0
d00064f2:	e7cd      	b.n	d0006490 <upsampleCrV+0x98>
d00064f4:	2300      	movs	r3, #0
d00064f6:	42b9      	cmp	r1, r7
d00064f8:	f800 3f01 	strb.w	r3, [r0, #1]!
d00064fc:	d1d9      	bne.n	d00064b2 <upsampleCrV+0xba>
d00064fe:	f10c 0c10 	add.w	ip, ip, #16
d0006502:	f10e 0e10 	add.w	lr, lr, #16
d0006506:	f101 0710 	add.w	r7, r1, #16
d000650a:	45c4      	cmp	ip, r8
d000650c:	d183      	bne.n	d0006416 <upsampleCrV+0x1e>
d000650e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d0006512:	2200      	movs	r2, #0
d0006514:	e7a0      	b.n	d0006458 <upsampleCrV+0x60>
d0006516:	22ff      	movs	r2, #255	; 0xff
d0006518:	e79e      	b.n	d0006458 <upsampleCrV+0x60>
d000651a:	f04f 09ff 	mov.w	r9, #255	; 0xff
d000651e:	e78a      	b.n	d0006436 <upsampleCrV+0x3e>
d0006520:	f04f 09ff 	mov.w	r9, #255	; 0xff
d0006524:	e7b4      	b.n	d0006490 <upsampleCrV+0x98>
d0006526:	23ff      	movs	r3, #255	; 0xff
d0006528:	e7bf      	b.n	d00064aa <upsampleCrV+0xb2>
d000652a:	bf00      	nop
d000652c:	d000ded4 	.word	0xd000ded4
d0006530:	d000e5e4 	.word	0xd000e5e4
d0006534:	d000e4e4 	.word	0xd000e4e4

d0006538 <getChar>:
d0006538:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000653a:	4c14      	ldr	r4, [pc, #80]	; (d000658c <getChar+0x54>)
d000653c:	7823      	ldrb	r3, [r4, #0]
d000653e:	b143      	cbz	r3, d0006552 <getChar+0x1a>
d0006540:	4d13      	ldr	r5, [pc, #76]	; (d0006590 <getChar+0x58>)
d0006542:	782a      	ldrb	r2, [r5, #0]
d0006544:	3b01      	subs	r3, #1
d0006546:	4813      	ldr	r0, [pc, #76]	; (d0006594 <getChar+0x5c>)
d0006548:	1c51      	adds	r1, r2, #1
d000654a:	7023      	strb	r3, [r4, #0]
d000654c:	5c80      	ldrb	r0, [r0, r2]
d000654e:	7029      	strb	r1, [r5, #0]
d0006550:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0006552:	4e11      	ldr	r6, [pc, #68]	; (d0006598 <getChar+0x60>)
d0006554:	2704      	movs	r7, #4
d0006556:	4811      	ldr	r0, [pc, #68]	; (d000659c <getChar+0x64>)
d0006558:	4622      	mov	r2, r4
d000655a:	4d0d      	ldr	r5, [pc, #52]	; (d0006590 <getChar+0x58>)
d000655c:	21fc      	movs	r1, #252	; 0xfc
d000655e:	7023      	strb	r3, [r4, #0]
d0006560:	6833      	ldr	r3, [r6, #0]
d0006562:	6806      	ldr	r6, [r0, #0]
d0006564:	480e      	ldr	r0, [pc, #56]	; (d00065a0 <getChar+0x68>)
d0006566:	702f      	strb	r7, [r5, #0]
d0006568:	47b0      	blx	r6
d000656a:	b108      	cbz	r0, d0006570 <getChar+0x38>
d000656c:	4b0d      	ldr	r3, [pc, #52]	; (d00065a4 <getChar+0x6c>)
d000656e:	7018      	strb	r0, [r3, #0]
d0006570:	7823      	ldrb	r3, [r4, #0]
d0006572:	2b00      	cmp	r3, #0
d0006574:	d1e5      	bne.n	d0006542 <getChar+0xa>
d0006576:	4a0c      	ldr	r2, [pc, #48]	; (d00065a8 <getChar+0x70>)
d0006578:	7813      	ldrb	r3, [r2, #0]
d000657a:	43db      	mvns	r3, r3
d000657c:	b2db      	uxtb	r3, r3
d000657e:	2b00      	cmp	r3, #0
d0006580:	7013      	strb	r3, [r2, #0]
d0006582:	bf14      	ite	ne
d0006584:	20ff      	movne	r0, #255	; 0xff
d0006586:	20d9      	moveq	r0, #217	; 0xd9
d0006588:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d000658a:	bf00      	nop
d000658c:	d000e3d8 	.word	0xd000e3d8
d0006590:	d000e3d9 	.word	0xd000e3d9
d0006594:	d000e2d8 	.word	0xd000e2d8
d0006598:	d000e804 	.word	0xd000e804
d000659c:	d000e808 	.word	0xd000e808
d00065a0:	d000e2dc 	.word	0xd000e2dc
d00065a4:	d000ded3 	.word	0xd000ded3
d00065a8:	d000e7ff 	.word	0xd000e7ff

d00065ac <getBits.constprop.1>:
d00065ac:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d00065b0:	f8df 8088 	ldr.w	r8, [pc, #136]	; d000663c <getBits.constprop.1+0x90>
d00065b4:	4c1f      	ldr	r4, [pc, #124]	; (d0006634 <getBits.constprop.1+0x88>)
d00065b6:	f898 3000 	ldrb.w	r3, [r8]
d00065ba:	8827      	ldrh	r7, [r4, #0]
d00065bc:	2b07      	cmp	r3, #7
d00065be:	d907      	bls.n	d00065d0 <getBits.constprop.1+0x24>
d00065c0:	3b08      	subs	r3, #8
d00065c2:	023a      	lsls	r2, r7, #8
d00065c4:	0a38      	lsrs	r0, r7, #8
d00065c6:	f888 3000 	strb.w	r3, [r8]
d00065ca:	8022      	strh	r2, [r4, #0]
d00065cc:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d00065d0:	fa07 f303 	lsl.w	r3, r7, r3
d00065d4:	4606      	mov	r6, r0
d00065d6:	8023      	strh	r3, [r4, #0]
d00065d8:	f7ff ffae 	bl	d0006538 <getChar>
d00065dc:	28ff      	cmp	r0, #255	; 0xff
d00065de:	4605      	mov	r5, r0
d00065e0:	d101      	bne.n	d00065e6 <getBits.constprop.1+0x3a>
d00065e2:	07f3      	lsls	r3, r6, #31
d00065e4:	d40b      	bmi.n	d00065fe <getBits.constprop.1+0x52>
d00065e6:	8820      	ldrh	r0, [r4, #0]
d00065e8:	f898 3000 	ldrb.w	r3, [r8]
d00065ec:	4305      	orrs	r5, r0
d00065ee:	0a38      	lsrs	r0, r7, #8
d00065f0:	f1c3 0308 	rsb	r3, r3, #8
d00065f4:	b2ad      	uxth	r5, r5
d00065f6:	409d      	lsls	r5, r3
d00065f8:	8025      	strh	r5, [r4, #0]
d00065fa:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d00065fe:	f7ff ff9b 	bl	d0006538 <getChar>
d0006602:	2800      	cmp	r0, #0
d0006604:	d0ef      	beq.n	d00065e6 <getBits.constprop.1+0x3a>
d0006606:	f8df c038 	ldr.w	ip, [pc, #56]	; d0006640 <getBits.constprop.1+0x94>
d000660a:	f04f 0eff 	mov.w	lr, #255	; 0xff
d000660e:	4e0a      	ldr	r6, [pc, #40]	; (d0006638 <getBits.constprop.1+0x8c>)
d0006610:	f89c 3000 	ldrb.w	r3, [ip]
d0006614:	7831      	ldrb	r1, [r6, #0]
d0006616:	1e9a      	subs	r2, r3, #2
d0006618:	3b01      	subs	r3, #1
d000661a:	3102      	adds	r1, #2
d000661c:	b2d2      	uxtb	r2, r2
d000661e:	b2db      	uxtb	r3, r3
d0006620:	7031      	strb	r1, [r6, #0]
d0006622:	f88c 2000 	strb.w	r2, [ip]
d0006626:	f8df c01c 	ldr.w	ip, [pc, #28]	; d0006644 <getBits.constprop.1+0x98>
d000662a:	f80c 0003 	strb.w	r0, [ip, r3]
d000662e:	f80c e002 	strb.w	lr, [ip, r2]
d0006632:	e7d8      	b.n	d00065e6 <getBits.constprop.1+0x3a>
d0006634:	d000ded0 	.word	0xd000ded0
d0006638:	d000e3d8 	.word	0xd000e3d8
d000663c:	d000ded2 	.word	0xd000ded2
d0006640:	d000e3d9 	.word	0xd000e3d9
d0006644:	d000e2d8 	.word	0xd000e2d8

d0006648 <getBits.constprop.0>:
d0006648:	b570      	push	{r4, r5, r6, lr}
d000664a:	4c17      	ldr	r4, [pc, #92]	; (d00066a8 <getBits.constprop.0+0x60>)
d000664c:	4d17      	ldr	r5, [pc, #92]	; (d00066ac <getBits.constprop.0+0x64>)
d000664e:	8826      	ldrh	r6, [r4, #0]
d0006650:	782b      	ldrb	r3, [r5, #0]
d0006652:	fa06 f303 	lsl.w	r3, r6, r3
d0006656:	f026 06ff 	bic.w	r6, r6, #255	; 0xff
d000665a:	8023      	strh	r3, [r4, #0]
d000665c:	f7ff ff6c 	bl	d0006538 <getChar>
d0006660:	8823      	ldrh	r3, [r4, #0]
d0006662:	782a      	ldrb	r2, [r5, #0]
d0006664:	4303      	orrs	r3, r0
d0006666:	f1c2 0008 	rsb	r0, r2, #8
d000666a:	2a07      	cmp	r2, #7
d000666c:	b29b      	uxth	r3, r3
d000666e:	fa03 f300 	lsl.w	r3, r3, r0
d0006672:	f3c3 2107 	ubfx	r1, r3, #8, #8
d0006676:	ea46 0601 	orr.w	r6, r6, r1
d000667a:	d905      	bls.n	d0006688 <getBits.constprop.0+0x40>
d000667c:	3a08      	subs	r2, #8
d000667e:	021b      	lsls	r3, r3, #8
d0006680:	4630      	mov	r0, r6
d0006682:	702a      	strb	r2, [r5, #0]
d0006684:	8023      	strh	r3, [r4, #0]
d0006686:	bd70      	pop	{r4, r5, r6, pc}
d0006688:	b29b      	uxth	r3, r3
d000668a:	4093      	lsls	r3, r2
d000668c:	8023      	strh	r3, [r4, #0]
d000668e:	f7ff ff53 	bl	d0006538 <getChar>
d0006692:	8822      	ldrh	r2, [r4, #0]
d0006694:	782b      	ldrb	r3, [r5, #0]
d0006696:	4310      	orrs	r0, r2
d0006698:	f1c3 0308 	rsb	r3, r3, #8
d000669c:	b280      	uxth	r0, r0
d000669e:	4098      	lsls	r0, r3
d00066a0:	8020      	strh	r0, [r4, #0]
d00066a2:	4630      	mov	r0, r6
d00066a4:	bd70      	pop	{r4, r5, r6, pc}
d00066a6:	bf00      	nop
d00066a8:	d000ded0 	.word	0xd000ded0
d00066ac:	d000ded2 	.word	0xd000ded2

d00066b0 <processMarkers>:
d00066b0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00066b4:	f8df 91f0 	ldr.w	r9, [pc, #496]	; d00068a8 <processMarkers+0x1f8>
d00066b8:	b089      	sub	sp, #36	; 0x24
d00066ba:	f8df b1f0 	ldr.w	fp, [pc, #496]	; d00068ac <processMarkers+0x1fc>
d00066be:	f8df a1f0 	ldr.w	sl, [pc, #496]	; d00068b0 <processMarkers+0x200>
d00066c2:	9003      	str	r0, [sp, #12]
d00066c4:	f8b9 0000 	ldrh.w	r0, [r9]
d00066c8:	f89b 2000 	ldrb.w	r2, [fp]
d00066cc:	2a07      	cmp	r2, #7
d00066ce:	d96b      	bls.n	d00067a8 <processMarkers+0xf8>
d00066d0:	1203      	asrs	r3, r0, #8
d00066d2:	3a08      	subs	r2, #8
d00066d4:	0201      	lsls	r1, r0, #8
d00066d6:	b2d2      	uxtb	r2, r2
d00066d8:	2bff      	cmp	r3, #255	; 0xff
d00066da:	b288      	uxth	r0, r1
d00066dc:	f88b 2000 	strb.w	r2, [fp]
d00066e0:	d1f4      	bne.n	d00066cc <processMarkers+0x1c>
d00066e2:	2a07      	cmp	r2, #7
d00066e4:	f1a2 0408 	sub.w	r4, r2, #8
d00066e8:	ea4f 2100 	mov.w	r1, r0, lsl #8
d00066ec:	ea4f 2320 	mov.w	r3, r0, asr #8
d00066f0:	d93f      	bls.n	d0006772 <processMarkers+0xc2>
d00066f2:	b2e2      	uxtb	r2, r4
d00066f4:	2bff      	cmp	r3, #255	; 0xff
d00066f6:	b288      	uxth	r0, r1
d00066f8:	f88b 2000 	strb.w	r2, [fp]
d00066fc:	f8a9 0000 	strh.w	r0, [r9]
d0006700:	d0ef      	beq.n	d00066e2 <processMarkers+0x32>
d0006702:	b2d9      	uxtb	r1, r3
d0006704:	2b00      	cmp	r3, #0
d0006706:	d0e1      	beq.n	d00066cc <processMarkers+0x1c>
d0006708:	2901      	cmp	r1, #1
d000670a:	d02e      	beq.n	d000676a <processMarkers+0xba>
d000670c:	f101 0340 	add.w	r3, r1, #64	; 0x40
d0006710:	b2db      	uxtb	r3, r3
d0006712:	2b1d      	cmp	r3, #29
d0006714:	f200 822d 	bhi.w	d0006b72 <processMarkers+0x4c2>
d0006718:	f1a1 03c0 	sub.w	r3, r1, #192	; 0xc0
d000671c:	2b1d      	cmp	r3, #29
d000671e:	f200 8228 	bhi.w	d0006b72 <processMarkers+0x4c2>
d0006722:	e8df f013 	tbh	[pc, r3, lsl #1]
d0006726:	0220      	.short	0x0220
d0006728:	02200220 	.word	0x02200220
d000672c:	00c70220 	.word	0x00c70220
d0006730:	02200220 	.word	0x02200220
d0006734:	00220220 	.word	0x00220220
d0006738:	02200220 	.word	0x02200220
d000673c:	001e0220 	.word	0x001e0220
d0006740:	02200220 	.word	0x02200220
d0006744:	00220220 	.word	0x00220220
d0006748:	00220022 	.word	0x00220022
d000674c:	00220022 	.word	0x00220022
d0006750:	00220022 	.word	0x00220022
d0006754:	02200022 	.word	0x02200022
d0006758:	02200220 	.word	0x02200220
d000675c:	02260062 	.word	0x02260062
d0006760:	0058      	.short	0x0058
d0006762:	2011      	movs	r0, #17
d0006764:	b009      	add	sp, #36	; 0x24
d0006766:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000676a:	2012      	movs	r0, #18
d000676c:	b009      	add	sp, #36	; 0x24
d000676e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0006772:	fa00 f202 	lsl.w	r2, r0, r2
d0006776:	4604      	mov	r4, r0
d0006778:	f8a9 2000 	strh.w	r2, [r9]
d000677c:	f7ff fedc 	bl	d0006538 <getChar>
d0006780:	f8b9 1000 	ldrh.w	r1, [r9]
d0006784:	1223      	asrs	r3, r4, #8
d0006786:	f89b 2000 	ldrb.w	r2, [fp]
d000678a:	4308      	orrs	r0, r1
d000678c:	2bff      	cmp	r3, #255	; 0xff
d000678e:	f1c2 0108 	rsb	r1, r2, #8
d0006792:	b280      	uxth	r0, r0
d0006794:	fa00 f001 	lsl.w	r0, r0, r1
d0006798:	b280      	uxth	r0, r0
d000679a:	f8a9 0000 	strh.w	r0, [r9]
d000679e:	d0a0      	beq.n	d00066e2 <processMarkers+0x32>
d00067a0:	b2d9      	uxtb	r1, r3
d00067a2:	2b00      	cmp	r3, #0
d00067a4:	d092      	beq.n	d00066cc <processMarkers+0x1c>
d00067a6:	e7af      	b.n	d0006708 <processMarkers+0x58>
d00067a8:	fa00 f202 	lsl.w	r2, r0, r2
d00067ac:	4604      	mov	r4, r0
d00067ae:	f8a9 2000 	strh.w	r2, [r9]
d00067b2:	f7ff fec1 	bl	d0006538 <getChar>
d00067b6:	f8b9 3000 	ldrh.w	r3, [r9]
d00067ba:	1224      	asrs	r4, r4, #8
d00067bc:	f89b 2000 	ldrb.w	r2, [fp]
d00067c0:	4318      	orrs	r0, r3
d00067c2:	2cff      	cmp	r4, #255	; 0xff
d00067c4:	f1c2 0308 	rsb	r3, r2, #8
d00067c8:	b280      	uxth	r0, r0
d00067ca:	fa00 f003 	lsl.w	r0, r0, r3
d00067ce:	b280      	uxth	r0, r0
d00067d0:	f47f af7c 	bne.w	d00066cc <processMarkers+0x1c>
d00067d4:	e785      	b.n	d00066e2 <processMarkers+0x32>
d00067d6:	f7ff ff37 	bl	d0006648 <getBits.constprop.0>
d00067da:	2804      	cmp	r0, #4
d00067dc:	f47f af72 	bne.w	d00066c4 <processMarkers+0x14>
d00067e0:	f7ff ff32 	bl	d0006648 <getBits.constprop.0>
d00067e4:	4b2c      	ldr	r3, [pc, #176]	; (d0006898 <processMarkers+0x1e8>)
d00067e6:	8018      	strh	r0, [r3, #0]
d00067e8:	e76c      	b.n	d00066c4 <processMarkers+0x14>
d00067ea:	f7ff ff2d 	bl	d0006648 <getBits.constprop.0>
d00067ee:	2801      	cmp	r0, #1
d00067f0:	f67f af68 	bls.w	d00066c4 <processMarkers+0x14>
d00067f4:	3802      	subs	r0, #2
d00067f6:	b284      	uxth	r4, r0
d00067f8:	2c00      	cmp	r4, #0
d00067fa:	f43f af63 	beq.w	d00066c4 <processMarkers+0x14>
d00067fe:	2000      	movs	r0, #0
d0006800:	f7ff fed4 	bl	d00065ac <getBits.constprop.1>
d0006804:	f010 0f0e 	tst.w	r0, #14
d0006808:	f3c0 1603 	ubfx	r6, r0, #4, #4
d000680c:	f000 030f 	and.w	r3, r0, #15
d0006810:	f47f af58 	bne.w	d00066c4 <processMarkers+0x14>
d0006814:	2b00      	cmp	r3, #0
d0006816:	f000 81df 	beq.w	d0006bd8 <processMarkers+0x528>
d000681a:	f89a 3000 	ldrb.w	r3, [sl]
d000681e:	f043 0302 	orr.w	r3, r3, #2
d0006822:	f88a 3000 	strb.w	r3, [sl]
d0006826:	2e00      	cmp	r6, #0
d0006828:	f040 82f3 	bne.w	d0006e12 <processMarkers+0x762>
d000682c:	4d1b      	ldr	r5, [pc, #108]	; (d000689c <processMarkers+0x1ec>)
d000682e:	f105 0780 	add.w	r7, r5, #128	; 0x80
d0006832:	f89b 3000 	ldrb.w	r3, [fp]
d0006836:	f8b9 8000 	ldrh.w	r8, [r9]
d000683a:	2b07      	cmp	r3, #7
d000683c:	f1a3 0008 	sub.w	r0, r3, #8
d0006840:	ea4f 2108 	mov.w	r1, r8, lsl #8
d0006844:	ea4f 2228 	mov.w	r2, r8, asr #8
d0006848:	f240 81a5 	bls.w	d0006b96 <processMarkers+0x4e6>
d000684c:	f825 2f02 	strh.w	r2, [r5, #2]!
d0006850:	42bd      	cmp	r5, r7
d0006852:	f88b 0000 	strb.w	r0, [fp]
d0006856:	f8a9 1000 	strh.w	r1, [r9]
d000685a:	d1ea      	bne.n	d0006832 <processMarkers+0x182>
d000685c:	4b10      	ldr	r3, [pc, #64]	; (d00068a0 <processMarkers+0x1f0>)
d000685e:	4911      	ldr	r1, [pc, #68]	; (d00068a4 <processMarkers+0x1f4>)
d0006860:	3b02      	subs	r3, #2
d0006862:	2504      	movs	r5, #4
d0006864:	f101 0040 	add.w	r0, r1, #64	; 0x40
d0006868:	f811 7b01 	ldrb.w	r7, [r1], #1
d000686c:	f833 2f02 	ldrh.w	r2, [r3, #2]!
d0006870:	4288      	cmp	r0, r1
d0006872:	fb12 5207 	smlabb	r2, r2, r7, r5
d0006876:	ea4f 02e2 	mov.w	r2, r2, asr #3
d000687a:	801a      	strh	r2, [r3, #0]
d000687c:	d1f4      	bne.n	d0006868 <processMarkers+0x1b8>
d000687e:	2e00      	cmp	r6, #0
d0006880:	bf0c      	ite	eq
d0006882:	2341      	moveq	r3, #65	; 0x41
d0006884:	2381      	movne	r3, #129	; 0x81
d0006886:	42a3      	cmp	r3, r4
d0006888:	f63f af1c 	bhi.w	d00066c4 <processMarkers+0x14>
d000688c:	1ae4      	subs	r4, r4, r3
d000688e:	b2a4      	uxth	r4, r4
d0006890:	2c00      	cmp	r4, #0
d0006892:	d1b4      	bne.n	d00067fe <processMarkers+0x14e>
d0006894:	e716      	b.n	d00066c4 <processMarkers+0x14>
d0006896:	bf00      	nop
d0006898:	d000e7fa 	.word	0xd000e7fa
d000689c:	d000e776 	.word	0xd000e776
d00068a0:	d000e778 	.word	0xd000e778
d00068a4:	d000d638 	.word	0xd000d638
d00068a8:	d000ded0 	.word	0xd000ded0
d00068ac:	d000ded2 	.word	0xd000ded2
d00068b0:	d000e801 	.word	0xd000e801
d00068b4:	f7ff fec8 	bl	d0006648 <getBits.constprop.0>
d00068b8:	2801      	cmp	r0, #1
d00068ba:	f67f af03 	bls.w	d00066c4 <processMarkers+0x14>
d00068be:	3802      	subs	r0, #2
d00068c0:	b286      	uxth	r6, r0
d00068c2:	2e00      	cmp	r6, #0
d00068c4:	f43f aefe 	beq.w	d00066c4 <processMarkers+0x14>
d00068c8:	f8df 8308 	ldr.w	r8, [pc, #776]	; d0006bd4 <processMarkers+0x524>
d00068cc:	4637      	mov	r7, r6
d00068ce:	2000      	movs	r0, #0
d00068d0:	f7ff fe6c 	bl	d00065ac <getBits.constprop.1>
d00068d4:	f010 060e 	ands.w	r6, r0, #14
d00068d8:	b2c5      	uxtb	r5, r0
d00068da:	f47f aef3 	bne.w	d00066c4 <processMarkers+0x14>
d00068de:	f005 03f0 	and.w	r3, r5, #240	; 0xf0
d00068e2:	2b10      	cmp	r3, #16
d00068e4:	f63f aeee 	bhi.w	d00066c4 <processMarkers+0x14>
d00068e8:	08ed      	lsrs	r5, r5, #3
d00068ea:	f000 0001 	and.w	r0, r0, #1
d00068ee:	2401      	movs	r4, #1
d00068f0:	f10d 030f 	add.w	r3, sp, #15
d00068f4:	f005 0502 	and.w	r5, r5, #2
d00068f8:	f898 c000 	ldrb.w	ip, [r8]
d00068fc:	9300      	str	r3, [sp, #0]
d00068fe:	ea45 0200 	orr.w	r2, r5, r0
d0006902:	4bb2      	ldr	r3, [pc, #712]	; (d0006bcc <processMarkers+0x51c>)
d0006904:	4635      	mov	r5, r6
d0006906:	fa04 fe02 	lsl.w	lr, r4, r2
d000690a:	4cb1      	ldr	r4, [pc, #708]	; (d0006bd0 <processMarkers+0x520>)
d000690c:	f853 3022 	ldr.w	r3, [r3, r2, lsl #2]
d0006910:	f854 4022 	ldr.w	r4, [r4, r2, lsl #2]
d0006914:	ea4e 0c0c 	orr.w	ip, lr, ip
d0006918:	9301      	str	r3, [sp, #4]
d000691a:	9402      	str	r4, [sp, #8]
d000691c:	9c00      	ldr	r4, [sp, #0]
d000691e:	9700      	str	r7, [sp, #0]
d0006920:	4617      	mov	r7, r2
d0006922:	f888 c000 	strb.w	ip, [r8]
d0006926:	2000      	movs	r0, #0
d0006928:	f7ff fe40 	bl	d00065ac <getBits.constprop.1>
d000692c:	f10d 011f 	add.w	r1, sp, #31
d0006930:	fa55 f580 	uxtab	r5, r5, r0
d0006934:	f804 0f01 	strb.w	r0, [r4, #1]!
d0006938:	428c      	cmp	r4, r1
d000693a:	b2ad      	uxth	r5, r5
d000693c:	d1f3      	bne.n	d0006926 <processMarkers+0x276>
d000693e:	463a      	mov	r2, r7
d0006940:	9c02      	ldr	r4, [sp, #8]
d0006942:	9f00      	ldr	r7, [sp, #0]
d0006944:	2a02      	cmp	r2, #2
d0006946:	bfb4      	ite	lt
d0006948:	230c      	movlt	r3, #12
d000694a:	23ff      	movge	r3, #255	; 0xff
d000694c:	429d      	cmp	r5, r3
d000694e:	f63f aeb9 	bhi.w	d00066c4 <processMarkers+0x14>
d0006952:	b14d      	cbz	r5, d0006968 <processMarkers+0x2b8>
d0006954:	2000      	movs	r0, #0
d0006956:	f7ff fe29 	bl	d00065ac <getBits.constprop.1>
d000695a:	1c73      	adds	r3, r6, #1
d000695c:	9a01      	ldr	r2, [sp, #4]
d000695e:	5590      	strb	r0, [r2, r6]
d0006960:	b2da      	uxtb	r2, r3
d0006962:	4295      	cmp	r5, r2
d0006964:	4616      	mov	r6, r2
d0006966:	d8f5      	bhi.n	d0006954 <processMarkers+0x2a4>
d0006968:	3511      	adds	r5, #17
d000696a:	b2ad      	uxth	r5, r5
d000696c:	42bd      	cmp	r5, r7
d000696e:	f63f aea9 	bhi.w	d00066c4 <processMarkers+0x14>
d0006972:	1b7d      	subs	r5, r7, r5
d0006974:	f89d 2010 	ldrb.w	r2, [sp, #16]
d0006978:	b2af      	uxth	r7, r5
d000697a:	2a00      	cmp	r2, #0
d000697c:	f000 8207 	beq.w	d0006d8e <processMarkers+0x6de>
d0006980:	2300      	movs	r3, #0
d0006982:	1e51      	subs	r1, r2, #1
d0006984:	8023      	strh	r3, [r4, #0]
d0006986:	f884 3040 	strb.w	r3, [r4, #64]	; 0x40
d000698a:	0053      	lsls	r3, r2, #1
d000698c:	8421      	strh	r1, [r4, #32]
d000698e:	f89d 1011 	ldrb.w	r1, [sp, #17]
d0006992:	2900      	cmp	r1, #0
d0006994:	f000 81f4 	beq.w	d0006d80 <processMarkers+0x6d0>
d0006998:	1858      	adds	r0, r3, r1
d000699a:	8063      	strh	r3, [r4, #2]
d000699c:	4411      	add	r1, r2
d000699e:	f884 2041 	strb.w	r2, [r4, #65]	; 0x41
d00069a2:	b283      	uxth	r3, r0
d00069a4:	b2ca      	uxtb	r2, r1
d00069a6:	1e59      	subs	r1, r3, #1
d00069a8:	8461      	strh	r1, [r4, #34]	; 0x22
d00069aa:	005b      	lsls	r3, r3, #1
d00069ac:	f89d 1012 	ldrb.w	r1, [sp, #18]
d00069b0:	b29b      	uxth	r3, r3
d00069b2:	2900      	cmp	r1, #0
d00069b4:	f000 81dd 	beq.w	d0006d72 <processMarkers+0x6c2>
d00069b8:	1858      	adds	r0, r3, r1
d00069ba:	80a3      	strh	r3, [r4, #4]
d00069bc:	4411      	add	r1, r2
d00069be:	f884 2042 	strb.w	r2, [r4, #66]	; 0x42
d00069c2:	b283      	uxth	r3, r0
d00069c4:	b2ca      	uxtb	r2, r1
d00069c6:	1e59      	subs	r1, r3, #1
d00069c8:	84a1      	strh	r1, [r4, #36]	; 0x24
d00069ca:	005b      	lsls	r3, r3, #1
d00069cc:	f89d 1013 	ldrb.w	r1, [sp, #19]
d00069d0:	b29b      	uxth	r3, r3
d00069d2:	2900      	cmp	r1, #0
d00069d4:	f000 815e 	beq.w	d0006c94 <processMarkers+0x5e4>
d00069d8:	1858      	adds	r0, r3, r1
d00069da:	80e3      	strh	r3, [r4, #6]
d00069dc:	4411      	add	r1, r2
d00069de:	f884 2043 	strb.w	r2, [r4, #67]	; 0x43
d00069e2:	b283      	uxth	r3, r0
d00069e4:	b2ca      	uxtb	r2, r1
d00069e6:	1e59      	subs	r1, r3, #1
d00069e8:	005b      	lsls	r3, r3, #1
d00069ea:	84e1      	strh	r1, [r4, #38]	; 0x26
d00069ec:	b29b      	uxth	r3, r3
d00069ee:	f89d 1014 	ldrb.w	r1, [sp, #20]
d00069f2:	2900      	cmp	r1, #0
d00069f4:	f000 815b 	beq.w	d0006cae <processMarkers+0x5fe>
d00069f8:	1858      	adds	r0, r3, r1
d00069fa:	8123      	strh	r3, [r4, #8]
d00069fc:	4411      	add	r1, r2
d00069fe:	f884 2044 	strb.w	r2, [r4, #68]	; 0x44
d0006a02:	b283      	uxth	r3, r0
d0006a04:	b2ca      	uxtb	r2, r1
d0006a06:	1e59      	subs	r1, r3, #1
d0006a08:	005b      	lsls	r3, r3, #1
d0006a0a:	8521      	strh	r1, [r4, #40]	; 0x28
d0006a0c:	b29b      	uxth	r3, r3
d0006a0e:	f89d 1015 	ldrb.w	r1, [sp, #21]
d0006a12:	2900      	cmp	r1, #0
d0006a14:	f000 8158 	beq.w	d0006cc8 <processMarkers+0x618>
d0006a18:	1858      	adds	r0, r3, r1
d0006a1a:	8163      	strh	r3, [r4, #10]
d0006a1c:	4411      	add	r1, r2
d0006a1e:	f884 2045 	strb.w	r2, [r4, #69]	; 0x45
d0006a22:	b283      	uxth	r3, r0
d0006a24:	b2ca      	uxtb	r2, r1
d0006a26:	1e59      	subs	r1, r3, #1
d0006a28:	005b      	lsls	r3, r3, #1
d0006a2a:	8561      	strh	r1, [r4, #42]	; 0x2a
d0006a2c:	b29b      	uxth	r3, r3
d0006a2e:	f89d 1016 	ldrb.w	r1, [sp, #22]
d0006a32:	2900      	cmp	r1, #0
d0006a34:	f000 8155 	beq.w	d0006ce2 <processMarkers+0x632>
d0006a38:	1858      	adds	r0, r3, r1
d0006a3a:	81a3      	strh	r3, [r4, #12]
d0006a3c:	4411      	add	r1, r2
d0006a3e:	f884 2046 	strb.w	r2, [r4, #70]	; 0x46
d0006a42:	b283      	uxth	r3, r0
d0006a44:	b2ca      	uxtb	r2, r1
d0006a46:	1e59      	subs	r1, r3, #1
d0006a48:	005b      	lsls	r3, r3, #1
d0006a4a:	85a1      	strh	r1, [r4, #44]	; 0x2c
d0006a4c:	b29b      	uxth	r3, r3
d0006a4e:	f89d 1017 	ldrb.w	r1, [sp, #23]
d0006a52:	2900      	cmp	r1, #0
d0006a54:	f000 8152 	beq.w	d0006cfc <processMarkers+0x64c>
d0006a58:	1858      	adds	r0, r3, r1
d0006a5a:	81e3      	strh	r3, [r4, #14]
d0006a5c:	4411      	add	r1, r2
d0006a5e:	f884 2047 	strb.w	r2, [r4, #71]	; 0x47
d0006a62:	b283      	uxth	r3, r0
d0006a64:	b2ca      	uxtb	r2, r1
d0006a66:	1e59      	subs	r1, r3, #1
d0006a68:	005b      	lsls	r3, r3, #1
d0006a6a:	85e1      	strh	r1, [r4, #46]	; 0x2e
d0006a6c:	b29b      	uxth	r3, r3
d0006a6e:	f89d 1018 	ldrb.w	r1, [sp, #24]
d0006a72:	2900      	cmp	r1, #0
d0006a74:	f000 814f 	beq.w	d0006d16 <processMarkers+0x666>
d0006a78:	1858      	adds	r0, r3, r1
d0006a7a:	8223      	strh	r3, [r4, #16]
d0006a7c:	4411      	add	r1, r2
d0006a7e:	f884 2048 	strb.w	r2, [r4, #72]	; 0x48
d0006a82:	b283      	uxth	r3, r0
d0006a84:	b2ca      	uxtb	r2, r1
d0006a86:	1e59      	subs	r1, r3, #1
d0006a88:	005b      	lsls	r3, r3, #1
d0006a8a:	8621      	strh	r1, [r4, #48]	; 0x30
d0006a8c:	b29b      	uxth	r3, r3
d0006a8e:	f89d 1019 	ldrb.w	r1, [sp, #25]
d0006a92:	2900      	cmp	r1, #0
d0006a94:	f000 814c 	beq.w	d0006d30 <processMarkers+0x680>
d0006a98:	1858      	adds	r0, r3, r1
d0006a9a:	8263      	strh	r3, [r4, #18]
d0006a9c:	4411      	add	r1, r2
d0006a9e:	f884 2049 	strb.w	r2, [r4, #73]	; 0x49
d0006aa2:	b283      	uxth	r3, r0
d0006aa4:	b2ca      	uxtb	r2, r1
d0006aa6:	1e59      	subs	r1, r3, #1
d0006aa8:	005b      	lsls	r3, r3, #1
d0006aaa:	8661      	strh	r1, [r4, #50]	; 0x32
d0006aac:	b29b      	uxth	r3, r3
d0006aae:	f89d 101a 	ldrb.w	r1, [sp, #26]
d0006ab2:	2900      	cmp	r1, #0
d0006ab4:	f000 8149 	beq.w	d0006d4a <processMarkers+0x69a>
d0006ab8:	1858      	adds	r0, r3, r1
d0006aba:	82a3      	strh	r3, [r4, #20]
d0006abc:	4411      	add	r1, r2
d0006abe:	f884 204a 	strb.w	r2, [r4, #74]	; 0x4a
d0006ac2:	b283      	uxth	r3, r0
d0006ac4:	b2ca      	uxtb	r2, r1
d0006ac6:	1e59      	subs	r1, r3, #1
d0006ac8:	005b      	lsls	r3, r3, #1
d0006aca:	86a1      	strh	r1, [r4, #52]	; 0x34
d0006acc:	b29b      	uxth	r3, r3
d0006ace:	f89d 101b 	ldrb.w	r1, [sp, #27]
d0006ad2:	2900      	cmp	r1, #0
d0006ad4:	f000 8146 	beq.w	d0006d64 <processMarkers+0x6b4>
d0006ad8:	1858      	adds	r0, r3, r1
d0006ada:	82e3      	strh	r3, [r4, #22]
d0006adc:	4411      	add	r1, r2
d0006ade:	f884 204b 	strb.w	r2, [r4, #75]	; 0x4b
d0006ae2:	b283      	uxth	r3, r0
d0006ae4:	b2ca      	uxtb	r2, r1
d0006ae6:	1e59      	subs	r1, r3, #1
d0006ae8:	86e1      	strh	r1, [r4, #54]	; 0x36
d0006aea:	005b      	lsls	r3, r3, #1
d0006aec:	f89d 101c 	ldrb.w	r1, [sp, #28]
d0006af0:	b29b      	uxth	r3, r3
d0006af2:	2900      	cmp	r1, #0
d0006af4:	f000 80c7 	beq.w	d0006c86 <processMarkers+0x5d6>
d0006af8:	1858      	adds	r0, r3, r1
d0006afa:	8323      	strh	r3, [r4, #24]
d0006afc:	4411      	add	r1, r2
d0006afe:	f884 204c 	strb.w	r2, [r4, #76]	; 0x4c
d0006b02:	b283      	uxth	r3, r0
d0006b04:	b2ca      	uxtb	r2, r1
d0006b06:	1e59      	subs	r1, r3, #1
d0006b08:	8721      	strh	r1, [r4, #56]	; 0x38
d0006b0a:	005b      	lsls	r3, r3, #1
d0006b0c:	f89d 101d 	ldrb.w	r1, [sp, #29]
d0006b10:	b29b      	uxth	r3, r3
d0006b12:	2900      	cmp	r1, #0
d0006b14:	f000 80b0 	beq.w	d0006c78 <processMarkers+0x5c8>
d0006b18:	1858      	adds	r0, r3, r1
d0006b1a:	8363      	strh	r3, [r4, #26]
d0006b1c:	4411      	add	r1, r2
d0006b1e:	f884 204d 	strb.w	r2, [r4, #77]	; 0x4d
d0006b22:	b283      	uxth	r3, r0
d0006b24:	b2ca      	uxtb	r2, r1
d0006b26:	1e59      	subs	r1, r3, #1
d0006b28:	8761      	strh	r1, [r4, #58]	; 0x3a
d0006b2a:	005b      	lsls	r3, r3, #1
d0006b2c:	f89d 101e 	ldrb.w	r1, [sp, #30]
d0006b30:	b29b      	uxth	r3, r3
d0006b32:	2900      	cmp	r1, #0
d0006b34:	f000 8099 	beq.w	d0006c6a <processMarkers+0x5ba>
d0006b38:	1858      	adds	r0, r3, r1
d0006b3a:	83a3      	strh	r3, [r4, #28]
d0006b3c:	4411      	add	r1, r2
d0006b3e:	f884 204e 	strb.w	r2, [r4, #78]	; 0x4e
d0006b42:	b283      	uxth	r3, r0
d0006b44:	b2ca      	uxtb	r2, r1
d0006b46:	1e59      	subs	r1, r3, #1
d0006b48:	87a1      	strh	r1, [r4, #60]	; 0x3c
d0006b4a:	f89d 101f 	ldrb.w	r1, [sp, #31]
d0006b4e:	2900      	cmp	r1, #0
d0006b50:	d17f      	bne.n	d0006c52 <processMarkers+0x5a2>
d0006b52:	f64f 73ff 	movw	r3, #65535	; 0xffff
d0006b56:	83e1      	strh	r1, [r4, #30]
d0006b58:	f884 104f 	strb.w	r1, [r4, #79]	; 0x4f
d0006b5c:	87e3      	strh	r3, [r4, #62]	; 0x3e
d0006b5e:	2f00      	cmp	r7, #0
d0006b60:	f47f aeb5 	bne.w	d00068ce <processMarkers+0x21e>
d0006b64:	e5ae      	b.n	d00066c4 <processMarkers+0x14>
d0006b66:	9b03      	ldr	r3, [sp, #12]
d0006b68:	2000      	movs	r0, #0
d0006b6a:	7019      	strb	r1, [r3, #0]
d0006b6c:	b009      	add	sp, #36	; 0x24
d0006b6e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0006b72:	f7ff fd69 	bl	d0006648 <getBits.constprop.0>
d0006b76:	2801      	cmp	r0, #1
d0006b78:	f67f ada4 	bls.w	d00066c4 <processMarkers+0x14>
d0006b7c:	3802      	subs	r0, #2
d0006b7e:	b284      	uxth	r4, r0
d0006b80:	2c00      	cmp	r4, #0
d0006b82:	f43f ad9f 	beq.w	d00066c4 <processMarkers+0x14>
d0006b86:	3c01      	subs	r4, #1
d0006b88:	2000      	movs	r0, #0
d0006b8a:	f7ff fd0f 	bl	d00065ac <getBits.constprop.1>
d0006b8e:	b2a4      	uxth	r4, r4
d0006b90:	2c00      	cmp	r4, #0
d0006b92:	d1f8      	bne.n	d0006b86 <processMarkers+0x4d6>
d0006b94:	e596      	b.n	d00066c4 <processMarkers+0x14>
d0006b96:	fa08 f303 	lsl.w	r3, r8, r3
d0006b9a:	ea4f 2828 	mov.w	r8, r8, asr #8
d0006b9e:	f8a9 3000 	strh.w	r3, [r9]
d0006ba2:	f7ff fcc9 	bl	d0006538 <getChar>
d0006ba6:	f8b9 3000 	ldrh.w	r3, [r9]
d0006baa:	f825 8f02 	strh.w	r8, [r5, #2]!
d0006bae:	42af      	cmp	r7, r5
d0006bb0:	ea40 0003 	orr.w	r0, r0, r3
d0006bb4:	f89b 3000 	ldrb.w	r3, [fp]
d0006bb8:	b280      	uxth	r0, r0
d0006bba:	f1c3 0308 	rsb	r3, r3, #8
d0006bbe:	fa00 f003 	lsl.w	r0, r0, r3
d0006bc2:	f8a9 0000 	strh.w	r0, [r9]
d0006bc6:	f47f ae34 	bne.w	d0006832 <processMarkers+0x182>
d0006bca:	e647      	b.n	d000685c <processMarkers+0x1ac>
d0006bcc:	d000d5e8 	.word	0xd000d5e8
d0006bd0:	d000d5d8 	.word	0xd000d5d8
d0006bd4:	d000e800 	.word	0xd000e800
d0006bd8:	f89a 3000 	ldrb.w	r3, [sl]
d0006bdc:	f043 0301 	orr.w	r3, r3, #1
d0006be0:	f88a 3000 	strb.w	r3, [sl]
d0006be4:	2e00      	cmp	r6, #0
d0006be6:	f040 80da 	bne.w	d0006d9e <processMarkers+0x6ee>
d0006bea:	4da6      	ldr	r5, [pc, #664]	; (d0006e84 <processMarkers+0x7d4>)
d0006bec:	f105 0780 	add.w	r7, r5, #128	; 0x80
d0006bf0:	f89b 3000 	ldrb.w	r3, [fp]
d0006bf4:	f8b9 8000 	ldrh.w	r8, [r9]
d0006bf8:	2b07      	cmp	r3, #7
d0006bfa:	f1a3 0008 	sub.w	r0, r3, #8
d0006bfe:	ea4f 2108 	mov.w	r1, r8, lsl #8
d0006c02:	ea4f 2228 	mov.w	r2, r8, asr #8
d0006c06:	d909      	bls.n	d0006c1c <processMarkers+0x56c>
d0006c08:	f825 2f02 	strh.w	r2, [r5, #2]!
d0006c0c:	42bd      	cmp	r5, r7
d0006c0e:	f88b 0000 	strb.w	r0, [fp]
d0006c12:	f8a9 1000 	strh.w	r1, [r9]
d0006c16:	d1eb      	bne.n	d0006bf0 <processMarkers+0x540>
d0006c18:	4b9b      	ldr	r3, [pc, #620]	; (d0006e88 <processMarkers+0x7d8>)
d0006c1a:	e620      	b.n	d000685e <processMarkers+0x1ae>
d0006c1c:	fa08 f303 	lsl.w	r3, r8, r3
d0006c20:	ea4f 2828 	mov.w	r8, r8, asr #8
d0006c24:	f8a9 3000 	strh.w	r3, [r9]
d0006c28:	f7ff fc86 	bl	d0006538 <getChar>
d0006c2c:	f8b9 3000 	ldrh.w	r3, [r9]
d0006c30:	f825 8f02 	strh.w	r8, [r5, #2]!
d0006c34:	42bd      	cmp	r5, r7
d0006c36:	ea40 0003 	orr.w	r0, r0, r3
d0006c3a:	f89b 3000 	ldrb.w	r3, [fp]
d0006c3e:	b280      	uxth	r0, r0
d0006c40:	f1c3 0308 	rsb	r3, r3, #8
d0006c44:	fa00 f003 	lsl.w	r0, r0, r3
d0006c48:	f8a9 0000 	strh.w	r0, [r9]
d0006c4c:	d1d0      	bne.n	d0006bf0 <processMarkers+0x540>
d0006c4e:	4b8e      	ldr	r3, [pc, #568]	; (d0006e88 <processMarkers+0x7d8>)
d0006c50:	e605      	b.n	d000685e <processMarkers+0x1ae>
d0006c52:	005b      	lsls	r3, r3, #1
d0006c54:	3901      	subs	r1, #1
d0006c56:	f884 204f 	strb.w	r2, [r4, #79]	; 0x4f
d0006c5a:	b29b      	uxth	r3, r3
d0006c5c:	4419      	add	r1, r3
d0006c5e:	83e3      	strh	r3, [r4, #30]
d0006c60:	87e1      	strh	r1, [r4, #62]	; 0x3e
d0006c62:	2f00      	cmp	r7, #0
d0006c64:	f47f ae33 	bne.w	d00068ce <processMarkers+0x21e>
d0006c68:	e52c      	b.n	d00066c4 <processMarkers+0x14>
d0006c6a:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006c6e:	83a1      	strh	r1, [r4, #28]
d0006c70:	f884 104e 	strb.w	r1, [r4, #78]	; 0x4e
d0006c74:	87a0      	strh	r0, [r4, #60]	; 0x3c
d0006c76:	e768      	b.n	d0006b4a <processMarkers+0x49a>
d0006c78:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006c7c:	8361      	strh	r1, [r4, #26]
d0006c7e:	f884 104d 	strb.w	r1, [r4, #77]	; 0x4d
d0006c82:	8760      	strh	r0, [r4, #58]	; 0x3a
d0006c84:	e751      	b.n	d0006b2a <processMarkers+0x47a>
d0006c86:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006c8a:	8321      	strh	r1, [r4, #24]
d0006c8c:	f884 104c 	strb.w	r1, [r4, #76]	; 0x4c
d0006c90:	8720      	strh	r0, [r4, #56]	; 0x38
d0006c92:	e73a      	b.n	d0006b0a <processMarkers+0x45a>
d0006c94:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006c98:	005b      	lsls	r3, r3, #1
d0006c9a:	80e1      	strh	r1, [r4, #6]
d0006c9c:	f884 1043 	strb.w	r1, [r4, #67]	; 0x43
d0006ca0:	b29b      	uxth	r3, r3
d0006ca2:	f89d 1014 	ldrb.w	r1, [sp, #20]
d0006ca6:	84e0      	strh	r0, [r4, #38]	; 0x26
d0006ca8:	2900      	cmp	r1, #0
d0006caa:	f47f aea5 	bne.w	d00069f8 <processMarkers+0x348>
d0006cae:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006cb2:	005b      	lsls	r3, r3, #1
d0006cb4:	8121      	strh	r1, [r4, #8]
d0006cb6:	f884 1044 	strb.w	r1, [r4, #68]	; 0x44
d0006cba:	b29b      	uxth	r3, r3
d0006cbc:	f89d 1015 	ldrb.w	r1, [sp, #21]
d0006cc0:	8520      	strh	r0, [r4, #40]	; 0x28
d0006cc2:	2900      	cmp	r1, #0
d0006cc4:	f47f aea8 	bne.w	d0006a18 <processMarkers+0x368>
d0006cc8:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006ccc:	005b      	lsls	r3, r3, #1
d0006cce:	8161      	strh	r1, [r4, #10]
d0006cd0:	f884 1045 	strb.w	r1, [r4, #69]	; 0x45
d0006cd4:	b29b      	uxth	r3, r3
d0006cd6:	f89d 1016 	ldrb.w	r1, [sp, #22]
d0006cda:	8560      	strh	r0, [r4, #42]	; 0x2a
d0006cdc:	2900      	cmp	r1, #0
d0006cde:	f47f aeab 	bne.w	d0006a38 <processMarkers+0x388>
d0006ce2:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006ce6:	005b      	lsls	r3, r3, #1
d0006ce8:	81a1      	strh	r1, [r4, #12]
d0006cea:	f884 1046 	strb.w	r1, [r4, #70]	; 0x46
d0006cee:	b29b      	uxth	r3, r3
d0006cf0:	f89d 1017 	ldrb.w	r1, [sp, #23]
d0006cf4:	85a0      	strh	r0, [r4, #44]	; 0x2c
d0006cf6:	2900      	cmp	r1, #0
d0006cf8:	f47f aeae 	bne.w	d0006a58 <processMarkers+0x3a8>
d0006cfc:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d00:	005b      	lsls	r3, r3, #1
d0006d02:	81e1      	strh	r1, [r4, #14]
d0006d04:	f884 1047 	strb.w	r1, [r4, #71]	; 0x47
d0006d08:	b29b      	uxth	r3, r3
d0006d0a:	f89d 1018 	ldrb.w	r1, [sp, #24]
d0006d0e:	85e0      	strh	r0, [r4, #46]	; 0x2e
d0006d10:	2900      	cmp	r1, #0
d0006d12:	f47f aeb1 	bne.w	d0006a78 <processMarkers+0x3c8>
d0006d16:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d1a:	005b      	lsls	r3, r3, #1
d0006d1c:	8221      	strh	r1, [r4, #16]
d0006d1e:	f884 1048 	strb.w	r1, [r4, #72]	; 0x48
d0006d22:	b29b      	uxth	r3, r3
d0006d24:	f89d 1019 	ldrb.w	r1, [sp, #25]
d0006d28:	8620      	strh	r0, [r4, #48]	; 0x30
d0006d2a:	2900      	cmp	r1, #0
d0006d2c:	f47f aeb4 	bne.w	d0006a98 <processMarkers+0x3e8>
d0006d30:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d34:	005b      	lsls	r3, r3, #1
d0006d36:	8261      	strh	r1, [r4, #18]
d0006d38:	f884 1049 	strb.w	r1, [r4, #73]	; 0x49
d0006d3c:	b29b      	uxth	r3, r3
d0006d3e:	f89d 101a 	ldrb.w	r1, [sp, #26]
d0006d42:	8660      	strh	r0, [r4, #50]	; 0x32
d0006d44:	2900      	cmp	r1, #0
d0006d46:	f47f aeb7 	bne.w	d0006ab8 <processMarkers+0x408>
d0006d4a:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d4e:	005b      	lsls	r3, r3, #1
d0006d50:	82a1      	strh	r1, [r4, #20]
d0006d52:	f884 104a 	strb.w	r1, [r4, #74]	; 0x4a
d0006d56:	b29b      	uxth	r3, r3
d0006d58:	f89d 101b 	ldrb.w	r1, [sp, #27]
d0006d5c:	86a0      	strh	r0, [r4, #52]	; 0x34
d0006d5e:	2900      	cmp	r1, #0
d0006d60:	f47f aeba 	bne.w	d0006ad8 <processMarkers+0x428>
d0006d64:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d68:	82e1      	strh	r1, [r4, #22]
d0006d6a:	f884 104b 	strb.w	r1, [r4, #75]	; 0x4b
d0006d6e:	86e0      	strh	r0, [r4, #54]	; 0x36
d0006d70:	e6bb      	b.n	d0006aea <processMarkers+0x43a>
d0006d72:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d76:	80a1      	strh	r1, [r4, #4]
d0006d78:	f884 1042 	strb.w	r1, [r4, #66]	; 0x42
d0006d7c:	84a0      	strh	r0, [r4, #36]	; 0x24
d0006d7e:	e624      	b.n	d00069ca <processMarkers+0x31a>
d0006d80:	f64f 70ff 	movw	r0, #65535	; 0xffff
d0006d84:	8061      	strh	r1, [r4, #2]
d0006d86:	f884 1041 	strb.w	r1, [r4, #65]	; 0x41
d0006d8a:	8460      	strh	r0, [r4, #34]	; 0x22
d0006d8c:	e60d      	b.n	d00069aa <processMarkers+0x2fa>
d0006d8e:	f64f 71ff 	movw	r1, #65535	; 0xffff
d0006d92:	4613      	mov	r3, r2
d0006d94:	8022      	strh	r2, [r4, #0]
d0006d96:	f884 2040 	strb.w	r2, [r4, #64]	; 0x40
d0006d9a:	8421      	strh	r1, [r4, #32]
d0006d9c:	e5f7      	b.n	d000698e <processMarkers+0x2de>
d0006d9e:	f8df 80e4 	ldr.w	r8, [pc, #228]	; d0006e84 <processMarkers+0x7d4>
d0006da2:	f108 0780 	add.w	r7, r8, #128	; 0x80
d0006da6:	f89b 3000 	ldrb.w	r3, [fp]
d0006daa:	2000      	movs	r0, #0
d0006dac:	f8b9 5000 	ldrh.w	r5, [r9]
d0006db0:	2b07      	cmp	r3, #7
d0006db2:	f1a3 0108 	sub.w	r1, r3, #8
d0006db6:	ea4f 2205 	mov.w	r2, r5, lsl #8
d0006dba:	d90d      	bls.n	d0006dd8 <processMarkers+0x728>
d0006dbc:	f405 457f 	and.w	r5, r5, #65280	; 0xff00
d0006dc0:	f88b 1000 	strb.w	r1, [fp]
d0006dc4:	f8a9 2000 	strh.w	r2, [r9]
d0006dc8:	f7ff fbf0 	bl	d00065ac <getBits.constprop.1>
d0006dcc:	4428      	add	r0, r5
d0006dce:	f828 0f02 	strh.w	r0, [r8, #2]!
d0006dd2:	45b8      	cmp	r8, r7
d0006dd4:	d1e7      	bne.n	d0006da6 <processMarkers+0x6f6>
d0006dd6:	e71f      	b.n	d0006c18 <processMarkers+0x568>
d0006dd8:	fa05 f303 	lsl.w	r3, r5, r3
d0006ddc:	f405 457f 	and.w	r5, r5, #65280	; 0xff00
d0006de0:	f8a9 3000 	strh.w	r3, [r9]
d0006de4:	f7ff fba8 	bl	d0006538 <getChar>
d0006de8:	f8b9 3000 	ldrh.w	r3, [r9]
d0006dec:	f89b 2000 	ldrb.w	r2, [fp]
d0006df0:	4303      	orrs	r3, r0
d0006df2:	2000      	movs	r0, #0
d0006df4:	f1c2 0208 	rsb	r2, r2, #8
d0006df8:	b29b      	uxth	r3, r3
d0006dfa:	4093      	lsls	r3, r2
d0006dfc:	f8a9 3000 	strh.w	r3, [r9]
d0006e00:	f7ff fbd4 	bl	d00065ac <getBits.constprop.1>
d0006e04:	4405      	add	r5, r0
d0006e06:	f828 5f02 	strh.w	r5, [r8, #2]!
d0006e0a:	4547      	cmp	r7, r8
d0006e0c:	d1cb      	bne.n	d0006da6 <processMarkers+0x6f6>
d0006e0e:	4b1e      	ldr	r3, [pc, #120]	; (d0006e88 <processMarkers+0x7d8>)
d0006e10:	e525      	b.n	d000685e <processMarkers+0x1ae>
d0006e12:	f8df 8078 	ldr.w	r8, [pc, #120]	; d0006e8c <processMarkers+0x7dc>
d0006e16:	f108 0780 	add.w	r7, r8, #128	; 0x80
d0006e1a:	f89b 3000 	ldrb.w	r3, [fp]
d0006e1e:	2000      	movs	r0, #0
d0006e20:	f8b9 5000 	ldrh.w	r5, [r9]
d0006e24:	2b07      	cmp	r3, #7
d0006e26:	f1a3 0108 	sub.w	r1, r3, #8
d0006e2a:	ea4f 2205 	mov.w	r2, r5, lsl #8
d0006e2e:	d90d      	bls.n	d0006e4c <processMarkers+0x79c>
d0006e30:	f405 457f 	and.w	r5, r5, #65280	; 0xff00
d0006e34:	f88b 1000 	strb.w	r1, [fp]
d0006e38:	f8a9 2000 	strh.w	r2, [r9]
d0006e3c:	f7ff fbb6 	bl	d00065ac <getBits.constprop.1>
d0006e40:	4405      	add	r5, r0
d0006e42:	f828 5f02 	strh.w	r5, [r8, #2]!
d0006e46:	45b8      	cmp	r8, r7
d0006e48:	d1e7      	bne.n	d0006e1a <processMarkers+0x76a>
d0006e4a:	e507      	b.n	d000685c <processMarkers+0x1ac>
d0006e4c:	fa05 f303 	lsl.w	r3, r5, r3
d0006e50:	f405 457f 	and.w	r5, r5, #65280	; 0xff00
d0006e54:	f8a9 3000 	strh.w	r3, [r9]
d0006e58:	f7ff fb6e 	bl	d0006538 <getChar>
d0006e5c:	f8b9 3000 	ldrh.w	r3, [r9]
d0006e60:	f89b 2000 	ldrb.w	r2, [fp]
d0006e64:	4303      	orrs	r3, r0
d0006e66:	2000      	movs	r0, #0
d0006e68:	f1c2 0208 	rsb	r2, r2, #8
d0006e6c:	b29b      	uxth	r3, r3
d0006e6e:	4093      	lsls	r3, r2
d0006e70:	f8a9 3000 	strh.w	r3, [r9]
d0006e74:	f7ff fb9a 	bl	d00065ac <getBits.constprop.1>
d0006e78:	4428      	add	r0, r5
d0006e7a:	f828 0f02 	strh.w	r0, [r8, #2]!
d0006e7e:	4547      	cmp	r7, r8
d0006e80:	d1cb      	bne.n	d0006e1a <processMarkers+0x76a>
d0006e82:	e4eb      	b.n	d000685c <processMarkers+0x1ac>
d0006e84:	d000e6f6 	.word	0xd000e6f6
d0006e88:	d000e6f8 	.word	0xd000e6f8
d0006e8c:	d000e776 	.word	0xd000e776

d0006e90 <getBits.constprop.2>:
d0006e90:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0006e94:	2808      	cmp	r0, #8
d0006e96:	4f46      	ldr	r7, [pc, #280]	; (d0006fb0 <getBits.constprop.2+0x120>)
d0006e98:	4605      	mov	r5, r0
d0006e9a:	f8df 811c 	ldr.w	r8, [pc, #284]	; d0006fb8 <getBits.constprop.2+0x128>
d0006e9e:	883e      	ldrh	r6, [r7, #0]
d0006ea0:	d813      	bhi.n	d0006eca <getBits.constprop.2+0x3a>
d0006ea2:	4681      	mov	r9, r0
d0006ea4:	f898 2000 	ldrb.w	r2, [r8]
d0006ea8:	4633      	mov	r3, r6
d0006eaa:	4591      	cmp	r9, r2
d0006eac:	d82d      	bhi.n	d0006f0a <getBits.constprop.2+0x7a>
d0006eae:	f1c5 0510 	rsb	r5, r5, #16
d0006eb2:	eba2 0209 	sub.w	r2, r2, r9
d0006eb6:	fa03 f309 	lsl.w	r3, r3, r9
d0006eba:	fa46 f505 	asr.w	r5, r6, r5
d0006ebe:	f888 2000 	strb.w	r2, [r8]
d0006ec2:	803b      	strh	r3, [r7, #0]
d0006ec4:	b2a8      	uxth	r0, r5
d0006ec6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d0006eca:	f1a0 0308 	sub.w	r3, r0, #8
d0006ece:	f898 2000 	ldrb.w	r2, [r8]
d0006ed2:	fa5f f983 	uxtb.w	r9, r3
d0006ed6:	fa06 f302 	lsl.w	r3, r6, r2
d0006eda:	803b      	strh	r3, [r7, #0]
d0006edc:	f7ff fb2c 	bl	d0006538 <getChar>
d0006ee0:	28ff      	cmp	r0, #255	; 0xff
d0006ee2:	4604      	mov	r4, r0
d0006ee4:	d02f      	beq.n	d0006f46 <getBits.constprop.2+0xb6>
d0006ee6:	883b      	ldrh	r3, [r7, #0]
d0006ee8:	f026 06ff 	bic.w	r6, r6, #255	; 0xff
d0006eec:	f898 2000 	ldrb.w	r2, [r8]
d0006ef0:	431c      	orrs	r4, r3
d0006ef2:	f1c2 0308 	rsb	r3, r2, #8
d0006ef6:	4591      	cmp	r9, r2
d0006ef8:	b2a4      	uxth	r4, r4
d0006efa:	fa04 f403 	lsl.w	r4, r4, r3
d0006efe:	f3c4 2107 	ubfx	r1, r4, #8, #8
d0006f02:	b2a3      	uxth	r3, r4
d0006f04:	ea46 0601 	orr.w	r6, r6, r1
d0006f08:	d9d1      	bls.n	d0006eae <getBits.constprop.2+0x1e>
d0006f0a:	fa03 f202 	lsl.w	r2, r3, r2
d0006f0e:	803a      	strh	r2, [r7, #0]
d0006f10:	f7ff fb12 	bl	d0006538 <getChar>
d0006f14:	28ff      	cmp	r0, #255	; 0xff
d0006f16:	4604      	mov	r4, r0
d0006f18:	d02f      	beq.n	d0006f7a <getBits.constprop.2+0xea>
d0006f1a:	8839      	ldrh	r1, [r7, #0]
d0006f1c:	f1c5 0510 	rsb	r5, r5, #16
d0006f20:	f898 3000 	ldrb.w	r3, [r8]
d0006f24:	ea44 0201 	orr.w	r2, r4, r1
d0006f28:	fa46 f505 	asr.w	r5, r6, r5
d0006f2c:	eba9 0103 	sub.w	r1, r9, r3
d0006f30:	3308      	adds	r3, #8
d0006f32:	b292      	uxth	r2, r2
d0006f34:	eba3 0309 	sub.w	r3, r3, r9
d0006f38:	b2a8      	uxth	r0, r5
d0006f3a:	408a      	lsls	r2, r1
d0006f3c:	f888 3000 	strb.w	r3, [r8]
d0006f40:	803a      	strh	r2, [r7, #0]
d0006f42:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d0006f46:	f7ff faf7 	bl	d0006538 <getChar>
d0006f4a:	2800      	cmp	r0, #0
d0006f4c:	d0cb      	beq.n	d0006ee6 <getBits.constprop.2+0x56>
d0006f4e:	f8df c06c 	ldr.w	ip, [pc, #108]	; d0006fbc <getBits.constprop.2+0x12c>
d0006f52:	4918      	ldr	r1, [pc, #96]	; (d0006fb4 <getBits.constprop.2+0x124>)
d0006f54:	f89c e000 	ldrb.w	lr, [ip]
d0006f58:	780b      	ldrb	r3, [r1, #0]
d0006f5a:	f10e 0e02 	add.w	lr, lr, #2
d0006f5e:	1e9a      	subs	r2, r3, #2
d0006f60:	3b01      	subs	r3, #1
d0006f62:	f88c e000 	strb.w	lr, [ip]
d0006f66:	b2d2      	uxtb	r2, r2
d0006f68:	f8df c054 	ldr.w	ip, [pc, #84]	; d0006fc0 <getBits.constprop.2+0x130>
d0006f6c:	b2db      	uxtb	r3, r3
d0006f6e:	700a      	strb	r2, [r1, #0]
d0006f70:	f80c 0003 	strb.w	r0, [ip, r3]
d0006f74:	f80c 4002 	strb.w	r4, [ip, r2]
d0006f78:	e7b5      	b.n	d0006ee6 <getBits.constprop.2+0x56>
d0006f7a:	f7ff fadd 	bl	d0006538 <getChar>
d0006f7e:	2800      	cmp	r0, #0
d0006f80:	d0cb      	beq.n	d0006f1a <getBits.constprop.2+0x8a>
d0006f82:	f8df c038 	ldr.w	ip, [pc, #56]	; d0006fbc <getBits.constprop.2+0x12c>
d0006f86:	490b      	ldr	r1, [pc, #44]	; (d0006fb4 <getBits.constprop.2+0x124>)
d0006f88:	f89c e000 	ldrb.w	lr, [ip]
d0006f8c:	780b      	ldrb	r3, [r1, #0]
d0006f8e:	f10e 0e02 	add.w	lr, lr, #2
d0006f92:	1e9a      	subs	r2, r3, #2
d0006f94:	3b01      	subs	r3, #1
d0006f96:	f88c e000 	strb.w	lr, [ip]
d0006f9a:	b2d2      	uxtb	r2, r2
d0006f9c:	f8df c020 	ldr.w	ip, [pc, #32]	; d0006fc0 <getBits.constprop.2+0x130>
d0006fa0:	b2db      	uxtb	r3, r3
d0006fa2:	700a      	strb	r2, [r1, #0]
d0006fa4:	f80c 0003 	strb.w	r0, [ip, r3]
d0006fa8:	f80c 4002 	strb.w	r4, [ip, r2]
d0006fac:	e7b5      	b.n	d0006f1a <getBits.constprop.2+0x8a>
d0006fae:	bf00      	nop
d0006fb0:	d000ded0 	.word	0xd000ded0
d0006fb4:	d000e3d9 	.word	0xd000e3d9
d0006fb8:	d000ded2 	.word	0xd000ded2
d0006fbc:	d000e3d8 	.word	0xd000e3d8
d0006fc0:	d000e2d8 	.word	0xd000e2d8

d0006fc4 <getBits>:
d0006fc4:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0006fc8:	2808      	cmp	r0, #8
d0006fca:	4f4a      	ldr	r7, [pc, #296]	; (d00070f4 <getBits+0x130>)
d0006fcc:	4604      	mov	r4, r0
d0006fce:	460e      	mov	r6, r1
d0006fd0:	f8b7 a000 	ldrh.w	sl, [r7]
d0006fd4:	f8df 812c 	ldr.w	r8, [pc, #300]	; d0007104 <getBits+0x140>
d0006fd8:	d813      	bhi.n	d0007002 <getBits+0x3e>
d0006fda:	4681      	mov	r9, r0
d0006fdc:	f898 2000 	ldrb.w	r2, [r8]
d0006fe0:	4653      	mov	r3, sl
d0006fe2:	4591      	cmp	r9, r2
d0006fe4:	d82f      	bhi.n	d0007046 <getBits+0x82>
d0006fe6:	f1c4 0410 	rsb	r4, r4, #16
d0006fea:	eba2 0209 	sub.w	r2, r2, r9
d0006fee:	fa03 f309 	lsl.w	r3, r3, r9
d0006ff2:	fa4a f404 	asr.w	r4, sl, r4
d0006ff6:	f888 2000 	strb.w	r2, [r8]
d0006ffa:	803b      	strh	r3, [r7, #0]
d0006ffc:	b2a0      	uxth	r0, r4
d0006ffe:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0007002:	f1a0 0308 	sub.w	r3, r0, #8
d0007006:	f898 2000 	ldrb.w	r2, [r8]
d000700a:	fa5f f983 	uxtb.w	r9, r3
d000700e:	fa0a f302 	lsl.w	r3, sl, r2
d0007012:	803b      	strh	r3, [r7, #0]
d0007014:	f7ff fa90 	bl	d0006538 <getChar>
d0007018:	28ff      	cmp	r0, #255	; 0xff
d000701a:	4605      	mov	r5, r0
d000701c:	d101      	bne.n	d0007022 <getBits+0x5e>
d000701e:	07f2      	lsls	r2, r6, #31
d0007020:	d449      	bmi.n	d00070b6 <getBits+0xf2>
d0007022:	883b      	ldrh	r3, [r7, #0]
d0007024:	f02a 0aff 	bic.w	sl, sl, #255	; 0xff
d0007028:	f898 2000 	ldrb.w	r2, [r8]
d000702c:	431d      	orrs	r5, r3
d000702e:	f1c2 0308 	rsb	r3, r2, #8
d0007032:	4591      	cmp	r9, r2
d0007034:	b2ad      	uxth	r5, r5
d0007036:	fa05 f503 	lsl.w	r5, r5, r3
d000703a:	f3c5 2107 	ubfx	r1, r5, #8, #8
d000703e:	b2ab      	uxth	r3, r5
d0007040:	ea4a 0a01 	orr.w	sl, sl, r1
d0007044:	d9cf      	bls.n	d0006fe6 <getBits+0x22>
d0007046:	fa03 f202 	lsl.w	r2, r3, r2
d000704a:	803a      	strh	r2, [r7, #0]
d000704c:	f7ff fa74 	bl	d0006538 <getChar>
d0007050:	28ff      	cmp	r0, #255	; 0xff
d0007052:	4605      	mov	r5, r0
d0007054:	d101      	bne.n	d000705a <getBits+0x96>
d0007056:	07f3      	lsls	r3, r6, #31
d0007058:	d414      	bmi.n	d0007084 <getBits+0xc0>
d000705a:	8838      	ldrh	r0, [r7, #0]
d000705c:	f1c4 0410 	rsb	r4, r4, #16
d0007060:	f898 3000 	ldrb.w	r3, [r8]
d0007064:	4305      	orrs	r5, r0
d0007066:	fa4a f404 	asr.w	r4, sl, r4
d000706a:	eba9 0203 	sub.w	r2, r9, r3
d000706e:	3308      	adds	r3, #8
d0007070:	b2ad      	uxth	r5, r5
d0007072:	eba3 0309 	sub.w	r3, r3, r9
d0007076:	b2a0      	uxth	r0, r4
d0007078:	4095      	lsls	r5, r2
d000707a:	f888 3000 	strb.w	r3, [r8]
d000707e:	803d      	strh	r5, [r7, #0]
d0007080:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0007084:	f7ff fa58 	bl	d0006538 <getChar>
d0007088:	2800      	cmp	r0, #0
d000708a:	d0e6      	beq.n	d000705a <getBits+0x96>
d000708c:	4e1a      	ldr	r6, [pc, #104]	; (d00070f8 <getBits+0x134>)
d000708e:	f04f 0cff 	mov.w	ip, #255	; 0xff
d0007092:	491a      	ldr	r1, [pc, #104]	; (d00070fc <getBits+0x138>)
d0007094:	7833      	ldrb	r3, [r6, #0]
d0007096:	f891 e000 	ldrb.w	lr, [r1]
d000709a:	1e9a      	subs	r2, r3, #2
d000709c:	3b01      	subs	r3, #1
d000709e:	f10e 0e02 	add.w	lr, lr, #2
d00070a2:	b2d2      	uxtb	r2, r2
d00070a4:	b2db      	uxtb	r3, r3
d00070a6:	f881 e000 	strb.w	lr, [r1]
d00070aa:	7032      	strb	r2, [r6, #0]
d00070ac:	4e14      	ldr	r6, [pc, #80]	; (d0007100 <getBits+0x13c>)
d00070ae:	54f0      	strb	r0, [r6, r3]
d00070b0:	f806 c002 	strb.w	ip, [r6, r2]
d00070b4:	e7d1      	b.n	d000705a <getBits+0x96>
d00070b6:	f7ff fa3f 	bl	d0006538 <getChar>
d00070ba:	2800      	cmp	r0, #0
d00070bc:	d0b1      	beq.n	d0007022 <getBits+0x5e>
d00070be:	f8df e038 	ldr.w	lr, [pc, #56]	; d00070f8 <getBits+0x134>
d00070c2:	f04f 0bff 	mov.w	fp, #255	; 0xff
d00070c6:	f8df c034 	ldr.w	ip, [pc, #52]	; d00070fc <getBits+0x138>
d00070ca:	f89e 3000 	ldrb.w	r3, [lr]
d00070ce:	f89c 1000 	ldrb.w	r1, [ip]
d00070d2:	1e9a      	subs	r2, r3, #2
d00070d4:	3b01      	subs	r3, #1
d00070d6:	3102      	adds	r1, #2
d00070d8:	b2d2      	uxtb	r2, r2
d00070da:	b2db      	uxtb	r3, r3
d00070dc:	f88c 1000 	strb.w	r1, [ip]
d00070e0:	f88e 2000 	strb.w	r2, [lr]
d00070e4:	f8df e018 	ldr.w	lr, [pc, #24]	; d0007100 <getBits+0x13c>
d00070e8:	f80e 0003 	strb.w	r0, [lr, r3]
d00070ec:	f80e b002 	strb.w	fp, [lr, r2]
d00070f0:	e797      	b.n	d0007022 <getBits+0x5e>
d00070f2:	bf00      	nop
d00070f4:	d000ded0 	.word	0xd000ded0
d00070f8:	d000e3d9 	.word	0xd000e3d9
d00070fc:	d000e3d8 	.word	0xd000e3d8
d0007100:	d000e2d8 	.word	0xd000e2d8
d0007104:	d000ded2 	.word	0xd000ded2

d0007108 <pjpeg_decode_mcu>:
d0007108:	4b9b      	ldr	r3, [pc, #620]	; (d0007378 <pjpeg_decode_mcu+0x270>)
d000710a:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d000710e:	b08f      	sub	sp, #60	; 0x3c
d0007110:	781b      	ldrb	r3, [r3, #0]
d0007112:	9303      	str	r3, [sp, #12]
d0007114:	2b00      	cmp	r3, #0
d0007116:	f040 80b0 	bne.w	d000727a <pjpeg_decode_mcu+0x172>
d000711a:	4b98      	ldr	r3, [pc, #608]	; (d000737c <pjpeg_decode_mcu+0x274>)
d000711c:	4a98      	ldr	r2, [pc, #608]	; (d0007380 <pjpeg_decode_mcu+0x278>)
d000711e:	881b      	ldrh	r3, [r3, #0]
d0007120:	8812      	ldrh	r2, [r2, #0]
d0007122:	431a      	orrs	r2, r3
d0007124:	f000 80c9 	beq.w	d00072ba <pjpeg_decode_mcu+0x1b2>
d0007128:	4e96      	ldr	r6, [pc, #600]	; (d0007384 <pjpeg_decode_mcu+0x27c>)
d000712a:	8832      	ldrh	r2, [r6, #0]
d000712c:	2a00      	cmp	r2, #0
d000712e:	f040 80a8 	bne.w	d0007282 <pjpeg_decode_mcu+0x17a>
d0007132:	4a95      	ldr	r2, [pc, #596]	; (d0007388 <pjpeg_decode_mcu+0x280>)
d0007134:	920c      	str	r2, [sp, #48]	; 0x30
d0007136:	7812      	ldrb	r2, [r2, #0]
d0007138:	2a00      	cmp	r2, #0
d000713a:	f000 8090 	beq.w	d000725e <pjpeg_decode_mcu+0x156>
d000713e:	4a93      	ldr	r2, [pc, #588]	; (d000738c <pjpeg_decode_mcu+0x284>)
d0007140:	2300      	movs	r3, #0
d0007142:	f8df b2a8 	ldr.w	fp, [pc, #680]	; d00073ec <pjpeg_decode_mcu+0x2e4>
d0007146:	920d      	str	r2, [sp, #52]	; 0x34
d0007148:	4a91      	ldr	r2, [pc, #580]	; (d0007390 <pjpeg_decode_mcu+0x288>)
d000714a:	9305      	str	r3, [sp, #20]
d000714c:	9202      	str	r2, [sp, #8]
d000714e:	9301      	str	r3, [sp, #4]
d0007150:	4b90      	ldr	r3, [pc, #576]	; (d0007394 <pjpeg_decode_mcu+0x28c>)
d0007152:	9a01      	ldr	r2, [sp, #4]
d0007154:	4990      	ldr	r1, [pc, #576]	; (d0007398 <pjpeg_decode_mcu+0x290>)
d0007156:	5c9c      	ldrb	r4, [r3, r2]
d0007158:	4b90      	ldr	r3, [pc, #576]	; (d000739c <pjpeg_decode_mcu+0x294>)
d000715a:	4a91      	ldr	r2, [pc, #580]	; (d00073a0 <pjpeg_decode_mcu+0x298>)
d000715c:	5d18      	ldrb	r0, [r3, r4]
d000715e:	4b91      	ldr	r3, [pc, #580]	; (d00073a4 <pjpeg_decode_mcu+0x29c>)
d0007160:	2800      	cmp	r0, #0
d0007162:	bf08      	it	eq
d0007164:	4611      	moveq	r1, r2
d0007166:	4e90      	ldr	r6, [pc, #576]	; (d00073a8 <pjpeg_decode_mcu+0x2a0>)
d0007168:	5d1b      	ldrb	r3, [r3, r4]
d000716a:	4f90      	ldr	r7, [pc, #576]	; (d00073ac <pjpeg_decode_mcu+0x2a4>)
d000716c:	2b00      	cmp	r3, #0
d000716e:	4b90      	ldr	r3, [pc, #576]	; (d00073b0 <pjpeg_decode_mcu+0x2a8>)
d0007170:	9104      	str	r1, [sp, #16]
d0007172:	bf18      	it	ne
d0007174:	461e      	movne	r6, r3
d0007176:	4b8f      	ldr	r3, [pc, #572]	; (d00073b4 <pjpeg_decode_mcu+0x2ac>)
d0007178:	498f      	ldr	r1, [pc, #572]	; (d00073b8 <pjpeg_decode_mcu+0x2b0>)
d000717a:	bf08      	it	eq
d000717c:	4639      	moveq	r1, r7
d000717e:	881a      	ldrh	r2, [r3, #0]
d0007180:	9b02      	ldr	r3, [sp, #8]
d0007182:	ea4f 38d2 	mov.w	r8, r2, lsr #15
d0007186:	9106      	str	r1, [sp, #24]
d0007188:	781b      	ldrb	r3, [r3, #0]
d000718a:	2b00      	cmp	r3, #0
d000718c:	f000 87a0 	beq.w	d00080d0 <pjpeg_decode_mcu+0xfc8>
d0007190:	3b01      	subs	r3, #1
d0007192:	9902      	ldr	r1, [sp, #8]
d0007194:	0052      	lsls	r2, r2, #1
d0007196:	2700      	movs	r7, #0
d0007198:	b2db      	uxtb	r3, r3
d000719a:	9607      	str	r6, [sp, #28]
d000719c:	b292      	uxth	r2, r2
d000719e:	f8df 9248 	ldr.w	r9, [pc, #584]	; d00073e8 <pjpeg_decode_mcu+0x2e0>
d00071a2:	700b      	strb	r3, [r1, #0]
d00071a4:	fa1f fc88 	uxth.w	ip, r8
d00071a8:	4982      	ldr	r1, [pc, #520]	; (d00073b4 <pjpeg_decode_mcu+0x2ac>)
d00071aa:	f106 081e 	add.w	r8, r6, #30
d00071ae:	463e      	mov	r6, r7
d00071b0:	800a      	strh	r2, [r1, #0]
d00071b2:	e00c      	b.n	d00071ce <pjpeg_decode_mcu+0xc6>
d00071b4:	0052      	lsls	r2, r2, #1
d00071b6:	497f      	ldr	r1, [pc, #508]	; (d00073b4 <pjpeg_decode_mcu+0x2ac>)
d00071b8:	3b01      	subs	r3, #1
d00071ba:	2e10      	cmp	r6, #16
d00071bc:	b292      	uxth	r2, r2
d00071be:	ea45 0c0a 	orr.w	ip, r5, sl
d00071c2:	b2db      	uxtb	r3, r3
d00071c4:	800a      	strh	r2, [r1, #0]
d00071c6:	9902      	ldr	r1, [sp, #8]
d00071c8:	700b      	strb	r3, [r1, #0]
d00071ca:	f000 8095 	beq.w	d00072f8 <pjpeg_decode_mcu+0x1f0>
d00071ce:	f838 0f02 	ldrh.w	r0, [r8, #2]!
d00071d2:	ea4f 054c 	mov.w	r5, ip, lsl #1
d00071d6:	f64f 77ff 	movw	r7, #65535	; 0xffff
d00071da:	ea4f 3ad2 	mov.w	sl, r2, lsr #15
d00071de:	4560      	cmp	r0, ip
d00071e0:	b2ad      	uxth	r5, r5
d00071e2:	d302      	bcc.n	d00071ea <pjpeg_decode_mcu+0xe2>
d00071e4:	42b8      	cmp	r0, r7
d00071e6:	f040 866e 	bne.w	d0007ec6 <pjpeg_decode_mcu+0xdbe>
d00071ea:	3601      	adds	r6, #1
d00071ec:	2b00      	cmp	r3, #0
d00071ee:	d1e1      	bne.n	d00071b4 <pjpeg_decode_mcu+0xac>
d00071f0:	f7ff f9a2 	bl	d0006538 <getChar>
d00071f4:	28ff      	cmp	r0, #255	; 0xff
d00071f6:	4607      	mov	r7, r0
d00071f8:	d065      	beq.n	d00072c6 <pjpeg_decode_mcu+0x1be>
d00071fa:	4b6e      	ldr	r3, [pc, #440]	; (d00073b4 <pjpeg_decode_mcu+0x2ac>)
d00071fc:	881a      	ldrh	r2, [r3, #0]
d00071fe:	9b02      	ldr	r3, [sp, #8]
d0007200:	433a      	orrs	r2, r7
d0007202:	781b      	ldrb	r3, [r3, #0]
d0007204:	b292      	uxth	r2, r2
d0007206:	3308      	adds	r3, #8
d0007208:	b2db      	uxtb	r3, r3
d000720a:	e7d3      	b.n	d00071b4 <pjpeg_decode_mcu+0xac>
d000720c:	4a6b      	ldr	r2, [pc, #428]	; (d00073bc <pjpeg_decode_mcu+0x2b4>)
d000720e:	8813      	ldrh	r3, [r2, #0]
d0007210:	f103 01d0 	add.w	r1, r3, #208	; 0xd0
d0007214:	4288      	cmp	r0, r1
d0007216:	d14b      	bne.n	d00072b0 <pjpeg_decode_mcu+0x1a8>
d0007218:	3301      	adds	r3, #1
d000721a:	8830      	ldrh	r0, [r6, #0]
d000721c:	2100      	movs	r1, #0
d000721e:	4d5b      	ldr	r5, [pc, #364]	; (d000738c <pjpeg_decode_mcu+0x284>)
d0007220:	f003 0307 	and.w	r3, r3, #7
d0007224:	4e5a      	ldr	r6, [pc, #360]	; (d0007390 <pjpeg_decode_mcu+0x288>)
d0007226:	8020      	strh	r0, [r4, #0]
d0007228:	2001      	movs	r0, #1
d000722a:	8013      	strh	r3, [r2, #0]
d000722c:	2308      	movs	r3, #8
d000722e:	6029      	str	r1, [r5, #0]
d0007230:	7033      	strb	r3, [r6, #0]
d0007232:	80a9      	strh	r1, [r5, #4]
d0007234:	f7ff f9ba 	bl	d00065ac <getBits.constprop.1>
d0007238:	2001      	movs	r0, #1
d000723a:	f7ff f9b7 	bl	d00065ac <getBits.constprop.1>
d000723e:	8823      	ldrh	r3, [r4, #0]
d0007240:	4a51      	ldr	r2, [pc, #324]	; (d0007388 <pjpeg_decode_mcu+0x280>)
d0007242:	3b01      	subs	r3, #1
d0007244:	8023      	strh	r3, [r4, #0]
d0007246:	7813      	ldrb	r3, [r2, #0]
d0007248:	920c      	str	r2, [sp, #48]	; 0x30
d000724a:	2b00      	cmp	r3, #0
d000724c:	f47f af77 	bne.w	d000713e <pjpeg_decode_mcu+0x36>
d0007250:	4b49      	ldr	r3, [pc, #292]	; (d0007378 <pjpeg_decode_mcu+0x270>)
d0007252:	781b      	ldrb	r3, [r3, #0]
d0007254:	2b00      	cmp	r3, #0
d0007256:	f040 87b5 	bne.w	d00081c4 <pjpeg_decode_mcu+0x10bc>
d000725a:	4b48      	ldr	r3, [pc, #288]	; (d000737c <pjpeg_decode_mcu+0x274>)
d000725c:	881b      	ldrh	r3, [r3, #0]
d000725e:	3b01      	subs	r3, #1
d0007260:	4a46      	ldr	r2, [pc, #280]	; (d000737c <pjpeg_decode_mcu+0x274>)
d0007262:	b29b      	uxth	r3, r3
d0007264:	8013      	strh	r3, [r2, #0]
d0007266:	b943      	cbnz	r3, d000727a <pjpeg_decode_mcu+0x172>
d0007268:	4945      	ldr	r1, [pc, #276]	; (d0007380 <pjpeg_decode_mcu+0x278>)
d000726a:	880b      	ldrh	r3, [r1, #0]
d000726c:	3b01      	subs	r3, #1
d000726e:	b29b      	uxth	r3, r3
d0007270:	800b      	strh	r3, [r1, #0]
d0007272:	b113      	cbz	r3, d000727a <pjpeg_decode_mcu+0x172>
d0007274:	4b52      	ldr	r3, [pc, #328]	; (d00073c0 <pjpeg_decode_mcu+0x2b8>)
d0007276:	881b      	ldrh	r3, [r3, #0]
d0007278:	8013      	strh	r3, [r2, #0]
d000727a:	9803      	ldr	r0, [sp, #12]
d000727c:	b00f      	add	sp, #60	; 0x3c
d000727e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0007282:	4c50      	ldr	r4, [pc, #320]	; (d00073c4 <pjpeg_decode_mcu+0x2bc>)
d0007284:	8823      	ldrh	r3, [r4, #0]
d0007286:	2b00      	cmp	r3, #0
d0007288:	d1da      	bne.n	d0007240 <pjpeg_decode_mcu+0x138>
d000728a:	f44f 65c0 	mov.w	r5, #1536	; 0x600
d000728e:	e001      	b.n	d0007294 <pjpeg_decode_mcu+0x18c>
d0007290:	b29d      	uxth	r5, r3
d0007292:	b16d      	cbz	r5, d00072b0 <pjpeg_decode_mcu+0x1a8>
d0007294:	f7ff f950 	bl	d0006538 <getChar>
d0007298:	28ff      	cmp	r0, #255	; 0xff
d000729a:	f105 33ff 	add.w	r3, r5, #4294967295	; 0xffffffff
d000729e:	d1f7      	bne.n	d0007290 <pjpeg_decode_mcu+0x188>
d00072a0:	3d01      	subs	r5, #1
d00072a2:	f7ff f949 	bl	d0006538 <getChar>
d00072a6:	28ff      	cmp	r0, #255	; 0xff
d00072a8:	b2ad      	uxth	r5, r5
d00072aa:	d1af      	bne.n	d000720c <pjpeg_decode_mcu+0x104>
d00072ac:	2d00      	cmp	r5, #0
d00072ae:	d1f7      	bne.n	d00072a0 <pjpeg_decode_mcu+0x198>
d00072b0:	231d      	movs	r3, #29
d00072b2:	461a      	mov	r2, r3
d00072b4:	9303      	str	r3, [sp, #12]
d00072b6:	f000 bf1d 	b.w	d00080f4 <pjpeg_decode_mcu+0xfec>
d00072ba:	2301      	movs	r3, #1
d00072bc:	9303      	str	r3, [sp, #12]
d00072be:	9803      	ldr	r0, [sp, #12]
d00072c0:	b00f      	add	sp, #60	; 0x3c
d00072c2:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00072c6:	f7ff f937 	bl	d0006538 <getChar>
d00072ca:	2800      	cmp	r0, #0
d00072cc:	d095      	beq.n	d00071fa <pjpeg_decode_mcu+0xf2>
d00072ce:	4a3e      	ldr	r2, [pc, #248]	; (d00073c8 <pjpeg_decode_mcu+0x2c0>)
d00072d0:	493e      	ldr	r1, [pc, #248]	; (d00073cc <pjpeg_decode_mcu+0x2c4>)
d00072d2:	f892 c000 	ldrb.w	ip, [r2]
d00072d6:	780b      	ldrb	r3, [r1, #0]
d00072d8:	4611      	mov	r1, r2
d00072da:	f10c 0c02 	add.w	ip, ip, #2
d00072de:	1e5a      	subs	r2, r3, #1
d00072e0:	3b02      	subs	r3, #2
d00072e2:	f881 c000 	strb.w	ip, [r1]
d00072e6:	b2db      	uxtb	r3, r3
d00072e8:	4938      	ldr	r1, [pc, #224]	; (d00073cc <pjpeg_decode_mcu+0x2c4>)
d00072ea:	b2d2      	uxtb	r2, r2
d00072ec:	700b      	strb	r3, [r1, #0]
d00072ee:	f809 0002 	strb.w	r0, [r9, r2]
d00072f2:	f809 7003 	strb.w	r7, [r9, r3]
d00072f6:	e780      	b.n	d00071fa <pjpeg_decode_mcu+0xf2>
d00072f8:	2000      	movs	r0, #0
d00072fa:	9f0d      	ldr	r7, [sp, #52]	; 0x34
d00072fc:	9904      	ldr	r1, [sp, #16]
d00072fe:	f837 5014 	ldrh.w	r5, [r7, r4, lsl #1]
d0007302:	8809      	ldrh	r1, [r1, #0]
d0007304:	4428      	add	r0, r5
d0007306:	4d32      	ldr	r5, [pc, #200]	; (d00073d0 <pjpeg_decode_mcu+0x2c8>)
d0007308:	4e32      	ldr	r6, [pc, #200]	; (d00073d4 <pjpeg_decode_mcu+0x2cc>)
d000730a:	b280      	uxth	r0, r0
d000730c:	782d      	ldrb	r5, [r5, #0]
d000730e:	5d36      	ldrb	r6, [r6, r4]
d0007310:	fb11 f100 	smulbb	r1, r1, r0
d0007314:	f827 0014 	strh.w	r0, [r7, r4, lsl #1]
d0007318:	f8ab 1000 	strh.w	r1, [fp]
d000731c:	2d00      	cmp	r5, #0
d000731e:	f000 81e7 	beq.w	d00076f0 <pjpeg_decode_mcu+0x5e8>
d0007322:	2e00      	cmp	r6, #0
d0007324:	482c      	ldr	r0, [pc, #176]	; (d00073d8 <pjpeg_decode_mcu+0x2d0>)
d0007326:	492d      	ldr	r1, [pc, #180]	; (d00073dc <pjpeg_decode_mcu+0x2d4>)
d0007328:	f04f 0401 	mov.w	r4, #1
d000732c:	bf08      	it	eq
d000732e:	4607      	moveq	r7, r0
d0007330:	482b      	ldr	r0, [pc, #172]	; (d00073e0 <pjpeg_decode_mcu+0x2d8>)
d0007332:	bf18      	it	ne
d0007334:	460f      	movne	r7, r1
d0007336:	492b      	ldr	r1, [pc, #172]	; (d00073e4 <pjpeg_decode_mcu+0x2dc>)
d0007338:	bf08      	it	eq
d000733a:	4601      	moveq	r1, r0
d000733c:	4e2a      	ldr	r6, [pc, #168]	; (d00073e8 <pjpeg_decode_mcu+0x2e0>)
d000733e:	f8dd 8008 	ldr.w	r8, [sp, #8]
d0007342:	9107      	str	r1, [sp, #28]
d0007344:	f107 011e 	add.w	r1, r7, #30
d0007348:	9108      	str	r1, [sp, #32]
d000734a:	ea4f 3ad2 	mov.w	sl, r2, lsr #15
d000734e:	2b00      	cmp	r3, #0
d0007350:	d07a      	beq.n	d0007448 <pjpeg_decode_mcu+0x340>
d0007352:	0050      	lsls	r0, r2, #1
d0007354:	3b01      	subs	r3, #1
d0007356:	fa1f fc8a 	uxth.w	ip, sl
d000735a:	4a16      	ldr	r2, [pc, #88]	; (d00073b4 <pjpeg_decode_mcu+0x2ac>)
d000735c:	f04f 0a00 	mov.w	sl, #0
d0007360:	b2db      	uxtb	r3, r3
d0007362:	b280      	uxth	r0, r0
d0007364:	9406      	str	r4, [sp, #24]
d0007366:	f8dd 9020 	ldr.w	r9, [sp, #32]
d000736a:	4654      	mov	r4, sl
d000736c:	f888 3000 	strb.w	r3, [r8]
d0007370:	46ba      	mov	sl, r7
d0007372:	8010      	strh	r0, [r2, #0]
d0007374:	4647      	mov	r7, r8
d0007376:	e047      	b.n	d0007408 <pjpeg_decode_mcu+0x300>
d0007378:	d000ded3 	.word	0xd000ded3
d000737c:	d000e6f4 	.word	0xd000e6f4
d0007380:	d000e6f6 	.word	0xd000e6f6
d0007384:	d000e7fa 	.word	0xd000e7fa
d0007388:	d000e6ea 	.word	0xd000e6ea
d000738c:	d000e3dc 	.word	0xd000e3dc
d0007390:	d000ded2 	.word	0xd000ded2
d0007394:	d000e6e4 	.word	0xd000e6e4
d0007398:	d000e778 	.word	0xd000e778
d000739c:	d000df68 	.word	0xd000df68
d00073a0:	d000e6f8 	.word	0xd000e6f8
d00073a4:	d000df58 	.word	0xd000df58
d00073a8:	d000df74 	.word	0xd000df74
d00073ac:	d000e0b4 	.word	0xd000e0b4
d00073b0:	d000dfc4 	.word	0xd000dfc4
d00073b4:	d000ded0 	.word	0xd000ded0
d00073b8:	d000e0c4 	.word	0xd000e0c4
d00073bc:	d000e6f2 	.word	0xd000e6f2
d00073c0:	d000e6ee 	.word	0xd000e6ee
d00073c4:	d000e7fc 	.word	0xd000e7fc
d00073c8:	d000e3d8 	.word	0xd000e3d8
d00073cc:	d000e3d9 	.word	0xd000e3d9
d00073d0:	d000e7f8 	.word	0xd000e7f8
d00073d4:	d000df54 	.word	0xd000df54
d00073d8:	d000e014 	.word	0xd000e014
d00073dc:	d000e064 	.word	0xd000e064
d00073e0:	d000e0d4 	.word	0xd000e0d4
d00073e4:	d000e1d4 	.word	0xd000e1d4
d00073e8:	d000e2d8 	.word	0xd000e2d8
d00073ec:	d000ded4 	.word	0xd000ded4
d00073f0:	9a04      	ldr	r2, [sp, #16]
d00073f2:	0040      	lsls	r0, r0, #1
d00073f4:	3b01      	subs	r3, #1
d00073f6:	2c10      	cmp	r4, #16
d00073f8:	ea45 0c02 	orr.w	ip, r5, r2
d00073fc:	b280      	uxth	r0, r0
d00073fe:	b2db      	uxtb	r3, r3
d0007400:	4ab5      	ldr	r2, [pc, #724]	; (d00076d8 <pjpeg_decode_mcu+0x5d0>)
d0007402:	703b      	strb	r3, [r7, #0]
d0007404:	8010      	strh	r0, [r2, #0]
d0007406:	d02f      	beq.n	d0007468 <pjpeg_decode_mcu+0x360>
d0007408:	f839 ef02 	ldrh.w	lr, [r9, #2]!
d000740c:	ea4f 054c 	mov.w	r5, ip, lsl #1
d0007410:	0bc2      	lsrs	r2, r0, #15
d0007412:	f64f 78ff 	movw	r8, #65535	; 0xffff
d0007416:	45e6      	cmp	lr, ip
d0007418:	b2ad      	uxth	r5, r5
d000741a:	9204      	str	r2, [sp, #16]
d000741c:	d302      	bcc.n	d0007424 <pjpeg_decode_mcu+0x31c>
d000741e:	45c6      	cmp	lr, r8
d0007420:	f040 8128 	bne.w	d0007674 <pjpeg_decode_mcu+0x56c>
d0007424:	3401      	adds	r4, #1
d0007426:	2b00      	cmp	r3, #0
d0007428:	d1e2      	bne.n	d00073f0 <pjpeg_decode_mcu+0x2e8>
d000742a:	f7ff f885 	bl	d0006538 <getChar>
d000742e:	28ff      	cmp	r0, #255	; 0xff
d0007430:	4680      	mov	r8, r0
d0007432:	f000 80ef 	beq.w	d0007614 <pjpeg_decode_mcu+0x50c>
d0007436:	4ba8      	ldr	r3, [pc, #672]	; (d00076d8 <pjpeg_decode_mcu+0x5d0>)
d0007438:	8818      	ldrh	r0, [r3, #0]
d000743a:	783b      	ldrb	r3, [r7, #0]
d000743c:	ea48 0000 	orr.w	r0, r8, r0
d0007440:	3308      	adds	r3, #8
d0007442:	b280      	uxth	r0, r0
d0007444:	b2db      	uxtb	r3, r3
d0007446:	e7d3      	b.n	d00073f0 <pjpeg_decode_mcu+0x2e8>
d0007448:	f7ff f876 	bl	d0006538 <getChar>
d000744c:	28ff      	cmp	r0, #255	; 0xff
d000744e:	4681      	mov	r9, r0
d0007450:	f000 80fa 	beq.w	d0007648 <pjpeg_decode_mcu+0x540>
d0007454:	4ba0      	ldr	r3, [pc, #640]	; (d00076d8 <pjpeg_decode_mcu+0x5d0>)
d0007456:	881a      	ldrh	r2, [r3, #0]
d0007458:	f898 3000 	ldrb.w	r3, [r8]
d000745c:	ea49 0202 	orr.w	r2, r9, r2
d0007460:	3308      	adds	r3, #8
d0007462:	b292      	uxth	r2, r2
d0007464:	b2db      	uxtb	r3, r3
d0007466:	e774      	b.n	d0007352 <pjpeg_decode_mcu+0x24a>
d0007468:	f9bb 3000 	ldrsh.w	r3, [fp]
d000746c:	4a9b      	ldr	r2, [pc, #620]	; (d00076dc <pjpeg_decode_mcu+0x5d4>)
d000746e:	3340      	adds	r3, #64	; 0x40
d0007470:	7812      	ldrb	r2, [r2, #0]
d0007472:	11db      	asrs	r3, r3, #7
d0007474:	3380      	adds	r3, #128	; 0x80
d0007476:	b29b      	uxth	r3, r3
d0007478:	2bff      	cmp	r3, #255	; 0xff
d000747a:	bf84      	itt	hi
d000747c:	43db      	mvnhi	r3, r3
d000747e:	f343 33c0 	sbfxhi	r3, r3, #15, #1
d0007482:	b2db      	uxtb	r3, r3
d0007484:	2a04      	cmp	r2, #4
d0007486:	f200 80ba 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000748a:	e8df f012 	tbh	[pc, r2, lsl #1]
d000748e:	064f      	.short	0x064f
d0007490:	001b063d 	.word	0x001b063d
d0007494:	00050011 	.word	0x00050011
d0007498:	9a01      	ldr	r2, [sp, #4]
d000749a:	2a05      	cmp	r2, #5
d000749c:	f200 80af 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00074a0:	e8df f012 	tbh	[pc, r2, lsl #1]
d00074a4:	0695063c 	.word	0x0695063c
d00074a8:	086306a0 	.word	0x086306a0
d00074ac:	001a0874 	.word	0x001a0874
d00074b0:	9a01      	ldr	r2, [sp, #4]
d00074b2:	2a03      	cmp	r2, #3
d00074b4:	f200 80a3 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00074b8:	e8df f012 	tbh	[pc, r2, lsl #1]
d00074bc:	06940630 	.word	0x06940630
d00074c0:	078c073a 	.word	0x078c073a
d00074c4:	9a01      	ldr	r2, [sp, #4]
d00074c6:	2a03      	cmp	r2, #3
d00074c8:	f200 8099 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00074cc:	e8df f012 	tbh	[pc, r2, lsl #1]
d00074d0:	067f0626 	.word	0x067f0626
d00074d4:	06bd07d7 	.word	0x06bd07d7
d00074d8:	eb03 0043 	add.w	r0, r3, r3, lsl #1
d00074dc:	f1a3 04b3 	sub.w	r4, r3, #179	; 0xb3
d00074e0:	b21a      	sxth	r2, r3
d00074e2:	497f      	ldr	r1, [pc, #508]	; (d00076e0 <pjpeg_decode_mcu+0x5d8>)
d00074e4:	eb00 1000 	add.w	r0, r0, r0, lsl #4
d00074e8:	eb03 0340 	add.w	r3, r3, r0, lsl #1
d00074ec:	7808      	ldrb	r0, [r1, #0]
d00074ee:	eb04 2313 	add.w	r3, r4, r3, lsr #8
d00074f2:	b29b      	uxth	r3, r3
d00074f4:	4418      	add	r0, r3
d00074f6:	b280      	uxth	r0, r0
d00074f8:	28ff      	cmp	r0, #255	; 0xff
d00074fa:	d906      	bls.n	d000750a <pjpeg_decode_mcu+0x402>
d00074fc:	b204      	sxth	r4, r0
d00074fe:	2c00      	cmp	r4, #0
d0007500:	f2c1 8211 	blt.w	d0008926 <pjpeg_decode_mcu+0x181e>
d0007504:	2cff      	cmp	r4, #255	; 0xff
d0007506:	f301 825e 	bgt.w	d00089c6 <pjpeg_decode_mcu+0x18be>
d000750a:	b2c4      	uxtb	r4, r0
d000750c:	f891 0040 	ldrb.w	r0, [r1, #64]	; 0x40
d0007510:	700c      	strb	r4, [r1, #0]
d0007512:	4418      	add	r0, r3
d0007514:	b280      	uxth	r0, r0
d0007516:	28ff      	cmp	r0, #255	; 0xff
d0007518:	d906      	bls.n	d0007528 <pjpeg_decode_mcu+0x420>
d000751a:	b204      	sxth	r4, r0
d000751c:	2c00      	cmp	r4, #0
d000751e:	f2c1 8205 	blt.w	d000892c <pjpeg_decode_mcu+0x1824>
d0007522:	2cff      	cmp	r4, #255	; 0xff
d0007524:	f301 8247 	bgt.w	d00089b6 <pjpeg_decode_mcu+0x18ae>
d0007528:	b2c4      	uxtb	r4, r0
d000752a:	f891 0080 	ldrb.w	r0, [r1, #128]	; 0x80
d000752e:	f881 4040 	strb.w	r4, [r1, #64]	; 0x40
d0007532:	4418      	add	r0, r3
d0007534:	b280      	uxth	r0, r0
d0007536:	28ff      	cmp	r0, #255	; 0xff
d0007538:	d906      	bls.n	d0007548 <pjpeg_decode_mcu+0x440>
d000753a:	b204      	sxth	r4, r0
d000753c:	2c00      	cmp	r4, #0
d000753e:	f2c1 81f8 	blt.w	d0008932 <pjpeg_decode_mcu+0x182a>
d0007542:	2cff      	cmp	r4, #255	; 0xff
d0007544:	f301 823a 	bgt.w	d00089bc <pjpeg_decode_mcu+0x18b4>
d0007548:	b2c0      	uxtb	r0, r0
d000754a:	f891 40c0 	ldrb.w	r4, [r1, #192]	; 0xc0
d000754e:	f881 0080 	strb.w	r0, [r1, #128]	; 0x80
d0007552:	4423      	add	r3, r4
d0007554:	b29b      	uxth	r3, r3
d0007556:	2bff      	cmp	r3, #255	; 0xff
d0007558:	d906      	bls.n	d0007568 <pjpeg_decode_mcu+0x460>
d000755a:	b218      	sxth	r0, r3
d000755c:	2800      	cmp	r0, #0
d000755e:	f2c1 81eb 	blt.w	d0008938 <pjpeg_decode_mcu+0x1830>
d0007562:	28ff      	cmp	r0, #255	; 0xff
d0007564:	f301 8221 	bgt.w	d00089aa <pjpeg_decode_mcu+0x18a2>
d0007568:	b2db      	uxtb	r3, r3
d000756a:	ebc2 1402 	rsb	r4, r2, r2, lsl #4
d000756e:	f881 30c0 	strb.w	r3, [r1, #192]	; 0xc0
d0007572:	485c      	ldr	r0, [pc, #368]	; (d00076e4 <pjpeg_decode_mcu+0x5dc>)
d0007574:	eb02 0284 	add.w	r2, r2, r4, lsl #2
d0007578:	7801      	ldrb	r1, [r0, #0]
d000757a:	ebc2 0282 	rsb	r2, r2, r2, lsl #2
d000757e:	0a13      	lsrs	r3, r2, #8
d0007580:	3b5b      	subs	r3, #91	; 0x5b
d0007582:	b29b      	uxth	r3, r3
d0007584:	1aca      	subs	r2, r1, r3
d0007586:	b292      	uxth	r2, r2
d0007588:	2aff      	cmp	r2, #255	; 0xff
d000758a:	d906      	bls.n	d000759a <pjpeg_decode_mcu+0x492>
d000758c:	b211      	sxth	r1, r2
d000758e:	2900      	cmp	r1, #0
d0007590:	f2c1 81d5 	blt.w	d000893e <pjpeg_decode_mcu+0x1836>
d0007594:	29ff      	cmp	r1, #255	; 0xff
d0007596:	f301 820b 	bgt.w	d00089b0 <pjpeg_decode_mcu+0x18a8>
d000759a:	b2d1      	uxtb	r1, r2
d000759c:	f890 2040 	ldrb.w	r2, [r0, #64]	; 0x40
d00075a0:	7001      	strb	r1, [r0, #0]
d00075a2:	1ad2      	subs	r2, r2, r3
d00075a4:	b292      	uxth	r2, r2
d00075a6:	2aff      	cmp	r2, #255	; 0xff
d00075a8:	d906      	bls.n	d00075b8 <pjpeg_decode_mcu+0x4b0>
d00075aa:	b211      	sxth	r1, r2
d00075ac:	2900      	cmp	r1, #0
d00075ae:	f2c1 81a6 	blt.w	d00088fe <pjpeg_decode_mcu+0x17f6>
d00075b2:	29ff      	cmp	r1, #255	; 0xff
d00075b4:	f301 81ee 	bgt.w	d0008994 <pjpeg_decode_mcu+0x188c>
d00075b8:	b2d1      	uxtb	r1, r2
d00075ba:	f890 2080 	ldrb.w	r2, [r0, #128]	; 0x80
d00075be:	f880 1040 	strb.w	r1, [r0, #64]	; 0x40
d00075c2:	1ad2      	subs	r2, r2, r3
d00075c4:	b292      	uxth	r2, r2
d00075c6:	2aff      	cmp	r2, #255	; 0xff
d00075c8:	d906      	bls.n	d00075d8 <pjpeg_decode_mcu+0x4d0>
d00075ca:	b211      	sxth	r1, r2
d00075cc:	2900      	cmp	r1, #0
d00075ce:	f2c1 8199 	blt.w	d0008904 <pjpeg_decode_mcu+0x17fc>
d00075d2:	29ff      	cmp	r1, #255	; 0xff
d00075d4:	f301 81e1 	bgt.w	d000899a <pjpeg_decode_mcu+0x1892>
d00075d8:	b2d1      	uxtb	r1, r2
d00075da:	f890 20c0 	ldrb.w	r2, [r0, #192]	; 0xc0
d00075de:	f880 1080 	strb.w	r1, [r0, #128]	; 0x80
d00075e2:	1ad3      	subs	r3, r2, r3
d00075e4:	b29b      	uxth	r3, r3
d00075e6:	2bff      	cmp	r3, #255	; 0xff
d00075e8:	d906      	bls.n	d00075f8 <pjpeg_decode_mcu+0x4f0>
d00075ea:	b21a      	sxth	r2, r3
d00075ec:	2a00      	cmp	r2, #0
d00075ee:	f2c1 8183 	blt.w	d00088f8 <pjpeg_decode_mcu+0x17f0>
d00075f2:	2aff      	cmp	r2, #255	; 0xff
d00075f4:	f301 81d6 	bgt.w	d00089a4 <pjpeg_decode_mcu+0x189c>
d00075f8:	b2db      	uxtb	r3, r3
d00075fa:	f880 30c0 	strb.w	r3, [r0, #192]	; 0xc0
d00075fe:	9a05      	ldr	r2, [sp, #20]
d0007600:	9b0c      	ldr	r3, [sp, #48]	; 0x30
d0007602:	3201      	adds	r2, #1
d0007604:	781b      	ldrb	r3, [r3, #0]
d0007606:	9205      	str	r2, [sp, #20]
d0007608:	b2d2      	uxtb	r2, r2
d000760a:	4293      	cmp	r3, r2
d000760c:	9201      	str	r2, [sp, #4]
d000760e:	f63f ad9f 	bhi.w	d0007150 <pjpeg_decode_mcu+0x48>
d0007612:	e61d      	b.n	d0007250 <pjpeg_decode_mcu+0x148>
d0007614:	f7fe ff90 	bl	d0006538 <getChar>
d0007618:	2800      	cmp	r0, #0
d000761a:	f43f af0c 	beq.w	d0007436 <pjpeg_decode_mcu+0x32e>
d000761e:	4a32      	ldr	r2, [pc, #200]	; (d00076e8 <pjpeg_decode_mcu+0x5e0>)
d0007620:	4932      	ldr	r1, [pc, #200]	; (d00076ec <pjpeg_decode_mcu+0x5e4>)
d0007622:	7813      	ldrb	r3, [r2, #0]
d0007624:	f891 e000 	ldrb.w	lr, [r1]
d0007628:	f103 3cff 	add.w	ip, r3, #4294967295	; 0xffffffff
d000762c:	3b02      	subs	r3, #2
d000762e:	f10e 0e02 	add.w	lr, lr, #2
d0007632:	b2db      	uxtb	r3, r3
d0007634:	fa5f fc8c 	uxtb.w	ip, ip
d0007638:	f881 e000 	strb.w	lr, [r1]
d000763c:	7013      	strb	r3, [r2, #0]
d000763e:	f806 000c 	strb.w	r0, [r6, ip]
d0007642:	f806 8003 	strb.w	r8, [r6, r3]
d0007646:	e6f6      	b.n	d0007436 <pjpeg_decode_mcu+0x32e>
d0007648:	f7fe ff76 	bl	d0006538 <getChar>
d000764c:	2800      	cmp	r0, #0
d000764e:	f43f af01 	beq.w	d0007454 <pjpeg_decode_mcu+0x34c>
d0007652:	4b25      	ldr	r3, [pc, #148]	; (d00076e8 <pjpeg_decode_mcu+0x5e0>)
d0007654:	4925      	ldr	r1, [pc, #148]	; (d00076ec <pjpeg_decode_mcu+0x5e4>)
d0007656:	781b      	ldrb	r3, [r3, #0]
d0007658:	460d      	mov	r5, r1
d000765a:	7809      	ldrb	r1, [r1, #0]
d000765c:	1e5a      	subs	r2, r3, #1
d000765e:	3b02      	subs	r3, #2
d0007660:	3102      	adds	r1, #2
d0007662:	b2d2      	uxtb	r2, r2
d0007664:	b2db      	uxtb	r3, r3
d0007666:	7029      	strb	r1, [r5, #0]
d0007668:	54b0      	strb	r0, [r6, r2]
d000766a:	4a1f      	ldr	r2, [pc, #124]	; (d00076e8 <pjpeg_decode_mcu+0x5e0>)
d000766c:	f806 9003 	strb.w	r9, [r6, r3]
d0007670:	7013      	strb	r3, [r2, #0]
d0007672:	e6ef      	b.n	d0007454 <pjpeg_decode_mcu+0x34c>
d0007674:	46b8      	mov	r8, r7
d0007676:	4657      	mov	r7, sl
d0007678:	46a2      	mov	sl, r4
d000767a:	9c06      	ldr	r4, [sp, #24]
d000767c:	eb07 030a 	add.w	r3, r7, sl
d0007680:	f817 201a 	ldrb.w	r2, [r7, sl, lsl #1]
d0007684:	f893 3040 	ldrb.w	r3, [r3, #64]	; 0x40
d0007688:	449c      	add	ip, r3
d000768a:	9b07      	ldr	r3, [sp, #28]
d000768c:	ebac 0c02 	sub.w	ip, ip, r2
d0007690:	f00c 0cff 	and.w	ip, ip, #255	; 0xff
d0007694:	f813 500c 	ldrb.w	r5, [r3, ip]
d0007698:	f015 000f 	ands.w	r0, r5, #15
d000769c:	d012      	beq.n	d00076c4 <pjpeg_decode_mcu+0x5bc>
d000769e:	f7ff fbf7 	bl	d0006e90 <getBits.constprop.2>
d00076a2:	092d      	lsrs	r5, r5, #4
d00076a4:	d004      	beq.n	d00076b0 <pjpeg_decode_mcu+0x5a8>
d00076a6:	442c      	add	r4, r5
d00076a8:	2c3f      	cmp	r4, #63	; 0x3f
d00076aa:	f300 8520 	bgt.w	d00080ee <pjpeg_decode_mcu+0xfe6>
d00076ae:	b2e4      	uxtb	r4, r4
d00076b0:	3401      	adds	r4, #1
d00076b2:	b2e4      	uxtb	r4, r4
d00076b4:	2c3f      	cmp	r4, #63	; 0x3f
d00076b6:	f63f aed7 	bhi.w	d0007468 <pjpeg_decode_mcu+0x360>
d00076ba:	4b07      	ldr	r3, [pc, #28]	; (d00076d8 <pjpeg_decode_mcu+0x5d0>)
d00076bc:	881a      	ldrh	r2, [r3, #0]
d00076be:	f898 3000 	ldrb.w	r3, [r8]
d00076c2:	e642      	b.n	d000734a <pjpeg_decode_mcu+0x242>
d00076c4:	092d      	lsrs	r5, r5, #4
d00076c6:	2d0f      	cmp	r5, #15
d00076c8:	f47f aece 	bne.w	d0007468 <pjpeg_decode_mcu+0x360>
d00076cc:	2c30      	cmp	r4, #48	; 0x30
d00076ce:	f200 850e 	bhi.w	d00080ee <pjpeg_decode_mcu+0xfe6>
d00076d2:	340f      	adds	r4, #15
d00076d4:	e7eb      	b.n	d00076ae <pjpeg_decode_mcu+0x5a6>
d00076d6:	bf00      	nop
d00076d8:	d000ded0 	.word	0xd000ded0
d00076dc:	d000e7fe 	.word	0xd000e7fe
d00076e0:	d000e5e4 	.word	0xd000e5e4
d00076e4:	d000e4e4 	.word	0xd000e4e4
d00076e8:	d000e3d9 	.word	0xd000e3d9
d00076ec:	d000e3d8 	.word	0xd000e3d8
d00076f0:	2e00      	cmp	r6, #0
d00076f2:	4896      	ldr	r0, [pc, #600]	; (d000794c <pjpeg_decode_mcu+0x844>)
d00076f4:	4996      	ldr	r1, [pc, #600]	; (d0007950 <pjpeg_decode_mcu+0x848>)
d00076f6:	f04f 0401 	mov.w	r4, #1
d00076fa:	bf08      	it	eq
d00076fc:	4606      	moveq	r6, r0
d00076fe:	4895      	ldr	r0, [pc, #596]	; (d0007954 <pjpeg_decode_mcu+0x84c>)
d0007700:	bf18      	it	ne
d0007702:	460e      	movne	r6, r1
d0007704:	4994      	ldr	r1, [pc, #592]	; (d0007958 <pjpeg_decode_mcu+0x850>)
d0007706:	bf08      	it	eq
d0007708:	4601      	moveq	r1, r0
d000770a:	4d94      	ldr	r5, [pc, #592]	; (d000795c <pjpeg_decode_mcu+0x854>)
d000770c:	f8dd 8008 	ldr.w	r8, [sp, #8]
d0007710:	9108      	str	r1, [sp, #32]
d0007712:	f106 011e 	add.w	r1, r6, #30
d0007716:	9109      	str	r1, [sp, #36]	; 0x24
d0007718:	ea4f 3ad2 	mov.w	sl, r2, lsr #15
d000771c:	2b00      	cmp	r3, #0
d000771e:	d03f      	beq.n	d00077a0 <pjpeg_decode_mcu+0x698>
d0007720:	0050      	lsls	r0, r2, #1
d0007722:	3b01      	subs	r3, #1
d0007724:	fa1f fc8a 	uxth.w	ip, sl
d0007728:	4a8d      	ldr	r2, [pc, #564]	; (d0007960 <pjpeg_decode_mcu+0x858>)
d000772a:	f04f 0a00 	mov.w	sl, #0
d000772e:	b2db      	uxtb	r3, r3
d0007730:	b280      	uxth	r0, r0
d0007732:	9607      	str	r6, [sp, #28]
d0007734:	f8dd 9024 	ldr.w	r9, [sp, #36]	; 0x24
d0007738:	4656      	mov	r6, sl
d000773a:	f888 3000 	strb.w	r3, [r8]
d000773e:	46c2      	mov	sl, r8
d0007740:	8010      	strh	r0, [r2, #0]
d0007742:	e00c      	b.n	d000775e <pjpeg_decode_mcu+0x656>
d0007744:	9a06      	ldr	r2, [sp, #24]
d0007746:	0040      	lsls	r0, r0, #1
d0007748:	3b01      	subs	r3, #1
d000774a:	2e10      	cmp	r6, #16
d000774c:	ea47 0c02 	orr.w	ip, r7, r2
d0007750:	b280      	uxth	r0, r0
d0007752:	b2db      	uxtb	r3, r3
d0007754:	4a82      	ldr	r2, [pc, #520]	; (d0007960 <pjpeg_decode_mcu+0x858>)
d0007756:	f88a 3000 	strb.w	r3, [sl]
d000775a:	8010      	strh	r0, [r2, #0]
d000775c:	d030      	beq.n	d00077c0 <pjpeg_decode_mcu+0x6b8>
d000775e:	f839 ef02 	ldrh.w	lr, [r9, #2]!
d0007762:	ea4f 074c 	mov.w	r7, ip, lsl #1
d0007766:	0bc2      	lsrs	r2, r0, #15
d0007768:	f64f 78ff 	movw	r8, #65535	; 0xffff
d000776c:	45e6      	cmp	lr, ip
d000776e:	b2bf      	uxth	r7, r7
d0007770:	9206      	str	r2, [sp, #24]
d0007772:	d302      	bcc.n	d000777a <pjpeg_decode_mcu+0x672>
d0007774:	45c6      	cmp	lr, r8
d0007776:	f040 8259 	bne.w	d0007c2c <pjpeg_decode_mcu+0xb24>
d000777a:	3601      	adds	r6, #1
d000777c:	2b00      	cmp	r3, #0
d000777e:	d1e1      	bne.n	d0007744 <pjpeg_decode_mcu+0x63c>
d0007780:	f7fe feda 	bl	d0006538 <getChar>
d0007784:	28ff      	cmp	r0, #255	; 0xff
d0007786:	4680      	mov	r8, r0
d0007788:	f000 8220 	beq.w	d0007bcc <pjpeg_decode_mcu+0xac4>
d000778c:	4b74      	ldr	r3, [pc, #464]	; (d0007960 <pjpeg_decode_mcu+0x858>)
d000778e:	8818      	ldrh	r0, [r3, #0]
d0007790:	f89a 3000 	ldrb.w	r3, [sl]
d0007794:	ea48 0000 	orr.w	r0, r8, r0
d0007798:	3308      	adds	r3, #8
d000779a:	b280      	uxth	r0, r0
d000779c:	b2db      	uxtb	r3, r3
d000779e:	e7d1      	b.n	d0007744 <pjpeg_decode_mcu+0x63c>
d00077a0:	f7fe feca 	bl	d0006538 <getChar>
d00077a4:	28ff      	cmp	r0, #255	; 0xff
d00077a6:	4681      	mov	r9, r0
d00077a8:	f000 822a 	beq.w	d0007c00 <pjpeg_decode_mcu+0xaf8>
d00077ac:	4b6c      	ldr	r3, [pc, #432]	; (d0007960 <pjpeg_decode_mcu+0x858>)
d00077ae:	881a      	ldrh	r2, [r3, #0]
d00077b0:	f898 3000 	ldrb.w	r3, [r8]
d00077b4:	ea49 0202 	orr.w	r2, r9, r2
d00077b8:	3308      	adds	r3, #8
d00077ba:	b292      	uxth	r2, r2
d00077bc:	b2db      	uxtb	r3, r3
d00077be:	e7af      	b.n	d0007720 <pjpeg_decode_mcu+0x618>
d00077c0:	2c3f      	cmp	r4, #63	; 0x3f
d00077c2:	d80e      	bhi.n	d00077e2 <pjpeg_decode_mcu+0x6da>
d00077c4:	4b67      	ldr	r3, [pc, #412]	; (d0007964 <pjpeg_decode_mcu+0x85c>)
d00077c6:	f1c4 023f 	rsb	r2, r4, #63	; 0x3f
d00077ca:	1c59      	adds	r1, r3, #1
d00077cc:	4423      	add	r3, r4
d00077ce:	440c      	add	r4, r1
d00077d0:	2100      	movs	r1, #0
d00077d2:	fa54 f482 	uxtab	r4, r4, r2
d00077d6:	f913 2b01 	ldrsb.w	r2, [r3], #1
d00077da:	429c      	cmp	r4, r3
d00077dc:	f82b 1012 	strh.w	r1, [fp, r2, lsl #1]
d00077e0:	d1f9      	bne.n	d00077d6 <pjpeg_decode_mcu+0x6ce>
d00077e2:	f04f 0980 	mov.w	r9, #128	; 0x80
d00077e6:	4b60      	ldr	r3, [pc, #384]	; (d0007968 <pjpeg_decode_mcu+0x860>)
d00077e8:	e014      	b.n	d0007814 <pjpeg_decode_mcu+0x70c>
d00077ea:	f933 2c10 	ldrsh.w	r2, [r3, #-16]
d00077ee:	3310      	adds	r3, #16
d00077f0:	f823 2c1e 	strh.w	r2, [r3, #-30]
d00077f4:	f823 2c1c 	strh.w	r2, [r3, #-28]
d00077f8:	f823 2c1a 	strh.w	r2, [r3, #-26]
d00077fc:	f823 2c18 	strh.w	r2, [r3, #-24]
d0007800:	f823 2c16 	strh.w	r2, [r3, #-22]
d0007804:	f823 2c14 	strh.w	r2, [r3, #-20]
d0007808:	f823 2c12 	strh.w	r2, [r3, #-18]
d000780c:	4a57      	ldr	r2, [pc, #348]	; (d000796c <pjpeg_decode_mcu+0x864>)
d000780e:	4293      	cmp	r3, r2
d0007810:	f000 8096 	beq.w	d0007940 <pjpeg_decode_mcu+0x838>
d0007814:	f933 ec0e 	ldrsh.w	lr, [r3, #-14]
d0007818:	f933 4c0c 	ldrsh.w	r4, [r3, #-12]
d000781c:	fa1f f28e 	uxth.w	r2, lr
d0007820:	f933 1c0a 	ldrsh.w	r1, [r3, #-10]
d0007824:	b2a7      	uxth	r7, r4
d0007826:	ea44 040e 	orr.w	r4, r4, lr
d000782a:	f933 ec06 	ldrsh.w	lr, [r3, #-6]
d000782e:	fa1f fc81 	uxth.w	ip, r1
d0007832:	f933 5c08 	ldrsh.w	r5, [r3, #-8]
d0007836:	430c      	orrs	r4, r1
d0007838:	fa1f f88e 	uxth.w	r8, lr
d000783c:	f933 0c04 	ldrsh.w	r0, [r3, #-4]
d0007840:	432c      	orrs	r4, r5
d0007842:	b2a9      	uxth	r1, r5
d0007844:	eba8 050c 	sub.w	r5, r8, ip
d0007848:	b286      	uxth	r6, r0
d000784a:	ea4e 0e04 	orr.w	lr, lr, r4
d000784e:	f933 ac02 	ldrsh.w	sl, [r3, #-2]
d0007852:	b2ad      	uxth	r5, r5
d0007854:	44c4      	add	ip, r8
d0007856:	ea40 0e0e 	orr.w	lr, r0, lr
d000785a:	eb06 0807 	add.w	r8, r6, r7
d000785e:	1aac      	subs	r4, r5, r2
d0007860:	1bbf      	subs	r7, r7, r6
d0007862:	f44f 70b5 	mov.w	r0, #362	; 0x16a
d0007866:	fa1f f68a 	uxth.w	r6, sl
d000786a:	fa1f fc8c 	uxth.w	ip, ip
d000786e:	fb17 9700 	smlabb	r7, r7, r0, r9
d0007872:	18b0      	adds	r0, r6, r2
d0007874:	1b92      	subs	r2, r2, r6
d0007876:	4426      	add	r6, r4
d0007878:	ea5a 040e 	orrs.w	r4, sl, lr
d000787c:	f240 1415 	movw	r4, #277	; 0x115
d0007880:	b280      	uxth	r0, r0
d0007882:	f3c7 270f 	ubfx	r7, r7, #8, #16
d0007886:	fb12 9204 	smlabb	r2, r2, r4, r9
d000788a:	fa1f f888 	uxth.w	r8, r8
d000788e:	eb00 0e0c 	add.w	lr, r0, ip
d0007892:	eba0 000c 	sub.w	r0, r0, ip
d0007896:	f3c2 220f 	ubfx	r2, r2, #8, #16
d000789a:	d0a6      	beq.n	d00077ea <pjpeg_decode_mcu+0x6e2>
d000789c:	24c4      	movs	r4, #196	; 0xc4
d000789e:	fa1f fe8e 	uxth.w	lr, lr
d00078a2:	f833 cc10 	ldrh.w	ip, [r3, #-16]
d00078a6:	3310      	adds	r3, #16
d00078a8:	fb16 9604 	smlabb	r6, r6, r4, r9
d00078ac:	ebae 0a02 	sub.w	sl, lr, r2
d00078b0:	f44f 74b5 	mov.w	r4, #362	; 0x16a
d00078b4:	eba2 020e 	sub.w	r2, r2, lr
d00078b8:	f3c6 260f 	ubfx	r6, r6, #8, #16
d00078bc:	fb10 9004 	smlabb	r0, r0, r4, r9
d00078c0:	ebac 0401 	sub.w	r4, ip, r1
d00078c4:	44b2      	add	sl, r6
d00078c6:	4461      	add	r1, ip
d00078c8:	b2a4      	uxth	r4, r4
d00078ca:	f240 2c9d 	movw	ip, #669	; 0x29d
d00078ce:	fa1f fa8a 	uxth.w	sl, sl
d00078d2:	fb15 950c 	smlabb	r5, r5, ip, r9
d00078d6:	eba4 0c08 	sub.w	ip, r4, r8
d00078da:	eb0a 2020 	add.w	r0, sl, r0, asr #8
d00078de:	4444      	add	r4, r8
d00078e0:	b289      	uxth	r1, r1
d00078e2:	44bc      	add	ip, r7
d00078e4:	b280      	uxth	r0, r0
d00078e6:	1be4      	subs	r4, r4, r7
d00078e8:	eba6 2525 	sub.w	r5, r6, r5, asr #8
d00078ec:	eba1 0708 	sub.w	r7, r1, r8
d00078f0:	fa1f fc8c 	uxth.w	ip, ip
d00078f4:	4488      	add	r8, r1
d00078f6:	4405      	add	r5, r0
d00078f8:	b2a4      	uxth	r4, r4
d00078fa:	4462      	add	r2, ip
d00078fc:	b2bf      	uxth	r7, r7
d00078fe:	b2ad      	uxth	r5, r5
d0007900:	1821      	adds	r1, r4, r0
d0007902:	fa1f f888 	uxth.w	r8, r8
d0007906:	1b92      	subs	r2, r2, r6
d0007908:	1a20      	subs	r0, r4, r0
d000790a:	1b7e      	subs	r6, r7, r5
d000790c:	eb08 040e 	add.w	r4, r8, lr
d0007910:	44d4      	add	ip, sl
d0007912:	443d      	add	r5, r7
d0007914:	eba8 080e 	sub.w	r8, r8, lr
d0007918:	f823 2c1e 	strh.w	r2, [r3, #-30]
d000791c:	4a13      	ldr	r2, [pc, #76]	; (d000796c <pjpeg_decode_mcu+0x864>)
d000791e:	f823 cc14 	strh.w	ip, [r3, #-20]
d0007922:	f823 6c1a 	strh.w	r6, [r3, #-26]
d0007926:	f823 5c18 	strh.w	r5, [r3, #-24]
d000792a:	f823 1c1c 	strh.w	r1, [r3, #-28]
d000792e:	f823 0c16 	strh.w	r0, [r3, #-22]
d0007932:	f823 4c20 	strh.w	r4, [r3, #-32]
d0007936:	f823 8c12 	strh.w	r8, [r3, #-18]
d000793a:	4293      	cmp	r3, r2
d000793c:	f47f af6a 	bne.w	d0007814 <pjpeg_decode_mcu+0x70c>
d0007940:	f1a2 0990 	sub.w	r9, r2, #144	; 0x90
d0007944:	f04f 0a80 	mov.w	sl, #128	; 0x80
d0007948:	e035      	b.n	d00079b6 <pjpeg_decode_mcu+0x8ae>
d000794a:	bf00      	nop
d000794c:	d000e014 	.word	0xd000e014
d0007950:	d000e064 	.word	0xd000e064
d0007954:	d000e0d4 	.word	0xd000e0d4
d0007958:	d000e1d4 	.word	0xd000e1d4
d000795c:	d000e2d8 	.word	0xd000e2d8
d0007960:	d000ded0 	.word	0xd000ded0
d0007964:	d000d5f8 	.word	0xd000d5f8
d0007968:	d000dee4 	.word	0xd000dee4
d000796c:	d000df64 	.word	0xd000df64
d0007970:	f9b9 3000 	ldrsh.w	r3, [r9]
d0007974:	f109 0902 	add.w	r9, r9, #2
d0007978:	3340      	adds	r3, #64	; 0x40
d000797a:	11db      	asrs	r3, r3, #7
d000797c:	3380      	adds	r3, #128	; 0x80
d000797e:	b29b      	uxth	r3, r3
d0007980:	2bff      	cmp	r3, #255	; 0xff
d0007982:	bf84      	itt	hi
d0007984:	43db      	mvnhi	r3, r3
d0007986:	f343 33c0 	sbfxhi	r3, r3, #15, #1
d000798a:	b2db      	uxtb	r3, r3
d000798c:	b21b      	sxth	r3, r3
d000798e:	f829 3c02 	strh.w	r3, [r9, #-2]
d0007992:	f8a9 300e 	strh.w	r3, [r9, #14]
d0007996:	f8a9 301e 	strh.w	r3, [r9, #30]
d000799a:	f8a9 302e 	strh.w	r3, [r9, #46]	; 0x2e
d000799e:	f8a9 303e 	strh.w	r3, [r9, #62]	; 0x3e
d00079a2:	f8a9 304e 	strh.w	r3, [r9, #78]	; 0x4e
d00079a6:	f8a9 305e 	strh.w	r3, [r9, #94]	; 0x5e
d00079aa:	f8a9 306e 	strh.w	r3, [r9, #110]	; 0x6e
d00079ae:	4bbc      	ldr	r3, [pc, #752]	; (d0007ca0 <pjpeg_decode_mcu+0xb98>)
d00079b0:	4599      	cmp	r9, r3
d00079b2:	f000 80ff 	beq.w	d0007bb4 <pjpeg_decode_mcu+0xaac>
d00079b6:	f9b9 1010 	ldrsh.w	r1, [r9, #16]
d00079ba:	f9b9 c020 	ldrsh.w	ip, [r9, #32]
d00079be:	f9b9 3030 	ldrsh.w	r3, [r9, #48]	; 0x30
d00079c2:	ea4c 0001 	orr.w	r0, ip, r1
d00079c6:	f9b9 4040 	ldrsh.w	r4, [r9, #64]	; 0x40
d00079ca:	f9b9 5050 	ldrsh.w	r5, [r9, #80]	; 0x50
d00079ce:	4318      	orrs	r0, r3
d00079d0:	f9b9 2060 	ldrsh.w	r2, [r9, #96]	; 0x60
d00079d4:	f9b9 7070 	ldrsh.w	r7, [r9, #112]	; 0x70
d00079d8:	4320      	orrs	r0, r4
d00079da:	4328      	orrs	r0, r5
d00079dc:	4310      	orrs	r0, r2
d00079de:	4338      	orrs	r0, r7
d00079e0:	d0c6      	beq.n	d0007970 <pjpeg_decode_mcu+0x868>
d00079e2:	b2a8      	uxth	r0, r5
d00079e4:	f8b9 8000 	ldrh.w	r8, [r9]
d00079e8:	b2bd      	uxth	r5, r7
d00079ea:	f109 0902 	add.w	r9, r9, #2
d00079ee:	b289      	uxth	r1, r1
d00079f0:	b29b      	uxth	r3, r3
d00079f2:	9508      	str	r5, [sp, #32]
d00079f4:	fa1f fc8c 	uxth.w	ip, ip
d00079f8:	1b4e      	subs	r6, r1, r5
d00079fa:	eb03 0e00 	add.w	lr, r3, r0
d00079fe:	b2a4      	uxth	r4, r4
d0007a00:	1ac3      	subs	r3, r0, r3
d0007a02:	b292      	uxth	r2, r2
d0007a04:	1868      	adds	r0, r5, r1
d0007a06:	eb04 0708 	add.w	r7, r4, r8
d0007a0a:	fa1f fe8e 	uxth.w	lr, lr
d0007a0e:	eb02 050c 	add.w	r5, r2, ip
d0007a12:	b280      	uxth	r0, r0
d0007a14:	ebac 0202 	sub.w	r2, ip, r2
d0007a18:	b29b      	uxth	r3, r3
d0007a1a:	eba8 0404 	sub.w	r4, r8, r4
d0007a1e:	b2ad      	uxth	r5, r5
d0007a20:	eb00 080e 	add.w	r8, r0, lr
d0007a24:	b2bf      	uxth	r7, r7
d0007a26:	eba0 000e 	sub.w	r0, r0, lr
d0007a2a:	1a59      	subs	r1, r3, r1
d0007a2c:	f44f 7cb5 	mov.w	ip, #362	; 0x16a
d0007a30:	fa1f f888 	uxth.w	r8, r8
d0007a34:	eb05 0e07 	add.w	lr, r5, r7
d0007a38:	9707      	str	r7, [sp, #28]
d0007a3a:	f240 1715 	movw	r7, #277	; 0x115
d0007a3e:	9109      	str	r1, [sp, #36]	; 0x24
d0007a40:	fb10 a10c 	smlabb	r1, r0, ip, sl
d0007a44:	fb16 a607 	smlabb	r6, r6, r7, sl
d0007a48:	920b      	str	r2, [sp, #44]	; 0x2c
d0007a4a:	fa0f f788 	sxth.w	r7, r8
d0007a4e:	910a      	str	r1, [sp, #40]	; 0x28
d0007a50:	fa0f f28e 	sxth.w	r2, lr
d0007a54:	9908      	ldr	r1, [sp, #32]
d0007a56:	9809      	ldr	r0, [sp, #36]	; 0x24
d0007a58:	f3c6 260f 	ubfx	r6, r6, #8, #16
d0007a5c:	eb07 0c02 	add.w	ip, r7, r2
d0007a60:	9206      	str	r2, [sp, #24]
d0007a62:	4408      	add	r0, r1
d0007a64:	9a0a      	ldr	r2, [sp, #40]	; 0x28
d0007a66:	9704      	str	r7, [sp, #16]
d0007a68:	b2a4      	uxth	r4, r4
d0007a6a:	4601      	mov	r1, r0
d0007a6c:	ebc6 2022 	rsb	r0, r6, r2, asr #8
d0007a70:	22c4      	movs	r2, #196	; 0xc4
d0007a72:	9f0b      	ldr	r7, [sp, #44]	; 0x2c
d0007a74:	eba4 0e05 	sub.w	lr, r4, r5
d0007a78:	eba6 0608 	sub.w	r6, r6, r8
d0007a7c:	fb11 a102 	smlabb	r1, r1, r2, sl
d0007a80:	f44f 72b5 	mov.w	r2, #362	; 0x16a
d0007a84:	442c      	add	r4, r5
d0007a86:	f10c 0c40 	add.w	ip, ip, #64	; 0x40
d0007a8a:	fb17 a202 	smlabb	r2, r7, r2, sl
d0007a8e:	f3c1 210f 	ubfx	r1, r1, #8, #16
d0007a92:	ea4f 1cec 	mov.w	ip, ip, asr #7
d0007a96:	4440      	add	r0, r8
d0007a98:	f3c2 220f 	ubfx	r2, r2, #8, #16
d0007a9c:	1a76      	subs	r6, r6, r1
d0007a9e:	f10c 0c80 	add.w	ip, ip, #128	; 0x80
d0007aa2:	f240 289d 	movw	r8, #669	; 0x29d
d0007aa6:	4496      	add	lr, r2
d0007aa8:	b236      	sxth	r6, r6
d0007aaa:	1aa4      	subs	r4, r4, r2
d0007aac:	fa1f fc8c 	uxth.w	ip, ip
d0007ab0:	fa0f fe8e 	sxth.w	lr, lr
d0007ab4:	4408      	add	r0, r1
d0007ab6:	f1bc 0fff 	cmp.w	ip, #255	; 0xff
d0007aba:	b224      	sxth	r4, r4
d0007abc:	eb06 020e 	add.w	r2, r6, lr
d0007ac0:	9f07      	ldr	r7, [sp, #28]
d0007ac2:	fb13 a308 	smlabb	r3, r3, r8, sl
d0007ac6:	bf88      	it	hi
d0007ac8:	ea6f 0c0c 	mvnhi.w	ip, ip
d0007acc:	f102 0240 	add.w	r2, r2, #64	; 0x40
d0007ad0:	eba7 0505 	sub.w	r5, r7, r5
d0007ad4:	bf88      	it	hi
d0007ad6:	f34c 3cc0 	sbfxhi	ip, ip, #15, #1
d0007ada:	eba1 2323 	sub.w	r3, r1, r3, asr #8
d0007ade:	11d2      	asrs	r2, r2, #7
d0007ae0:	fa13 f380 	uxtah	r3, r3, r0
d0007ae4:	b200      	sxth	r0, r0
d0007ae6:	3280      	adds	r2, #128	; 0x80
d0007ae8:	b22d      	sxth	r5, r5
d0007aea:	b21b      	sxth	r3, r3
d0007aec:	b292      	uxth	r2, r2
d0007aee:	fa5f fc8c 	uxtb.w	ip, ip
d0007af2:	2aff      	cmp	r2, #255	; 0xff
d0007af4:	f829 cc02 	strh.w	ip, [r9, #-2]
d0007af8:	bf84      	itt	hi
d0007afa:	43d2      	mvnhi	r2, r2
d0007afc:	f342 32c0 	sbfxhi	r2, r2, #15, #1
d0007b00:	b2d1      	uxtb	r1, r2
d0007b02:	1902      	adds	r2, r0, r4
d0007b04:	3240      	adds	r2, #64	; 0x40
d0007b06:	f8a9 100e 	strh.w	r1, [r9, #14]
d0007b0a:	11d2      	asrs	r2, r2, #7
d0007b0c:	3280      	adds	r2, #128	; 0x80
d0007b0e:	b292      	uxth	r2, r2
d0007b10:	2aff      	cmp	r2, #255	; 0xff
d0007b12:	bf84      	itt	hi
d0007b14:	43d2      	mvnhi	r2, r2
d0007b16:	f342 32c0 	sbfxhi	r2, r2, #15, #1
d0007b1a:	b2d1      	uxtb	r1, r2
d0007b1c:	1aea      	subs	r2, r5, r3
d0007b1e:	442b      	add	r3, r5
d0007b20:	3240      	adds	r2, #64	; 0x40
d0007b22:	f8a9 101e 	strh.w	r1, [r9, #30]
d0007b26:	3340      	adds	r3, #64	; 0x40
d0007b28:	9904      	ldr	r1, [sp, #16]
d0007b2a:	11d2      	asrs	r2, r2, #7
d0007b2c:	11db      	asrs	r3, r3, #7
d0007b2e:	3280      	adds	r2, #128	; 0x80
d0007b30:	3380      	adds	r3, #128	; 0x80
d0007b32:	b292      	uxth	r2, r2
d0007b34:	b29b      	uxth	r3, r3
d0007b36:	2aff      	cmp	r2, #255	; 0xff
d0007b38:	bf84      	itt	hi
d0007b3a:	43d2      	mvnhi	r2, r2
d0007b3c:	f342 32c0 	sbfxhi	r2, r2, #15, #1
d0007b40:	2bff      	cmp	r3, #255	; 0xff
d0007b42:	b2d2      	uxtb	r2, r2
d0007b44:	bf88      	it	hi
d0007b46:	43db      	mvnhi	r3, r3
d0007b48:	f8a9 202e 	strh.w	r2, [r9, #46]	; 0x2e
d0007b4c:	bf88      	it	hi
d0007b4e:	f343 33c0 	sbfxhi	r3, r3, #15, #1
d0007b52:	1a22      	subs	r2, r4, r0
d0007b54:	b2db      	uxtb	r3, r3
d0007b56:	3240      	adds	r2, #64	; 0x40
d0007b58:	f8a9 303e 	strh.w	r3, [r9, #62]	; 0x3e
d0007b5c:	ebae 0306 	sub.w	r3, lr, r6
d0007b60:	11d2      	asrs	r2, r2, #7
d0007b62:	3340      	adds	r3, #64	; 0x40
d0007b64:	3280      	adds	r2, #128	; 0x80
d0007b66:	11db      	asrs	r3, r3, #7
d0007b68:	b292      	uxth	r2, r2
d0007b6a:	3380      	adds	r3, #128	; 0x80
d0007b6c:	2aff      	cmp	r2, #255	; 0xff
d0007b6e:	b29b      	uxth	r3, r3
d0007b70:	bf84      	itt	hi
d0007b72:	43d2      	mvnhi	r2, r2
d0007b74:	f342 32c0 	sbfxhi	r2, r2, #15, #1
d0007b78:	2bff      	cmp	r3, #255	; 0xff
d0007b7a:	bf88      	it	hi
d0007b7c:	43db      	mvnhi	r3, r3
d0007b7e:	b2d2      	uxtb	r2, r2
d0007b80:	bf88      	it	hi
d0007b82:	f343 33c0 	sbfxhi	r3, r3, #15, #1
d0007b86:	f8a9 204e 	strh.w	r2, [r9, #78]	; 0x4e
d0007b8a:	b2da      	uxtb	r2, r3
d0007b8c:	9b06      	ldr	r3, [sp, #24]
d0007b8e:	1a5b      	subs	r3, r3, r1
d0007b90:	f8a9 205e 	strh.w	r2, [r9, #94]	; 0x5e
d0007b94:	3340      	adds	r3, #64	; 0x40
d0007b96:	11db      	asrs	r3, r3, #7
d0007b98:	3380      	adds	r3, #128	; 0x80
d0007b9a:	b29b      	uxth	r3, r3
d0007b9c:	2bff      	cmp	r3, #255	; 0xff
d0007b9e:	bf84      	itt	hi
d0007ba0:	43db      	mvnhi	r3, r3
d0007ba2:	f343 33c0 	sbfxhi	r3, r3, #15, #1
d0007ba6:	b2db      	uxtb	r3, r3
d0007ba8:	f8a9 306e 	strh.w	r3, [r9, #110]	; 0x6e
d0007bac:	4b3c      	ldr	r3, [pc, #240]	; (d0007ca0 <pjpeg_decode_mcu+0xb98>)
d0007bae:	4599      	cmp	r9, r3
d0007bb0:	f47f af01 	bne.w	d00079b6 <pjpeg_decode_mcu+0x8ae>
d0007bb4:	4b3b      	ldr	r3, [pc, #236]	; (d0007ca4 <pjpeg_decode_mcu+0xb9c>)
d0007bb6:	781b      	ldrb	r3, [r3, #0]
d0007bb8:	2b04      	cmp	r3, #4
d0007bba:	f63f ad20 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007bbe:	e8df f013 	tbh	[pc, r3, lsl #1]
d0007bc2:	02b9      	.short	0x02b9
d0007bc4:	025702cc 	.word	0x025702cc
d0007bc8:	01ac0204 	.word	0x01ac0204
d0007bcc:	f7fe fcb4 	bl	d0006538 <getChar>
d0007bd0:	2800      	cmp	r0, #0
d0007bd2:	f43f addb 	beq.w	d000778c <pjpeg_decode_mcu+0x684>
d0007bd6:	4a34      	ldr	r2, [pc, #208]	; (d0007ca8 <pjpeg_decode_mcu+0xba0>)
d0007bd8:	4934      	ldr	r1, [pc, #208]	; (d0007cac <pjpeg_decode_mcu+0xba4>)
d0007bda:	7813      	ldrb	r3, [r2, #0]
d0007bdc:	f891 e000 	ldrb.w	lr, [r1]
d0007be0:	f103 3cff 	add.w	ip, r3, #4294967295	; 0xffffffff
d0007be4:	3b02      	subs	r3, #2
d0007be6:	f10e 0e02 	add.w	lr, lr, #2
d0007bea:	b2db      	uxtb	r3, r3
d0007bec:	fa5f fc8c 	uxtb.w	ip, ip
d0007bf0:	f881 e000 	strb.w	lr, [r1]
d0007bf4:	7013      	strb	r3, [r2, #0]
d0007bf6:	f805 000c 	strb.w	r0, [r5, ip]
d0007bfa:	f805 8003 	strb.w	r8, [r5, r3]
d0007bfe:	e5c5      	b.n	d000778c <pjpeg_decode_mcu+0x684>
d0007c00:	f7fe fc9a 	bl	d0006538 <getChar>
d0007c04:	2800      	cmp	r0, #0
d0007c06:	f43f add1 	beq.w	d00077ac <pjpeg_decode_mcu+0x6a4>
d0007c0a:	4b27      	ldr	r3, [pc, #156]	; (d0007ca8 <pjpeg_decode_mcu+0xba0>)
d0007c0c:	4927      	ldr	r1, [pc, #156]	; (d0007cac <pjpeg_decode_mcu+0xba4>)
d0007c0e:	781b      	ldrb	r3, [r3, #0]
d0007c10:	460f      	mov	r7, r1
d0007c12:	7809      	ldrb	r1, [r1, #0]
d0007c14:	1e5a      	subs	r2, r3, #1
d0007c16:	3b02      	subs	r3, #2
d0007c18:	3102      	adds	r1, #2
d0007c1a:	b2d2      	uxtb	r2, r2
d0007c1c:	b2db      	uxtb	r3, r3
d0007c1e:	7039      	strb	r1, [r7, #0]
d0007c20:	54a8      	strb	r0, [r5, r2]
d0007c22:	4a21      	ldr	r2, [pc, #132]	; (d0007ca8 <pjpeg_decode_mcu+0xba0>)
d0007c24:	f805 9003 	strb.w	r9, [r5, r3]
d0007c28:	7013      	strb	r3, [r2, #0]
d0007c2a:	e5bf      	b.n	d00077ac <pjpeg_decode_mcu+0x6a4>
d0007c2c:	46d0      	mov	r8, sl
d0007c2e:	46b2      	mov	sl, r6
d0007c30:	9e07      	ldr	r6, [sp, #28]
d0007c32:	eb06 030a 	add.w	r3, r6, sl
d0007c36:	f816 201a 	ldrb.w	r2, [r6, sl, lsl #1]
d0007c3a:	f893 3040 	ldrb.w	r3, [r3, #64]	; 0x40
d0007c3e:	449c      	add	ip, r3
d0007c40:	9b08      	ldr	r3, [sp, #32]
d0007c42:	ebac 0c02 	sub.w	ip, ip, r2
d0007c46:	f00c 0cff 	and.w	ip, ip, #255	; 0xff
d0007c4a:	f813 900c 	ldrb.w	r9, [r3, ip]
d0007c4e:	f019 070f 	ands.w	r7, r9, #15
d0007c52:	f000 80cc 	beq.w	d0007dee <pjpeg_decode_mcu+0xce6>
d0007c56:	4638      	mov	r0, r7
d0007c58:	f7ff f91a 	bl	d0006e90 <getBits.constprop.2>
d0007c5c:	ea5f 1119 	movs.w	r1, r9, lsr #4
d0007c60:	d12e      	bne.n	d0007cc0 <pjpeg_decode_mcu+0xbb8>
d0007c62:	4b13      	ldr	r3, [pc, #76]	; (d0007cb0 <pjpeg_decode_mcu+0xba8>)
d0007c64:	3f01      	subs	r7, #1
d0007c66:	4a13      	ldr	r2, [pc, #76]	; (d0007cb4 <pjpeg_decode_mcu+0xbac>)
d0007c68:	b2ff      	uxtb	r7, r7
d0007c6a:	f832 2017 	ldrh.w	r2, [r2, r7, lsl #1]
d0007c6e:	4282      	cmp	r2, r0
d0007c70:	d904      	bls.n	d0007c7c <pjpeg_decode_mcu+0xb74>
d0007c72:	4a11      	ldr	r2, [pc, #68]	; (d0007cb8 <pjpeg_decode_mcu+0xbb0>)
d0007c74:	f832 2017 	ldrh.w	r2, [r2, r7, lsl #1]
d0007c78:	4410      	add	r0, r2
d0007c7a:	b280      	uxth	r0, r0
d0007c7c:	9a04      	ldr	r2, [sp, #16]
d0007c7e:	571b      	ldrsb	r3, [r3, r4]
d0007c80:	f832 2014 	ldrh.w	r2, [r2, r4, lsl #1]
d0007c84:	fb12 f000 	smulbb	r0, r2, r0
d0007c88:	f82b 0013 	strh.w	r0, [fp, r3, lsl #1]
d0007c8c:	3401      	adds	r4, #1
d0007c8e:	b2e4      	uxtb	r4, r4
d0007c90:	2c3f      	cmp	r4, #63	; 0x3f
d0007c92:	f63f ada6 	bhi.w	d00077e2 <pjpeg_decode_mcu+0x6da>
d0007c96:	4b09      	ldr	r3, [pc, #36]	; (d0007cbc <pjpeg_decode_mcu+0xbb4>)
d0007c98:	881a      	ldrh	r2, [r3, #0]
d0007c9a:	f898 3000 	ldrb.w	r3, [r8]
d0007c9e:	e53b      	b.n	d0007718 <pjpeg_decode_mcu+0x610>
d0007ca0:	d000dee4 	.word	0xd000dee4
d0007ca4:	d000e7fe 	.word	0xd000e7fe
d0007ca8:	d000e3d9 	.word	0xd000e3d9
d0007cac:	d000e3d8 	.word	0xd000e3d8
d0007cb0:	d000d5f8 	.word	0xd000d5f8
d0007cb4:	d000d598 	.word	0xd000d598
d0007cb8:	d000d5b8 	.word	0xd000d5b8
d0007cbc:	d000ded0 	.word	0xd000ded0
d0007cc0:	eb01 0904 	add.w	r9, r1, r4
d0007cc4:	f1b9 0f3f 	cmp.w	r9, #63	; 0x3f
d0007cc8:	f300 8211 	bgt.w	d00080ee <pjpeg_decode_mcu+0xfe6>
d0007ccc:	4bc4      	ldr	r3, [pc, #784]	; (d0007fe0 <pjpeg_decode_mcu+0xed8>)
d0007cce:	f04f 0c00 	mov.w	ip, #0
d0007cd2:	f104 0e01 	add.w	lr, r4, #1
d0007cd6:	2901      	cmp	r1, #1
d0007cd8:	f913 a004 	ldrsb.w	sl, [r3, r4]
d0007cdc:	b28a      	uxth	r2, r1
d0007cde:	fa5f fe8e 	uxtb.w	lr, lr
d0007ce2:	f82b c01a 	strh.w	ip, [fp, sl, lsl #1]
d0007ce6:	d07f      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007ce8:	f913 e00e 	ldrsb.w	lr, [r3, lr]
d0007cec:	1ca1      	adds	r1, r4, #2
d0007cee:	2a02      	cmp	r2, #2
d0007cf0:	b2c9      	uxtb	r1, r1
d0007cf2:	f82b c01e 	strh.w	ip, [fp, lr, lsl #1]
d0007cf6:	d077      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007cf8:	f913 e001 	ldrsb.w	lr, [r3, r1]
d0007cfc:	2a03      	cmp	r2, #3
d0007cfe:	f104 0103 	add.w	r1, r4, #3
d0007d02:	f82b c01e 	strh.w	ip, [fp, lr, lsl #1]
d0007d06:	b2c9      	uxtb	r1, r1
d0007d08:	d06e      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d0a:	f913 e001 	ldrsb.w	lr, [r3, r1]
d0007d0e:	2a04      	cmp	r2, #4
d0007d10:	f104 0104 	add.w	r1, r4, #4
d0007d14:	f82b c01e 	strh.w	ip, [fp, lr, lsl #1]
d0007d18:	b2c9      	uxtb	r1, r1
d0007d1a:	d065      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d1c:	f913 e001 	ldrsb.w	lr, [r3, r1]
d0007d20:	2a05      	cmp	r2, #5
d0007d22:	f104 0105 	add.w	r1, r4, #5
d0007d26:	f82b c01e 	strh.w	ip, [fp, lr, lsl #1]
d0007d2a:	b2c9      	uxtb	r1, r1
d0007d2c:	d05c      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d2e:	f913 e001 	ldrsb.w	lr, [r3, r1]
d0007d32:	2a06      	cmp	r2, #6
d0007d34:	4661      	mov	r1, ip
d0007d36:	f104 0c06 	add.w	ip, r4, #6
d0007d3a:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007d3e:	fa5f fc8c 	uxtb.w	ip, ip
d0007d42:	d051      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d44:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007d48:	2a07      	cmp	r2, #7
d0007d4a:	f104 0c07 	add.w	ip, r4, #7
d0007d4e:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007d52:	fa5f fc8c 	uxtb.w	ip, ip
d0007d56:	d047      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d58:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007d5c:	2a08      	cmp	r2, #8
d0007d5e:	f104 0c08 	add.w	ip, r4, #8
d0007d62:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007d66:	fa5f fc8c 	uxtb.w	ip, ip
d0007d6a:	d03d      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d6c:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007d70:	2a09      	cmp	r2, #9
d0007d72:	f104 0c09 	add.w	ip, r4, #9
d0007d76:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007d7a:	fa5f fc8c 	uxtb.w	ip, ip
d0007d7e:	d033      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d80:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007d84:	2a0a      	cmp	r2, #10
d0007d86:	f104 0c0a 	add.w	ip, r4, #10
d0007d8a:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007d8e:	fa5f fc8c 	uxtb.w	ip, ip
d0007d92:	d029      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007d94:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007d98:	2a0b      	cmp	r2, #11
d0007d9a:	f104 0c0b 	add.w	ip, r4, #11
d0007d9e:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007da2:	fa5f fc8c 	uxtb.w	ip, ip
d0007da6:	d01f      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007da8:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007dac:	2a0c      	cmp	r2, #12
d0007dae:	f104 0c0c 	add.w	ip, r4, #12
d0007db2:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007db6:	fa5f fc8c 	uxtb.w	ip, ip
d0007dba:	d015      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007dbc:	3a0d      	subs	r2, #13
d0007dbe:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007dc2:	f104 0c0d 	add.w	ip, r4, #13
d0007dc6:	b292      	uxth	r2, r2
d0007dc8:	f82b 101e 	strh.w	r1, [fp, lr, lsl #1]
d0007dcc:	fa5f fc8c 	uxtb.w	ip, ip
d0007dd0:	b152      	cbz	r2, d0007de8 <pjpeg_decode_mcu+0xce0>
d0007dd2:	340e      	adds	r4, #14
d0007dd4:	f913 c00c 	ldrsb.w	ip, [r3, ip]
d0007dd8:	2a01      	cmp	r2, #1
d0007dda:	b2e4      	uxtb	r4, r4
d0007ddc:	f82b 101c 	strh.w	r1, [fp, ip, lsl #1]
d0007de0:	d002      	beq.n	d0007de8 <pjpeg_decode_mcu+0xce0>
d0007de2:	571a      	ldrsb	r2, [r3, r4]
d0007de4:	f82b 1012 	strh.w	r1, [fp, r2, lsl #1]
d0007de8:	fa5f f489 	uxtb.w	r4, r9
d0007dec:	e73a      	b.n	d0007c64 <pjpeg_decode_mcu+0xb5c>
d0007dee:	ea4f 1119 	mov.w	r1, r9, lsr #4
d0007df2:	290f      	cmp	r1, #15
d0007df4:	f47f ace4 	bne.w	d00077c0 <pjpeg_decode_mcu+0x6b8>
d0007df8:	2c30      	cmp	r4, #48	; 0x30
d0007dfa:	f200 8178 	bhi.w	d00080ee <pjpeg_decode_mcu+0xfe6>
d0007dfe:	4b78      	ldr	r3, [pc, #480]	; (d0007fe0 <pjpeg_decode_mcu+0xed8>)
d0007e00:	f104 0e01 	add.w	lr, r4, #1
d0007e04:	f104 0c02 	add.w	ip, r4, #2
d0007e08:	1ce1      	adds	r1, r4, #3
d0007e0a:	571a      	ldrsb	r2, [r3, r4]
d0007e0c:	fa5f fe8e 	uxtb.w	lr, lr
d0007e10:	fa5f fc8c 	uxtb.w	ip, ip
d0007e14:	1d20      	adds	r0, r4, #4
d0007e16:	b2c9      	uxtb	r1, r1
d0007e18:	f82b 7012 	strh.w	r7, [fp, r2, lsl #1]
d0007e1c:	f913 900e 	ldrsb.w	r9, [r3, lr]
d0007e20:	1da2      	adds	r2, r4, #6
d0007e22:	f913 e00c 	ldrsb.w	lr, [r3, ip]
d0007e26:	b2c0      	uxtb	r0, r0
d0007e28:	f913 c001 	ldrsb.w	ip, [r3, r1]
d0007e2c:	1d61      	adds	r1, r4, #5
d0007e2e:	b2d2      	uxtb	r2, r2
d0007e30:	f82b 7019 	strh.w	r7, [fp, r9, lsl #1]
d0007e34:	b2c9      	uxtb	r1, r1
d0007e36:	f82b 701e 	strh.w	r7, [fp, lr, lsl #1]
d0007e3a:	f913 e002 	ldrsb.w	lr, [r3, r2]
d0007e3e:	f104 0208 	add.w	r2, r4, #8
d0007e42:	f913 9001 	ldrsb.w	r9, [r3, r1]
d0007e46:	1de1      	adds	r1, r4, #7
d0007e48:	5618      	ldrsb	r0, [r3, r0]
d0007e4a:	b2d2      	uxtb	r2, r2
d0007e4c:	b2c9      	uxtb	r1, r1
d0007e4e:	f82b 701c 	strh.w	r7, [fp, ip, lsl #1]
d0007e52:	f82b 7010 	strh.w	r7, [fp, r0, lsl #1]
d0007e56:	f913 c001 	ldrsb.w	ip, [r3, r1]
d0007e5a:	f104 0109 	add.w	r1, r4, #9
d0007e5e:	5698      	ldrsb	r0, [r3, r2]
d0007e60:	f104 020a 	add.w	r2, r4, #10
d0007e64:	b2c9      	uxtb	r1, r1
d0007e66:	f82b 7019 	strh.w	r7, [fp, r9, lsl #1]
d0007e6a:	b2d2      	uxtb	r2, r2
d0007e6c:	f82b 701e 	strh.w	r7, [fp, lr, lsl #1]
d0007e70:	f913 9001 	ldrsb.w	r9, [r3, r1]
d0007e74:	f104 010b 	add.w	r1, r4, #11
d0007e78:	f913 e002 	ldrsb.w	lr, [r3, r2]
d0007e7c:	f104 020c 	add.w	r2, r4, #12
d0007e80:	b2c9      	uxtb	r1, r1
d0007e82:	f82b 701c 	strh.w	r7, [fp, ip, lsl #1]
d0007e86:	b2d2      	uxtb	r2, r2
d0007e88:	f82b 7010 	strh.w	r7, [fp, r0, lsl #1]
d0007e8c:	f913 c001 	ldrsb.w	ip, [r3, r1]
d0007e90:	f104 010d 	add.w	r1, r4, #13
d0007e94:	5698      	ldrsb	r0, [r3, r2]
d0007e96:	f104 020e 	add.w	r2, r4, #14
d0007e9a:	340f      	adds	r4, #15
d0007e9c:	b2c9      	uxtb	r1, r1
d0007e9e:	b2d2      	uxtb	r2, r2
d0007ea0:	f82b 7019 	strh.w	r7, [fp, r9, lsl #1]
d0007ea4:	b2e4      	uxtb	r4, r4
d0007ea6:	5659      	ldrsb	r1, [r3, r1]
d0007ea8:	569a      	ldrsb	r2, [r3, r2]
d0007eaa:	571b      	ldrsb	r3, [r3, r4]
d0007eac:	f82b 701e 	strh.w	r7, [fp, lr, lsl #1]
d0007eb0:	f82b 701c 	strh.w	r7, [fp, ip, lsl #1]
d0007eb4:	f82b 7010 	strh.w	r7, [fp, r0, lsl #1]
d0007eb8:	f82b 7011 	strh.w	r7, [fp, r1, lsl #1]
d0007ebc:	f82b 7012 	strh.w	r7, [fp, r2, lsl #1]
d0007ec0:	f82b 7013 	strh.w	r7, [fp, r3, lsl #1]
d0007ec4:	e6e2      	b.n	d0007c8c <pjpeg_decode_mcu+0xb84>
d0007ec6:	4637      	mov	r7, r6
d0007ec8:	9e07      	ldr	r6, [sp, #28]
d0007eca:	19f5      	adds	r5, r6, r7
d0007ecc:	f816 0017 	ldrb.w	r0, [r6, r7, lsl #1]
d0007ed0:	f895 1040 	ldrb.w	r1, [r5, #64]	; 0x40
d0007ed4:	448c      	add	ip, r1
d0007ed6:	9906      	ldr	r1, [sp, #24]
d0007ed8:	ebac 0c00 	sub.w	ip, ip, r0
d0007edc:	f00c 0cff 	and.w	ip, ip, #255	; 0xff
d0007ee0:	f811 500c 	ldrb.w	r5, [r1, ip]
d0007ee4:	f015 000f 	ands.w	r0, r5, #15
d0007ee8:	d005      	beq.n	d0007ef6 <pjpeg_decode_mcu+0xdee>
d0007eea:	f7fe ffd1 	bl	d0006e90 <getBits.constprop.2>
d0007eee:	4b3d      	ldr	r3, [pc, #244]	; (d0007fe4 <pjpeg_decode_mcu+0xedc>)
d0007ef0:	881a      	ldrh	r2, [r3, #0]
d0007ef2:	9b02      	ldr	r3, [sp, #8]
d0007ef4:	781b      	ldrb	r3, [r3, #0]
d0007ef6:	3d01      	subs	r5, #1
d0007ef8:	b2ed      	uxtb	r5, r5
d0007efa:	2d0e      	cmp	r5, #14
d0007efc:	f63f a9fd 	bhi.w	d00072fa <pjpeg_decode_mcu+0x1f2>
d0007f00:	4939      	ldr	r1, [pc, #228]	; (d0007fe8 <pjpeg_decode_mcu+0xee0>)
d0007f02:	f831 1015 	ldrh.w	r1, [r1, r5, lsl #1]
d0007f06:	4281      	cmp	r1, r0
d0007f08:	f67f a9f7 	bls.w	d00072fa <pjpeg_decode_mcu+0x1f2>
d0007f0c:	4937      	ldr	r1, [pc, #220]	; (d0007fec <pjpeg_decode_mcu+0xee4>)
d0007f0e:	f831 1015 	ldrh.w	r1, [r1, r5, lsl #1]
d0007f12:	4408      	add	r0, r1
d0007f14:	b280      	uxth	r0, r0
d0007f16:	f7ff b9f0 	b.w	d00072fa <pjpeg_decode_mcu+0x1f2>
d0007f1a:	9b01      	ldr	r3, [sp, #4]
d0007f1c:	2b05      	cmp	r3, #5
d0007f1e:	f63f ab6e 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007f22:	e8df f013 	tbh	[pc, r3, lsl #1]
d0007f26:	003f      	.short	0x003f
d0007f28:	0019002c 	.word	0x0019002c
d0007f2c:	03100006 	.word	0x03100006
d0007f30:	02fe      	.short	0x02fe
d0007f32:	492f      	ldr	r1, [pc, #188]	; (d0007ff0 <pjpeg_decode_mcu+0xee8>)
d0007f34:	4d2f      	ldr	r5, [pc, #188]	; (d0007ff4 <pjpeg_decode_mcu+0xeec>)
d0007f36:	f101 0380 	add.w	r3, r1, #128	; 0x80
d0007f3a:	4c2f      	ldr	r4, [pc, #188]	; (d0007ff8 <pjpeg_decode_mcu+0xef0>)
d0007f3c:	482f      	ldr	r0, [pc, #188]	; (d0007ffc <pjpeg_decode_mcu+0xef4>)
d0007f3e:	f831 2b02 	ldrh.w	r2, [r1], #2
d0007f42:	b2d2      	uxtb	r2, r2
d0007f44:	4299      	cmp	r1, r3
d0007f46:	f800 2b01 	strb.w	r2, [r0], #1
d0007f4a:	f804 2b01 	strb.w	r2, [r4], #1
d0007f4e:	f805 2b01 	strb.w	r2, [r5], #1
d0007f52:	d1f4      	bne.n	d0007f3e <pjpeg_decode_mcu+0xe36>
d0007f54:	f7ff bb53 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007f58:	4925      	ldr	r1, [pc, #148]	; (d0007ff0 <pjpeg_decode_mcu+0xee8>)
d0007f5a:	4d29      	ldr	r5, [pc, #164]	; (d0008000 <pjpeg_decode_mcu+0xef8>)
d0007f5c:	f101 0380 	add.w	r3, r1, #128	; 0x80
d0007f60:	4c28      	ldr	r4, [pc, #160]	; (d0008004 <pjpeg_decode_mcu+0xefc>)
d0007f62:	4829      	ldr	r0, [pc, #164]	; (d0008008 <pjpeg_decode_mcu+0xf00>)
d0007f64:	f831 2b02 	ldrh.w	r2, [r1], #2
d0007f68:	b2d2      	uxtb	r2, r2
d0007f6a:	4299      	cmp	r1, r3
d0007f6c:	f800 2b01 	strb.w	r2, [r0], #1
d0007f70:	f804 2b01 	strb.w	r2, [r4], #1
d0007f74:	f805 2b01 	strb.w	r2, [r5], #1
d0007f78:	d1f4      	bne.n	d0007f64 <pjpeg_decode_mcu+0xe5c>
d0007f7a:	f7ff bb40 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007f7e:	491c      	ldr	r1, [pc, #112]	; (d0007ff0 <pjpeg_decode_mcu+0xee8>)
d0007f80:	4d22      	ldr	r5, [pc, #136]	; (d000800c <pjpeg_decode_mcu+0xf04>)
d0007f82:	f101 0380 	add.w	r3, r1, #128	; 0x80
d0007f86:	4c22      	ldr	r4, [pc, #136]	; (d0008010 <pjpeg_decode_mcu+0xf08>)
d0007f88:	4822      	ldr	r0, [pc, #136]	; (d0008014 <pjpeg_decode_mcu+0xf0c>)
d0007f8a:	f831 2b02 	ldrh.w	r2, [r1], #2
d0007f8e:	b2d2      	uxtb	r2, r2
d0007f90:	4299      	cmp	r1, r3
d0007f92:	f800 2b01 	strb.w	r2, [r0], #1
d0007f96:	f804 2b01 	strb.w	r2, [r4], #1
d0007f9a:	f805 2b01 	strb.w	r2, [r5], #1
d0007f9e:	d1f4      	bne.n	d0007f8a <pjpeg_decode_mcu+0xe82>
d0007fa0:	f7ff bb2d 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007fa4:	4912      	ldr	r1, [pc, #72]	; (d0007ff0 <pjpeg_decode_mcu+0xee8>)
d0007fa6:	4d1c      	ldr	r5, [pc, #112]	; (d0008018 <pjpeg_decode_mcu+0xf10>)
d0007fa8:	f101 0380 	add.w	r3, r1, #128	; 0x80
d0007fac:	4c1b      	ldr	r4, [pc, #108]	; (d000801c <pjpeg_decode_mcu+0xf14>)
d0007fae:	481c      	ldr	r0, [pc, #112]	; (d0008020 <pjpeg_decode_mcu+0xf18>)
d0007fb0:	f831 2b02 	ldrh.w	r2, [r1], #2
d0007fb4:	b2d2      	uxtb	r2, r2
d0007fb6:	4299      	cmp	r1, r3
d0007fb8:	f800 2b01 	strb.w	r2, [r0], #1
d0007fbc:	f804 2b01 	strb.w	r2, [r4], #1
d0007fc0:	f805 2b01 	strb.w	r2, [r5], #1
d0007fc4:	d1f4      	bne.n	d0007fb0 <pjpeg_decode_mcu+0xea8>
d0007fc6:	f7ff bb1a 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007fca:	9b01      	ldr	r3, [sp, #4]
d0007fcc:	2b03      	cmp	r3, #3
d0007fce:	f63f ab16 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0007fd2:	e8df f013 	tbh	[pc, r3, lsl #1]
d0007fd6:	003a      	.short	0x003a
d0007fd8:	01300027 	.word	0x01300027
d0007fdc:	011c      	.short	0x011c
d0007fde:	bf00      	nop
d0007fe0:	d000d5f8 	.word	0xd000d5f8
d0007fe4:	d000ded0 	.word	0xd000ded0
d0007fe8:	d000d598 	.word	0xd000d598
d0007fec:	d000d5b8 	.word	0xd000d5b8
d0007ff0:	d000ded4 	.word	0xd000ded4
d0007ff4:	d000e4a4 	.word	0xd000e4a4
d0007ff8:	d000e5a4 	.word	0xd000e5a4
d0007ffc:	d000e6a4 	.word	0xd000e6a4
d0008000:	d000e464 	.word	0xd000e464
d0008004:	d000e564 	.word	0xd000e564
d0008008:	d000e664 	.word	0xd000e664
d000800c:	d000e424 	.word	0xd000e424
d0008010:	d000e524 	.word	0xd000e524
d0008014:	d000e624 	.word	0xd000e624
d0008018:	d000e3e4 	.word	0xd000e3e4
d000801c:	d000e4e4 	.word	0xd000e4e4
d0008020:	d000e5e4 	.word	0xd000e5e4
d0008024:	49b3      	ldr	r1, [pc, #716]	; (d00082f4 <pjpeg_decode_mcu+0x11ec>)
d0008026:	4db4      	ldr	r5, [pc, #720]	; (d00082f8 <pjpeg_decode_mcu+0x11f0>)
d0008028:	f101 0380 	add.w	r3, r1, #128	; 0x80
d000802c:	4cb3      	ldr	r4, [pc, #716]	; (d00082fc <pjpeg_decode_mcu+0x11f4>)
d000802e:	48b4      	ldr	r0, [pc, #720]	; (d0008300 <pjpeg_decode_mcu+0x11f8>)
d0008030:	f831 2b02 	ldrh.w	r2, [r1], #2
d0008034:	b2d2      	uxtb	r2, r2
d0008036:	4299      	cmp	r1, r3
d0008038:	f800 2b01 	strb.w	r2, [r0], #1
d000803c:	f804 2b01 	strb.w	r2, [r4], #1
d0008040:	f805 2b01 	strb.w	r2, [r5], #1
d0008044:	d1f4      	bne.n	d0008030 <pjpeg_decode_mcu+0xf28>
d0008046:	f7ff bada 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000804a:	49aa      	ldr	r1, [pc, #680]	; (d00082f4 <pjpeg_decode_mcu+0x11ec>)
d000804c:	4dad      	ldr	r5, [pc, #692]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d000804e:	f101 0380 	add.w	r3, r1, #128	; 0x80
d0008052:	4cad      	ldr	r4, [pc, #692]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d0008054:	48ad      	ldr	r0, [pc, #692]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d0008056:	f831 2b02 	ldrh.w	r2, [r1], #2
d000805a:	b2d2      	uxtb	r2, r2
d000805c:	4299      	cmp	r1, r3
d000805e:	f800 2b01 	strb.w	r2, [r0], #1
d0008062:	f804 2b01 	strb.w	r2, [r4], #1
d0008066:	f805 2b01 	strb.w	r2, [r5], #1
d000806a:	d1f4      	bne.n	d0008056 <pjpeg_decode_mcu+0xf4e>
d000806c:	f7ff bac7 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008070:	9b01      	ldr	r3, [sp, #4]
d0008072:	2b03      	cmp	r3, #3
d0008074:	f63f aac3 	bhi.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008078:	e8df f013 	tbh	[pc, r3, lsl #1]
d000807c:	00040017 	.word	0x00040017
d0008080:	00bf00d3 	.word	0x00bf00d3
d0008084:	499b      	ldr	r1, [pc, #620]	; (d00082f4 <pjpeg_decode_mcu+0x11ec>)
d0008086:	4da2      	ldr	r5, [pc, #648]	; (d0008310 <pjpeg_decode_mcu+0x1208>)
d0008088:	f101 0380 	add.w	r3, r1, #128	; 0x80
d000808c:	4ca1      	ldr	r4, [pc, #644]	; (d0008314 <pjpeg_decode_mcu+0x120c>)
d000808e:	48a2      	ldr	r0, [pc, #648]	; (d0008318 <pjpeg_decode_mcu+0x1210>)
d0008090:	f831 2b02 	ldrh.w	r2, [r1], #2
d0008094:	b2d2      	uxtb	r2, r2
d0008096:	4299      	cmp	r1, r3
d0008098:	f800 2b01 	strb.w	r2, [r0], #1
d000809c:	f804 2b01 	strb.w	r2, [r4], #1
d00080a0:	f805 2b01 	strb.w	r2, [r5], #1
d00080a4:	d1f4      	bne.n	d0008090 <pjpeg_decode_mcu+0xf88>
d00080a6:	f7ff baaa 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00080aa:	4992      	ldr	r1, [pc, #584]	; (d00082f4 <pjpeg_decode_mcu+0x11ec>)
d00080ac:	4d95      	ldr	r5, [pc, #596]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d00080ae:	f101 0380 	add.w	r3, r1, #128	; 0x80
d00080b2:	4c95      	ldr	r4, [pc, #596]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d00080b4:	4895      	ldr	r0, [pc, #596]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d00080b6:	f831 2b02 	ldrh.w	r2, [r1], #2
d00080ba:	b2d2      	uxtb	r2, r2
d00080bc:	4299      	cmp	r1, r3
d00080be:	f800 2b01 	strb.w	r2, [r0], #1
d00080c2:	f804 2b01 	strb.w	r2, [r4], #1
d00080c6:	f805 2b01 	strb.w	r2, [r5], #1
d00080ca:	d1f4      	bne.n	d00080b6 <pjpeg_decode_mcu+0xfae>
d00080cc:	f7ff ba97 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00080d0:	f7fe fa32 	bl	d0006538 <getChar>
d00080d4:	28ff      	cmp	r0, #255	; 0xff
d00080d6:	4605      	mov	r5, r0
d00080d8:	d05c      	beq.n	d0008194 <pjpeg_decode_mcu+0x108c>
d00080da:	4b90      	ldr	r3, [pc, #576]	; (d000831c <pjpeg_decode_mcu+0x1214>)
d00080dc:	881a      	ldrh	r2, [r3, #0]
d00080de:	9b02      	ldr	r3, [sp, #8]
d00080e0:	432a      	orrs	r2, r5
d00080e2:	781b      	ldrb	r3, [r3, #0]
d00080e4:	b292      	uxth	r2, r2
d00080e6:	3308      	adds	r3, #8
d00080e8:	b2db      	uxtb	r3, r3
d00080ea:	f7ff b851 	b.w	d0007190 <pjpeg_decode_mcu+0x88>
d00080ee:	231c      	movs	r3, #28
d00080f0:	461a      	mov	r2, r3
d00080f2:	9303      	str	r3, [sp, #12]
d00080f4:	4b8a      	ldr	r3, [pc, #552]	; (d0008320 <pjpeg_decode_mcu+0x1218>)
d00080f6:	781b      	ldrb	r3, [r3, #0]
d00080f8:	2b00      	cmp	r3, #0
d00080fa:	bf18      	it	ne
d00080fc:	461a      	movne	r2, r3
d00080fe:	9203      	str	r2, [sp, #12]
d0008100:	9803      	ldr	r0, [sp, #12]
d0008102:	b00f      	add	sp, #60	; 0x3c
d0008104:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0008108:	9a01      	ldr	r2, [sp, #4]
d000810a:	2a01      	cmp	r2, #1
d000810c:	f000 8381 	beq.w	d0008812 <pjpeg_decode_mcu+0x170a>
d0008110:	2a02      	cmp	r2, #2
d0008112:	f000 834f 	beq.w	d00087b4 <pjpeg_decode_mcu+0x16ac>
d0008116:	2a00      	cmp	r2, #0
d0008118:	f47f aa71 	bne.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000811c:	4a7b      	ldr	r2, [pc, #492]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d000811e:	497a      	ldr	r1, [pc, #488]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d0008120:	7013      	strb	r3, [r2, #0]
d0008122:	4a78      	ldr	r2, [pc, #480]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d0008124:	700b      	strb	r3, [r1, #0]
d0008126:	7013      	strb	r3, [r2, #0]
d0008128:	f7ff ba69 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000812c:	4a77      	ldr	r2, [pc, #476]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d000812e:	7013      	strb	r3, [r2, #0]
d0008130:	f7ff ba65 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008134:	496f      	ldr	r1, [pc, #444]	; (d00082f4 <pjpeg_decode_mcu+0x11ec>)
d0008136:	4d73      	ldr	r5, [pc, #460]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d0008138:	f101 0380 	add.w	r3, r1, #128	; 0x80
d000813c:	4c72      	ldr	r4, [pc, #456]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d000813e:	4873      	ldr	r0, [pc, #460]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d0008140:	f831 2b02 	ldrh.w	r2, [r1], #2
d0008144:	b2d2      	uxtb	r2, r2
d0008146:	4299      	cmp	r1, r3
d0008148:	f800 2b01 	strb.w	r2, [r0], #1
d000814c:	f804 2b01 	strb.w	r2, [r4], #1
d0008150:	f805 2b01 	strb.w	r2, [r5], #1
d0008154:	d1f4      	bne.n	d0008140 <pjpeg_decode_mcu+0x1038>
d0008156:	f7ff ba52 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000815a:	9b01      	ldr	r3, [sp, #4]
d000815c:	2b01      	cmp	r3, #1
d000815e:	f000 82eb 	beq.w	d0008738 <pjpeg_decode_mcu+0x1630>
d0008162:	2b02      	cmp	r3, #2
d0008164:	f000 82a5 	beq.w	d00086b2 <pjpeg_decode_mcu+0x15aa>
d0008168:	2b00      	cmp	r3, #0
d000816a:	f47f aa48 	bne.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000816e:	4961      	ldr	r1, [pc, #388]	; (d00082f4 <pjpeg_decode_mcu+0x11ec>)
d0008170:	4d64      	ldr	r5, [pc, #400]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d0008172:	f101 0380 	add.w	r3, r1, #128	; 0x80
d0008176:	4c64      	ldr	r4, [pc, #400]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d0008178:	4864      	ldr	r0, [pc, #400]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d000817a:	f831 2b02 	ldrh.w	r2, [r1], #2
d000817e:	b2d2      	uxtb	r2, r2
d0008180:	4299      	cmp	r1, r3
d0008182:	f800 2b01 	strb.w	r2, [r0], #1
d0008186:	f804 2b01 	strb.w	r2, [r4], #1
d000818a:	f805 2b01 	strb.w	r2, [r5], #1
d000818e:	d1f4      	bne.n	d000817a <pjpeg_decode_mcu+0x1072>
d0008190:	f7ff ba35 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008194:	f7fe f9d0 	bl	d0006538 <getChar>
d0008198:	2800      	cmp	r0, #0
d000819a:	d09e      	beq.n	d00080da <pjpeg_decode_mcu+0xfd2>
d000819c:	4b61      	ldr	r3, [pc, #388]	; (d0008324 <pjpeg_decode_mcu+0x121c>)
d000819e:	4962      	ldr	r1, [pc, #392]	; (d0008328 <pjpeg_decode_mcu+0x1220>)
d00081a0:	781b      	ldrb	r3, [r3, #0]
d00081a2:	460f      	mov	r7, r1
d00081a4:	f8df c184 	ldr.w	ip, [pc, #388]	; d000832c <pjpeg_decode_mcu+0x1224>
d00081a8:	1e5a      	subs	r2, r3, #1
d00081aa:	7809      	ldrb	r1, [r1, #0]
d00081ac:	3b02      	subs	r3, #2
d00081ae:	b2d2      	uxtb	r2, r2
d00081b0:	3102      	adds	r1, #2
d00081b2:	b2db      	uxtb	r3, r3
d00081b4:	f80c 0002 	strb.w	r0, [ip, r2]
d00081b8:	4a5a      	ldr	r2, [pc, #360]	; (d0008324 <pjpeg_decode_mcu+0x121c>)
d00081ba:	7039      	strb	r1, [r7, #0]
d00081bc:	7013      	strb	r3, [r2, #0]
d00081be:	f80c 5003 	strb.w	r5, [ip, r3]
d00081c2:	e78a      	b.n	d00080da <pjpeg_decode_mcu+0xfd2>
d00081c4:	9303      	str	r3, [sp, #12]
d00081c6:	9803      	ldr	r0, [sp, #12]
d00081c8:	b00f      	add	sp, #60	; 0x3c
d00081ca:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00081ce:	4a4f      	ldr	r2, [pc, #316]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d00081d0:	494d      	ldr	r1, [pc, #308]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d00081d2:	f882 3040 	strb.w	r3, [r2, #64]	; 0x40
d00081d6:	4a4b      	ldr	r2, [pc, #300]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d00081d8:	f881 3040 	strb.w	r3, [r1, #64]	; 0x40
d00081dc:	f882 3040 	strb.w	r3, [r2, #64]	; 0x40
d00081e0:	f7ff ba0d 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00081e4:	4a49      	ldr	r2, [pc, #292]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d00081e6:	4948      	ldr	r1, [pc, #288]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d00081e8:	f882 3080 	strb.w	r3, [r2, #128]	; 0x80
d00081ec:	4a45      	ldr	r2, [pc, #276]	; (d0008304 <pjpeg_decode_mcu+0x11fc>)
d00081ee:	f881 3080 	strb.w	r3, [r1, #128]	; 0x80
d00081f2:	f882 3080 	strb.w	r3, [r2, #128]	; 0x80
d00081f6:	f7ff ba02 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00081fa:	2100      	movs	r1, #0
d00081fc:	4608      	mov	r0, r1
d00081fe:	f7fe f865 	bl	d00062cc <upsampleCrH>
d0008202:	2140      	movs	r1, #64	; 0x40
d0008204:	2004      	movs	r0, #4
d0008206:	f7fe f861 	bl	d00062cc <upsampleCrH>
d000820a:	f7ff b9f8 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000820e:	2100      	movs	r1, #0
d0008210:	4608      	mov	r0, r1
d0008212:	f7fe f8f1 	bl	d00063f8 <upsampleCrV>
d0008216:	2180      	movs	r1, #128	; 0x80
d0008218:	2020      	movs	r0, #32
d000821a:	f7fe f8ed 	bl	d00063f8 <upsampleCrV>
d000821e:	f7ff b9ee 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008222:	2100      	movs	r1, #0
d0008224:	4608      	mov	r0, r1
d0008226:	f7fd fe13 	bl	d0005e50 <upsampleCbH>
d000822a:	2140      	movs	r1, #64	; 0x40
d000822c:	2004      	movs	r0, #4
d000822e:	f7fd fe0f 	bl	d0005e50 <upsampleCbH>
d0008232:	f7ff b9e4 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008236:	2100      	movs	r1, #0
d0008238:	4608      	mov	r0, r1
d000823a:	f7fd feab 	bl	d0005f94 <upsampleCbV>
d000823e:	2180      	movs	r1, #128	; 0x80
d0008240:	2020      	movs	r0, #32
d0008242:	f7fd fea7 	bl	d0005f94 <upsampleCbV>
d0008246:	f7ff b9da 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000824a:	eb03 0443 	add.w	r4, r3, r3, lsl #1
d000824e:	f1a3 00b3 	sub.w	r0, r3, #179	; 0xb3
d0008252:	b21a      	sxth	r2, r3
d0008254:	492d      	ldr	r1, [pc, #180]	; (d000830c <pjpeg_decode_mcu+0x1204>)
d0008256:	eb04 1404 	add.w	r4, r4, r4, lsl #4
d000825a:	eb03 0344 	add.w	r3, r3, r4, lsl #1
d000825e:	780c      	ldrb	r4, [r1, #0]
d0008260:	eb00 2313 	add.w	r3, r0, r3, lsr #8
d0008264:	b29b      	uxth	r3, r3
d0008266:	1918      	adds	r0, r3, r4
d0008268:	b280      	uxth	r0, r0
d000826a:	28ff      	cmp	r0, #255	; 0xff
d000826c:	d906      	bls.n	d000827c <pjpeg_decode_mcu+0x1174>
d000826e:	b204      	sxth	r4, r0
d0008270:	2c00      	cmp	r4, #0
d0008272:	f2c0 830a 	blt.w	d000888a <pjpeg_decode_mcu+0x1782>
d0008276:	2cff      	cmp	r4, #255	; 0xff
d0008278:	f300 8364 	bgt.w	d0008944 <pjpeg_decode_mcu+0x183c>
d000827c:	b2c0      	uxtb	r0, r0
d000827e:	f891 4040 	ldrb.w	r4, [r1, #64]	; 0x40
d0008282:	7008      	strb	r0, [r1, #0]
d0008284:	4423      	add	r3, r4
d0008286:	b29b      	uxth	r3, r3
d0008288:	2bff      	cmp	r3, #255	; 0xff
d000828a:	d906      	bls.n	d000829a <pjpeg_decode_mcu+0x1192>
d000828c:	b218      	sxth	r0, r3
d000828e:	2800      	cmp	r0, #0
d0008290:	f2c0 8310 	blt.w	d00088b4 <pjpeg_decode_mcu+0x17ac>
d0008294:	28ff      	cmp	r0, #255	; 0xff
d0008296:	f300 835d 	bgt.w	d0008954 <pjpeg_decode_mcu+0x184c>
d000829a:	b2db      	uxtb	r3, r3
d000829c:	ebc2 1402 	rsb	r4, r2, r2, lsl #4
d00082a0:	f881 3040 	strb.w	r3, [r1, #64]	; 0x40
d00082a4:	4818      	ldr	r0, [pc, #96]	; (d0008308 <pjpeg_decode_mcu+0x1200>)
d00082a6:	eb02 0284 	add.w	r2, r2, r4, lsl #2
d00082aa:	7801      	ldrb	r1, [r0, #0]
d00082ac:	ebc2 0282 	rsb	r2, r2, r2, lsl #2
d00082b0:	0a13      	lsrs	r3, r2, #8
d00082b2:	3b5b      	subs	r3, #91	; 0x5b
d00082b4:	b29b      	uxth	r3, r3
d00082b6:	1aca      	subs	r2, r1, r3
d00082b8:	b292      	uxth	r2, r2
d00082ba:	2aff      	cmp	r2, #255	; 0xff
d00082bc:	d906      	bls.n	d00082cc <pjpeg_decode_mcu+0x11c4>
d00082be:	b211      	sxth	r1, r2
d00082c0:	2900      	cmp	r1, #0
d00082c2:	f2c0 82f9 	blt.w	d00088b8 <pjpeg_decode_mcu+0x17b0>
d00082c6:	29ff      	cmp	r1, #255	; 0xff
d00082c8:	f300 8346 	bgt.w	d0008958 <pjpeg_decode_mcu+0x1850>
d00082cc:	b2d1      	uxtb	r1, r2
d00082ce:	f890 2040 	ldrb.w	r2, [r0, #64]	; 0x40
d00082d2:	7001      	strb	r1, [r0, #0]
d00082d4:	1ad3      	subs	r3, r2, r3
d00082d6:	b29b      	uxth	r3, r3
d00082d8:	2bff      	cmp	r3, #255	; 0xff
d00082da:	d906      	bls.n	d00082ea <pjpeg_decode_mcu+0x11e2>
d00082dc:	b21a      	sxth	r2, r3
d00082de:	2a00      	cmp	r2, #0
d00082e0:	f2c0 82fa 	blt.w	d00088d8 <pjpeg_decode_mcu+0x17d0>
d00082e4:	2aff      	cmp	r2, #255	; 0xff
d00082e6:	f300 8347 	bgt.w	d0008978 <pjpeg_decode_mcu+0x1870>
d00082ea:	b2db      	uxtb	r3, r3
d00082ec:	f880 3040 	strb.w	r3, [r0, #64]	; 0x40
d00082f0:	f7ff b985 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00082f4:	d000ded4 	.word	0xd000ded4
d00082f8:	d000e464 	.word	0xd000e464
d00082fc:	d000e564 	.word	0xd000e564
d0008300:	d000e664 	.word	0xd000e664
d0008304:	d000e3e4 	.word	0xd000e3e4
d0008308:	d000e4e4 	.word	0xd000e4e4
d000830c:	d000e5e4 	.word	0xd000e5e4
d0008310:	d000e424 	.word	0xd000e424
d0008314:	d000e524 	.word	0xd000e524
d0008318:	d000e624 	.word	0xd000e624
d000831c:	d000ded0 	.word	0xd000ded0
d0008320:	d000ded3 	.word	0xd000ded3
d0008324:	d000e3d9 	.word	0xd000e3d9
d0008328:	d000e3d8 	.word	0xd000e3d8
d000832c:	d000e2d8 	.word	0xd000e2d8
d0008330:	eb03 0183 	add.w	r1, r3, r3, lsl #2
d0008334:	4892      	ldr	r0, [pc, #584]	; (d0008580 <pjpeg_decode_mcu+0x1478>)
d0008336:	b21a      	sxth	r2, r3
d0008338:	eb03 0141 	add.w	r1, r3, r1, lsl #1
d000833c:	7804      	ldrb	r4, [r0, #0]
d000833e:	f3c1 1157 	ubfx	r1, r1, #5, #24
d0008342:	392c      	subs	r1, #44	; 0x2c
d0008344:	b289      	uxth	r1, r1
d0008346:	1a64      	subs	r4, r4, r1
d0008348:	b2a4      	uxth	r4, r4
d000834a:	2cff      	cmp	r4, #255	; 0xff
d000834c:	d906      	bls.n	d000835c <pjpeg_decode_mcu+0x1254>
d000834e:	b225      	sxth	r5, r4
d0008350:	2d00      	cmp	r5, #0
d0008352:	f2c0 82b3 	blt.w	d00088bc <pjpeg_decode_mcu+0x17b4>
d0008356:	2dff      	cmp	r5, #255	; 0xff
d0008358:	f300 8308 	bgt.w	d000896c <pjpeg_decode_mcu+0x1864>
d000835c:	b2e5      	uxtb	r5, r4
d000835e:	f890 4080 	ldrb.w	r4, [r0, #128]	; 0x80
d0008362:	7005      	strb	r5, [r0, #0]
d0008364:	1a61      	subs	r1, r4, r1
d0008366:	b289      	uxth	r1, r1
d0008368:	29ff      	cmp	r1, #255	; 0xff
d000836a:	d906      	bls.n	d000837a <pjpeg_decode_mcu+0x1272>
d000836c:	b20c      	sxth	r4, r1
d000836e:	2c00      	cmp	r4, #0
d0008370:	f2c0 82a6 	blt.w	d00088c0 <pjpeg_decode_mcu+0x17b8>
d0008374:	2cff      	cmp	r4, #255	; 0xff
d0008376:	f300 82fb 	bgt.w	d0008970 <pjpeg_decode_mcu+0x1868>
d000837a:	b2c9      	uxtb	r1, r1
d000837c:	eb02 0242 	add.w	r2, r2, r2, lsl #1
d0008380:	3be3      	subs	r3, #227	; 0xe3
d0008382:	f880 1080 	strb.w	r1, [r0, #128]	; 0x80
d0008386:	eb02 1242 	add.w	r2, r2, r2, lsl #5
d000838a:	497e      	ldr	r1, [pc, #504]	; (d0008584 <pjpeg_decode_mcu+0x147c>)
d000838c:	f3c2 12d7 	ubfx	r2, r2, #7, #24
d0008390:	7808      	ldrb	r0, [r1, #0]
d0008392:	4413      	add	r3, r2
d0008394:	b29b      	uxth	r3, r3
d0008396:	181a      	adds	r2, r3, r0
d0008398:	b292      	uxth	r2, r2
d000839a:	2aff      	cmp	r2, #255	; 0xff
d000839c:	d906      	bls.n	d00083ac <pjpeg_decode_mcu+0x12a4>
d000839e:	b210      	sxth	r0, r2
d00083a0:	2800      	cmp	r0, #0
d00083a2:	f2c0 828f 	blt.w	d00088c4 <pjpeg_decode_mcu+0x17bc>
d00083a6:	28ff      	cmp	r0, #255	; 0xff
d00083a8:	f300 82dc 	bgt.w	d0008964 <pjpeg_decode_mcu+0x185c>
d00083ac:	b2d2      	uxtb	r2, r2
d00083ae:	f891 0080 	ldrb.w	r0, [r1, #128]	; 0x80
d00083b2:	700a      	strb	r2, [r1, #0]
d00083b4:	4403      	add	r3, r0
d00083b6:	b29b      	uxth	r3, r3
d00083b8:	2bff      	cmp	r3, #255	; 0xff
d00083ba:	d906      	bls.n	d00083ca <pjpeg_decode_mcu+0x12c2>
d00083bc:	b21a      	sxth	r2, r3
d00083be:	2a00      	cmp	r2, #0
d00083c0:	f2c0 8282 	blt.w	d00088c8 <pjpeg_decode_mcu+0x17c0>
d00083c4:	2aff      	cmp	r2, #255	; 0xff
d00083c6:	f300 82cf 	bgt.w	d0008968 <pjpeg_decode_mcu+0x1860>
d00083ca:	b2db      	uxtb	r3, r3
d00083cc:	f881 3080 	strb.w	r3, [r1, #128]	; 0x80
d00083d0:	f7ff b915 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00083d4:	eb03 0443 	add.w	r4, r3, r3, lsl #1
d00083d8:	f1a3 00b3 	sub.w	r0, r3, #179	; 0xb3
d00083dc:	b21a      	sxth	r2, r3
d00083de:	496a      	ldr	r1, [pc, #424]	; (d0008588 <pjpeg_decode_mcu+0x1480>)
d00083e0:	eb04 1404 	add.w	r4, r4, r4, lsl #4
d00083e4:	eb03 0344 	add.w	r3, r3, r4, lsl #1
d00083e8:	780c      	ldrb	r4, [r1, #0]
d00083ea:	eb00 2313 	add.w	r3, r0, r3, lsr #8
d00083ee:	b29b      	uxth	r3, r3
d00083f0:	1918      	adds	r0, r3, r4
d00083f2:	b280      	uxth	r0, r0
d00083f4:	28ff      	cmp	r0, #255	; 0xff
d00083f6:	d906      	bls.n	d0008406 <pjpeg_decode_mcu+0x12fe>
d00083f8:	b204      	sxth	r4, r0
d00083fa:	2c00      	cmp	r4, #0
d00083fc:	f2c0 8266 	blt.w	d00088cc <pjpeg_decode_mcu+0x17c4>
d0008400:	2cff      	cmp	r4, #255	; 0xff
d0008402:	f300 82bb 	bgt.w	d000897c <pjpeg_decode_mcu+0x1874>
d0008406:	b2c0      	uxtb	r0, r0
d0008408:	f891 4080 	ldrb.w	r4, [r1, #128]	; 0x80
d000840c:	7008      	strb	r0, [r1, #0]
d000840e:	4423      	add	r3, r4
d0008410:	b29b      	uxth	r3, r3
d0008412:	2bff      	cmp	r3, #255	; 0xff
d0008414:	d906      	bls.n	d0008424 <pjpeg_decode_mcu+0x131c>
d0008416:	b218      	sxth	r0, r3
d0008418:	2800      	cmp	r0, #0
d000841a:	f2c0 8259 	blt.w	d00088d0 <pjpeg_decode_mcu+0x17c8>
d000841e:	28ff      	cmp	r0, #255	; 0xff
d0008420:	f300 82ae 	bgt.w	d0008980 <pjpeg_decode_mcu+0x1878>
d0008424:	b2db      	uxtb	r3, r3
d0008426:	ebc2 1402 	rsb	r4, r2, r2, lsl #4
d000842a:	f881 3080 	strb.w	r3, [r1, #128]	; 0x80
d000842e:	4854      	ldr	r0, [pc, #336]	; (d0008580 <pjpeg_decode_mcu+0x1478>)
d0008430:	eb02 0284 	add.w	r2, r2, r4, lsl #2
d0008434:	7801      	ldrb	r1, [r0, #0]
d0008436:	ebc2 0282 	rsb	r2, r2, r2, lsl #2
d000843a:	0a13      	lsrs	r3, r2, #8
d000843c:	3b5b      	subs	r3, #91	; 0x5b
d000843e:	b29b      	uxth	r3, r3
d0008440:	1aca      	subs	r2, r1, r3
d0008442:	b292      	uxth	r2, r2
d0008444:	2aff      	cmp	r2, #255	; 0xff
d0008446:	d906      	bls.n	d0008456 <pjpeg_decode_mcu+0x134e>
d0008448:	b211      	sxth	r1, r2
d000844a:	2900      	cmp	r1, #0
d000844c:	f2c0 8219 	blt.w	d0008882 <pjpeg_decode_mcu+0x177a>
d0008450:	29ff      	cmp	r1, #255	; 0xff
d0008452:	f300 827b 	bgt.w	d000894c <pjpeg_decode_mcu+0x1844>
d0008456:	b2d1      	uxtb	r1, r2
d0008458:	f890 2080 	ldrb.w	r2, [r0, #128]	; 0x80
d000845c:	7001      	strb	r1, [r0, #0]
d000845e:	1ad3      	subs	r3, r2, r3
d0008460:	b29b      	uxth	r3, r3
d0008462:	2bff      	cmp	r3, #255	; 0xff
d0008464:	d906      	bls.n	d0008474 <pjpeg_decode_mcu+0x136c>
d0008466:	b21a      	sxth	r2, r3
d0008468:	2a00      	cmp	r2, #0
d000846a:	f2c0 820c 	blt.w	d0008886 <pjpeg_decode_mcu+0x177e>
d000846e:	2aff      	cmp	r2, #255	; 0xff
d0008470:	f300 826e 	bgt.w	d0008950 <pjpeg_decode_mcu+0x1848>
d0008474:	b2db      	uxtb	r3, r3
d0008476:	f880 3080 	strb.w	r3, [r0, #128]	; 0x80
d000847a:	f7ff b8c0 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000847e:	eb03 0183 	add.w	r1, r3, r3, lsl #2
d0008482:	483f      	ldr	r0, [pc, #252]	; (d0008580 <pjpeg_decode_mcu+0x1478>)
d0008484:	b21a      	sxth	r2, r3
d0008486:	eb03 0141 	add.w	r1, r3, r1, lsl #1
d000848a:	7804      	ldrb	r4, [r0, #0]
d000848c:	f3c1 1157 	ubfx	r1, r1, #5, #24
d0008490:	392c      	subs	r1, #44	; 0x2c
d0008492:	b289      	uxth	r1, r1
d0008494:	1a64      	subs	r4, r4, r1
d0008496:	b2a4      	uxth	r4, r4
d0008498:	2cff      	cmp	r4, #255	; 0xff
d000849a:	d906      	bls.n	d00084aa <pjpeg_decode_mcu+0x13a2>
d000849c:	b225      	sxth	r5, r4
d000849e:	2d00      	cmp	r5, #0
d00084a0:	f2c0 81f5 	blt.w	d000888e <pjpeg_decode_mcu+0x1786>
d00084a4:	2dff      	cmp	r5, #255	; 0xff
d00084a6:	f300 824f 	bgt.w	d0008948 <pjpeg_decode_mcu+0x1840>
d00084aa:	b2e5      	uxtb	r5, r4
d00084ac:	f890 4040 	ldrb.w	r4, [r0, #64]	; 0x40
d00084b0:	7005      	strb	r5, [r0, #0]
d00084b2:	1a61      	subs	r1, r4, r1
d00084b4:	b289      	uxth	r1, r1
d00084b6:	29ff      	cmp	r1, #255	; 0xff
d00084b8:	d906      	bls.n	d00084c8 <pjpeg_decode_mcu+0x13c0>
d00084ba:	b20c      	sxth	r4, r1
d00084bc:	2c00      	cmp	r4, #0
d00084be:	f2c0 81f5 	blt.w	d00088ac <pjpeg_decode_mcu+0x17a4>
d00084c2:	2cff      	cmp	r4, #255	; 0xff
d00084c4:	f300 824a 	bgt.w	d000895c <pjpeg_decode_mcu+0x1854>
d00084c8:	b2c9      	uxtb	r1, r1
d00084ca:	eb02 0242 	add.w	r2, r2, r2, lsl #1
d00084ce:	3be3      	subs	r3, #227	; 0xe3
d00084d0:	f880 1040 	strb.w	r1, [r0, #64]	; 0x40
d00084d4:	eb02 1242 	add.w	r2, r2, r2, lsl #5
d00084d8:	492a      	ldr	r1, [pc, #168]	; (d0008584 <pjpeg_decode_mcu+0x147c>)
d00084da:	f3c2 12d7 	ubfx	r2, r2, #7, #24
d00084de:	7808      	ldrb	r0, [r1, #0]
d00084e0:	4413      	add	r3, r2
d00084e2:	b29b      	uxth	r3, r3
d00084e4:	181a      	adds	r2, r3, r0
d00084e6:	b292      	uxth	r2, r2
d00084e8:	2aff      	cmp	r2, #255	; 0xff
d00084ea:	d906      	bls.n	d00084fa <pjpeg_decode_mcu+0x13f2>
d00084ec:	b210      	sxth	r0, r2
d00084ee:	2800      	cmp	r0, #0
d00084f0:	f2c0 81de 	blt.w	d00088b0 <pjpeg_decode_mcu+0x17a8>
d00084f4:	28ff      	cmp	r0, #255	; 0xff
d00084f6:	f300 8233 	bgt.w	d0008960 <pjpeg_decode_mcu+0x1858>
d00084fa:	b2d2      	uxtb	r2, r2
d00084fc:	f891 0040 	ldrb.w	r0, [r1, #64]	; 0x40
d0008500:	700a      	strb	r2, [r1, #0]
d0008502:	4403      	add	r3, r0
d0008504:	b29b      	uxth	r3, r3
d0008506:	2bff      	cmp	r3, #255	; 0xff
d0008508:	d906      	bls.n	d0008518 <pjpeg_decode_mcu+0x1410>
d000850a:	b21a      	sxth	r2, r3
d000850c:	2a00      	cmp	r2, #0
d000850e:	f2c0 81e1 	blt.w	d00088d4 <pjpeg_decode_mcu+0x17cc>
d0008512:	2aff      	cmp	r2, #255	; 0xff
d0008514:	f300 822e 	bgt.w	d0008974 <pjpeg_decode_mcu+0x186c>
d0008518:	b2db      	uxtb	r3, r3
d000851a:	f881 3040 	strb.w	r3, [r1, #64]	; 0x40
d000851e:	f7ff b86e 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008522:	2100      	movs	r1, #0
d0008524:	4608      	mov	r0, r1
d0008526:	f7fd fddf 	bl	d00060e8 <upsampleCr>
d000852a:	2140      	movs	r1, #64	; 0x40
d000852c:	2004      	movs	r0, #4
d000852e:	f7fd fddb 	bl	d00060e8 <upsampleCr>
d0008532:	2180      	movs	r1, #128	; 0x80
d0008534:	2020      	movs	r0, #32
d0008536:	f7fd fdd7 	bl	d00060e8 <upsampleCr>
d000853a:	21c0      	movs	r1, #192	; 0xc0
d000853c:	2024      	movs	r0, #36	; 0x24
d000853e:	f7fd fdd3 	bl	d00060e8 <upsampleCr>
d0008542:	f7ff b85c 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008546:	2100      	movs	r1, #0
d0008548:	4608      	mov	r0, r1
d000854a:	f7fd fb93 	bl	d0005c74 <upsampleCb>
d000854e:	2140      	movs	r1, #64	; 0x40
d0008550:	2004      	movs	r0, #4
d0008552:	f7fd fb8f 	bl	d0005c74 <upsampleCb>
d0008556:	2180      	movs	r1, #128	; 0x80
d0008558:	2020      	movs	r0, #32
d000855a:	f7fd fb8b 	bl	d0005c74 <upsampleCb>
d000855e:	21c0      	movs	r1, #192	; 0xc0
d0008560:	2024      	movs	r0, #36	; 0x24
d0008562:	f7fd fb87 	bl	d0005c74 <upsampleCb>
d0008566:	f7ff b84a 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000856a:	4a07      	ldr	r2, [pc, #28]	; (d0008588 <pjpeg_decode_mcu+0x1480>)
d000856c:	4904      	ldr	r1, [pc, #16]	; (d0008580 <pjpeg_decode_mcu+0x1478>)
d000856e:	f882 30c0 	strb.w	r3, [r2, #192]	; 0xc0
d0008572:	4a04      	ldr	r2, [pc, #16]	; (d0008584 <pjpeg_decode_mcu+0x147c>)
d0008574:	f881 30c0 	strb.w	r3, [r1, #192]	; 0xc0
d0008578:	f882 30c0 	strb.w	r3, [r2, #192]	; 0xc0
d000857c:	f7ff b83f 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008580:	d000e4e4 	.word	0xd000e4e4
d0008584:	d000e3e4 	.word	0xd000e3e4
d0008588:	d000e5e4 	.word	0xd000e5e4
d000858c:	eb03 0183 	add.w	r1, r3, r3, lsl #2
d0008590:	48c0      	ldr	r0, [pc, #768]	; (d0008894 <pjpeg_decode_mcu+0x178c>)
d0008592:	b21a      	sxth	r2, r3
d0008594:	eb03 0141 	add.w	r1, r3, r1, lsl #1
d0008598:	7804      	ldrb	r4, [r0, #0]
d000859a:	f3c1 1157 	ubfx	r1, r1, #5, #24
d000859e:	392c      	subs	r1, #44	; 0x2c
d00085a0:	b289      	uxth	r1, r1
d00085a2:	1a64      	subs	r4, r4, r1
d00085a4:	b2a4      	uxth	r4, r4
d00085a6:	2cff      	cmp	r4, #255	; 0xff
d00085a8:	d906      	bls.n	d00085b8 <pjpeg_decode_mcu+0x14b0>
d00085aa:	b225      	sxth	r5, r4
d00085ac:	2d00      	cmp	r5, #0
d00085ae:	f2c0 81a1 	blt.w	d00088f4 <pjpeg_decode_mcu+0x17ec>
d00085b2:	2dff      	cmp	r5, #255	; 0xff
d00085b4:	f300 81f4 	bgt.w	d00089a0 <pjpeg_decode_mcu+0x1898>
d00085b8:	b2e5      	uxtb	r5, r4
d00085ba:	f890 4040 	ldrb.w	r4, [r0, #64]	; 0x40
d00085be:	7005      	strb	r5, [r0, #0]
d00085c0:	1a64      	subs	r4, r4, r1
d00085c2:	b2a4      	uxth	r4, r4
d00085c4:	2cff      	cmp	r4, #255	; 0xff
d00085c6:	d906      	bls.n	d00085d6 <pjpeg_decode_mcu+0x14ce>
d00085c8:	b225      	sxth	r5, r4
d00085ca:	2d00      	cmp	r5, #0
d00085cc:	f2c0 819d 	blt.w	d000890a <pjpeg_decode_mcu+0x1802>
d00085d0:	2dff      	cmp	r5, #255	; 0xff
d00085d2:	f300 81db 	bgt.w	d000898c <pjpeg_decode_mcu+0x1884>
d00085d6:	b2e5      	uxtb	r5, r4
d00085d8:	f890 4080 	ldrb.w	r4, [r0, #128]	; 0x80
d00085dc:	f880 5040 	strb.w	r5, [r0, #64]	; 0x40
d00085e0:	1a64      	subs	r4, r4, r1
d00085e2:	b2a4      	uxth	r4, r4
d00085e4:	2cff      	cmp	r4, #255	; 0xff
d00085e6:	d906      	bls.n	d00085f6 <pjpeg_decode_mcu+0x14ee>
d00085e8:	b225      	sxth	r5, r4
d00085ea:	2d00      	cmp	r5, #0
d00085ec:	f2c0 818f 	blt.w	d000890e <pjpeg_decode_mcu+0x1806>
d00085f0:	2dff      	cmp	r5, #255	; 0xff
d00085f2:	f300 81cd 	bgt.w	d0008990 <pjpeg_decode_mcu+0x1888>
d00085f6:	b2e5      	uxtb	r5, r4
d00085f8:	f890 40c0 	ldrb.w	r4, [r0, #192]	; 0xc0
d00085fc:	f880 5080 	strb.w	r5, [r0, #128]	; 0x80
d0008600:	1a61      	subs	r1, r4, r1
d0008602:	b289      	uxth	r1, r1
d0008604:	29ff      	cmp	r1, #255	; 0xff
d0008606:	d906      	bls.n	d0008616 <pjpeg_decode_mcu+0x150e>
d0008608:	b20c      	sxth	r4, r1
d000860a:	2c00      	cmp	r4, #0
d000860c:	f2c0 8181 	blt.w	d0008912 <pjpeg_decode_mcu+0x180a>
d0008610:	2cff      	cmp	r4, #255	; 0xff
d0008612:	f300 81b7 	bgt.w	d0008984 <pjpeg_decode_mcu+0x187c>
d0008616:	b2c9      	uxtb	r1, r1
d0008618:	eb02 0242 	add.w	r2, r2, r2, lsl #1
d000861c:	f1a3 04e3 	sub.w	r4, r3, #227	; 0xe3
d0008620:	f880 10c0 	strb.w	r1, [r0, #192]	; 0xc0
d0008624:	eb02 1242 	add.w	r2, r2, r2, lsl #5
d0008628:	499b      	ldr	r1, [pc, #620]	; (d0008898 <pjpeg_decode_mcu+0x1790>)
d000862a:	f3c2 13d7 	ubfx	r3, r2, #7, #24
d000862e:	780a      	ldrb	r2, [r1, #0]
d0008630:	4423      	add	r3, r4
d0008632:	b29b      	uxth	r3, r3
d0008634:	441a      	add	r2, r3
d0008636:	b292      	uxth	r2, r2
d0008638:	2aff      	cmp	r2, #255	; 0xff
d000863a:	d906      	bls.n	d000864a <pjpeg_decode_mcu+0x1542>
d000863c:	b210      	sxth	r0, r2
d000863e:	2800      	cmp	r0, #0
d0008640:	f2c0 8169 	blt.w	d0008916 <pjpeg_decode_mcu+0x180e>
d0008644:	28ff      	cmp	r0, #255	; 0xff
d0008646:	f300 819f 	bgt.w	d0008988 <pjpeg_decode_mcu+0x1880>
d000864a:	b2d0      	uxtb	r0, r2
d000864c:	f891 2040 	ldrb.w	r2, [r1, #64]	; 0x40
d0008650:	7008      	strb	r0, [r1, #0]
d0008652:	441a      	add	r2, r3
d0008654:	b292      	uxth	r2, r2
d0008656:	2aff      	cmp	r2, #255	; 0xff
d0008658:	d906      	bls.n	d0008668 <pjpeg_decode_mcu+0x1560>
d000865a:	b210      	sxth	r0, r2
d000865c:	2800      	cmp	r0, #0
d000865e:	f2c0 815c 	blt.w	d000891a <pjpeg_decode_mcu+0x1812>
d0008662:	28ff      	cmp	r0, #255	; 0xff
d0008664:	f300 81b2 	bgt.w	d00089cc <pjpeg_decode_mcu+0x18c4>
d0008668:	b2d0      	uxtb	r0, r2
d000866a:	f891 2080 	ldrb.w	r2, [r1, #128]	; 0x80
d000866e:	f881 0040 	strb.w	r0, [r1, #64]	; 0x40
d0008672:	441a      	add	r2, r3
d0008674:	b292      	uxth	r2, r2
d0008676:	2aff      	cmp	r2, #255	; 0xff
d0008678:	d906      	bls.n	d0008688 <pjpeg_decode_mcu+0x1580>
d000867a:	b210      	sxth	r0, r2
d000867c:	2800      	cmp	r0, #0
d000867e:	f2c0 814e 	blt.w	d000891e <pjpeg_decode_mcu+0x1816>
d0008682:	28ff      	cmp	r0, #255	; 0xff
d0008684:	f300 81a4 	bgt.w	d00089d0 <pjpeg_decode_mcu+0x18c8>
d0008688:	b2d2      	uxtb	r2, r2
d000868a:	f891 00c0 	ldrb.w	r0, [r1, #192]	; 0xc0
d000868e:	f881 2080 	strb.w	r2, [r1, #128]	; 0x80
d0008692:	4403      	add	r3, r0
d0008694:	b29b      	uxth	r3, r3
d0008696:	2bff      	cmp	r3, #255	; 0xff
d0008698:	d906      	bls.n	d00086a8 <pjpeg_decode_mcu+0x15a0>
d000869a:	b21a      	sxth	r2, r3
d000869c:	2a00      	cmp	r2, #0
d000869e:	f2c0 8140 	blt.w	d0008922 <pjpeg_decode_mcu+0x181a>
d00086a2:	2aff      	cmp	r2, #255	; 0xff
d00086a4:	f300 818d 	bgt.w	d00089c2 <pjpeg_decode_mcu+0x18ba>
d00086a8:	b2db      	uxtb	r3, r3
d00086aa:	f881 30c0 	strb.w	r3, [r1, #192]	; 0xc0
d00086ae:	f7fe bfa6 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00086b2:	497a      	ldr	r1, [pc, #488]	; (d000889c <pjpeg_decode_mcu+0x1794>)
d00086b4:	487a      	ldr	r0, [pc, #488]	; (d00088a0 <pjpeg_decode_mcu+0x1798>)
d00086b6:	f101 0540 	add.w	r5, r1, #64	; 0x40
d00086ba:	4c7a      	ldr	r4, [pc, #488]	; (d00088a4 <pjpeg_decode_mcu+0x179c>)
d00086bc:	e01d      	b.n	d00086fa <pjpeg_decode_mcu+0x15f2>
d00086be:	2eff      	cmp	r6, #255	; 0xff
d00086c0:	dc38      	bgt.n	d0008734 <pjpeg_decode_mcu+0x162c>
d00086c2:	b2d2      	uxtb	r2, r2
d00086c4:	ebc3 1603 	rsb	r6, r3, r3, lsl #4
d00086c8:	f801 2c01 	strb.w	r2, [r1, #-1]
d00086cc:	7842      	ldrb	r2, [r0, #1]
d00086ce:	eb03 0386 	add.w	r3, r3, r6, lsl #2
d00086d2:	ebc3 0383 	rsb	r3, r3, r3, lsl #2
d00086d6:	0a1b      	lsrs	r3, r3, #8
d00086d8:	f1c3 035b 	rsb	r3, r3, #91	; 0x5b
d00086dc:	4413      	add	r3, r2
d00086de:	b29b      	uxth	r3, r3
d00086e0:	2bff      	cmp	r3, #255	; 0xff
d00086e2:	d904      	bls.n	d00086ee <pjpeg_decode_mcu+0x15e6>
d00086e4:	b21a      	sxth	r2, r3
d00086e6:	2a00      	cmp	r2, #0
d00086e8:	db20      	blt.n	d000872c <pjpeg_decode_mcu+0x1624>
d00086ea:	2aff      	cmp	r2, #255	; 0xff
d00086ec:	dc20      	bgt.n	d0008730 <pjpeg_decode_mcu+0x1628>
d00086ee:	b2db      	uxtb	r3, r3
d00086f0:	42a9      	cmp	r1, r5
d00086f2:	f800 3f01 	strb.w	r3, [r0, #1]!
d00086f6:	f43e af82 	beq.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00086fa:	f934 3b02 	ldrsh.w	r3, [r4], #2
d00086fe:	f811 7b01 	ldrb.w	r7, [r1], #1
d0008702:	b2db      	uxtb	r3, r3
d0008704:	eb03 0643 	add.w	r6, r3, r3, lsl #1
d0008708:	f1a3 02b3 	sub.w	r2, r3, #179	; 0xb3
d000870c:	eb06 1606 	add.w	r6, r6, r6, lsl #4
d0008710:	eb03 0646 	add.w	r6, r3, r6, lsl #1
d0008714:	b21b      	sxth	r3, r3
d0008716:	eb02 2216 	add.w	r2, r2, r6, lsr #8
d000871a:	443a      	add	r2, r7
d000871c:	b292      	uxth	r2, r2
d000871e:	2aff      	cmp	r2, #255	; 0xff
d0008720:	d9cf      	bls.n	d00086c2 <pjpeg_decode_mcu+0x15ba>
d0008722:	b216      	sxth	r6, r2
d0008724:	2e00      	cmp	r6, #0
d0008726:	daca      	bge.n	d00086be <pjpeg_decode_mcu+0x15b6>
d0008728:	2200      	movs	r2, #0
d000872a:	e7cb      	b.n	d00086c4 <pjpeg_decode_mcu+0x15bc>
d000872c:	2300      	movs	r3, #0
d000872e:	e7df      	b.n	d00086f0 <pjpeg_decode_mcu+0x15e8>
d0008730:	23ff      	movs	r3, #255	; 0xff
d0008732:	e7dd      	b.n	d00086f0 <pjpeg_decode_mcu+0x15e8>
d0008734:	22ff      	movs	r2, #255	; 0xff
d0008736:	e7c5      	b.n	d00086c4 <pjpeg_decode_mcu+0x15bc>
d0008738:	4856      	ldr	r0, [pc, #344]	; (d0008894 <pjpeg_decode_mcu+0x178c>)
d000873a:	4c5b      	ldr	r4, [pc, #364]	; (d00088a8 <pjpeg_decode_mcu+0x17a0>)
d000873c:	f100 0640 	add.w	r6, r0, #64	; 0x40
d0008740:	4d58      	ldr	r5, [pc, #352]	; (d00088a4 <pjpeg_decode_mcu+0x179c>)
d0008742:	e01b      	b.n	d000877c <pjpeg_decode_mcu+0x1674>
d0008744:	2fff      	cmp	r7, #255	; 0xff
d0008746:	dc31      	bgt.n	d00087ac <pjpeg_decode_mcu+0x16a4>
d0008748:	b2db      	uxtb	r3, r3
d000874a:	eb02 0242 	add.w	r2, r2, r2, lsl #1
d000874e:	39e3      	subs	r1, #227	; 0xe3
d0008750:	f800 3c01 	strb.w	r3, [r0, #-1]
d0008754:	eb02 1242 	add.w	r2, r2, r2, lsl #5
d0008758:	7863      	ldrb	r3, [r4, #1]
d000875a:	eb01 12d2 	add.w	r2, r1, r2, lsr #7
d000875e:	441a      	add	r2, r3
d0008760:	b292      	uxth	r2, r2
d0008762:	2aff      	cmp	r2, #255	; 0xff
d0008764:	d904      	bls.n	d0008770 <pjpeg_decode_mcu+0x1668>
d0008766:	b213      	sxth	r3, r2
d0008768:	2b00      	cmp	r3, #0
d000876a:	db1d      	blt.n	d00087a8 <pjpeg_decode_mcu+0x16a0>
d000876c:	2bff      	cmp	r3, #255	; 0xff
d000876e:	dc1f      	bgt.n	d00087b0 <pjpeg_decode_mcu+0x16a8>
d0008770:	b2d2      	uxtb	r2, r2
d0008772:	42b0      	cmp	r0, r6
d0008774:	f804 2f01 	strb.w	r2, [r4, #1]!
d0008778:	f43e af41 	beq.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000877c:	f935 1b02 	ldrsh.w	r1, [r5], #2
d0008780:	f810 7b01 	ldrb.w	r7, [r0], #1
d0008784:	b2ca      	uxtb	r2, r1
d0008786:	eb02 0382 	add.w	r3, r2, r2, lsl #2
d000878a:	4611      	mov	r1, r2
d000878c:	eb02 0343 	add.w	r3, r2, r3, lsl #1
d0008790:	095b      	lsrs	r3, r3, #5
d0008792:	f1c3 032c 	rsb	r3, r3, #44	; 0x2c
d0008796:	443b      	add	r3, r7
d0008798:	b29b      	uxth	r3, r3
d000879a:	2bff      	cmp	r3, #255	; 0xff
d000879c:	d9d4      	bls.n	d0008748 <pjpeg_decode_mcu+0x1640>
d000879e:	b21f      	sxth	r7, r3
d00087a0:	2f00      	cmp	r7, #0
d00087a2:	dacf      	bge.n	d0008744 <pjpeg_decode_mcu+0x163c>
d00087a4:	2300      	movs	r3, #0
d00087a6:	e7d0      	b.n	d000874a <pjpeg_decode_mcu+0x1642>
d00087a8:	2200      	movs	r2, #0
d00087aa:	e7e2      	b.n	d0008772 <pjpeg_decode_mcu+0x166a>
d00087ac:	23ff      	movs	r3, #255	; 0xff
d00087ae:	e7cc      	b.n	d000874a <pjpeg_decode_mcu+0x1642>
d00087b0:	22ff      	movs	r2, #255	; 0xff
d00087b2:	e7de      	b.n	d0008772 <pjpeg_decode_mcu+0x166a>
d00087b4:	4939      	ldr	r1, [pc, #228]	; (d000889c <pjpeg_decode_mcu+0x1794>)
d00087b6:	eb03 0443 	add.w	r4, r3, r3, lsl #1
d00087ba:	b21a      	sxth	r2, r3
d00087bc:	7808      	ldrb	r0, [r1, #0]
d00087be:	eb04 1404 	add.w	r4, r4, r4, lsl #4
d00087c2:	38b3      	subs	r0, #179	; 0xb3
d00087c4:	eb03 0444 	add.w	r4, r3, r4, lsl #1
d00087c8:	4403      	add	r3, r0
d00087ca:	eb03 2314 	add.w	r3, r3, r4, lsr #8
d00087ce:	b29b      	uxth	r3, r3
d00087d0:	2bff      	cmp	r3, #255	; 0xff
d00087d2:	d905      	bls.n	d00087e0 <pjpeg_decode_mcu+0x16d8>
d00087d4:	b218      	sxth	r0, r3
d00087d6:	2800      	cmp	r0, #0
d00087d8:	db47      	blt.n	d000886a <pjpeg_decode_mcu+0x1762>
d00087da:	28ff      	cmp	r0, #255	; 0xff
d00087dc:	f300 8084 	bgt.w	d00088e8 <pjpeg_decode_mcu+0x17e0>
d00087e0:	b2db      	uxtb	r3, r3
d00087e2:	482c      	ldr	r0, [pc, #176]	; (d0008894 <pjpeg_decode_mcu+0x178c>)
d00087e4:	ebc2 1402 	rsb	r4, r2, r2, lsl #4
d00087e8:	700b      	strb	r3, [r1, #0]
d00087ea:	eb02 0284 	add.w	r2, r2, r4, lsl #2
d00087ee:	7803      	ldrb	r3, [r0, #0]
d00087f0:	ebc2 0282 	rsb	r2, r2, r2, lsl #2
d00087f4:	335b      	adds	r3, #91	; 0x5b
d00087f6:	eba3 2312 	sub.w	r3, r3, r2, lsr #8
d00087fa:	b29b      	uxth	r3, r3
d00087fc:	2bff      	cmp	r3, #255	; 0xff
d00087fe:	d904      	bls.n	d000880a <pjpeg_decode_mcu+0x1702>
d0008800:	b21a      	sxth	r2, r3
d0008802:	2a00      	cmp	r2, #0
d0008804:	db33      	blt.n	d000886e <pjpeg_decode_mcu+0x1766>
d0008806:	2aff      	cmp	r2, #255	; 0xff
d0008808:	dc70      	bgt.n	d00088ec <pjpeg_decode_mcu+0x17e4>
d000880a:	b2db      	uxtb	r3, r3
d000880c:	7003      	strb	r3, [r0, #0]
d000880e:	f7fe bef6 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008812:	4820      	ldr	r0, [pc, #128]	; (d0008894 <pjpeg_decode_mcu+0x178c>)
d0008814:	eb03 0483 	add.w	r4, r3, r3, lsl #2
d0008818:	b21a      	sxth	r2, r3
d000881a:	7801      	ldrb	r1, [r0, #0]
d000881c:	eb03 0444 	add.w	r4, r3, r4, lsl #1
d0008820:	312c      	adds	r1, #44	; 0x2c
d0008822:	f3c4 1457 	ubfx	r4, r4, #5, #24
d0008826:	1b09      	subs	r1, r1, r4
d0008828:	b289      	uxth	r1, r1
d000882a:	29ff      	cmp	r1, #255	; 0xff
d000882c:	d904      	bls.n	d0008838 <pjpeg_decode_mcu+0x1730>
d000882e:	b20c      	sxth	r4, r1
d0008830:	2c00      	cmp	r4, #0
d0008832:	db20      	blt.n	d0008876 <pjpeg_decode_mcu+0x176e>
d0008834:	2cff      	cmp	r4, #255	; 0xff
d0008836:	dc51      	bgt.n	d00088dc <pjpeg_decode_mcu+0x17d4>
d0008838:	b2cc      	uxtb	r4, r1
d000883a:	4917      	ldr	r1, [pc, #92]	; (d0008898 <pjpeg_decode_mcu+0x1790>)
d000883c:	eb02 0242 	add.w	r2, r2, r2, lsl #1
d0008840:	7004      	strb	r4, [r0, #0]
d0008842:	7808      	ldrb	r0, [r1, #0]
d0008844:	eb02 1242 	add.w	r2, r2, r2, lsl #5
d0008848:	38e3      	subs	r0, #227	; 0xe3
d000884a:	f3c2 12d7 	ubfx	r2, r2, #7, #24
d000884e:	4403      	add	r3, r0
d0008850:	4413      	add	r3, r2
d0008852:	b29b      	uxth	r3, r3
d0008854:	2bff      	cmp	r3, #255	; 0xff
d0008856:	d904      	bls.n	d0008862 <pjpeg_decode_mcu+0x175a>
d0008858:	b21a      	sxth	r2, r3
d000885a:	2a00      	cmp	r2, #0
d000885c:	db0d      	blt.n	d000887a <pjpeg_decode_mcu+0x1772>
d000885e:	2aff      	cmp	r2, #255	; 0xff
d0008860:	dc3e      	bgt.n	d00088e0 <pjpeg_decode_mcu+0x17d8>
d0008862:	b2db      	uxtb	r3, r3
d0008864:	700b      	strb	r3, [r1, #0]
d0008866:	f7fe beca 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d000886a:	2300      	movs	r3, #0
d000886c:	e7b9      	b.n	d00087e2 <pjpeg_decode_mcu+0x16da>
d000886e:	2300      	movs	r3, #0
d0008870:	7003      	strb	r3, [r0, #0]
d0008872:	f7fe bec4 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008876:	2400      	movs	r4, #0
d0008878:	e7df      	b.n	d000883a <pjpeg_decode_mcu+0x1732>
d000887a:	2300      	movs	r3, #0
d000887c:	700b      	strb	r3, [r1, #0]
d000887e:	f7fe bebe 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d0008882:	2100      	movs	r1, #0
d0008884:	e5e8      	b.n	d0008458 <pjpeg_decode_mcu+0x1350>
d0008886:	2300      	movs	r3, #0
d0008888:	e5f5      	b.n	d0008476 <pjpeg_decode_mcu+0x136e>
d000888a:	2000      	movs	r0, #0
d000888c:	e4f7      	b.n	d000827e <pjpeg_decode_mcu+0x1176>
d000888e:	2500      	movs	r5, #0
d0008890:	e60c      	b.n	d00084ac <pjpeg_decode_mcu+0x13a4>
d0008892:	bf00      	nop
d0008894:	d000e4e4 	.word	0xd000e4e4
d0008898:	d000e3e4 	.word	0xd000e3e4
d000889c:	d000e5e4 	.word	0xd000e5e4
d00088a0:	d000e4e3 	.word	0xd000e4e3
d00088a4:	d000ded4 	.word	0xd000ded4
d00088a8:	d000e3e3 	.word	0xd000e3e3
d00088ac:	2100      	movs	r1, #0
d00088ae:	e60c      	b.n	d00084ca <pjpeg_decode_mcu+0x13c2>
d00088b0:	2200      	movs	r2, #0
d00088b2:	e623      	b.n	d00084fc <pjpeg_decode_mcu+0x13f4>
d00088b4:	2300      	movs	r3, #0
d00088b6:	e4f1      	b.n	d000829c <pjpeg_decode_mcu+0x1194>
d00088b8:	2100      	movs	r1, #0
d00088ba:	e508      	b.n	d00082ce <pjpeg_decode_mcu+0x11c6>
d00088bc:	2500      	movs	r5, #0
d00088be:	e54e      	b.n	d000835e <pjpeg_decode_mcu+0x1256>
d00088c0:	2100      	movs	r1, #0
d00088c2:	e55b      	b.n	d000837c <pjpeg_decode_mcu+0x1274>
d00088c4:	2200      	movs	r2, #0
d00088c6:	e572      	b.n	d00083ae <pjpeg_decode_mcu+0x12a6>
d00088c8:	2300      	movs	r3, #0
d00088ca:	e57f      	b.n	d00083cc <pjpeg_decode_mcu+0x12c4>
d00088cc:	2000      	movs	r0, #0
d00088ce:	e59b      	b.n	d0008408 <pjpeg_decode_mcu+0x1300>
d00088d0:	2300      	movs	r3, #0
d00088d2:	e5a8      	b.n	d0008426 <pjpeg_decode_mcu+0x131e>
d00088d4:	2300      	movs	r3, #0
d00088d6:	e620      	b.n	d000851a <pjpeg_decode_mcu+0x1412>
d00088d8:	2300      	movs	r3, #0
d00088da:	e507      	b.n	d00082ec <pjpeg_decode_mcu+0x11e4>
d00088dc:	24ff      	movs	r4, #255	; 0xff
d00088de:	e7ac      	b.n	d000883a <pjpeg_decode_mcu+0x1732>
d00088e0:	23ff      	movs	r3, #255	; 0xff
d00088e2:	700b      	strb	r3, [r1, #0]
d00088e4:	f7fe be8b 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00088e8:	23ff      	movs	r3, #255	; 0xff
d00088ea:	e77a      	b.n	d00087e2 <pjpeg_decode_mcu+0x16da>
d00088ec:	23ff      	movs	r3, #255	; 0xff
d00088ee:	7003      	strb	r3, [r0, #0]
d00088f0:	f7fe be85 	b.w	d00075fe <pjpeg_decode_mcu+0x4f6>
d00088f4:	2500      	movs	r5, #0
d00088f6:	e660      	b.n	d00085ba <pjpeg_decode_mcu+0x14b2>
d00088f8:	2300      	movs	r3, #0
d00088fa:	f7fe be7e 	b.w	d00075fa <pjpeg_decode_mcu+0x4f2>
d00088fe:	2100      	movs	r1, #0
d0008900:	f7fe be5b 	b.w	d00075ba <pjpeg_decode_mcu+0x4b2>
d0008904:	2100      	movs	r1, #0
d0008906:	f7fe be68 	b.w	d00075da <pjpeg_decode_mcu+0x4d2>
d000890a:	2500      	movs	r5, #0
d000890c:	e664      	b.n	d00085d8 <pjpeg_decode_mcu+0x14d0>
d000890e:	2500      	movs	r5, #0
d0008910:	e672      	b.n	d00085f8 <pjpeg_decode_mcu+0x14f0>
d0008912:	2100      	movs	r1, #0
d0008914:	e680      	b.n	d0008618 <pjpeg_decode_mcu+0x1510>
d0008916:	2000      	movs	r0, #0
d0008918:	e698      	b.n	d000864c <pjpeg_decode_mcu+0x1544>
d000891a:	2000      	movs	r0, #0
d000891c:	e6a5      	b.n	d000866a <pjpeg_decode_mcu+0x1562>
d000891e:	2200      	movs	r2, #0
d0008920:	e6b3      	b.n	d000868a <pjpeg_decode_mcu+0x1582>
d0008922:	2300      	movs	r3, #0
d0008924:	e6c1      	b.n	d00086aa <pjpeg_decode_mcu+0x15a2>
d0008926:	2400      	movs	r4, #0
d0008928:	f7fe bdf0 	b.w	d000750c <pjpeg_decode_mcu+0x404>
d000892c:	2400      	movs	r4, #0
d000892e:	f7fe bdfc 	b.w	d000752a <pjpeg_decode_mcu+0x422>
d0008932:	2000      	movs	r0, #0
d0008934:	f7fe be09 	b.w	d000754a <pjpeg_decode_mcu+0x442>
d0008938:	2300      	movs	r3, #0
d000893a:	f7fe be16 	b.w	d000756a <pjpeg_decode_mcu+0x462>
d000893e:	2100      	movs	r1, #0
d0008940:	f7fe be2c 	b.w	d000759c <pjpeg_decode_mcu+0x494>
d0008944:	20ff      	movs	r0, #255	; 0xff
d0008946:	e49a      	b.n	d000827e <pjpeg_decode_mcu+0x1176>
d0008948:	25ff      	movs	r5, #255	; 0xff
d000894a:	e5af      	b.n	d00084ac <pjpeg_decode_mcu+0x13a4>
d000894c:	21ff      	movs	r1, #255	; 0xff
d000894e:	e583      	b.n	d0008458 <pjpeg_decode_mcu+0x1350>
d0008950:	23ff      	movs	r3, #255	; 0xff
d0008952:	e590      	b.n	d0008476 <pjpeg_decode_mcu+0x136e>
d0008954:	23ff      	movs	r3, #255	; 0xff
d0008956:	e4a1      	b.n	d000829c <pjpeg_decode_mcu+0x1194>
d0008958:	21ff      	movs	r1, #255	; 0xff
d000895a:	e4b8      	b.n	d00082ce <pjpeg_decode_mcu+0x11c6>
d000895c:	21ff      	movs	r1, #255	; 0xff
d000895e:	e5b4      	b.n	d00084ca <pjpeg_decode_mcu+0x13c2>
d0008960:	22ff      	movs	r2, #255	; 0xff
d0008962:	e5cb      	b.n	d00084fc <pjpeg_decode_mcu+0x13f4>
d0008964:	22ff      	movs	r2, #255	; 0xff
d0008966:	e522      	b.n	d00083ae <pjpeg_decode_mcu+0x12a6>
d0008968:	23ff      	movs	r3, #255	; 0xff
d000896a:	e52f      	b.n	d00083cc <pjpeg_decode_mcu+0x12c4>
d000896c:	25ff      	movs	r5, #255	; 0xff
d000896e:	e4f6      	b.n	d000835e <pjpeg_decode_mcu+0x1256>
d0008970:	21ff      	movs	r1, #255	; 0xff
d0008972:	e503      	b.n	d000837c <pjpeg_decode_mcu+0x1274>
d0008974:	23ff      	movs	r3, #255	; 0xff
d0008976:	e5d0      	b.n	d000851a <pjpeg_decode_mcu+0x1412>
d0008978:	23ff      	movs	r3, #255	; 0xff
d000897a:	e4b7      	b.n	d00082ec <pjpeg_decode_mcu+0x11e4>
d000897c:	20ff      	movs	r0, #255	; 0xff
d000897e:	e543      	b.n	d0008408 <pjpeg_decode_mcu+0x1300>
d0008980:	23ff      	movs	r3, #255	; 0xff
d0008982:	e550      	b.n	d0008426 <pjpeg_decode_mcu+0x131e>
d0008984:	21ff      	movs	r1, #255	; 0xff
d0008986:	e647      	b.n	d0008618 <pjpeg_decode_mcu+0x1510>
d0008988:	20ff      	movs	r0, #255	; 0xff
d000898a:	e65f      	b.n	d000864c <pjpeg_decode_mcu+0x1544>
d000898c:	25ff      	movs	r5, #255	; 0xff
d000898e:	e623      	b.n	d00085d8 <pjpeg_decode_mcu+0x14d0>
d0008990:	25ff      	movs	r5, #255	; 0xff
d0008992:	e631      	b.n	d00085f8 <pjpeg_decode_mcu+0x14f0>
d0008994:	21ff      	movs	r1, #255	; 0xff
d0008996:	f7fe be10 	b.w	d00075ba <pjpeg_decode_mcu+0x4b2>
d000899a:	21ff      	movs	r1, #255	; 0xff
d000899c:	f7fe be1d 	b.w	d00075da <pjpeg_decode_mcu+0x4d2>
d00089a0:	25ff      	movs	r5, #255	; 0xff
d00089a2:	e60a      	b.n	d00085ba <pjpeg_decode_mcu+0x14b2>
d00089a4:	23ff      	movs	r3, #255	; 0xff
d00089a6:	f7fe be28 	b.w	d00075fa <pjpeg_decode_mcu+0x4f2>
d00089aa:	23ff      	movs	r3, #255	; 0xff
d00089ac:	f7fe bddd 	b.w	d000756a <pjpeg_decode_mcu+0x462>
d00089b0:	21ff      	movs	r1, #255	; 0xff
d00089b2:	f7fe bdf3 	b.w	d000759c <pjpeg_decode_mcu+0x494>
d00089b6:	24ff      	movs	r4, #255	; 0xff
d00089b8:	f7fe bdb7 	b.w	d000752a <pjpeg_decode_mcu+0x422>
d00089bc:	20ff      	movs	r0, #255	; 0xff
d00089be:	f7fe bdc4 	b.w	d000754a <pjpeg_decode_mcu+0x442>
d00089c2:	23ff      	movs	r3, #255	; 0xff
d00089c4:	e671      	b.n	d00086aa <pjpeg_decode_mcu+0x15a2>
d00089c6:	24ff      	movs	r4, #255	; 0xff
d00089c8:	f7fe bda0 	b.w	d000750c <pjpeg_decode_mcu+0x404>
d00089cc:	20ff      	movs	r0, #255	; 0xff
d00089ce:	e64c      	b.n	d000866a <pjpeg_decode_mcu+0x1562>
d00089d0:	22ff      	movs	r2, #255	; 0xff
d00089d2:	e65a      	b.n	d000868a <pjpeg_decode_mcu+0x1582>

d00089d4 <pjpeg_decode_init>:
d00089d4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00089d8:	4e9c      	ldr	r6, [pc, #624]	; (d0008c4c <pjpeg_decode_init+0x278>)
d00089da:	2400      	movs	r4, #0
d00089dc:	f8df b2a0 	ldr.w	fp, [pc, #672]	; d0008c80 <pjpeg_decode_init+0x2ac>
d00089e0:	4605      	mov	r5, r0
d00089e2:	7033      	strb	r3, [r6, #0]
d00089e4:	f04f 0c08 	mov.w	ip, #8
d00089e8:	4b99      	ldr	r3, [pc, #612]	; (d0008c50 <pjpeg_decode_init+0x27c>)
d00089ea:	b087      	sub	sp, #28
d00089ec:	f8cb 2000 	str.w	r2, [fp]
d00089f0:	4620      	mov	r0, r4
d00089f2:	801c      	strh	r4, [r3, #0]
d00089f4:	4b97      	ldr	r3, [pc, #604]	; (d0008c54 <pjpeg_decode_init+0x280>)
d00089f6:	f8df e28c 	ldr.w	lr, [pc, #652]	; d0008c84 <pjpeg_decode_init+0x2b0>
d00089fa:	801c      	strh	r4, [r3, #0]
d00089fc:	4b96      	ldr	r3, [pc, #600]	; (d0008c58 <pjpeg_decode_init+0x284>)
d00089fe:	4f97      	ldr	r7, [pc, #604]	; (d0008c5c <pjpeg_decode_init+0x288>)
d0008a00:	801c      	strh	r4, [r3, #0]
d0008a02:	4b97      	ldr	r3, [pc, #604]	; (d0008c60 <pjpeg_decode_init+0x28c>)
d0008a04:	f8df 9280 	ldr.w	r9, [pc, #640]	; d0008c88 <pjpeg_decode_init+0x2b4>
d0008a08:	701c      	strb	r4, [r3, #0]
d0008a0a:	4b96      	ldr	r3, [pc, #600]	; (d0008c64 <pjpeg_decode_init+0x290>)
d0008a0c:	f8df a27c 	ldr.w	sl, [pc, #636]	; d0008c8c <pjpeg_decode_init+0x2b8>
d0008a10:	701c      	strb	r4, [r3, #0]
d0008a12:	4b95      	ldr	r3, [pc, #596]	; (d0008c68 <pjpeg_decode_init+0x294>)
d0008a14:	f8df 8278 	ldr.w	r8, [pc, #632]	; d0008c90 <pjpeg_decode_init+0x2bc>
d0008a18:	701c      	strb	r4, [r3, #0]
d0008a1a:	f8df b278 	ldr.w	fp, [pc, #632]	; d0008c94 <pjpeg_decode_init+0x2c0>
d0008a1e:	4b93      	ldr	r3, [pc, #588]	; (d0008c6c <pjpeg_decode_init+0x298>)
d0008a20:	4e93      	ldr	r6, [pc, #588]	; (d0008c70 <pjpeg_decode_init+0x29c>)
d0008a22:	602c      	str	r4, [r5, #0]
d0008a24:	606c      	str	r4, [r5, #4]
d0008a26:	60ac      	str	r4, [r5, #8]
d0008a28:	60ec      	str	r4, [r5, #12]
d0008a2a:	612c      	str	r4, [r5, #16]
d0008a2c:	752c      	strb	r4, [r5, #20]
d0008a2e:	61ac      	str	r4, [r5, #24]
d0008a30:	61ec      	str	r4, [r5, #28]
d0008a32:	622c      	str	r4, [r5, #32]
d0008a34:	626c      	str	r4, [r5, #36]	; 0x24
d0008a36:	62ac      	str	r4, [r5, #40]	; 0x28
d0008a38:	f88e 4000 	strb.w	r4, [lr]
d0008a3c:	701c      	strb	r4, [r3, #0]
d0008a3e:	f8c9 1000 	str.w	r1, [r9]
d0008a42:	703c      	strb	r4, [r7, #0]
d0008a44:	f88a 4000 	strb.w	r4, [sl]
d0008a48:	f888 4000 	strb.w	r4, [r8]
d0008a4c:	f8ab 4000 	strh.w	r4, [fp]
d0008a50:	f886 c000 	strb.w	ip, [r6]
d0008a54:	f7fd fdaa 	bl	d00065ac <getBits.constprop.1>
d0008a58:	4620      	mov	r0, r4
d0008a5a:	f7fd fda7 	bl	d00065ac <getBits.constprop.1>
d0008a5e:	783c      	ldrb	r4, [r7, #0]
d0008a60:	b11c      	cbz	r4, d0008a6a <pjpeg_decode_init+0x96>
d0008a62:	4620      	mov	r0, r4
d0008a64:	b007      	add	sp, #28
d0008a66:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0008a6a:	4620      	mov	r0, r4
d0008a6c:	f7fd fd9e 	bl	d00065ac <getBits.constprop.1>
d0008a70:	4603      	mov	r3, r0
d0008a72:	4620      	mov	r0, r4
d0008a74:	461c      	mov	r4, r3
d0008a76:	f7fd fd99 	bl	d00065ac <getBits.constprop.1>
d0008a7a:	fa5f f980 	uxtb.w	r9, r0
d0008a7e:	b2e4      	uxtb	r4, r4
d0008a80:	2cff      	cmp	r4, #255	; 0xff
d0008a82:	d112      	bne.n	d0008aaa <pjpeg_decode_init+0xd6>
d0008a84:	f1b9 0fd8 	cmp.w	r9, #216	; 0xd8
d0008a88:	d10f      	bne.n	d0008aaa <pjpeg_decode_init+0xd6>
d0008a8a:	f10d 0017 	add.w	r0, sp, #23
d0008a8e:	f7fd fe0f 	bl	d00066b0 <processMarkers>
d0008a92:	4604      	mov	r4, r0
d0008a94:	bb58      	cbnz	r0, d0008aee <pjpeg_decode_init+0x11a>
d0008a96:	f89d 3017 	ldrb.w	r3, [sp, #23]
d0008a9a:	2bc2      	cmp	r3, #194	; 0xc2
d0008a9c:	d04e      	beq.n	d0008b3c <pjpeg_decode_init+0x168>
d0008a9e:	2bc9      	cmp	r3, #201	; 0xc9
d0008aa0:	d059      	beq.n	d0008b56 <pjpeg_decode_init+0x182>
d0008aa2:	2bc0      	cmp	r3, #192	; 0xc0
d0008aa4:	d04c      	beq.n	d0008b40 <pjpeg_decode_init+0x16c>
d0008aa6:	2414      	movs	r4, #20
d0008aa8:	e021      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008aaa:	f640 72ff 	movw	r2, #4095	; 0xfff
d0008aae:	9500      	str	r5, [sp, #0]
d0008ab0:	f8bb 3000 	ldrh.w	r3, [fp]
d0008ab4:	464d      	mov	r5, r9
d0008ab6:	4691      	mov	r9, r2
d0008ab8:	7831      	ldrb	r1, [r6, #0]
d0008aba:	ea4f 2c03 	mov.w	ip, r3, lsl #8
d0008abe:	461c      	mov	r4, r3
d0008ac0:	2907      	cmp	r1, #7
d0008ac2:	f1a1 0008 	sub.w	r0, r1, #8
d0008ac6:	d922      	bls.n	d0008b0e <pjpeg_decode_init+0x13a>
d0008ac8:	fa1f f38c 	uxth.w	r3, ip
d0008acc:	7030      	strb	r0, [r6, #0]
d0008ace:	f8ab 3000 	strh.w	r3, [fp]
d0008ad2:	f109 39ff 	add.w	r9, r9, #4294967295	; 0xffffffff
d0008ad6:	1221      	asrs	r1, r4, #8
d0008ad8:	2dff      	cmp	r5, #255	; 0xff
d0008ada:	f3c4 2407 	ubfx	r4, r4, #8, #8
d0008ade:	fa1f f989 	uxth.w	r9, r9
d0008ae2:	4625      	mov	r5, r4
d0008ae4:	d00b      	beq.n	d0008afe <pjpeg_decode_init+0x12a>
d0008ae6:	f1b9 0f00 	cmp.w	r9, #0
d0008aea:	d1e5      	bne.n	d0008ab8 <pjpeg_decode_init+0xe4>
d0008aec:	2413      	movs	r4, #19
d0008aee:	783b      	ldrb	r3, [r7, #0]
d0008af0:	2b00      	cmp	r3, #0
d0008af2:	bf18      	it	ne
d0008af4:	461c      	movne	r4, r3
d0008af6:	4620      	mov	r0, r4
d0008af8:	b007      	add	sp, #28
d0008afa:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0008afe:	29d8      	cmp	r1, #216	; 0xd8
d0008b00:	d017      	beq.n	d0008b32 <pjpeg_decode_init+0x15e>
d0008b02:	29d9      	cmp	r1, #217	; 0xd9
d0008b04:	d0f2      	beq.n	d0008aec <pjpeg_decode_init+0x118>
d0008b06:	f1b9 0f00 	cmp.w	r9, #0
d0008b0a:	d1d5      	bne.n	d0008ab8 <pjpeg_decode_init+0xe4>
d0008b0c:	e7ee      	b.n	d0008aec <pjpeg_decode_init+0x118>
d0008b0e:	fa03 f101 	lsl.w	r1, r3, r1
d0008b12:	f8ab 1000 	strh.w	r1, [fp]
d0008b16:	f7fd fd0f 	bl	d0006538 <getChar>
d0008b1a:	f8bb 1000 	ldrh.w	r1, [fp]
d0008b1e:	7833      	ldrb	r3, [r6, #0]
d0008b20:	4308      	orrs	r0, r1
d0008b22:	f1c3 0108 	rsb	r1, r3, #8
d0008b26:	b283      	uxth	r3, r0
d0008b28:	408b      	lsls	r3, r1
d0008b2a:	b29b      	uxth	r3, r3
d0008b2c:	f8ab 3000 	strh.w	r3, [fp]
d0008b30:	e7cf      	b.n	d0008ad2 <pjpeg_decode_init+0xfe>
d0008b32:	0a1b      	lsrs	r3, r3, #8
d0008b34:	9d00      	ldr	r5, [sp, #0]
d0008b36:	2bff      	cmp	r3, #255	; 0xff
d0008b38:	d0a7      	beq.n	d0008a8a <pjpeg_decode_init+0xb6>
d0008b3a:	e7d7      	b.n	d0008aec <pjpeg_decode_init+0x118>
d0008b3c:	2425      	movs	r4, #37	; 0x25
d0008b3e:	e7d6      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008b40:	f7fd fd82 	bl	d0006648 <getBits.constprop.0>
d0008b44:	4603      	mov	r3, r0
d0008b46:	4620      	mov	r0, r4
d0008b48:	4699      	mov	r9, r3
d0008b4a:	f7fd fd2f 	bl	d00065ac <getBits.constprop.1>
d0008b4e:	2808      	cmp	r0, #8
d0008b50:	d003      	beq.n	d0008b5a <pjpeg_decode_init+0x186>
d0008b52:	2407      	movs	r4, #7
d0008b54:	e7cb      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008b56:	2411      	movs	r4, #17
d0008b58:	e7c9      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008b5a:	9000      	str	r0, [sp, #0]
d0008b5c:	f7fd fd74 	bl	d0006648 <getBits.constprop.0>
d0008b60:	1e42      	subs	r2, r0, #1
d0008b62:	4b3c      	ldr	r3, [pc, #240]	; (d0008c54 <pjpeg_decode_init+0x280>)
d0008b64:	f5b2 4f80 	cmp.w	r2, #16384	; 0x4000
d0008b68:	8018      	strh	r0, [r3, #0]
d0008b6a:	9b00      	ldr	r3, [sp, #0]
d0008b6c:	f080 8118 	bcs.w	d0008da0 <pjpeg_decode_init+0x3cc>
d0008b70:	f7fd fd6a 	bl	d0006648 <getBits.constprop.0>
d0008b74:	1e42      	subs	r2, r0, #1
d0008b76:	4b36      	ldr	r3, [pc, #216]	; (d0008c50 <pjpeg_decode_init+0x27c>)
d0008b78:	f5b2 4f80 	cmp.w	r2, #16384	; 0x4000
d0008b7c:	8018      	strh	r0, [r3, #0]
d0008b7e:	9b00      	ldr	r3, [sp, #0]
d0008b80:	f080 8110 	bcs.w	d0008da4 <pjpeg_decode_init+0x3d0>
d0008b84:	4620      	mov	r0, r4
d0008b86:	9300      	str	r3, [sp, #0]
d0008b88:	f7fd fd10 	bl	d00065ac <getBits.constprop.1>
d0008b8c:	9b00      	ldr	r3, [sp, #0]
d0008b8e:	b2c0      	uxtb	r0, r0
d0008b90:	2803      	cmp	r0, #3
d0008b92:	f88a 0000 	strb.w	r0, [sl]
d0008b96:	f200 826c 	bhi.w	d0009072 <pjpeg_decode_init+0x69e>
d0008b9a:	2103      	movs	r1, #3
d0008b9c:	fb11 3300 	smlabb	r3, r1, r0, r3
d0008ba0:	4599      	cmp	r9, r3
d0008ba2:	f040 825e 	bne.w	d0009062 <pjpeg_decode_init+0x68e>
d0008ba6:	2800      	cmp	r0, #0
d0008ba8:	f000 829b 	beq.w	d00090e2 <pjpeg_decode_init+0x70e>
d0008bac:	2200      	movs	r2, #0
d0008bae:	9500      	str	r5, [sp, #0]
d0008bb0:	f8df 90e4 	ldr.w	r9, [pc, #228]	; d0008c98 <pjpeg_decode_init+0x2c4>
d0008bb4:	4614      	mov	r4, r2
d0008bb6:	4615      	mov	r5, r2
d0008bb8:	e004      	b.n	d0008bc4 <pjpeg_decode_init+0x1f0>
d0008bba:	f89a 1000 	ldrb.w	r1, [sl]
d0008bbe:	4b2d      	ldr	r3, [pc, #180]	; (d0008c74 <pjpeg_decode_init+0x2a0>)
d0008bc0:	42a1      	cmp	r1, r4
d0008bc2:	d921      	bls.n	d0008c08 <pjpeg_decode_init+0x234>
d0008bc4:	2000      	movs	r0, #0
d0008bc6:	3501      	adds	r5, #1
d0008bc8:	f7fd fcf0 	bl	d00065ac <getBits.constprop.1>
d0008bcc:	4b2a      	ldr	r3, [pc, #168]	; (d0008c78 <pjpeg_decode_init+0x2a4>)
d0008bce:	4684      	mov	ip, r0
d0008bd0:	2100      	movs	r1, #0
d0008bd2:	2004      	movs	r0, #4
d0008bd4:	f803 c004 	strb.w	ip, [r3, r4]
d0008bd8:	f7fe f9f4 	bl	d0006fc4 <getBits>
d0008bdc:	4b25      	ldr	r3, [pc, #148]	; (d0008c74 <pjpeg_decode_init+0x2a0>)
d0008bde:	4684      	mov	ip, r0
d0008be0:	2100      	movs	r1, #0
d0008be2:	2004      	movs	r0, #4
d0008be4:	f803 c004 	strb.w	ip, [r3, r4]
d0008be8:	f7fe f9ec 	bl	d0006fc4 <getBits>
d0008bec:	4601      	mov	r1, r0
d0008bee:	2000      	movs	r0, #0
d0008bf0:	f809 1004 	strb.w	r1, [r9, r4]
d0008bf4:	f7fd fcda 	bl	d00065ac <getBits.constprop.1>
d0008bf8:	b2c0      	uxtb	r0, r0
d0008bfa:	4b20      	ldr	r3, [pc, #128]	; (d0008c7c <pjpeg_decode_init+0x2a8>)
d0008bfc:	2801      	cmp	r0, #1
d0008bfe:	5518      	strb	r0, [r3, r4]
d0008c00:	b2ec      	uxtb	r4, r5
d0008c02:	d9da      	bls.n	d0008bba <pjpeg_decode_init+0x1e6>
d0008c04:	2424      	movs	r4, #36	; 0x24
d0008c06:	e772      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008c08:	783c      	ldrb	r4, [r7, #0]
d0008c0a:	9d00      	ldr	r5, [sp, #0]
d0008c0c:	2c00      	cmp	r4, #0
d0008c0e:	f47f af28 	bne.w	d0008a62 <pjpeg_decode_init+0x8e>
d0008c12:	2901      	cmp	r1, #1
d0008c14:	d042      	beq.n	d0008c9c <pjpeg_decode_init+0x2c8>
d0008c16:	2903      	cmp	r1, #3
d0008c18:	f040 80bc 	bne.w	d0008d94 <pjpeg_decode_init+0x3c0>
d0008c1c:	7859      	ldrb	r1, [r3, #1]
d0008c1e:	2901      	cmp	r1, #1
d0008c20:	d111      	bne.n	d0008c46 <pjpeg_decode_init+0x272>
d0008c22:	f899 1001 	ldrb.w	r1, [r9, #1]
d0008c26:	2901      	cmp	r1, #1
d0008c28:	d10d      	bne.n	d0008c46 <pjpeg_decode_init+0x272>
d0008c2a:	7899      	ldrb	r1, [r3, #2]
d0008c2c:	2901      	cmp	r1, #1
d0008c2e:	d10a      	bne.n	d0008c46 <pjpeg_decode_init+0x272>
d0008c30:	f899 1002 	ldrb.w	r1, [r9, #2]
d0008c34:	2901      	cmp	r1, #1
d0008c36:	d106      	bne.n	d0008c46 <pjpeg_decode_init+0x272>
d0008c38:	781b      	ldrb	r3, [r3, #0]
d0008c3a:	2b01      	cmp	r3, #1
d0008c3c:	f000 80b4 	beq.w	d0008da8 <pjpeg_decode_init+0x3d4>
d0008c40:	2b02      	cmp	r3, #2
d0008c42:	f000 80d1 	beq.w	d0008de8 <pjpeg_decode_init+0x414>
d0008c46:	241b      	movs	r4, #27
d0008c48:	e70b      	b.n	d0008a62 <pjpeg_decode_init+0x8e>
d0008c4a:	bf00      	nop
d0008c4c:	d000e7f8 	.word	0xd000e7f8
d0008c50:	d000e2d4 	.word	0xd000e2d4
d0008c54:	d000e2d6 	.word	0xd000e2d6
d0008c58:	d000e7fa 	.word	0xd000e7fa
d0008c5c:	d000ded3 	.word	0xd000ded3
d0008c60:	d000e800 	.word	0xd000e800
d0008c64:	d000e801 	.word	0xd000e801
d0008c68:	d000e3d9 	.word	0xd000e3d9
d0008c6c:	d000e3d8 	.word	0xd000e3d8
d0008c70:	d000ded2 	.word	0xd000ded2
d0008c74:	d000df5c 	.word	0xd000df5c
d0008c78:	d000df60 	.word	0xd000df60
d0008c7c:	d000df68 	.word	0xd000df68
d0008c80:	d000e804 	.word	0xd000e804
d0008c84:	d000e7ff 	.word	0xd000e7ff
d0008c88:	d000e808 	.word	0xd000e808
d0008c8c:	d000df6f 	.word	0xd000df6f
d0008c90:	d000df70 	.word	0xd000df70
d0008c94:	d000ded0 	.word	0xd000ded0
d0008c98:	d000df6c 	.word	0xd000df6c
d0008c9c:	781b      	ldrb	r3, [r3, #0]
d0008c9e:	2b01      	cmp	r3, #1
d0008ca0:	d1d1      	bne.n	d0008c46 <pjpeg_decode_init+0x272>
d0008ca2:	f899 3000 	ldrb.w	r3, [r9]
d0008ca6:	2b01      	cmp	r3, #1
d0008ca8:	d1cd      	bne.n	d0008c46 <pjpeg_decode_init+0x272>
d0008caa:	4a63      	ldr	r2, [pc, #396]	; (d0008e38 <pjpeg_decode_init+0x464>)
d0008cac:	f04f 0c07 	mov.w	ip, #7
d0008cb0:	4862      	ldr	r0, [pc, #392]	; (d0008e3c <pjpeg_decode_init+0x468>)
d0008cb2:	4611      	mov	r1, r2
d0008cb4:	9202      	str	r2, [sp, #8]
d0008cb6:	2208      	movs	r2, #8
d0008cb8:	7003      	strb	r3, [r0, #0]
d0008cba:	700c      	strb	r4, [r1, #0]
d0008cbc:	4b60      	ldr	r3, [pc, #384]	; (d0008e40 <pjpeg_decode_init+0x46c>)
d0008cbe:	4610      	mov	r0, r2
d0008cc0:	4960      	ldr	r1, [pc, #384]	; (d0008e44 <pjpeg_decode_init+0x470>)
d0008cc2:	f8df e1a0 	ldr.w	lr, [pc, #416]	; d0008e64 <pjpeg_decode_init+0x490>
d0008cc6:	9300      	str	r3, [sp, #0]
d0008cc8:	f88e 4000 	strb.w	r4, [lr]
d0008ccc:	9101      	str	r1, [sp, #4]
d0008cce:	701a      	strb	r2, [r3, #0]
d0008cd0:	700a      	strb	r2, [r1, #0]
d0008cd2:	4b5d      	ldr	r3, [pc, #372]	; (d0008e48 <pjpeg_decode_init+0x474>)
d0008cd4:	2103      	movs	r1, #3
d0008cd6:	881b      	ldrh	r3, [r3, #0]
d0008cd8:	3307      	adds	r3, #7
d0008cda:	4a5c      	ldr	r2, [pc, #368]	; (d0008e4c <pjpeg_decode_init+0x478>)
d0008cdc:	2808      	cmp	r0, #8
d0008cde:	fa43 f301 	asr.w	r3, r3, r1
d0008ce2:	4c5b      	ldr	r4, [pc, #364]	; (d0008e50 <pjpeg_decode_init+0x47c>)
d0008ce4:	8812      	ldrh	r2, [r2, #0]
d0008ce6:	f10d 0017 	add.w	r0, sp, #23
d0008cea:	b29b      	uxth	r3, r3
d0008cec:	eb02 010c 	add.w	r1, r2, ip
d0008cf0:	bf0c      	ite	eq
d0008cf2:	2203      	moveq	r2, #3
d0008cf4:	2204      	movne	r2, #4
d0008cf6:	8023      	strh	r3, [r4, #0]
d0008cf8:	4c56      	ldr	r4, [pc, #344]	; (d0008e54 <pjpeg_decode_init+0x480>)
d0008cfa:	fa41 f202 	asr.w	r2, r1, r2
d0008cfe:	4956      	ldr	r1, [pc, #344]	; (d0008e58 <pjpeg_decode_init+0x484>)
d0008d00:	8023      	strh	r3, [r4, #0]
d0008d02:	b292      	uxth	r2, r2
d0008d04:	4b55      	ldr	r3, [pc, #340]	; (d0008e5c <pjpeg_decode_init+0x488>)
d0008d06:	800a      	strh	r2, [r1, #0]
d0008d08:	801a      	strh	r2, [r3, #0]
d0008d0a:	f7fd fcd1 	bl	d00066b0 <processMarkers>
d0008d0e:	4604      	mov	r4, r0
d0008d10:	2800      	cmp	r0, #0
d0008d12:	f47f aeec 	bne.w	d0008aee <pjpeg_decode_init+0x11a>
d0008d16:	f89d 3017 	ldrb.w	r3, [sp, #23]
d0008d1a:	2bda      	cmp	r3, #218	; 0xda
d0008d1c:	d13c      	bne.n	d0008d98 <pjpeg_decode_init+0x3c4>
d0008d1e:	f7fd fc93 	bl	d0006648 <getBits.constprop.0>
d0008d22:	4603      	mov	r3, r0
d0008d24:	4620      	mov	r0, r4
d0008d26:	9303      	str	r3, [sp, #12]
d0008d28:	f7fd fc40 	bl	d00065ac <getBits.constprop.1>
d0008d2c:	9b03      	ldr	r3, [sp, #12]
d0008d2e:	b2c2      	uxtb	r2, r0
d0008d30:	2103      	movs	r1, #3
d0008d32:	3b03      	subs	r3, #3
d0008d34:	f888 2000 	strb.w	r2, [r8]
d0008d38:	fa1f fc83 	uxth.w	ip, r3
d0008d3c:	eb01 0342 	add.w	r3, r1, r2, lsl #1
d0008d40:	459c      	cmp	ip, r3
d0008d42:	d12b      	bne.n	d0008d9c <pjpeg_decode_init+0x3c8>
d0008d44:	3a01      	subs	r2, #1
d0008d46:	2a02      	cmp	r2, #2
d0008d48:	d828      	bhi.n	d0008d9c <pjpeg_decode_init+0x3c8>
d0008d4a:	9503      	str	r5, [sp, #12]
d0008d4c:	4625      	mov	r5, r4
d0008d4e:	46e1      	mov	r9, ip
d0008d50:	2000      	movs	r0, #0
d0008d52:	f7fd fc2b 	bl	d00065ac <getBits.constprop.1>
d0008d56:	4604      	mov	r4, r0
d0008d58:	2000      	movs	r0, #0
d0008d5a:	f7fd fc27 	bl	d00065ac <getBits.constprop.1>
d0008d5e:	f1a9 0c02 	sub.w	ip, r9, #2
d0008d62:	f89a 1000 	ldrb.w	r1, [sl]
d0008d66:	b2e4      	uxtb	r4, r4
d0008d68:	b2c3      	uxtb	r3, r0
d0008d6a:	fa1f fc8c 	uxth.w	ip, ip
d0008d6e:	b179      	cbz	r1, d0008d90 <pjpeg_decode_init+0x3bc>
d0008d70:	4a3b      	ldr	r2, [pc, #236]	; (d0008e60 <pjpeg_decode_init+0x48c>)
d0008d72:	7810      	ldrb	r0, [r2, #0]
d0008d74:	42a0      	cmp	r0, r4
d0008d76:	d079      	beq.n	d0008e6c <pjpeg_decode_init+0x498>
d0008d78:	2901      	cmp	r1, #1
d0008d7a:	d909      	bls.n	d0008d90 <pjpeg_decode_init+0x3bc>
d0008d7c:	7850      	ldrb	r0, [r2, #1]
d0008d7e:	42a0      	cmp	r0, r4
d0008d80:	f000 8171 	beq.w	d0009066 <pjpeg_decode_init+0x692>
d0008d84:	2902      	cmp	r1, #2
d0008d86:	d003      	beq.n	d0008d90 <pjpeg_decode_init+0x3bc>
d0008d88:	7891      	ldrb	r1, [r2, #2]
d0008d8a:	42a1      	cmp	r1, r4
d0008d8c:	f000 816e 	beq.w	d000906c <pjpeg_decode_init+0x698>
d0008d90:	240f      	movs	r4, #15
d0008d92:	e6ac      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008d94:	241a      	movs	r4, #26
d0008d96:	e664      	b.n	d0008a62 <pjpeg_decode_init+0x8e>
d0008d98:	2412      	movs	r4, #18
d0008d9a:	e6a8      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008d9c:	240e      	movs	r4, #14
d0008d9e:	e6a6      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008da0:	461c      	mov	r4, r3
d0008da2:	e6a4      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008da4:	2409      	movs	r4, #9
d0008da6:	e6a2      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0008da8:	f899 3000 	ldrb.w	r3, [r9]
d0008dac:	2b01      	cmp	r3, #1
d0008dae:	f000 8162 	beq.w	d0009076 <pjpeg_decode_init+0x6a2>
d0008db2:	2b02      	cmp	r3, #2
d0008db4:	f47f af47 	bne.w	d0008c46 <pjpeg_decode_init+0x272>
d0008db8:	4a20      	ldr	r2, [pc, #128]	; (d0008e3c <pjpeg_decode_init+0x468>)
d0008dba:	2004      	movs	r0, #4
d0008dbc:	4b1e      	ldr	r3, [pc, #120]	; (d0008e38 <pjpeg_decode_init+0x464>)
d0008dbe:	f04f 0c03 	mov.w	ip, #3
d0008dc2:	7010      	strb	r0, [r2, #0]
d0008dc4:	2408      	movs	r4, #8
d0008dc6:	4927      	ldr	r1, [pc, #156]	; (d0008e64 <pjpeg_decode_init+0x490>)
d0008dc8:	4a27      	ldr	r2, [pc, #156]	; (d0008e68 <pjpeg_decode_init+0x494>)
d0008dca:	f883 c000 	strb.w	ip, [r3]
d0008dce:	f04f 0c0f 	mov.w	ip, #15
d0008dd2:	600a      	str	r2, [r1, #0]
d0008dd4:	9302      	str	r3, [sp, #8]
d0008dd6:	2310      	movs	r3, #16
d0008dd8:	4a19      	ldr	r2, [pc, #100]	; (d0008e40 <pjpeg_decode_init+0x46c>)
d0008dda:	491a      	ldr	r1, [pc, #104]	; (d0008e44 <pjpeg_decode_init+0x470>)
d0008ddc:	4618      	mov	r0, r3
d0008dde:	9200      	str	r2, [sp, #0]
d0008de0:	9101      	str	r1, [sp, #4]
d0008de2:	7014      	strb	r4, [r2, #0]
d0008de4:	700b      	strb	r3, [r1, #0]
d0008de6:	e774      	b.n	d0008cd2 <pjpeg_decode_init+0x2fe>
d0008de8:	f899 2000 	ldrb.w	r2, [r9]
d0008dec:	2a01      	cmp	r2, #1
d0008dee:	f000 815f 	beq.w	d00090b0 <pjpeg_decode_init+0x6dc>
d0008df2:	2a02      	cmp	r2, #2
d0008df4:	f47f af27 	bne.w	d0008c46 <pjpeg_decode_init+0x272>
d0008df8:	4b0f      	ldr	r3, [pc, #60]	; (d0008e38 <pjpeg_decode_init+0x464>)
d0008dfa:	2004      	movs	r0, #4
d0008dfc:	4a19      	ldr	r2, [pc, #100]	; (d0008e64 <pjpeg_decode_init+0x490>)
d0008dfe:	2106      	movs	r1, #6
d0008e00:	f240 2c01 	movw	ip, #513	; 0x201
d0008e04:	7018      	strb	r0, [r3, #0]
d0008e06:	f8df e034 	ldr.w	lr, [pc, #52]	; d0008e3c <pjpeg_decode_init+0x468>
d0008e0a:	2400      	movs	r4, #0
d0008e0c:	9302      	str	r3, [sp, #8]
d0008e0e:	2310      	movs	r3, #16
d0008e10:	6014      	str	r4, [r2, #0]
d0008e12:	f8a2 c004 	strh.w	ip, [r2, #4]
d0008e16:	4618      	mov	r0, r3
d0008e18:	4a0a      	ldr	r2, [pc, #40]	; (d0008e44 <pjpeg_decode_init+0x470>)
d0008e1a:	f04f 0c0f 	mov.w	ip, #15
d0008e1e:	f88e 1000 	strb.w	r1, [lr]
d0008e22:	4907      	ldr	r1, [pc, #28]	; (d0008e40 <pjpeg_decode_init+0x46c>)
d0008e24:	9201      	str	r2, [sp, #4]
d0008e26:	9100      	str	r1, [sp, #0]
d0008e28:	700b      	strb	r3, [r1, #0]
d0008e2a:	7013      	strb	r3, [r2, #0]
d0008e2c:	4b06      	ldr	r3, [pc, #24]	; (d0008e48 <pjpeg_decode_init+0x474>)
d0008e2e:	2104      	movs	r1, #4
d0008e30:	881b      	ldrh	r3, [r3, #0]
d0008e32:	330f      	adds	r3, #15
d0008e34:	e751      	b.n	d0008cda <pjpeg_decode_init+0x306>
d0008e36:	bf00      	nop
d0008e38:	d000e7fe 	.word	0xd000e7fe
d0008e3c:	d000e6ea 	.word	0xd000e6ea
d0008e40:	d000e6f0 	.word	0xd000e6f0
d0008e44:	d000e6f1 	.word	0xd000e6f1
d0008e48:	d000e2d4 	.word	0xd000e2d4
d0008e4c:	d000e2d6 	.word	0xd000e2d6
d0008e50:	d000e6f4 	.word	0xd000e6f4
d0008e54:	d000e6ee 	.word	0xd000e6ee
d0008e58:	d000e6f6 	.word	0xd000e6f6
d0008e5c:	d000e6ec 	.word	0xd000e6ec
d0008e60:	d000df60 	.word	0xd000df60
d0008e64:	d000e6e4 	.word	0xd000e6e4
d0008e68:	02010000 	.word	0x02010000
d0008e6c:	2000      	movs	r0, #0
d0008e6e:	4601      	mov	r1, r0
d0008e70:	b2ec      	uxtb	r4, r5
d0008e72:	4a9e      	ldr	r2, [pc, #632]	; (d00090ec <pjpeg_decode_init+0x718>)
d0008e74:	ea4f 1e13 	mov.w	lr, r3, lsr #4
d0008e78:	3501      	adds	r5, #1
d0008e7a:	5510      	strb	r0, [r2, r4]
d0008e7c:	f003 030f 	and.w	r3, r3, #15
d0008e80:	4a9b      	ldr	r2, [pc, #620]	; (d00090f0 <pjpeg_decode_init+0x71c>)
d0008e82:	b2e8      	uxtb	r0, r5
d0008e84:	4c9b      	ldr	r4, [pc, #620]	; (d00090f4 <pjpeg_decode_init+0x720>)
d0008e86:	f802 e001 	strb.w	lr, [r2, r1]
d0008e8a:	f898 e000 	ldrb.w	lr, [r8]
d0008e8e:	5463      	strb	r3, [r4, r1]
d0008e90:	4586      	cmp	lr, r0
d0008e92:	f63f af5c 	bhi.w	d0008d4e <pjpeg_decode_init+0x37a>
d0008e96:	2000      	movs	r0, #0
d0008e98:	9d03      	ldr	r5, [sp, #12]
d0008e9a:	f7fd fb87 	bl	d00065ac <getBits.constprop.1>
d0008e9e:	2000      	movs	r0, #0
d0008ea0:	f7fd fb84 	bl	d00065ac <getBits.constprop.1>
d0008ea4:	2100      	movs	r1, #0
d0008ea6:	2004      	movs	r0, #4
d0008ea8:	f7fe f88c 	bl	d0006fc4 <getBits>
d0008eac:	2100      	movs	r1, #0
d0008eae:	2004      	movs	r0, #4
d0008eb0:	f7fe f888 	bl	d0006fc4 <getBits>
d0008eb4:	f1a9 0305 	sub.w	r3, r9, #5
d0008eb8:	b29b      	uxth	r3, r3
d0008eba:	b14b      	cbz	r3, d0008ed0 <pjpeg_decode_init+0x4fc>
d0008ebc:	46a9      	mov	r9, r5
d0008ebe:	461d      	mov	r5, r3
d0008ec0:	3d01      	subs	r5, #1
d0008ec2:	2000      	movs	r0, #0
d0008ec4:	f7fd fb72 	bl	d00065ac <getBits.constprop.1>
d0008ec8:	b2ad      	uxth	r5, r5
d0008eca:	2d00      	cmp	r5, #0
d0008ecc:	d1f8      	bne.n	d0008ec0 <pjpeg_decode_init+0x4ec>
d0008ece:	464d      	mov	r5, r9
d0008ed0:	f898 c000 	ldrb.w	ip, [r8]
d0008ed4:	f1bc 0f00 	cmp.w	ip, #0
d0008ed8:	d05f      	beq.n	d0008f9a <pjpeg_decode_init+0x5c6>
d0008eda:	4b84      	ldr	r3, [pc, #528]	; (d00090ec <pjpeg_decode_init+0x718>)
d0008edc:	2201      	movs	r2, #1
d0008ede:	4986      	ldr	r1, [pc, #536]	; (d00090f8 <pjpeg_decode_init+0x724>)
d0008ee0:	f893 e000 	ldrb.w	lr, [r3]
d0008ee4:	f891 9000 	ldrb.w	r9, [r1]
d0008ee8:	f814 300e 	ldrb.w	r3, [r4, lr]
d0008eec:	4980      	ldr	r1, [pc, #512]	; (d00090f0 <pjpeg_decode_init+0x71c>)
d0008eee:	3302      	adds	r3, #2
d0008ef0:	4608      	mov	r0, r1
d0008ef2:	f811 100e 	ldrb.w	r1, [r1, lr]
d0008ef6:	b2db      	uxtb	r3, r3
d0008ef8:	fa02 f101 	lsl.w	r1, r2, r1
d0008efc:	fa02 f303 	lsl.w	r3, r2, r3
d0008f00:	430b      	orrs	r3, r1
d0008f02:	ea33 0809 	bics.w	r8, r3, r9
d0008f06:	f040 80aa 	bne.w	d000905e <pjpeg_decode_init+0x68a>
d0008f0a:	4594      	cmp	ip, r2
d0008f0c:	d920      	bls.n	d0008f50 <pjpeg_decode_init+0x57c>
d0008f0e:	4b77      	ldr	r3, [pc, #476]	; (d00090ec <pjpeg_decode_init+0x718>)
d0008f10:	7859      	ldrb	r1, [r3, #1]
d0008f12:	5c63      	ldrb	r3, [r4, r1]
d0008f14:	5c41      	ldrb	r1, [r0, r1]
d0008f16:	3302      	adds	r3, #2
d0008f18:	fa02 f101 	lsl.w	r1, r2, r1
d0008f1c:	b2db      	uxtb	r3, r3
d0008f1e:	fa02 f303 	lsl.w	r3, r2, r3
d0008f22:	430b      	orrs	r3, r1
d0008f24:	ea33 0809 	bics.w	r8, r3, r9
d0008f28:	f040 8099 	bne.w	d000905e <pjpeg_decode_init+0x68a>
d0008f2c:	f1bc 0f02 	cmp.w	ip, #2
d0008f30:	d00e      	beq.n	d0008f50 <pjpeg_decode_init+0x57c>
d0008f32:	4b6e      	ldr	r3, [pc, #440]	; (d00090ec <pjpeg_decode_init+0x718>)
d0008f34:	7899      	ldrb	r1, [r3, #2]
d0008f36:	5c63      	ldrb	r3, [r4, r1]
d0008f38:	5c41      	ldrb	r1, [r0, r1]
d0008f3a:	3302      	adds	r3, #2
d0008f3c:	fa02 f101 	lsl.w	r1, r2, r1
d0008f40:	b2db      	uxtb	r3, r3
d0008f42:	fa02 f303 	lsl.w	r3, r2, r3
d0008f46:	430b      	orrs	r3, r1
d0008f48:	ea33 0309 	bics.w	r3, r3, r9
d0008f4c:	f040 8087 	bne.w	d000905e <pjpeg_decode_init+0x68a>
d0008f50:	496a      	ldr	r1, [pc, #424]	; (d00090fc <pjpeg_decode_init+0x728>)
d0008f52:	4b6b      	ldr	r3, [pc, #428]	; (d0009100 <pjpeg_decode_init+0x72c>)
d0008f54:	f811 200e 	ldrb.w	r2, [r1, lr]
d0008f58:	781b      	ldrb	r3, [r3, #0]
d0008f5a:	2a00      	cmp	r2, #0
d0008f5c:	bf14      	ite	ne
d0008f5e:	2202      	movne	r2, #2
d0008f60:	2201      	moveq	r2, #1
d0008f62:	4213      	tst	r3, r2
d0008f64:	f000 80a2 	beq.w	d00090ac <pjpeg_decode_init+0x6d8>
d0008f68:	f1bc 0f01 	cmp.w	ip, #1
d0008f6c:	d915      	bls.n	d0008f9a <pjpeg_decode_init+0x5c6>
d0008f6e:	485f      	ldr	r0, [pc, #380]	; (d00090ec <pjpeg_decode_init+0x718>)
d0008f70:	7842      	ldrb	r2, [r0, #1]
d0008f72:	5c8a      	ldrb	r2, [r1, r2]
d0008f74:	2a00      	cmp	r2, #0
d0008f76:	bf14      	ite	ne
d0008f78:	2202      	movne	r2, #2
d0008f7a:	2201      	moveq	r2, #1
d0008f7c:	4213      	tst	r3, r2
d0008f7e:	f000 8095 	beq.w	d00090ac <pjpeg_decode_init+0x6d8>
d0008f82:	f1bc 0f02 	cmp.w	ip, #2
d0008f86:	d008      	beq.n	d0008f9a <pjpeg_decode_init+0x5c6>
d0008f88:	7882      	ldrb	r2, [r0, #2]
d0008f8a:	5c8a      	ldrb	r2, [r1, r2]
d0008f8c:	2a00      	cmp	r2, #0
d0008f8e:	bf14      	ite	ne
d0008f90:	2202      	movne	r2, #2
d0008f92:	2201      	moveq	r2, #1
d0008f94:	4213      	tst	r3, r2
d0008f96:	f000 8089 	beq.w	d00090ac <pjpeg_decode_init+0x6d8>
d0008f9a:	4b5a      	ldr	r3, [pc, #360]	; (d0009104 <pjpeg_decode_init+0x730>)
d0008f9c:	4a5a      	ldr	r2, [pc, #360]	; (d0009108 <pjpeg_decode_init+0x734>)
d0008f9e:	8819      	ldrh	r1, [r3, #0]
d0008fa0:	2300      	movs	r3, #0
d0008fa2:	6013      	str	r3, [r2, #0]
d0008fa4:	8093      	strh	r3, [r2, #4]
d0008fa6:	b119      	cbz	r1, d0008fb0 <pjpeg_decode_init+0x5dc>
d0008fa8:	4858      	ldr	r0, [pc, #352]	; (d000910c <pjpeg_decode_init+0x738>)
d0008faa:	4a59      	ldr	r2, [pc, #356]	; (d0009110 <pjpeg_decode_init+0x73c>)
d0008fac:	8001      	strh	r1, [r0, #0]
d0008fae:	8013      	strh	r3, [r2, #0]
d0008fb0:	7833      	ldrb	r3, [r6, #0]
d0008fb2:	2b00      	cmp	r3, #0
d0008fb4:	d144      	bne.n	d0009040 <pjpeg_decode_init+0x66c>
d0008fb6:	4b57      	ldr	r3, [pc, #348]	; (d0009114 <pjpeg_decode_init+0x740>)
d0008fb8:	4a57      	ldr	r2, [pc, #348]	; (d0009118 <pjpeg_decode_init+0x744>)
d0008fba:	f8bb 1000 	ldrh.w	r1, [fp]
d0008fbe:	781b      	ldrb	r3, [r3, #0]
d0008fc0:	7812      	ldrb	r2, [r2, #0]
d0008fc2:	f8df c18c 	ldr.w	ip, [pc, #396]	; d0009150 <pjpeg_decode_init+0x77c>
d0008fc6:	3201      	adds	r2, #1
d0008fc8:	4c53      	ldr	r4, [pc, #332]	; (d0009118 <pjpeg_decode_init+0x744>)
d0008fca:	3b01      	subs	r3, #1
d0008fcc:	0a09      	lsrs	r1, r1, #8
d0008fce:	f04f 0e08 	mov.w	lr, #8
d0008fd2:	7022      	strb	r2, [r4, #0]
d0008fd4:	b2db      	uxtb	r3, r3
d0008fd6:	4a4f      	ldr	r2, [pc, #316]	; (d0009114 <pjpeg_decode_init+0x740>)
d0008fd8:	2001      	movs	r0, #1
d0008fda:	f886 e000 	strb.w	lr, [r6]
d0008fde:	7013      	strb	r3, [r2, #0]
d0008fe0:	f80c 1003 	strb.w	r1, [ip, r3]
d0008fe4:	f7fd fae2 	bl	d00065ac <getBits.constprop.1>
d0008fe8:	2001      	movs	r0, #1
d0008fea:	f7fd fadf 	bl	d00065ac <getBits.constprop.1>
d0008fee:	783c      	ldrb	r4, [r7, #0]
d0008ff0:	2c00      	cmp	r4, #0
d0008ff2:	f47f ad36 	bne.w	d0008a62 <pjpeg_decode_init+0x8e>
d0008ff6:	9902      	ldr	r1, [sp, #8]
d0008ff8:	4b48      	ldr	r3, [pc, #288]	; (d000911c <pjpeg_decode_init+0x748>)
d0008ffa:	780f      	ldrb	r7, [r1, #0]
d0008ffc:	4948      	ldr	r1, [pc, #288]	; (d0009120 <pjpeg_decode_init+0x74c>)
d0008ffe:	881a      	ldrh	r2, [r3, #0]
d0009000:	f8b1 c000 	ldrh.w	ip, [r1]
d0009004:	4947      	ldr	r1, [pc, #284]	; (d0009124 <pjpeg_decode_init+0x750>)
d0009006:	4b48      	ldr	r3, [pc, #288]	; (d0009128 <pjpeg_decode_init+0x754>)
d0009008:	f8b1 e000 	ldrh.w	lr, [r1]
d000900c:	9900      	ldr	r1, [sp, #0]
d000900e:	881b      	ldrh	r3, [r3, #0]
d0009010:	f891 8000 	ldrb.w	r8, [r1]
d0009014:	9901      	ldr	r1, [sp, #4]
d0009016:	f89a 6000 	ldrb.w	r6, [sl]
d000901a:	7808      	ldrb	r0, [r1, #0]
d000901c:	602a      	str	r2, [r5, #0]
d000901e:	4943      	ldr	r1, [pc, #268]	; (d000912c <pjpeg_decode_init+0x758>)
d0009020:	4a43      	ldr	r2, [pc, #268]	; (d0009130 <pjpeg_decode_init+0x75c>)
d0009022:	606b      	str	r3, [r5, #4]
d0009024:	4b43      	ldr	r3, [pc, #268]	; (d0009134 <pjpeg_decode_init+0x760>)
d0009026:	60ae      	str	r6, [r5, #8]
d0009028:	752f      	strb	r7, [r5, #20]
d000902a:	f8c5 c00c 	str.w	ip, [r5, #12]
d000902e:	f8c5 e010 	str.w	lr, [r5, #16]
d0009032:	f8c5 8018 	str.w	r8, [r5, #24]
d0009036:	61e8      	str	r0, [r5, #28]
d0009038:	6229      	str	r1, [r5, #32]
d000903a:	626a      	str	r2, [r5, #36]	; 0x24
d000903c:	62ab      	str	r3, [r5, #40]	; 0x28
d000903e:	e510      	b.n	d0008a62 <pjpeg_decode_init+0x8e>
d0009040:	4b34      	ldr	r3, [pc, #208]	; (d0009114 <pjpeg_decode_init+0x740>)
d0009042:	4a35      	ldr	r2, [pc, #212]	; (d0009118 <pjpeg_decode_init+0x744>)
d0009044:	781b      	ldrb	r3, [r3, #0]
d0009046:	7812      	ldrb	r2, [r2, #0]
d0009048:	3b01      	subs	r3, #1
d000904a:	f8bb 1000 	ldrh.w	r1, [fp]
d000904e:	3201      	adds	r2, #1
d0009050:	f8df c0fc 	ldr.w	ip, [pc, #252]	; d0009150 <pjpeg_decode_init+0x77c>
d0009054:	b2db      	uxtb	r3, r3
d0009056:	b2d2      	uxtb	r2, r2
d0009058:	f80c 1003 	strb.w	r1, [ip, r3]
d000905c:	e7b3      	b.n	d0008fc6 <pjpeg_decode_init+0x5f2>
d000905e:	2418      	movs	r4, #24
d0009060:	e545      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0009062:	240b      	movs	r4, #11
d0009064:	e543      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0009066:	2101      	movs	r1, #1
d0009068:	4608      	mov	r0, r1
d000906a:	e701      	b.n	d0008e70 <pjpeg_decode_init+0x49c>
d000906c:	2102      	movs	r1, #2
d000906e:	4608      	mov	r0, r1
d0009070:	e6fe      	b.n	d0008e70 <pjpeg_decode_init+0x49c>
d0009072:	240a      	movs	r4, #10
d0009074:	e53b      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d0009076:	4a30      	ldr	r2, [pc, #192]	; (d0009138 <pjpeg_decode_init+0x764>)
d0009078:	2003      	movs	r0, #3
d000907a:	4930      	ldr	r1, [pc, #192]	; (d000913c <pjpeg_decode_init+0x768>)
d000907c:	f44f 7480 	mov.w	r4, #256	; 0x100
d0009080:	7013      	strb	r3, [r2, #0]
d0009082:	f04f 0e02 	mov.w	lr, #2
d0009086:	2308      	movs	r3, #8
d0009088:	7008      	strb	r0, [r1, #0]
d000908a:	f8df 90bc 	ldr.w	r9, [pc, #188]	; d0009148 <pjpeg_decode_init+0x774>
d000908e:	f04f 0c07 	mov.w	ip, #7
d0009092:	492b      	ldr	r1, [pc, #172]	; (d0009140 <pjpeg_decode_init+0x76c>)
d0009094:	4618      	mov	r0, r3
d0009096:	9202      	str	r2, [sp, #8]
d0009098:	4a2a      	ldr	r2, [pc, #168]	; (d0009144 <pjpeg_decode_init+0x770>)
d000909a:	f8a9 4000 	strh.w	r4, [r9]
d000909e:	f889 e002 	strb.w	lr, [r9, #2]
d00090a2:	9200      	str	r2, [sp, #0]
d00090a4:	9101      	str	r1, [sp, #4]
d00090a6:	7013      	strb	r3, [r2, #0]
d00090a8:	700b      	strb	r3, [r1, #0]
d00090aa:	e612      	b.n	d0008cd2 <pjpeg_decode_init+0x2fe>
d00090ac:	2417      	movs	r4, #23
d00090ae:	e51e      	b.n	d0008aee <pjpeg_decode_init+0x11a>
d00090b0:	4a21      	ldr	r2, [pc, #132]	; (d0009138 <pjpeg_decode_init+0x764>)
d00090b2:	2004      	movs	r0, #4
d00090b4:	4c24      	ldr	r4, [pc, #144]	; (d0009148 <pjpeg_decode_init+0x774>)
d00090b6:	f04f 0908 	mov.w	r9, #8
d00090ba:	7013      	strb	r3, [r2, #0]
d00090bc:	f04f 0e10 	mov.w	lr, #16
d00090c0:	4b22      	ldr	r3, [pc, #136]	; (d000914c <pjpeg_decode_init+0x778>)
d00090c2:	f04f 0c07 	mov.w	ip, #7
d00090c6:	491d      	ldr	r1, [pc, #116]	; (d000913c <pjpeg_decode_init+0x768>)
d00090c8:	9202      	str	r2, [sp, #8]
d00090ca:	6023      	str	r3, [r4, #0]
d00090cc:	4a1c      	ldr	r2, [pc, #112]	; (d0009140 <pjpeg_decode_init+0x76c>)
d00090ce:	4b1d      	ldr	r3, [pc, #116]	; (d0009144 <pjpeg_decode_init+0x770>)
d00090d0:	7008      	strb	r0, [r1, #0]
d00090d2:	4648      	mov	r0, r9
d00090d4:	9300      	str	r3, [sp, #0]
d00090d6:	9201      	str	r2, [sp, #4]
d00090d8:	f883 e000 	strb.w	lr, [r3]
d00090dc:	f882 9000 	strb.w	r9, [r2]
d00090e0:	e6a4      	b.n	d0008e2c <pjpeg_decode_init+0x458>
d00090e2:	783c      	ldrb	r4, [r7, #0]
d00090e4:	2c00      	cmp	r4, #0
d00090e6:	bf08      	it	eq
d00090e8:	241a      	moveq	r4, #26
d00090ea:	e4ba      	b.n	d0008a62 <pjpeg_decode_init+0x8e>
d00090ec:	d000df64 	.word	0xd000df64
d00090f0:	d000df58 	.word	0xd000df58
d00090f4:	d000df54 	.word	0xd000df54
d00090f8:	d000e800 	.word	0xd000e800
d00090fc:	d000df68 	.word	0xd000df68
d0009100:	d000e801 	.word	0xd000e801
d0009104:	d000e7fa 	.word	0xd000e7fa
d0009108:	d000e3dc 	.word	0xd000e3dc
d000910c:	d000e7fc 	.word	0xd000e7fc
d0009110:	d000e6f2 	.word	0xd000e6f2
d0009114:	d000e3d9 	.word	0xd000e3d9
d0009118:	d000e3d8 	.word	0xd000e3d8
d000911c:	d000e2d4 	.word	0xd000e2d4
d0009120:	d000e6ee 	.word	0xd000e6ee
d0009124:	d000e6ec 	.word	0xd000e6ec
d0009128:	d000e2d6 	.word	0xd000e2d6
d000912c:	d000e5e4 	.word	0xd000e5e4
d0009130:	d000e4e4 	.word	0xd000e4e4
d0009134:	d000e3e4 	.word	0xd000e3e4
d0009138:	d000e7fe 	.word	0xd000e7fe
d000913c:	d000e6ea 	.word	0xd000e6ea
d0009140:	d000e6f1 	.word	0xd000e6f1
d0009144:	d000e6f0 	.word	0xd000e6f0
d0009148:	d000e6e4 	.word	0xd000e6e4
d000914c:	02010000 	.word	0x02010000
d0009150:	d000e2d8 	.word	0xd000e2d8

d0009154 <init_rgb332_palette>:
d0009154:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0009158:	2100      	movs	r1, #0
d000915a:	2403      	movs	r4, #3
d000915c:	f8df a230 	ldr.w	sl, [pc, #560]	; d0009390 <init_rgb332_palette+0x23c>
d0009160:	fbaa 2304 	umull	r2, r3, sl, r4
d0009164:	014a      	lsls	r2, r1, #5
d0009166:	01cd      	lsls	r5, r1, #7
d0009168:	f8df c228 	ldr.w	ip, [pc, #552]	; d0009394 <init_rgb332_palette+0x240>
d000916c:	1ae6      	subs	r6, r4, r3
d000916e:	b212      	sxth	r2, r2
d0009170:	4f7b      	ldr	r7, [pc, #492]	; (d0009360 <init_rgb332_palette+0x20c>)
d0009172:	3101      	adds	r1, #1
d0009174:	eb03 0356 	add.w	r3, r3, r6, lsr #1
d0009178:	f8df e21c 	ldr.w	lr, [pc, #540]	; d0009398 <init_rgb332_palette+0x244>
d000917c:	4e79      	ldr	r6, [pc, #484]	; (d0009364 <init_rgb332_palette+0x210>)
d000917e:	2908      	cmp	r1, #8
d0009180:	ea4f 0393 	mov.w	r3, r3, lsr #2
d0009184:	f8df b214 	ldr.w	fp, [pc, #532]	; d000939c <init_rgb332_palette+0x248>
d0009188:	f8df 9214 	ldr.w	r9, [pc, #532]	; d00093a0 <init_rgb332_palette+0x24c>
d000918c:	f104 04ff 	add.w	r4, r4, #255	; 0xff
d0009190:	ea4f 4303 	mov.w	r3, r3, lsl #16
d0009194:	f043 487f 	orr.w	r8, r3, #4278190080	; 0xff000000
d0009198:	ea43 0c0c 	orr.w	ip, r3, ip
d000919c:	ea47 0703 	orr.w	r7, r7, r3
d00091a0:	ea43 0e0e 	orr.w	lr, r3, lr
d00091a4:	f840 8005 	str.w	r8, [r0, r5]
d00091a8:	f042 0801 	orr.w	r8, r2, #1
d00091ac:	ea46 0603 	orr.w	r6, r6, r3
d00091b0:	4d6d      	ldr	r5, [pc, #436]	; (d0009368 <init_rgb332_palette+0x214>)
d00091b2:	f840 c028 	str.w	ip, [r0, r8, lsl #2]
d00091b6:	f042 0802 	orr.w	r8, r2, #2
d00091ba:	ea45 0503 	orr.w	r5, r5, r3
d00091be:	f8df c1e4 	ldr.w	ip, [pc, #484]	; d00093a4 <init_rgb332_palette+0x250>
d00091c2:	f840 7028 	str.w	r7, [r0, r8, lsl #2]
d00091c6:	f042 0803 	orr.w	r8, r2, #3
d00091ca:	ea43 0c0c 	orr.w	ip, r3, ip
d00091ce:	ea43 0b0b 	orr.w	fp, r3, fp
d00091d2:	f840 e028 	str.w	lr, [r0, r8, lsl #2]
d00091d6:	f042 0e04 	orr.w	lr, r2, #4
d00091da:	4f64      	ldr	r7, [pc, #400]	; (d000936c <init_rgb332_palette+0x218>)
d00091dc:	ea43 0909 	orr.w	r9, r3, r9
d00091e0:	f840 602e 	str.w	r6, [r0, lr, lsl #2]
d00091e4:	f042 0605 	orr.w	r6, r2, #5
d00091e8:	f8df e1bc 	ldr.w	lr, [pc, #444]	; d00093a8 <init_rgb332_palette+0x254>
d00091ec:	ea47 0703 	orr.w	r7, r7, r3
d00091f0:	f8df 81b8 	ldr.w	r8, [pc, #440]	; d00093ac <init_rgb332_palette+0x258>
d00091f4:	ea43 0e0e 	orr.w	lr, r3, lr
d00091f8:	ea43 0808 	orr.w	r8, r3, r8
d00091fc:	f840 e026 	str.w	lr, [r0, r6, lsl #2]
d0009200:	f042 0606 	orr.w	r6, r2, #6
d0009204:	f8df e1a8 	ldr.w	lr, [pc, #424]	; d00093b0 <init_rgb332_palette+0x25c>
d0009208:	ea43 0e0e 	orr.w	lr, r3, lr
d000920c:	f840 e026 	str.w	lr, [r0, r6, lsl #2]
d0009210:	f042 0e07 	orr.w	lr, r2, #7
d0009214:	4e56      	ldr	r6, [pc, #344]	; (d0009370 <init_rgb332_palette+0x21c>)
d0009216:	f840 502e 	str.w	r5, [r0, lr, lsl #2]
d000921a:	f042 0e08 	orr.w	lr, r2, #8
d000921e:	ea46 0603 	orr.w	r6, r6, r3
d0009222:	4d54      	ldr	r5, [pc, #336]	; (d0009374 <init_rgb332_palette+0x220>)
d0009224:	f840 c02e 	str.w	ip, [r0, lr, lsl #2]
d0009228:	f042 0c09 	orr.w	ip, r2, #9
d000922c:	f8df e184 	ldr.w	lr, [pc, #388]	; d00093b4 <init_rgb332_palette+0x260>
d0009230:	ea45 0503 	orr.w	r5, r5, r3
d0009234:	ea43 0e0e 	orr.w	lr, r3, lr
d0009238:	f840 e02c 	str.w	lr, [r0, ip, lsl #2]
d000923c:	f042 0c0a 	orr.w	ip, r2, #10
d0009240:	f8df e174 	ldr.w	lr, [pc, #372]	; d00093b8 <init_rgb332_palette+0x264>
d0009244:	f840 b02c 	str.w	fp, [r0, ip, lsl #2]
d0009248:	f042 0b0b 	orr.w	fp, r2, #11
d000924c:	ea43 0e0e 	orr.w	lr, r3, lr
d0009250:	f8df c168 	ldr.w	ip, [pc, #360]	; d00093bc <init_rgb332_palette+0x268>
d0009254:	f840 702b 	str.w	r7, [r0, fp, lsl #2]
d0009258:	f042 0b0c 	orr.w	fp, r2, #12
d000925c:	ea43 0c0c 	orr.w	ip, r3, ip
d0009260:	4f45      	ldr	r7, [pc, #276]	; (d0009378 <init_rgb332_palette+0x224>)
d0009262:	f840 902b 	str.w	r9, [r0, fp, lsl #2]
d0009266:	f042 090d 	orr.w	r9, r2, #13
d000926a:	f8df b154 	ldr.w	fp, [pc, #340]	; d00093c0 <init_rgb332_palette+0x26c>
d000926e:	ea47 0703 	orr.w	r7, r7, r3
d0009272:	ea43 0b0b 	orr.w	fp, r3, fp
d0009276:	f840 b029 	str.w	fp, [r0, r9, lsl #2]
d000927a:	f042 090e 	orr.w	r9, r2, #14
d000927e:	f8df b144 	ldr.w	fp, [pc, #324]	; d00093c4 <init_rgb332_palette+0x270>
d0009282:	ea43 0b0b 	orr.w	fp, r3, fp
d0009286:	f840 b029 	str.w	fp, [r0, r9, lsl #2]
d000928a:	f042 090f 	orr.w	r9, r2, #15
d000928e:	f840 8029 	str.w	r8, [r0, r9, lsl #2]
d0009292:	f042 0810 	orr.w	r8, r2, #16
d0009296:	f8df 9130 	ldr.w	r9, [pc, #304]	; d00093c8 <init_rgb332_palette+0x274>
d000929a:	f840 6028 	str.w	r6, [r0, r8, lsl #2]
d000929e:	f042 0811 	orr.w	r8, r2, #17
d00092a2:	ea43 0909 	orr.w	r9, r3, r9
d00092a6:	4e35      	ldr	r6, [pc, #212]	; (d000937c <init_rgb332_palette+0x228>)
d00092a8:	f840 9028 	str.w	r9, [r0, r8, lsl #2]
d00092ac:	f042 0812 	orr.w	r8, r2, #18
d00092b0:	f8df 9118 	ldr.w	r9, [pc, #280]	; d00093cc <init_rgb332_palette+0x278>
d00092b4:	ea46 0603 	orr.w	r6, r6, r3
d00092b8:	ea43 0909 	orr.w	r9, r3, r9
d00092bc:	f840 9028 	str.w	r9, [r0, r8, lsl #2]
d00092c0:	f042 0813 	orr.w	r8, r2, #19
d00092c4:	f840 5028 	str.w	r5, [r0, r8, lsl #2]
d00092c8:	f042 0814 	orr.w	r8, r2, #20
d00092cc:	4d2c      	ldr	r5, [pc, #176]	; (d0009380 <init_rgb332_palette+0x22c>)
d00092ce:	f840 e028 	str.w	lr, [r0, r8, lsl #2]
d00092d2:	f042 0815 	orr.w	r8, r2, #21
d00092d6:	ea45 0503 	orr.w	r5, r5, r3
d00092da:	f8df e0f4 	ldr.w	lr, [pc, #244]	; d00093d0 <init_rgb332_palette+0x27c>
d00092de:	f840 c028 	str.w	ip, [r0, r8, lsl #2]
d00092e2:	f042 0816 	orr.w	r8, r2, #22
d00092e6:	ea43 0e0e 	orr.w	lr, r3, lr
d00092ea:	f8df c0e8 	ldr.w	ip, [pc, #232]	; d00093d4 <init_rgb332_palette+0x280>
d00092ee:	f840 7028 	str.w	r7, [r0, r8, lsl #2]
d00092f2:	f042 0817 	orr.w	r8, r2, #23
d00092f6:	ea43 0c0c 	orr.w	ip, r3, ip
d00092fa:	4f22      	ldr	r7, [pc, #136]	; (d0009384 <init_rgb332_palette+0x230>)
d00092fc:	f840 6028 	str.w	r6, [r0, r8, lsl #2]
d0009300:	f042 0818 	orr.w	r8, r2, #24
d0009304:	ea47 0703 	orr.w	r7, r7, r3
d0009308:	4e1f      	ldr	r6, [pc, #124]	; (d0009388 <init_rgb332_palette+0x234>)
d000930a:	f840 5028 	str.w	r5, [r0, r8, lsl #2]
d000930e:	f042 0819 	orr.w	r8, r2, #25
d0009312:	4d1e      	ldr	r5, [pc, #120]	; (d000938c <init_rgb332_palette+0x238>)
d0009314:	ea46 0603 	orr.w	r6, r6, r3
d0009318:	f840 e028 	str.w	lr, [r0, r8, lsl #2]
d000931c:	f042 0e1a 	orr.w	lr, r2, #26
d0009320:	ea45 0503 	orr.w	r5, r5, r3
d0009324:	f840 c02e 	str.w	ip, [r0, lr, lsl #2]
d0009328:	f042 0c1b 	orr.w	ip, r2, #27
d000932c:	f840 702c 	str.w	r7, [r0, ip, lsl #2]
d0009330:	f043 2cff 	orr.w	ip, r3, #4278255360	; 0xff00ff00
d0009334:	f042 071c 	orr.w	r7, r2, #28
d0009338:	f463 037f 	orn	r3, r3, #16711680	; 0xff0000
d000933c:	f840 c027 	str.w	ip, [r0, r7, lsl #2]
d0009340:	f042 0c1d 	orr.w	ip, r2, #29
d0009344:	f042 071e 	orr.w	r7, r2, #30
d0009348:	f042 021f 	orr.w	r2, r2, #31
d000934c:	f840 602c 	str.w	r6, [r0, ip, lsl #2]
d0009350:	f840 5027 	str.w	r5, [r0, r7, lsl #2]
d0009354:	f840 3022 	str.w	r3, [r0, r2, lsl #2]
d0009358:	f47f af02 	bne.w	d0009160 <init_rgb332_palette+0xc>
d000935c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0009360:	ff0000aa 	.word	0xff0000aa
d0009364:	ff002400 	.word	0xff002400
d0009368:	ff0024ff 	.word	0xff0024ff
d000936c:	ff0049ff 	.word	0xff0049ff
d0009370:	ff009200 	.word	0xff009200
d0009374:	ff0092ff 	.word	0xff0092ff
d0009378:	ff00b6aa 	.word	0xff00b6aa
d000937c:	ff00b6ff 	.word	0xff00b6ff
d0009380:	ff00db00 	.word	0xff00db00
d0009384:	ff00dbff 	.word	0xff00dbff
d0009388:	ff00ff55 	.word	0xff00ff55
d000938c:	ff00ffaa 	.word	0xff00ffaa
d0009390:	24924925 	.word	0x24924925
d0009394:	ff000055 	.word	0xff000055
d0009398:	ff0000ff 	.word	0xff0000ff
d000939c:	ff0049aa 	.word	0xff0049aa
d00093a0:	ff006d00 	.word	0xff006d00
d00093a4:	ff004900 	.word	0xff004900
d00093a8:	ff002455 	.word	0xff002455
d00093ac:	ff006dff 	.word	0xff006dff
d00093b0:	ff0024aa 	.word	0xff0024aa
d00093b4:	ff004955 	.word	0xff004955
d00093b8:	ff00b600 	.word	0xff00b600
d00093bc:	ff00b655 	.word	0xff00b655
d00093c0:	ff006d55 	.word	0xff006d55
d00093c4:	ff006daa 	.word	0xff006daa
d00093c8:	ff009255 	.word	0xff009255
d00093cc:	ff0092aa 	.word	0xff0092aa
d00093d0:	ff00db55 	.word	0xff00db55
d00093d4:	ff00dbaa 	.word	0xff00dbaa

d00093d8 <bmp_make_mask_info>:
d00093d8:	b430      	push	{r4, r5}
d00093da:	b311      	cbz	r1, d0009422 <bmp_make_mask_info+0x4a>
d00093dc:	f011 0501 	ands.w	r5, r1, #1
d00093e0:	460b      	mov	r3, r1
d00093e2:	d002      	beq.n	d00093ea <bmp_make_mask_info+0x12>
d00093e4:	e013      	b.n	d000940e <bmp_make_mask_info+0x36>
d00093e6:	07da      	lsls	r2, r3, #31
d00093e8:	d411      	bmi.n	d000940e <bmp_make_mask_info+0x36>
d00093ea:	085b      	lsrs	r3, r3, #1
d00093ec:	d1fb      	bne.n	d00093e6 <bmp_make_mask_info+0xe>
d00093ee:	460a      	mov	r2, r1
d00093f0:	2400      	movs	r4, #0
d00093f2:	0852      	lsrs	r2, r2, #1
d00093f4:	3401      	adds	r4, #1
d00093f6:	07d5      	lsls	r5, r2, #31
d00093f8:	d5fb      	bpl.n	d00093f2 <bmp_make_mask_info+0x1a>
d00093fa:	b11b      	cbz	r3, d0009404 <bmp_make_mask_info+0x2c>
d00093fc:	2201      	movs	r2, #1
d00093fe:	fa02 f303 	lsl.w	r3, r2, r3
d0009402:	3b01      	subs	r3, #1
d0009404:	6083      	str	r3, [r0, #8]
d0009406:	e9c0 1400 	strd	r1, r4, [r0]
d000940a:	bc30      	pop	{r4, r5}
d000940c:	4770      	bx	lr
d000940e:	461a      	mov	r2, r3
d0009410:	2300      	movs	r3, #0
d0009412:	0852      	lsrs	r2, r2, #1
d0009414:	3301      	adds	r3, #1
d0009416:	f012 0401 	ands.w	r4, r2, #1
d000941a:	d1fa      	bne.n	d0009412 <bmp_make_mask_info+0x3a>
d000941c:	2d00      	cmp	r5, #0
d000941e:	d0e6      	beq.n	d00093ee <bmp_make_mask_info+0x16>
d0009420:	e7eb      	b.n	d00093fa <bmp_make_mask_info+0x22>
d0009422:	460c      	mov	r4, r1
d0009424:	460b      	mov	r3, r1
d0009426:	e7ed      	b.n	d0009404 <bmp_make_mask_info+0x2c>

d0009428 <wait_for_exit_combo>:
d0009428:	b510      	push	{r4, lr}
d000942a:	4c11      	ldr	r4, [pc, #68]	; (d0009470 <wait_for_exit_combo+0x48>)
d000942c:	7820      	ldrb	r0, [r4, #0]
d000942e:	7861      	ldrb	r1, [r4, #1]
d0009430:	78a2      	ldrb	r2, [r4, #2]
d0009432:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0009436:	78e3      	ldrb	r3, [r4, #3]
d0009438:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000943c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009440:	6a1b      	ldr	r3, [r3, #32]
d0009442:	4798      	blx	r3
d0009444:	f000 0003 	and.w	r0, r0, #3
d0009448:	2803      	cmp	r0, #3
d000944a:	d1ef      	bne.n	d000942c <wait_for_exit_combo+0x4>
d000944c:	7820      	ldrb	r0, [r4, #0]
d000944e:	7861      	ldrb	r1, [r4, #1]
d0009450:	78a2      	ldrb	r2, [r4, #2]
d0009452:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0009456:	78e3      	ldrb	r3, [r4, #3]
d0009458:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000945c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009460:	6a1b      	ldr	r3, [r3, #32]
d0009462:	4798      	blx	r3
d0009464:	f000 0003 	and.w	r0, r0, #3
d0009468:	2803      	cmp	r0, #3
d000946a:	d0ef      	beq.n	d000944c <wait_for_exit_combo+0x24>
d000946c:	bd10      	pop	{r4, pc}
d000946e:	bf00      	nop
d0009470:	2001f000 	.word	0x2001f000

d0009474 <jpeg_need_bytes>:
d0009474:	b5e0      	push	{r5, r6, r7, lr}
d0009476:	461e      	mov	r6, r3
d0009478:	689b      	ldr	r3, [r3, #8]
d000947a:	4617      	mov	r7, r2
d000947c:	6875      	ldr	r5, [r6, #4]
d000947e:	1aed      	subs	r5, r5, r3
d0009480:	428d      	cmp	r5, r1
d0009482:	bf28      	it	cs
d0009484:	460d      	movcs	r5, r1
d0009486:	b915      	cbnz	r5, d000948e <jpeg_need_bytes+0x1a>
d0009488:	2000      	movs	r0, #0
d000948a:	703d      	strb	r5, [r7, #0]
d000948c:	bde0      	pop	{r5, r6, r7, pc}
d000948e:	6831      	ldr	r1, [r6, #0]
d0009490:	462a      	mov	r2, r5
d0009492:	4419      	add	r1, r3
d0009494:	f002 fbb8 	bl	d000bc08 <memcpy>
d0009498:	68b3      	ldr	r3, [r6, #8]
d000949a:	2000      	movs	r0, #0
d000949c:	442b      	add	r3, r5
d000949e:	60b3      	str	r3, [r6, #8]
d00094a0:	703d      	strb	r5, [r7, #0]
d00094a2:	bde0      	pop	{r5, r6, r7, pc}

d00094a4 <set_status>:
d00094a4:	b570      	push	{r4, r5, r6, lr}
d00094a6:	4d13      	ldr	r5, [pc, #76]	; (d00094f4 <set_status+0x50>)
d00094a8:	4601      	mov	r1, r0
d00094aa:	4c13      	ldr	r4, [pc, #76]	; (d00094f8 <set_status+0x54>)
d00094ac:	229f      	movs	r2, #159	; 0x9f
d00094ae:	4628      	mov	r0, r5
d00094b0:	f003 f8e0 	bl	d000c674 <strncpy>
d00094b4:	7823      	ldrb	r3, [r4, #0]
d00094b6:	7862      	ldrb	r2, [r4, #1]
d00094b8:	2000      	movs	r0, #0
d00094ba:	78a1      	ldrb	r1, [r4, #2]
d00094bc:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00094c0:	78e2      	ldrb	r2, [r4, #3]
d00094c2:	f885 009f 	strb.w	r0, [r5, #159]	; 0x9f
d00094c6:	4628      	mov	r0, r5
d00094c8:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00094cc:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00094d0:	68db      	ldr	r3, [r3, #12]
d00094d2:	4798      	blx	r3
d00094d4:	7823      	ldrb	r3, [r4, #0]
d00094d6:	7862      	ldrb	r2, [r4, #1]
d00094d8:	78a1      	ldrb	r1, [r4, #2]
d00094da:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00094de:	78e2      	ldrb	r2, [r4, #3]
d00094e0:	4806      	ldr	r0, [pc, #24]	; (d00094fc <set_status+0x58>)
d00094e2:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00094e6:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00094ea:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d00094ee:	68db      	ldr	r3, [r3, #12]
d00094f0:	4718      	bx	r3
d00094f2:	bf00      	nop
d00094f4:	d000f018 	.word	0xd000f018
d00094f8:	2001f000 	.word	0x2001f000
d00094fc:	d000d678 	.word	0xd000d678

d0009500 <render_view.constprop.0>:
d0009500:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0009504:	f8df 9168 	ldr.w	r9, [pc, #360]	; d0009670 <render_view.constprop.0+0x170>
d0009508:	b081      	sub	sp, #4
d000950a:	468a      	mov	sl, r1
d000950c:	f8b9 b000 	ldrh.w	fp, [r9]
d0009510:	f8b9 7002 	ldrh.w	r7, [r9, #2]
d0009514:	f5bb 7ff0 	cmp.w	fp, #480	; 0x1e0
d0009518:	f080 8097 	bcs.w	d000964a <render_view.constprop.0+0x14a>
d000951c:	f5cb 75f0 	rsb	r5, fp, #480	; 0x1e0
d0009520:	2600      	movs	r6, #0
d0009522:	106d      	asrs	r5, r5, #1
d0009524:	f5b7 7fa0 	cmp.w	r7, #320	; 0x140
d0009528:	f080 808a 	bcs.w	d0009640 <render_view.constprop.0+0x140>
d000952c:	f5c7 78a0 	rsb	r8, r7, #320	; 0x140
d0009530:	f04f 0a00 	mov.w	sl, #0
d0009534:	ea4f 0868 	mov.w	r8, r8, asr #1
d0009538:	4c49      	ldr	r4, [pc, #292]	; (d0009660 <render_view.constprop.0+0x160>)
d000953a:	7b23      	ldrb	r3, [r4, #12]
d000953c:	7b62      	ldrb	r2, [r4, #13]
d000953e:	7ba1      	ldrb	r1, [r4, #14]
d0009540:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009544:	7be2      	ldrb	r2, [r4, #15]
d0009546:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d000954a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d000954e:	681b      	ldr	r3, [r3, #0]
d0009550:	68db      	ldr	r3, [r3, #12]
d0009552:	4798      	blx	r3
d0009554:	7b23      	ldrb	r3, [r4, #12]
d0009556:	7b62      	ldrb	r2, [r4, #13]
d0009558:	7ba1      	ldrb	r1, [r4, #14]
d000955a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d000955e:	7be2      	ldrb	r2, [r4, #15]
d0009560:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009564:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009568:	685b      	ldr	r3, [r3, #4]
d000956a:	681b      	ldr	r3, [r3, #0]
d000956c:	4798      	blx	r3
d000956e:	7b23      	ldrb	r3, [r4, #12]
d0009570:	7b62      	ldrb	r2, [r4, #13]
d0009572:	7ba1      	ldrb	r1, [r4, #14]
d0009574:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009578:	7be2      	ldrb	r2, [r4, #15]
d000957a:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d000957e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009582:	681b      	ldr	r3, [r3, #0]
d0009584:	6b5b      	ldr	r3, [r3, #52]	; 0x34
d0009586:	4798      	blx	r3
d0009588:	b388      	cbz	r0, d00095ee <render_view.constprop.0+0xee>
d000958a:	6801      	ldr	r1, [r0, #0]
d000958c:	b379      	cbz	r1, d00095ee <render_view.constprop.0+0xee>
d000958e:	f1bb 0f00 	cmp.w	fp, #0
d0009592:	d02c      	beq.n	d00095ee <render_view.constprop.0+0xee>
d0009594:	b35f      	cbz	r7, d00095ee <render_view.constprop.0+0xee>
d0009596:	eb05 0585 	add.w	r5, r5, r5, lsl #2
d000959a:	44b3      	add	fp, r6
d000959c:	eb08 1885 	add.w	r8, r8, r5, lsl #6
d00095a0:	f10b 3bff 	add.w	fp, fp, #4294967295	; 0xffffffff
d00095a4:	f8b9 2000 	ldrh.w	r2, [r9]
d00095a8:	2f01      	cmp	r7, #1
d00095aa:	f8d9 c004 	ldr.w	ip, [r9, #4]
d00095ae:	fb0a 6202 	mla	r2, sl, r2, r6
d00095b2:	f81c 3002 	ldrb.w	r3, [ip, r2]
d00095b6:	f801 3008 	strb.w	r3, [r1, r8]
d00095ba:	d011      	beq.n	d00095e0 <render_view.constprop.0+0xe0>
d00095bc:	f108 0301 	add.w	r3, r8, #1
d00095c0:	eb01 0508 	add.w	r5, r1, r8
d00095c4:	4462      	add	r2, ip
d00095c6:	440b      	add	r3, r1
d00095c8:	eb07 0c05 	add.w	ip, r7, r5
d00095cc:	f8b9 e000 	ldrh.w	lr, [r9]
d00095d0:	1b59      	subs	r1, r3, r5
d00095d2:	fb01 f10e 	mul.w	r1, r1, lr
d00095d6:	5c51      	ldrb	r1, [r2, r1]
d00095d8:	f803 1b01 	strb.w	r1, [r3], #1
d00095dc:	459c      	cmp	ip, r3
d00095de:	d1f5      	bne.n	d00095cc <render_view.constprop.0+0xcc>
d00095e0:	45b3      	cmp	fp, r6
d00095e2:	f508 78a0 	add.w	r8, r8, #320	; 0x140
d00095e6:	d002      	beq.n	d00095ee <render_view.constprop.0+0xee>
d00095e8:	3601      	adds	r6, #1
d00095ea:	6801      	ldr	r1, [r0, #0]
d00095ec:	e7da      	b.n	d00095a4 <render_view.constprop.0+0xa4>
d00095ee:	4a1d      	ldr	r2, [pc, #116]	; (d0009664 <render_view.constprop.0+0x164>)
d00095f0:	7813      	ldrb	r3, [r2, #0]
d00095f2:	f1c3 0301 	rsb	r3, r3, #1
d00095f6:	b2db      	uxtb	r3, r3
d00095f8:	7013      	strb	r3, [r2, #0]
d00095fa:	7813      	ldrb	r3, [r2, #0]
d00095fc:	7b20      	ldrb	r0, [r4, #12]
d00095fe:	7b61      	ldrb	r1, [r4, #13]
d0009600:	7ba2      	ldrb	r2, [r4, #14]
d0009602:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0009606:	b32b      	cbz	r3, d0009654 <render_view.constprop.0+0x154>
d0009608:	7be3      	ldrb	r3, [r4, #15]
d000960a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000960e:	4d16      	ldr	r5, [pc, #88]	; (d0009668 <render_view.constprop.0+0x168>)
d0009610:	4816      	ldr	r0, [pc, #88]	; (d000966c <render_view.constprop.0+0x16c>)
d0009612:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009616:	6829      	ldr	r1, [r5, #0]
d0009618:	6800      	ldr	r0, [r0, #0]
d000961a:	681b      	ldr	r3, [r3, #0]
d000961c:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d000961e:	4798      	blx	r3
d0009620:	7b23      	ldrb	r3, [r4, #12]
d0009622:	7b62      	ldrb	r2, [r4, #13]
d0009624:	7ba1      	ldrb	r1, [r4, #14]
d0009626:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d000962a:	7be2      	ldrb	r2, [r4, #15]
d000962c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009630:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009634:	681b      	ldr	r3, [r3, #0]
d0009636:	681b      	ldr	r3, [r3, #0]
d0009638:	b001      	add	sp, #4
d000963a:	e8bd 4ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d000963e:	4718      	bx	r3
d0009640:	f44f 77a0 	mov.w	r7, #320	; 0x140
d0009644:	f04f 0800 	mov.w	r8, #0
d0009648:	e776      	b.n	d0009538 <render_view.constprop.0+0x38>
d000964a:	4606      	mov	r6, r0
d000964c:	f44f 7bf0 	mov.w	fp, #480	; 0x1e0
d0009650:	2500      	movs	r5, #0
d0009652:	e767      	b.n	d0009524 <render_view.constprop.0+0x24>
d0009654:	7be3      	ldrb	r3, [r4, #15]
d0009656:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000965a:	4d04      	ldr	r5, [pc, #16]	; (d000966c <render_view.constprop.0+0x16c>)
d000965c:	4802      	ldr	r0, [pc, #8]	; (d0009668 <render_view.constprop.0+0x168>)
d000965e:	e7d8      	b.n	d0009612 <render_view.constprop.0+0x112>
d0009660:	2001f000 	.word	0x2001f000
d0009664:	d000e80c 	.word	0xd000e80c
d0009668:	d000f100 	.word	0xd000f100
d000966c:	d000f120 	.word	0xd000f120
d0009670:	d000ec10 	.word	0xd000ec10

d0009674 <free_image.constprop.0>:
d0009674:	b508      	push	{r3, lr}
d0009676:	4b06      	ldr	r3, [pc, #24]	; (d0009690 <free_image.constprop.0+0x1c>)
d0009678:	6858      	ldr	r0, [r3, #4]
d000967a:	b108      	cbz	r0, d0009680 <free_image.constprop.0+0xc>
d000967c:	f002 faae 	bl	d000bbdc <free>
d0009680:	f44f 6281 	mov.w	r2, #1032	; 0x408
d0009684:	2100      	movs	r1, #0
d0009686:	4802      	ldr	r0, [pc, #8]	; (d0009690 <free_image.constprop.0+0x1c>)
d0009688:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
d000968c:	f002 baca 	b.w	d000bc24 <memset>
d0009690:	d000ec10 	.word	0xd000ec10

d0009694 <draw_message.constprop.0>:
d0009694:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d0009698:	4c68      	ldr	r4, [pc, #416]	; (d000983c <draw_message.constprop.0+0x1a8>)
d000969a:	4606      	mov	r6, r0
d000969c:	4d68      	ldr	r5, [pc, #416]	; (d0009840 <draw_message.constprop.0+0x1ac>)
d000969e:	b082      	sub	sp, #8
d00096a0:	7b22      	ldrb	r2, [r4, #12]
d00096a2:	f04f 0902 	mov.w	r9, #2
d00096a6:	7b63      	ldrb	r3, [r4, #13]
d00096a8:	7ba0      	ldrb	r0, [r4, #14]
d00096aa:	ea42 2303 	orr.w	r3, r2, r3, lsl #8
d00096ae:	7be1      	ldrb	r1, [r4, #15]
d00096b0:	f8df 8198 	ldr.w	r8, [pc, #408]	; d000984c <draw_message.constprop.0+0x1b8>
d00096b4:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d00096b8:	4862      	ldr	r0, [pc, #392]	; (d0009844 <draw_message.constprop.0+0x1b0>)
d00096ba:	4f63      	ldr	r7, [pc, #396]	; (d0009848 <draw_message.constprop.0+0x1b4>)
d00096bc:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00096c0:	f8df a18c 	ldr.w	sl, [pc, #396]	; d0009850 <draw_message.constprop.0+0x1bc>
d00096c4:	681b      	ldr	r3, [r3, #0]
d00096c6:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d00096c8:	4798      	blx	r3
d00096ca:	782b      	ldrb	r3, [r5, #0]
d00096cc:	2b00      	cmp	r3, #0
d00096ce:	f000 809b 	beq.w	d0009808 <draw_message.constprop.0+0x174>
d00096d2:	f8d8 0000 	ldr.w	r0, [r8]
d00096d6:	f894 c00c 	ldrb.w	ip, [r4, #12]
d00096da:	7b61      	ldrb	r1, [r4, #13]
d00096dc:	7ba2      	ldrb	r2, [r4, #14]
d00096de:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d00096e2:	7be3      	ldrb	r3, [r4, #15]
d00096e4:	9001      	str	r0, [sp, #4]
d00096e6:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00096ea:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00096ee:	681b      	ldr	r3, [r3, #0]
d00096f0:	68db      	ldr	r3, [r3, #12]
d00096f2:	4798      	blx	r3
d00096f4:	7b23      	ldrb	r3, [r4, #12]
d00096f6:	7b61      	ldrb	r1, [r4, #13]
d00096f8:	7ba2      	ldrb	r2, [r4, #14]
d00096fa:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
d00096fe:	7be3      	ldrb	r3, [r4, #15]
d0009700:	9801      	ldr	r0, [sp, #4]
d0009702:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009706:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d000970a:	681b      	ldr	r3, [r3, #0]
d000970c:	699b      	ldr	r3, [r3, #24]
d000970e:	4798      	blx	r3
d0009710:	f894 c00c 	ldrb.w	ip, [r4, #12]
d0009714:	7b61      	ldrb	r1, [r4, #13]
d0009716:	2000      	movs	r0, #0
d0009718:	7ba2      	ldrb	r2, [r4, #14]
d000971a:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d000971e:	7be3      	ldrb	r3, [r4, #15]
d0009720:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009724:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009728:	685b      	ldr	r3, [r3, #4]
d000972a:	68db      	ldr	r3, [r3, #12]
d000972c:	4798      	blx	r3
d000972e:	7b20      	ldrb	r0, [r4, #12]
d0009730:	7b61      	ldrb	r1, [r4, #13]
d0009732:	7ba2      	ldrb	r2, [r4, #14]
d0009734:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0009738:	7be3      	ldrb	r3, [r4, #15]
d000973a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000973e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009742:	685b      	ldr	r3, [r3, #4]
d0009744:	681b      	ldr	r3, [r3, #0]
d0009746:	4798      	blx	r3
d0009748:	f894 c00c 	ldrb.w	ip, [r4, #12]
d000974c:	7b61      	ldrb	r1, [r4, #13]
d000974e:	2001      	movs	r0, #1
d0009750:	7ba2      	ldrb	r2, [r4, #14]
d0009752:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d0009756:	7be3      	ldrb	r3, [r4, #15]
d0009758:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000975c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009760:	685b      	ldr	r3, [r3, #4]
d0009762:	68db      	ldr	r3, [r3, #12]
d0009764:	4798      	blx	r3
d0009766:	f894 e00c 	ldrb.w	lr, [r4, #12]
d000976a:	7b60      	ldrb	r0, [r4, #13]
d000976c:	4652      	mov	r2, sl
d000976e:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0009772:	2178      	movs	r1, #120	; 0x78
d0009774:	ea4e 2000 	orr.w	r0, lr, r0, lsl #8
d0009778:	7be3      	ldrb	r3, [r4, #15]
d000977a:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d000977e:	2018      	movs	r0, #24
d0009780:	ea4c 6303 	orr.w	r3, ip, r3, lsl #24
d0009784:	685b      	ldr	r3, [r3, #4]
d0009786:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0009788:	4798      	blx	r3
d000978a:	f894 e00c 	ldrb.w	lr, [r4, #12]
d000978e:	7b60      	ldrb	r0, [r4, #13]
d0009790:	4632      	mov	r2, r6
d0009792:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0009796:	2190      	movs	r1, #144	; 0x90
d0009798:	ea4e 2000 	orr.w	r0, lr, r0, lsl #8
d000979c:	7be3      	ldrb	r3, [r4, #15]
d000979e:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d00097a2:	2018      	movs	r0, #24
d00097a4:	ea4c 6303 	orr.w	r3, ip, r3, lsl #24
d00097a8:	685b      	ldr	r3, [r3, #4]
d00097aa:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d00097ac:	4798      	blx	r3
d00097ae:	782b      	ldrb	r3, [r5, #0]
d00097b0:	f1c3 0301 	rsb	r3, r3, #1
d00097b4:	b2db      	uxtb	r3, r3
d00097b6:	702b      	strb	r3, [r5, #0]
d00097b8:	782b      	ldrb	r3, [r5, #0]
d00097ba:	7b21      	ldrb	r1, [r4, #12]
d00097bc:	7b60      	ldrb	r0, [r4, #13]
d00097be:	7ba2      	ldrb	r2, [r4, #14]
d00097c0:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d00097c4:	b313      	cbz	r3, d000980c <draw_message.constprop.0+0x178>
d00097c6:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d00097ca:	7be3      	ldrb	r3, [r4, #15]
d00097cc:	6839      	ldr	r1, [r7, #0]
d00097ce:	f8d8 0000 	ldr.w	r0, [r8]
d00097d2:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00097d6:	681b      	ldr	r3, [r3, #0]
d00097d8:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d00097da:	4798      	blx	r3
d00097dc:	7b20      	ldrb	r0, [r4, #12]
d00097de:	7b61      	ldrb	r1, [r4, #13]
d00097e0:	7ba2      	ldrb	r2, [r4, #14]
d00097e2:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d00097e6:	7be3      	ldrb	r3, [r4, #15]
d00097e8:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00097ec:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00097f0:	681b      	ldr	r3, [r3, #0]
d00097f2:	681b      	ldr	r3, [r3, #0]
d00097f4:	4798      	blx	r3
d00097f6:	f1b9 0f01 	cmp.w	r9, #1
d00097fa:	d00e      	beq.n	d000981a <draw_message.constprop.0+0x186>
d00097fc:	782b      	ldrb	r3, [r5, #0]
d00097fe:	f04f 0901 	mov.w	r9, #1
d0009802:	2b00      	cmp	r3, #0
d0009804:	f47f af65 	bne.w	d00096d2 <draw_message.constprop.0+0x3e>
d0009808:	6838      	ldr	r0, [r7, #0]
d000980a:	e764      	b.n	d00096d6 <draw_message.constprop.0+0x42>
d000980c:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d0009810:	7be3      	ldrb	r3, [r4, #15]
d0009812:	f8d8 1000 	ldr.w	r1, [r8]
d0009816:	6838      	ldr	r0, [r7, #0]
d0009818:	e7db      	b.n	d00097d2 <draw_message.constprop.0+0x13e>
d000981a:	7b23      	ldrb	r3, [r4, #12]
d000981c:	7b62      	ldrb	r2, [r4, #13]
d000981e:	7ba1      	ldrb	r1, [r4, #14]
d0009820:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009824:	7be2      	ldrb	r2, [r4, #15]
d0009826:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d000982a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d000982e:	681b      	ldr	r3, [r3, #0]
d0009830:	68db      	ldr	r3, [r3, #12]
d0009832:	b002      	add	sp, #8
d0009834:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d0009838:	4718      	bx	r3
d000983a:	bf00      	nop
d000983c:	2001f000 	.word	0x2001f000
d0009840:	d000e80c 	.word	0xd000e80c
d0009844:	d000e810 	.word	0xd000e810
d0009848:	d000f100 	.word	0xd000f100
d000984c:	d000f120 	.word	0xd000f120
d0009850:	d000d67c 	.word	0xd000d67c
d0009854:	00000000 	.word	0x00000000

d0009858 <main>:
d0009858:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d000985c:	f8df b378 	ldr.w	fp, [pc, #888]	; d0009bd8 <main+0x380>
d0009860:	460e      	mov	r6, r1
d0009862:	4605      	mov	r5, r0
d0009864:	2404      	movs	r4, #4
d0009866:	f89b 3004 	ldrb.w	r3, [fp, #4]
d000986a:	f89b 2005 	ldrb.w	r2, [fp, #5]
d000986e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009872:	f89b 2006 	ldrb.w	r2, [fp, #6]
d0009876:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d000987a:	f89b 2007 	ldrb.w	r2, [fp, #7]
d000987e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009882:	ed2d 8b02 	vpush	{d8}
d0009886:	689b      	ldr	r3, [r3, #8]
d0009888:	b0af      	sub	sp, #188	; 0xbc
d000988a:	4798      	blx	r3
d000988c:	f89b 3000 	ldrb.w	r3, [fp]
d0009890:	f89b 2001 	ldrb.w	r2, [fp, #1]
d0009894:	f44f 2000 	mov.w	r0, #524288	; 0x80000
d0009898:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d000989c:	f89b 2002 	ldrb.w	r2, [fp, #2]
d00098a0:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00098a4:	f89b 2003 	ldrb.w	r2, [fp, #3]
d00098a8:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00098ac:	681b      	ldr	r3, [r3, #0]
d00098ae:	4798      	blx	r3
d00098b0:	f7f7 fbd2 	bl	d0001058 <initMalloc>
d00098b4:	4bc0      	ldr	r3, [pc, #768]	; (d0009bb8 <main+0x360>)
d00098b6:	f04f 427f 	mov.w	r2, #4278190080	; 0xff000000
d00098ba:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00098be:	49bf      	ldr	r1, [pc, #764]	; (d0009bbc <main+0x364>)
d00098c0:	601a      	str	r2, [r3, #0]
d00098c2:	461a      	mov	r2, r3
d00098c4:	6058      	str	r0, [r3, #4]
d00098c6:	6099      	str	r1, [r3, #8]
d00098c8:	4bbd      	ldr	r3, [pc, #756]	; (d0009bc0 <main+0x368>)
d00098ca:	f842 3f0c 	str.w	r3, [r2, #12]!
d00098ce:	0423      	lsls	r3, r4, #16
d00098d0:	ea43 2304 	orr.w	r3, r3, r4, lsl #8
d00098d4:	4323      	orrs	r3, r4
d00098d6:	3401      	adds	r4, #1
d00098d8:	f043 437f 	orr.w	r3, r3, #4278190080	; 0xff000000
d00098dc:	f5b4 7f80 	cmp.w	r4, #256	; 0x100
d00098e0:	f842 3f04 	str.w	r3, [r2, #4]!
d00098e4:	d1f3      	bne.n	d00098ce <main+0x76>
d00098e6:	2100      	movs	r1, #0
d00098e8:	f44f 6281 	mov.w	r2, #1032	; 0x408
d00098ec:	48b5      	ldr	r0, [pc, #724]	; (d0009bc4 <main+0x36c>)
d00098ee:	4689      	mov	r9, r1
d00098f0:	f002 f998 	bl	d000bc24 <memset>
d00098f4:	f89b 700c 	ldrb.w	r7, [fp, #12]
d00098f8:	2190      	movs	r1, #144	; 0x90
d00098fa:	f89b 300d 	ldrb.w	r3, [fp, #13]
d00098fe:	20dc      	movs	r0, #220	; 0xdc
d0009900:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009904:	ea47 2703 	orr.w	r7, r7, r3, lsl #8
d0009908:	f89b 300f 	ldrb.w	r3, [fp, #15]
d000990c:	f8df 82cc 	ldr.w	r8, [pc, #716]	; d0009bdc <main+0x384>
d0009910:	ea47 4202 	orr.w	r2, r7, r2, lsl #16
d0009914:	4fac      	ldr	r7, [pc, #688]	; (d0009bc8 <main+0x370>)
d0009916:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d000991a:	681b      	ldr	r3, [r3, #0]
d000991c:	691b      	ldr	r3, [r3, #16]
d000991e:	4798      	blx	r3
d0009920:	f89b 200c 	ldrb.w	r2, [fp, #12]
d0009924:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0009928:	f04f 0c02 	mov.w	ip, #2
d000992c:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0009930:	f44f 73a0 	mov.w	r3, #320	; 0x140
d0009934:	ea42 2200 	orr.w	r2, r2, r0, lsl #8
d0009938:	f89b 000f 	ldrb.w	r0, [fp, #15]
d000993c:	ea42 4101 	orr.w	r1, r2, r1, lsl #16
d0009940:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0009944:	ea41 6000 	orr.w	r0, r1, r0, lsl #24
d0009948:	4619      	mov	r1, r3
d000994a:	f8d0 e000 	ldr.w	lr, [r0]
d000994e:	4610      	mov	r0, r2
d0009950:	f8cd c000 	str.w	ip, [sp]
d0009954:	f8de a014 	ldr.w	sl, [lr, #20]
d0009958:	47d0      	blx	sl
d000995a:	f89b 100c 	ldrb.w	r1, [fp, #12]
d000995e:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009962:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009966:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d000996a:	f89b 300f 	ldrb.w	r3, [fp, #15]
d000996e:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009972:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009976:	681b      	ldr	r3, [r3, #0]
d0009978:	6b5b      	ldr	r3, [r3, #52]	; 0x34
d000997a:	4798      	blx	r3
d000997c:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0009980:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0009984:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0009988:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d000998c:	f89b 100f 	ldrb.w	r1, [fp, #15]
d0009990:	f8c8 0000 	str.w	r0, [r8]
d0009994:	ea43 420c 	orr.w	r2, r3, ip, lsl #16
d0009998:	ea42 6301 	orr.w	r3, r2, r1, lsl #24
d000999c:	681b      	ldr	r3, [r3, #0]
d000999e:	6b9b      	ldr	r3, [r3, #56]	; 0x38
d00099a0:	4798      	blx	r3
d00099a2:	4b8a      	ldr	r3, [pc, #552]	; (d0009bcc <main+0x374>)
d00099a4:	6038      	str	r0, [r7, #0]
d00099a6:	f883 9000 	strb.w	r9, [r3]
d00099aa:	f89b 100c 	ldrb.w	r1, [fp, #12]
d00099ae:	f89b 300d 	ldrb.w	r3, [fp, #13]
d00099b2:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00099b6:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d00099ba:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00099be:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00099c2:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00099c6:	681b      	ldr	r3, [r3, #0]
d00099c8:	6d9b      	ldr	r3, [r3, #88]	; 0x58
d00099ca:	4798      	blx	r3
d00099cc:	f89b 1018 	ldrb.w	r1, [fp, #24]
d00099d0:	f89b 3019 	ldrb.w	r3, [fp, #25]
d00099d4:	f89b 201a 	ldrb.w	r2, [fp, #26]
d00099d8:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d00099dc:	f89b 301b 	ldrb.w	r3, [fp, #27]
d00099e0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00099e4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00099e8:	681b      	ldr	r3, [r3, #0]
d00099ea:	4798      	blx	r3
d00099ec:	f89b 100c 	ldrb.w	r1, [fp, #12]
d00099f0:	f89b 300d 	ldrb.w	r3, [fp, #13]
d00099f4:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00099f8:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d00099fc:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009a00:	486d      	ldr	r0, [pc, #436]	; (d0009bb8 <main+0x360>)
d0009a02:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009a06:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009a0a:	681b      	ldr	r3, [r3, #0]
d0009a0c:	6d1b      	ldr	r3, [r3, #80]	; 0x50
d0009a0e:	4798      	blx	r3
d0009a10:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009a14:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009a18:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009a1c:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009a20:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009a24:	4864      	ldr	r0, [pc, #400]	; (d0009bb8 <main+0x360>)
d0009a26:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009a2a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009a2e:	681b      	ldr	r3, [r3, #0]
d0009a30:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d0009a32:	4798      	blx	r3
d0009a34:	f44f 72a0 	mov.w	r2, #320	; 0x140
d0009a38:	f44f 71f0 	mov.w	r1, #480	; 0x1e0
d0009a3c:	4864      	ldr	r0, [pc, #400]	; (d0009bd0 <main+0x378>)
d0009a3e:	f7f7 fafd 	bl	d000103c <gfx_createBitmap>
d0009a42:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009a46:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009a4a:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009a4e:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009a52:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009a56:	485e      	ldr	r0, [pc, #376]	; (d0009bd0 <main+0x378>)
d0009a58:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009a5c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009a60:	681b      	ldr	r3, [r3, #0]
d0009a62:	6a1b      	ldr	r3, [r3, #32]
d0009a64:	4798      	blx	r3
d0009a66:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009a6a:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009a6e:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009a72:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009a76:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009a7a:	4855      	ldr	r0, [pc, #340]	; (d0009bd0 <main+0x378>)
d0009a7c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009a80:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009a84:	681b      	ldr	r3, [r3, #0]
d0009a86:	699b      	ldr	r3, [r3, #24]
d0009a88:	4798      	blx	r3
d0009a8a:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009a8e:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009a92:	4648      	mov	r0, r9
d0009a94:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009a98:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009a9c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009aa0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009aa4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009aa8:	685b      	ldr	r3, [r3, #4]
d0009aaa:	68db      	ldr	r3, [r3, #12]
d0009aac:	4798      	blx	r3
d0009aae:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009ab2:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009ab6:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009aba:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009abe:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009ac2:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009ac6:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009aca:	685b      	ldr	r3, [r3, #4]
d0009acc:	681b      	ldr	r3, [r3, #0]
d0009ace:	4798      	blx	r3
d0009ad0:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009ad4:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009ad8:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009adc:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009ae0:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009ae4:	f8d8 0000 	ldr.w	r0, [r8]
d0009ae8:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009aec:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009af0:	681b      	ldr	r3, [r3, #0]
d0009af2:	69db      	ldr	r3, [r3, #28]
d0009af4:	4798      	blx	r3
d0009af6:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0009afa:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0009afe:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0009b02:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009b06:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0009b0a:	6838      	ldr	r0, [r7, #0]
d0009b0c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009b10:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009b14:	681b      	ldr	r3, [r3, #0]
d0009b16:	699b      	ldr	r3, [r3, #24]
d0009b18:	4798      	blx	r3
d0009b1a:	2d01      	cmp	r5, #1
d0009b1c:	f340 82ab 	ble.w	d000a076 <main+0x81e>
d0009b20:	4632      	mov	r2, r6
d0009b22:	2301      	movs	r3, #1
d0009b24:	f852 1f04 	ldr.w	r1, [r2, #4]!
d0009b28:	3301      	adds	r3, #1
d0009b2a:	b111      	cbz	r1, d0009b32 <main+0x2da>
d0009b2c:	7808      	ldrb	r0, [r1, #0]
d0009b2e:	2800      	cmp	r0, #0
d0009b30:	d156      	bne.n	d0009be0 <main+0x388>
d0009b32:	429d      	cmp	r5, r3
d0009b34:	d1f6      	bne.n	d0009b24 <main+0x2cc>
d0009b36:	f8d6 a000 	ldr.w	sl, [r6]
d0009b3a:	f1ba 0f00 	cmp.w	sl, #0
d0009b3e:	d033      	beq.n	d0009ba8 <main+0x350>
d0009b40:	212e      	movs	r1, #46	; 0x2e
d0009b42:	4650      	mov	r0, sl
d0009b44:	f002 fda9 	bl	d000c69a <strrchr>
d0009b48:	b370      	cbz	r0, d0009ba8 <main+0x350>
d0009b4a:	7843      	ldrb	r3, [r0, #1]
d0009b4c:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009b50:	2b42      	cmp	r3, #66	; 0x42
d0009b52:	d10a      	bne.n	d0009b6a <main+0x312>
d0009b54:	7883      	ldrb	r3, [r0, #2]
d0009b56:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009b5a:	2b4d      	cmp	r3, #77	; 0x4d
d0009b5c:	d124      	bne.n	d0009ba8 <main+0x350>
d0009b5e:	78c3      	ldrb	r3, [r0, #3]
d0009b60:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009b64:	2b50      	cmp	r3, #80	; 0x50
d0009b66:	d01d      	beq.n	d0009ba4 <main+0x34c>
d0009b68:	e01e      	b.n	d0009ba8 <main+0x350>
d0009b6a:	2b49      	cmp	r3, #73	; 0x49
d0009b6c:	f000 8243 	beq.w	d0009ff6 <main+0x79e>
d0009b70:	2b4c      	cmp	r3, #76	; 0x4c
d0009b72:	d10a      	bne.n	d0009b8a <main+0x332>
d0009b74:	7883      	ldrb	r3, [r0, #2]
d0009b76:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009b7a:	2b42      	cmp	r3, #66	; 0x42
d0009b7c:	d114      	bne.n	d0009ba8 <main+0x350>
d0009b7e:	78c3      	ldrb	r3, [r0, #3]
d0009b80:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009b84:	2b4d      	cmp	r3, #77	; 0x4d
d0009b86:	d10f      	bne.n	d0009ba8 <main+0x350>
d0009b88:	e00c      	b.n	d0009ba4 <main+0x34c>
d0009b8a:	2b47      	cmp	r3, #71	; 0x47
d0009b8c:	f040 824d 	bne.w	d000a02a <main+0x7d2>
d0009b90:	7883      	ldrb	r3, [r0, #2]
d0009b92:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009b96:	2b49      	cmp	r3, #73	; 0x49
d0009b98:	d106      	bne.n	d0009ba8 <main+0x350>
d0009b9a:	78c3      	ldrb	r3, [r0, #3]
d0009b9c:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009ba0:	2b46      	cmp	r3, #70	; 0x46
d0009ba2:	d101      	bne.n	d0009ba8 <main+0x350>
d0009ba4:	7903      	ldrb	r3, [r0, #4]
d0009ba6:	b1e3      	cbz	r3, d0009be2 <main+0x38a>
d0009ba8:	480a      	ldr	r0, [pc, #40]	; (d0009bd4 <main+0x37c>)
d0009baa:	2401      	movs	r4, #1
d0009bac:	f7ff fd72 	bl	d0009694 <draw_message.constprop.0>
d0009bb0:	f7ff fc3a 	bl	d0009428 <wait_for_exit_combo>
d0009bb4:	e199      	b.n	d0009eea <main+0x692>
d0009bb6:	bf00      	nop
d0009bb8:	d000e810 	.word	0xd000e810
d0009bbc:	ff606060 	.word	0xff606060
d0009bc0:	ffdcdcdc 	.word	0xffdcdcdc
d0009bc4:	d000ec10 	.word	0xd000ec10
d0009bc8:	d000f100 	.word	0xd000f100
d0009bcc:	d000e80c 	.word	0xd000e80c
d0009bd0:	d000f0e0 	.word	0xd000f0e0
d0009bd4:	d000d6fc 	.word	0xd000d6fc
d0009bd8:	2001f000 	.word	0x2001f000
d0009bdc:	d000f120 	.word	0xd000f120
d0009be0:	468a      	mov	sl, r1
d0009be2:	48af      	ldr	r0, [pc, #700]	; (d0009ea0 <main+0x648>)
d0009be4:	f7ff fd56 	bl	d0009694 <draw_message.constprop.0>
d0009be8:	f89b 1004 	ldrb.w	r1, [fp, #4]
d0009bec:	f89b 3005 	ldrb.w	r3, [fp, #5]
d0009bf0:	2000      	movs	r0, #0
d0009bf2:	f89b 5006 	ldrb.w	r5, [fp, #6]
d0009bf6:	2201      	movs	r2, #1
d0009bf8:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009bfc:	f89b 3007 	ldrb.w	r3, [fp, #7]
d0009c00:	9023      	str	r0, [sp, #140]	; 0x8c
d0009c02:	ea41 4505 	orr.w	r5, r1, r5, lsl #16
d0009c06:	4651      	mov	r1, sl
d0009c08:	ea45 6303 	orr.w	r3, r5, r3, lsl #24
d0009c0c:	681b      	ldr	r3, [r3, #0]
d0009c0e:	681b      	ldr	r3, [r3, #0]
d0009c10:	4798      	blx	r3
d0009c12:	4605      	mov	r5, r0
d0009c14:	2800      	cmp	r0, #0
d0009c16:	f040 8383 	bne.w	d000a320 <main+0xac8>
d0009c1a:	f89b 1004 	ldrb.w	r1, [fp, #4]
d0009c1e:	f89b 3005 	ldrb.w	r3, [fp, #5]
d0009c22:	f89b 2006 	ldrb.w	r2, [fp, #6]
d0009c26:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d0009c2a:	f89b 3007 	ldrb.w	r3, [fp, #7]
d0009c2e:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0009c32:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0009c36:	681b      	ldr	r3, [r3, #0]
d0009c38:	685b      	ldr	r3, [r3, #4]
d0009c3a:	4798      	blx	r3
d0009c3c:	4606      	mov	r6, r0
d0009c3e:	2800      	cmp	r0, #0
d0009c40:	f000 81c4 	beq.w	d0009fcc <main+0x774>
d0009c44:	f001 ffc2 	bl	d000bbcc <malloc>
d0009c48:	4681      	mov	r9, r0
d0009c4a:	2800      	cmp	r0, #0
d0009c4c:	f001 842f 	beq.w	d000b4ae <main+0x1c56>
d0009c50:	f89b 1004 	ldrb.w	r1, [fp, #4]
d0009c54:	4632      	mov	r2, r6
d0009c56:	f89b 0005 	ldrb.w	r0, [fp, #5]
d0009c5a:	ab23      	add	r3, sp, #140	; 0x8c
d0009c5c:	f89b 7006 	ldrb.w	r7, [fp, #6]
d0009c60:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d0009c64:	f89b c007 	ldrb.w	ip, [fp, #7]
d0009c68:	4649      	mov	r1, r9
d0009c6a:	ea40 4707 	orr.w	r7, r0, r7, lsl #16
d0009c6e:	4628      	mov	r0, r5
d0009c70:	ea47 670c 	orr.w	r7, r7, ip, lsl #24
d0009c74:	683f      	ldr	r7, [r7, #0]
d0009c76:	68bf      	ldr	r7, [r7, #8]
d0009c78:	47b8      	blx	r7
d0009c7a:	f89b 2004 	ldrb.w	r2, [fp, #4]
d0009c7e:	4603      	mov	r3, r0
d0009c80:	f89b 1005 	ldrb.w	r1, [fp, #5]
d0009c84:	4628      	mov	r0, r5
d0009c86:	ea42 2201 	orr.w	r2, r2, r1, lsl #8
d0009c8a:	461d      	mov	r5, r3
d0009c8c:	9306      	str	r3, [sp, #24]
d0009c8e:	f89b 3006 	ldrb.w	r3, [fp, #6]
d0009c92:	f89b 1007 	ldrb.w	r1, [fp, #7]
d0009c96:	ea42 4303 	orr.w	r3, r2, r3, lsl #16
d0009c9a:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d0009c9e:	681b      	ldr	r3, [r3, #0]
d0009ca0:	68db      	ldr	r3, [r3, #12]
d0009ca2:	4798      	blx	r3
d0009ca4:	2d00      	cmp	r5, #0
d0009ca6:	f040 81d9 	bne.w	d000a05c <main+0x804>
d0009caa:	9b23      	ldr	r3, [sp, #140]	; 0x8c
d0009cac:	429e      	cmp	r6, r3
d0009cae:	f040 81d5 	bne.w	d000a05c <main+0x804>
d0009cb2:	f44f 6281 	mov.w	r2, #1032	; 0x408
d0009cb6:	9906      	ldr	r1, [sp, #24]
d0009cb8:	487a      	ldr	r0, [pc, #488]	; (d0009ea4 <main+0x64c>)
d0009cba:	f001 ffb3 	bl	d000bc24 <memset>
d0009cbe:	2e01      	cmp	r6, #1
d0009cc0:	f240 8105 	bls.w	d0009ece <main+0x676>
d0009cc4:	f899 5000 	ldrb.w	r5, [r9]
d0009cc8:	2d42      	cmp	r5, #66	; 0x42
d0009cca:	f000 81d7 	beq.w	d000a07c <main+0x824>
d0009cce:	2e0b      	cmp	r6, #11
d0009cd0:	f240 80f0 	bls.w	d0009eb4 <main+0x65c>
d0009cd4:	f8d9 2000 	ldr.w	r2, [r9]
d0009cd8:	4b73      	ldr	r3, [pc, #460]	; (d0009ea8 <main+0x650>)
d0009cda:	429a      	cmp	r2, r3
d0009cdc:	f000 832c 	beq.w	d000a338 <main+0xae0>
d0009ce0:	2203      	movs	r2, #3
d0009ce2:	4972      	ldr	r1, [pc, #456]	; (d0009eac <main+0x654>)
d0009ce4:	4648      	mov	r0, r9
d0009ce6:	f001 ff81 	bl	d000bbec <memcmp>
d0009cea:	2800      	cmp	r0, #0
d0009cec:	f040 80ec 	bne.w	d0009ec8 <main+0x670>
d0009cf0:	2e0c      	cmp	r6, #12
d0009cf2:	f000 839d 	beq.w	d000a430 <main+0xbd8>
d0009cf6:	f109 0403 	add.w	r4, r9, #3
d0009cfa:	2203      	movs	r2, #3
d0009cfc:	496c      	ldr	r1, [pc, #432]	; (d0009eb0 <main+0x658>)
d0009cfe:	4620      	mov	r0, r4
d0009d00:	f001 ff74 	bl	d000bbec <memcmp>
d0009d04:	2800      	cmp	r0, #0
d0009d06:	f040 838b 	bne.w	d000a420 <main+0xbc8>
d0009d0a:	f899 3009 	ldrb.w	r3, [r9, #9]
d0009d0e:	f640 72ff 	movw	r2, #4095	; 0xfff
d0009d12:	f899 0008 	ldrb.w	r0, [r9, #8]
d0009d16:	f899 1007 	ldrb.w	r1, [r9, #7]
d0009d1a:	ea40 2003 	orr.w	r0, r0, r3, lsl #8
d0009d1e:	f899 8006 	ldrb.w	r8, [r9, #6]
d0009d22:	1e43      	subs	r3, r0, #1
d0009d24:	ea48 2101 	orr.w	r1, r8, r1, lsl #8
d0009d28:	9004      	str	r0, [sp, #16]
d0009d2a:	b29b      	uxth	r3, r3
d0009d2c:	9103      	str	r1, [sp, #12]
d0009d2e:	4293      	cmp	r3, r2
d0009d30:	f200 83d0 	bhi.w	d000a4d4 <main+0xc7c>
d0009d34:	1e4b      	subs	r3, r1, #1
d0009d36:	b29b      	uxth	r3, r3
d0009d38:	4293      	cmp	r3, r2
d0009d3a:	f200 83cb 	bhi.w	d000a4d4 <main+0xc7c>
d0009d3e:	fba1 2300 	umull	r2, r3, r1, r0
d0009d42:	a155      	add	r1, pc, #340	; (adr r1, d0009e98 <main+0x640>)
d0009d44:	e9d1 0100 	ldrd	r0, r1, [r1]
d0009d48:	4299      	cmp	r1, r3
d0009d4a:	bf08      	it	eq
d0009d4c:	4290      	cmpeq	r0, r2
d0009d4e:	f0c0 83c1 	bcc.w	d000a4d4 <main+0xc7c>
d0009d52:	f8df 8150 	ldr.w	r8, [pc, #336]	; d0009ea4 <main+0x64c>
d0009d56:	f899 200b 	ldrb.w	r2, [r9, #11]
d0009d5a:	f108 0308 	add.w	r3, r8, #8
d0009d5e:	f018 0f04 	tst.w	r8, #4
d0009d62:	f899 400a 	ldrb.w	r4, [r9, #10]
d0009d66:	ee08 2a10 	vmov	s16, r2
d0009d6a:	9305      	str	r3, [sp, #20]
d0009d6c:	f3c8 0380 	ubfx	r3, r8, #2, #1
d0009d70:	d003      	beq.n	d0009d7a <main+0x522>
d0009d72:	f04f 427f 	mov.w	r2, #4278190080	; 0xff000000
d0009d76:	f8c8 2008 	str.w	r2, [r8, #8]
d0009d7a:	f5c3 7780 	rsb	r7, r3, #256	; 0x100
d0009d7e:	1c9a      	adds	r2, r3, #2
d0009d80:	f04f 407f 	mov.w	r0, #4278190080	; 0xff000000
d0009d84:	f04f 417f 	mov.w	r1, #4278190080	; 0xff000000
d0009d88:	f3c7 054e 	ubfx	r5, r7, #1, #15
d0009d8c:	eb08 0282 	add.w	r2, r8, r2, lsl #2
d0009d90:	b2bf      	uxth	r7, r7
d0009d92:	eb02 05c5 	add.w	r5, r2, r5, lsl #3
d0009d96:	e8e2 0102 	strd	r0, r1, [r2], #8
d0009d9a:	42aa      	cmp	r2, r5
d0009d9c:	d1fb      	bne.n	d0009d96 <main+0x53e>
d0009d9e:	f027 0201 	bic.w	r2, r7, #1
d0009da2:	4413      	add	r3, r2
d0009da4:	42ba      	cmp	r2, r7
d0009da6:	b29b      	uxth	r3, r3
d0009da8:	d004      	beq.n	d0009db4 <main+0x55c>
d0009daa:	3302      	adds	r3, #2
d0009dac:	f04f 427f 	mov.w	r2, #4278190080	; 0xff000000
d0009db0:	f848 2023 	str.w	r2, [r8, r3, lsl #2]
d0009db4:	0622      	lsls	r2, r4, #24
d0009db6:	f140 8519 	bpl.w	d000a7ec <main+0xf94>
d0009dba:	f004 0307 	and.w	r3, r4, #7
d0009dbe:	2701      	movs	r7, #1
d0009dc0:	2403      	movs	r4, #3
d0009dc2:	443b      	add	r3, r7
d0009dc4:	409c      	lsls	r4, r3
d0009dc6:	fa07 f303 	lsl.w	r3, r7, r3
d0009dca:	340d      	adds	r4, #13
d0009dcc:	fa1f fe83 	uxth.w	lr, r3
d0009dd0:	42a6      	cmp	r6, r4
d0009dd2:	f0c1 830b 	bcc.w	d000b3ec <main+0x1b94>
d0009dd6:	464a      	mov	r2, r9
d0009dd8:	f8dd c014 	ldr.w	ip, [sp, #20]
d0009ddc:	e001      	b.n	d0009de2 <main+0x58a>
d0009dde:	29ff      	cmp	r1, #255	; 0xff
d0009de0:	d811      	bhi.n	d0009e06 <main+0x5ae>
d0009de2:	7b93      	ldrb	r3, [r2, #14]
d0009de4:	b2b9      	uxth	r1, r7
d0009de6:	7b55      	ldrb	r5, [r2, #13]
d0009de8:	3701      	adds	r7, #1
d0009dea:	021b      	lsls	r3, r3, #8
d0009dec:	7bd0      	ldrb	r0, [r2, #15]
d0009dee:	458e      	cmp	lr, r1
d0009df0:	f102 0203 	add.w	r2, r2, #3
d0009df4:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0009df8:	ea43 0300 	orr.w	r3, r3, r0
d0009dfc:	f043 437f 	orr.w	r3, r3, #4278190080	; 0xff000000
d0009e00:	f84c 3b04 	str.w	r3, [ip], #4
d0009e04:	d8eb      	bhi.n	d0009dde <main+0x586>
d0009e06:	9b04      	ldr	r3, [sp, #16]
d0009e08:	9903      	ldr	r1, [sp, #12]
d0009e0a:	f8a8 3002 	strh.w	r3, [r8, #2]
d0009e0e:	fb03 f201 	mul.w	r2, r3, r1
d0009e12:	f8a8 1000 	strh.w	r1, [r8]
d0009e16:	4610      	mov	r0, r2
d0009e18:	9207      	str	r2, [sp, #28]
d0009e1a:	f001 fed7 	bl	d000bbcc <malloc>
d0009e1e:	9a07      	ldr	r2, [sp, #28]
d0009e20:	f8c8 0004 	str.w	r0, [r8, #4]
d0009e24:	2800      	cmp	r0, #0
d0009e26:	f001 836c 	beq.w	d000b502 <main+0x1caa>
d0009e2a:	ee18 1a10 	vmov	r1, s16
d0009e2e:	f001 fef9 	bl	d000bc24 <memset>
d0009e32:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0009e36:	42a6      	cmp	r6, r4
d0009e38:	f241 8377 	bls.w	d000b52a <main+0x1cd2>
d0009e3c:	f819 3004 	ldrb.w	r3, [r9, r4]
d0009e40:	1c62      	adds	r2, r4, #1
d0009e42:	eb09 0e04 	add.w	lr, r9, r4
d0009e46:	2b3b      	cmp	r3, #59	; 0x3b
d0009e48:	f001 8365 	beq.w	d000b516 <main+0x1cbe>
d0009e4c:	2b21      	cmp	r3, #33	; 0x21
d0009e4e:	f041 8376 	bne.w	d000b53e <main+0x1ce6>
d0009e52:	4296      	cmp	r6, r2
d0009e54:	f240 84bc 	bls.w	d000a7d0 <main+0xf78>
d0009e58:	f819 2002 	ldrb.w	r2, [r9, r2]
d0009e5c:	1ca3      	adds	r3, r4, #2
d0009e5e:	2af9      	cmp	r2, #249	; 0xf9
d0009e60:	f040 84b2 	bne.w	d000a7c8 <main+0xf70>
d0009e64:	f104 0108 	add.w	r1, r4, #8
d0009e68:	428e      	cmp	r6, r1
d0009e6a:	f0c1 8340 	bcc.w	d000b4ee <main+0x1c96>
d0009e6e:	f819 2003 	ldrb.w	r2, [r9, r3]
d0009e72:	1ce3      	adds	r3, r4, #3
d0009e74:	2a04      	cmp	r2, #4
d0009e76:	f041 8330 	bne.w	d000b4da <main+0x1c82>
d0009e7a:	f819 3003 	ldrb.w	r3, [r9, r3]
d0009e7e:	3407      	adds	r4, #7
d0009e80:	07db      	lsls	r3, r3, #31
d0009e82:	f100 84af 	bmi.w	d000a7e4 <main+0xf8c>
d0009e86:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0009e8a:	f819 3004 	ldrb.w	r3, [r9, r4]
d0009e8e:	2b00      	cmp	r3, #0
d0009e90:	f041 82a2 	bne.w	d000b3d8 <main+0x1b80>
d0009e94:	460c      	mov	r4, r1
d0009e96:	e7ce      	b.n	d0009e36 <main+0x5de>
d0009e98:	004c4b40 	.word	0x004c4b40
d0009e9c:	00000000 	.word	0x00000000
d0009ea0:	d000dd60 	.word	0xd000dd60
d0009ea4:	d000ec10 	.word	0xd000ec10
d0009ea8:	4d524f46 	.word	0x4d524f46
d0009eac:	d000da30 	.word	0xd000da30
d0009eb0:	d000da34 	.word	0xd000da34
d0009eb4:	2e05      	cmp	r6, #5
d0009eb6:	d907      	bls.n	d0009ec8 <main+0x670>
d0009eb8:	2203      	movs	r2, #3
d0009eba:	49d3      	ldr	r1, [pc, #844]	; (d000a208 <main+0x9b0>)
d0009ebc:	4648      	mov	r0, r9
d0009ebe:	f001 fe95 	bl	d000bbec <memcmp>
d0009ec2:	2800      	cmp	r0, #0
d0009ec4:	f000 82b4 	beq.w	d000a430 <main+0xbd8>
d0009ec8:	2dff      	cmp	r5, #255	; 0xff
d0009eca:	f000 81f8 	beq.w	d000a2be <main+0xa66>
d0009ece:	48cf      	ldr	r0, [pc, #828]	; (d000a20c <main+0x9b4>)
d0009ed0:	f7ff fae8 	bl	d00094a4 <set_status>
d0009ed4:	4648      	mov	r0, r9
d0009ed6:	f001 fe81 	bl	d000bbdc <free>
d0009eda:	f7ff fbcb 	bl	d0009674 <free_image.constprop.0>
d0009ede:	48cc      	ldr	r0, [pc, #816]	; (d000a210 <main+0x9b8>)
d0009ee0:	2401      	movs	r4, #1
d0009ee2:	f7ff fbd7 	bl	d0009694 <draw_message.constprop.0>
d0009ee6:	f7ff fa9f 	bl	d0009428 <wait_for_exit_combo>
d0009eea:	4dca      	ldr	r5, [pc, #808]	; (d000a214 <main+0x9bc>)
d0009eec:	f7ff fbc2 	bl	d0009674 <free_image.constprop.0>
d0009ef0:	682b      	ldr	r3, [r5, #0]
d0009ef2:	b13b      	cbz	r3, d0009f04 <main+0x6ac>
d0009ef4:	6828      	ldr	r0, [r5, #0]
d0009ef6:	f001 fe71 	bl	d000bbdc <free>
d0009efa:	4628      	mov	r0, r5
d0009efc:	2220      	movs	r2, #32
d0009efe:	2100      	movs	r1, #0
d0009f00:	f001 fe90 	bl	d000bc24 <memset>
d0009f04:	48c4      	ldr	r0, [pc, #784]	; (d000a218 <main+0x9c0>)
d0009f06:	2602      	movs	r6, #2
d0009f08:	f002 faaa 	bl	d000c460 <puts>
d0009f0c:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0009f10:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0009f14:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0009f18:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009f1c:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0009f20:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009f24:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009f28:	681b      	ldr	r3, [r3, #0]
d0009f2a:	68db      	ldr	r3, [r3, #12]
d0009f2c:	4798      	blx	r3
d0009f2e:	f89b 500c 	ldrb.w	r5, [fp, #12]
d0009f32:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0009f36:	f44f 73a0 	mov.w	r3, #320	; 0x140
d0009f3a:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0009f3e:	ea45 2502 	orr.w	r5, r5, r2, lsl #8
d0009f42:	f89b 000f 	ldrb.w	r0, [fp, #15]
d0009f46:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0009f4a:	ea45 4501 	orr.w	r5, r5, r1, lsl #16
d0009f4e:	4619      	mov	r1, r3
d0009f50:	ea45 6500 	orr.w	r5, r5, r0, lsl #24
d0009f54:	4610      	mov	r0, r2
d0009f56:	682d      	ldr	r5, [r5, #0]
d0009f58:	9600      	str	r6, [sp, #0]
d0009f5a:	696d      	ldr	r5, [r5, #20]
d0009f5c:	47a8      	blx	r5
d0009f5e:	f89b 3004 	ldrb.w	r3, [fp, #4]
d0009f62:	f89b 2005 	ldrb.w	r2, [fp, #5]
d0009f66:	f89b 1006 	ldrb.w	r1, [fp, #6]
d0009f6a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009f6e:	f89b 2007 	ldrb.w	r2, [fp, #7]
d0009f72:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009f76:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009f7a:	685b      	ldr	r3, [r3, #4]
d0009f7c:	4798      	blx	r3
d0009f7e:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0009f82:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0009f86:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0009f8a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009f8e:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0009f92:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009f96:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009f9a:	681b      	ldr	r3, [r3, #0]
d0009f9c:	68db      	ldr	r3, [r3, #12]
d0009f9e:	4798      	blx	r3
d0009fa0:	f89b 3000 	ldrb.w	r3, [fp]
d0009fa4:	f89b 2001 	ldrb.w	r2, [fp, #1]
d0009fa8:	f89b 1002 	ldrb.w	r1, [fp, #2]
d0009fac:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009fb0:	f89b 2003 	ldrb.w	r2, [fp, #3]
d0009fb4:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009fb8:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009fbc:	685b      	ldr	r3, [r3, #4]
d0009fbe:	4798      	blx	r3
d0009fc0:	4620      	mov	r0, r4
d0009fc2:	b02f      	add	sp, #188	; 0xbc
d0009fc4:	ecbd 8b02 	vpop	{d8}
d0009fc8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0009fcc:	f89b 3004 	ldrb.w	r3, [fp, #4]
d0009fd0:	f89b 2005 	ldrb.w	r2, [fp, #5]
d0009fd4:	f89b 1006 	ldrb.w	r1, [fp, #6]
d0009fd8:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0009fdc:	f89b 2007 	ldrb.w	r2, [fp, #7]
d0009fe0:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0009fe4:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0009fe8:	681b      	ldr	r3, [r3, #0]
d0009fea:	68db      	ldr	r3, [r3, #12]
d0009fec:	4798      	blx	r3
d0009fee:	488b      	ldr	r0, [pc, #556]	; (d000a21c <main+0x9c4>)
d0009ff0:	f7ff fa58 	bl	d00094a4 <set_status>
d0009ff4:	e773      	b.n	d0009ede <main+0x686>
d0009ff6:	7883      	ldrb	r3, [r0, #2]
d0009ff8:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d0009ffc:	2b46      	cmp	r3, #70	; 0x46
d0009ffe:	f43f adcc 	beq.w	d0009b9a <main+0x342>
d000a002:	2b4c      	cmp	r3, #76	; 0x4c
d000a004:	f47f add0 	bne.w	d0009ba8 <main+0x350>
d000a008:	78c3      	ldrb	r3, [r0, #3]
d000a00a:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d000a00e:	2b42      	cmp	r3, #66	; 0x42
d000a010:	f47f adca 	bne.w	d0009ba8 <main+0x350>
d000a014:	7903      	ldrb	r3, [r0, #4]
d000a016:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d000a01a:	2b4d      	cmp	r3, #77	; 0x4d
d000a01c:	f47f adc4 	bne.w	d0009ba8 <main+0x350>
d000a020:	7943      	ldrb	r3, [r0, #5]
d000a022:	2b00      	cmp	r3, #0
d000a024:	f43f addd 	beq.w	d0009be2 <main+0x38a>
d000a028:	e5be      	b.n	d0009ba8 <main+0x350>
d000a02a:	2b4a      	cmp	r3, #74	; 0x4a
d000a02c:	f47f adbc 	bne.w	d0009ba8 <main+0x350>
d000a030:	7883      	ldrb	r3, [r0, #2]
d000a032:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d000a036:	2b50      	cmp	r3, #80	; 0x50
d000a038:	f47f adb6 	bne.w	d0009ba8 <main+0x350>
d000a03c:	78c3      	ldrb	r3, [r0, #3]
d000a03e:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d000a042:	2b47      	cmp	r3, #71	; 0x47
d000a044:	f43f adae 	beq.w	d0009ba4 <main+0x34c>
d000a048:	2b45      	cmp	r3, #69	; 0x45
d000a04a:	f47f adad 	bne.w	d0009ba8 <main+0x350>
d000a04e:	7903      	ldrb	r3, [r0, #4]
d000a050:	f003 03df 	and.w	r3, r3, #223	; 0xdf
d000a054:	2b47      	cmp	r3, #71	; 0x47
d000a056:	f47f ada7 	bne.w	d0009ba8 <main+0x350>
d000a05a:	e7e1      	b.n	d000a020 <main+0x7c8>
d000a05c:	4648      	mov	r0, r9
d000a05e:	f001 fdbd 	bl	d000bbdc <free>
d000a062:	9b06      	ldr	r3, [sp, #24]
d000a064:	4a6e      	ldr	r2, [pc, #440]	; (d000a220 <main+0x9c8>)
d000a066:	21a0      	movs	r1, #160	; 0xa0
d000a068:	4869      	ldr	r0, [pc, #420]	; (d000a210 <main+0x9b8>)
d000a06a:	f002 facf 	bl	d000c60c <sniprintf>
d000a06e:	4868      	ldr	r0, [pc, #416]	; (d000a210 <main+0x9b8>)
d000a070:	f7ff fa18 	bl	d00094a4 <set_status>
d000a074:	e733      	b.n	d0009ede <main+0x686>
d000a076:	f47f ad97 	bne.w	d0009ba8 <main+0x350>
d000a07a:	e55c      	b.n	d0009b36 <main+0x2de>
d000a07c:	f899 3001 	ldrb.w	r3, [r9, #1]
d000a080:	2b4d      	cmp	r3, #77	; 0x4d
d000a082:	f47f ae24 	bne.w	d0009cce <main+0x476>
d000a086:	2e35      	cmp	r6, #53	; 0x35
d000a088:	f240 821b 	bls.w	d000a4c2 <main+0xc6a>
d000a08c:	f8b9 400e 	ldrh.w	r4, [r9, #14]
d000a090:	f8b9 3010 	ldrh.w	r3, [r9, #16]
d000a094:	ea44 4403 	orr.w	r4, r4, r3, lsl #16
d000a098:	2c27      	cmp	r4, #39	; 0x27
d000a09a:	f240 83c0 	bls.w	d000a81e <main+0xfc6>
d000a09e:	f104 0c0e 	add.w	ip, r4, #14
d000a0a2:	4566      	cmp	r6, ip
d000a0a4:	f0c0 83bb 	bcc.w	d000a81e <main+0xfc6>
d000a0a8:	f8b9 2012 	ldrh.w	r2, [r9, #18]
d000a0ac:	f8b9 3014 	ldrh.w	r3, [r9, #20]
d000a0b0:	f8b9 8016 	ldrh.w	r8, [r9, #22]
d000a0b4:	ea42 4103 	orr.w	r1, r2, r3, lsl #16
d000a0b8:	f8b9 3018 	ldrh.w	r3, [r9, #24]
d000a0bc:	2900      	cmp	r1, #0
d000a0be:	ea48 4203 	orr.w	r2, r8, r3, lsl #16
d000a0c2:	9104      	str	r1, [sp, #16]
d000a0c4:	9203      	str	r2, [sp, #12]
d000a0c6:	f340 83a0 	ble.w	d000a80a <main+0xfb2>
d000a0ca:	fab2 f382 	clz	r3, r2
d000a0ce:	095b      	lsrs	r3, r3, #5
d000a0d0:	2a00      	cmp	r2, #0
d000a0d2:	f000 839a 	beq.w	d000a80a <main+0xfb2>
d000a0d6:	9a03      	ldr	r2, [sp, #12]
d000a0d8:	2a00      	cmp	r2, #0
d000a0da:	f2c1 81cd 	blt.w	d000b478 <main+0x1c20>
d000a0de:	9307      	str	r3, [sp, #28]
d000a0e0:	9b04      	ldr	r3, [sp, #16]
d000a0e2:	f5b3 5f80 	cmp.w	r3, #4096	; 0x1000
d000a0e6:	f201 81bd 	bhi.w	d000b464 <main+0x1c0c>
d000a0ea:	9a03      	ldr	r2, [sp, #12]
d000a0ec:	f5b2 5f80 	cmp.w	r2, #4096	; 0x1000
d000a0f0:	f201 81b8 	bhi.w	d000b464 <main+0x1c0c>
d000a0f4:	fba3 2302 	umull	r2, r3, r3, r2
d000a0f8:	a141      	add	r1, pc, #260	; (adr r1, d000a200 <main+0x9a8>)
d000a0fa:	e9d1 0100 	ldrd	r0, r1, [r1]
d000a0fe:	4299      	cmp	r1, r3
d000a100:	bf08      	it	eq
d000a102:	4290      	cmpeq	r0, r2
d000a104:	f0c1 81ae 	bcc.w	d000b464 <main+0x1c0c>
d000a108:	f8b9 300a 	ldrh.w	r3, [r9, #10]
d000a10c:	f8b9 200c 	ldrh.w	r2, [r9, #12]
d000a110:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d000a114:	429e      	cmp	r6, r3
d000a116:	9308      	str	r3, [sp, #32]
d000a118:	f241 8186 	bls.w	d000b428 <main+0x1bd0>
d000a11c:	f8b9 201e 	ldrh.w	r2, [r9, #30]
d000a120:	f8b9 3020 	ldrh.w	r3, [r9, #32]
d000a124:	ea52 4203 	orrs.w	r2, r2, r3, lsl #16
d000a128:	d002      	beq.n	d000a130 <main+0x8d8>
d000a12a:	2a03      	cmp	r2, #3
d000a12c:	f041 8172 	bne.w	d000b414 <main+0x1bbc>
d000a130:	f899 301d 	ldrb.w	r3, [r9, #29]
d000a134:	f899 001c 	ldrb.w	r0, [r9, #28]
d000a138:	ea40 2003 	orr.w	r0, r0, r3, lsl #8
d000a13c:	4605      	mov	r5, r0
d000a13e:	9005      	str	r0, [sp, #20]
d000a140:	b200      	sxth	r0, r0
d000a142:	2d08      	cmp	r5, #8
d000a144:	f201 811b 	bhi.w	d000b37e <main+0x1b26>
d000a148:	f8b9 302e 	ldrh.w	r3, [r9, #46]	; 0x2e
d000a14c:	f8b9 1030 	ldrh.w	r1, [r9, #48]	; 0x30
d000a150:	ea53 4301 	orrs.w	r3, r3, r1, lsl #16
d000a154:	d101      	bne.n	d000a15a <main+0x902>
d000a156:	2301      	movs	r3, #1
d000a158:	40ab      	lsls	r3, r5
d000a15a:	f5b3 7f80 	cmp.w	r3, #256	; 0x100
d000a15e:	bf28      	it	cs
d000a160:	f44f 7380 	movcs.w	r3, #256	; 0x100
d000a164:	eb0c 0183 	add.w	r1, ip, r3, lsl #2
d000a168:	428e      	cmp	r6, r1
d000a16a:	f0c1 8117 	bcc.w	d000b39c <main+0x1b44>
d000a16e:	2a03      	cmp	r2, #3
d000a170:	f001 810d 	beq.w	d000b38e <main+0x1b36>
d000a174:	9a05      	ldr	r2, [sp, #20]
d000a176:	2a20      	cmp	r2, #32
d000a178:	bf0b      	itete	eq
d000a17a:	24ff      	moveq	r4, #255	; 0xff
d000a17c:	241f      	movne	r4, #31
d000a17e:	f44f 457f 	moveq.w	r5, #65280	; 0xff00
d000a182:	f44f 7578 	movne.w	r5, #992	; 0x3e0
d000a186:	bf0c      	ite	eq
d000a188:	f44f 077f 	moveq.w	r7, #16711680	; 0xff0000
d000a18c:	f44f 47f8 	movne.w	r7, #31744	; 0x7c00
d000a190:	9905      	ldr	r1, [sp, #20]
d000a192:	9a04      	ldr	r2, [sp, #16]
d000a194:	fb02 f201 	mul.w	r2, r2, r1
d000a198:	9903      	ldr	r1, [sp, #12]
d000a19a:	321f      	adds	r2, #31
d000a19c:	468e      	mov	lr, r1
d000a19e:	9908      	ldr	r1, [sp, #32]
d000a1a0:	0952      	lsrs	r2, r2, #5
d000a1a2:	0092      	lsls	r2, r2, #2
d000a1a4:	9209      	str	r2, [sp, #36]	; 0x24
d000a1a6:	fb02 120e 	mla	r2, r2, lr, r1
d000a1aa:	4296      	cmp	r6, r2
d000a1ac:	f0c1 8100 	bcc.w	d000b3b0 <main+0x1b58>
d000a1b0:	f8df 8070 	ldr.w	r8, [pc, #112]	; d000a224 <main+0x9cc>
d000a1b4:	9a04      	ldr	r2, [sp, #16]
d000a1b6:	f8a8 2000 	strh.w	r2, [r8]
d000a1ba:	9a03      	ldr	r2, [sp, #12]
d000a1bc:	f8a8 2002 	strh.w	r2, [r8, #2]
d000a1c0:	9a05      	ldr	r2, [sp, #20]
d000a1c2:	2a08      	cmp	r2, #8
d000a1c4:	f200 85f6 	bhi.w	d000adb4 <main+0x155c>
d000a1c8:	eb09 010c 	add.w	r1, r9, ip
d000a1cc:	f108 0008 	add.w	r0, r8, #8
d000a1d0:	eb01 0683 	add.w	r6, r1, r3, lsl #2
d000a1d4:	e00b      	b.n	d000a1ee <main+0x996>
d000a1d6:	784a      	ldrb	r2, [r1, #1]
d000a1d8:	788d      	ldrb	r5, [r1, #2]
d000a1da:	0212      	lsls	r2, r2, #8
d000a1dc:	f811 4b04 	ldrb.w	r4, [r1], #4
d000a1e0:	ea42 4205 	orr.w	r2, r2, r5, lsl #16
d000a1e4:	4322      	orrs	r2, r4
d000a1e6:	f042 427f 	orr.w	r2, r2, #4278190080	; 0xff000000
d000a1ea:	f840 2b04 	str.w	r2, [r0], #4
d000a1ee:	428e      	cmp	r6, r1
d000a1f0:	d1f1      	bne.n	d000a1d6 <main+0x97e>
d000a1f2:	3301      	adds	r3, #1
d000a1f4:	f04f 427f 	mov.w	r2, #4278190080	; 0xff000000
d000a1f8:	e018      	b.n	d000a22c <main+0x9d4>
d000a1fa:	bf00      	nop
d000a1fc:	f3af 8000 	nop.w
d000a200:	004c4b40 	.word	0x004c4b40
d000a204:	00000000 	.word	0x00000000
d000a208:	d000da30 	.word	0xd000da30
d000a20c:	d000dcf4 	.word	0xd000dcf4
d000a210:	d000f018 	.word	0xd000f018
d000a214:	d000f0e0 	.word	0xd000f0e0
d000a218:	d000dd20 	.word	0xd000dd20
d000a21c:	d000d73c 	.word	0xd000d73c
d000a220:	d000d768 	.word	0xd000d768
d000a224:	d000ec10 	.word	0xd000ec10
d000a228:	f848 2023 	str.w	r2, [r8, r3, lsl #2]
d000a22c:	3301      	adds	r3, #1
d000a22e:	f5b3 7f81 	cmp.w	r3, #258	; 0x102
d000a232:	d1f9      	bne.n	d000a228 <main+0x9d0>
d000a234:	9b03      	ldr	r3, [sp, #12]
d000a236:	9a04      	ldr	r2, [sp, #16]
d000a238:	fb03 f002 	mul.w	r0, r3, r2
d000a23c:	f001 fcc6 	bl	d000bbcc <malloc>
d000a240:	f8c8 0004 	str.w	r0, [r8, #4]
d000a244:	2800      	cmp	r0, #0
d000a246:	f001 845d 	beq.w	d000bb04 <main+0x22ac>
d000a24a:	9b05      	ldr	r3, [sp, #20]
d000a24c:	2b08      	cmp	r3, #8
d000a24e:	f001 843c 	beq.w	d000baca <main+0x2272>
d000a252:	9b05      	ldr	r3, [sp, #20]
d000a254:	2b04      	cmp	r3, #4
d000a256:	f001 840f 	beq.w	d000ba78 <main+0x2220>
d000a25a:	9b05      	ldr	r3, [sp, #20]
d000a25c:	2b01      	cmp	r3, #1
d000a25e:	f041 80b1 	bne.w	d000b3c4 <main+0x1b6c>
d000a262:	2400      	movs	r4, #0
d000a264:	9b03      	ldr	r3, [sp, #12]
d000a266:	f04f 0c80 	mov.w	ip, #128	; 0x80
d000a26a:	9d04      	ldr	r5, [sp, #16]
d000a26c:	1e5f      	subs	r7, r3, #1
d000a26e:	4621      	mov	r1, r4
d000a270:	9b03      	ldr	r3, [sp, #12]
d000a272:	428b      	cmp	r3, r1
d000a274:	f000 86df 	beq.w	d000b036 <main+0x17de>
d000a278:	9b07      	ldr	r3, [sp, #28]
d000a27a:	2b00      	cmp	r3, #0
d000a27c:	f041 83f9 	bne.w	d000ba72 <main+0x221a>
d000a280:	1a7b      	subs	r3, r7, r1
d000a282:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000a284:	9808      	ldr	r0, [sp, #32]
d000a286:	fb03 0302 	mla	r3, r3, r2, r0
d000a28a:	f8d8 0004 	ldr.w	r0, [r8, #4]
d000a28e:	2200      	movs	r2, #0
d000a290:	444b      	add	r3, r9
d000a292:	4420      	add	r0, r4
d000a294:	ea4f 0ed2 	mov.w	lr, r2, lsr #3
d000a298:	f002 0607 	and.w	r6, r2, #7
d000a29c:	3201      	adds	r2, #1
d000a29e:	fa2c f606 	lsr.w	r6, ip, r6
d000a2a2:	f813 e00e 	ldrb.w	lr, [r3, lr]
d000a2a6:	ea1e 0f06 	tst.w	lr, r6
d000a2aa:	bf14      	ite	ne
d000a2ac:	2601      	movne	r6, #1
d000a2ae:	2600      	moveq	r6, #0
d000a2b0:	4295      	cmp	r5, r2
d000a2b2:	f800 6b01 	strb.w	r6, [r0], #1
d000a2b6:	d8ed      	bhi.n	d000a294 <main+0xa3c>
d000a2b8:	3101      	adds	r1, #1
d000a2ba:	442c      	add	r4, r5
d000a2bc:	e7d8      	b.n	d000a270 <main+0xa18>
d000a2be:	f899 3001 	ldrb.w	r3, [r9, #1]
d000a2c2:	2bd8      	cmp	r3, #216	; 0xd8
d000a2c4:	f47f ae03 	bne.w	d0009ece <main+0x676>
d000a2c8:	2300      	movs	r3, #0
d000a2ca:	aa20      	add	r2, sp, #128	; 0x80
d000a2cc:	49ba      	ldr	r1, [pc, #744]	; (d000a5b8 <main+0xd60>)
d000a2ce:	a823      	add	r0, sp, #140	; 0x8c
d000a2d0:	ee08 2a10 	vmov	s16, r2
d000a2d4:	9322      	str	r3, [sp, #136]	; 0x88
d000a2d6:	e9cd 9620 	strd	r9, r6, [sp, #128]	; 0x80
d000a2da:	f7fe fb7b 	bl	d00089d4 <pjpeg_decode_init>
d000a2de:	4605      	mov	r5, r0
d000a2e0:	2800      	cmp	r0, #0
d000a2e2:	f000 8739 	beq.w	d000b158 <main+0x1900>
d000a2e6:	2825      	cmp	r0, #37	; 0x25
d000a2e8:	f000 86ce 	beq.w	d000b088 <main+0x1830>
d000a2ec:	281b      	cmp	r0, #27
d000a2ee:	f000 86bf 	beq.w	d000b070 <main+0x1818>
d000a2f2:	2d1a      	cmp	r5, #26
d000a2f4:	f000 86b9 	beq.w	d000b06a <main+0x1812>
d000a2f8:	4bb0      	ldr	r3, [pc, #704]	; (d000a5bc <main+0xd64>)
d000a2fa:	4ab1      	ldr	r2, [pc, #708]	; (d000a5c0 <main+0xd68>)
d000a2fc:	2d13      	cmp	r5, #19
d000a2fe:	bf08      	it	eq
d000a300:	4613      	moveq	r3, r2
d000a302:	4ab0      	ldr	r2, [pc, #704]	; (d000a5c4 <main+0xd6c>)
d000a304:	21a0      	movs	r1, #160	; 0xa0
d000a306:	48b0      	ldr	r0, [pc, #704]	; (d000a5c8 <main+0xd70>)
d000a308:	9500      	str	r5, [sp, #0]
d000a30a:	f002 f97f 	bl	d000c60c <sniprintf>
d000a30e:	48ae      	ldr	r0, [pc, #696]	; (d000a5c8 <main+0xd70>)
d000a310:	f7ff f8c8 	bl	d00094a4 <set_status>
d000a314:	4648      	mov	r0, r9
d000a316:	f001 fc61 	bl	d000bbdc <free>
d000a31a:	f7ff f9ab 	bl	d0009674 <free_image.constprop.0>
d000a31e:	e5de      	b.n	d0009ede <main+0x686>
d000a320:	462b      	mov	r3, r5
d000a322:	4aaa      	ldr	r2, [pc, #680]	; (d000a5cc <main+0xd74>)
d000a324:	21a0      	movs	r1, #160	; 0xa0
d000a326:	f8cd a000 	str.w	sl, [sp]
d000a32a:	48a7      	ldr	r0, [pc, #668]	; (d000a5c8 <main+0xd70>)
d000a32c:	f002 f96e 	bl	d000c60c <sniprintf>
d000a330:	48a5      	ldr	r0, [pc, #660]	; (d000a5c8 <main+0xd70>)
d000a332:	f7ff f8b7 	bl	d00094a4 <set_status>
d000a336:	e5d2      	b.n	d0009ede <main+0x686>
d000a338:	f8d9 2008 	ldr.w	r2, [r9, #8]
d000a33c:	2300      	movs	r3, #0
d000a33e:	49a4      	ldr	r1, [pc, #656]	; (d000a5d0 <main+0xd78>)
d000a340:	ba12      	rev	r2, r2
d000a342:	9323      	str	r3, [sp, #140]	; 0x8c
d000a344:	9324      	str	r3, [sp, #144]	; 0x90
d000a346:	428a      	cmp	r2, r1
d000a348:	9325      	str	r3, [sp, #148]	; 0x94
d000a34a:	f8ad 3098 	strh.w	r3, [sp, #152]	; 0x98
d000a34e:	d078      	beq.n	d000a442 <main+0xbea>
d000a350:	f101 4179 	add.w	r1, r1, #4177526784	; 0xf9000000
d000a354:	f501 211f 	add.w	r1, r1, #651264	; 0x9f000
d000a358:	f201 512d 	addw	r1, r1, #1325	; 0x52d
d000a35c:	428a      	cmp	r2, r1
d000a35e:	f041 804f 	bne.w	d000b400 <main+0x1ba8>
d000a362:	9308      	str	r3, [sp, #32]
d000a364:	2700      	movs	r7, #0
d000a366:	210c      	movs	r1, #12
d000a368:	46a0      	mov	r8, r4
d000a36a:	9704      	str	r7, [sp, #16]
d000a36c:	970e      	str	r7, [sp, #56]	; 0x38
d000a36e:	9705      	str	r7, [sp, #20]
d000a370:	9709      	str	r7, [sp, #36]	; 0x24
d000a372:	9703      	str	r7, [sp, #12]
d000a374:	f101 0508 	add.w	r5, r1, #8
d000a378:	42ae      	cmp	r6, r5
d000a37a:	f0c0 80b4 	bcc.w	d000a4e6 <main+0xc8e>
d000a37e:	eb09 0c01 	add.w	ip, r9, r1
d000a382:	f819 2001 	ldrb.w	r2, [r9, r1]
d000a386:	eb09 0005 	add.w	r0, r9, r5
d000a38a:	f89c e005 	ldrb.w	lr, [ip, #5]
d000a38e:	f89c 3004 	ldrb.w	r3, [ip, #4]
d000a392:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d000a396:	f89c e006 	ldrb.w	lr, [ip, #6]
d000a39a:	ea43 430e 	orr.w	r3, r3, lr, lsl #16
d000a39e:	f89c e007 	ldrb.w	lr, [ip, #7]
d000a3a2:	ea43 630e 	orr.w	r3, r3, lr, lsl #24
d000a3a6:	f89c e001 	ldrb.w	lr, [ip, #1]
d000a3aa:	ba1b      	rev	r3, r3
d000a3ac:	ea42 220e 	orr.w	r2, r2, lr, lsl #8
d000a3b0:	f89c e002 	ldrb.w	lr, [ip, #2]
d000a3b4:	4419      	add	r1, r3
d000a3b6:	f89c c003 	ldrb.w	ip, [ip, #3]
d000a3ba:	ea42 420e 	orr.w	r2, r2, lr, lsl #16
d000a3be:	f003 0e01 	and.w	lr, r3, #1
d000a3c2:	ea42 620c 	orr.w	r2, r2, ip, lsl #24
d000a3c6:	f101 0c08 	add.w	ip, r1, #8
d000a3ca:	448e      	add	lr, r1
d000a3cc:	4566      	cmp	r6, ip
d000a3ce:	ba12      	rev	r2, r2
d000a3d0:	f10e 0108 	add.w	r1, lr, #8
d000a3d4:	f0c0 820d 	bcc.w	d000a7f2 <main+0xf9a>
d000a3d8:	4c7e      	ldr	r4, [pc, #504]	; (d000a5d4 <main+0xd7c>)
d000a3da:	42a2      	cmp	r2, r4
d000a3dc:	d03a      	beq.n	d000a454 <main+0xbfc>
d000a3de:	4c7e      	ldr	r4, [pc, #504]	; (d000a5d8 <main+0xd80>)
d000a3e0:	42a2      	cmp	r2, r4
d000a3e2:	d031      	beq.n	d000a448 <main+0xbf0>
d000a3e4:	f104 447f 	add.w	r4, r4, #4278190080	; 0xff000000
d000a3e8:	f504 3400 	add.w	r4, r4, #131072	; 0x20000
d000a3ec:	f204 3409 	addw	r4, r4, #777	; 0x309
d000a3f0:	42a2      	cmp	r2, r4
d000a3f2:	d02c      	beq.n	d000a44e <main+0xbf6>
d000a3f4:	f504 0472 	add.w	r4, r4, #15859712	; 0xf20000
d000a3f8:	f604 04ee 	addw	r4, r4, #2286	; 0x8ee
d000a3fc:	42a2      	cmp	r2, r4
d000a3fe:	d1b9      	bne.n	d000a374 <main+0xb1c>
d000a400:	2b03      	cmp	r3, #3
d000a402:	d9b7      	bls.n	d000a374 <main+0xb1c>
d000a404:	f819 3005 	ldrb.w	r3, [r9, r5]
d000a408:	7842      	ldrb	r2, [r0, #1]
d000a40a:	7885      	ldrb	r5, [r0, #2]
d000a40c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d000a410:	78c2      	ldrb	r2, [r0, #3]
d000a412:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d000a416:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d000a41a:	ba1b      	rev	r3, r3
d000a41c:	9304      	str	r3, [sp, #16]
d000a41e:	e7a9      	b.n	d000a374 <main+0xb1c>
d000a420:	4620      	mov	r0, r4
d000a422:	2203      	movs	r2, #3
d000a424:	496d      	ldr	r1, [pc, #436]	; (d000a5dc <main+0xd84>)
d000a426:	f001 fbe1 	bl	d000bbec <memcmp>
d000a42a:	2800      	cmp	r0, #0
d000a42c:	f43f ac6d 	beq.w	d0009d0a <main+0x4b2>
d000a430:	486b      	ldr	r0, [pc, #428]	; (d000a5e0 <main+0xd88>)
d000a432:	f7ff f837 	bl	d00094a4 <set_status>
d000a436:	4648      	mov	r0, r9
d000a438:	f001 fbd0 	bl	d000bbdc <free>
d000a43c:	f7ff f91a 	bl	d0009674 <free_image.constprop.0>
d000a440:	e54d      	b.n	d0009ede <main+0x686>
d000a442:	2301      	movs	r3, #1
d000a444:	9308      	str	r3, [sp, #32]
d000a446:	e78d      	b.n	d000a364 <main+0xb0c>
d000a448:	9305      	str	r3, [sp, #20]
d000a44a:	9003      	str	r0, [sp, #12]
d000a44c:	e792      	b.n	d000a374 <main+0xb1c>
d000a44e:	930e      	str	r3, [sp, #56]	; 0x38
d000a450:	9009      	str	r0, [sp, #36]	; 0x24
d000a452:	e78f      	b.n	d000a374 <main+0xb1c>
d000a454:	2b13      	cmp	r3, #19
d000a456:	d92b      	bls.n	d000a4b0 <main+0xc58>
d000a458:	f819 3005 	ldrb.w	r3, [r9, r5]
d000a45c:	7842      	ldrb	r2, [r0, #1]
d000a45e:	ea42 2203 	orr.w	r2, r2, r3, lsl #8
d000a462:	f8ad 208c 	strh.w	r2, [sp, #140]	; 0x8c
d000a466:	7885      	ldrb	r5, [r0, #2]
d000a468:	78c3      	ldrb	r3, [r0, #3]
d000a46a:	ea43 2305 	orr.w	r3, r3, r5, lsl #8
d000a46e:	f8ad 308e 	strh.w	r3, [sp, #142]	; 0x8e
d000a472:	7a05      	ldrb	r5, [r0, #8]
d000a474:	f88d 5090 	strb.w	r5, [sp, #144]	; 0x90
d000a478:	7a45      	ldrb	r5, [r0, #9]
d000a47a:	f88d 5091 	strb.w	r5, [sp, #145]	; 0x91
d000a47e:	7a85      	ldrb	r5, [r0, #10]
d000a480:	f88d 5092 	strb.w	r5, [sp, #146]	; 0x92
d000a484:	7b07      	ldrb	r7, [r0, #12]
d000a486:	7b45      	ldrb	r5, [r0, #13]
d000a488:	ea45 2507 	orr.w	r5, r5, r7, lsl #8
d000a48c:	f8ad 5094 	strh.w	r5, [sp, #148]	; 0x94
d000a490:	7c07      	ldrb	r7, [r0, #16]
d000a492:	7c45      	ldrb	r5, [r0, #17]
d000a494:	ea45 2507 	orr.w	r5, r5, r7, lsl #8
d000a498:	f8ad 5096 	strh.w	r5, [sp, #150]	; 0x96
d000a49c:	7c85      	ldrb	r5, [r0, #18]
d000a49e:	7cc0      	ldrb	r0, [r0, #19]
d000a4a0:	ea40 2005 	orr.w	r0, r0, r5, lsl #8
d000a4a4:	f8ad 0098 	strh.w	r0, [sp, #152]	; 0x98
d000a4a8:	b112      	cbz	r2, d000a4b0 <main+0xc58>
d000a4aa:	2b00      	cmp	r3, #0
d000a4ac:	f040 81ab 	bne.w	d000a806 <main+0xfae>
d000a4b0:	484c      	ldr	r0, [pc, #304]	; (d000a5e4 <main+0xd8c>)
d000a4b2:	f7fe fff7 	bl	d00094a4 <set_status>
d000a4b6:	4648      	mov	r0, r9
d000a4b8:	f001 fb90 	bl	d000bbdc <free>
d000a4bc:	f7ff f8da 	bl	d0009674 <free_image.constprop.0>
d000a4c0:	e50d      	b.n	d0009ede <main+0x686>
d000a4c2:	4849      	ldr	r0, [pc, #292]	; (d000a5e8 <main+0xd90>)
d000a4c4:	f7fe ffee 	bl	d00094a4 <set_status>
d000a4c8:	4648      	mov	r0, r9
d000a4ca:	f001 fb87 	bl	d000bbdc <free>
d000a4ce:	f7ff f8d1 	bl	d0009674 <free_image.constprop.0>
d000a4d2:	e504      	b.n	d0009ede <main+0x686>
d000a4d4:	4845      	ldr	r0, [pc, #276]	; (d000a5ec <main+0xd94>)
d000a4d6:	f7fe ffe5 	bl	d00094a4 <set_status>
d000a4da:	4648      	mov	r0, r9
d000a4dc:	f001 fb7e 	bl	d000bbdc <free>
d000a4e0:	f7ff f8c8 	bl	d0009674 <free_image.constprop.0>
d000a4e4:	e4fb      	b.n	d0009ede <main+0x686>
d000a4e6:	4644      	mov	r4, r8
d000a4e8:	2f00      	cmp	r7, #0
d000a4ea:	f000 843c 	beq.w	d000ad66 <main+0x150e>
d000a4ee:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000a4f0:	2b00      	cmp	r3, #0
d000a4f2:	f000 8438 	beq.w	d000ad66 <main+0x150e>
d000a4f6:	f89d 3092 	ldrb.w	r3, [sp, #146]	; 0x92
d000a4fa:	2b01      	cmp	r3, #1
d000a4fc:	f200 8429 	bhi.w	d000ad52 <main+0x14fa>
d000a500:	f8bd 508c 	ldrh.w	r5, [sp, #140]	; 0x8c
d000a504:	f5b5 5f80 	cmp.w	r5, #4096	; 0x1000
d000a508:	f200 8437 	bhi.w	d000ad7a <main+0x1522>
d000a50c:	f8bd 308e 	ldrh.w	r3, [sp, #142]	; 0x8e
d000a510:	f5b3 5f80 	cmp.w	r3, #4096	; 0x1000
d000a514:	9307      	str	r3, [sp, #28]
d000a516:	f200 8430 	bhi.w	d000ad7a <main+0x1522>
d000a51a:	fba5 2303 	umull	r2, r3, r5, r3
d000a51e:	a124      	add	r1, pc, #144	; (adr r1, d000a5b0 <main+0xd58>)
d000a520:	e9d1 0100 	ldrd	r0, r1, [r1]
d000a524:	4299      	cmp	r1, r3
d000a526:	bf08      	it	eq
d000a528:	4290      	cmpeq	r0, r2
d000a52a:	f0c0 8426 	bcc.w	d000ad7a <main+0x1522>
d000a52e:	f8df 80c0 	ldr.w	r8, [pc, #192]	; d000a5f0 <main+0xd98>
d000a532:	f44f 7380 	mov.w	r3, #256	; 0x100
d000a536:	9a07      	ldr	r2, [sp, #28]
d000a538:	f04f 417f 	mov.w	r1, #4278190080	; 0xff000000
d000a53c:	f108 0708 	add.w	r7, r8, #8
d000a540:	f8a8 5000 	strh.w	r5, [r8]
d000a544:	f8a8 2002 	strh.w	r2, [r8, #2]
d000a548:	463a      	mov	r2, r7
d000a54a:	3b01      	subs	r3, #1
d000a54c:	f842 1b04 	str.w	r1, [r2], #4
d000a550:	b29b      	uxth	r3, r3
d000a552:	2b00      	cmp	r3, #0
d000a554:	d1f9      	bne.n	d000a54a <main+0xcf2>
d000a556:	9b03      	ldr	r3, [sp, #12]
d000a558:	2b00      	cmp	r3, #0
d000a55a:	d05e      	beq.n	d000a61a <main+0xdc2>
d000a55c:	f240 3302 	movw	r3, #770	; 0x302
d000a560:	9a05      	ldr	r2, [sp, #20]
d000a562:	429a      	cmp	r2, r3
d000a564:	d802      	bhi.n	d000a56c <main+0xd14>
d000a566:	2403      	movs	r4, #3
d000a568:	fbb2 f4f4 	udiv	r4, r2, r4
d000a56c:	9b03      	ldr	r3, [sp, #12]
d000a56e:	46bc      	mov	ip, r7
d000a570:	2100      	movs	r1, #0
d000a572:	e00d      	b.n	d000a590 <main+0xd38>
d000a574:	f813 2c02 	ldrb.w	r2, [r3, #-2]
d000a578:	f813 6c03 	ldrb.w	r6, [r3, #-3]
d000a57c:	0212      	lsls	r2, r2, #8
d000a57e:	f813 0c01 	ldrb.w	r0, [r3, #-1]
d000a582:	ea42 4206 	orr.w	r2, r2, r6, lsl #16
d000a586:	4302      	orrs	r2, r0
d000a588:	f042 427f 	orr.w	r2, r2, #4278190080	; 0xff000000
d000a58c:	f84c 2b04 	str.w	r2, [ip], #4
d000a590:	42a1      	cmp	r1, r4
d000a592:	f103 0303 	add.w	r3, r3, #3
d000a596:	f101 0101 	add.w	r1, r1, #1
d000a59a:	d1eb      	bne.n	d000a574 <main+0xd1c>
d000a59c:	9b04      	ldr	r3, [sp, #16]
d000a59e:	0618      	lsls	r0, r3, #24
d000a5a0:	d53b      	bpl.n	d000a61a <main+0xdc2>
d000a5a2:	2c20      	cmp	r4, #32
d000a5a4:	d839      	bhi.n	d000a61a <main+0xdc2>
d000a5a6:	2100      	movs	r1, #0
d000a5a8:	e033      	b.n	d000a612 <main+0xdba>
d000a5aa:	bf00      	nop
d000a5ac:	f3af 8000 	nop.w
d000a5b0:	004c4b40 	.word	0x004c4b40
d000a5b4:	00000000 	.word	0x00000000
d000a5b8:	d0009475 	.word	0xd0009475
d000a5bc:	d000d6ac 	.word	0xd000d6ac
d000a5c0:	d000d68c 	.word	0xd000d68c
d000a5c4:	d000dcd4 	.word	0xd000dcd4
d000a5c8:	d000f018 	.word	0xd000f018
d000a5cc:	d000d724 	.word	0xd000d724
d000a5d0:	50424d20 	.word	0x50424d20
d000a5d4:	424d4844 	.word	0x424d4844
d000a5d8:	434d4150 	.word	0x434d4150
d000a5dc:	d000da38 	.word	0xd000da38
d000a5e0:	d000da3c 	.word	0xd000da3c
d000a5e4:	d000d908 	.word	0xd000d908
d000a5e8:	d000d77c 	.word	0xd000d77c
d000a5ec:	d000da4c 	.word	0xd000da4c
d000a5f0:	d000ec10 	.word	0xd000ec10
d000a5f4:	f857 2b04 	ldr.w	r2, [r7], #4
d000a5f8:	f3c2 2346 	ubfx	r3, r2, #9, #7
d000a5fc:	f3c2 4046 	ubfx	r0, r2, #17, #7
d000a600:	f3c2 0246 	ubfx	r2, r2, #1, #7
d000a604:	021b      	lsls	r3, r3, #8
d000a606:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d000a60a:	4313      	orrs	r3, r2
d000a60c:	f043 437f 	orr.w	r3, r3, #4278190080	; 0xff000000
d000a610:	67fb      	str	r3, [r7, #124]	; 0x7c
d000a612:	428c      	cmp	r4, r1
d000a614:	f101 0101 	add.w	r1, r1, #1
d000a618:	d1ec      	bne.n	d000a5f4 <main+0xd9c>
d000a61a:	9b04      	ldr	r3, [sp, #16]
d000a61c:	f3c3 23c0 	ubfx	r3, r3, #11, #1
d000a620:	9304      	str	r3, [sp, #16]
d000a622:	9b08      	ldr	r3, [sp, #32]
d000a624:	2b00      	cmp	r3, #0
d000a626:	f040 8383 	bne.w	d000ad30 <main+0x14d8>
d000a62a:	f89d 2090 	ldrb.w	r2, [sp, #144]	; 0x90
d000a62e:	2a18      	cmp	r2, #24
d000a630:	f000 837a 	beq.w	d000ad28 <main+0x14d0>
d000a634:	9b04      	ldr	r3, [sp, #16]
d000a636:	2b00      	cmp	r3, #0
d000a638:	f040 8372 	bne.w	d000ad20 <main+0x14c8>
d000a63c:	2a08      	cmp	r2, #8
d000a63e:	f200 8365 	bhi.w	d000ad0c <main+0x14b4>
d000a642:	9b08      	ldr	r3, [sp, #32]
d000a644:	930a      	str	r3, [sp, #40]	; 0x28
d000a646:	930b      	str	r3, [sp, #44]	; 0x2c
d000a648:	f105 030f 	add.w	r3, r5, #15
d000a64c:	f89d 1091 	ldrb.w	r1, [sp, #145]	; 0x91
d000a650:	091b      	lsrs	r3, r3, #4
d000a652:	2901      	cmp	r1, #1
d000a654:	bf08      	it	eq
d000a656:	3201      	addeq	r2, #1
d000a658:	005b      	lsls	r3, r3, #1
d000a65a:	920d      	str	r2, [sp, #52]	; 0x34
d000a65c:	9303      	str	r3, [sp, #12]
d000a65e:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d000a660:	9a03      	ldr	r2, [sp, #12]
d000a662:	fb03 f302 	mul.w	r3, r3, r2
d000a666:	4618      	mov	r0, r3
d000a668:	ee08 3a10 	vmov	s16, r3
d000a66c:	f001 faae 	bl	d000bbcc <malloc>
d000a670:	4606      	mov	r6, r0
d000a672:	2800      	cmp	r0, #0
d000a674:	f000 8340 	beq.w	d000acf8 <main+0x14a0>
d000a678:	9807      	ldr	r0, [sp, #28]
d000a67a:	fb00 f005 	mul.w	r0, r0, r5
d000a67e:	f001 faa5 	bl	d000bbcc <malloc>
d000a682:	f8c8 0004 	str.w	r0, [r8, #4]
d000a686:	2800      	cmp	r0, #0
d000a688:	f000 8329 	beq.w	d000acde <main+0x1486>
d000a68c:	9b03      	ldr	r3, [sp, #12]
d000a68e:	2400      	movs	r4, #0
d000a690:	f8cd a04c 	str.w	sl, [sp, #76]	; 0x4c
d000a694:	00db      	lsls	r3, r3, #3
d000a696:	9405      	str	r4, [sp, #20]
d000a698:	f8cd 901c 	str.w	r9, [sp, #28]
d000a69c:	930f      	str	r3, [sp, #60]	; 0x3c
d000a69e:	f8bd 308e 	ldrh.w	r3, [sp, #142]	; 0x8e
d000a6a2:	9a05      	ldr	r2, [sp, #20]
d000a6a4:	429a      	cmp	r2, r3
d000a6a6:	f080 81f1 	bcs.w	d000aa8c <main+0x1234>
d000a6aa:	f89d 3092 	ldrb.w	r3, [sp, #146]	; 0x92
d000a6ae:	2b00      	cmp	r3, #0
d000a6b0:	f040 8189 	bne.w	d000a9c6 <main+0x116e>
d000a6b4:	ee18 3a10 	vmov	r3, s16
d000a6b8:	9a0e      	ldr	r2, [sp, #56]	; 0x38
d000a6ba:	4423      	add	r3, r4
d000a6bc:	4293      	cmp	r3, r2
d000a6be:	f200 8173 	bhi.w	d000a9a8 <main+0x1150>
d000a6c2:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000a6c4:	4630      	mov	r0, r6
d000a6c6:	1911      	adds	r1, r2, r4
d000a6c8:	ee18 2a10 	vmov	r2, s16
d000a6cc:	461c      	mov	r4, r3
d000a6ce:	f001 fa9b 	bl	d000bc08 <memcpy>
d000a6d2:	9b08      	ldr	r3, [sp, #32]
d000a6d4:	2b00      	cmp	r3, #0
d000a6d6:	f040 80ac 	bne.w	d000a832 <main+0xfda>
d000a6da:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d000a6dc:	2b00      	cmp	r3, #0
d000a6de:	f040 80fb 	bne.w	d000a8d8 <main+0x1080>
d000a6e2:	9b04      	ldr	r3, [sp, #16]
d000a6e4:	2b00      	cmp	r3, #0
d000a6e6:	f000 80c2 	beq.w	d000a86e <main+0x1016>
d000a6ea:	f89d 3090 	ldrb.w	r3, [sp, #144]	; 0x90
d000a6ee:	9a0b      	ldr	r2, [sp, #44]	; 0x2c
d000a6f0:	2b07      	cmp	r3, #7
d000a6f2:	f04f 0301 	mov.w	r3, #1
d000a6f6:	4692      	mov	sl, r2
d000a6f8:	4694      	mov	ip, r2
d000a6fa:	bf8c      	ite	hi
d000a6fc:	f04f 0906 	movhi.w	r9, #6
d000a700:	f04f 0904 	movls.w	r9, #4
d000a704:	920c      	str	r2, [sp, #48]	; 0x30
d000a706:	fa03 f309 	lsl.w	r3, r3, r9
d000a70a:	3b01      	subs	r3, #1
d000a70c:	b2db      	uxtb	r3, r3
d000a70e:	9310      	str	r3, [sp, #64]	; 0x40
d000a710:	f8bd 708c 	ldrh.w	r7, [sp, #140]	; 0x8c
d000a714:	42ba      	cmp	r2, r7
d000a716:	f080 8096 	bcs.w	d000a846 <main+0xfee>
d000a71a:	f89d 0090 	ldrb.w	r0, [sp, #144]	; 0x90
d000a71e:	f002 0107 	and.w	r1, r2, #7
d000a722:	2300      	movs	r3, #0
d000a724:	eb06 05d2 	add.w	r5, r6, r2, lsr #3
d000a728:	9011      	str	r0, [sp, #68]	; 0x44
d000a72a:	2080      	movs	r0, #128	; 0x80
d000a72c:	9214      	str	r2, [sp, #80]	; 0x50
d000a72e:	fa20 f101 	lsr.w	r1, r0, r1
d000a732:	4618      	mov	r0, r3
d000a734:	b2c9      	uxtb	r1, r1
d000a736:	9112      	str	r1, [sp, #72]	; 0x48
d000a738:	e00b      	b.n	d000a752 <main+0xefa>
d000a73a:	f1be 0f07 	cmp.w	lr, #7
d000a73e:	d812      	bhi.n	d000a766 <main+0xf0e>
d000a740:	9a03      	ldr	r2, [sp, #12]
d000a742:	f895 e000 	ldrb.w	lr, [r5]
d000a746:	4415      	add	r5, r2
d000a748:	9a12      	ldr	r2, [sp, #72]	; 0x48
d000a74a:	ea12 0f0e 	tst.w	r2, lr
d000a74e:	bf18      	it	ne
d000a750:	b2cb      	uxtbne	r3, r1
d000a752:	2201      	movs	r2, #1
d000a754:	fa5f fe80 	uxtb.w	lr, r0
d000a758:	fa02 f100 	lsl.w	r1, r2, r0
d000a75c:	4410      	add	r0, r2
d000a75e:	9a11      	ldr	r2, [sp, #68]	; 0x44
d000a760:	4319      	orrs	r1, r3
d000a762:	4596      	cmp	lr, r2
d000a764:	d3e9      	bcc.n	d000a73a <main+0xee2>
d000a766:	9910      	ldr	r1, [sp, #64]	; 0x40
d000a768:	f1b9 0f06 	cmp.w	r9, #6
d000a76c:	fa43 f009 	asr.w	r0, r3, r9
d000a770:	9a14      	ldr	r2, [sp, #80]	; 0x50
d000a772:	ea03 0301 	and.w	r3, r3, r1
d000a776:	d071      	beq.n	d000a85c <main+0x1004>
d000a778:	ea43 1103 	orr.w	r1, r3, r3, lsl #4
d000a77c:	b2c9      	uxtb	r1, r1
d000a77e:	2800      	cmp	r0, #0
d000a780:	d165      	bne.n	d000a84e <main+0xff6>
d000a782:	3302      	adds	r3, #2
d000a784:	f858 3023 	ldr.w	r3, [r8, r3, lsl #2]
d000a788:	f3c3 2107 	ubfx	r1, r3, #8, #8
d000a78c:	f3c3 4c07 	ubfx	ip, r3, #16, #8
d000a790:	fa5f fa83 	uxtb.w	sl, r3
d000a794:	910c      	str	r1, [sp, #48]	; 0x30
d000a796:	9b0c      	ldr	r3, [sp, #48]	; 0x30
d000a798:	f02c 011f 	bic.w	r1, ip, #31
d000a79c:	9d05      	ldr	r5, [sp, #20]
d000a79e:	08d8      	lsrs	r0, r3, #3
d000a7a0:	f8d8 3004 	ldr.w	r3, [r8, #4]
d000a7a4:	ea41 119a 	orr.w	r1, r1, sl, lsr #6
d000a7a8:	f000 001c 	and.w	r0, r0, #28
d000a7ac:	fb07 3305 	mla	r3, r7, r5, r3
d000a7b0:	4301      	orrs	r1, r0
d000a7b2:	5499      	strb	r1, [r3, r2]
d000a7b4:	3201      	adds	r2, #1
d000a7b6:	e7ab      	b.n	d000a710 <main+0xeb8>
d000a7b8:	f819 2003 	ldrb.w	r2, [r9, r3]
d000a7bc:	1853      	adds	r3, r2, r1
d000a7be:	2a00      	cmp	r2, #0
d000a7c0:	f43f ab68 	beq.w	d0009e94 <main+0x63c>
d000a7c4:	429e      	cmp	r6, r3
d000a7c6:	d303      	bcc.n	d000a7d0 <main+0xf78>
d000a7c8:	429e      	cmp	r6, r3
d000a7ca:	f103 0101 	add.w	r1, r3, #1
d000a7ce:	d8f3      	bhi.n	d000a7b8 <main+0xf60>
d000a7d0:	48a8      	ldr	r0, [pc, #672]	; (d000aa74 <main+0x121c>)
d000a7d2:	f7fe fe67 	bl	d00094a4 <set_status>
d000a7d6:	4648      	mov	r0, r9
d000a7d8:	f001 fa00 	bl	d000bbdc <free>
d000a7dc:	f7fe ff4a 	bl	d0009674 <free_image.constprop.0>
d000a7e0:	f7ff bb7d 	b.w	d0009ede <main+0x686>
d000a7e4:	f89e 0006 	ldrb.w	r0, [lr, #6]
d000a7e8:	f7ff bb4f 	b.w	d0009e8a <main+0x632>
d000a7ec:	240d      	movs	r4, #13
d000a7ee:	f7ff bb0a 	b.w	d0009e06 <main+0x5ae>
d000a7f2:	48a1      	ldr	r0, [pc, #644]	; (d000aa78 <main+0x1220>)
d000a7f4:	f7fe fe56 	bl	d00094a4 <set_status>
d000a7f8:	4648      	mov	r0, r9
d000a7fa:	f001 f9ef 	bl	d000bbdc <free>
d000a7fe:	f7fe ff39 	bl	d0009674 <free_image.constprop.0>
d000a802:	f7ff bb6c 	b.w	d0009ede <main+0x686>
d000a806:	2701      	movs	r7, #1
d000a808:	e5b4      	b.n	d000a374 <main+0xb1c>
d000a80a:	489c      	ldr	r0, [pc, #624]	; (d000aa7c <main+0x1224>)
d000a80c:	f7fe fe4a 	bl	d00094a4 <set_status>
d000a810:	4648      	mov	r0, r9
d000a812:	f001 f9e3 	bl	d000bbdc <free>
d000a816:	f7fe ff2d 	bl	d0009674 <free_image.constprop.0>
d000a81a:	f7ff bb60 	b.w	d0009ede <main+0x686>
d000a81e:	4898      	ldr	r0, [pc, #608]	; (d000aa80 <main+0x1228>)
d000a820:	f7fe fe40 	bl	d00094a4 <set_status>
d000a824:	4648      	mov	r0, r9
d000a826:	f001 f9d9 	bl	d000bbdc <free>
d000a82a:	f7fe ff23 	bl	d0009674 <free_image.constprop.0>
d000a82e:	f7ff bb56 	b.w	d0009ede <main+0x686>
d000a832:	f8bd 208c 	ldrh.w	r2, [sp, #140]	; 0x8c
d000a836:	4631      	mov	r1, r6
d000a838:	f8d8 0004 	ldr.w	r0, [r8, #4]
d000a83c:	9b05      	ldr	r3, [sp, #20]
d000a83e:	fb03 0002 	mla	r0, r3, r2, r0
d000a842:	f001 f9e1 	bl	d000bc08 <memcpy>
d000a846:	9b05      	ldr	r3, [sp, #20]
d000a848:	3301      	adds	r3, #1
d000a84a:	9305      	str	r3, [sp, #20]
d000a84c:	e727      	b.n	d000a69e <main+0xe46>
d000a84e:	2801      	cmp	r0, #1
d000a850:	b2c3      	uxtb	r3, r0
d000a852:	d00a      	beq.n	d000a86a <main+0x1012>
d000a854:	2b02      	cmp	r3, #2
d000a856:	d006      	beq.n	d000a866 <main+0x100e>
d000a858:	910c      	str	r1, [sp, #48]	; 0x30
d000a85a:	e79c      	b.n	d000a796 <main+0xf3e>
d000a85c:	0919      	lsrs	r1, r3, #4
d000a85e:	ea41 0183 	orr.w	r1, r1, r3, lsl #2
d000a862:	b2c9      	uxtb	r1, r1
d000a864:	e78b      	b.n	d000a77e <main+0xf26>
d000a866:	468c      	mov	ip, r1
d000a868:	e795      	b.n	d000a796 <main+0xf3e>
d000a86a:	468a      	mov	sl, r1
d000a86c:	e793      	b.n	d000a796 <main+0xf3e>
d000a86e:	9b04      	ldr	r3, [sp, #16]
d000a870:	f04f 0980 	mov.w	r9, #128	; 0x80
d000a874:	f8bd 208c 	ldrh.w	r2, [sp, #140]	; 0x8c
d000a878:	429a      	cmp	r2, r3
d000a87a:	d9e4      	bls.n	d000a846 <main+0xfee>
d000a87c:	f003 0107 	and.w	r1, r3, #7
d000a880:	9d05      	ldr	r5, [sp, #20]
d000a882:	2000      	movs	r0, #0
d000a884:	f89d a090 	ldrb.w	sl, [sp, #144]	; 0x90
d000a888:	fb02 3e05 	mla	lr, r2, r5, r3
d000a88c:	fa29 f201 	lsr.w	r2, r9, r1
d000a890:	f8d8 1004 	ldr.w	r1, [r8, #4]
d000a894:	4605      	mov	r5, r0
d000a896:	eb06 07d3 	add.w	r7, r6, r3, lsr #3
d000a89a:	9310      	str	r3, [sp, #64]	; 0x40
d000a89c:	b2d2      	uxtb	r2, r2
d000a89e:	910c      	str	r1, [sp, #48]	; 0x30
d000a8a0:	e00a      	b.n	d000a8b8 <main+0x1060>
d000a8a2:	f1bc 0f07 	cmp.w	ip, #7
d000a8a6:	d811      	bhi.n	d000a8cc <main+0x1074>
d000a8a8:	f897 c000 	ldrb.w	ip, [r7]
d000a8ac:	9b03      	ldr	r3, [sp, #12]
d000a8ae:	ea12 0f0c 	tst.w	r2, ip
d000a8b2:	441f      	add	r7, r3
d000a8b4:	bf18      	it	ne
d000a8b6:	b2c8      	uxtbne	r0, r1
d000a8b8:	2301      	movs	r3, #1
d000a8ba:	fa5f fc85 	uxtb.w	ip, r5
d000a8be:	fa03 f105 	lsl.w	r1, r3, r5
d000a8c2:	45d4      	cmp	ip, sl
d000a8c4:	441d      	add	r5, r3
d000a8c6:	ea41 0100 	orr.w	r1, r1, r0
d000a8ca:	d3ea      	bcc.n	d000a8a2 <main+0x104a>
d000a8cc:	9b10      	ldr	r3, [sp, #64]	; 0x40
d000a8ce:	9a0c      	ldr	r2, [sp, #48]	; 0x30
d000a8d0:	3301      	adds	r3, #1
d000a8d2:	f802 000e 	strb.w	r0, [r2, lr]
d000a8d6:	e7cd      	b.n	d000a874 <main+0x101c>
d000a8d8:	9908      	ldr	r1, [sp, #32]
d000a8da:	f04f 0980 	mov.w	r9, #128	; 0x80
d000a8de:	940c      	str	r4, [sp, #48]	; 0x30
d000a8e0:	f8bd 408c 	ldrh.w	r4, [sp, #140]	; 0x8c
d000a8e4:	42a1      	cmp	r1, r4
d000a8e6:	d25d      	bcs.n	d000a9a4 <main+0x114c>
d000a8e8:	f001 0007 	and.w	r0, r1, #7
d000a8ec:	2500      	movs	r5, #0
d000a8ee:	08ca      	lsrs	r2, r1, #3
d000a8f0:	fa29 f000 	lsr.w	r0, r9, r0
d000a8f4:	462f      	mov	r7, r5
d000a8f6:	eb06 0cd1 	add.w	ip, r6, r1, lsr #3
d000a8fa:	b2c0      	uxtb	r0, r0
d000a8fc:	fa29 fa07 	lsr.w	sl, r9, r7
d000a900:	9b03      	ldr	r3, [sp, #12]
d000a902:	f89c e000 	ldrb.w	lr, [ip]
d000a906:	3701      	adds	r7, #1
d000a908:	449c      	add	ip, r3
d000a90a:	4653      	mov	r3, sl
d000a90c:	ea10 0f0e 	tst.w	r0, lr
d000a910:	ea43 0305 	orr.w	r3, r3, r5
d000a914:	bf18      	it	ne
d000a916:	b2dd      	uxtbne	r5, r3
d000a918:	2f08      	cmp	r7, #8
d000a91a:	d1ef      	bne.n	d000a8fc <main+0x10a4>
d000a91c:	9b0f      	ldr	r3, [sp, #60]	; 0x3c
d000a91e:	441a      	add	r2, r3
d000a920:	2300      	movs	r3, #0
d000a922:	eb06 0e02 	add.w	lr, r6, r2
d000a926:	469c      	mov	ip, r3
d000a928:	9210      	str	r2, [sp, #64]	; 0x40
d000a92a:	fa29 f70c 	lsr.w	r7, r9, ip
d000a92e:	f89e a000 	ldrb.w	sl, [lr]
d000a932:	f10c 0c01 	add.w	ip, ip, #1
d000a936:	9a03      	ldr	r2, [sp, #12]
d000a938:	ea10 0f0a 	tst.w	r0, sl
d000a93c:	ea47 0703 	orr.w	r7, r7, r3
d000a940:	4496      	add	lr, r2
d000a942:	bf18      	it	ne
d000a944:	b2fb      	uxtbne	r3, r7
d000a946:	f1bc 0f08 	cmp.w	ip, #8
d000a94a:	d1ee      	bne.n	d000a92a <main+0x10d2>
d000a94c:	9a10      	ldr	r2, [sp, #64]	; 0x40
d000a94e:	f04f 0c00 	mov.w	ip, #0
d000a952:	9f0f      	ldr	r7, [sp, #60]	; 0x3c
d000a954:	46e6      	mov	lr, ip
d000a956:	9310      	str	r3, [sp, #64]	; 0x40
d000a958:	443a      	add	r2, r7
d000a95a:	4432      	add	r2, r6
d000a95c:	fa29 f70e 	lsr.w	r7, r9, lr
d000a960:	f892 a000 	ldrb.w	sl, [r2]
d000a964:	f10e 0e01 	add.w	lr, lr, #1
d000a968:	9b03      	ldr	r3, [sp, #12]
d000a96a:	ea10 0f0a 	tst.w	r0, sl
d000a96e:	ea4c 0707 	orr.w	r7, ip, r7
d000a972:	441a      	add	r2, r3
d000a974:	bf18      	it	ne
d000a976:	fa5f fc87 	uxtbne.w	ip, r7
d000a97a:	f1be 0f08 	cmp.w	lr, #8
d000a97e:	d1ed      	bne.n	d000a95c <main+0x1104>
d000a980:	9b10      	ldr	r3, [sp, #64]	; 0x40
d000a982:	f025 051f 	bic.w	r5, r5, #31
d000a986:	f8d8 2004 	ldr.w	r2, [r8, #4]
d000a98a:	08db      	lsrs	r3, r3, #3
d000a98c:	9805      	ldr	r0, [sp, #20]
d000a98e:	f003 031c 	and.w	r3, r3, #28
d000a992:	fb04 2200 	mla	r2, r4, r0, r2
d000a996:	432b      	orrs	r3, r5
d000a998:	ea43 1c9c 	orr.w	ip, r3, ip, lsr #6
d000a99c:	f802 c001 	strb.w	ip, [r2, r1]
d000a9a0:	3101      	adds	r1, #1
d000a9a2:	e79d      	b.n	d000a8e0 <main+0x1088>
d000a9a4:	9c0c      	ldr	r4, [sp, #48]	; 0x30
d000a9a6:	e74e      	b.n	d000a846 <main+0xfee>
d000a9a8:	f8dd 901c 	ldr.w	r9, [sp, #28]
d000a9ac:	4630      	mov	r0, r6
d000a9ae:	f001 f915 	bl	d000bbdc <free>
d000a9b2:	4834      	ldr	r0, [pc, #208]	; (d000aa84 <main+0x122c>)
d000a9b4:	f7fe fd76 	bl	d00094a4 <set_status>
d000a9b8:	4648      	mov	r0, r9
d000a9ba:	f001 f90f 	bl	d000bbdc <free>
d000a9be:	f7fe fe59 	bl	d0009674 <free_image.constprop.0>
d000a9c2:	f7ff ba8c 	b.w	d0009ede <main+0x686>
d000a9c6:	46a4      	mov	ip, r4
d000a9c8:	4637      	mov	r7, r6
d000a9ca:	f04f 0900 	mov.w	r9, #0
d000a9ce:	f8dd a00c 	ldr.w	sl, [sp, #12]
d000a9d2:	9c0e      	ldr	r4, [sp, #56]	; 0x38
d000a9d4:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d000a9d6:	454b      	cmp	r3, r9
d000a9d8:	d04a      	beq.n	d000aa70 <main+0x1218>
d000a9da:	2000      	movs	r0, #0
d000a9dc:	960c      	str	r6, [sp, #48]	; 0x30
d000a9de:	4582      	cmp	sl, r0
d000a9e0:	d92c      	bls.n	d000aa3c <main+0x11e4>
d000a9e2:	4564      	cmp	r4, ip
d000a9e4:	d92a      	bls.n	d000aa3c <main+0x11e4>
d000a9e6:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000a9e8:	f10c 0501 	add.w	r5, ip, #1
d000a9ec:	f913 200c 	ldrsb.w	r2, [r3, ip]
d000a9f0:	2a00      	cmp	r2, #0
d000a9f2:	db0f      	blt.n	d000aa14 <main+0x11bc>
d000a9f4:	3201      	adds	r2, #1
d000a9f6:	eb05 0c02 	add.w	ip, r5, r2
d000a9fa:	4564      	cmp	r4, ip
d000a9fc:	d325      	bcc.n	d000aa4a <main+0x11f2>
d000a9fe:	1816      	adds	r6, r2, r0
d000aa00:	45b2      	cmp	sl, r6
d000aa02:	d322      	bcc.n	d000aa4a <main+0x11f2>
d000aa04:	1959      	adds	r1, r3, r5
d000aa06:	4438      	add	r0, r7
d000aa08:	4665      	mov	r5, ip
d000aa0a:	f001 f8fd 	bl	d000bc08 <memcpy>
d000aa0e:	4630      	mov	r0, r6
d000aa10:	46ac      	mov	ip, r5
d000aa12:	e7e4      	b.n	d000a9de <main+0x1186>
d000aa14:	f112 0f80 	cmn.w	r2, #128	; 0x80
d000aa18:	d0fa      	beq.n	d000aa10 <main+0x11b8>
d000aa1a:	42ac      	cmp	r4, r5
d000aa1c:	f1c2 0201 	rsb	r2, r2, #1
d000aa20:	d913      	bls.n	d000aa4a <main+0x11f2>
d000aa22:	1886      	adds	r6, r0, r2
d000aa24:	45b2      	cmp	sl, r6
d000aa26:	d310      	bcc.n	d000aa4a <main+0x11f2>
d000aa28:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000aa2a:	4438      	add	r0, r7
d000aa2c:	5d59      	ldrb	r1, [r3, r5]
d000aa2e:	f10c 0502 	add.w	r5, ip, #2
d000aa32:	f001 f8f7 	bl	d000bc24 <memset>
d000aa36:	4630      	mov	r0, r6
d000aa38:	46ac      	mov	ip, r5
d000aa3a:	e7d0      	b.n	d000a9de <main+0x1186>
d000aa3c:	4582      	cmp	sl, r0
d000aa3e:	9e0c      	ldr	r6, [sp, #48]	; 0x30
d000aa40:	4457      	add	r7, sl
d000aa42:	d112      	bne.n	d000aa6a <main+0x1212>
d000aa44:	f109 0901 	add.w	r9, r9, #1
d000aa48:	e7c4      	b.n	d000a9d4 <main+0x117c>
d000aa4a:	f8dd 901c 	ldr.w	r9, [sp, #28]
d000aa4e:	9e0c      	ldr	r6, [sp, #48]	; 0x30
d000aa50:	4630      	mov	r0, r6
d000aa52:	f001 f8c3 	bl	d000bbdc <free>
d000aa56:	480c      	ldr	r0, [pc, #48]	; (d000aa88 <main+0x1230>)
d000aa58:	f7fe fd24 	bl	d00094a4 <set_status>
d000aa5c:	4648      	mov	r0, r9
d000aa5e:	f001 f8bd 	bl	d000bbdc <free>
d000aa62:	f7fe fe07 	bl	d0009674 <free_image.constprop.0>
d000aa66:	f7ff ba3a 	b.w	d0009ede <main+0x686>
d000aa6a:	f8dd 901c 	ldr.w	r9, [sp, #28]
d000aa6e:	e7ef      	b.n	d000aa50 <main+0x11f8>
d000aa70:	4664      	mov	r4, ip
d000aa72:	e62e      	b.n	d000a6d2 <main+0xe7a>
d000aa74:	d000dacc 	.word	0xd000dacc
d000aa78:	d000d8f0 	.word	0xd000d8f0
d000aa7c:	d000d7a4 	.word	0xd000d7a4
d000aa80:	d000d78c 	.word	0xd000d78c
d000aa84:	d000d9f8 	.word	0xd000d9f8
d000aa88:	d000da10 	.word	0xd000da10
d000aa8c:	4630      	mov	r0, r6
d000aa8e:	f8dd a04c 	ldr.w	sl, [sp, #76]	; 0x4c
d000aa92:	f8dd 901c 	ldr.w	r9, [sp, #28]
d000aa96:	f001 f8a1 	bl	d000bbdc <free>
d000aa9a:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d000aa9c:	2b00      	cmp	r3, #0
d000aa9e:	f040 8110 	bne.w	d000acc2 <main+0x146a>
d000aaa2:	ab1d      	add	r3, sp, #116	; 0x74
d000aaa4:	4648      	mov	r0, r9
d000aaa6:	ac1c      	add	r4, sp, #112	; 0x70
d000aaa8:	ee08 3a90 	vmov	s17, r3
d000aaac:	f001 f896 	bl	d000bbdc <free>
d000aab0:	ab20      	add	r3, sp, #128	; 0x80
d000aab2:	ee08 3a10 	vmov	s16, r3
d000aab6:	f8b8 3002 	ldrh.w	r3, [r8, #2]
d000aaba:	21a0      	movs	r1, #160	; 0xa0
d000aabc:	4ab4      	ldr	r2, [pc, #720]	; (d000ad90 <main+0x1538>)
d000aabe:	48b5      	ldr	r0, [pc, #724]	; (d000ad94 <main+0x153c>)
d000aac0:	e9cd 3a00 	strd	r3, sl, [sp]
d000aac4:	f8b8 3000 	ldrh.w	r3, [r8]
d000aac8:	f04f 0a00 	mov.w	sl, #0
d000aacc:	f001 fd9e 	bl	d000c60c <sniprintf>
d000aad0:	48b0      	ldr	r0, [pc, #704]	; (d000ad94 <main+0x153c>)
d000aad2:	f7fe fce7 	bl	d00094a4 <set_status>
d000aad6:	f8b8 3000 	ldrh.w	r3, [r8]
d000aada:	f89b 200c 	ldrb.w	r2, [fp, #12]
d000aade:	46d1      	mov	r9, sl
d000aae0:	f5b3 7ff0 	cmp.w	r3, #480	; 0x1e0
d000aae4:	48ac      	ldr	r0, [pc, #688]	; (d000ad98 <main+0x1540>)
d000aae6:	f8cd a020 	str.w	sl, [sp, #32]
d000aaea:	bf2c      	ite	cs
d000aaec:	f5a3 73f0 	subcs.w	r3, r3, #480	; 0x1e0
d000aaf0:	2300      	movcc	r3, #0
d000aaf2:	f8cd a01c 	str.w	sl, [sp, #28]
d000aaf6:	9309      	str	r3, [sp, #36]	; 0x24
d000aaf8:	f8b8 3002 	ldrh.w	r3, [r8, #2]
d000aafc:	46d0      	mov	r8, sl
d000aafe:	f8cd a010 	str.w	sl, [sp, #16]
d000ab02:	f5b3 7fa0 	cmp.w	r3, #320	; 0x140
d000ab06:	f8cd a014 	str.w	sl, [sp, #20]
d000ab0a:	bf2c      	ite	cs
d000ab0c:	f5a3 73a0 	subcs.w	r3, r3, #320	; 0x140
d000ab10:	2300      	movcc	r3, #0
d000ab12:	930a      	str	r3, [sp, #40]	; 0x28
d000ab14:	f89b 300d 	ldrb.w	r3, [fp, #13]
d000ab18:	f89b 100e 	ldrb.w	r1, [fp, #14]
d000ab1c:	ea42 2203 	orr.w	r2, r2, r3, lsl #8
d000ab20:	f89b 500f 	ldrb.w	r5, [fp, #15]
d000ab24:	ea42 4301 	orr.w	r3, r2, r1, lsl #16
d000ab28:	ea43 6305 	orr.w	r3, r3, r5, lsl #24
d000ab2c:	681b      	ldr	r3, [r3, #0]
d000ab2e:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d000ab30:	4798      	blx	r3
d000ab32:	f89b 3000 	ldrb.w	r3, [fp]
d000ab36:	f89b 2001 	ldrb.w	r2, [fp, #1]
d000ab3a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d000ab3e:	f89b 2002 	ldrb.w	r2, [fp, #2]
d000ab42:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d000ab46:	f89b 2003 	ldrb.w	r2, [fp, #3]
d000ab4a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d000ab4e:	69db      	ldr	r3, [r3, #28]
d000ab50:	4798      	blx	r3
d000ab52:	4651      	mov	r1, sl
d000ab54:	4650      	mov	r0, sl
d000ab56:	f7fe fcd3 	bl	d0009500 <render_view.constprop.0>
d000ab5a:	9f06      	ldr	r7, [sp, #24]
d000ab5c:	f8cd a00c 	str.w	sl, [sp, #12]
d000ab60:	f89b 6000 	ldrb.w	r6, [fp]
d000ab64:	ee18 1a90 	vmov	r1, s17
d000ab68:	f89b 5001 	ldrb.w	r5, [fp, #1]
d000ab6c:	4620      	mov	r0, r4
d000ab6e:	f8ad 9070 	strh.w	r9, [sp, #112]	; 0x70
d000ab72:	ea46 2505 	orr.w	r5, r6, r5, lsl #8
d000ab76:	f89b 6002 	ldrb.w	r6, [fp, #2]
d000ab7a:	f8ad 9074 	strh.w	r9, [sp, #116]	; 0x74
d000ab7e:	ea45 4606 	orr.w	r6, r5, r6, lsl #16
d000ab82:	f89b 5003 	ldrb.w	r5, [fp, #3]
d000ab86:	f8ad 9080 	strh.w	r9, [sp, #128]	; 0x80
d000ab8a:	ea46 6505 	orr.w	r5, r6, r5, lsl #24
d000ab8e:	f8ad 908c 	strh.w	r9, [sp, #140]	; 0x8c
d000ab92:	692d      	ldr	r5, [r5, #16]
d000ab94:	47a8      	blx	r5
d000ab96:	f89b 5018 	ldrb.w	r5, [fp, #24]
d000ab9a:	f89b 0019 	ldrb.w	r0, [fp, #25]
d000ab9e:	a923      	add	r1, sp, #140	; 0x8c
d000aba0:	f89b 601a 	ldrb.w	r6, [fp, #26]
d000aba4:	ea45 2000 	orr.w	r0, r5, r0, lsl #8
d000aba8:	f89b 501b 	ldrb.w	r5, [fp, #27]
d000abac:	ea40 4606 	orr.w	r6, r0, r6, lsl #16
d000abb0:	ee18 0a10 	vmov	r0, s16
d000abb4:	ea46 6505 	orr.w	r5, r6, r5, lsl #24
d000abb8:	68ad      	ldr	r5, [r5, #8]
d000abba:	47a8      	blx	r5
d000abbc:	f89b 1000 	ldrb.w	r1, [fp]
d000abc0:	f89b 5001 	ldrb.w	r5, [fp, #1]
d000abc4:	4606      	mov	r6, r0
d000abc6:	f89b 0002 	ldrb.w	r0, [fp, #2]
d000abca:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
d000abce:	f89b 1003 	ldrb.w	r1, [fp, #3]
d000abd2:	ea45 4000 	orr.w	r0, r5, r0, lsl #16
d000abd6:	ea40 6101 	orr.w	r1, r0, r1, lsl #24
d000abda:	6a09      	ldr	r1, [r1, #32]
d000abdc:	4788      	blx	r1
d000abde:	f000 0103 	and.w	r1, r0, #3
d000abe2:	2903      	cmp	r1, #3
d000abe4:	d02d      	beq.n	d000ac42 <main+0x13ea>
d000abe6:	f010 0501 	ands.w	r5, r0, #1
d000abea:	d041      	beq.n	d000ac70 <main+0x1418>
d000abec:	2f00      	cmp	r7, #0
d000abee:	d04f      	beq.n	d000ac90 <main+0x1438>
d000abf0:	f9bd 0070 	ldrsh.w	r0, [sp, #112]	; 0x70
d000abf4:	9b05      	ldr	r3, [sp, #20]
d000abf6:	f9bd 1074 	ldrsh.w	r1, [sp, #116]	; 0x74
d000abfa:	eba0 0c03 	sub.w	ip, r0, r3
d000abfe:	9b04      	ldr	r3, [sp, #16]
d000ac00:	9005      	str	r0, [sp, #20]
d000ac02:	1ac8      	subs	r0, r1, r3
d000ac04:	ebaa 0a0c 	sub.w	sl, sl, ip
d000ac08:	9104      	str	r1, [sp, #16]
d000ac0a:	eba8 0800 	sub.w	r8, r8, r0
d000ac0e:	b146      	cbz	r6, d000ac22 <main+0x13ca>
d000ac10:	9b03      	ldr	r3, [sp, #12]
d000ac12:	f9bd 0080 	ldrsh.w	r0, [sp, #128]	; 0x80
d000ac16:	2b00      	cmp	r3, #0
d000ac18:	d145      	bne.n	d000aca6 <main+0x144e>
d000ac1a:	f9bd 108c 	ldrsh.w	r1, [sp, #140]	; 0x8c
d000ac1e:	9007      	str	r0, [sp, #28]
d000ac20:	9108      	str	r1, [sp, #32]
d000ac22:	f1ba 0f00 	cmp.w	sl, #0
d000ac26:	da25      	bge.n	d000ac74 <main+0x141c>
d000ac28:	f04f 0a00 	mov.w	sl, #0
d000ac2c:	f1b8 0f00 	cmp.w	r8, #0
d000ac30:	db25      	blt.n	d000ac7e <main+0x1426>
d000ac32:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d000ac34:	4598      	cmp	r8, r3
d000ac36:	bfa8      	it	ge
d000ac38:	4698      	movge	r8, r3
d000ac3a:	bb27      	cbnz	r7, d000ac86 <main+0x142e>
d000ac3c:	462f      	mov	r7, r5
d000ac3e:	9603      	str	r6, [sp, #12]
d000ac40:	e78e      	b.n	d000ab60 <main+0x1308>
d000ac42:	f89b 1000 	ldrb.w	r1, [fp]
d000ac46:	f89b 3001 	ldrb.w	r3, [fp, #1]
d000ac4a:	f89b 2002 	ldrb.w	r2, [fp, #2]
d000ac4e:	ea41 2103 	orr.w	r1, r1, r3, lsl #8
d000ac52:	f89b 3003 	ldrb.w	r3, [fp, #3]
d000ac56:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d000ac5a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d000ac5e:	6a1b      	ldr	r3, [r3, #32]
d000ac60:	4798      	blx	r3
d000ac62:	f000 0003 	and.w	r0, r0, #3
d000ac66:	2803      	cmp	r0, #3
d000ac68:	d0eb      	beq.n	d000ac42 <main+0x13ea>
d000ac6a:	2400      	movs	r4, #0
d000ac6c:	f7ff b93d 	b.w	d0009eea <main+0x692>
d000ac70:	b9be      	cbnz	r6, d000aca2 <main+0x144a>
d000ac72:	4637      	mov	r7, r6
d000ac74:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000ac76:	459a      	cmp	sl, r3
d000ac78:	bfa8      	it	ge
d000ac7a:	469a      	movge	sl, r3
d000ac7c:	e7d6      	b.n	d000ac2c <main+0x13d4>
d000ac7e:	f04f 0800 	mov.w	r8, #0
d000ac82:	2f00      	cmp	r7, #0
d000ac84:	d0da      	beq.n	d000ac3c <main+0x13e4>
d000ac86:	4641      	mov	r1, r8
d000ac88:	4650      	mov	r0, sl
d000ac8a:	f7fe fc39 	bl	d0009500 <render_view.constprop.0>
d000ac8e:	e7d5      	b.n	d000ac3c <main+0x13e4>
d000ac90:	f9bd 3070 	ldrsh.w	r3, [sp, #112]	; 0x70
d000ac94:	9305      	str	r3, [sp, #20]
d000ac96:	f9bd 3074 	ldrsh.w	r3, [sp, #116]	; 0x74
d000ac9a:	9304      	str	r3, [sp, #16]
d000ac9c:	2e00      	cmp	r6, #0
d000ac9e:	d1b7      	bne.n	d000ac10 <main+0x13b8>
d000aca0:	e7e8      	b.n	d000ac74 <main+0x141c>
d000aca2:	462f      	mov	r7, r5
d000aca4:	e7b4      	b.n	d000ac10 <main+0x13b8>
d000aca6:	9b07      	ldr	r3, [sp, #28]
d000aca8:	2701      	movs	r7, #1
d000acaa:	f9bd 108c 	ldrsh.w	r1, [sp, #140]	; 0x8c
d000acae:	eba0 0e03 	sub.w	lr, r0, r3
d000acb2:	9b08      	ldr	r3, [sp, #32]
d000acb4:	eba1 0c03 	sub.w	ip, r1, r3
d000acb8:	ebaa 0a0e 	sub.w	sl, sl, lr
d000acbc:	eba8 080c 	sub.w	r8, r8, ip
d000acc0:	e7ad      	b.n	d000ac1e <main+0x13c6>
d000acc2:	ab1d      	add	r3, sp, #116	; 0x74
d000acc4:	4834      	ldr	r0, [pc, #208]	; (d000ad98 <main+0x1540>)
d000acc6:	ee08 3a90 	vmov	s17, r3
d000acca:	f7fe fa43 	bl	d0009154 <init_rgb332_palette>
d000acce:	4648      	mov	r0, r9
d000acd0:	ac1c      	add	r4, sp, #112	; 0x70
d000acd2:	f000 ff83 	bl	d000bbdc <free>
d000acd6:	ab20      	add	r3, sp, #128	; 0x80
d000acd8:	ee08 3a10 	vmov	s16, r3
d000acdc:	e6eb      	b.n	d000aab6 <main+0x125e>
d000acde:	4630      	mov	r0, r6
d000ace0:	f000 ff7c 	bl	d000bbdc <free>
d000ace4:	482d      	ldr	r0, [pc, #180]	; (d000ad9c <main+0x1544>)
d000ace6:	f7fe fbdd 	bl	d00094a4 <set_status>
d000acea:	4648      	mov	r0, r9
d000acec:	f000 ff76 	bl	d000bbdc <free>
d000acf0:	f7fe fcc0 	bl	d0009674 <free_image.constprop.0>
d000acf4:	f7ff b8f3 	b.w	d0009ede <main+0x686>
d000acf8:	4829      	ldr	r0, [pc, #164]	; (d000ada0 <main+0x1548>)
d000acfa:	f7fe fbd3 	bl	d00094a4 <set_status>
d000acfe:	4648      	mov	r0, r9
d000ad00:	f000 ff6c 	bl	d000bbdc <free>
d000ad04:	f7fe fcb6 	bl	d0009674 <free_image.constprop.0>
d000ad08:	f7ff b8e9 	b.w	d0009ede <main+0x686>
d000ad0c:	4825      	ldr	r0, [pc, #148]	; (d000ada4 <main+0x154c>)
d000ad0e:	f7fe fbc9 	bl	d00094a4 <set_status>
d000ad12:	4648      	mov	r0, r9
d000ad14:	f000 ff62 	bl	d000bbdc <free>
d000ad18:	f7fe fcac 	bl	d0009674 <free_image.constprop.0>
d000ad1c:	f7ff b8df 	b.w	d0009ede <main+0x686>
d000ad20:	930a      	str	r3, [sp, #40]	; 0x28
d000ad22:	9b08      	ldr	r3, [sp, #32]
d000ad24:	930b      	str	r3, [sp, #44]	; 0x2c
d000ad26:	e48f      	b.n	d000a648 <main+0xdf0>
d000ad28:	2301      	movs	r3, #1
d000ad2a:	930a      	str	r3, [sp, #40]	; 0x28
d000ad2c:	930b      	str	r3, [sp, #44]	; 0x2c
d000ad2e:	e48b      	b.n	d000a648 <main+0xdf0>
d000ad30:	9b04      	ldr	r3, [sp, #16]
d000ad32:	b923      	cbnz	r3, d000ad3e <main+0x14e6>
d000ad34:	f89d 3090 	ldrb.w	r3, [sp, #144]	; 0x90
d000ad38:	2b08      	cmp	r3, #8
d000ad3a:	d8e7      	bhi.n	d000ad0c <main+0x14b4>
d000ad3c:	9b04      	ldr	r3, [sp, #16]
d000ad3e:	2200      	movs	r2, #0
d000ad40:	930a      	str	r3, [sp, #40]	; 0x28
d000ad42:	1c6b      	adds	r3, r5, #1
d000ad44:	920b      	str	r2, [sp, #44]	; 0x2c
d000ad46:	2201      	movs	r2, #1
d000ad48:	f023 0301 	bic.w	r3, r3, #1
d000ad4c:	920d      	str	r2, [sp, #52]	; 0x34
d000ad4e:	9303      	str	r3, [sp, #12]
d000ad50:	e485      	b.n	d000a65e <main+0xe06>
d000ad52:	4815      	ldr	r0, [pc, #84]	; (d000ada8 <main+0x1550>)
d000ad54:	f7fe fba6 	bl	d00094a4 <set_status>
d000ad58:	4648      	mov	r0, r9
d000ad5a:	f000 ff3f 	bl	d000bbdc <free>
d000ad5e:	f7fe fc89 	bl	d0009674 <free_image.constprop.0>
d000ad62:	f7ff b8bc 	b.w	d0009ede <main+0x686>
d000ad66:	4811      	ldr	r0, [pc, #68]	; (d000adac <main+0x1554>)
d000ad68:	f7fe fb9c 	bl	d00094a4 <set_status>
d000ad6c:	4648      	mov	r0, r9
d000ad6e:	f000 ff35 	bl	d000bbdc <free>
d000ad72:	f7fe fc7f 	bl	d0009674 <free_image.constprop.0>
d000ad76:	f7ff b8b2 	b.w	d0009ede <main+0x686>
d000ad7a:	480d      	ldr	r0, [pc, #52]	; (d000adb0 <main+0x1558>)
d000ad7c:	f7fe fb92 	bl	d00094a4 <set_status>
d000ad80:	4648      	mov	r0, r9
d000ad82:	f000 ff2b 	bl	d000bbdc <free>
d000ad86:	f7fe fc75 	bl	d0009674 <free_image.constprop.0>
d000ad8a:	f7ff b8a8 	b.w	d0009ede <main+0x686>
d000ad8e:	bf00      	nop
d000ad90:	d000dd0c 	.word	0xd000dd0c
d000ad94:	d000f018 	.word	0xd000f018
d000ad98:	d000ec18 	.word	0xd000ec18
d000ad9c:	d000d9d4 	.word	0xd000d9d4
d000ada0:	d000d9b4 	.word	0xd000d9b4
d000ada4:	d000d978 	.word	0xd000d978
d000ada8:	d000d938 	.word	0xd000d938
d000adac:	d000d91c 	.word	0xd000d91c
d000adb0:	d000d954 	.word	0xd000d954
d000adb4:	f020 0008 	bic.w	r0, r0, #8
d000adb8:	2810      	cmp	r0, #16
d000adba:	d003      	beq.n	d000adc4 <main+0x156c>
d000adbc:	9b05      	ldr	r3, [sp, #20]
d000adbe:	2b20      	cmp	r3, #32
d000adc0:	f040 8300 	bne.w	d000b3c4 <main+0x1b6c>
d000adc4:	9b03      	ldr	r3, [sp, #12]
d000adc6:	9a04      	ldr	r2, [sp, #16]
d000adc8:	fb03 f002 	mul.w	r0, r3, r2
d000adcc:	f000 fefe 	bl	d000bbcc <malloc>
d000add0:	f8c8 0004 	str.w	r0, [r8, #4]
d000add4:	2800      	cmp	r0, #0
d000add6:	f000 80f1 	beq.w	d000afbc <main+0x1764>
d000adda:	48a7      	ldr	r0, [pc, #668]	; (d000b078 <main+0x1820>)
d000addc:	f7fe f9ba 	bl	d0009154 <init_rgb332_palette>
d000ade0:	9b05      	ldr	r3, [sp, #20]
d000ade2:	2b18      	cmp	r3, #24
d000ade4:	f000 80ba 	beq.w	d000af5c <main+0x1704>
d000ade8:	f5b5 4f7f 	cmp.w	r5, #65280	; 0xff00
d000adec:	bf08      	it	eq
d000adee:	f5b7 0f7f 	cmpeq.w	r7, #16711680	; 0xff0000
d000adf2:	9a05      	ldr	r2, [sp, #20]
d000adf4:	bf0c      	ite	eq
d000adf6:	2301      	moveq	r3, #1
d000adf8:	2300      	movne	r3, #0
d000adfa:	2a20      	cmp	r2, #32
d000adfc:	bf14      	ite	ne
d000adfe:	2300      	movne	r3, #0
d000ae00:	f003 0301 	andeq.w	r3, r3, #1
d000ae04:	b113      	cbz	r3, d000ae0c <main+0x15b4>
d000ae06:	2cff      	cmp	r4, #255	; 0xff
d000ae08:	f000 80e2 	beq.w	d000afd0 <main+0x1778>
d000ae0c:	aa20      	add	r2, sp, #128	; 0x80
d000ae0e:	ab1d      	add	r3, sp, #116	; 0x74
d000ae10:	4639      	mov	r1, r7
d000ae12:	4616      	mov	r6, r2
d000ae14:	4618      	mov	r0, r3
d000ae16:	ee08 3a90 	vmov	s17, r3
d000ae1a:	ee08 2a10 	vmov	s16, r2
d000ae1e:	f7fe fadb 	bl	d00093d8 <bmp_make_mask_info>
d000ae22:	4629      	mov	r1, r5
d000ae24:	4630      	mov	r0, r6
d000ae26:	f7fe fad7 	bl	d00093d8 <bmp_make_mask_info>
d000ae2a:	4621      	mov	r1, r4
d000ae2c:	a823      	add	r0, sp, #140	; 0x8c
d000ae2e:	f7fe fad3 	bl	d00093d8 <bmp_make_mask_info>
d000ae32:	f8dd e07c 	ldr.w	lr, [sp, #124]	; 0x7c
d000ae36:	9e22      	ldr	r6, [sp, #136]	; 0x88
d000ae38:	f04f 0c00 	mov.w	ip, #0
d000ae3c:	ea4f 035e 	mov.w	r3, lr, lsr #1
d000ae40:	9d25      	ldr	r5, [sp, #148]	; 0x94
d000ae42:	9a03      	ldr	r2, [sp, #12]
d000ae44:	930e      	str	r3, [sp, #56]	; 0x38
d000ae46:	0873      	lsrs	r3, r6, #1
d000ae48:	4611      	mov	r1, r2
d000ae4a:	f8cd a050 	str.w	sl, [sp, #80]	; 0x50
d000ae4e:	9310      	str	r3, [sp, #64]	; 0x40
d000ae50:	9b1d      	ldr	r3, [sp, #116]	; 0x74
d000ae52:	930a      	str	r3, [sp, #40]	; 0x28
d000ae54:	086b      	lsrs	r3, r5, #1
d000ae56:	9312      	str	r3, [sp, #72]	; 0x48
d000ae58:	9b1e      	ldr	r3, [sp, #120]	; 0x78
d000ae5a:	930d      	str	r3, [sp, #52]	; 0x34
d000ae5c:	9b20      	ldr	r3, [sp, #128]	; 0x80
d000ae5e:	930b      	str	r3, [sp, #44]	; 0x2c
d000ae60:	9b21      	ldr	r3, [sp, #132]	; 0x84
d000ae62:	930f      	str	r3, [sp, #60]	; 0x3c
d000ae64:	9b23      	ldr	r3, [sp, #140]	; 0x8c
d000ae66:	930c      	str	r3, [sp, #48]	; 0x30
d000ae68:	9b24      	ldr	r3, [sp, #144]	; 0x90
d000ae6a:	9311      	str	r3, [sp, #68]	; 0x44
d000ae6c:	9b03      	ldr	r3, [sp, #12]
d000ae6e:	1a5b      	subs	r3, r3, r1
d000ae70:	2900      	cmp	r1, #0
d000ae72:	d06c      	beq.n	d000af4e <main+0x16f6>
d000ae74:	9a07      	ldr	r2, [sp, #28]
d000ae76:	3901      	subs	r1, #1
d000ae78:	b902      	cbnz	r2, d000ae7c <main+0x1624>
d000ae7a:	460b      	mov	r3, r1
d000ae7c:	9808      	ldr	r0, [sp, #32]
d000ae7e:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000ae80:	9115      	str	r1, [sp, #84]	; 0x54
d000ae82:	fb03 0202 	mla	r2, r3, r2, r0
d000ae86:	f8d8 3004 	ldr.w	r3, [r8, #4]
d000ae8a:	2000      	movs	r0, #0
d000ae8c:	444a      	add	r2, r9
d000ae8e:	eb03 0a0c 	add.w	sl, r3, ip
d000ae92:	1c53      	adds	r3, r2, #1
d000ae94:	9313      	str	r3, [sp, #76]	; 0x4c
d000ae96:	e049      	b.n	d000af2c <main+0x16d4>
d000ae98:	9b13      	ldr	r3, [sp, #76]	; 0x4c
d000ae9a:	f813 4010 	ldrb.w	r4, [r3, r0, lsl #1]
d000ae9e:	f812 3010 	ldrb.w	r3, [r2, r0, lsl #1]
d000aea2:	ea43 2304 	orr.w	r3, r3, r4, lsl #8
d000aea6:	9c0a      	ldr	r4, [sp, #40]	; 0x28
d000aea8:	2c00      	cmp	r4, #0
d000aeaa:	f000 80dc 	beq.w	d000b066 <main+0x180e>
d000aeae:	f1be 0f00 	cmp.w	lr, #0
d000aeb2:	f000 80d6 	beq.w	d000b062 <main+0x180a>
d000aeb6:	990d      	ldr	r1, [sp, #52]	; 0x34
d000aeb8:	401c      	ands	r4, r3
d000aeba:	40cc      	lsrs	r4, r1
d000aebc:	990e      	ldr	r1, [sp, #56]	; 0x38
d000aebe:	ebc4 2404 	rsb	r4, r4, r4, lsl #8
d000aec2:	1867      	adds	r7, r4, r1
d000aec4:	fbb7 f7fe 	udiv	r7, r7, lr
d000aec8:	b2ff      	uxtb	r7, r7
d000aeca:	9c0b      	ldr	r4, [sp, #44]	; 0x2c
d000aecc:	2c00      	cmp	r4, #0
d000aece:	f000 80c6 	beq.w	d000b05e <main+0x1806>
d000aed2:	2e00      	cmp	r6, #0
d000aed4:	f000 80c1 	beq.w	d000b05a <main+0x1802>
d000aed8:	990f      	ldr	r1, [sp, #60]	; 0x3c
d000aeda:	401c      	ands	r4, r3
d000aedc:	40cc      	lsrs	r4, r1
d000aede:	9910      	ldr	r1, [sp, #64]	; 0x40
d000aee0:	ebc4 2404 	rsb	r4, r4, r4, lsl #8
d000aee4:	440c      	add	r4, r1
d000aee6:	fbb4 f4f6 	udiv	r4, r4, r6
d000aeea:	b2e4      	uxtb	r4, r4
d000aeec:	990c      	ldr	r1, [sp, #48]	; 0x30
d000aeee:	2900      	cmp	r1, #0
d000aef0:	f000 80b1 	beq.w	d000b056 <main+0x17fe>
d000aef4:	2d00      	cmp	r5, #0
d000aef6:	f000 80ac 	beq.w	d000b052 <main+0x17fa>
d000aefa:	400b      	ands	r3, r1
d000aefc:	9911      	ldr	r1, [sp, #68]	; 0x44
d000aefe:	40cb      	lsrs	r3, r1
d000af00:	9912      	ldr	r1, [sp, #72]	; 0x48
d000af02:	ebc3 2303 	rsb	r3, r3, r3, lsl #8
d000af06:	440b      	add	r3, r1
d000af08:	fbb3 f3f5 	udiv	r3, r3, r5
d000af0c:	b2db      	uxtb	r3, r3
d000af0e:	08e4      	lsrs	r4, r4, #3
d000af10:	f027 071f 	bic.w	r7, r7, #31
d000af14:	3001      	adds	r0, #1
d000af16:	f004 041c 	and.w	r4, r4, #28
d000af1a:	433c      	orrs	r4, r7
d000af1c:	ea44 1493 	orr.w	r4, r4, r3, lsr #6
d000af20:	9b04      	ldr	r3, [sp, #16]
d000af22:	4283      	cmp	r3, r0
d000af24:	f80a 4b01 	strb.w	r4, [sl], #1
d000af28:	f240 8090 	bls.w	d000b04c <main+0x17f4>
d000af2c:	9b05      	ldr	r3, [sp, #20]
d000af2e:	2b20      	cmp	r3, #32
d000af30:	d1b2      	bne.n	d000ae98 <main+0x1640>
d000af32:	eb02 0480 	add.w	r4, r2, r0, lsl #2
d000af36:	f812 1020 	ldrb.w	r1, [r2, r0, lsl #2]
d000af3a:	7863      	ldrb	r3, [r4, #1]
d000af3c:	78a7      	ldrb	r7, [r4, #2]
d000af3e:	ea41 2303 	orr.w	r3, r1, r3, lsl #8
d000af42:	78e4      	ldrb	r4, [r4, #3]
d000af44:	ea43 4307 	orr.w	r3, r3, r7, lsl #16
d000af48:	ea43 6304 	orr.w	r3, r3, r4, lsl #24
d000af4c:	e7ab      	b.n	d000aea6 <main+0x164e>
d000af4e:	4648      	mov	r0, r9
d000af50:	f8dd a050 	ldr.w	sl, [sp, #80]	; 0x50
d000af54:	ac1c      	add	r4, sp, #112	; 0x70
d000af56:	f000 fe41 	bl	d000bbdc <free>
d000af5a:	e5ac      	b.n	d000aab6 <main+0x125e>
d000af5c:	2400      	movs	r4, #0
d000af5e:	9b03      	ldr	r3, [sp, #12]
d000af60:	9804      	ldr	r0, [sp, #16]
d000af62:	f103 3cff 	add.w	ip, r3, #4294967295	; 0xffffffff
d000af66:	4621      	mov	r1, r4
d000af68:	9b03      	ldr	r3, [sp, #12]
d000af6a:	428b      	cmp	r3, r1
d000af6c:	d063      	beq.n	d000b036 <main+0x17de>
d000af6e:	9b07      	ldr	r3, [sp, #28]
d000af70:	2b00      	cmp	r3, #0
d000af72:	d15e      	bne.n	d000b032 <main+0x17da>
d000af74:	ebac 0301 	sub.w	r3, ip, r1
d000af78:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000af7a:	9d08      	ldr	r5, [sp, #32]
d000af7c:	fb03 5302 	mla	r3, r3, r2, r5
d000af80:	f8d8 2004 	ldr.w	r2, [r8, #4]
d000af84:	2500      	movs	r5, #0
d000af86:	3303      	adds	r3, #3
d000af88:	1916      	adds	r6, r2, r4
d000af8a:	444b      	add	r3, r9
d000af8c:	f813 2c01 	ldrb.w	r2, [r3, #-1]
d000af90:	3501      	adds	r5, #1
d000af92:	f813 7c02 	ldrb.w	r7, [r3, #-2]
d000af96:	3303      	adds	r3, #3
d000af98:	f813 ec06 	ldrb.w	lr, [r3, #-6]
d000af9c:	f022 021f 	bic.w	r2, r2, #31
d000afa0:	08ff      	lsrs	r7, r7, #3
d000afa2:	42a8      	cmp	r0, r5
d000afa4:	ea42 129e 	orr.w	r2, r2, lr, lsr #6
d000afa8:	f007 071c 	and.w	r7, r7, #28
d000afac:	ea42 0207 	orr.w	r2, r2, r7
d000afb0:	f806 2b01 	strb.w	r2, [r6], #1
d000afb4:	d8ea      	bhi.n	d000af8c <main+0x1734>
d000afb6:	3101      	adds	r1, #1
d000afb8:	4404      	add	r4, r0
d000afba:	e7d5      	b.n	d000af68 <main+0x1710>
d000afbc:	482f      	ldr	r0, [pc, #188]	; (d000b07c <main+0x1824>)
d000afbe:	f7fe fa71 	bl	d00094a4 <set_status>
d000afc2:	4648      	mov	r0, r9
d000afc4:	f000 fe0a 	bl	d000bbdc <free>
d000afc8:	f7fe fb54 	bl	d0009674 <free_image.constprop.0>
d000afcc:	f7fe bf87 	b.w	d0009ede <main+0x686>
d000afd0:	2500      	movs	r5, #0
d000afd2:	9b03      	ldr	r3, [sp, #12]
d000afd4:	4628      	mov	r0, r5
d000afd6:	3b01      	subs	r3, #1
d000afd8:	9305      	str	r3, [sp, #20]
d000afda:	9b03      	ldr	r3, [sp, #12]
d000afdc:	4283      	cmp	r3, r0
d000afde:	d02a      	beq.n	d000b036 <main+0x17de>
d000afe0:	9b07      	ldr	r3, [sp, #28]
d000afe2:	bb23      	cbnz	r3, d000b02e <main+0x17d6>
d000afe4:	9b05      	ldr	r3, [sp, #20]
d000afe6:	1a1b      	subs	r3, r3, r0
d000afe8:	9908      	ldr	r1, [sp, #32]
d000afea:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000afec:	f8d8 6004 	ldr.w	r6, [r8, #4]
d000aff0:	fb03 1302 	mla	r3, r3, r2, r1
d000aff4:	2100      	movs	r1, #0
d000aff6:	442e      	add	r6, r5
d000aff8:	444b      	add	r3, r9
d000affa:	f103 0c02 	add.w	ip, r3, #2
d000affe:	1c5f      	adds	r7, r3, #1
d000b000:	f81c 2021 	ldrb.w	r2, [ip, r1, lsl #2]
d000b004:	f817 4021 	ldrb.w	r4, [r7, r1, lsl #2]
d000b008:	f813 e021 	ldrb.w	lr, [r3, r1, lsl #2]
d000b00c:	f022 021f 	bic.w	r2, r2, #31
d000b010:	08e4      	lsrs	r4, r4, #3
d000b012:	3101      	adds	r1, #1
d000b014:	ea42 129e 	orr.w	r2, r2, lr, lsr #6
d000b018:	f004 041c 	and.w	r4, r4, #28
d000b01c:	4322      	orrs	r2, r4
d000b01e:	f806 2b01 	strb.w	r2, [r6], #1
d000b022:	9a04      	ldr	r2, [sp, #16]
d000b024:	428a      	cmp	r2, r1
d000b026:	d8eb      	bhi.n	d000b000 <main+0x17a8>
d000b028:	3001      	adds	r0, #1
d000b02a:	4415      	add	r5, r2
d000b02c:	e7d5      	b.n	d000afda <main+0x1782>
d000b02e:	4603      	mov	r3, r0
d000b030:	e7da      	b.n	d000afe8 <main+0x1790>
d000b032:	460b      	mov	r3, r1
d000b034:	e7a0      	b.n	d000af78 <main+0x1720>
d000b036:	ab20      	add	r3, sp, #128	; 0x80
d000b038:	ee08 3a10 	vmov	s16, r3
d000b03c:	ab1d      	add	r3, sp, #116	; 0x74
d000b03e:	4648      	mov	r0, r9
d000b040:	ac1c      	add	r4, sp, #112	; 0x70
d000b042:	ee08 3a90 	vmov	s17, r3
d000b046:	f000 fdc9 	bl	d000bbdc <free>
d000b04a:	e534      	b.n	d000aab6 <main+0x125e>
d000b04c:	9915      	ldr	r1, [sp, #84]	; 0x54
d000b04e:	449c      	add	ip, r3
d000b050:	e70c      	b.n	d000ae6c <main+0x1614>
d000b052:	462b      	mov	r3, r5
d000b054:	e75b      	b.n	d000af0e <main+0x16b6>
d000b056:	9b0c      	ldr	r3, [sp, #48]	; 0x30
d000b058:	e759      	b.n	d000af0e <main+0x16b6>
d000b05a:	4634      	mov	r4, r6
d000b05c:	e746      	b.n	d000aeec <main+0x1694>
d000b05e:	9c0b      	ldr	r4, [sp, #44]	; 0x2c
d000b060:	e744      	b.n	d000aeec <main+0x1694>
d000b062:	4677      	mov	r7, lr
d000b064:	e731      	b.n	d000aeca <main+0x1672>
d000b066:	9f0a      	ldr	r7, [sp, #40]	; 0x28
d000b068:	e72f      	b.n	d000aeca <main+0x1672>
d000b06a:	4b05      	ldr	r3, [pc, #20]	; (d000b080 <main+0x1828>)
d000b06c:	f7ff b949 	b.w	d000a302 <main+0xaaa>
d000b070:	4b04      	ldr	r3, [pc, #16]	; (d000b084 <main+0x182c>)
d000b072:	f7ff b946 	b.w	d000a302 <main+0xaaa>
d000b076:	bf00      	nop
d000b078:	d000ec18 	.word	0xd000ec18
d000b07c:	d000d8ac 	.word	0xd000d8ac
d000b080:	d000d6c0 	.word	0xd000d6c0
d000b084:	d000d6e0 	.word	0xd000d6e0
d000b088:	2e00      	cmp	r6, #0
d000b08a:	f2c0 8174 	blt.w	d000b376 <main+0x1b1e>
d000b08e:	ab1d      	add	r3, sp, #116	; 0x74
d000b090:	2203      	movs	r2, #3
d000b092:	ac1c      	add	r4, sp, #112	; 0x70
d000b094:	4631      	mov	r1, r6
d000b096:	4618      	mov	r0, r3
d000b098:	9201      	str	r2, [sp, #4]
d000b09a:	ee08 3a90 	vmov	s17, r3
d000b09e:	aa1b      	add	r2, sp, #108	; 0x6c
d000b0a0:	9000      	str	r0, [sp, #0]
d000b0a2:	4623      	mov	r3, r4
d000b0a4:	4648      	mov	r0, r9
d000b0a6:	f7fa fdcd 	bl	d0005c44 <stbi_load_from_memory>
d000b0aa:	4606      	mov	r6, r0
d000b0ac:	2800      	cmp	r0, #0
d000b0ae:	f000 815e 	beq.w	d000b36e <main+0x1b16>
d000b0b2:	991b      	ldr	r1, [sp, #108]	; 0x6c
d000b0b4:	2900      	cmp	r1, #0
d000b0b6:	f340 8153 	ble.w	d000b360 <main+0x1b08>
d000b0ba:	f8dd c070 	ldr.w	ip, [sp, #112]	; 0x70
d000b0be:	f10c 33ff 	add.w	r3, ip, #4294967295	; 0xffffffff
d000b0c2:	f5b3 5f80 	cmp.w	r3, #4096	; 0x1000
d000b0c6:	f080 814b 	bcs.w	d000b360 <main+0x1b08>
d000b0ca:	f5b1 5f80 	cmp.w	r1, #4096	; 0x1000
d000b0ce:	f300 8147 	bgt.w	d000b360 <main+0x1b08>
d000b0d2:	fb81 230c 	smull	r2, r3, r1, ip
d000b0d6:	f20f 58a0 	addw	r8, pc, #1440	; 0x5a0
d000b0da:	e9d8 7800 	ldrd	r7, r8, [r8]
d000b0de:	4598      	cmp	r8, r3
d000b0e0:	bf08      	it	eq
d000b0e2:	4297      	cmpeq	r7, r2
d000b0e4:	f0c0 813c 	bcc.w	d000b360 <main+0x1b08>
d000b0e8:	f8df 8594 	ldr.w	r8, [pc, #1428]	; d000b680 <main+0x1e28>
d000b0ec:	fb0c f001 	mul.w	r0, ip, r1
d000b0f0:	f8a8 1000 	strh.w	r1, [r8]
d000b0f4:	f8a8 c002 	strh.w	ip, [r8, #2]
d000b0f8:	f000 fd68 	bl	d000bbcc <malloc>
d000b0fc:	f8c8 0004 	str.w	r0, [r8, #4]
d000b100:	2800      	cmp	r0, #0
d000b102:	f000 8124 	beq.w	d000b34e <main+0x1af6>
d000b106:	f108 0008 	add.w	r0, r8, #8
d000b10a:	f7fe f823 	bl	d0009154 <init_rgb332_palette>
d000b10e:	4633      	mov	r3, r6
d000b110:	2200      	movs	r2, #0
d000b112:	e011      	b.n	d000b138 <main+0x18e0>
d000b114:	f813 1c03 	ldrb.w	r1, [r3, #-3]
d000b118:	f813 0c02 	ldrb.w	r0, [r3, #-2]
d000b11c:	f813 5c01 	ldrb.w	r5, [r3, #-1]
d000b120:	f021 011f 	bic.w	r1, r1, #31
d000b124:	08c0      	lsrs	r0, r0, #3
d000b126:	ea41 1195 	orr.w	r1, r1, r5, lsr #6
d000b12a:	f8d8 5004 	ldr.w	r5, [r8, #4]
d000b12e:	f000 001c 	and.w	r0, r0, #28
d000b132:	4301      	orrs	r1, r0
d000b134:	54a9      	strb	r1, [r5, r2]
d000b136:	3201      	adds	r2, #1
d000b138:	f8b8 0000 	ldrh.w	r0, [r8]
d000b13c:	3303      	adds	r3, #3
d000b13e:	f8b8 1002 	ldrh.w	r1, [r8, #2]
d000b142:	fb01 f100 	mul.w	r1, r1, r0
d000b146:	428a      	cmp	r2, r1
d000b148:	d3e4      	bcc.n	d000b114 <main+0x18bc>
d000b14a:	4630      	mov	r0, r6
d000b14c:	f7fa fd78 	bl	d0005c40 <stbi_image_free>
d000b150:	4648      	mov	r0, r9
d000b152:	f000 fd43 	bl	d000bbdc <free>
d000b156:	e4ae      	b.n	d000aab6 <main+0x125e>
d000b158:	9d23      	ldr	r5, [sp, #140]	; 0x8c
d000b15a:	2d00      	cmp	r5, #0
d000b15c:	f340 80ed 	ble.w	d000b33a <main+0x1ae2>
d000b160:	9e24      	ldr	r6, [sp, #144]	; 0x90
d000b162:	1e73      	subs	r3, r6, #1
d000b164:	f5b3 5f80 	cmp.w	r3, #4096	; 0x1000
d000b168:	f080 80e7 	bcs.w	d000b33a <main+0x1ae2>
d000b16c:	f5b5 5f80 	cmp.w	r5, #4096	; 0x1000
d000b170:	bfd4      	ite	le
d000b172:	2700      	movle	r7, #0
d000b174:	2701      	movgt	r7, #1
d000b176:	2f00      	cmp	r7, #0
d000b178:	f040 80df 	bne.w	d000b33a <main+0x1ae2>
d000b17c:	fb85 2306 	smull	r2, r3, r5, r6
d000b180:	f20f 41f4 	addw	r1, pc, #1268	; 0x4f4
d000b184:	e9d1 0100 	ldrd	r0, r1, [r1]
d000b188:	4299      	cmp	r1, r3
d000b18a:	bf08      	it	eq
d000b18c:	4290      	cmpeq	r0, r2
d000b18e:	f0c0 80d4 	bcc.w	d000b33a <main+0x1ae2>
d000b192:	f8df 84ec 	ldr.w	r8, [pc, #1260]	; d000b680 <main+0x1e28>
d000b196:	fb06 f005 	mul.w	r0, r6, r5
d000b19a:	f8a8 5000 	strh.w	r5, [r8]
d000b19e:	f8a8 6002 	strh.w	r6, [r8, #2]
d000b1a2:	f000 fd13 	bl	d000bbcc <malloc>
d000b1a6:	f8c8 0004 	str.w	r0, [r8, #4]
d000b1aa:	2800      	cmp	r0, #0
d000b1ac:	f000 80bb 	beq.w	d000b326 <main+0x1ace>
d000b1b0:	f108 0008 	add.w	r0, r8, #8
d000b1b4:	f7fd ffce 	bl	d0009154 <init_rgb332_palette>
d000b1b8:	f8cd a028 	str.w	sl, [sp, #40]	; 0x28
d000b1bc:	46c2      	mov	sl, r8
d000b1be:	46b8      	mov	r8, r7
d000b1c0:	f8cd 9014 	str.w	r9, [sp, #20]
d000b1c4:	fa1f f388 	uxth.w	r3, r8
d000b1c8:	461a      	mov	r2, r3
d000b1ca:	9309      	str	r3, [sp, #36]	; 0x24
d000b1cc:	f8bd 309c 	ldrh.w	r3, [sp, #156]	; 0x9c
d000b1d0:	4293      	cmp	r3, r2
d000b1d2:	f240 80a2 	bls.w	d000b31a <main+0x1ac2>
d000b1d6:	2300      	movs	r3, #0
d000b1d8:	f8cd 802c 	str.w	r8, [sp, #44]	; 0x2c
d000b1dc:	9303      	str	r3, [sp, #12]
d000b1de:	f8bd 100c 	ldrh.w	r1, [sp, #12]
d000b1e2:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d000b1e6:	428b      	cmp	r3, r1
d000b1e8:	f240 8092 	bls.w	d000b310 <main+0x1ab8>
d000b1ec:	9a29      	ldr	r2, [sp, #164]	; 0xa4
d000b1ee:	9b2a      	ldr	r3, [sp, #168]	; 0xa8
d000b1f0:	fb12 f201 	smulbb	r2, r2, r1
d000b1f4:	9909      	ldr	r1, [sp, #36]	; 0x24
d000b1f6:	fb13 f301 	smulbb	r3, r3, r1
d000b1fa:	b292      	uxth	r2, r2
d000b1fc:	b29b      	uxth	r3, r3
d000b1fe:	9204      	str	r2, [sp, #16]
d000b200:	9307      	str	r3, [sp, #28]
d000b202:	f7fb ff81 	bl	d0007108 <pjpeg_decode_mcu>
d000b206:	4603      	mov	r3, r0
d000b208:	2800      	cmp	r0, #0
d000b20a:	d178      	bne.n	d000b2fe <main+0x1aa6>
d000b20c:	4606      	mov	r6, r0
d000b20e:	b2b1      	uxth	r1, r6
d000b210:	f8bd 30a8 	ldrh.w	r3, [sp, #168]	; 0xa8
d000b214:	428b      	cmp	r3, r1
d000b216:	d96e      	bls.n	d000b2f6 <main+0x1a9e>
d000b218:	9b07      	ldr	r3, [sp, #28]
d000b21a:	f8ba 2002 	ldrh.w	r2, [sl, #2]
d000b21e:	440b      	add	r3, r1
d000b220:	b29b      	uxth	r3, r3
d000b222:	429a      	cmp	r2, r3
d000b224:	d967      	bls.n	d000b2f6 <main+0x1a9e>
d000b226:	08cc      	lsrs	r4, r1, #3
d000b228:	f001 0c07 	and.w	ip, r1, #7
d000b22c:	f8ba 5000 	ldrh.w	r5, [sl]
d000b230:	ea4f 0ec1 	mov.w	lr, r1, lsl #3
d000b234:	eb0c 1704 	add.w	r7, ip, r4, lsl #4
d000b238:	f8da 2004 	ldr.w	r2, [sl, #4]
d000b23c:	0064      	lsls	r4, r4, #1
d000b23e:	2000      	movs	r0, #0
d000b240:	00ff      	lsls	r7, r7, #3
d000b242:	fb03 2505 	mla	r5, r3, r5, r2
d000b246:	fa1f fe8e 	uxth.w	lr, lr
d000b24a:	b2bb      	uxth	r3, r7
d000b24c:	4637      	mov	r7, r6
d000b24e:	9308      	str	r3, [sp, #32]
d000b250:	e010      	b.n	d000b274 <main+0x1a1c>
d000b252:	9e2c      	ldr	r6, [sp, #176]	; 0xb0
d000b254:	f028 081f 	bic.w	r8, r8, #31
d000b258:	f816 9003 	ldrb.w	r9, [r6, r3]
d000b25c:	9e2d      	ldr	r6, [sp, #180]	; 0xb4
d000b25e:	ea4f 09d9 	mov.w	r9, r9, lsr #3
d000b262:	5cf3      	ldrb	r3, [r6, r3]
d000b264:	f009 091c 	and.w	r9, r9, #28
d000b268:	ea48 1393 	orr.w	r3, r8, r3, lsr #6
d000b26c:	ea43 0309 	orr.w	r3, r3, r9
d000b270:	54ab      	strb	r3, [r5, r2]
d000b272:	3001      	adds	r0, #1
d000b274:	b283      	uxth	r3, r0
d000b276:	f8bd 20a4 	ldrh.w	r2, [sp, #164]	; 0xa4
d000b27a:	429a      	cmp	r2, r3
d000b27c:	d938      	bls.n	d000b2f0 <main+0x1a98>
d000b27e:	9a04      	ldr	r2, [sp, #16]
d000b280:	f8ba 6000 	ldrh.w	r6, [sl]
d000b284:	441a      	add	r2, r3
d000b286:	b292      	uxth	r2, r2
d000b288:	4296      	cmp	r6, r2
d000b28a:	d931      	bls.n	d000b2f0 <main+0x1a98>
d000b28c:	f89d 60a0 	ldrb.w	r6, [sp, #160]	; 0xa0
d000b290:	2e03      	cmp	r6, #3
d000b292:	d029      	beq.n	d000b2e8 <main+0x1a90>
d000b294:	2e04      	cmp	r6, #4
d000b296:	d01d      	beq.n	d000b2d4 <main+0x1a7c>
d000b298:	2e02      	cmp	r6, #2
d000b29a:	d012      	beq.n	d000b2c2 <main+0x1a6a>
d000b29c:	4473      	add	r3, lr
d000b29e:	b29b      	uxth	r3, r3
d000b2a0:	9e25      	ldr	r6, [sp, #148]	; 0x94
d000b2a2:	2e01      	cmp	r6, #1
d000b2a4:	9e2b      	ldr	r6, [sp, #172]	; 0xac
d000b2a6:	f816 8003 	ldrb.w	r8, [r6, r3]
d000b2aa:	d1d2      	bne.n	d000b252 <main+0x19fa>
d000b2ac:	f028 031f 	bic.w	r3, r8, #31
d000b2b0:	ea4f 06d8 	mov.w	r6, r8, lsr #3
d000b2b4:	ea43 1398 	orr.w	r3, r3, r8, lsr #6
d000b2b8:	f006 061c 	and.w	r6, r6, #28
d000b2bc:	4333      	orrs	r3, r6
d000b2be:	54ab      	strb	r3, [r5, r2]
d000b2c0:	e7d7      	b.n	d000b272 <main+0x1a1a>
d000b2c2:	08de      	lsrs	r6, r3, #3
d000b2c4:	f003 0307 	and.w	r3, r3, #7
d000b2c8:	eb01 06c6 	add.w	r6, r1, r6, lsl #3
d000b2cc:	eb03 03c6 	add.w	r3, r3, r6, lsl #3
d000b2d0:	b29b      	uxth	r3, r3
d000b2d2:	e7e5      	b.n	d000b2a0 <main+0x1a48>
d000b2d4:	eb04 06d3 	add.w	r6, r4, r3, lsr #3
d000b2d8:	f003 0307 	and.w	r3, r3, #7
d000b2dc:	eb0c 06c6 	add.w	r6, ip, r6, lsl #3
d000b2e0:	eb03 03c6 	add.w	r3, r3, r6, lsl #3
d000b2e4:	b29b      	uxth	r3, r3
d000b2e6:	e7db      	b.n	d000b2a0 <main+0x1a48>
d000b2e8:	9e08      	ldr	r6, [sp, #32]
d000b2ea:	4433      	add	r3, r6
d000b2ec:	b29b      	uxth	r3, r3
d000b2ee:	e7d7      	b.n	d000b2a0 <main+0x1a48>
d000b2f0:	463e      	mov	r6, r7
d000b2f2:	3601      	adds	r6, #1
d000b2f4:	e78b      	b.n	d000b20e <main+0x19b6>
d000b2f6:	9b03      	ldr	r3, [sp, #12]
d000b2f8:	3301      	adds	r3, #1
d000b2fa:	9303      	str	r3, [sp, #12]
d000b2fc:	e76f      	b.n	d000b1de <main+0x1986>
d000b2fe:	4ac8      	ldr	r2, [pc, #800]	; (d000b620 <main+0x1dc8>)
d000b300:	21a0      	movs	r1, #160	; 0xa0
d000b302:	48c8      	ldr	r0, [pc, #800]	; (d000b624 <main+0x1dcc>)
d000b304:	f8dd 9014 	ldr.w	r9, [sp, #20]
d000b308:	f001 f980 	bl	d000c60c <sniprintf>
d000b30c:	f7fe bfff 	b.w	d000a30e <main+0xab6>
d000b310:	f8dd 802c 	ldr.w	r8, [sp, #44]	; 0x2c
d000b314:	f108 0801 	add.w	r8, r8, #1
d000b318:	e754      	b.n	d000b1c4 <main+0x196c>
d000b31a:	46d0      	mov	r8, sl
d000b31c:	f8dd 9014 	ldr.w	r9, [sp, #20]
d000b320:	f8dd a028 	ldr.w	sl, [sp, #40]	; 0x28
d000b324:	e68a      	b.n	d000b03c <main+0x17e4>
d000b326:	48c0      	ldr	r0, [pc, #768]	; (d000b628 <main+0x1dd0>)
d000b328:	f7fe f8bc 	bl	d00094a4 <set_status>
d000b32c:	4648      	mov	r0, r9
d000b32e:	f000 fc55 	bl	d000bbdc <free>
d000b332:	f7fe f99f 	bl	d0009674 <free_image.constprop.0>
d000b336:	f7fe bdd2 	b.w	d0009ede <main+0x686>
d000b33a:	48bc      	ldr	r0, [pc, #752]	; (d000b62c <main+0x1dd4>)
d000b33c:	f7fe f8b2 	bl	d00094a4 <set_status>
d000b340:	4648      	mov	r0, r9
d000b342:	f000 fc4b 	bl	d000bbdc <free>
d000b346:	f7fe f995 	bl	d0009674 <free_image.constprop.0>
d000b34a:	f7fe bdc8 	b.w	d0009ede <main+0x686>
d000b34e:	4630      	mov	r0, r6
d000b350:	f7fa fc76 	bl	d0005c40 <stbi_image_free>
d000b354:	48b4      	ldr	r0, [pc, #720]	; (d000b628 <main+0x1dd0>)
d000b356:	f7fe f8a5 	bl	d00094a4 <set_status>
d000b35a:	4bb5      	ldr	r3, [pc, #724]	; (d000b630 <main+0x1dd8>)
d000b35c:	f7fe bfd1 	b.w	d000a302 <main+0xaaa>
d000b360:	4630      	mov	r0, r6
d000b362:	f7fa fc6d 	bl	d0005c40 <stbi_image_free>
d000b366:	48b1      	ldr	r0, [pc, #708]	; (d000b62c <main+0x1dd4>)
d000b368:	f7fe f89c 	bl	d00094a4 <set_status>
d000b36c:	e7f5      	b.n	d000b35a <main+0x1b02>
d000b36e:	48b1      	ldr	r0, [pc, #708]	; (d000b634 <main+0x1ddc>)
d000b370:	f7fe f898 	bl	d00094a4 <set_status>
d000b374:	e7f1      	b.n	d000b35a <main+0x1b02>
d000b376:	48b0      	ldr	r0, [pc, #704]	; (d000b638 <main+0x1de0>)
d000b378:	f7fe f894 	bl	d00094a4 <set_status>
d000b37c:	e7ed      	b.n	d000b35a <main+0x1b02>
d000b37e:	2a03      	cmp	r2, #3
d000b380:	9b05      	ldr	r3, [sp, #20]
d000b382:	d05b      	beq.n	d000b43c <main+0x1be4>
d000b384:	2b10      	cmp	r3, #16
d000b386:	f04f 0300 	mov.w	r3, #0
d000b38a:	f47e aef3 	bne.w	d000a174 <main+0x91c>
d000b38e:	241f      	movs	r4, #31
d000b390:	f44f 7578 	mov.w	r5, #992	; 0x3e0
d000b394:	f44f 47f8 	mov.w	r7, #31744	; 0x7c00
d000b398:	f7fe befa 	b.w	d000a190 <main+0x938>
d000b39c:	48a7      	ldr	r0, [pc, #668]	; (d000b63c <main+0x1de4>)
d000b39e:	f7fe f881 	bl	d00094a4 <set_status>
d000b3a2:	4648      	mov	r0, r9
d000b3a4:	f000 fc1a 	bl	d000bbdc <free>
d000b3a8:	f7fe f964 	bl	d0009674 <free_image.constprop.0>
d000b3ac:	f7fe bd97 	b.w	d0009ede <main+0x686>
d000b3b0:	48a3      	ldr	r0, [pc, #652]	; (d000b640 <main+0x1de8>)
d000b3b2:	f7fe f877 	bl	d00094a4 <set_status>
d000b3b6:	4648      	mov	r0, r9
d000b3b8:	f000 fc10 	bl	d000bbdc <free>
d000b3bc:	f7fe f95a 	bl	d0009674 <free_image.constprop.0>
d000b3c0:	f7fe bd8d 	b.w	d0009ede <main+0x686>
d000b3c4:	489f      	ldr	r0, [pc, #636]	; (d000b644 <main+0x1dec>)
d000b3c6:	f7fe f86d 	bl	d00094a4 <set_status>
d000b3ca:	4648      	mov	r0, r9
d000b3cc:	f000 fc06 	bl	d000bbdc <free>
d000b3d0:	f7fe f950 	bl	d0009674 <free_image.constprop.0>
d000b3d4:	f7fe bd83 	b.w	d0009ede <main+0x686>
d000b3d8:	489b      	ldr	r0, [pc, #620]	; (d000b648 <main+0x1df0>)
d000b3da:	f7fe f863 	bl	d00094a4 <set_status>
d000b3de:	4648      	mov	r0, r9
d000b3e0:	f000 fbfc 	bl	d000bbdc <free>
d000b3e4:	f7fe f946 	bl	d0009674 <free_image.constprop.0>
d000b3e8:	f7fe bd79 	b.w	d0009ede <main+0x686>
d000b3ec:	4897      	ldr	r0, [pc, #604]	; (d000b64c <main+0x1df4>)
d000b3ee:	f7fe f859 	bl	d00094a4 <set_status>
d000b3f2:	4648      	mov	r0, r9
d000b3f4:	f000 fbf2 	bl	d000bbdc <free>
d000b3f8:	f7fe f93c 	bl	d0009674 <free_image.constprop.0>
d000b3fc:	f7fe bd6f 	b.w	d0009ede <main+0x686>
d000b400:	4893      	ldr	r0, [pc, #588]	; (d000b650 <main+0x1df8>)
d000b402:	f7fe f84f 	bl	d00094a4 <set_status>
d000b406:	4648      	mov	r0, r9
d000b408:	f000 fbe8 	bl	d000bbdc <free>
d000b40c:	f7fe f932 	bl	d0009674 <free_image.constprop.0>
d000b410:	f7fe bd65 	b.w	d0009ede <main+0x686>
d000b414:	488f      	ldr	r0, [pc, #572]	; (d000b654 <main+0x1dfc>)
d000b416:	f7fe f845 	bl	d00094a4 <set_status>
d000b41a:	4648      	mov	r0, r9
d000b41c:	f000 fbde 	bl	d000bbdc <free>
d000b420:	f7fe f928 	bl	d0009674 <free_image.constprop.0>
d000b424:	f7fe bd5b 	b.w	d0009ede <main+0x686>
d000b428:	488b      	ldr	r0, [pc, #556]	; (d000b658 <main+0x1e00>)
d000b42a:	f7fe f83b 	bl	d00094a4 <set_status>
d000b42e:	4648      	mov	r0, r9
d000b430:	f000 fbd4 	bl	d000bbdc <free>
d000b434:	f7fe f91e 	bl	d0009674 <free_image.constprop.0>
d000b438:	f7fe bd51 	b.w	d0009ede <main+0x686>
d000b43c:	2b10      	cmp	r3, #16
d000b43e:	d005      	beq.n	d000b44c <main+0x1bf4>
d000b440:	f1a3 0520 	sub.w	r5, r3, #32
d000b444:	426b      	negs	r3, r5
d000b446:	416b      	adcs	r3, r5
d000b448:	2b00      	cmp	r3, #0
d000b44a:	d0a0      	beq.n	d000b38e <main+0x1b36>
d000b44c:	2c33      	cmp	r4, #51	; 0x33
d000b44e:	d819      	bhi.n	d000b484 <main+0x1c2c>
d000b450:	2e41      	cmp	r6, #65	; 0x41
d000b452:	d817      	bhi.n	d000b484 <main+0x1c2c>
d000b454:	2300      	movs	r3, #0
d000b456:	241f      	movs	r4, #31
d000b458:	f44f 7578 	mov.w	r5, #992	; 0x3e0
d000b45c:	f44f 47f8 	mov.w	r7, #31744	; 0x7c00
d000b460:	f7fe be96 	b.w	d000a190 <main+0x938>
d000b464:	487d      	ldr	r0, [pc, #500]	; (d000b65c <main+0x1e04>)
d000b466:	f7fe f81d 	bl	d00094a4 <set_status>
d000b46a:	4648      	mov	r0, r9
d000b46c:	f000 fbb6 	bl	d000bbdc <free>
d000b470:	f7fe f900 	bl	d0009674 <free_image.constprop.0>
d000b474:	f7fe bd33 	b.w	d0009ede <main+0x686>
d000b478:	4253      	negs	r3, r2
d000b47a:	9303      	str	r3, [sp, #12]
d000b47c:	2301      	movs	r3, #1
d000b47e:	9307      	str	r3, [sp, #28]
d000b480:	f7fe be2e 	b.w	d000a0e0 <main+0x888>
d000b484:	f8b9 203c 	ldrh.w	r2, [r9, #60]	; 0x3c
d000b488:	2300      	movs	r3, #0
d000b48a:	f8b9 503a 	ldrh.w	r5, [r9, #58]	; 0x3a
d000b48e:	f8b9 7036 	ldrh.w	r7, [r9, #54]	; 0x36
d000b492:	f8b9 1038 	ldrh.w	r1, [r9, #56]	; 0x38
d000b496:	ea45 4502 	orr.w	r5, r5, r2, lsl #16
d000b49a:	f8b9 403e 	ldrh.w	r4, [r9, #62]	; 0x3e
d000b49e:	f8b9 2040 	ldrh.w	r2, [r9, #64]	; 0x40
d000b4a2:	ea47 4701 	orr.w	r7, r7, r1, lsl #16
d000b4a6:	ea44 4402 	orr.w	r4, r4, r2, lsl #16
d000b4aa:	f7fe be71 	b.w	d000a190 <main+0x938>
d000b4ae:	f89b 3004 	ldrb.w	r3, [fp, #4]
d000b4b2:	f89b 2005 	ldrb.w	r2, [fp, #5]
d000b4b6:	f89b 1006 	ldrb.w	r1, [fp, #6]
d000b4ba:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d000b4be:	f89b 2007 	ldrb.w	r2, [fp, #7]
d000b4c2:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d000b4c6:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d000b4ca:	681b      	ldr	r3, [r3, #0]
d000b4cc:	68db      	ldr	r3, [r3, #12]
d000b4ce:	4798      	blx	r3
d000b4d0:	4863      	ldr	r0, [pc, #396]	; (d000b660 <main+0x1e08>)
d000b4d2:	f7fd ffe7 	bl	d00094a4 <set_status>
d000b4d6:	f7fe bd02 	b.w	d0009ede <main+0x686>
d000b4da:	4862      	ldr	r0, [pc, #392]	; (d000b664 <main+0x1e0c>)
d000b4dc:	f7fd ffe2 	bl	d00094a4 <set_status>
d000b4e0:	4648      	mov	r0, r9
d000b4e2:	f000 fb7b 	bl	d000bbdc <free>
d000b4e6:	f7fe f8c5 	bl	d0009674 <free_image.constprop.0>
d000b4ea:	f7fe bcf8 	b.w	d0009ede <main+0x686>
d000b4ee:	485e      	ldr	r0, [pc, #376]	; (d000b668 <main+0x1e10>)
d000b4f0:	f7fd ffd8 	bl	d00094a4 <set_status>
d000b4f4:	4648      	mov	r0, r9
d000b4f6:	f000 fb71 	bl	d000bbdc <free>
d000b4fa:	f7fe f8bb 	bl	d0009674 <free_image.constprop.0>
d000b4fe:	f7fe bcee 	b.w	d0009ede <main+0x686>
d000b502:	485a      	ldr	r0, [pc, #360]	; (d000b66c <main+0x1e14>)
d000b504:	f7fd ffce 	bl	d00094a4 <set_status>
d000b508:	4648      	mov	r0, r9
d000b50a:	f000 fb67 	bl	d000bbdc <free>
d000b50e:	f7fe f8b1 	bl	d0009674 <free_image.constprop.0>
d000b512:	f7fe bce4 	b.w	d0009ede <main+0x686>
d000b516:	4856      	ldr	r0, [pc, #344]	; (d000b670 <main+0x1e18>)
d000b518:	f7fd ffc4 	bl	d00094a4 <set_status>
d000b51c:	4648      	mov	r0, r9
d000b51e:	f000 fb5d 	bl	d000bbdc <free>
d000b522:	f7fe f8a7 	bl	d0009674 <free_image.constprop.0>
d000b526:	f7fe bcda 	b.w	d0009ede <main+0x686>
d000b52a:	4852      	ldr	r0, [pc, #328]	; (d000b674 <main+0x1e1c>)
d000b52c:	f7fd ffba 	bl	d00094a4 <set_status>
d000b530:	4648      	mov	r0, r9
d000b532:	f000 fb53 	bl	d000bbdc <free>
d000b536:	f7fe f89d 	bl	d0009674 <free_image.constprop.0>
d000b53a:	f7fe bcd0 	b.w	d0009ede <main+0x686>
d000b53e:	2b2c      	cmp	r3, #44	; 0x2c
d000b540:	9016      	str	r0, [sp, #88]	; 0x58
d000b542:	f040 828c 	bne.w	d000ba5e <main+0x2206>
d000b546:	f104 030a 	add.w	r3, r4, #10
d000b54a:	429e      	cmp	r6, r3
d000b54c:	f0c0 827d 	bcc.w	d000ba4a <main+0x21f2>
d000b550:	1ce0      	adds	r0, r4, #3
d000b552:	1de1      	adds	r1, r4, #7
d000b554:	eb09 0502 	add.w	r5, r9, r2
d000b558:	3405      	adds	r4, #5
d000b55a:	eb09 0c00 	add.w	ip, r9, r0
d000b55e:	eb09 0701 	add.w	r7, r9, r1
d000b562:	f819 0000 	ldrb.w	r0, [r9, r0]
d000b566:	f89c c001 	ldrb.w	ip, [ip, #1]
d000b56a:	f819 1001 	ldrb.w	r1, [r9, r1]
d000b56e:	ea40 200c 	orr.w	r0, r0, ip, lsl #8
d000b572:	9508      	str	r5, [sp, #32]
d000b574:	787f      	ldrb	r7, [r7, #1]
d000b576:	eb09 0504 	add.w	r5, r9, r4
d000b57a:	900e      	str	r0, [sp, #56]	; 0x38
d000b57c:	7868      	ldrb	r0, [r5, #1]
d000b57e:	ea41 2507 	orr.w	r5, r1, r7, lsl #8
d000b582:	9908      	ldr	r1, [sp, #32]
d000b584:	f819 4004 	ldrb.w	r4, [r9, r4]
d000b588:	7849      	ldrb	r1, [r1, #1]
d000b58a:	f819 2002 	ldrb.w	r2, [r9, r2]
d000b58e:	9507      	str	r5, [sp, #28]
d000b590:	ea42 2201 	orr.w	r2, r2, r1, lsl #8
d000b594:	ea54 2100 	orrs.w	r1, r4, r0, lsl #8
d000b598:	9214      	str	r2, [sp, #80]	; 0x50
d000b59a:	9115      	str	r1, [sp, #84]	; 0x54
d000b59c:	f000 8241 	beq.w	d000ba22 <main+0x21ca>
d000b5a0:	2d00      	cmp	r5, #0
d000b5a2:	f000 823e 	beq.w	d000ba22 <main+0x21ca>
d000b5a6:	9903      	ldr	r1, [sp, #12]
d000b5a8:	4291      	cmp	r1, r2
d000b5aa:	f240 823a 	bls.w	d000ba22 <main+0x21ca>
d000b5ae:	9a04      	ldr	r2, [sp, #16]
d000b5b0:	980e      	ldr	r0, [sp, #56]	; 0x38
d000b5b2:	4282      	cmp	r2, r0
d000b5b4:	f240 8235 	bls.w	d000ba22 <main+0x21ca>
d000b5b8:	f99e 2009 	ldrsb.w	r2, [lr, #9]
d000b5bc:	f89e 1009 	ldrb.w	r1, [lr, #9]
d000b5c0:	2a00      	cmp	r2, #0
d000b5c2:	9109      	str	r1, [sp, #36]	; 0x24
d000b5c4:	f2c0 8206 	blt.w	d000b9d4 <main+0x217c>
d000b5c8:	429e      	cmp	r6, r3
d000b5ca:	f240 8196 	bls.w	d000b8fa <main+0x20a2>
d000b5ce:	1c5c      	adds	r4, r3, #1
d000b5d0:	2700      	movs	r7, #0
d000b5d2:	4622      	mov	r2, r4
d000b5d4:	e007      	b.n	d000b5e6 <main+0x1d8e>
d000b5d6:	f819 0002 	ldrb.w	r0, [r9, r2]
d000b5da:	180a      	adds	r2, r1, r0
d000b5dc:	b140      	cbz	r0, d000b5f0 <main+0x1d98>
d000b5de:	4296      	cmp	r6, r2
d000b5e0:	4407      	add	r7, r0
d000b5e2:	f0c0 8180 	bcc.w	d000b8e6 <main+0x208e>
d000b5e6:	4296      	cmp	r6, r2
d000b5e8:	f102 0101 	add.w	r1, r2, #1
d000b5ec:	d8f3      	bhi.n	d000b5d6 <main+0x1d7e>
d000b5ee:	4611      	mov	r1, r2
d000b5f0:	428e      	cmp	r6, r1
d000b5f2:	f0c0 8178 	bcc.w	d000b8e6 <main+0x208e>
d000b5f6:	fab7 f587 	clz	r5, r7
d000b5fa:	096d      	lsrs	r5, r5, #5
d000b5fc:	2f00      	cmp	r7, #0
d000b5fe:	f000 8172 	beq.w	d000b8e6 <main+0x208e>
d000b602:	f819 3003 	ldrb.w	r3, [r9, r3]
d000b606:	4638      	mov	r0, r7
d000b608:	9303      	str	r3, [sp, #12]
d000b60a:	f000 fadf 	bl	d000bbcc <malloc>
d000b60e:	9008      	str	r0, [sp, #32]
d000b610:	2800      	cmp	r0, #0
d000b612:	f000 8165 	beq.w	d000b8e0 <main+0x2088>
d000b616:	f8cd 8010 	str.w	r8, [sp, #16]
d000b61a:	46b8      	mov	r8, r7
d000b61c:	4637      	mov	r7, r6
d000b61e:	e03b      	b.n	d000b698 <main+0x1e40>
d000b620:	d000dcdc 	.word	0xd000dcdc
d000b624:	d000f018 	.word	0xd000f018
d000b628:	d000dcb0 	.word	0xd000dcb0
d000b62c:	d000dc8c 	.word	0xd000dc8c
d000b630:	d000d698 	.word	0xd000d698
d000b634:	d000dc6c 	.word	0xd000dc6c
d000b638:	d000dc54 	.word	0xd000dc54
d000b63c:	d000d834 	.word	0xd000d834
d000b640:	d000d850 	.word	0xd000d850
d000b644:	d000d890 	.word	0xd000d890
d000b648:	d000db20 	.word	0xd000db20
d000b64c:	d000da70 	.word	0xd000da70
d000b650:	d000d8d4 	.word	0xd000d8d4
d000b654:	d000d808 	.word	0xd000d808
d000b658:	d000d7e0 	.word	0xd000d7e0
d000b65c:	d000d7bc 	.word	0xd000d7bc
d000b660:	d000d74c 	.word	0xd000d74c
d000b664:	d000db08 	.word	0xd000db08
d000b668:	d000dae8 	.word	0xd000dae8
d000b66c:	d000da90 	.word	0xd000da90
d000b670:	d000dab4 	.word	0xd000dab4
d000b674:	d000dc38 	.word	0xd000dc38
d000b678:	004c4b40 	.word	0x004c4b40
d000b67c:	00000000 	.word	0x00000000
d000b680:	d000ec10 	.word	0xd000ec10
d000b684:	f819 4004 	ldrb.w	r4, [r9, r4]
d000b688:	eb09 0106 	add.w	r1, r9, r6
d000b68c:	4622      	mov	r2, r4
d000b68e:	b154      	cbz	r4, d000b6a6 <main+0x1e4e>
d000b690:	4425      	add	r5, r4
d000b692:	4434      	add	r4, r6
d000b694:	f000 fab8 	bl	d000bc08 <memcpy>
d000b698:	9b08      	ldr	r3, [sp, #32]
d000b69a:	42a7      	cmp	r7, r4
d000b69c:	f104 0601 	add.w	r6, r4, #1
d000b6a0:	eb03 0005 	add.w	r0, r3, r5
d000b6a4:	d8ee      	bhi.n	d000b684 <main+0x1e2c>
d000b6a6:	9b03      	ldr	r3, [sp, #12]
d000b6a8:	4647      	mov	r7, r8
d000b6aa:	f8dd 8010 	ldr.w	r8, [sp, #16]
d000b6ae:	3b02      	subs	r3, #2
d000b6b0:	2b06      	cmp	r3, #6
d000b6b2:	f200 8142 	bhi.w	d000b93a <main+0x20e2>
d000b6b6:	f44f 5000 	mov.w	r0, #8192	; 0x2000
d000b6ba:	f000 fa87 	bl	d000bbcc <malloc>
d000b6be:	4603      	mov	r3, r0
d000b6c0:	f44f 5080 	mov.w	r0, #4096	; 0x1000
d000b6c4:	461e      	mov	r6, r3
d000b6c6:	9304      	str	r3, [sp, #16]
d000b6c8:	f000 fa80 	bl	d000bbcc <malloc>
d000b6cc:	4605      	mov	r5, r0
d000b6ce:	f44f 5080 	mov.w	r0, #4096	; 0x1000
d000b6d2:	f000 fa7b 	bl	d000bbcc <malloc>
d000b6d6:	2d00      	cmp	r5, #0
d000b6d8:	bf18      	it	ne
d000b6da:	2e00      	cmpne	r6, #0
d000b6dc:	4604      	mov	r4, r0
d000b6de:	f000 8116 	beq.w	d000b90e <main+0x20b6>
d000b6e2:	fab0 f380 	clz	r3, r0
d000b6e6:	095b      	lsrs	r3, r3, #5
d000b6e8:	2800      	cmp	r0, #0
d000b6ea:	f000 8110 	beq.w	d000b90e <main+0x20b6>
d000b6ee:	2201      	movs	r2, #1
d000b6f0:	9903      	ldr	r1, [sp, #12]
d000b6f2:	461e      	mov	r6, r3
d000b6f4:	1888      	adds	r0, r1, r2
d000b6f6:	fa02 f101 	lsl.w	r1, r2, r1
d000b6fa:	b2c0      	uxtb	r0, r0
d000b6fc:	b289      	uxth	r1, r1
d000b6fe:	4082      	lsls	r2, r0
d000b700:	9011      	str	r0, [sp, #68]	; 0x44
d000b702:	1c48      	adds	r0, r1, #1
d000b704:	910a      	str	r1, [sp, #40]	; 0x28
d000b706:	3a01      	subs	r2, #1
d000b708:	3102      	adds	r1, #2
d000b70a:	b292      	uxth	r2, r2
d000b70c:	9212      	str	r2, [sp, #72]	; 0x48
d000b70e:	b282      	uxth	r2, r0
d000b710:	9217      	str	r2, [sp, #92]	; 0x5c
d000b712:	b28a      	uxth	r2, r1
d000b714:	9210      	str	r2, [sp, #64]	; 0x40
d000b716:	9a04      	ldr	r2, [sp, #16]
d000b718:	54eb      	strb	r3, [r5, r3]
d000b71a:	f822 6013 	strh.w	r6, [r2, r3, lsl #1]
d000b71e:	3301      	adds	r3, #1
d000b720:	990a      	ldr	r1, [sp, #40]	; 0x28
d000b722:	b29a      	uxth	r2, r3
d000b724:	428a      	cmp	r2, r1
d000b726:	d3f6      	bcc.n	d000b716 <main+0x1ebe>
d000b728:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000b72a:	f04f 0c00 	mov.w	ip, #0
d000b72e:	f8cd a024 	str.w	sl, [sp, #36]	; 0x24
d000b732:	f3c3 1380 	ubfx	r3, r3, #6, #1
d000b736:	9910      	ldr	r1, [sp, #64]	; 0x40
d000b738:	46e6      	mov	lr, ip
d000b73a:	f8cd c014 	str.w	ip, [sp, #20]
d000b73e:	930f      	str	r3, [sp, #60]	; 0x3c
d000b740:	00fb      	lsls	r3, r7, #3
d000b742:	f64f 77ff 	movw	r7, #65535	; 0xffff
d000b746:	f8cd c02c 	str.w	ip, [sp, #44]	; 0x2c
d000b74a:	9318      	str	r3, [sp, #96]	; 0x60
d000b74c:	9b12      	ldr	r3, [sp, #72]	; 0x48
d000b74e:	f8cd c034 	str.w	ip, [sp, #52]	; 0x34
d000b752:	930c      	str	r3, [sp, #48]	; 0x30
d000b754:	9b11      	ldr	r3, [sp, #68]	; 0x44
d000b756:	f8cd 900c 	str.w	r9, [sp, #12]
d000b75a:	469a      	mov	sl, r3
d000b75c:	9b0d      	ldr	r3, [sp, #52]	; 0x34
d000b75e:	9a18      	ldr	r2, [sp, #96]	; 0x60
d000b760:	4699      	mov	r9, r3
d000b762:	4453      	add	r3, sl
d000b764:	4293      	cmp	r3, r2
d000b766:	930d      	str	r3, [sp, #52]	; 0x34
d000b768:	f200 80a5 	bhi.w	d000b8b6 <main+0x205e>
d000b76c:	2000      	movs	r0, #0
d000b76e:	9113      	str	r1, [sp, #76]	; 0x4c
d000b770:	4603      	mov	r3, r0
d000b772:	eb09 0600 	add.w	r6, r9, r0
d000b776:	9a08      	ldr	r2, [sp, #32]
d000b778:	08f1      	lsrs	r1, r6, #3
d000b77a:	f006 0607 	and.w	r6, r6, #7
d000b77e:	5c52      	ldrb	r2, [r2, r1]
d000b780:	4132      	asrs	r2, r6
d000b782:	f002 0201 	and.w	r2, r2, #1
d000b786:	4082      	lsls	r2, r0
d000b788:	3001      	adds	r0, #1
d000b78a:	b2c6      	uxtb	r6, r0
d000b78c:	4313      	orrs	r3, r2
d000b78e:	45b2      	cmp	sl, r6
d000b790:	d8ef      	bhi.n	d000b772 <main+0x1f1a>
d000b792:	9a0c      	ldr	r2, [sp, #48]	; 0x30
d000b794:	980a      	ldr	r0, [sp, #40]	; 0x28
d000b796:	4013      	ands	r3, r2
d000b798:	9913      	ldr	r1, [sp, #76]	; 0x4c
d000b79a:	4298      	cmp	r0, r3
d000b79c:	f000 810a 	beq.w	d000b9b4 <main+0x215c>
d000b7a0:	9a17      	ldr	r2, [sp, #92]	; 0x5c
d000b7a2:	429a      	cmp	r2, r3
d000b7a4:	f000 8087 	beq.w	d000b8b6 <main+0x205e>
d000b7a8:	f5b3 5f80 	cmp.w	r3, #4096	; 0x1000
d000b7ac:	f080 80c9 	bcs.w	d000b942 <main+0x20ea>
d000b7b0:	f64f 72ff 	movw	r2, #65535	; 0xffff
d000b7b4:	4297      	cmp	r7, r2
d000b7b6:	d102      	bne.n	d000b7be <main+0x1f66>
d000b7b8:	4298      	cmp	r0, r3
d000b7ba:	f240 80c2 	bls.w	d000b942 <main+0x20ea>
d000b7be:	f64f 72ff 	movw	r2, #65535	; 0xffff
d000b7c2:	4297      	cmp	r7, r2
d000b7c4:	d002      	beq.n	d000b7cc <main+0x1f74>
d000b7c6:	428b      	cmp	r3, r1
d000b7c8:	f200 80bb 	bhi.w	d000b942 <main+0x20ea>
d000b7cc:	f64f 72ff 	movw	r2, #65535	; 0xffff
d000b7d0:	4297      	cmp	r7, r2
d000b7d2:	f000 80f7 	beq.w	d000b9c4 <main+0x216c>
d000b7d6:	428b      	cmp	r3, r1
d000b7d8:	f0c0 80e9 	bcc.w	d000b9ae <main+0x2156>
d000b7dc:	9a05      	ldr	r2, [sp, #20]
d000b7de:	2001      	movs	r0, #1
d000b7e0:	7022      	strb	r2, [r4, #0]
d000b7e2:	463a      	mov	r2, r7
d000b7e4:	eb04 0900 	add.w	r9, r4, r0
d000b7e8:	9305      	str	r3, [sp, #20]
d000b7ea:	e00e      	b.n	d000b80a <main+0x1fb2>
d000b7ec:	f640 73ff 	movw	r3, #4095	; 0xfff
d000b7f0:	4298      	cmp	r0, r3
d000b7f2:	b2b0      	uxth	r0, r6
d000b7f4:	f200 80a5 	bhi.w	d000b942 <main+0x20ea>
d000b7f8:	429a      	cmp	r2, r3
d000b7fa:	f200 80a2 	bhi.w	d000b942 <main+0x20ea>
d000b7fe:	5cae      	ldrb	r6, [r5, r2]
d000b800:	9b04      	ldr	r3, [sp, #16]
d000b802:	f833 2012 	ldrh.w	r2, [r3, r2, lsl #1]
d000b806:	f809 6b01 	strb.w	r6, [r9], #1
d000b80a:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d000b80c:	1c46      	adds	r6, r0, #1
d000b80e:	4293      	cmp	r3, r2
d000b810:	d9ec      	bls.n	d000b7ec <main+0x1f94>
d000b812:	5caa      	ldrb	r2, [r5, r2]
d000b814:	f5b1 5f80 	cmp.w	r1, #4096	; 0x1000
d000b818:	9b05      	ldr	r3, [sp, #20]
d000b81a:	9205      	str	r2, [sp, #20]
d000b81c:	d212      	bcs.n	d000b844 <main+0x1fec>
d000b81e:	f04f 0901 	mov.w	r9, #1
d000b822:	9a04      	ldr	r2, [sp, #16]
d000b824:	eb01 0609 	add.w	r6, r1, r9
d000b828:	f822 7011 	strh.w	r7, [r2, r1, lsl #1]
d000b82c:	fa09 f70a 	lsl.w	r7, r9, sl
d000b830:	9a05      	ldr	r2, [sp, #20]
d000b832:	b2bf      	uxth	r7, r7
d000b834:	546a      	strb	r2, [r5, r1]
d000b836:	b2b1      	uxth	r1, r6
d000b838:	428f      	cmp	r7, r1
d000b83a:	d103      	bne.n	d000b844 <main+0x1fec>
d000b83c:	f1ba 0f0b 	cmp.w	sl, #11
d000b840:	f240 808e 	bls.w	d000b960 <main+0x2108>
d000b844:	1c42      	adds	r2, r0, #1
d000b846:	9e05      	ldr	r6, [sp, #20]
d000b848:	9313      	str	r3, [sp, #76]	; 0x4c
d000b84a:	b292      	uxth	r2, r2
d000b84c:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d000b84e:	5426      	strb	r6, [r4, r0]
d000b850:	3a01      	subs	r2, #1
d000b852:	9816      	ldr	r0, [sp, #88]	; 0x58
d000b854:	b292      	uxth	r2, r2
d000b856:	5ca7      	ldrb	r7, [r4, r2]
d000b858:	42b8      	cmp	r0, r7
d000b85a:	d014      	beq.n	d000b886 <main+0x202e>
d000b85c:	9814      	ldr	r0, [sp, #80]	; 0x50
d000b85e:	f8b8 9000 	ldrh.w	r9, [r8]
d000b862:	4418      	add	r0, r3
d000b864:	4548      	cmp	r0, r9
d000b866:	900b      	str	r0, [sp, #44]	; 0x2c
d000b868:	da0d      	bge.n	d000b886 <main+0x202e>
d000b86a:	980e      	ldr	r0, [sp, #56]	; 0x38
d000b86c:	eb00 060e 	add.w	r6, r0, lr
d000b870:	f8b8 0002 	ldrh.w	r0, [r8, #2]
d000b874:	4286      	cmp	r6, r0
d000b876:	9619      	str	r6, [sp, #100]	; 0x64
d000b878:	da05      	bge.n	d000b886 <main+0x202e>
d000b87a:	f8d8 0004 	ldr.w	r0, [r8, #4]
d000b87e:	fb09 0006 	mla	r0, r9, r6, r0
d000b882:	9e0b      	ldr	r6, [sp, #44]	; 0x2c
d000b884:	5587      	strb	r7, [r0, r6]
d000b886:	1c58      	adds	r0, r3, #1
d000b888:	b283      	uxth	r3, r0
d000b88a:	9815      	ldr	r0, [sp, #84]	; 0x54
d000b88c:	4298      	cmp	r0, r3
d000b88e:	d807      	bhi.n	d000b8a0 <main+0x2048>
d000b890:	9b0f      	ldr	r3, [sp, #60]	; 0x3c
d000b892:	2b00      	cmp	r3, #0
d000b894:	d16e      	bne.n	d000b974 <main+0x211c>
d000b896:	f10e 0e01 	add.w	lr, lr, #1
d000b89a:	9b0f      	ldr	r3, [sp, #60]	; 0x3c
d000b89c:	fa1f fe8e 	uxth.w	lr, lr
d000b8a0:	b112      	cbz	r2, d000b8a8 <main+0x2050>
d000b8a2:	9807      	ldr	r0, [sp, #28]
d000b8a4:	4570      	cmp	r0, lr
d000b8a6:	d8d3      	bhi.n	d000b850 <main+0x1ff8>
d000b8a8:	930b      	str	r3, [sp, #44]	; 0x2c
d000b8aa:	9b13      	ldr	r3, [sp, #76]	; 0x4c
d000b8ac:	461f      	mov	r7, r3
d000b8ae:	9b07      	ldr	r3, [sp, #28]
d000b8b0:	4573      	cmp	r3, lr
d000b8b2:	f63f af53 	bhi.w	d000b75c <main+0x1f04>
d000b8b6:	ab1d      	add	r3, sp, #116	; 0x74
d000b8b8:	9804      	ldr	r0, [sp, #16]
d000b8ba:	f8dd a024 	ldr.w	sl, [sp, #36]	; 0x24
d000b8be:	ee08 3a90 	vmov	s17, r3
d000b8c2:	f8dd 900c 	ldr.w	r9, [sp, #12]
d000b8c6:	f000 f989 	bl	d000bbdc <free>
d000b8ca:	4628      	mov	r0, r5
d000b8cc:	f000 f986 	bl	d000bbdc <free>
d000b8d0:	4620      	mov	r0, r4
d000b8d2:	f000 f983 	bl	d000bbdc <free>
d000b8d6:	9808      	ldr	r0, [sp, #32]
d000b8d8:	f000 f980 	bl	d000bbdc <free>
d000b8dc:	f7ff b9f7 	b.w	d000acce <main+0x1476>
d000b8e0:	488e      	ldr	r0, [pc, #568]	; (d000bb1c <main+0x22c4>)
d000b8e2:	f7fd fddf 	bl	d00094a4 <set_status>
d000b8e6:	488e      	ldr	r0, [pc, #568]	; (d000bb20 <main+0x22c8>)
d000b8e8:	f7fd fddc 	bl	d00094a4 <set_status>
d000b8ec:	4648      	mov	r0, r9
d000b8ee:	f000 f975 	bl	d000bbdc <free>
d000b8f2:	f7fd febf 	bl	d0009674 <free_image.constprop.0>
d000b8f6:	f7fe baf2 	b.w	d0009ede <main+0x686>
d000b8fa:	488a      	ldr	r0, [pc, #552]	; (d000bb24 <main+0x22cc>)
d000b8fc:	f7fd fdd2 	bl	d00094a4 <set_status>
d000b900:	4648      	mov	r0, r9
d000b902:	f000 f96b 	bl	d000bbdc <free>
d000b906:	f7fd feb5 	bl	d0009674 <free_image.constprop.0>
d000b90a:	f7fe bae8 	b.w	d0009ede <main+0x686>
d000b90e:	9804      	ldr	r0, [sp, #16]
d000b910:	f000 f964 	bl	d000bbdc <free>
d000b914:	4628      	mov	r0, r5
d000b916:	f000 f961 	bl	d000bbdc <free>
d000b91a:	4620      	mov	r0, r4
d000b91c:	f000 f95e 	bl	d000bbdc <free>
d000b920:	4881      	ldr	r0, [pc, #516]	; (d000bb28 <main+0x22d0>)
d000b922:	f7fd fdbf 	bl	d00094a4 <set_status>
d000b926:	9808      	ldr	r0, [sp, #32]
d000b928:	f000 f958 	bl	d000bbdc <free>
d000b92c:	4648      	mov	r0, r9
d000b92e:	f000 f955 	bl	d000bbdc <free>
d000b932:	f7fd fe9f 	bl	d0009674 <free_image.constprop.0>
d000b936:	f7fe bad2 	b.w	d0009ede <main+0x686>
d000b93a:	487c      	ldr	r0, [pc, #496]	; (d000bb2c <main+0x22d4>)
d000b93c:	f7fd fdb2 	bl	d00094a4 <set_status>
d000b940:	e7f1      	b.n	d000b926 <main+0x20ce>
d000b942:	9804      	ldr	r0, [sp, #16]
d000b944:	f8dd 900c 	ldr.w	r9, [sp, #12]
d000b948:	f000 f948 	bl	d000bbdc <free>
d000b94c:	4628      	mov	r0, r5
d000b94e:	f000 f945 	bl	d000bbdc <free>
d000b952:	4620      	mov	r0, r4
d000b954:	f000 f942 	bl	d000bbdc <free>
d000b958:	4875      	ldr	r0, [pc, #468]	; (d000bb30 <main+0x22d8>)
d000b95a:	f7fd fda3 	bl	d00094a4 <set_status>
d000b95e:	e7e2      	b.n	d000b926 <main+0x20ce>
d000b960:	eb0a 0609 	add.w	r6, sl, r9
d000b964:	fa5f fa86 	uxtb.w	sl, r6
d000b968:	fa09 f20a 	lsl.w	r2, r9, sl
d000b96c:	3a01      	subs	r2, #1
d000b96e:	b292      	uxth	r2, r2
d000b970:	920c      	str	r2, [sp, #48]	; 0x30
d000b972:	e767      	b.n	d000b844 <main+0x1fec>
d000b974:	4b6f      	ldr	r3, [pc, #444]	; (d000bb34 <main+0x22dc>)
d000b976:	f10c 0001 	add.w	r0, ip, #1
d000b97a:	f813 600c 	ldrb.w	r6, [r3, ip]
d000b97e:	4b6e      	ldr	r3, [pc, #440]	; (d000bb38 <main+0x22e0>)
d000b980:	44b6      	add	lr, r6
d000b982:	fa53 f080 	uxtab	r0, r3, r0
d000b986:	fa1f fe8e 	uxth.w	lr, lr
d000b98a:	e006      	b.n	d000b99a <main+0x2142>
d000b98c:	9e07      	ldr	r6, [sp, #28]
d000b98e:	4576      	cmp	r6, lr
d000b990:	d80b      	bhi.n	d000b9aa <main+0x2152>
d000b992:	fa5f fc83 	uxtb.w	ip, r3
d000b996:	f810 eb01 	ldrb.w	lr, [r0], #1
d000b99a:	f1bc 0f02 	cmp.w	ip, #2
d000b99e:	f10c 0301 	add.w	r3, ip, #1
d000b9a2:	d9f3      	bls.n	d000b98c <main+0x2134>
d000b9a4:	9b07      	ldr	r3, [sp, #28]
d000b9a6:	4573      	cmp	r3, lr
d000b9a8:	d985      	bls.n	d000b8b6 <main+0x205e>
d000b9aa:	2300      	movs	r3, #0
d000b9ac:	e778      	b.n	d000b8a0 <main+0x2048>
d000b9ae:	461a      	mov	r2, r3
d000b9b0:	2000      	movs	r0, #0
d000b9b2:	e717      	b.n	d000b7e4 <main+0x1f8c>
d000b9b4:	9b12      	ldr	r3, [sp, #72]	; 0x48
d000b9b6:	f64f 77ff 	movw	r7, #65535	; 0xffff
d000b9ba:	f8dd a044 	ldr.w	sl, [sp, #68]	; 0x44
d000b9be:	9910      	ldr	r1, [sp, #64]	; 0x40
d000b9c0:	930c      	str	r3, [sp, #48]	; 0x30
d000b9c2:	e774      	b.n	d000b8ae <main+0x2056>
d000b9c4:	5cea      	ldrb	r2, [r5, r3]
d000b9c6:	9313      	str	r3, [sp, #76]	; 0x4c
d000b9c8:	4610      	mov	r0, r2
d000b9ca:	9205      	str	r2, [sp, #20]
d000b9cc:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d000b9ce:	2201      	movs	r2, #1
d000b9d0:	7020      	strb	r0, [r4, #0]
d000b9d2:	e73d      	b.n	d000b850 <main+0x1ff8>
d000b9d4:	f001 0207 	and.w	r2, r1, #7
d000b9d8:	2501      	movs	r5, #1
d000b9da:	2103      	movs	r1, #3
d000b9dc:	442a      	add	r2, r5
d000b9de:	4091      	lsls	r1, r2
d000b9e0:	fa05 f202 	lsl.w	r2, r5, r2
d000b9e4:	440b      	add	r3, r1
d000b9e6:	b297      	uxth	r7, r2
d000b9e8:	429e      	cmp	r6, r3
d000b9ea:	d324      	bcc.n	d000ba36 <main+0x21de>
d000b9ec:	9805      	ldr	r0, [sp, #20]
d000b9ee:	e002      	b.n	d000b9f6 <main+0x219e>
d000b9f0:	29ff      	cmp	r1, #255	; 0xff
d000b9f2:	f63f ade9 	bhi.w	d000b5c8 <main+0x1d70>
d000b9f6:	f89e 200b 	ldrb.w	r2, [lr, #11]
d000b9fa:	b2a9      	uxth	r1, r5
d000b9fc:	f89e c00a 	ldrb.w	ip, [lr, #10]
d000ba00:	3501      	adds	r5, #1
d000ba02:	0212      	lsls	r2, r2, #8
d000ba04:	f89e 400c 	ldrb.w	r4, [lr, #12]
d000ba08:	428f      	cmp	r7, r1
d000ba0a:	f10e 0e03 	add.w	lr, lr, #3
d000ba0e:	ea42 420c 	orr.w	r2, r2, ip, lsl #16
d000ba12:	ea42 0204 	orr.w	r2, r2, r4
d000ba16:	f042 427f 	orr.w	r2, r2, #4278190080	; 0xff000000
d000ba1a:	f840 2b04 	str.w	r2, [r0], #4
d000ba1e:	d8e7      	bhi.n	d000b9f0 <main+0x2198>
d000ba20:	e5d2      	b.n	d000b5c8 <main+0x1d70>
d000ba22:	4846      	ldr	r0, [pc, #280]	; (d000bb3c <main+0x22e4>)
d000ba24:	f7fd fd3e 	bl	d00094a4 <set_status>
d000ba28:	4648      	mov	r0, r9
d000ba2a:	f000 f8d7 	bl	d000bbdc <free>
d000ba2e:	f7fd fe21 	bl	d0009674 <free_image.constprop.0>
d000ba32:	f7fe ba54 	b.w	d0009ede <main+0x686>
d000ba36:	4842      	ldr	r0, [pc, #264]	; (d000bb40 <main+0x22e8>)
d000ba38:	f7fd fd34 	bl	d00094a4 <set_status>
d000ba3c:	4648      	mov	r0, r9
d000ba3e:	f000 f8cd 	bl	d000bbdc <free>
d000ba42:	f7fd fe17 	bl	d0009674 <free_image.constprop.0>
d000ba46:	f7fe ba4a 	b.w	d0009ede <main+0x686>
d000ba4a:	483e      	ldr	r0, [pc, #248]	; (d000bb44 <main+0x22ec>)
d000ba4c:	f7fd fd2a 	bl	d00094a4 <set_status>
d000ba50:	4648      	mov	r0, r9
d000ba52:	f000 f8c3 	bl	d000bbdc <free>
d000ba56:	f7fd fe0d 	bl	d0009674 <free_image.constprop.0>
d000ba5a:	f7fe ba40 	b.w	d0009ede <main+0x686>
d000ba5e:	483a      	ldr	r0, [pc, #232]	; (d000bb48 <main+0x22f0>)
d000ba60:	f7fd fd20 	bl	d00094a4 <set_status>
d000ba64:	4648      	mov	r0, r9
d000ba66:	f000 f8b9 	bl	d000bbdc <free>
d000ba6a:	f7fd fe03 	bl	d0009674 <free_image.constprop.0>
d000ba6e:	f7fe ba36 	b.w	d0009ede <main+0x686>
d000ba72:	460b      	mov	r3, r1
d000ba74:	f7fe bc05 	b.w	d000a282 <main+0xa2a>
d000ba78:	2400      	movs	r4, #0
d000ba7a:	9b03      	ldr	r3, [sp, #12]
d000ba7c:	9d04      	ldr	r5, [sp, #16]
d000ba7e:	1e5f      	subs	r7, r3, #1
d000ba80:	4621      	mov	r1, r4
d000ba82:	9b03      	ldr	r3, [sp, #12]
d000ba84:	428b      	cmp	r3, r1
d000ba86:	f43f aad6 	beq.w	d000b036 <main+0x17de>
d000ba8a:	9b07      	ldr	r3, [sp, #28]
d000ba8c:	2b00      	cmp	r3, #0
d000ba8e:	d143      	bne.n	d000bb18 <main+0x22c0>
d000ba90:	1a7b      	subs	r3, r7, r1
d000ba92:	9808      	ldr	r0, [sp, #32]
d000ba94:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000ba96:	fb03 0202 	mla	r2, r3, r2, r0
d000ba9a:	f8d8 3004 	ldr.w	r3, [r8, #4]
d000ba9e:	2000      	movs	r0, #0
d000baa0:	444a      	add	r2, r9
d000baa2:	4423      	add	r3, r4
d000baa4:	0846      	lsrs	r6, r0, #1
d000baa6:	f010 0f01 	tst.w	r0, #1
d000baaa:	f100 0001 	add.w	r0, r0, #1
d000baae:	f812 c006 	ldrb.w	ip, [r2, r6]
d000bab2:	ea4f 161c 	mov.w	r6, ip, lsr #4
d000bab6:	bf18      	it	ne
d000bab8:	f00c 060f 	andne.w	r6, ip, #15
d000babc:	4285      	cmp	r5, r0
d000babe:	f803 6b01 	strb.w	r6, [r3], #1
d000bac2:	d8ef      	bhi.n	d000baa4 <main+0x224c>
d000bac4:	3101      	adds	r1, #1
d000bac6:	442c      	add	r4, r5
d000bac8:	e7db      	b.n	d000ba82 <main+0x222a>
d000baca:	9b03      	ldr	r3, [sp, #12]
d000bacc:	2400      	movs	r4, #0
d000bace:	9e04      	ldr	r6, [sp, #16]
d000bad0:	e00d      	b.n	d000baee <main+0x2296>
d000bad2:	1e5d      	subs	r5, r3, #1
d000bad4:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000bad6:	4632      	mov	r2, r6
d000bad8:	9f08      	ldr	r7, [sp, #32]
d000bada:	f8d8 0004 	ldr.w	r0, [r8, #4]
d000bade:	fb01 7103 	mla	r1, r1, r3, r7
d000bae2:	4420      	add	r0, r4
d000bae4:	4434      	add	r4, r6
d000bae6:	4449      	add	r1, r9
d000bae8:	f000 f88e 	bl	d000bc08 <memcpy>
d000baec:	462b      	mov	r3, r5
d000baee:	9a03      	ldr	r2, [sp, #12]
d000baf0:	1e5d      	subs	r5, r3, #1
d000baf2:	1ad1      	subs	r1, r2, r3
d000baf4:	2b00      	cmp	r3, #0
d000baf6:	f43f aa9e 	beq.w	d000b036 <main+0x17de>
d000bafa:	9a07      	ldr	r2, [sp, #28]
d000bafc:	2a00      	cmp	r2, #0
d000bafe:	d1e8      	bne.n	d000bad2 <main+0x227a>
d000bb00:	4629      	mov	r1, r5
d000bb02:	e7e7      	b.n	d000bad4 <main+0x227c>
d000bb04:	4811      	ldr	r0, [pc, #68]	; (d000bb4c <main+0x22f4>)
d000bb06:	f7fd fccd 	bl	d00094a4 <set_status>
d000bb0a:	4648      	mov	r0, r9
d000bb0c:	f000 f866 	bl	d000bbdc <free>
d000bb10:	f7fd fdb0 	bl	d0009674 <free_image.constprop.0>
d000bb14:	f7fe b9e3 	b.w	d0009ede <main+0x686>
d000bb18:	460b      	mov	r3, r1
d000bb1a:	e7ba      	b.n	d000ba92 <main+0x223a>
d000bb1c:	d000dbbc 	.word	0xd000dbbc
d000bb20:	d000dd44 	.word	0xd000dd44
d000bb24:	d000dba0 	.word	0xd000dba0
d000bb28:	d000dbf8 	.word	0xd000dbf8
d000bb2c:	d000dbdc 	.word	0xd000dbdc
d000bb30:	d000dd2c 	.word	0xd000dd2c
d000bb34:	d000dd78 	.word	0xd000dd78
d000bb38:	d000dd74 	.word	0xd000dd74
d000bb3c:	d000db60 	.word	0xd000db60
d000bb40:	d000db80 	.word	0xd000db80
d000bb44:	d000db3c 	.word	0xd000db3c
d000bb48:	d000dc18 	.word	0xd000dc18
d000bb4c:	d000d86c 	.word	0xd000d86c

d000bb50 <__assert_func>:
d000bb50:	b51f      	push	{r0, r1, r2, r3, r4, lr}
d000bb52:	4614      	mov	r4, r2
d000bb54:	461a      	mov	r2, r3
d000bb56:	4b09      	ldr	r3, [pc, #36]	; (d000bb7c <__assert_func+0x2c>)
d000bb58:	681b      	ldr	r3, [r3, #0]
d000bb5a:	4605      	mov	r5, r0
d000bb5c:	68d8      	ldr	r0, [r3, #12]
d000bb5e:	b14c      	cbz	r4, d000bb74 <__assert_func+0x24>
d000bb60:	4b07      	ldr	r3, [pc, #28]	; (d000bb80 <__assert_func+0x30>)
d000bb62:	9100      	str	r1, [sp, #0]
d000bb64:	e9cd 3401 	strd	r3, r4, [sp, #4]
d000bb68:	4906      	ldr	r1, [pc, #24]	; (d000bb84 <__assert_func+0x34>)
d000bb6a:	462b      	mov	r3, r5
d000bb6c:	f000 f81c 	bl	d000bba8 <fiprintf>
d000bb70:	f000 fe68 	bl	d000c844 <abort>
d000bb74:	4b04      	ldr	r3, [pc, #16]	; (d000bb88 <__assert_func+0x38>)
d000bb76:	461c      	mov	r4, r3
d000bb78:	e7f3      	b.n	d000bb62 <__assert_func+0x12>
d000bb7a:	bf00      	nop
d000bb7c:	d000de58 	.word	0xd000de58
d000bb80:	d000dd7c 	.word	0xd000dd7c
d000bb84:	d000dd89 	.word	0xd000dd89
d000bb88:	d000ddb7 	.word	0xd000ddb7

d000bb8c <calloc>:
d000bb8c:	4b02      	ldr	r3, [pc, #8]	; (d000bb98 <calloc+0xc>)
d000bb8e:	460a      	mov	r2, r1
d000bb90:	4601      	mov	r1, r0
d000bb92:	6818      	ldr	r0, [r3, #0]
d000bb94:	f000 b84e 	b.w	d000bc34 <_calloc_r>
d000bb98:	d000de58 	.word	0xd000de58

d000bb9c <__errno>:
d000bb9c:	4b01      	ldr	r3, [pc, #4]	; (d000bba4 <__errno+0x8>)
d000bb9e:	6818      	ldr	r0, [r3, #0]
d000bba0:	4770      	bx	lr
d000bba2:	bf00      	nop
d000bba4:	d000de58 	.word	0xd000de58

d000bba8 <fiprintf>:
d000bba8:	b40e      	push	{r1, r2, r3}
d000bbaa:	b503      	push	{r0, r1, lr}
d000bbac:	4601      	mov	r1, r0
d000bbae:	ab03      	add	r3, sp, #12
d000bbb0:	4805      	ldr	r0, [pc, #20]	; (d000bbc8 <fiprintf+0x20>)
d000bbb2:	f853 2b04 	ldr.w	r2, [r3], #4
d000bbb6:	6800      	ldr	r0, [r0, #0]
d000bbb8:	9301      	str	r3, [sp, #4]
d000bbba:	f000 f91f 	bl	d000bdfc <_vfiprintf_r>
d000bbbe:	b002      	add	sp, #8
d000bbc0:	f85d eb04 	ldr.w	lr, [sp], #4
d000bbc4:	b003      	add	sp, #12
d000bbc6:	4770      	bx	lr
d000bbc8:	d000de58 	.word	0xd000de58

d000bbcc <malloc>:
d000bbcc:	4b02      	ldr	r3, [pc, #8]	; (d000bbd8 <malloc+0xc>)
d000bbce:	4601      	mov	r1, r0
d000bbd0:	6818      	ldr	r0, [r3, #0]
d000bbd2:	f000 b88f 	b.w	d000bcf4 <_malloc_r>
d000bbd6:	bf00      	nop
d000bbd8:	d000de58 	.word	0xd000de58

d000bbdc <free>:
d000bbdc:	4b02      	ldr	r3, [pc, #8]	; (d000bbe8 <free+0xc>)
d000bbde:	4601      	mov	r1, r0
d000bbe0:	6818      	ldr	r0, [r3, #0]
d000bbe2:	f000 b837 	b.w	d000bc54 <_free_r>
d000bbe6:	bf00      	nop
d000bbe8:	d000de58 	.word	0xd000de58

d000bbec <memcmp>:
d000bbec:	b530      	push	{r4, r5, lr}
d000bbee:	3901      	subs	r1, #1
d000bbf0:	2400      	movs	r4, #0
d000bbf2:	42a2      	cmp	r2, r4
d000bbf4:	d101      	bne.n	d000bbfa <memcmp+0xe>
d000bbf6:	2000      	movs	r0, #0
d000bbf8:	e005      	b.n	d000bc06 <memcmp+0x1a>
d000bbfa:	5d03      	ldrb	r3, [r0, r4]
d000bbfc:	3401      	adds	r4, #1
d000bbfe:	5d0d      	ldrb	r5, [r1, r4]
d000bc00:	42ab      	cmp	r3, r5
d000bc02:	d0f6      	beq.n	d000bbf2 <memcmp+0x6>
d000bc04:	1b58      	subs	r0, r3, r5
d000bc06:	bd30      	pop	{r4, r5, pc}

d000bc08 <memcpy>:
d000bc08:	440a      	add	r2, r1
d000bc0a:	4291      	cmp	r1, r2
d000bc0c:	f100 33ff 	add.w	r3, r0, #4294967295	; 0xffffffff
d000bc10:	d100      	bne.n	d000bc14 <memcpy+0xc>
d000bc12:	4770      	bx	lr
d000bc14:	b510      	push	{r4, lr}
d000bc16:	f811 4b01 	ldrb.w	r4, [r1], #1
d000bc1a:	f803 4f01 	strb.w	r4, [r3, #1]!
d000bc1e:	4291      	cmp	r1, r2
d000bc20:	d1f9      	bne.n	d000bc16 <memcpy+0xe>
d000bc22:	bd10      	pop	{r4, pc}

d000bc24 <memset>:
d000bc24:	4402      	add	r2, r0
d000bc26:	4603      	mov	r3, r0
d000bc28:	4293      	cmp	r3, r2
d000bc2a:	d100      	bne.n	d000bc2e <memset+0xa>
d000bc2c:	4770      	bx	lr
d000bc2e:	f803 1b01 	strb.w	r1, [r3], #1
d000bc32:	e7f9      	b.n	d000bc28 <memset+0x4>

d000bc34 <_calloc_r>:
d000bc34:	b513      	push	{r0, r1, r4, lr}
d000bc36:	434a      	muls	r2, r1
d000bc38:	4611      	mov	r1, r2
d000bc3a:	9201      	str	r2, [sp, #4]
d000bc3c:	f000 f85a 	bl	d000bcf4 <_malloc_r>
d000bc40:	4604      	mov	r4, r0
d000bc42:	b118      	cbz	r0, d000bc4c <_calloc_r+0x18>
d000bc44:	9a01      	ldr	r2, [sp, #4]
d000bc46:	2100      	movs	r1, #0
d000bc48:	f7ff ffec 	bl	d000bc24 <memset>
d000bc4c:	4620      	mov	r0, r4
d000bc4e:	b002      	add	sp, #8
d000bc50:	bd10      	pop	{r4, pc}
	...

d000bc54 <_free_r>:
d000bc54:	b537      	push	{r0, r1, r2, r4, r5, lr}
d000bc56:	2900      	cmp	r1, #0
d000bc58:	d048      	beq.n	d000bcec <_free_r+0x98>
d000bc5a:	f851 3c04 	ldr.w	r3, [r1, #-4]
d000bc5e:	9001      	str	r0, [sp, #4]
d000bc60:	2b00      	cmp	r3, #0
d000bc62:	f1a1 0404 	sub.w	r4, r1, #4
d000bc66:	bfb8      	it	lt
d000bc68:	18e4      	addlt	r4, r4, r3
d000bc6a:	f001 f87b 	bl	d000cd64 <__malloc_lock>
d000bc6e:	4a20      	ldr	r2, [pc, #128]	; (d000bcf0 <_free_r+0x9c>)
d000bc70:	9801      	ldr	r0, [sp, #4]
d000bc72:	6813      	ldr	r3, [r2, #0]
d000bc74:	4615      	mov	r5, r2
d000bc76:	b933      	cbnz	r3, d000bc86 <_free_r+0x32>
d000bc78:	6063      	str	r3, [r4, #4]
d000bc7a:	6014      	str	r4, [r2, #0]
d000bc7c:	b003      	add	sp, #12
d000bc7e:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d000bc82:	f001 b875 	b.w	d000cd70 <__malloc_unlock>
d000bc86:	42a3      	cmp	r3, r4
d000bc88:	d90b      	bls.n	d000bca2 <_free_r+0x4e>
d000bc8a:	6821      	ldr	r1, [r4, #0]
d000bc8c:	1862      	adds	r2, r4, r1
d000bc8e:	4293      	cmp	r3, r2
d000bc90:	bf04      	itt	eq
d000bc92:	681a      	ldreq	r2, [r3, #0]
d000bc94:	685b      	ldreq	r3, [r3, #4]
d000bc96:	6063      	str	r3, [r4, #4]
d000bc98:	bf04      	itt	eq
d000bc9a:	1852      	addeq	r2, r2, r1
d000bc9c:	6022      	streq	r2, [r4, #0]
d000bc9e:	602c      	str	r4, [r5, #0]
d000bca0:	e7ec      	b.n	d000bc7c <_free_r+0x28>
d000bca2:	461a      	mov	r2, r3
d000bca4:	685b      	ldr	r3, [r3, #4]
d000bca6:	b10b      	cbz	r3, d000bcac <_free_r+0x58>
d000bca8:	42a3      	cmp	r3, r4
d000bcaa:	d9fa      	bls.n	d000bca2 <_free_r+0x4e>
d000bcac:	6811      	ldr	r1, [r2, #0]
d000bcae:	1855      	adds	r5, r2, r1
d000bcb0:	42a5      	cmp	r5, r4
d000bcb2:	d10b      	bne.n	d000bccc <_free_r+0x78>
d000bcb4:	6824      	ldr	r4, [r4, #0]
d000bcb6:	4421      	add	r1, r4
d000bcb8:	1854      	adds	r4, r2, r1
d000bcba:	42a3      	cmp	r3, r4
d000bcbc:	6011      	str	r1, [r2, #0]
d000bcbe:	d1dd      	bne.n	d000bc7c <_free_r+0x28>
d000bcc0:	681c      	ldr	r4, [r3, #0]
d000bcc2:	685b      	ldr	r3, [r3, #4]
d000bcc4:	6053      	str	r3, [r2, #4]
d000bcc6:	4421      	add	r1, r4
d000bcc8:	6011      	str	r1, [r2, #0]
d000bcca:	e7d7      	b.n	d000bc7c <_free_r+0x28>
d000bccc:	d902      	bls.n	d000bcd4 <_free_r+0x80>
d000bcce:	230c      	movs	r3, #12
d000bcd0:	6003      	str	r3, [r0, #0]
d000bcd2:	e7d3      	b.n	d000bc7c <_free_r+0x28>
d000bcd4:	6825      	ldr	r5, [r4, #0]
d000bcd6:	1961      	adds	r1, r4, r5
d000bcd8:	428b      	cmp	r3, r1
d000bcda:	bf04      	itt	eq
d000bcdc:	6819      	ldreq	r1, [r3, #0]
d000bcde:	685b      	ldreq	r3, [r3, #4]
d000bce0:	6063      	str	r3, [r4, #4]
d000bce2:	bf04      	itt	eq
d000bce4:	1949      	addeq	r1, r1, r5
d000bce6:	6021      	streq	r1, [r4, #0]
d000bce8:	6054      	str	r4, [r2, #4]
d000bcea:	e7c7      	b.n	d000bc7c <_free_r+0x28>
d000bcec:	b003      	add	sp, #12
d000bcee:	bd30      	pop	{r4, r5, pc}
d000bcf0:	d000f0b8 	.word	0xd000f0b8

d000bcf4 <_malloc_r>:
d000bcf4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000bcf6:	1ccd      	adds	r5, r1, #3
d000bcf8:	f025 0503 	bic.w	r5, r5, #3
d000bcfc:	3508      	adds	r5, #8
d000bcfe:	2d0c      	cmp	r5, #12
d000bd00:	bf38      	it	cc
d000bd02:	250c      	movcc	r5, #12
d000bd04:	2d00      	cmp	r5, #0
d000bd06:	4606      	mov	r6, r0
d000bd08:	db01      	blt.n	d000bd0e <_malloc_r+0x1a>
d000bd0a:	42a9      	cmp	r1, r5
d000bd0c:	d903      	bls.n	d000bd16 <_malloc_r+0x22>
d000bd0e:	230c      	movs	r3, #12
d000bd10:	6033      	str	r3, [r6, #0]
d000bd12:	2000      	movs	r0, #0
d000bd14:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d000bd16:	f001 f825 	bl	d000cd64 <__malloc_lock>
d000bd1a:	4921      	ldr	r1, [pc, #132]	; (d000bda0 <_malloc_r+0xac>)
d000bd1c:	680a      	ldr	r2, [r1, #0]
d000bd1e:	4614      	mov	r4, r2
d000bd20:	b99c      	cbnz	r4, d000bd4a <_malloc_r+0x56>
d000bd22:	4f20      	ldr	r7, [pc, #128]	; (d000bda4 <_malloc_r+0xb0>)
d000bd24:	683b      	ldr	r3, [r7, #0]
d000bd26:	b923      	cbnz	r3, d000bd32 <_malloc_r+0x3e>
d000bd28:	4621      	mov	r1, r4
d000bd2a:	4630      	mov	r0, r6
d000bd2c:	f7f5 f9e6 	bl	d00010fc <_sbrk_r>
d000bd30:	6038      	str	r0, [r7, #0]
d000bd32:	4629      	mov	r1, r5
d000bd34:	4630      	mov	r0, r6
d000bd36:	f7f5 f9e1 	bl	d00010fc <_sbrk_r>
d000bd3a:	1c43      	adds	r3, r0, #1
d000bd3c:	d123      	bne.n	d000bd86 <_malloc_r+0x92>
d000bd3e:	230c      	movs	r3, #12
d000bd40:	6033      	str	r3, [r6, #0]
d000bd42:	4630      	mov	r0, r6
d000bd44:	f001 f814 	bl	d000cd70 <__malloc_unlock>
d000bd48:	e7e3      	b.n	d000bd12 <_malloc_r+0x1e>
d000bd4a:	6823      	ldr	r3, [r4, #0]
d000bd4c:	1b5b      	subs	r3, r3, r5
d000bd4e:	d417      	bmi.n	d000bd80 <_malloc_r+0x8c>
d000bd50:	2b0b      	cmp	r3, #11
d000bd52:	d903      	bls.n	d000bd5c <_malloc_r+0x68>
d000bd54:	6023      	str	r3, [r4, #0]
d000bd56:	441c      	add	r4, r3
d000bd58:	6025      	str	r5, [r4, #0]
d000bd5a:	e004      	b.n	d000bd66 <_malloc_r+0x72>
d000bd5c:	6863      	ldr	r3, [r4, #4]
d000bd5e:	42a2      	cmp	r2, r4
d000bd60:	bf0c      	ite	eq
d000bd62:	600b      	streq	r3, [r1, #0]
d000bd64:	6053      	strne	r3, [r2, #4]
d000bd66:	4630      	mov	r0, r6
d000bd68:	f001 f802 	bl	d000cd70 <__malloc_unlock>
d000bd6c:	f104 000b 	add.w	r0, r4, #11
d000bd70:	1d23      	adds	r3, r4, #4
d000bd72:	f020 0007 	bic.w	r0, r0, #7
d000bd76:	1ac2      	subs	r2, r0, r3
d000bd78:	d0cc      	beq.n	d000bd14 <_malloc_r+0x20>
d000bd7a:	1a1b      	subs	r3, r3, r0
d000bd7c:	50a3      	str	r3, [r4, r2]
d000bd7e:	e7c9      	b.n	d000bd14 <_malloc_r+0x20>
d000bd80:	4622      	mov	r2, r4
d000bd82:	6864      	ldr	r4, [r4, #4]
d000bd84:	e7cc      	b.n	d000bd20 <_malloc_r+0x2c>
d000bd86:	1cc4      	adds	r4, r0, #3
d000bd88:	f024 0403 	bic.w	r4, r4, #3
d000bd8c:	42a0      	cmp	r0, r4
d000bd8e:	d0e3      	beq.n	d000bd58 <_malloc_r+0x64>
d000bd90:	1a21      	subs	r1, r4, r0
d000bd92:	4630      	mov	r0, r6
d000bd94:	f7f5 f9b2 	bl	d00010fc <_sbrk_r>
d000bd98:	3001      	adds	r0, #1
d000bd9a:	d1dd      	bne.n	d000bd58 <_malloc_r+0x64>
d000bd9c:	e7cf      	b.n	d000bd3e <_malloc_r+0x4a>
d000bd9e:	bf00      	nop
d000bda0:	d000f0b8 	.word	0xd000f0b8
d000bda4:	d000f0bc 	.word	0xd000f0bc

d000bda8 <__sfputc_r>:
d000bda8:	6893      	ldr	r3, [r2, #8]
d000bdaa:	3b01      	subs	r3, #1
d000bdac:	2b00      	cmp	r3, #0
d000bdae:	b410      	push	{r4}
d000bdb0:	6093      	str	r3, [r2, #8]
d000bdb2:	da08      	bge.n	d000bdc6 <__sfputc_r+0x1e>
d000bdb4:	6994      	ldr	r4, [r2, #24]
d000bdb6:	42a3      	cmp	r3, r4
d000bdb8:	db01      	blt.n	d000bdbe <__sfputc_r+0x16>
d000bdba:	290a      	cmp	r1, #10
d000bdbc:	d103      	bne.n	d000bdc6 <__sfputc_r+0x1e>
d000bdbe:	f85d 4b04 	ldr.w	r4, [sp], #4
d000bdc2:	f000 bc7f 	b.w	d000c6c4 <__swbuf_r>
d000bdc6:	6813      	ldr	r3, [r2, #0]
d000bdc8:	1c58      	adds	r0, r3, #1
d000bdca:	6010      	str	r0, [r2, #0]
d000bdcc:	7019      	strb	r1, [r3, #0]
d000bdce:	4608      	mov	r0, r1
d000bdd0:	f85d 4b04 	ldr.w	r4, [sp], #4
d000bdd4:	4770      	bx	lr

d000bdd6 <__sfputs_r>:
d000bdd6:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000bdd8:	4606      	mov	r6, r0
d000bdda:	460f      	mov	r7, r1
d000bddc:	4614      	mov	r4, r2
d000bdde:	18d5      	adds	r5, r2, r3
d000bde0:	42ac      	cmp	r4, r5
d000bde2:	d101      	bne.n	d000bde8 <__sfputs_r+0x12>
d000bde4:	2000      	movs	r0, #0
d000bde6:	e007      	b.n	d000bdf8 <__sfputs_r+0x22>
d000bde8:	f814 1b01 	ldrb.w	r1, [r4], #1
d000bdec:	463a      	mov	r2, r7
d000bdee:	4630      	mov	r0, r6
d000bdf0:	f7ff ffda 	bl	d000bda8 <__sfputc_r>
d000bdf4:	1c43      	adds	r3, r0, #1
d000bdf6:	d1f3      	bne.n	d000bde0 <__sfputs_r+0xa>
d000bdf8:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

d000bdfc <_vfiprintf_r>:
d000bdfc:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d000be00:	460d      	mov	r5, r1
d000be02:	b09d      	sub	sp, #116	; 0x74
d000be04:	4614      	mov	r4, r2
d000be06:	4698      	mov	r8, r3
d000be08:	4606      	mov	r6, r0
d000be0a:	b118      	cbz	r0, d000be14 <_vfiprintf_r+0x18>
d000be0c:	6983      	ldr	r3, [r0, #24]
d000be0e:	b90b      	cbnz	r3, d000be14 <_vfiprintf_r+0x18>
d000be10:	f000 fe3a 	bl	d000ca88 <__sinit>
d000be14:	4b89      	ldr	r3, [pc, #548]	; (d000c03c <_vfiprintf_r+0x240>)
d000be16:	429d      	cmp	r5, r3
d000be18:	d11b      	bne.n	d000be52 <_vfiprintf_r+0x56>
d000be1a:	6875      	ldr	r5, [r6, #4]
d000be1c:	6e6b      	ldr	r3, [r5, #100]	; 0x64
d000be1e:	07d9      	lsls	r1, r3, #31
d000be20:	d405      	bmi.n	d000be2e <_vfiprintf_r+0x32>
d000be22:	89ab      	ldrh	r3, [r5, #12]
d000be24:	059a      	lsls	r2, r3, #22
d000be26:	d402      	bmi.n	d000be2e <_vfiprintf_r+0x32>
d000be28:	6da8      	ldr	r0, [r5, #88]	; 0x58
d000be2a:	f000 fecb 	bl	d000cbc4 <__retarget_lock_acquire_recursive>
d000be2e:	89ab      	ldrh	r3, [r5, #12]
d000be30:	071b      	lsls	r3, r3, #28
d000be32:	d501      	bpl.n	d000be38 <_vfiprintf_r+0x3c>
d000be34:	692b      	ldr	r3, [r5, #16]
d000be36:	b9eb      	cbnz	r3, d000be74 <_vfiprintf_r+0x78>
d000be38:	4629      	mov	r1, r5
d000be3a:	4630      	mov	r0, r6
d000be3c:	f000 fc94 	bl	d000c768 <__swsetup_r>
d000be40:	b1c0      	cbz	r0, d000be74 <_vfiprintf_r+0x78>
d000be42:	6e6b      	ldr	r3, [r5, #100]	; 0x64
d000be44:	07dc      	lsls	r4, r3, #31
d000be46:	d50e      	bpl.n	d000be66 <_vfiprintf_r+0x6a>
d000be48:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000be4c:	b01d      	add	sp, #116	; 0x74
d000be4e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000be52:	4b7b      	ldr	r3, [pc, #492]	; (d000c040 <_vfiprintf_r+0x244>)
d000be54:	429d      	cmp	r5, r3
d000be56:	d101      	bne.n	d000be5c <_vfiprintf_r+0x60>
d000be58:	68b5      	ldr	r5, [r6, #8]
d000be5a:	e7df      	b.n	d000be1c <_vfiprintf_r+0x20>
d000be5c:	4b79      	ldr	r3, [pc, #484]	; (d000c044 <_vfiprintf_r+0x248>)
d000be5e:	429d      	cmp	r5, r3
d000be60:	bf08      	it	eq
d000be62:	68f5      	ldreq	r5, [r6, #12]
d000be64:	e7da      	b.n	d000be1c <_vfiprintf_r+0x20>
d000be66:	89ab      	ldrh	r3, [r5, #12]
d000be68:	0598      	lsls	r0, r3, #22
d000be6a:	d4ed      	bmi.n	d000be48 <_vfiprintf_r+0x4c>
d000be6c:	6da8      	ldr	r0, [r5, #88]	; 0x58
d000be6e:	f000 feaa 	bl	d000cbc6 <__retarget_lock_release_recursive>
d000be72:	e7e9      	b.n	d000be48 <_vfiprintf_r+0x4c>
d000be74:	2300      	movs	r3, #0
d000be76:	9309      	str	r3, [sp, #36]	; 0x24
d000be78:	2320      	movs	r3, #32
d000be7a:	f88d 3029 	strb.w	r3, [sp, #41]	; 0x29
d000be7e:	f8cd 800c 	str.w	r8, [sp, #12]
d000be82:	2330      	movs	r3, #48	; 0x30
d000be84:	f8df 81c0 	ldr.w	r8, [pc, #448]	; d000c048 <_vfiprintf_r+0x24c>
d000be88:	f88d 302a 	strb.w	r3, [sp, #42]	; 0x2a
d000be8c:	f04f 0901 	mov.w	r9, #1
d000be90:	4623      	mov	r3, r4
d000be92:	469a      	mov	sl, r3
d000be94:	f813 2b01 	ldrb.w	r2, [r3], #1
d000be98:	b10a      	cbz	r2, d000be9e <_vfiprintf_r+0xa2>
d000be9a:	2a25      	cmp	r2, #37	; 0x25
d000be9c:	d1f9      	bne.n	d000be92 <_vfiprintf_r+0x96>
d000be9e:	ebba 0b04 	subs.w	fp, sl, r4
d000bea2:	d00b      	beq.n	d000bebc <_vfiprintf_r+0xc0>
d000bea4:	465b      	mov	r3, fp
d000bea6:	4622      	mov	r2, r4
d000bea8:	4629      	mov	r1, r5
d000beaa:	4630      	mov	r0, r6
d000beac:	f7ff ff93 	bl	d000bdd6 <__sfputs_r>
d000beb0:	3001      	adds	r0, #1
d000beb2:	f000 80aa 	beq.w	d000c00a <_vfiprintf_r+0x20e>
d000beb6:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000beb8:	445a      	add	r2, fp
d000beba:	9209      	str	r2, [sp, #36]	; 0x24
d000bebc:	f89a 3000 	ldrb.w	r3, [sl]
d000bec0:	2b00      	cmp	r3, #0
d000bec2:	f000 80a2 	beq.w	d000c00a <_vfiprintf_r+0x20e>
d000bec6:	2300      	movs	r3, #0
d000bec8:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d000becc:	e9cd 2305 	strd	r2, r3, [sp, #20]
d000bed0:	f10a 0a01 	add.w	sl, sl, #1
d000bed4:	9304      	str	r3, [sp, #16]
d000bed6:	9307      	str	r3, [sp, #28]
d000bed8:	f88d 3053 	strb.w	r3, [sp, #83]	; 0x53
d000bedc:	931a      	str	r3, [sp, #104]	; 0x68
d000bede:	4654      	mov	r4, sl
d000bee0:	2205      	movs	r2, #5
d000bee2:	f814 1b01 	ldrb.w	r1, [r4], #1
d000bee6:	4858      	ldr	r0, [pc, #352]	; (d000c048 <_vfiprintf_r+0x24c>)
d000bee8:	f000 fed2 	bl	d000cc90 <memchr>
d000beec:	9a04      	ldr	r2, [sp, #16]
d000beee:	b9d8      	cbnz	r0, d000bf28 <_vfiprintf_r+0x12c>
d000bef0:	06d1      	lsls	r1, r2, #27
d000bef2:	bf44      	itt	mi
d000bef4:	2320      	movmi	r3, #32
d000bef6:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d000befa:	0713      	lsls	r3, r2, #28
d000befc:	bf44      	itt	mi
d000befe:	232b      	movmi	r3, #43	; 0x2b
d000bf00:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d000bf04:	f89a 3000 	ldrb.w	r3, [sl]
d000bf08:	2b2a      	cmp	r3, #42	; 0x2a
d000bf0a:	d015      	beq.n	d000bf38 <_vfiprintf_r+0x13c>
d000bf0c:	9a07      	ldr	r2, [sp, #28]
d000bf0e:	4654      	mov	r4, sl
d000bf10:	2000      	movs	r0, #0
d000bf12:	f04f 0c0a 	mov.w	ip, #10
d000bf16:	4621      	mov	r1, r4
d000bf18:	f811 3b01 	ldrb.w	r3, [r1], #1
d000bf1c:	3b30      	subs	r3, #48	; 0x30
d000bf1e:	2b09      	cmp	r3, #9
d000bf20:	d94e      	bls.n	d000bfc0 <_vfiprintf_r+0x1c4>
d000bf22:	b1b0      	cbz	r0, d000bf52 <_vfiprintf_r+0x156>
d000bf24:	9207      	str	r2, [sp, #28]
d000bf26:	e014      	b.n	d000bf52 <_vfiprintf_r+0x156>
d000bf28:	eba0 0308 	sub.w	r3, r0, r8
d000bf2c:	fa09 f303 	lsl.w	r3, r9, r3
d000bf30:	4313      	orrs	r3, r2
d000bf32:	9304      	str	r3, [sp, #16]
d000bf34:	46a2      	mov	sl, r4
d000bf36:	e7d2      	b.n	d000bede <_vfiprintf_r+0xe2>
d000bf38:	9b03      	ldr	r3, [sp, #12]
d000bf3a:	1d19      	adds	r1, r3, #4
d000bf3c:	681b      	ldr	r3, [r3, #0]
d000bf3e:	9103      	str	r1, [sp, #12]
d000bf40:	2b00      	cmp	r3, #0
d000bf42:	bfbb      	ittet	lt
d000bf44:	425b      	neglt	r3, r3
d000bf46:	f042 0202 	orrlt.w	r2, r2, #2
d000bf4a:	9307      	strge	r3, [sp, #28]
d000bf4c:	9307      	strlt	r3, [sp, #28]
d000bf4e:	bfb8      	it	lt
d000bf50:	9204      	strlt	r2, [sp, #16]
d000bf52:	7823      	ldrb	r3, [r4, #0]
d000bf54:	2b2e      	cmp	r3, #46	; 0x2e
d000bf56:	d10c      	bne.n	d000bf72 <_vfiprintf_r+0x176>
d000bf58:	7863      	ldrb	r3, [r4, #1]
d000bf5a:	2b2a      	cmp	r3, #42	; 0x2a
d000bf5c:	d135      	bne.n	d000bfca <_vfiprintf_r+0x1ce>
d000bf5e:	9b03      	ldr	r3, [sp, #12]
d000bf60:	1d1a      	adds	r2, r3, #4
d000bf62:	681b      	ldr	r3, [r3, #0]
d000bf64:	9203      	str	r2, [sp, #12]
d000bf66:	2b00      	cmp	r3, #0
d000bf68:	bfb8      	it	lt
d000bf6a:	f04f 33ff 	movlt.w	r3, #4294967295	; 0xffffffff
d000bf6e:	3402      	adds	r4, #2
d000bf70:	9305      	str	r3, [sp, #20]
d000bf72:	f8df a0e4 	ldr.w	sl, [pc, #228]	; d000c058 <_vfiprintf_r+0x25c>
d000bf76:	7821      	ldrb	r1, [r4, #0]
d000bf78:	2203      	movs	r2, #3
d000bf7a:	4650      	mov	r0, sl
d000bf7c:	f000 fe88 	bl	d000cc90 <memchr>
d000bf80:	b140      	cbz	r0, d000bf94 <_vfiprintf_r+0x198>
d000bf82:	2340      	movs	r3, #64	; 0x40
d000bf84:	eba0 000a 	sub.w	r0, r0, sl
d000bf88:	fa03 f000 	lsl.w	r0, r3, r0
d000bf8c:	9b04      	ldr	r3, [sp, #16]
d000bf8e:	4303      	orrs	r3, r0
d000bf90:	3401      	adds	r4, #1
d000bf92:	9304      	str	r3, [sp, #16]
d000bf94:	f814 1b01 	ldrb.w	r1, [r4], #1
d000bf98:	482c      	ldr	r0, [pc, #176]	; (d000c04c <_vfiprintf_r+0x250>)
d000bf9a:	f88d 1028 	strb.w	r1, [sp, #40]	; 0x28
d000bf9e:	2206      	movs	r2, #6
d000bfa0:	f000 fe76 	bl	d000cc90 <memchr>
d000bfa4:	2800      	cmp	r0, #0
d000bfa6:	d03f      	beq.n	d000c028 <_vfiprintf_r+0x22c>
d000bfa8:	4b29      	ldr	r3, [pc, #164]	; (d000c050 <_vfiprintf_r+0x254>)
d000bfaa:	bb1b      	cbnz	r3, d000bff4 <_vfiprintf_r+0x1f8>
d000bfac:	9b03      	ldr	r3, [sp, #12]
d000bfae:	3307      	adds	r3, #7
d000bfb0:	f023 0307 	bic.w	r3, r3, #7
d000bfb4:	3308      	adds	r3, #8
d000bfb6:	9303      	str	r3, [sp, #12]
d000bfb8:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000bfba:	443b      	add	r3, r7
d000bfbc:	9309      	str	r3, [sp, #36]	; 0x24
d000bfbe:	e767      	b.n	d000be90 <_vfiprintf_r+0x94>
d000bfc0:	fb0c 3202 	mla	r2, ip, r2, r3
d000bfc4:	460c      	mov	r4, r1
d000bfc6:	2001      	movs	r0, #1
d000bfc8:	e7a5      	b.n	d000bf16 <_vfiprintf_r+0x11a>
d000bfca:	2300      	movs	r3, #0
d000bfcc:	3401      	adds	r4, #1
d000bfce:	9305      	str	r3, [sp, #20]
d000bfd0:	4619      	mov	r1, r3
d000bfd2:	f04f 0c0a 	mov.w	ip, #10
d000bfd6:	4620      	mov	r0, r4
d000bfd8:	f810 2b01 	ldrb.w	r2, [r0], #1
d000bfdc:	3a30      	subs	r2, #48	; 0x30
d000bfde:	2a09      	cmp	r2, #9
d000bfe0:	d903      	bls.n	d000bfea <_vfiprintf_r+0x1ee>
d000bfe2:	2b00      	cmp	r3, #0
d000bfe4:	d0c5      	beq.n	d000bf72 <_vfiprintf_r+0x176>
d000bfe6:	9105      	str	r1, [sp, #20]
d000bfe8:	e7c3      	b.n	d000bf72 <_vfiprintf_r+0x176>
d000bfea:	fb0c 2101 	mla	r1, ip, r1, r2
d000bfee:	4604      	mov	r4, r0
d000bff0:	2301      	movs	r3, #1
d000bff2:	e7f0      	b.n	d000bfd6 <_vfiprintf_r+0x1da>
d000bff4:	ab03      	add	r3, sp, #12
d000bff6:	9300      	str	r3, [sp, #0]
d000bff8:	462a      	mov	r2, r5
d000bffa:	4b16      	ldr	r3, [pc, #88]	; (d000c054 <_vfiprintf_r+0x258>)
d000bffc:	a904      	add	r1, sp, #16
d000bffe:	4630      	mov	r0, r6
d000c000:	f3af 8000 	nop.w
d000c004:	4607      	mov	r7, r0
d000c006:	1c78      	adds	r0, r7, #1
d000c008:	d1d6      	bne.n	d000bfb8 <_vfiprintf_r+0x1bc>
d000c00a:	6e6b      	ldr	r3, [r5, #100]	; 0x64
d000c00c:	07d9      	lsls	r1, r3, #31
d000c00e:	d405      	bmi.n	d000c01c <_vfiprintf_r+0x220>
d000c010:	89ab      	ldrh	r3, [r5, #12]
d000c012:	059a      	lsls	r2, r3, #22
d000c014:	d402      	bmi.n	d000c01c <_vfiprintf_r+0x220>
d000c016:	6da8      	ldr	r0, [r5, #88]	; 0x58
d000c018:	f000 fdd5 	bl	d000cbc6 <__retarget_lock_release_recursive>
d000c01c:	89ab      	ldrh	r3, [r5, #12]
d000c01e:	065b      	lsls	r3, r3, #25
d000c020:	f53f af12 	bmi.w	d000be48 <_vfiprintf_r+0x4c>
d000c024:	9809      	ldr	r0, [sp, #36]	; 0x24
d000c026:	e711      	b.n	d000be4c <_vfiprintf_r+0x50>
d000c028:	ab03      	add	r3, sp, #12
d000c02a:	9300      	str	r3, [sp, #0]
d000c02c:	462a      	mov	r2, r5
d000c02e:	4b09      	ldr	r3, [pc, #36]	; (d000c054 <_vfiprintf_r+0x258>)
d000c030:	a904      	add	r1, sp, #16
d000c032:	4630      	mov	r0, r6
d000c034:	f000 f880 	bl	d000c138 <_printf_i>
d000c038:	e7e4      	b.n	d000c004 <_vfiprintf_r+0x208>
d000c03a:	bf00      	nop
d000c03c:	d000de10 	.word	0xd000de10
d000c040:	d000de30 	.word	0xd000de30
d000c044:	d000ddf0 	.word	0xd000ddf0
d000c048:	d000ddbc 	.word	0xd000ddbc
d000c04c:	d000ddc6 	.word	0xd000ddc6
d000c050:	00000000 	.word	0x00000000
d000c054:	d000bdd7 	.word	0xd000bdd7
d000c058:	d000ddc2 	.word	0xd000ddc2

d000c05c <_printf_common>:
d000c05c:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d000c060:	4616      	mov	r6, r2
d000c062:	4699      	mov	r9, r3
d000c064:	688a      	ldr	r2, [r1, #8]
d000c066:	690b      	ldr	r3, [r1, #16]
d000c068:	f8dd 8020 	ldr.w	r8, [sp, #32]
d000c06c:	4293      	cmp	r3, r2
d000c06e:	bfb8      	it	lt
d000c070:	4613      	movlt	r3, r2
d000c072:	6033      	str	r3, [r6, #0]
d000c074:	f891 2043 	ldrb.w	r2, [r1, #67]	; 0x43
d000c078:	4607      	mov	r7, r0
d000c07a:	460c      	mov	r4, r1
d000c07c:	b10a      	cbz	r2, d000c082 <_printf_common+0x26>
d000c07e:	3301      	adds	r3, #1
d000c080:	6033      	str	r3, [r6, #0]
d000c082:	6823      	ldr	r3, [r4, #0]
d000c084:	0699      	lsls	r1, r3, #26
d000c086:	bf42      	ittt	mi
d000c088:	6833      	ldrmi	r3, [r6, #0]
d000c08a:	3302      	addmi	r3, #2
d000c08c:	6033      	strmi	r3, [r6, #0]
d000c08e:	6825      	ldr	r5, [r4, #0]
d000c090:	f015 0506 	ands.w	r5, r5, #6
d000c094:	d106      	bne.n	d000c0a4 <_printf_common+0x48>
d000c096:	f104 0a19 	add.w	sl, r4, #25
d000c09a:	68e3      	ldr	r3, [r4, #12]
d000c09c:	6832      	ldr	r2, [r6, #0]
d000c09e:	1a9b      	subs	r3, r3, r2
d000c0a0:	42ab      	cmp	r3, r5
d000c0a2:	dc26      	bgt.n	d000c0f2 <_printf_common+0x96>
d000c0a4:	f894 2043 	ldrb.w	r2, [r4, #67]	; 0x43
d000c0a8:	1e13      	subs	r3, r2, #0
d000c0aa:	6822      	ldr	r2, [r4, #0]
d000c0ac:	bf18      	it	ne
d000c0ae:	2301      	movne	r3, #1
d000c0b0:	0692      	lsls	r2, r2, #26
d000c0b2:	d42b      	bmi.n	d000c10c <_printf_common+0xb0>
d000c0b4:	f104 0243 	add.w	r2, r4, #67	; 0x43
d000c0b8:	4649      	mov	r1, r9
d000c0ba:	4638      	mov	r0, r7
d000c0bc:	47c0      	blx	r8
d000c0be:	3001      	adds	r0, #1
d000c0c0:	d01e      	beq.n	d000c100 <_printf_common+0xa4>
d000c0c2:	6823      	ldr	r3, [r4, #0]
d000c0c4:	68e5      	ldr	r5, [r4, #12]
d000c0c6:	6832      	ldr	r2, [r6, #0]
d000c0c8:	f003 0306 	and.w	r3, r3, #6
d000c0cc:	2b04      	cmp	r3, #4
d000c0ce:	bf08      	it	eq
d000c0d0:	1aad      	subeq	r5, r5, r2
d000c0d2:	68a3      	ldr	r3, [r4, #8]
d000c0d4:	6922      	ldr	r2, [r4, #16]
d000c0d6:	bf0c      	ite	eq
d000c0d8:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
d000c0dc:	2500      	movne	r5, #0
d000c0de:	4293      	cmp	r3, r2
d000c0e0:	bfc4      	itt	gt
d000c0e2:	1a9b      	subgt	r3, r3, r2
d000c0e4:	18ed      	addgt	r5, r5, r3
d000c0e6:	2600      	movs	r6, #0
d000c0e8:	341a      	adds	r4, #26
d000c0ea:	42b5      	cmp	r5, r6
d000c0ec:	d11a      	bne.n	d000c124 <_printf_common+0xc8>
d000c0ee:	2000      	movs	r0, #0
d000c0f0:	e008      	b.n	d000c104 <_printf_common+0xa8>
d000c0f2:	2301      	movs	r3, #1
d000c0f4:	4652      	mov	r2, sl
d000c0f6:	4649      	mov	r1, r9
d000c0f8:	4638      	mov	r0, r7
d000c0fa:	47c0      	blx	r8
d000c0fc:	3001      	adds	r0, #1
d000c0fe:	d103      	bne.n	d000c108 <_printf_common+0xac>
d000c100:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000c104:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d000c108:	3501      	adds	r5, #1
d000c10a:	e7c6      	b.n	d000c09a <_printf_common+0x3e>
d000c10c:	18e1      	adds	r1, r4, r3
d000c10e:	1c5a      	adds	r2, r3, #1
d000c110:	2030      	movs	r0, #48	; 0x30
d000c112:	f881 0043 	strb.w	r0, [r1, #67]	; 0x43
d000c116:	4422      	add	r2, r4
d000c118:	f894 1045 	ldrb.w	r1, [r4, #69]	; 0x45
d000c11c:	f882 1043 	strb.w	r1, [r2, #67]	; 0x43
d000c120:	3302      	adds	r3, #2
d000c122:	e7c7      	b.n	d000c0b4 <_printf_common+0x58>
d000c124:	2301      	movs	r3, #1
d000c126:	4622      	mov	r2, r4
d000c128:	4649      	mov	r1, r9
d000c12a:	4638      	mov	r0, r7
d000c12c:	47c0      	blx	r8
d000c12e:	3001      	adds	r0, #1
d000c130:	d0e6      	beq.n	d000c100 <_printf_common+0xa4>
d000c132:	3601      	adds	r6, #1
d000c134:	e7d9      	b.n	d000c0ea <_printf_common+0x8e>
	...

d000c138 <_printf_i>:
d000c138:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
d000c13c:	460c      	mov	r4, r1
d000c13e:	4691      	mov	r9, r2
d000c140:	7e27      	ldrb	r7, [r4, #24]
d000c142:	990c      	ldr	r1, [sp, #48]	; 0x30
d000c144:	2f78      	cmp	r7, #120	; 0x78
d000c146:	4680      	mov	r8, r0
d000c148:	469a      	mov	sl, r3
d000c14a:	f104 0243 	add.w	r2, r4, #67	; 0x43
d000c14e:	d807      	bhi.n	d000c160 <_printf_i+0x28>
d000c150:	2f62      	cmp	r7, #98	; 0x62
d000c152:	d80a      	bhi.n	d000c16a <_printf_i+0x32>
d000c154:	2f00      	cmp	r7, #0
d000c156:	f000 80d8 	beq.w	d000c30a <_printf_i+0x1d2>
d000c15a:	2f58      	cmp	r7, #88	; 0x58
d000c15c:	f000 80a3 	beq.w	d000c2a6 <_printf_i+0x16e>
d000c160:	f104 0642 	add.w	r6, r4, #66	; 0x42
d000c164:	f884 7042 	strb.w	r7, [r4, #66]	; 0x42
d000c168:	e03a      	b.n	d000c1e0 <_printf_i+0xa8>
d000c16a:	f1a7 0363 	sub.w	r3, r7, #99	; 0x63
d000c16e:	2b15      	cmp	r3, #21
d000c170:	d8f6      	bhi.n	d000c160 <_printf_i+0x28>
d000c172:	a001      	add	r0, pc, #4	; (adr r0, d000c178 <_printf_i+0x40>)
d000c174:	f850 f023 	ldr.w	pc, [r0, r3, lsl #2]
d000c178:	d000c1d1 	.word	0xd000c1d1
d000c17c:	d000c1e5 	.word	0xd000c1e5
d000c180:	d000c161 	.word	0xd000c161
d000c184:	d000c161 	.word	0xd000c161
d000c188:	d000c161 	.word	0xd000c161
d000c18c:	d000c161 	.word	0xd000c161
d000c190:	d000c1e5 	.word	0xd000c1e5
d000c194:	d000c161 	.word	0xd000c161
d000c198:	d000c161 	.word	0xd000c161
d000c19c:	d000c161 	.word	0xd000c161
d000c1a0:	d000c161 	.word	0xd000c161
d000c1a4:	d000c2f1 	.word	0xd000c2f1
d000c1a8:	d000c215 	.word	0xd000c215
d000c1ac:	d000c2d3 	.word	0xd000c2d3
d000c1b0:	d000c161 	.word	0xd000c161
d000c1b4:	d000c161 	.word	0xd000c161
d000c1b8:	d000c313 	.word	0xd000c313
d000c1bc:	d000c161 	.word	0xd000c161
d000c1c0:	d000c215 	.word	0xd000c215
d000c1c4:	d000c161 	.word	0xd000c161
d000c1c8:	d000c161 	.word	0xd000c161
d000c1cc:	d000c2db 	.word	0xd000c2db
d000c1d0:	680b      	ldr	r3, [r1, #0]
d000c1d2:	1d1a      	adds	r2, r3, #4
d000c1d4:	681b      	ldr	r3, [r3, #0]
d000c1d6:	600a      	str	r2, [r1, #0]
d000c1d8:	f104 0642 	add.w	r6, r4, #66	; 0x42
d000c1dc:	f884 3042 	strb.w	r3, [r4, #66]	; 0x42
d000c1e0:	2301      	movs	r3, #1
d000c1e2:	e0a3      	b.n	d000c32c <_printf_i+0x1f4>
d000c1e4:	6825      	ldr	r5, [r4, #0]
d000c1e6:	6808      	ldr	r0, [r1, #0]
d000c1e8:	062e      	lsls	r6, r5, #24
d000c1ea:	f100 0304 	add.w	r3, r0, #4
d000c1ee:	d50a      	bpl.n	d000c206 <_printf_i+0xce>
d000c1f0:	6805      	ldr	r5, [r0, #0]
d000c1f2:	600b      	str	r3, [r1, #0]
d000c1f4:	2d00      	cmp	r5, #0
d000c1f6:	da03      	bge.n	d000c200 <_printf_i+0xc8>
d000c1f8:	232d      	movs	r3, #45	; 0x2d
d000c1fa:	426d      	negs	r5, r5
d000c1fc:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d000c200:	485e      	ldr	r0, [pc, #376]	; (d000c37c <_printf_i+0x244>)
d000c202:	230a      	movs	r3, #10
d000c204:	e019      	b.n	d000c23a <_printf_i+0x102>
d000c206:	f015 0f40 	tst.w	r5, #64	; 0x40
d000c20a:	6805      	ldr	r5, [r0, #0]
d000c20c:	600b      	str	r3, [r1, #0]
d000c20e:	bf18      	it	ne
d000c210:	b22d      	sxthne	r5, r5
d000c212:	e7ef      	b.n	d000c1f4 <_printf_i+0xbc>
d000c214:	680b      	ldr	r3, [r1, #0]
d000c216:	6825      	ldr	r5, [r4, #0]
d000c218:	1d18      	adds	r0, r3, #4
d000c21a:	6008      	str	r0, [r1, #0]
d000c21c:	0628      	lsls	r0, r5, #24
d000c21e:	d501      	bpl.n	d000c224 <_printf_i+0xec>
d000c220:	681d      	ldr	r5, [r3, #0]
d000c222:	e002      	b.n	d000c22a <_printf_i+0xf2>
d000c224:	0669      	lsls	r1, r5, #25
d000c226:	d5fb      	bpl.n	d000c220 <_printf_i+0xe8>
d000c228:	881d      	ldrh	r5, [r3, #0]
d000c22a:	4854      	ldr	r0, [pc, #336]	; (d000c37c <_printf_i+0x244>)
d000c22c:	2f6f      	cmp	r7, #111	; 0x6f
d000c22e:	bf0c      	ite	eq
d000c230:	2308      	moveq	r3, #8
d000c232:	230a      	movne	r3, #10
d000c234:	2100      	movs	r1, #0
d000c236:	f884 1043 	strb.w	r1, [r4, #67]	; 0x43
d000c23a:	6866      	ldr	r6, [r4, #4]
d000c23c:	60a6      	str	r6, [r4, #8]
d000c23e:	2e00      	cmp	r6, #0
d000c240:	bfa2      	ittt	ge
d000c242:	6821      	ldrge	r1, [r4, #0]
d000c244:	f021 0104 	bicge.w	r1, r1, #4
d000c248:	6021      	strge	r1, [r4, #0]
d000c24a:	b90d      	cbnz	r5, d000c250 <_printf_i+0x118>
d000c24c:	2e00      	cmp	r6, #0
d000c24e:	d04d      	beq.n	d000c2ec <_printf_i+0x1b4>
d000c250:	4616      	mov	r6, r2
d000c252:	fbb5 f1f3 	udiv	r1, r5, r3
d000c256:	fb03 5711 	mls	r7, r3, r1, r5
d000c25a:	5dc7      	ldrb	r7, [r0, r7]
d000c25c:	f806 7d01 	strb.w	r7, [r6, #-1]!
d000c260:	462f      	mov	r7, r5
d000c262:	42bb      	cmp	r3, r7
d000c264:	460d      	mov	r5, r1
d000c266:	d9f4      	bls.n	d000c252 <_printf_i+0x11a>
d000c268:	2b08      	cmp	r3, #8
d000c26a:	d10b      	bne.n	d000c284 <_printf_i+0x14c>
d000c26c:	6823      	ldr	r3, [r4, #0]
d000c26e:	07df      	lsls	r7, r3, #31
d000c270:	d508      	bpl.n	d000c284 <_printf_i+0x14c>
d000c272:	6923      	ldr	r3, [r4, #16]
d000c274:	6861      	ldr	r1, [r4, #4]
d000c276:	4299      	cmp	r1, r3
d000c278:	bfde      	ittt	le
d000c27a:	2330      	movle	r3, #48	; 0x30
d000c27c:	f806 3c01 	strble.w	r3, [r6, #-1]
d000c280:	f106 36ff 	addle.w	r6, r6, #4294967295	; 0xffffffff
d000c284:	1b92      	subs	r2, r2, r6
d000c286:	6122      	str	r2, [r4, #16]
d000c288:	f8cd a000 	str.w	sl, [sp]
d000c28c:	464b      	mov	r3, r9
d000c28e:	aa03      	add	r2, sp, #12
d000c290:	4621      	mov	r1, r4
d000c292:	4640      	mov	r0, r8
d000c294:	f7ff fee2 	bl	d000c05c <_printf_common>
d000c298:	3001      	adds	r0, #1
d000c29a:	d14c      	bne.n	d000c336 <_printf_i+0x1fe>
d000c29c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000c2a0:	b004      	add	sp, #16
d000c2a2:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d000c2a6:	4835      	ldr	r0, [pc, #212]	; (d000c37c <_printf_i+0x244>)
d000c2a8:	f884 7045 	strb.w	r7, [r4, #69]	; 0x45
d000c2ac:	6823      	ldr	r3, [r4, #0]
d000c2ae:	680e      	ldr	r6, [r1, #0]
d000c2b0:	061f      	lsls	r7, r3, #24
d000c2b2:	f856 5b04 	ldr.w	r5, [r6], #4
d000c2b6:	600e      	str	r6, [r1, #0]
d000c2b8:	d514      	bpl.n	d000c2e4 <_printf_i+0x1ac>
d000c2ba:	07d9      	lsls	r1, r3, #31
d000c2bc:	bf44      	itt	mi
d000c2be:	f043 0320 	orrmi.w	r3, r3, #32
d000c2c2:	6023      	strmi	r3, [r4, #0]
d000c2c4:	b91d      	cbnz	r5, d000c2ce <_printf_i+0x196>
d000c2c6:	6823      	ldr	r3, [r4, #0]
d000c2c8:	f023 0320 	bic.w	r3, r3, #32
d000c2cc:	6023      	str	r3, [r4, #0]
d000c2ce:	2310      	movs	r3, #16
d000c2d0:	e7b0      	b.n	d000c234 <_printf_i+0xfc>
d000c2d2:	6823      	ldr	r3, [r4, #0]
d000c2d4:	f043 0320 	orr.w	r3, r3, #32
d000c2d8:	6023      	str	r3, [r4, #0]
d000c2da:	2378      	movs	r3, #120	; 0x78
d000c2dc:	4828      	ldr	r0, [pc, #160]	; (d000c380 <_printf_i+0x248>)
d000c2de:	f884 3045 	strb.w	r3, [r4, #69]	; 0x45
d000c2e2:	e7e3      	b.n	d000c2ac <_printf_i+0x174>
d000c2e4:	065e      	lsls	r6, r3, #25
d000c2e6:	bf48      	it	mi
d000c2e8:	b2ad      	uxthmi	r5, r5
d000c2ea:	e7e6      	b.n	d000c2ba <_printf_i+0x182>
d000c2ec:	4616      	mov	r6, r2
d000c2ee:	e7bb      	b.n	d000c268 <_printf_i+0x130>
d000c2f0:	680b      	ldr	r3, [r1, #0]
d000c2f2:	6826      	ldr	r6, [r4, #0]
d000c2f4:	6960      	ldr	r0, [r4, #20]
d000c2f6:	1d1d      	adds	r5, r3, #4
d000c2f8:	600d      	str	r5, [r1, #0]
d000c2fa:	0635      	lsls	r5, r6, #24
d000c2fc:	681b      	ldr	r3, [r3, #0]
d000c2fe:	d501      	bpl.n	d000c304 <_printf_i+0x1cc>
d000c300:	6018      	str	r0, [r3, #0]
d000c302:	e002      	b.n	d000c30a <_printf_i+0x1d2>
d000c304:	0671      	lsls	r1, r6, #25
d000c306:	d5fb      	bpl.n	d000c300 <_printf_i+0x1c8>
d000c308:	8018      	strh	r0, [r3, #0]
d000c30a:	2300      	movs	r3, #0
d000c30c:	6123      	str	r3, [r4, #16]
d000c30e:	4616      	mov	r6, r2
d000c310:	e7ba      	b.n	d000c288 <_printf_i+0x150>
d000c312:	680b      	ldr	r3, [r1, #0]
d000c314:	1d1a      	adds	r2, r3, #4
d000c316:	600a      	str	r2, [r1, #0]
d000c318:	681e      	ldr	r6, [r3, #0]
d000c31a:	6862      	ldr	r2, [r4, #4]
d000c31c:	2100      	movs	r1, #0
d000c31e:	4630      	mov	r0, r6
d000c320:	f000 fcb6 	bl	d000cc90 <memchr>
d000c324:	b108      	cbz	r0, d000c32a <_printf_i+0x1f2>
d000c326:	1b80      	subs	r0, r0, r6
d000c328:	6060      	str	r0, [r4, #4]
d000c32a:	6863      	ldr	r3, [r4, #4]
d000c32c:	6123      	str	r3, [r4, #16]
d000c32e:	2300      	movs	r3, #0
d000c330:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d000c334:	e7a8      	b.n	d000c288 <_printf_i+0x150>
d000c336:	6923      	ldr	r3, [r4, #16]
d000c338:	4632      	mov	r2, r6
d000c33a:	4649      	mov	r1, r9
d000c33c:	4640      	mov	r0, r8
d000c33e:	47d0      	blx	sl
d000c340:	3001      	adds	r0, #1
d000c342:	d0ab      	beq.n	d000c29c <_printf_i+0x164>
d000c344:	6823      	ldr	r3, [r4, #0]
d000c346:	079b      	lsls	r3, r3, #30
d000c348:	d413      	bmi.n	d000c372 <_printf_i+0x23a>
d000c34a:	68e0      	ldr	r0, [r4, #12]
d000c34c:	9b03      	ldr	r3, [sp, #12]
d000c34e:	4298      	cmp	r0, r3
d000c350:	bfb8      	it	lt
d000c352:	4618      	movlt	r0, r3
d000c354:	e7a4      	b.n	d000c2a0 <_printf_i+0x168>
d000c356:	2301      	movs	r3, #1
d000c358:	4632      	mov	r2, r6
d000c35a:	4649      	mov	r1, r9
d000c35c:	4640      	mov	r0, r8
d000c35e:	47d0      	blx	sl
d000c360:	3001      	adds	r0, #1
d000c362:	d09b      	beq.n	d000c29c <_printf_i+0x164>
d000c364:	3501      	adds	r5, #1
d000c366:	68e3      	ldr	r3, [r4, #12]
d000c368:	9903      	ldr	r1, [sp, #12]
d000c36a:	1a5b      	subs	r3, r3, r1
d000c36c:	42ab      	cmp	r3, r5
d000c36e:	dcf2      	bgt.n	d000c356 <_printf_i+0x21e>
d000c370:	e7eb      	b.n	d000c34a <_printf_i+0x212>
d000c372:	2500      	movs	r5, #0
d000c374:	f104 0619 	add.w	r6, r4, #25
d000c378:	e7f5      	b.n	d000c366 <_printf_i+0x22e>
d000c37a:	bf00      	nop
d000c37c:	d000ddcd 	.word	0xd000ddcd
d000c380:	d000ddde 	.word	0xd000ddde

d000c384 <_puts_r>:
d000c384:	b570      	push	{r4, r5, r6, lr}
d000c386:	460e      	mov	r6, r1
d000c388:	4605      	mov	r5, r0
d000c38a:	b118      	cbz	r0, d000c394 <_puts_r+0x10>
d000c38c:	6983      	ldr	r3, [r0, #24]
d000c38e:	b90b      	cbnz	r3, d000c394 <_puts_r+0x10>
d000c390:	f000 fb7a 	bl	d000ca88 <__sinit>
d000c394:	69ab      	ldr	r3, [r5, #24]
d000c396:	68ac      	ldr	r4, [r5, #8]
d000c398:	b913      	cbnz	r3, d000c3a0 <_puts_r+0x1c>
d000c39a:	4628      	mov	r0, r5
d000c39c:	f000 fb74 	bl	d000ca88 <__sinit>
d000c3a0:	4b2c      	ldr	r3, [pc, #176]	; (d000c454 <_puts_r+0xd0>)
d000c3a2:	429c      	cmp	r4, r3
d000c3a4:	d120      	bne.n	d000c3e8 <_puts_r+0x64>
d000c3a6:	686c      	ldr	r4, [r5, #4]
d000c3a8:	6e63      	ldr	r3, [r4, #100]	; 0x64
d000c3aa:	07db      	lsls	r3, r3, #31
d000c3ac:	d405      	bmi.n	d000c3ba <_puts_r+0x36>
d000c3ae:	89a3      	ldrh	r3, [r4, #12]
d000c3b0:	0598      	lsls	r0, r3, #22
d000c3b2:	d402      	bmi.n	d000c3ba <_puts_r+0x36>
d000c3b4:	6da0      	ldr	r0, [r4, #88]	; 0x58
d000c3b6:	f000 fc05 	bl	d000cbc4 <__retarget_lock_acquire_recursive>
d000c3ba:	89a3      	ldrh	r3, [r4, #12]
d000c3bc:	0719      	lsls	r1, r3, #28
d000c3be:	d51d      	bpl.n	d000c3fc <_puts_r+0x78>
d000c3c0:	6923      	ldr	r3, [r4, #16]
d000c3c2:	b1db      	cbz	r3, d000c3fc <_puts_r+0x78>
d000c3c4:	3e01      	subs	r6, #1
d000c3c6:	68a3      	ldr	r3, [r4, #8]
d000c3c8:	f816 1f01 	ldrb.w	r1, [r6, #1]!
d000c3cc:	3b01      	subs	r3, #1
d000c3ce:	60a3      	str	r3, [r4, #8]
d000c3d0:	bb39      	cbnz	r1, d000c422 <_puts_r+0x9e>
d000c3d2:	2b00      	cmp	r3, #0
d000c3d4:	da38      	bge.n	d000c448 <_puts_r+0xc4>
d000c3d6:	4622      	mov	r2, r4
d000c3d8:	210a      	movs	r1, #10
d000c3da:	4628      	mov	r0, r5
d000c3dc:	f000 f972 	bl	d000c6c4 <__swbuf_r>
d000c3e0:	3001      	adds	r0, #1
d000c3e2:	d011      	beq.n	d000c408 <_puts_r+0x84>
d000c3e4:	250a      	movs	r5, #10
d000c3e6:	e011      	b.n	d000c40c <_puts_r+0x88>
d000c3e8:	4b1b      	ldr	r3, [pc, #108]	; (d000c458 <_puts_r+0xd4>)
d000c3ea:	429c      	cmp	r4, r3
d000c3ec:	d101      	bne.n	d000c3f2 <_puts_r+0x6e>
d000c3ee:	68ac      	ldr	r4, [r5, #8]
d000c3f0:	e7da      	b.n	d000c3a8 <_puts_r+0x24>
d000c3f2:	4b1a      	ldr	r3, [pc, #104]	; (d000c45c <_puts_r+0xd8>)
d000c3f4:	429c      	cmp	r4, r3
d000c3f6:	bf08      	it	eq
d000c3f8:	68ec      	ldreq	r4, [r5, #12]
d000c3fa:	e7d5      	b.n	d000c3a8 <_puts_r+0x24>
d000c3fc:	4621      	mov	r1, r4
d000c3fe:	4628      	mov	r0, r5
d000c400:	f000 f9b2 	bl	d000c768 <__swsetup_r>
d000c404:	2800      	cmp	r0, #0
d000c406:	d0dd      	beq.n	d000c3c4 <_puts_r+0x40>
d000c408:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d000c40c:	6e63      	ldr	r3, [r4, #100]	; 0x64
d000c40e:	07da      	lsls	r2, r3, #31
d000c410:	d405      	bmi.n	d000c41e <_puts_r+0x9a>
d000c412:	89a3      	ldrh	r3, [r4, #12]
d000c414:	059b      	lsls	r3, r3, #22
d000c416:	d402      	bmi.n	d000c41e <_puts_r+0x9a>
d000c418:	6da0      	ldr	r0, [r4, #88]	; 0x58
d000c41a:	f000 fbd4 	bl	d000cbc6 <__retarget_lock_release_recursive>
d000c41e:	4628      	mov	r0, r5
d000c420:	bd70      	pop	{r4, r5, r6, pc}
d000c422:	2b00      	cmp	r3, #0
d000c424:	da04      	bge.n	d000c430 <_puts_r+0xac>
d000c426:	69a2      	ldr	r2, [r4, #24]
d000c428:	429a      	cmp	r2, r3
d000c42a:	dc06      	bgt.n	d000c43a <_puts_r+0xb6>
d000c42c:	290a      	cmp	r1, #10
d000c42e:	d004      	beq.n	d000c43a <_puts_r+0xb6>
d000c430:	6823      	ldr	r3, [r4, #0]
d000c432:	1c5a      	adds	r2, r3, #1
d000c434:	6022      	str	r2, [r4, #0]
d000c436:	7019      	strb	r1, [r3, #0]
d000c438:	e7c5      	b.n	d000c3c6 <_puts_r+0x42>
d000c43a:	4622      	mov	r2, r4
d000c43c:	4628      	mov	r0, r5
d000c43e:	f000 f941 	bl	d000c6c4 <__swbuf_r>
d000c442:	3001      	adds	r0, #1
d000c444:	d1bf      	bne.n	d000c3c6 <_puts_r+0x42>
d000c446:	e7df      	b.n	d000c408 <_puts_r+0x84>
d000c448:	6823      	ldr	r3, [r4, #0]
d000c44a:	250a      	movs	r5, #10
d000c44c:	1c5a      	adds	r2, r3, #1
d000c44e:	6022      	str	r2, [r4, #0]
d000c450:	701d      	strb	r5, [r3, #0]
d000c452:	e7db      	b.n	d000c40c <_puts_r+0x88>
d000c454:	d000de10 	.word	0xd000de10
d000c458:	d000de30 	.word	0xd000de30
d000c45c:	d000ddf0 	.word	0xd000ddf0

d000c460 <puts>:
d000c460:	4b02      	ldr	r3, [pc, #8]	; (d000c46c <puts+0xc>)
d000c462:	4601      	mov	r1, r0
d000c464:	6818      	ldr	r0, [r3, #0]
d000c466:	f7ff bf8d 	b.w	d000c384 <_puts_r>
d000c46a:	bf00      	nop
d000c46c:	d000de58 	.word	0xd000de58

d000c470 <setbuf>:
d000c470:	2900      	cmp	r1, #0
d000c472:	f44f 6380 	mov.w	r3, #1024	; 0x400
d000c476:	bf0c      	ite	eq
d000c478:	2202      	moveq	r2, #2
d000c47a:	2200      	movne	r2, #0
d000c47c:	f000 b800 	b.w	d000c480 <setvbuf>

d000c480 <setvbuf>:
d000c480:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d000c484:	461d      	mov	r5, r3
d000c486:	4b5d      	ldr	r3, [pc, #372]	; (d000c5fc <setvbuf+0x17c>)
d000c488:	681f      	ldr	r7, [r3, #0]
d000c48a:	4604      	mov	r4, r0
d000c48c:	460e      	mov	r6, r1
d000c48e:	4690      	mov	r8, r2
d000c490:	b127      	cbz	r7, d000c49c <setvbuf+0x1c>
d000c492:	69bb      	ldr	r3, [r7, #24]
d000c494:	b913      	cbnz	r3, d000c49c <setvbuf+0x1c>
d000c496:	4638      	mov	r0, r7
d000c498:	f000 faf6 	bl	d000ca88 <__sinit>
d000c49c:	4b58      	ldr	r3, [pc, #352]	; (d000c600 <setvbuf+0x180>)
d000c49e:	429c      	cmp	r4, r3
d000c4a0:	d167      	bne.n	d000c572 <setvbuf+0xf2>
d000c4a2:	687c      	ldr	r4, [r7, #4]
d000c4a4:	f1b8 0f02 	cmp.w	r8, #2
d000c4a8:	d006      	beq.n	d000c4b8 <setvbuf+0x38>
d000c4aa:	f1b8 0f01 	cmp.w	r8, #1
d000c4ae:	f200 809f 	bhi.w	d000c5f0 <setvbuf+0x170>
d000c4b2:	2d00      	cmp	r5, #0
d000c4b4:	f2c0 809c 	blt.w	d000c5f0 <setvbuf+0x170>
d000c4b8:	6e63      	ldr	r3, [r4, #100]	; 0x64
d000c4ba:	07db      	lsls	r3, r3, #31
d000c4bc:	d405      	bmi.n	d000c4ca <setvbuf+0x4a>
d000c4be:	89a3      	ldrh	r3, [r4, #12]
d000c4c0:	0598      	lsls	r0, r3, #22
d000c4c2:	d402      	bmi.n	d000c4ca <setvbuf+0x4a>
d000c4c4:	6da0      	ldr	r0, [r4, #88]	; 0x58
d000c4c6:	f000 fb7d 	bl	d000cbc4 <__retarget_lock_acquire_recursive>
d000c4ca:	4621      	mov	r1, r4
d000c4cc:	4638      	mov	r0, r7
d000c4ce:	f000 fa47 	bl	d000c960 <_fflush_r>
d000c4d2:	6b61      	ldr	r1, [r4, #52]	; 0x34
d000c4d4:	b141      	cbz	r1, d000c4e8 <setvbuf+0x68>
d000c4d6:	f104 0344 	add.w	r3, r4, #68	; 0x44
d000c4da:	4299      	cmp	r1, r3
d000c4dc:	d002      	beq.n	d000c4e4 <setvbuf+0x64>
d000c4de:	4638      	mov	r0, r7
d000c4e0:	f7ff fbb8 	bl	d000bc54 <_free_r>
d000c4e4:	2300      	movs	r3, #0
d000c4e6:	6363      	str	r3, [r4, #52]	; 0x34
d000c4e8:	2300      	movs	r3, #0
d000c4ea:	61a3      	str	r3, [r4, #24]
d000c4ec:	6063      	str	r3, [r4, #4]
d000c4ee:	89a3      	ldrh	r3, [r4, #12]
d000c4f0:	0619      	lsls	r1, r3, #24
d000c4f2:	d503      	bpl.n	d000c4fc <setvbuf+0x7c>
d000c4f4:	6921      	ldr	r1, [r4, #16]
d000c4f6:	4638      	mov	r0, r7
d000c4f8:	f7ff fbac 	bl	d000bc54 <_free_r>
d000c4fc:	89a3      	ldrh	r3, [r4, #12]
d000c4fe:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d000c502:	f023 0303 	bic.w	r3, r3, #3
d000c506:	f1b8 0f02 	cmp.w	r8, #2
d000c50a:	81a3      	strh	r3, [r4, #12]
d000c50c:	d06c      	beq.n	d000c5e8 <setvbuf+0x168>
d000c50e:	ab01      	add	r3, sp, #4
d000c510:	466a      	mov	r2, sp
d000c512:	4621      	mov	r1, r4
d000c514:	4638      	mov	r0, r7
d000c516:	f000 fb57 	bl	d000cbc8 <__swhatbuf_r>
d000c51a:	89a3      	ldrh	r3, [r4, #12]
d000c51c:	4318      	orrs	r0, r3
d000c51e:	81a0      	strh	r0, [r4, #12]
d000c520:	2d00      	cmp	r5, #0
d000c522:	d130      	bne.n	d000c586 <setvbuf+0x106>
d000c524:	9d00      	ldr	r5, [sp, #0]
d000c526:	4628      	mov	r0, r5
d000c528:	f7ff fb50 	bl	d000bbcc <malloc>
d000c52c:	4606      	mov	r6, r0
d000c52e:	2800      	cmp	r0, #0
d000c530:	d155      	bne.n	d000c5de <setvbuf+0x15e>
d000c532:	f8dd 9000 	ldr.w	r9, [sp]
d000c536:	45a9      	cmp	r9, r5
d000c538:	d14a      	bne.n	d000c5d0 <setvbuf+0x150>
d000c53a:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d000c53e:	2200      	movs	r2, #0
d000c540:	60a2      	str	r2, [r4, #8]
d000c542:	f104 0247 	add.w	r2, r4, #71	; 0x47
d000c546:	6022      	str	r2, [r4, #0]
d000c548:	6122      	str	r2, [r4, #16]
d000c54a:	2201      	movs	r2, #1
d000c54c:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d000c550:	6162      	str	r2, [r4, #20]
d000c552:	6e62      	ldr	r2, [r4, #100]	; 0x64
d000c554:	f043 0302 	orr.w	r3, r3, #2
d000c558:	07d2      	lsls	r2, r2, #31
d000c55a:	81a3      	strh	r3, [r4, #12]
d000c55c:	d405      	bmi.n	d000c56a <setvbuf+0xea>
d000c55e:	f413 7f00 	tst.w	r3, #512	; 0x200
d000c562:	d102      	bne.n	d000c56a <setvbuf+0xea>
d000c564:	6da0      	ldr	r0, [r4, #88]	; 0x58
d000c566:	f000 fb2e 	bl	d000cbc6 <__retarget_lock_release_recursive>
d000c56a:	4628      	mov	r0, r5
d000c56c:	b003      	add	sp, #12
d000c56e:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d000c572:	4b24      	ldr	r3, [pc, #144]	; (d000c604 <setvbuf+0x184>)
d000c574:	429c      	cmp	r4, r3
d000c576:	d101      	bne.n	d000c57c <setvbuf+0xfc>
d000c578:	68bc      	ldr	r4, [r7, #8]
d000c57a:	e793      	b.n	d000c4a4 <setvbuf+0x24>
d000c57c:	4b22      	ldr	r3, [pc, #136]	; (d000c608 <setvbuf+0x188>)
d000c57e:	429c      	cmp	r4, r3
d000c580:	bf08      	it	eq
d000c582:	68fc      	ldreq	r4, [r7, #12]
d000c584:	e78e      	b.n	d000c4a4 <setvbuf+0x24>
d000c586:	2e00      	cmp	r6, #0
d000c588:	d0cd      	beq.n	d000c526 <setvbuf+0xa6>
d000c58a:	69bb      	ldr	r3, [r7, #24]
d000c58c:	b913      	cbnz	r3, d000c594 <setvbuf+0x114>
d000c58e:	4638      	mov	r0, r7
d000c590:	f000 fa7a 	bl	d000ca88 <__sinit>
d000c594:	f1b8 0f01 	cmp.w	r8, #1
d000c598:	bf08      	it	eq
d000c59a:	89a3      	ldrheq	r3, [r4, #12]
d000c59c:	6026      	str	r6, [r4, #0]
d000c59e:	bf04      	itt	eq
d000c5a0:	f043 0301 	orreq.w	r3, r3, #1
d000c5a4:	81a3      	strheq	r3, [r4, #12]
d000c5a6:	89a2      	ldrh	r2, [r4, #12]
d000c5a8:	f012 0308 	ands.w	r3, r2, #8
d000c5ac:	e9c4 6504 	strd	r6, r5, [r4, #16]
d000c5b0:	d01c      	beq.n	d000c5ec <setvbuf+0x16c>
d000c5b2:	07d3      	lsls	r3, r2, #31
d000c5b4:	bf41      	itttt	mi
d000c5b6:	2300      	movmi	r3, #0
d000c5b8:	426d      	negmi	r5, r5
d000c5ba:	60a3      	strmi	r3, [r4, #8]
d000c5bc:	61a5      	strmi	r5, [r4, #24]
d000c5be:	bf58      	it	pl
d000c5c0:	60a5      	strpl	r5, [r4, #8]
d000c5c2:	6e65      	ldr	r5, [r4, #100]	; 0x64
d000c5c4:	f015 0501 	ands.w	r5, r5, #1
d000c5c8:	d115      	bne.n	d000c5f6 <setvbuf+0x176>
d000c5ca:	f412 7f00 	tst.w	r2, #512	; 0x200
d000c5ce:	e7c8      	b.n	d000c562 <setvbuf+0xe2>
d000c5d0:	4648      	mov	r0, r9
d000c5d2:	f7ff fafb 	bl	d000bbcc <malloc>
d000c5d6:	4606      	mov	r6, r0
d000c5d8:	2800      	cmp	r0, #0
d000c5da:	d0ae      	beq.n	d000c53a <setvbuf+0xba>
d000c5dc:	464d      	mov	r5, r9
d000c5de:	89a3      	ldrh	r3, [r4, #12]
d000c5e0:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d000c5e4:	81a3      	strh	r3, [r4, #12]
d000c5e6:	e7d0      	b.n	d000c58a <setvbuf+0x10a>
d000c5e8:	2500      	movs	r5, #0
d000c5ea:	e7a8      	b.n	d000c53e <setvbuf+0xbe>
d000c5ec:	60a3      	str	r3, [r4, #8]
d000c5ee:	e7e8      	b.n	d000c5c2 <setvbuf+0x142>
d000c5f0:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d000c5f4:	e7b9      	b.n	d000c56a <setvbuf+0xea>
d000c5f6:	2500      	movs	r5, #0
d000c5f8:	e7b7      	b.n	d000c56a <setvbuf+0xea>
d000c5fa:	bf00      	nop
d000c5fc:	d000de58 	.word	0xd000de58
d000c600:	d000de10 	.word	0xd000de10
d000c604:	d000de30 	.word	0xd000de30
d000c608:	d000ddf0 	.word	0xd000ddf0

d000c60c <sniprintf>:
d000c60c:	b40c      	push	{r2, r3}
d000c60e:	b530      	push	{r4, r5, lr}
d000c610:	4b17      	ldr	r3, [pc, #92]	; (d000c670 <sniprintf+0x64>)
d000c612:	1e0c      	subs	r4, r1, #0
d000c614:	681d      	ldr	r5, [r3, #0]
d000c616:	b09d      	sub	sp, #116	; 0x74
d000c618:	da08      	bge.n	d000c62c <sniprintf+0x20>
d000c61a:	238b      	movs	r3, #139	; 0x8b
d000c61c:	602b      	str	r3, [r5, #0]
d000c61e:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000c622:	b01d      	add	sp, #116	; 0x74
d000c624:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d000c628:	b002      	add	sp, #8
d000c62a:	4770      	bx	lr
d000c62c:	f44f 7302 	mov.w	r3, #520	; 0x208
d000c630:	f8ad 3014 	strh.w	r3, [sp, #20]
d000c634:	bf14      	ite	ne
d000c636:	f104 33ff 	addne.w	r3, r4, #4294967295	; 0xffffffff
d000c63a:	4623      	moveq	r3, r4
d000c63c:	9304      	str	r3, [sp, #16]
d000c63e:	9307      	str	r3, [sp, #28]
d000c640:	f64f 73ff 	movw	r3, #65535	; 0xffff
d000c644:	9002      	str	r0, [sp, #8]
d000c646:	9006      	str	r0, [sp, #24]
d000c648:	f8ad 3016 	strh.w	r3, [sp, #22]
d000c64c:	9a20      	ldr	r2, [sp, #128]	; 0x80
d000c64e:	ab21      	add	r3, sp, #132	; 0x84
d000c650:	a902      	add	r1, sp, #8
d000c652:	4628      	mov	r0, r5
d000c654:	9301      	str	r3, [sp, #4]
d000c656:	f000 fc13 	bl	d000ce80 <_svfiprintf_r>
d000c65a:	1c43      	adds	r3, r0, #1
d000c65c:	bfbc      	itt	lt
d000c65e:	238b      	movlt	r3, #139	; 0x8b
d000c660:	602b      	strlt	r3, [r5, #0]
d000c662:	2c00      	cmp	r4, #0
d000c664:	d0dd      	beq.n	d000c622 <sniprintf+0x16>
d000c666:	9b02      	ldr	r3, [sp, #8]
d000c668:	2200      	movs	r2, #0
d000c66a:	701a      	strb	r2, [r3, #0]
d000c66c:	e7d9      	b.n	d000c622 <sniprintf+0x16>
d000c66e:	bf00      	nop
d000c670:	d000de58 	.word	0xd000de58

d000c674 <strncpy>:
d000c674:	b510      	push	{r4, lr}
d000c676:	3901      	subs	r1, #1
d000c678:	4603      	mov	r3, r0
d000c67a:	b132      	cbz	r2, d000c68a <strncpy+0x16>
d000c67c:	f811 4f01 	ldrb.w	r4, [r1, #1]!
d000c680:	f803 4b01 	strb.w	r4, [r3], #1
d000c684:	3a01      	subs	r2, #1
d000c686:	2c00      	cmp	r4, #0
d000c688:	d1f7      	bne.n	d000c67a <strncpy+0x6>
d000c68a:	441a      	add	r2, r3
d000c68c:	2100      	movs	r1, #0
d000c68e:	4293      	cmp	r3, r2
d000c690:	d100      	bne.n	d000c694 <strncpy+0x20>
d000c692:	bd10      	pop	{r4, pc}
d000c694:	f803 1b01 	strb.w	r1, [r3], #1
d000c698:	e7f9      	b.n	d000c68e <strncpy+0x1a>

d000c69a <strrchr>:
d000c69a:	b538      	push	{r3, r4, r5, lr}
d000c69c:	4603      	mov	r3, r0
d000c69e:	460c      	mov	r4, r1
d000c6a0:	b969      	cbnz	r1, d000c6be <strrchr+0x24>
d000c6a2:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
d000c6a6:	f000 bd72 	b.w	d000d18e <strchr>
d000c6aa:	1c43      	adds	r3, r0, #1
d000c6ac:	4605      	mov	r5, r0
d000c6ae:	4621      	mov	r1, r4
d000c6b0:	4618      	mov	r0, r3
d000c6b2:	f000 fd6c 	bl	d000d18e <strchr>
d000c6b6:	2800      	cmp	r0, #0
d000c6b8:	d1f7      	bne.n	d000c6aa <strrchr+0x10>
d000c6ba:	4628      	mov	r0, r5
d000c6bc:	bd38      	pop	{r3, r4, r5, pc}
d000c6be:	2500      	movs	r5, #0
d000c6c0:	e7f5      	b.n	d000c6ae <strrchr+0x14>
	...

d000c6c4 <__swbuf_r>:
d000c6c4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000c6c6:	460e      	mov	r6, r1
d000c6c8:	4614      	mov	r4, r2
d000c6ca:	4605      	mov	r5, r0
d000c6cc:	b118      	cbz	r0, d000c6d6 <__swbuf_r+0x12>
d000c6ce:	6983      	ldr	r3, [r0, #24]
d000c6d0:	b90b      	cbnz	r3, d000c6d6 <__swbuf_r+0x12>
d000c6d2:	f000 f9d9 	bl	d000ca88 <__sinit>
d000c6d6:	4b21      	ldr	r3, [pc, #132]	; (d000c75c <__swbuf_r+0x98>)
d000c6d8:	429c      	cmp	r4, r3
d000c6da:	d12b      	bne.n	d000c734 <__swbuf_r+0x70>
d000c6dc:	686c      	ldr	r4, [r5, #4]
d000c6de:	69a3      	ldr	r3, [r4, #24]
d000c6e0:	60a3      	str	r3, [r4, #8]
d000c6e2:	89a3      	ldrh	r3, [r4, #12]
d000c6e4:	071a      	lsls	r2, r3, #28
d000c6e6:	d52f      	bpl.n	d000c748 <__swbuf_r+0x84>
d000c6e8:	6923      	ldr	r3, [r4, #16]
d000c6ea:	b36b      	cbz	r3, d000c748 <__swbuf_r+0x84>
d000c6ec:	6923      	ldr	r3, [r4, #16]
d000c6ee:	6820      	ldr	r0, [r4, #0]
d000c6f0:	1ac0      	subs	r0, r0, r3
d000c6f2:	6963      	ldr	r3, [r4, #20]
d000c6f4:	b2f6      	uxtb	r6, r6
d000c6f6:	4283      	cmp	r3, r0
d000c6f8:	4637      	mov	r7, r6
d000c6fa:	dc04      	bgt.n	d000c706 <__swbuf_r+0x42>
d000c6fc:	4621      	mov	r1, r4
d000c6fe:	4628      	mov	r0, r5
d000c700:	f000 f92e 	bl	d000c960 <_fflush_r>
d000c704:	bb30      	cbnz	r0, d000c754 <__swbuf_r+0x90>
d000c706:	68a3      	ldr	r3, [r4, #8]
d000c708:	3b01      	subs	r3, #1
d000c70a:	60a3      	str	r3, [r4, #8]
d000c70c:	6823      	ldr	r3, [r4, #0]
d000c70e:	1c5a      	adds	r2, r3, #1
d000c710:	6022      	str	r2, [r4, #0]
d000c712:	701e      	strb	r6, [r3, #0]
d000c714:	6963      	ldr	r3, [r4, #20]
d000c716:	3001      	adds	r0, #1
d000c718:	4283      	cmp	r3, r0
d000c71a:	d004      	beq.n	d000c726 <__swbuf_r+0x62>
d000c71c:	89a3      	ldrh	r3, [r4, #12]
d000c71e:	07db      	lsls	r3, r3, #31
d000c720:	d506      	bpl.n	d000c730 <__swbuf_r+0x6c>
d000c722:	2e0a      	cmp	r6, #10
d000c724:	d104      	bne.n	d000c730 <__swbuf_r+0x6c>
d000c726:	4621      	mov	r1, r4
d000c728:	4628      	mov	r0, r5
d000c72a:	f000 f919 	bl	d000c960 <_fflush_r>
d000c72e:	b988      	cbnz	r0, d000c754 <__swbuf_r+0x90>
d000c730:	4638      	mov	r0, r7
d000c732:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d000c734:	4b0a      	ldr	r3, [pc, #40]	; (d000c760 <__swbuf_r+0x9c>)
d000c736:	429c      	cmp	r4, r3
d000c738:	d101      	bne.n	d000c73e <__swbuf_r+0x7a>
d000c73a:	68ac      	ldr	r4, [r5, #8]
d000c73c:	e7cf      	b.n	d000c6de <__swbuf_r+0x1a>
d000c73e:	4b09      	ldr	r3, [pc, #36]	; (d000c764 <__swbuf_r+0xa0>)
d000c740:	429c      	cmp	r4, r3
d000c742:	bf08      	it	eq
d000c744:	68ec      	ldreq	r4, [r5, #12]
d000c746:	e7ca      	b.n	d000c6de <__swbuf_r+0x1a>
d000c748:	4621      	mov	r1, r4
d000c74a:	4628      	mov	r0, r5
d000c74c:	f000 f80c 	bl	d000c768 <__swsetup_r>
d000c750:	2800      	cmp	r0, #0
d000c752:	d0cb      	beq.n	d000c6ec <__swbuf_r+0x28>
d000c754:	f04f 37ff 	mov.w	r7, #4294967295	; 0xffffffff
d000c758:	e7ea      	b.n	d000c730 <__swbuf_r+0x6c>
d000c75a:	bf00      	nop
d000c75c:	d000de10 	.word	0xd000de10
d000c760:	d000de30 	.word	0xd000de30
d000c764:	d000ddf0 	.word	0xd000ddf0

d000c768 <__swsetup_r>:
d000c768:	4b32      	ldr	r3, [pc, #200]	; (d000c834 <__swsetup_r+0xcc>)
d000c76a:	b570      	push	{r4, r5, r6, lr}
d000c76c:	681d      	ldr	r5, [r3, #0]
d000c76e:	4606      	mov	r6, r0
d000c770:	460c      	mov	r4, r1
d000c772:	b125      	cbz	r5, d000c77e <__swsetup_r+0x16>
d000c774:	69ab      	ldr	r3, [r5, #24]
d000c776:	b913      	cbnz	r3, d000c77e <__swsetup_r+0x16>
d000c778:	4628      	mov	r0, r5
d000c77a:	f000 f985 	bl	d000ca88 <__sinit>
d000c77e:	4b2e      	ldr	r3, [pc, #184]	; (d000c838 <__swsetup_r+0xd0>)
d000c780:	429c      	cmp	r4, r3
d000c782:	d10f      	bne.n	d000c7a4 <__swsetup_r+0x3c>
d000c784:	686c      	ldr	r4, [r5, #4]
d000c786:	89a3      	ldrh	r3, [r4, #12]
d000c788:	f9b4 200c 	ldrsh.w	r2, [r4, #12]
d000c78c:	0719      	lsls	r1, r3, #28
d000c78e:	d42c      	bmi.n	d000c7ea <__swsetup_r+0x82>
d000c790:	06dd      	lsls	r5, r3, #27
d000c792:	d411      	bmi.n	d000c7b8 <__swsetup_r+0x50>
d000c794:	2309      	movs	r3, #9
d000c796:	6033      	str	r3, [r6, #0]
d000c798:	f042 0340 	orr.w	r3, r2, #64	; 0x40
d000c79c:	81a3      	strh	r3, [r4, #12]
d000c79e:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000c7a2:	e03e      	b.n	d000c822 <__swsetup_r+0xba>
d000c7a4:	4b25      	ldr	r3, [pc, #148]	; (d000c83c <__swsetup_r+0xd4>)
d000c7a6:	429c      	cmp	r4, r3
d000c7a8:	d101      	bne.n	d000c7ae <__swsetup_r+0x46>
d000c7aa:	68ac      	ldr	r4, [r5, #8]
d000c7ac:	e7eb      	b.n	d000c786 <__swsetup_r+0x1e>
d000c7ae:	4b24      	ldr	r3, [pc, #144]	; (d000c840 <__swsetup_r+0xd8>)
d000c7b0:	429c      	cmp	r4, r3
d000c7b2:	bf08      	it	eq
d000c7b4:	68ec      	ldreq	r4, [r5, #12]
d000c7b6:	e7e6      	b.n	d000c786 <__swsetup_r+0x1e>
d000c7b8:	0758      	lsls	r0, r3, #29
d000c7ba:	d512      	bpl.n	d000c7e2 <__swsetup_r+0x7a>
d000c7bc:	6b61      	ldr	r1, [r4, #52]	; 0x34
d000c7be:	b141      	cbz	r1, d000c7d2 <__swsetup_r+0x6a>
d000c7c0:	f104 0344 	add.w	r3, r4, #68	; 0x44
d000c7c4:	4299      	cmp	r1, r3
d000c7c6:	d002      	beq.n	d000c7ce <__swsetup_r+0x66>
d000c7c8:	4630      	mov	r0, r6
d000c7ca:	f7ff fa43 	bl	d000bc54 <_free_r>
d000c7ce:	2300      	movs	r3, #0
d000c7d0:	6363      	str	r3, [r4, #52]	; 0x34
d000c7d2:	89a3      	ldrh	r3, [r4, #12]
d000c7d4:	f023 0324 	bic.w	r3, r3, #36	; 0x24
d000c7d8:	81a3      	strh	r3, [r4, #12]
d000c7da:	2300      	movs	r3, #0
d000c7dc:	6063      	str	r3, [r4, #4]
d000c7de:	6923      	ldr	r3, [r4, #16]
d000c7e0:	6023      	str	r3, [r4, #0]
d000c7e2:	89a3      	ldrh	r3, [r4, #12]
d000c7e4:	f043 0308 	orr.w	r3, r3, #8
d000c7e8:	81a3      	strh	r3, [r4, #12]
d000c7ea:	6923      	ldr	r3, [r4, #16]
d000c7ec:	b94b      	cbnz	r3, d000c802 <__swsetup_r+0x9a>
d000c7ee:	89a3      	ldrh	r3, [r4, #12]
d000c7f0:	f403 7320 	and.w	r3, r3, #640	; 0x280
d000c7f4:	f5b3 7f00 	cmp.w	r3, #512	; 0x200
d000c7f8:	d003      	beq.n	d000c802 <__swsetup_r+0x9a>
d000c7fa:	4621      	mov	r1, r4
d000c7fc:	4630      	mov	r0, r6
d000c7fe:	f000 fa07 	bl	d000cc10 <__smakebuf_r>
d000c802:	89a0      	ldrh	r0, [r4, #12]
d000c804:	f9b4 200c 	ldrsh.w	r2, [r4, #12]
d000c808:	f010 0301 	ands.w	r3, r0, #1
d000c80c:	d00a      	beq.n	d000c824 <__swsetup_r+0xbc>
d000c80e:	2300      	movs	r3, #0
d000c810:	60a3      	str	r3, [r4, #8]
d000c812:	6963      	ldr	r3, [r4, #20]
d000c814:	425b      	negs	r3, r3
d000c816:	61a3      	str	r3, [r4, #24]
d000c818:	6923      	ldr	r3, [r4, #16]
d000c81a:	b943      	cbnz	r3, d000c82e <__swsetup_r+0xc6>
d000c81c:	f010 0080 	ands.w	r0, r0, #128	; 0x80
d000c820:	d1ba      	bne.n	d000c798 <__swsetup_r+0x30>
d000c822:	bd70      	pop	{r4, r5, r6, pc}
d000c824:	0781      	lsls	r1, r0, #30
d000c826:	bf58      	it	pl
d000c828:	6963      	ldrpl	r3, [r4, #20]
d000c82a:	60a3      	str	r3, [r4, #8]
d000c82c:	e7f4      	b.n	d000c818 <__swsetup_r+0xb0>
d000c82e:	2000      	movs	r0, #0
d000c830:	e7f7      	b.n	d000c822 <__swsetup_r+0xba>
d000c832:	bf00      	nop
d000c834:	d000de58 	.word	0xd000de58
d000c838:	d000de10 	.word	0xd000de10
d000c83c:	d000de30 	.word	0xd000de30
d000c840:	d000ddf0 	.word	0xd000ddf0

d000c844 <abort>:
d000c844:	b508      	push	{r3, lr}
d000c846:	2006      	movs	r0, #6
d000c848:	f000 fc42 	bl	d000d0d0 <raise>
d000c84c:	2001      	movs	r0, #1
d000c84e:	f7f4 fc77 	bl	d0001140 <_exit>
	...

d000c854 <__sflush_r>:
d000c854:	898a      	ldrh	r2, [r1, #12]
d000c856:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d000c85a:	4605      	mov	r5, r0
d000c85c:	0710      	lsls	r0, r2, #28
d000c85e:	460c      	mov	r4, r1
d000c860:	d458      	bmi.n	d000c914 <__sflush_r+0xc0>
d000c862:	684b      	ldr	r3, [r1, #4]
d000c864:	2b00      	cmp	r3, #0
d000c866:	dc05      	bgt.n	d000c874 <__sflush_r+0x20>
d000c868:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d000c86a:	2b00      	cmp	r3, #0
d000c86c:	dc02      	bgt.n	d000c874 <__sflush_r+0x20>
d000c86e:	2000      	movs	r0, #0
d000c870:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d000c874:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d000c876:	2e00      	cmp	r6, #0
d000c878:	d0f9      	beq.n	d000c86e <__sflush_r+0x1a>
d000c87a:	2300      	movs	r3, #0
d000c87c:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d000c880:	682f      	ldr	r7, [r5, #0]
d000c882:	602b      	str	r3, [r5, #0]
d000c884:	d032      	beq.n	d000c8ec <__sflush_r+0x98>
d000c886:	6d60      	ldr	r0, [r4, #84]	; 0x54
d000c888:	89a3      	ldrh	r3, [r4, #12]
d000c88a:	075a      	lsls	r2, r3, #29
d000c88c:	d505      	bpl.n	d000c89a <__sflush_r+0x46>
d000c88e:	6863      	ldr	r3, [r4, #4]
d000c890:	1ac0      	subs	r0, r0, r3
d000c892:	6b63      	ldr	r3, [r4, #52]	; 0x34
d000c894:	b10b      	cbz	r3, d000c89a <__sflush_r+0x46>
d000c896:	6c23      	ldr	r3, [r4, #64]	; 0x40
d000c898:	1ac0      	subs	r0, r0, r3
d000c89a:	2300      	movs	r3, #0
d000c89c:	4602      	mov	r2, r0
d000c89e:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d000c8a0:	6a21      	ldr	r1, [r4, #32]
d000c8a2:	4628      	mov	r0, r5
d000c8a4:	47b0      	blx	r6
d000c8a6:	1c43      	adds	r3, r0, #1
d000c8a8:	89a3      	ldrh	r3, [r4, #12]
d000c8aa:	d106      	bne.n	d000c8ba <__sflush_r+0x66>
d000c8ac:	6829      	ldr	r1, [r5, #0]
d000c8ae:	291d      	cmp	r1, #29
d000c8b0:	d82c      	bhi.n	d000c90c <__sflush_r+0xb8>
d000c8b2:	4a2a      	ldr	r2, [pc, #168]	; (d000c95c <__sflush_r+0x108>)
d000c8b4:	40ca      	lsrs	r2, r1
d000c8b6:	07d6      	lsls	r6, r2, #31
d000c8b8:	d528      	bpl.n	d000c90c <__sflush_r+0xb8>
d000c8ba:	2200      	movs	r2, #0
d000c8bc:	6062      	str	r2, [r4, #4]
d000c8be:	04d9      	lsls	r1, r3, #19
d000c8c0:	6922      	ldr	r2, [r4, #16]
d000c8c2:	6022      	str	r2, [r4, #0]
d000c8c4:	d504      	bpl.n	d000c8d0 <__sflush_r+0x7c>
d000c8c6:	1c42      	adds	r2, r0, #1
d000c8c8:	d101      	bne.n	d000c8ce <__sflush_r+0x7a>
d000c8ca:	682b      	ldr	r3, [r5, #0]
d000c8cc:	b903      	cbnz	r3, d000c8d0 <__sflush_r+0x7c>
d000c8ce:	6560      	str	r0, [r4, #84]	; 0x54
d000c8d0:	6b61      	ldr	r1, [r4, #52]	; 0x34
d000c8d2:	602f      	str	r7, [r5, #0]
d000c8d4:	2900      	cmp	r1, #0
d000c8d6:	d0ca      	beq.n	d000c86e <__sflush_r+0x1a>
d000c8d8:	f104 0344 	add.w	r3, r4, #68	; 0x44
d000c8dc:	4299      	cmp	r1, r3
d000c8de:	d002      	beq.n	d000c8e6 <__sflush_r+0x92>
d000c8e0:	4628      	mov	r0, r5
d000c8e2:	f7ff f9b7 	bl	d000bc54 <_free_r>
d000c8e6:	2000      	movs	r0, #0
d000c8e8:	6360      	str	r0, [r4, #52]	; 0x34
d000c8ea:	e7c1      	b.n	d000c870 <__sflush_r+0x1c>
d000c8ec:	6a21      	ldr	r1, [r4, #32]
d000c8ee:	2301      	movs	r3, #1
d000c8f0:	4628      	mov	r0, r5
d000c8f2:	47b0      	blx	r6
d000c8f4:	1c41      	adds	r1, r0, #1
d000c8f6:	d1c7      	bne.n	d000c888 <__sflush_r+0x34>
d000c8f8:	682b      	ldr	r3, [r5, #0]
d000c8fa:	2b00      	cmp	r3, #0
d000c8fc:	d0c4      	beq.n	d000c888 <__sflush_r+0x34>
d000c8fe:	2b1d      	cmp	r3, #29
d000c900:	d001      	beq.n	d000c906 <__sflush_r+0xb2>
d000c902:	2b16      	cmp	r3, #22
d000c904:	d101      	bne.n	d000c90a <__sflush_r+0xb6>
d000c906:	602f      	str	r7, [r5, #0]
d000c908:	e7b1      	b.n	d000c86e <__sflush_r+0x1a>
d000c90a:	89a3      	ldrh	r3, [r4, #12]
d000c90c:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d000c910:	81a3      	strh	r3, [r4, #12]
d000c912:	e7ad      	b.n	d000c870 <__sflush_r+0x1c>
d000c914:	690f      	ldr	r7, [r1, #16]
d000c916:	2f00      	cmp	r7, #0
d000c918:	d0a9      	beq.n	d000c86e <__sflush_r+0x1a>
d000c91a:	0793      	lsls	r3, r2, #30
d000c91c:	680e      	ldr	r6, [r1, #0]
d000c91e:	bf08      	it	eq
d000c920:	694b      	ldreq	r3, [r1, #20]
d000c922:	600f      	str	r7, [r1, #0]
d000c924:	bf18      	it	ne
d000c926:	2300      	movne	r3, #0
d000c928:	eba6 0807 	sub.w	r8, r6, r7
d000c92c:	608b      	str	r3, [r1, #8]
d000c92e:	f1b8 0f00 	cmp.w	r8, #0
d000c932:	dd9c      	ble.n	d000c86e <__sflush_r+0x1a>
d000c934:	6a21      	ldr	r1, [r4, #32]
d000c936:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d000c938:	4643      	mov	r3, r8
d000c93a:	463a      	mov	r2, r7
d000c93c:	4628      	mov	r0, r5
d000c93e:	47b0      	blx	r6
d000c940:	2800      	cmp	r0, #0
d000c942:	dc06      	bgt.n	d000c952 <__sflush_r+0xfe>
d000c944:	89a3      	ldrh	r3, [r4, #12]
d000c946:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d000c94a:	81a3      	strh	r3, [r4, #12]
d000c94c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000c950:	e78e      	b.n	d000c870 <__sflush_r+0x1c>
d000c952:	4407      	add	r7, r0
d000c954:	eba8 0800 	sub.w	r8, r8, r0
d000c958:	e7e9      	b.n	d000c92e <__sflush_r+0xda>
d000c95a:	bf00      	nop
d000c95c:	20400001 	.word	0x20400001

d000c960 <_fflush_r>:
d000c960:	b538      	push	{r3, r4, r5, lr}
d000c962:	690b      	ldr	r3, [r1, #16]
d000c964:	4605      	mov	r5, r0
d000c966:	460c      	mov	r4, r1
d000c968:	b913      	cbnz	r3, d000c970 <_fflush_r+0x10>
d000c96a:	2500      	movs	r5, #0
d000c96c:	4628      	mov	r0, r5
d000c96e:	bd38      	pop	{r3, r4, r5, pc}
d000c970:	b118      	cbz	r0, d000c97a <_fflush_r+0x1a>
d000c972:	6983      	ldr	r3, [r0, #24]
d000c974:	b90b      	cbnz	r3, d000c97a <_fflush_r+0x1a>
d000c976:	f000 f887 	bl	d000ca88 <__sinit>
d000c97a:	4b14      	ldr	r3, [pc, #80]	; (d000c9cc <_fflush_r+0x6c>)
d000c97c:	429c      	cmp	r4, r3
d000c97e:	d11b      	bne.n	d000c9b8 <_fflush_r+0x58>
d000c980:	686c      	ldr	r4, [r5, #4]
d000c982:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d000c986:	2b00      	cmp	r3, #0
d000c988:	d0ef      	beq.n	d000c96a <_fflush_r+0xa>
d000c98a:	6e62      	ldr	r2, [r4, #100]	; 0x64
d000c98c:	07d0      	lsls	r0, r2, #31
d000c98e:	d404      	bmi.n	d000c99a <_fflush_r+0x3a>
d000c990:	0599      	lsls	r1, r3, #22
d000c992:	d402      	bmi.n	d000c99a <_fflush_r+0x3a>
d000c994:	6da0      	ldr	r0, [r4, #88]	; 0x58
d000c996:	f000 f915 	bl	d000cbc4 <__retarget_lock_acquire_recursive>
d000c99a:	4628      	mov	r0, r5
d000c99c:	4621      	mov	r1, r4
d000c99e:	f7ff ff59 	bl	d000c854 <__sflush_r>
d000c9a2:	6e63      	ldr	r3, [r4, #100]	; 0x64
d000c9a4:	07da      	lsls	r2, r3, #31
d000c9a6:	4605      	mov	r5, r0
d000c9a8:	d4e0      	bmi.n	d000c96c <_fflush_r+0xc>
d000c9aa:	89a3      	ldrh	r3, [r4, #12]
d000c9ac:	059b      	lsls	r3, r3, #22
d000c9ae:	d4dd      	bmi.n	d000c96c <_fflush_r+0xc>
d000c9b0:	6da0      	ldr	r0, [r4, #88]	; 0x58
d000c9b2:	f000 f908 	bl	d000cbc6 <__retarget_lock_release_recursive>
d000c9b6:	e7d9      	b.n	d000c96c <_fflush_r+0xc>
d000c9b8:	4b05      	ldr	r3, [pc, #20]	; (d000c9d0 <_fflush_r+0x70>)
d000c9ba:	429c      	cmp	r4, r3
d000c9bc:	d101      	bne.n	d000c9c2 <_fflush_r+0x62>
d000c9be:	68ac      	ldr	r4, [r5, #8]
d000c9c0:	e7df      	b.n	d000c982 <_fflush_r+0x22>
d000c9c2:	4b04      	ldr	r3, [pc, #16]	; (d000c9d4 <_fflush_r+0x74>)
d000c9c4:	429c      	cmp	r4, r3
d000c9c6:	bf08      	it	eq
d000c9c8:	68ec      	ldreq	r4, [r5, #12]
d000c9ca:	e7da      	b.n	d000c982 <_fflush_r+0x22>
d000c9cc:	d000de10 	.word	0xd000de10
d000c9d0:	d000de30 	.word	0xd000de30
d000c9d4:	d000ddf0 	.word	0xd000ddf0

d000c9d8 <std>:
d000c9d8:	2300      	movs	r3, #0
d000c9da:	b510      	push	{r4, lr}
d000c9dc:	4604      	mov	r4, r0
d000c9de:	e9c0 3300 	strd	r3, r3, [r0]
d000c9e2:	e9c0 3304 	strd	r3, r3, [r0, #16]
d000c9e6:	6083      	str	r3, [r0, #8]
d000c9e8:	8181      	strh	r1, [r0, #12]
d000c9ea:	6643      	str	r3, [r0, #100]	; 0x64
d000c9ec:	81c2      	strh	r2, [r0, #14]
d000c9ee:	6183      	str	r3, [r0, #24]
d000c9f0:	4619      	mov	r1, r3
d000c9f2:	2208      	movs	r2, #8
d000c9f4:	305c      	adds	r0, #92	; 0x5c
d000c9f6:	f7ff f915 	bl	d000bc24 <memset>
d000c9fa:	4b05      	ldr	r3, [pc, #20]	; (d000ca10 <std+0x38>)
d000c9fc:	6263      	str	r3, [r4, #36]	; 0x24
d000c9fe:	4b05      	ldr	r3, [pc, #20]	; (d000ca14 <std+0x3c>)
d000ca00:	62a3      	str	r3, [r4, #40]	; 0x28
d000ca02:	4b05      	ldr	r3, [pc, #20]	; (d000ca18 <std+0x40>)
d000ca04:	62e3      	str	r3, [r4, #44]	; 0x2c
d000ca06:	4b05      	ldr	r3, [pc, #20]	; (d000ca1c <std+0x44>)
d000ca08:	6224      	str	r4, [r4, #32]
d000ca0a:	6323      	str	r3, [r4, #48]	; 0x30
d000ca0c:	bd10      	pop	{r4, pc}
d000ca0e:	bf00      	nop
d000ca10:	d000d109 	.word	0xd000d109
d000ca14:	d000d12b 	.word	0xd000d12b
d000ca18:	d000d163 	.word	0xd000d163
d000ca1c:	d000d187 	.word	0xd000d187

d000ca20 <_cleanup_r>:
d000ca20:	4901      	ldr	r1, [pc, #4]	; (d000ca28 <_cleanup_r+0x8>)
d000ca22:	f000 b8af 	b.w	d000cb84 <_fwalk_reent>
d000ca26:	bf00      	nop
d000ca28:	d000c961 	.word	0xd000c961

d000ca2c <__sfmoreglue>:
d000ca2c:	b570      	push	{r4, r5, r6, lr}
d000ca2e:	1e4a      	subs	r2, r1, #1
d000ca30:	2568      	movs	r5, #104	; 0x68
d000ca32:	4355      	muls	r5, r2
d000ca34:	460e      	mov	r6, r1
d000ca36:	f105 0174 	add.w	r1, r5, #116	; 0x74
d000ca3a:	f7ff f95b 	bl	d000bcf4 <_malloc_r>
d000ca3e:	4604      	mov	r4, r0
d000ca40:	b140      	cbz	r0, d000ca54 <__sfmoreglue+0x28>
d000ca42:	2100      	movs	r1, #0
d000ca44:	e9c0 1600 	strd	r1, r6, [r0]
d000ca48:	300c      	adds	r0, #12
d000ca4a:	60a0      	str	r0, [r4, #8]
d000ca4c:	f105 0268 	add.w	r2, r5, #104	; 0x68
d000ca50:	f7ff f8e8 	bl	d000bc24 <memset>
d000ca54:	4620      	mov	r0, r4
d000ca56:	bd70      	pop	{r4, r5, r6, pc}

d000ca58 <__sfp_lock_acquire>:
d000ca58:	4801      	ldr	r0, [pc, #4]	; (d000ca60 <__sfp_lock_acquire+0x8>)
d000ca5a:	f000 b8b3 	b.w	d000cbc4 <__retarget_lock_acquire_recursive>
d000ca5e:	bf00      	nop
d000ca60:	d000f12c 	.word	0xd000f12c

d000ca64 <__sfp_lock_release>:
d000ca64:	4801      	ldr	r0, [pc, #4]	; (d000ca6c <__sfp_lock_release+0x8>)
d000ca66:	f000 b8ae 	b.w	d000cbc6 <__retarget_lock_release_recursive>
d000ca6a:	bf00      	nop
d000ca6c:	d000f12c 	.word	0xd000f12c

d000ca70 <__sinit_lock_acquire>:
d000ca70:	4801      	ldr	r0, [pc, #4]	; (d000ca78 <__sinit_lock_acquire+0x8>)
d000ca72:	f000 b8a7 	b.w	d000cbc4 <__retarget_lock_acquire_recursive>
d000ca76:	bf00      	nop
d000ca78:	d000f127 	.word	0xd000f127

d000ca7c <__sinit_lock_release>:
d000ca7c:	4801      	ldr	r0, [pc, #4]	; (d000ca84 <__sinit_lock_release+0x8>)
d000ca7e:	f000 b8a2 	b.w	d000cbc6 <__retarget_lock_release_recursive>
d000ca82:	bf00      	nop
d000ca84:	d000f127 	.word	0xd000f127

d000ca88 <__sinit>:
d000ca88:	b510      	push	{r4, lr}
d000ca8a:	4604      	mov	r4, r0
d000ca8c:	f7ff fff0 	bl	d000ca70 <__sinit_lock_acquire>
d000ca90:	69a3      	ldr	r3, [r4, #24]
d000ca92:	b11b      	cbz	r3, d000ca9c <__sinit+0x14>
d000ca94:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d000ca98:	f7ff bff0 	b.w	d000ca7c <__sinit_lock_release>
d000ca9c:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d000caa0:	6523      	str	r3, [r4, #80]	; 0x50
d000caa2:	4b13      	ldr	r3, [pc, #76]	; (d000caf0 <__sinit+0x68>)
d000caa4:	4a13      	ldr	r2, [pc, #76]	; (d000caf4 <__sinit+0x6c>)
d000caa6:	681b      	ldr	r3, [r3, #0]
d000caa8:	62a2      	str	r2, [r4, #40]	; 0x28
d000caaa:	42a3      	cmp	r3, r4
d000caac:	bf04      	itt	eq
d000caae:	2301      	moveq	r3, #1
d000cab0:	61a3      	streq	r3, [r4, #24]
d000cab2:	4620      	mov	r0, r4
d000cab4:	f000 f820 	bl	d000caf8 <__sfp>
d000cab8:	6060      	str	r0, [r4, #4]
d000caba:	4620      	mov	r0, r4
d000cabc:	f000 f81c 	bl	d000caf8 <__sfp>
d000cac0:	60a0      	str	r0, [r4, #8]
d000cac2:	4620      	mov	r0, r4
d000cac4:	f000 f818 	bl	d000caf8 <__sfp>
d000cac8:	2200      	movs	r2, #0
d000caca:	60e0      	str	r0, [r4, #12]
d000cacc:	2104      	movs	r1, #4
d000cace:	6860      	ldr	r0, [r4, #4]
d000cad0:	f7ff ff82 	bl	d000c9d8 <std>
d000cad4:	68a0      	ldr	r0, [r4, #8]
d000cad6:	2201      	movs	r2, #1
d000cad8:	2109      	movs	r1, #9
d000cada:	f7ff ff7d 	bl	d000c9d8 <std>
d000cade:	68e0      	ldr	r0, [r4, #12]
d000cae0:	2202      	movs	r2, #2
d000cae2:	2112      	movs	r1, #18
d000cae4:	f7ff ff78 	bl	d000c9d8 <std>
d000cae8:	2301      	movs	r3, #1
d000caea:	61a3      	str	r3, [r4, #24]
d000caec:	e7d2      	b.n	d000ca94 <__sinit+0xc>
d000caee:	bf00      	nop
d000caf0:	d000ddb8 	.word	0xd000ddb8
d000caf4:	d000ca21 	.word	0xd000ca21

d000caf8 <__sfp>:
d000caf8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000cafa:	4607      	mov	r7, r0
d000cafc:	f7ff ffac 	bl	d000ca58 <__sfp_lock_acquire>
d000cb00:	4b1e      	ldr	r3, [pc, #120]	; (d000cb7c <__sfp+0x84>)
d000cb02:	681e      	ldr	r6, [r3, #0]
d000cb04:	69b3      	ldr	r3, [r6, #24]
d000cb06:	b913      	cbnz	r3, d000cb0e <__sfp+0x16>
d000cb08:	4630      	mov	r0, r6
d000cb0a:	f7ff ffbd 	bl	d000ca88 <__sinit>
d000cb0e:	3648      	adds	r6, #72	; 0x48
d000cb10:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d000cb14:	3b01      	subs	r3, #1
d000cb16:	d503      	bpl.n	d000cb20 <__sfp+0x28>
d000cb18:	6833      	ldr	r3, [r6, #0]
d000cb1a:	b30b      	cbz	r3, d000cb60 <__sfp+0x68>
d000cb1c:	6836      	ldr	r6, [r6, #0]
d000cb1e:	e7f7      	b.n	d000cb10 <__sfp+0x18>
d000cb20:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d000cb24:	b9d5      	cbnz	r5, d000cb5c <__sfp+0x64>
d000cb26:	4b16      	ldr	r3, [pc, #88]	; (d000cb80 <__sfp+0x88>)
d000cb28:	60e3      	str	r3, [r4, #12]
d000cb2a:	f104 0058 	add.w	r0, r4, #88	; 0x58
d000cb2e:	6665      	str	r5, [r4, #100]	; 0x64
d000cb30:	f000 f847 	bl	d000cbc2 <__retarget_lock_init_recursive>
d000cb34:	f7ff ff96 	bl	d000ca64 <__sfp_lock_release>
d000cb38:	e9c4 5501 	strd	r5, r5, [r4, #4]
d000cb3c:	e9c4 5504 	strd	r5, r5, [r4, #16]
d000cb40:	6025      	str	r5, [r4, #0]
d000cb42:	61a5      	str	r5, [r4, #24]
d000cb44:	2208      	movs	r2, #8
d000cb46:	4629      	mov	r1, r5
d000cb48:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d000cb4c:	f7ff f86a 	bl	d000bc24 <memset>
d000cb50:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d000cb54:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d000cb58:	4620      	mov	r0, r4
d000cb5a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d000cb5c:	3468      	adds	r4, #104	; 0x68
d000cb5e:	e7d9      	b.n	d000cb14 <__sfp+0x1c>
d000cb60:	2104      	movs	r1, #4
d000cb62:	4638      	mov	r0, r7
d000cb64:	f7ff ff62 	bl	d000ca2c <__sfmoreglue>
d000cb68:	4604      	mov	r4, r0
d000cb6a:	6030      	str	r0, [r6, #0]
d000cb6c:	2800      	cmp	r0, #0
d000cb6e:	d1d5      	bne.n	d000cb1c <__sfp+0x24>
d000cb70:	f7ff ff78 	bl	d000ca64 <__sfp_lock_release>
d000cb74:	230c      	movs	r3, #12
d000cb76:	603b      	str	r3, [r7, #0]
d000cb78:	e7ee      	b.n	d000cb58 <__sfp+0x60>
d000cb7a:	bf00      	nop
d000cb7c:	d000ddb8 	.word	0xd000ddb8
d000cb80:	ffff0001 	.word	0xffff0001

d000cb84 <_fwalk_reent>:
d000cb84:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d000cb88:	4606      	mov	r6, r0
d000cb8a:	4688      	mov	r8, r1
d000cb8c:	f100 0448 	add.w	r4, r0, #72	; 0x48
d000cb90:	2700      	movs	r7, #0
d000cb92:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d000cb96:	f1b9 0901 	subs.w	r9, r9, #1
d000cb9a:	d505      	bpl.n	d000cba8 <_fwalk_reent+0x24>
d000cb9c:	6824      	ldr	r4, [r4, #0]
d000cb9e:	2c00      	cmp	r4, #0
d000cba0:	d1f7      	bne.n	d000cb92 <_fwalk_reent+0xe>
d000cba2:	4638      	mov	r0, r7
d000cba4:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d000cba8:	89ab      	ldrh	r3, [r5, #12]
d000cbaa:	2b01      	cmp	r3, #1
d000cbac:	d907      	bls.n	d000cbbe <_fwalk_reent+0x3a>
d000cbae:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d000cbb2:	3301      	adds	r3, #1
d000cbb4:	d003      	beq.n	d000cbbe <_fwalk_reent+0x3a>
d000cbb6:	4629      	mov	r1, r5
d000cbb8:	4630      	mov	r0, r6
d000cbba:	47c0      	blx	r8
d000cbbc:	4307      	orrs	r7, r0
d000cbbe:	3568      	adds	r5, #104	; 0x68
d000cbc0:	e7e9      	b.n	d000cb96 <_fwalk_reent+0x12>

d000cbc2 <__retarget_lock_init_recursive>:
d000cbc2:	4770      	bx	lr

d000cbc4 <__retarget_lock_acquire_recursive>:
d000cbc4:	4770      	bx	lr

d000cbc6 <__retarget_lock_release_recursive>:
d000cbc6:	4770      	bx	lr

d000cbc8 <__swhatbuf_r>:
d000cbc8:	b570      	push	{r4, r5, r6, lr}
d000cbca:	460e      	mov	r6, r1
d000cbcc:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d000cbd0:	2900      	cmp	r1, #0
d000cbd2:	b096      	sub	sp, #88	; 0x58
d000cbd4:	4614      	mov	r4, r2
d000cbd6:	461d      	mov	r5, r3
d000cbd8:	da07      	bge.n	d000cbea <__swhatbuf_r+0x22>
d000cbda:	2300      	movs	r3, #0
d000cbdc:	602b      	str	r3, [r5, #0]
d000cbde:	89b3      	ldrh	r3, [r6, #12]
d000cbe0:	061a      	lsls	r2, r3, #24
d000cbe2:	d410      	bmi.n	d000cc06 <__swhatbuf_r+0x3e>
d000cbe4:	f44f 6380 	mov.w	r3, #1024	; 0x400
d000cbe8:	e00e      	b.n	d000cc08 <__swhatbuf_r+0x40>
d000cbea:	466a      	mov	r2, sp
d000cbec:	f000 faec 	bl	d000d1c8 <_fstat_r>
d000cbf0:	2800      	cmp	r0, #0
d000cbf2:	dbf2      	blt.n	d000cbda <__swhatbuf_r+0x12>
d000cbf4:	9a01      	ldr	r2, [sp, #4]
d000cbf6:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d000cbfa:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d000cbfe:	425a      	negs	r2, r3
d000cc00:	415a      	adcs	r2, r3
d000cc02:	602a      	str	r2, [r5, #0]
d000cc04:	e7ee      	b.n	d000cbe4 <__swhatbuf_r+0x1c>
d000cc06:	2340      	movs	r3, #64	; 0x40
d000cc08:	2000      	movs	r0, #0
d000cc0a:	6023      	str	r3, [r4, #0]
d000cc0c:	b016      	add	sp, #88	; 0x58
d000cc0e:	bd70      	pop	{r4, r5, r6, pc}

d000cc10 <__smakebuf_r>:
d000cc10:	898b      	ldrh	r3, [r1, #12]
d000cc12:	b573      	push	{r0, r1, r4, r5, r6, lr}
d000cc14:	079d      	lsls	r5, r3, #30
d000cc16:	4606      	mov	r6, r0
d000cc18:	460c      	mov	r4, r1
d000cc1a:	d507      	bpl.n	d000cc2c <__smakebuf_r+0x1c>
d000cc1c:	f104 0347 	add.w	r3, r4, #71	; 0x47
d000cc20:	6023      	str	r3, [r4, #0]
d000cc22:	6123      	str	r3, [r4, #16]
d000cc24:	2301      	movs	r3, #1
d000cc26:	6163      	str	r3, [r4, #20]
d000cc28:	b002      	add	sp, #8
d000cc2a:	bd70      	pop	{r4, r5, r6, pc}
d000cc2c:	ab01      	add	r3, sp, #4
d000cc2e:	466a      	mov	r2, sp
d000cc30:	f7ff ffca 	bl	d000cbc8 <__swhatbuf_r>
d000cc34:	9900      	ldr	r1, [sp, #0]
d000cc36:	4605      	mov	r5, r0
d000cc38:	4630      	mov	r0, r6
d000cc3a:	f7ff f85b 	bl	d000bcf4 <_malloc_r>
d000cc3e:	b948      	cbnz	r0, d000cc54 <__smakebuf_r+0x44>
d000cc40:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d000cc44:	059a      	lsls	r2, r3, #22
d000cc46:	d4ef      	bmi.n	d000cc28 <__smakebuf_r+0x18>
d000cc48:	f023 0303 	bic.w	r3, r3, #3
d000cc4c:	f043 0302 	orr.w	r3, r3, #2
d000cc50:	81a3      	strh	r3, [r4, #12]
d000cc52:	e7e3      	b.n	d000cc1c <__smakebuf_r+0xc>
d000cc54:	4b0d      	ldr	r3, [pc, #52]	; (d000cc8c <__smakebuf_r+0x7c>)
d000cc56:	62b3      	str	r3, [r6, #40]	; 0x28
d000cc58:	89a3      	ldrh	r3, [r4, #12]
d000cc5a:	6020      	str	r0, [r4, #0]
d000cc5c:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d000cc60:	81a3      	strh	r3, [r4, #12]
d000cc62:	9b00      	ldr	r3, [sp, #0]
d000cc64:	6163      	str	r3, [r4, #20]
d000cc66:	9b01      	ldr	r3, [sp, #4]
d000cc68:	6120      	str	r0, [r4, #16]
d000cc6a:	b15b      	cbz	r3, d000cc84 <__smakebuf_r+0x74>
d000cc6c:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d000cc70:	4630      	mov	r0, r6
d000cc72:	f000 fabb 	bl	d000d1ec <_isatty_r>
d000cc76:	b128      	cbz	r0, d000cc84 <__smakebuf_r+0x74>
d000cc78:	89a3      	ldrh	r3, [r4, #12]
d000cc7a:	f023 0303 	bic.w	r3, r3, #3
d000cc7e:	f043 0301 	orr.w	r3, r3, #1
d000cc82:	81a3      	strh	r3, [r4, #12]
d000cc84:	89a0      	ldrh	r0, [r4, #12]
d000cc86:	4305      	orrs	r5, r0
d000cc88:	81a5      	strh	r5, [r4, #12]
d000cc8a:	e7cd      	b.n	d000cc28 <__smakebuf_r+0x18>
d000cc8c:	d000ca21 	.word	0xd000ca21

d000cc90 <memchr>:
d000cc90:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d000cc94:	2a10      	cmp	r2, #16
d000cc96:	db2b      	blt.n	d000ccf0 <memchr+0x60>
d000cc98:	f010 0f07 	tst.w	r0, #7
d000cc9c:	d008      	beq.n	d000ccb0 <memchr+0x20>
d000cc9e:	f810 3b01 	ldrb.w	r3, [r0], #1
d000cca2:	3a01      	subs	r2, #1
d000cca4:	428b      	cmp	r3, r1
d000cca6:	d02d      	beq.n	d000cd04 <memchr+0x74>
d000cca8:	f010 0f07 	tst.w	r0, #7
d000ccac:	b342      	cbz	r2, d000cd00 <memchr+0x70>
d000ccae:	d1f6      	bne.n	d000cc9e <memchr+0xe>
d000ccb0:	b4f0      	push	{r4, r5, r6, r7}
d000ccb2:	ea41 2101 	orr.w	r1, r1, r1, lsl #8
d000ccb6:	ea41 4101 	orr.w	r1, r1, r1, lsl #16
d000ccba:	f022 0407 	bic.w	r4, r2, #7
d000ccbe:	f07f 0700 	mvns.w	r7, #0
d000ccc2:	2300      	movs	r3, #0
d000ccc4:	e8f0 5602 	ldrd	r5, r6, [r0], #8
d000ccc8:	3c08      	subs	r4, #8
d000ccca:	ea85 0501 	eor.w	r5, r5, r1
d000ccce:	ea86 0601 	eor.w	r6, r6, r1
d000ccd2:	fa85 f547 	uadd8	r5, r5, r7
d000ccd6:	faa3 f587 	sel	r5, r3, r7
d000ccda:	fa86 f647 	uadd8	r6, r6, r7
d000ccde:	faa5 f687 	sel	r6, r5, r7
d000cce2:	b98e      	cbnz	r6, d000cd08 <memchr+0x78>
d000cce4:	d1ee      	bne.n	d000ccc4 <memchr+0x34>
d000cce6:	bcf0      	pop	{r4, r5, r6, r7}
d000cce8:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d000ccec:	f002 0207 	and.w	r2, r2, #7
d000ccf0:	b132      	cbz	r2, d000cd00 <memchr+0x70>
d000ccf2:	f810 3b01 	ldrb.w	r3, [r0], #1
d000ccf6:	3a01      	subs	r2, #1
d000ccf8:	ea83 0301 	eor.w	r3, r3, r1
d000ccfc:	b113      	cbz	r3, d000cd04 <memchr+0x74>
d000ccfe:	d1f8      	bne.n	d000ccf2 <memchr+0x62>
d000cd00:	2000      	movs	r0, #0
d000cd02:	4770      	bx	lr
d000cd04:	3801      	subs	r0, #1
d000cd06:	4770      	bx	lr
d000cd08:	2d00      	cmp	r5, #0
d000cd0a:	bf06      	itte	eq
d000cd0c:	4635      	moveq	r5, r6
d000cd0e:	3803      	subeq	r0, #3
d000cd10:	3807      	subne	r0, #7
d000cd12:	f015 0f01 	tst.w	r5, #1
d000cd16:	d107      	bne.n	d000cd28 <memchr+0x98>
d000cd18:	3001      	adds	r0, #1
d000cd1a:	f415 7f80 	tst.w	r5, #256	; 0x100
d000cd1e:	bf02      	ittt	eq
d000cd20:	3001      	addeq	r0, #1
d000cd22:	f415 3fc0 	tsteq.w	r5, #98304	; 0x18000
d000cd26:	3001      	addeq	r0, #1
d000cd28:	bcf0      	pop	{r4, r5, r6, r7}
d000cd2a:	3801      	subs	r0, #1
d000cd2c:	4770      	bx	lr
d000cd2e:	bf00      	nop

d000cd30 <memmove>:
d000cd30:	4288      	cmp	r0, r1
d000cd32:	b510      	push	{r4, lr}
d000cd34:	eb01 0402 	add.w	r4, r1, r2
d000cd38:	d902      	bls.n	d000cd40 <memmove+0x10>
d000cd3a:	4284      	cmp	r4, r0
d000cd3c:	4623      	mov	r3, r4
d000cd3e:	d807      	bhi.n	d000cd50 <memmove+0x20>
d000cd40:	1e43      	subs	r3, r0, #1
d000cd42:	42a1      	cmp	r1, r4
d000cd44:	d008      	beq.n	d000cd58 <memmove+0x28>
d000cd46:	f811 2b01 	ldrb.w	r2, [r1], #1
d000cd4a:	f803 2f01 	strb.w	r2, [r3, #1]!
d000cd4e:	e7f8      	b.n	d000cd42 <memmove+0x12>
d000cd50:	4402      	add	r2, r0
d000cd52:	4601      	mov	r1, r0
d000cd54:	428a      	cmp	r2, r1
d000cd56:	d100      	bne.n	d000cd5a <memmove+0x2a>
d000cd58:	bd10      	pop	{r4, pc}
d000cd5a:	f813 4d01 	ldrb.w	r4, [r3, #-1]!
d000cd5e:	f802 4d01 	strb.w	r4, [r2, #-1]!
d000cd62:	e7f7      	b.n	d000cd54 <memmove+0x24>

d000cd64 <__malloc_lock>:
d000cd64:	4801      	ldr	r0, [pc, #4]	; (d000cd6c <__malloc_lock+0x8>)
d000cd66:	f7ff bf2d 	b.w	d000cbc4 <__retarget_lock_acquire_recursive>
d000cd6a:	bf00      	nop
d000cd6c:	d000f128 	.word	0xd000f128

d000cd70 <__malloc_unlock>:
d000cd70:	4801      	ldr	r0, [pc, #4]	; (d000cd78 <__malloc_unlock+0x8>)
d000cd72:	f7ff bf28 	b.w	d000cbc6 <__retarget_lock_release_recursive>
d000cd76:	bf00      	nop
d000cd78:	d000f128 	.word	0xd000f128

d000cd7c <_realloc_r>:
d000cd7c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000cd7e:	4607      	mov	r7, r0
d000cd80:	4614      	mov	r4, r2
d000cd82:	460e      	mov	r6, r1
d000cd84:	b921      	cbnz	r1, d000cd90 <_realloc_r+0x14>
d000cd86:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
d000cd8a:	4611      	mov	r1, r2
d000cd8c:	f7fe bfb2 	b.w	d000bcf4 <_malloc_r>
d000cd90:	b922      	cbnz	r2, d000cd9c <_realloc_r+0x20>
d000cd92:	f7fe ff5f 	bl	d000bc54 <_free_r>
d000cd96:	4625      	mov	r5, r4
d000cd98:	4628      	mov	r0, r5
d000cd9a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d000cd9c:	f000 fa48 	bl	d000d230 <_malloc_usable_size_r>
d000cda0:	42a0      	cmp	r0, r4
d000cda2:	d20f      	bcs.n	d000cdc4 <_realloc_r+0x48>
d000cda4:	4621      	mov	r1, r4
d000cda6:	4638      	mov	r0, r7
d000cda8:	f7fe ffa4 	bl	d000bcf4 <_malloc_r>
d000cdac:	4605      	mov	r5, r0
d000cdae:	2800      	cmp	r0, #0
d000cdb0:	d0f2      	beq.n	d000cd98 <_realloc_r+0x1c>
d000cdb2:	4631      	mov	r1, r6
d000cdb4:	4622      	mov	r2, r4
d000cdb6:	f7fe ff27 	bl	d000bc08 <memcpy>
d000cdba:	4631      	mov	r1, r6
d000cdbc:	4638      	mov	r0, r7
d000cdbe:	f7fe ff49 	bl	d000bc54 <_free_r>
d000cdc2:	e7e9      	b.n	d000cd98 <_realloc_r+0x1c>
d000cdc4:	4635      	mov	r5, r6
d000cdc6:	e7e7      	b.n	d000cd98 <_realloc_r+0x1c>

d000cdc8 <__ssputs_r>:
d000cdc8:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d000cdcc:	688e      	ldr	r6, [r1, #8]
d000cdce:	429e      	cmp	r6, r3
d000cdd0:	4682      	mov	sl, r0
d000cdd2:	460c      	mov	r4, r1
d000cdd4:	4690      	mov	r8, r2
d000cdd6:	461f      	mov	r7, r3
d000cdd8:	d838      	bhi.n	d000ce4c <__ssputs_r+0x84>
d000cdda:	898a      	ldrh	r2, [r1, #12]
d000cddc:	f412 6f90 	tst.w	r2, #1152	; 0x480
d000cde0:	d032      	beq.n	d000ce48 <__ssputs_r+0x80>
d000cde2:	6825      	ldr	r5, [r4, #0]
d000cde4:	6909      	ldr	r1, [r1, #16]
d000cde6:	eba5 0901 	sub.w	r9, r5, r1
d000cdea:	6965      	ldr	r5, [r4, #20]
d000cdec:	eb05 0545 	add.w	r5, r5, r5, lsl #1
d000cdf0:	eb05 75d5 	add.w	r5, r5, r5, lsr #31
d000cdf4:	3301      	adds	r3, #1
d000cdf6:	444b      	add	r3, r9
d000cdf8:	106d      	asrs	r5, r5, #1
d000cdfa:	429d      	cmp	r5, r3
d000cdfc:	bf38      	it	cc
d000cdfe:	461d      	movcc	r5, r3
d000ce00:	0553      	lsls	r3, r2, #21
d000ce02:	d531      	bpl.n	d000ce68 <__ssputs_r+0xa0>
d000ce04:	4629      	mov	r1, r5
d000ce06:	f7fe ff75 	bl	d000bcf4 <_malloc_r>
d000ce0a:	4606      	mov	r6, r0
d000ce0c:	b950      	cbnz	r0, d000ce24 <__ssputs_r+0x5c>
d000ce0e:	230c      	movs	r3, #12
d000ce10:	f8ca 3000 	str.w	r3, [sl]
d000ce14:	89a3      	ldrh	r3, [r4, #12]
d000ce16:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d000ce1a:	81a3      	strh	r3, [r4, #12]
d000ce1c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000ce20:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d000ce24:	6921      	ldr	r1, [r4, #16]
d000ce26:	464a      	mov	r2, r9
d000ce28:	f7fe feee 	bl	d000bc08 <memcpy>
d000ce2c:	89a3      	ldrh	r3, [r4, #12]
d000ce2e:	f423 6390 	bic.w	r3, r3, #1152	; 0x480
d000ce32:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d000ce36:	81a3      	strh	r3, [r4, #12]
d000ce38:	6126      	str	r6, [r4, #16]
d000ce3a:	6165      	str	r5, [r4, #20]
d000ce3c:	444e      	add	r6, r9
d000ce3e:	eba5 0509 	sub.w	r5, r5, r9
d000ce42:	6026      	str	r6, [r4, #0]
d000ce44:	60a5      	str	r5, [r4, #8]
d000ce46:	463e      	mov	r6, r7
d000ce48:	42be      	cmp	r6, r7
d000ce4a:	d900      	bls.n	d000ce4e <__ssputs_r+0x86>
d000ce4c:	463e      	mov	r6, r7
d000ce4e:	4632      	mov	r2, r6
d000ce50:	6820      	ldr	r0, [r4, #0]
d000ce52:	4641      	mov	r1, r8
d000ce54:	f7ff ff6c 	bl	d000cd30 <memmove>
d000ce58:	68a3      	ldr	r3, [r4, #8]
d000ce5a:	6822      	ldr	r2, [r4, #0]
d000ce5c:	1b9b      	subs	r3, r3, r6
d000ce5e:	4432      	add	r2, r6
d000ce60:	60a3      	str	r3, [r4, #8]
d000ce62:	6022      	str	r2, [r4, #0]
d000ce64:	2000      	movs	r0, #0
d000ce66:	e7db      	b.n	d000ce20 <__ssputs_r+0x58>
d000ce68:	462a      	mov	r2, r5
d000ce6a:	f7ff ff87 	bl	d000cd7c <_realloc_r>
d000ce6e:	4606      	mov	r6, r0
d000ce70:	2800      	cmp	r0, #0
d000ce72:	d1e1      	bne.n	d000ce38 <__ssputs_r+0x70>
d000ce74:	6921      	ldr	r1, [r4, #16]
d000ce76:	4650      	mov	r0, sl
d000ce78:	f7fe feec 	bl	d000bc54 <_free_r>
d000ce7c:	e7c7      	b.n	d000ce0e <__ssputs_r+0x46>
	...

d000ce80 <_svfiprintf_r>:
d000ce80:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d000ce84:	4698      	mov	r8, r3
d000ce86:	898b      	ldrh	r3, [r1, #12]
d000ce88:	061b      	lsls	r3, r3, #24
d000ce8a:	b09d      	sub	sp, #116	; 0x74
d000ce8c:	4607      	mov	r7, r0
d000ce8e:	460d      	mov	r5, r1
d000ce90:	4614      	mov	r4, r2
d000ce92:	d50e      	bpl.n	d000ceb2 <_svfiprintf_r+0x32>
d000ce94:	690b      	ldr	r3, [r1, #16]
d000ce96:	b963      	cbnz	r3, d000ceb2 <_svfiprintf_r+0x32>
d000ce98:	2140      	movs	r1, #64	; 0x40
d000ce9a:	f7fe ff2b 	bl	d000bcf4 <_malloc_r>
d000ce9e:	6028      	str	r0, [r5, #0]
d000cea0:	6128      	str	r0, [r5, #16]
d000cea2:	b920      	cbnz	r0, d000ceae <_svfiprintf_r+0x2e>
d000cea4:	230c      	movs	r3, #12
d000cea6:	603b      	str	r3, [r7, #0]
d000cea8:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000ceac:	e0d1      	b.n	d000d052 <_svfiprintf_r+0x1d2>
d000ceae:	2340      	movs	r3, #64	; 0x40
d000ceb0:	616b      	str	r3, [r5, #20]
d000ceb2:	2300      	movs	r3, #0
d000ceb4:	9309      	str	r3, [sp, #36]	; 0x24
d000ceb6:	2320      	movs	r3, #32
d000ceb8:	f88d 3029 	strb.w	r3, [sp, #41]	; 0x29
d000cebc:	f8cd 800c 	str.w	r8, [sp, #12]
d000cec0:	2330      	movs	r3, #48	; 0x30
d000cec2:	f8df 81a8 	ldr.w	r8, [pc, #424]	; d000d06c <_svfiprintf_r+0x1ec>
d000cec6:	f88d 302a 	strb.w	r3, [sp, #42]	; 0x2a
d000ceca:	f04f 0901 	mov.w	r9, #1
d000cece:	4623      	mov	r3, r4
d000ced0:	469a      	mov	sl, r3
d000ced2:	f813 2b01 	ldrb.w	r2, [r3], #1
d000ced6:	b10a      	cbz	r2, d000cedc <_svfiprintf_r+0x5c>
d000ced8:	2a25      	cmp	r2, #37	; 0x25
d000ceda:	d1f9      	bne.n	d000ced0 <_svfiprintf_r+0x50>
d000cedc:	ebba 0b04 	subs.w	fp, sl, r4
d000cee0:	d00b      	beq.n	d000cefa <_svfiprintf_r+0x7a>
d000cee2:	465b      	mov	r3, fp
d000cee4:	4622      	mov	r2, r4
d000cee6:	4629      	mov	r1, r5
d000cee8:	4638      	mov	r0, r7
d000ceea:	f7ff ff6d 	bl	d000cdc8 <__ssputs_r>
d000ceee:	3001      	adds	r0, #1
d000cef0:	f000 80aa 	beq.w	d000d048 <_svfiprintf_r+0x1c8>
d000cef4:	9a09      	ldr	r2, [sp, #36]	; 0x24
d000cef6:	445a      	add	r2, fp
d000cef8:	9209      	str	r2, [sp, #36]	; 0x24
d000cefa:	f89a 3000 	ldrb.w	r3, [sl]
d000cefe:	2b00      	cmp	r3, #0
d000cf00:	f000 80a2 	beq.w	d000d048 <_svfiprintf_r+0x1c8>
d000cf04:	2300      	movs	r3, #0
d000cf06:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d000cf0a:	e9cd 2305 	strd	r2, r3, [sp, #20]
d000cf0e:	f10a 0a01 	add.w	sl, sl, #1
d000cf12:	9304      	str	r3, [sp, #16]
d000cf14:	9307      	str	r3, [sp, #28]
d000cf16:	f88d 3053 	strb.w	r3, [sp, #83]	; 0x53
d000cf1a:	931a      	str	r3, [sp, #104]	; 0x68
d000cf1c:	4654      	mov	r4, sl
d000cf1e:	2205      	movs	r2, #5
d000cf20:	f814 1b01 	ldrb.w	r1, [r4], #1
d000cf24:	4851      	ldr	r0, [pc, #324]	; (d000d06c <_svfiprintf_r+0x1ec>)
d000cf26:	f7ff feb3 	bl	d000cc90 <memchr>
d000cf2a:	9a04      	ldr	r2, [sp, #16]
d000cf2c:	b9d8      	cbnz	r0, d000cf66 <_svfiprintf_r+0xe6>
d000cf2e:	06d0      	lsls	r0, r2, #27
d000cf30:	bf44      	itt	mi
d000cf32:	2320      	movmi	r3, #32
d000cf34:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d000cf38:	0711      	lsls	r1, r2, #28
d000cf3a:	bf44      	itt	mi
d000cf3c:	232b      	movmi	r3, #43	; 0x2b
d000cf3e:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d000cf42:	f89a 3000 	ldrb.w	r3, [sl]
d000cf46:	2b2a      	cmp	r3, #42	; 0x2a
d000cf48:	d015      	beq.n	d000cf76 <_svfiprintf_r+0xf6>
d000cf4a:	9a07      	ldr	r2, [sp, #28]
d000cf4c:	4654      	mov	r4, sl
d000cf4e:	2000      	movs	r0, #0
d000cf50:	f04f 0c0a 	mov.w	ip, #10
d000cf54:	4621      	mov	r1, r4
d000cf56:	f811 3b01 	ldrb.w	r3, [r1], #1
d000cf5a:	3b30      	subs	r3, #48	; 0x30
d000cf5c:	2b09      	cmp	r3, #9
d000cf5e:	d94e      	bls.n	d000cffe <_svfiprintf_r+0x17e>
d000cf60:	b1b0      	cbz	r0, d000cf90 <_svfiprintf_r+0x110>
d000cf62:	9207      	str	r2, [sp, #28]
d000cf64:	e014      	b.n	d000cf90 <_svfiprintf_r+0x110>
d000cf66:	eba0 0308 	sub.w	r3, r0, r8
d000cf6a:	fa09 f303 	lsl.w	r3, r9, r3
d000cf6e:	4313      	orrs	r3, r2
d000cf70:	9304      	str	r3, [sp, #16]
d000cf72:	46a2      	mov	sl, r4
d000cf74:	e7d2      	b.n	d000cf1c <_svfiprintf_r+0x9c>
d000cf76:	9b03      	ldr	r3, [sp, #12]
d000cf78:	1d19      	adds	r1, r3, #4
d000cf7a:	681b      	ldr	r3, [r3, #0]
d000cf7c:	9103      	str	r1, [sp, #12]
d000cf7e:	2b00      	cmp	r3, #0
d000cf80:	bfbb      	ittet	lt
d000cf82:	425b      	neglt	r3, r3
d000cf84:	f042 0202 	orrlt.w	r2, r2, #2
d000cf88:	9307      	strge	r3, [sp, #28]
d000cf8a:	9307      	strlt	r3, [sp, #28]
d000cf8c:	bfb8      	it	lt
d000cf8e:	9204      	strlt	r2, [sp, #16]
d000cf90:	7823      	ldrb	r3, [r4, #0]
d000cf92:	2b2e      	cmp	r3, #46	; 0x2e
d000cf94:	d10c      	bne.n	d000cfb0 <_svfiprintf_r+0x130>
d000cf96:	7863      	ldrb	r3, [r4, #1]
d000cf98:	2b2a      	cmp	r3, #42	; 0x2a
d000cf9a:	d135      	bne.n	d000d008 <_svfiprintf_r+0x188>
d000cf9c:	9b03      	ldr	r3, [sp, #12]
d000cf9e:	1d1a      	adds	r2, r3, #4
d000cfa0:	681b      	ldr	r3, [r3, #0]
d000cfa2:	9203      	str	r2, [sp, #12]
d000cfa4:	2b00      	cmp	r3, #0
d000cfa6:	bfb8      	it	lt
d000cfa8:	f04f 33ff 	movlt.w	r3, #4294967295	; 0xffffffff
d000cfac:	3402      	adds	r4, #2
d000cfae:	9305      	str	r3, [sp, #20]
d000cfb0:	f8df a0c8 	ldr.w	sl, [pc, #200]	; d000d07c <_svfiprintf_r+0x1fc>
d000cfb4:	7821      	ldrb	r1, [r4, #0]
d000cfb6:	2203      	movs	r2, #3
d000cfb8:	4650      	mov	r0, sl
d000cfba:	f7ff fe69 	bl	d000cc90 <memchr>
d000cfbe:	b140      	cbz	r0, d000cfd2 <_svfiprintf_r+0x152>
d000cfc0:	2340      	movs	r3, #64	; 0x40
d000cfc2:	eba0 000a 	sub.w	r0, r0, sl
d000cfc6:	fa03 f000 	lsl.w	r0, r3, r0
d000cfca:	9b04      	ldr	r3, [sp, #16]
d000cfcc:	4303      	orrs	r3, r0
d000cfce:	3401      	adds	r4, #1
d000cfd0:	9304      	str	r3, [sp, #16]
d000cfd2:	f814 1b01 	ldrb.w	r1, [r4], #1
d000cfd6:	4826      	ldr	r0, [pc, #152]	; (d000d070 <_svfiprintf_r+0x1f0>)
d000cfd8:	f88d 1028 	strb.w	r1, [sp, #40]	; 0x28
d000cfdc:	2206      	movs	r2, #6
d000cfde:	f7ff fe57 	bl	d000cc90 <memchr>
d000cfe2:	2800      	cmp	r0, #0
d000cfe4:	d038      	beq.n	d000d058 <_svfiprintf_r+0x1d8>
d000cfe6:	4b23      	ldr	r3, [pc, #140]	; (d000d074 <_svfiprintf_r+0x1f4>)
d000cfe8:	bb1b      	cbnz	r3, d000d032 <_svfiprintf_r+0x1b2>
d000cfea:	9b03      	ldr	r3, [sp, #12]
d000cfec:	3307      	adds	r3, #7
d000cfee:	f023 0307 	bic.w	r3, r3, #7
d000cff2:	3308      	adds	r3, #8
d000cff4:	9303      	str	r3, [sp, #12]
d000cff6:	9b09      	ldr	r3, [sp, #36]	; 0x24
d000cff8:	4433      	add	r3, r6
d000cffa:	9309      	str	r3, [sp, #36]	; 0x24
d000cffc:	e767      	b.n	d000cece <_svfiprintf_r+0x4e>
d000cffe:	fb0c 3202 	mla	r2, ip, r2, r3
d000d002:	460c      	mov	r4, r1
d000d004:	2001      	movs	r0, #1
d000d006:	e7a5      	b.n	d000cf54 <_svfiprintf_r+0xd4>
d000d008:	2300      	movs	r3, #0
d000d00a:	3401      	adds	r4, #1
d000d00c:	9305      	str	r3, [sp, #20]
d000d00e:	4619      	mov	r1, r3
d000d010:	f04f 0c0a 	mov.w	ip, #10
d000d014:	4620      	mov	r0, r4
d000d016:	f810 2b01 	ldrb.w	r2, [r0], #1
d000d01a:	3a30      	subs	r2, #48	; 0x30
d000d01c:	2a09      	cmp	r2, #9
d000d01e:	d903      	bls.n	d000d028 <_svfiprintf_r+0x1a8>
d000d020:	2b00      	cmp	r3, #0
d000d022:	d0c5      	beq.n	d000cfb0 <_svfiprintf_r+0x130>
d000d024:	9105      	str	r1, [sp, #20]
d000d026:	e7c3      	b.n	d000cfb0 <_svfiprintf_r+0x130>
d000d028:	fb0c 2101 	mla	r1, ip, r1, r2
d000d02c:	4604      	mov	r4, r0
d000d02e:	2301      	movs	r3, #1
d000d030:	e7f0      	b.n	d000d014 <_svfiprintf_r+0x194>
d000d032:	ab03      	add	r3, sp, #12
d000d034:	9300      	str	r3, [sp, #0]
d000d036:	462a      	mov	r2, r5
d000d038:	4b0f      	ldr	r3, [pc, #60]	; (d000d078 <_svfiprintf_r+0x1f8>)
d000d03a:	a904      	add	r1, sp, #16
d000d03c:	4638      	mov	r0, r7
d000d03e:	f3af 8000 	nop.w
d000d042:	1c42      	adds	r2, r0, #1
d000d044:	4606      	mov	r6, r0
d000d046:	d1d6      	bne.n	d000cff6 <_svfiprintf_r+0x176>
d000d048:	89ab      	ldrh	r3, [r5, #12]
d000d04a:	065b      	lsls	r3, r3, #25
d000d04c:	f53f af2c 	bmi.w	d000cea8 <_svfiprintf_r+0x28>
d000d050:	9809      	ldr	r0, [sp, #36]	; 0x24
d000d052:	b01d      	add	sp, #116	; 0x74
d000d054:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d000d058:	ab03      	add	r3, sp, #12
d000d05a:	9300      	str	r3, [sp, #0]
d000d05c:	462a      	mov	r2, r5
d000d05e:	4b06      	ldr	r3, [pc, #24]	; (d000d078 <_svfiprintf_r+0x1f8>)
d000d060:	a904      	add	r1, sp, #16
d000d062:	4638      	mov	r0, r7
d000d064:	f7ff f868 	bl	d000c138 <_printf_i>
d000d068:	e7eb      	b.n	d000d042 <_svfiprintf_r+0x1c2>
d000d06a:	bf00      	nop
d000d06c:	d000ddbc 	.word	0xd000ddbc
d000d070:	d000ddc6 	.word	0xd000ddc6
d000d074:	00000000 	.word	0x00000000
d000d078:	d000cdc9 	.word	0xd000cdc9
d000d07c:	d000ddc2 	.word	0xd000ddc2

d000d080 <_raise_r>:
d000d080:	291f      	cmp	r1, #31
d000d082:	b538      	push	{r3, r4, r5, lr}
d000d084:	4604      	mov	r4, r0
d000d086:	460d      	mov	r5, r1
d000d088:	d904      	bls.n	d000d094 <_raise_r+0x14>
d000d08a:	2316      	movs	r3, #22
d000d08c:	6003      	str	r3, [r0, #0]
d000d08e:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d000d092:	bd38      	pop	{r3, r4, r5, pc}
d000d094:	6c42      	ldr	r2, [r0, #68]	; 0x44
d000d096:	b112      	cbz	r2, d000d09e <_raise_r+0x1e>
d000d098:	f852 3021 	ldr.w	r3, [r2, r1, lsl #2]
d000d09c:	b94b      	cbnz	r3, d000d0b2 <_raise_r+0x32>
d000d09e:	4620      	mov	r0, r4
d000d0a0:	f000 f830 	bl	d000d104 <_getpid_r>
d000d0a4:	462a      	mov	r2, r5
d000d0a6:	4601      	mov	r1, r0
d000d0a8:	4620      	mov	r0, r4
d000d0aa:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
d000d0ae:	f000 b817 	b.w	d000d0e0 <_kill_r>
d000d0b2:	2b01      	cmp	r3, #1
d000d0b4:	d00a      	beq.n	d000d0cc <_raise_r+0x4c>
d000d0b6:	1c59      	adds	r1, r3, #1
d000d0b8:	d103      	bne.n	d000d0c2 <_raise_r+0x42>
d000d0ba:	2316      	movs	r3, #22
d000d0bc:	6003      	str	r3, [r0, #0]
d000d0be:	2001      	movs	r0, #1
d000d0c0:	e7e7      	b.n	d000d092 <_raise_r+0x12>
d000d0c2:	2400      	movs	r4, #0
d000d0c4:	f842 4025 	str.w	r4, [r2, r5, lsl #2]
d000d0c8:	4628      	mov	r0, r5
d000d0ca:	4798      	blx	r3
d000d0cc:	2000      	movs	r0, #0
d000d0ce:	e7e0      	b.n	d000d092 <_raise_r+0x12>

d000d0d0 <raise>:
d000d0d0:	4b02      	ldr	r3, [pc, #8]	; (d000d0dc <raise+0xc>)
d000d0d2:	4601      	mov	r1, r0
d000d0d4:	6818      	ldr	r0, [r3, #0]
d000d0d6:	f7ff bfd3 	b.w	d000d080 <_raise_r>
d000d0da:	bf00      	nop
d000d0dc:	d000de58 	.word	0xd000de58

d000d0e0 <_kill_r>:
d000d0e0:	b538      	push	{r3, r4, r5, lr}
d000d0e2:	4d07      	ldr	r5, [pc, #28]	; (d000d100 <_kill_r+0x20>)
d000d0e4:	2300      	movs	r3, #0
d000d0e6:	4604      	mov	r4, r0
d000d0e8:	4608      	mov	r0, r1
d000d0ea:	4611      	mov	r1, r2
d000d0ec:	602b      	str	r3, [r5, #0]
d000d0ee:	f7f4 f82b 	bl	d0001148 <_kill>
d000d0f2:	1c43      	adds	r3, r0, #1
d000d0f4:	d102      	bne.n	d000d0fc <_kill_r+0x1c>
d000d0f6:	682b      	ldr	r3, [r5, #0]
d000d0f8:	b103      	cbz	r3, d000d0fc <_kill_r+0x1c>
d000d0fa:	6023      	str	r3, [r4, #0]
d000d0fc:	bd38      	pop	{r3, r4, r5, pc}
d000d0fe:	bf00      	nop
d000d100:	d000f130 	.word	0xd000f130

d000d104 <_getpid_r>:
d000d104:	f7f4 b81e 	b.w	d0001144 <_getpid>

d000d108 <__sread>:
d000d108:	b510      	push	{r4, lr}
d000d10a:	460c      	mov	r4, r1
d000d10c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d000d110:	f000 f896 	bl	d000d240 <_read_r>
d000d114:	2800      	cmp	r0, #0
d000d116:	bfab      	itete	ge
d000d118:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d000d11a:	89a3      	ldrhlt	r3, [r4, #12]
d000d11c:	181b      	addge	r3, r3, r0
d000d11e:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d000d122:	bfac      	ite	ge
d000d124:	6563      	strge	r3, [r4, #84]	; 0x54
d000d126:	81a3      	strhlt	r3, [r4, #12]
d000d128:	bd10      	pop	{r4, pc}

d000d12a <__swrite>:
d000d12a:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d000d12e:	461f      	mov	r7, r3
d000d130:	898b      	ldrh	r3, [r1, #12]
d000d132:	05db      	lsls	r3, r3, #23
d000d134:	4605      	mov	r5, r0
d000d136:	460c      	mov	r4, r1
d000d138:	4616      	mov	r6, r2
d000d13a:	d505      	bpl.n	d000d148 <__swrite+0x1e>
d000d13c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d000d140:	2302      	movs	r3, #2
d000d142:	2200      	movs	r2, #0
d000d144:	f000 f862 	bl	d000d20c <_lseek_r>
d000d148:	89a3      	ldrh	r3, [r4, #12]
d000d14a:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d000d14e:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d000d152:	81a3      	strh	r3, [r4, #12]
d000d154:	4632      	mov	r2, r6
d000d156:	463b      	mov	r3, r7
d000d158:	4628      	mov	r0, r5
d000d15a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d000d15e:	f7f3 bf87 	b.w	d0001070 <_write_r>

d000d162 <__sseek>:
d000d162:	b510      	push	{r4, lr}
d000d164:	460c      	mov	r4, r1
d000d166:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d000d16a:	f000 f84f 	bl	d000d20c <_lseek_r>
d000d16e:	1c43      	adds	r3, r0, #1
d000d170:	89a3      	ldrh	r3, [r4, #12]
d000d172:	bf15      	itete	ne
d000d174:	6560      	strne	r0, [r4, #84]	; 0x54
d000d176:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d000d17a:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d000d17e:	81a3      	strheq	r3, [r4, #12]
d000d180:	bf18      	it	ne
d000d182:	81a3      	strhne	r3, [r4, #12]
d000d184:	bd10      	pop	{r4, pc}

d000d186 <__sclose>:
d000d186:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d000d18a:	f000 b80d 	b.w	d000d1a8 <_close_r>

d000d18e <strchr>:
d000d18e:	b2c9      	uxtb	r1, r1
d000d190:	4603      	mov	r3, r0
d000d192:	f810 2b01 	ldrb.w	r2, [r0], #1
d000d196:	b11a      	cbz	r2, d000d1a0 <strchr+0x12>
d000d198:	428a      	cmp	r2, r1
d000d19a:	d1f9      	bne.n	d000d190 <strchr+0x2>
d000d19c:	4618      	mov	r0, r3
d000d19e:	4770      	bx	lr
d000d1a0:	2900      	cmp	r1, #0
d000d1a2:	bf18      	it	ne
d000d1a4:	2300      	movne	r3, #0
d000d1a6:	e7f9      	b.n	d000d19c <strchr+0xe>

d000d1a8 <_close_r>:
d000d1a8:	b538      	push	{r3, r4, r5, lr}
d000d1aa:	4d06      	ldr	r5, [pc, #24]	; (d000d1c4 <_close_r+0x1c>)
d000d1ac:	2300      	movs	r3, #0
d000d1ae:	4604      	mov	r4, r0
d000d1b0:	4608      	mov	r0, r1
d000d1b2:	602b      	str	r3, [r5, #0]
d000d1b4:	f7f3 ff96 	bl	d00010e4 <_close>
d000d1b8:	1c43      	adds	r3, r0, #1
d000d1ba:	d102      	bne.n	d000d1c2 <_close_r+0x1a>
d000d1bc:	682b      	ldr	r3, [r5, #0]
d000d1be:	b103      	cbz	r3, d000d1c2 <_close_r+0x1a>
d000d1c0:	6023      	str	r3, [r4, #0]
d000d1c2:	bd38      	pop	{r3, r4, r5, pc}
d000d1c4:	d000f130 	.word	0xd000f130

d000d1c8 <_fstat_r>:
d000d1c8:	b538      	push	{r3, r4, r5, lr}
d000d1ca:	4d07      	ldr	r5, [pc, #28]	; (d000d1e8 <_fstat_r+0x20>)
d000d1cc:	2300      	movs	r3, #0
d000d1ce:	4604      	mov	r4, r0
d000d1d0:	4608      	mov	r0, r1
d000d1d2:	4611      	mov	r1, r2
d000d1d4:	602b      	str	r3, [r5, #0]
d000d1d6:	f7f3 ff89 	bl	d00010ec <_fstat>
d000d1da:	1c43      	adds	r3, r0, #1
d000d1dc:	d102      	bne.n	d000d1e4 <_fstat_r+0x1c>
d000d1de:	682b      	ldr	r3, [r5, #0]
d000d1e0:	b103      	cbz	r3, d000d1e4 <_fstat_r+0x1c>
d000d1e2:	6023      	str	r3, [r4, #0]
d000d1e4:	bd38      	pop	{r3, r4, r5, pc}
d000d1e6:	bf00      	nop
d000d1e8:	d000f130 	.word	0xd000f130

d000d1ec <_isatty_r>:
d000d1ec:	b538      	push	{r3, r4, r5, lr}
d000d1ee:	4d06      	ldr	r5, [pc, #24]	; (d000d208 <_isatty_r+0x1c>)
d000d1f0:	2300      	movs	r3, #0
d000d1f2:	4604      	mov	r4, r0
d000d1f4:	4608      	mov	r0, r1
d000d1f6:	602b      	str	r3, [r5, #0]
d000d1f8:	f7f3 ffa0 	bl	d000113c <_isatty>
d000d1fc:	1c43      	adds	r3, r0, #1
d000d1fe:	d102      	bne.n	d000d206 <_isatty_r+0x1a>
d000d200:	682b      	ldr	r3, [r5, #0]
d000d202:	b103      	cbz	r3, d000d206 <_isatty_r+0x1a>
d000d204:	6023      	str	r3, [r4, #0]
d000d206:	bd38      	pop	{r3, r4, r5, pc}
d000d208:	d000f130 	.word	0xd000f130

d000d20c <_lseek_r>:
d000d20c:	b538      	push	{r3, r4, r5, lr}
d000d20e:	4d07      	ldr	r5, [pc, #28]	; (d000d22c <_lseek_r+0x20>)
d000d210:	4604      	mov	r4, r0
d000d212:	4608      	mov	r0, r1
d000d214:	4611      	mov	r1, r2
d000d216:	2200      	movs	r2, #0
d000d218:	602a      	str	r2, [r5, #0]
d000d21a:	461a      	mov	r2, r3
d000d21c:	f7f3 ff6c 	bl	d00010f8 <_lseek>
d000d220:	1c43      	adds	r3, r0, #1
d000d222:	d102      	bne.n	d000d22a <_lseek_r+0x1e>
d000d224:	682b      	ldr	r3, [r5, #0]
d000d226:	b103      	cbz	r3, d000d22a <_lseek_r+0x1e>
d000d228:	6023      	str	r3, [r4, #0]
d000d22a:	bd38      	pop	{r3, r4, r5, pc}
d000d22c:	d000f130 	.word	0xd000f130

d000d230 <_malloc_usable_size_r>:
d000d230:	f851 3c04 	ldr.w	r3, [r1, #-4]
d000d234:	1f18      	subs	r0, r3, #4
d000d236:	2b00      	cmp	r3, #0
d000d238:	bfbc      	itt	lt
d000d23a:	580b      	ldrlt	r3, [r1, r0]
d000d23c:	18c0      	addlt	r0, r0, r3
d000d23e:	4770      	bx	lr

d000d240 <_read_r>:
d000d240:	b538      	push	{r3, r4, r5, lr}
d000d242:	4d07      	ldr	r5, [pc, #28]	; (d000d260 <_read_r+0x20>)
d000d244:	4604      	mov	r4, r0
d000d246:	4608      	mov	r0, r1
d000d248:	4611      	mov	r1, r2
d000d24a:	2200      	movs	r2, #0
d000d24c:	602a      	str	r2, [r5, #0]
d000d24e:	461a      	mov	r2, r3
d000d250:	f7f3 ff3e 	bl	d00010d0 <_read>
d000d254:	1c43      	adds	r3, r0, #1
d000d256:	d102      	bne.n	d000d25e <_read_r+0x1e>
d000d258:	682b      	ldr	r3, [r5, #0]
d000d25a:	b103      	cbz	r3, d000d25e <_read_r+0x1e>
d000d25c:	6023      	str	r3, [r4, #0]
d000d25e:	bd38      	pop	{r3, r4, r5, pc}
d000d260:	d000f130 	.word	0xd000f130
d000d264:	20646162 	.word	0x20646162
d000d268:	657a6973 	.word	0x657a6973
d000d26c:	73696c20 	.word	0x73696c20
d000d270:	00000074 	.word	0x00000074
d000d274:	20646162 	.word	0x20646162
d000d278:	65646f63 	.word	0x65646f63
d000d27c:	6e656c20 	.word	0x6e656c20
d000d280:	73687467 	.word	0x73687467
d000d284:	00000000 	.word	0x00000000
d000d288:	6a282828 	.word	0x6a282828
d000d28c:	6f633e2d 	.word	0x6f633e2d
d000d290:	625f6564 	.word	0x625f6564
d000d294:	65666675 	.word	0x65666675
d000d298:	3e202972 	.word	0x3e202972
d000d29c:	3328203e 	.word	0x3328203e
d000d2a0:	202d2032 	.word	0x202d2032
d000d2a4:	733e2d68 	.word	0x733e2d68
d000d2a8:	5b657a69 	.word	0x5b657a69
d000d2ac:	29295d63 	.word	0x29295d63
d000d2b0:	73202620 	.word	0x73202620
d000d2b4:	5f696274 	.word	0x5f696274
d000d2b8:	616d625f 	.word	0x616d625f
d000d2bc:	685b6b73 	.word	0x685b6b73
d000d2c0:	69733e2d 	.word	0x69733e2d
d000d2c4:	635b657a 	.word	0x635b657a
d000d2c8:	20295d5d 	.word	0x20295d5d
d000d2cc:	68203d3d 	.word	0x68203d3d
d000d2d0:	6f633e2d 	.word	0x6f633e2d
d000d2d4:	635b6564 	.word	0x635b6564
d000d2d8:	0000005d 	.word	0x0000005d
d000d2dc:	6a6f7270 	.word	0x6a6f7270
d000d2e0:	2f746365 	.word	0x2f746365
d000d2e4:	5f627473 	.word	0x5f627473
d000d2e8:	67616d69 	.word	0x67616d69
d000d2ec:	00682e65 	.word	0x00682e65
d000d2f0:	20646162 	.word	0x20646162
d000d2f4:	66667568 	.word	0x66667568
d000d2f8:	206e616d 	.word	0x206e616d
d000d2fc:	65646f63 	.word	0x65646f63
d000d300:	00000000 	.word	0x00000000
d000d304:	20646162 	.word	0x20646162
d000d308:	746c6564 	.word	0x746c6564
d000d30c:	00000061 	.word	0x00000061
d000d310:	276e6163 	.word	0x276e6163
d000d314:	656d2074 	.word	0x656d2074
d000d318:	20656772 	.word	0x20656772
d000d31c:	61206364 	.word	0x61206364
d000d320:	6120646e 	.word	0x6120646e
d000d324:	00000063 	.word	0x00000063
d000d328:	65707865 	.word	0x65707865
d000d32c:	64657463 	.word	0x64657463
d000d330:	72616d20 	.word	0x72616d20
d000d334:	0072656b 	.word	0x0072656b
d000d338:	20646162 	.word	0x20646162
d000d33c:	20495244 	.word	0x20495244
d000d340:	006e656c 	.word	0x006e656c
d000d344:	20646162 	.word	0x20646162
d000d348:	20545144 	.word	0x20545144
d000d34c:	65707974 	.word	0x65707974
d000d350:	00000000 	.word	0x00000000
d000d354:	20646162 	.word	0x20646162
d000d358:	20545144 	.word	0x20545144
d000d35c:	6c626174 	.word	0x6c626174
d000d360:	00000065 	.word	0x00000065
d000d364:	20646162 	.word	0x20646162
d000d368:	20544844 	.word	0x20544844
d000d36c:	64616568 	.word	0x64616568
d000d370:	00007265 	.word	0x00007265
d000d374:	20646162 	.word	0x20646162
d000d378:	204d4f43 	.word	0x204d4f43
d000d37c:	006e656c 	.word	0x006e656c
d000d380:	20646162 	.word	0x20646162
d000d384:	20505041 	.word	0x20505041
d000d388:	006e656c 	.word	0x006e656c
d000d38c:	6e6b6e75 	.word	0x6e6b6e75
d000d390:	206e776f 	.word	0x206e776f
d000d394:	6b72616d 	.word	0x6b72616d
d000d398:	00007265 	.word	0x00007265
d000d39c:	53206f6e 	.word	0x53206f6e
d000d3a0:	0000494f 	.word	0x0000494f
d000d3a4:	53206f6e 	.word	0x53206f6e
d000d3a8:	0000464f 	.word	0x0000464f
d000d3ac:	20646162 	.word	0x20646162
d000d3b0:	20464f53 	.word	0x20464f53
d000d3b4:	006e656c 	.word	0x006e656c
d000d3b8:	796c6e6f 	.word	0x796c6e6f
d000d3bc:	622d3820 	.word	0x622d3820
d000d3c0:	00007469 	.word	0x00007469
d000d3c4:	68206f6e 	.word	0x68206f6e
d000d3c8:	65646165 	.word	0x65646165
d000d3cc:	65682072 	.word	0x65682072
d000d3d0:	74686769 	.word	0x74686769
d000d3d4:	00000000 	.word	0x00000000
d000d3d8:	69772030 	.word	0x69772030
d000d3dc:	00687464 	.word	0x00687464
d000d3e0:	206f6f74 	.word	0x206f6f74
d000d3e4:	6772616c 	.word	0x6772616c
d000d3e8:	00000065 	.word	0x00000065
d000d3ec:	20646162 	.word	0x20646162
d000d3f0:	706d6f63 	.word	0x706d6f63
d000d3f4:	6e656e6f 	.word	0x6e656e6f
d000d3f8:	6f632074 	.word	0x6f632074
d000d3fc:	00746e75 	.word	0x00746e75
d000d400:	20646162 	.word	0x20646162
d000d404:	00000048 	.word	0x00000048
d000d408:	20646162 	.word	0x20646162
d000d40c:	00000056 	.word	0x00000056
d000d410:	20646162 	.word	0x20646162
d000d414:	00005154 	.word	0x00005154
d000d418:	6f74756f 	.word	0x6f74756f
d000d41c:	6d656d66 	.word	0x6d656d66
d000d420:	00000000 	.word	0x00000000
d000d424:	20646162 	.word	0x20646162
d000d428:	5f716572 	.word	0x5f716572
d000d42c:	706d6f63 	.word	0x706d6f63
d000d430:	00000000 	.word	0x00000000
d000d434:	20646162 	.word	0x20646162
d000d438:	20534f53 	.word	0x20534f53
d000d43c:	706d6f63 	.word	0x706d6f63
d000d440:	6e656e6f 	.word	0x6e656e6f
d000d444:	6f632074 	.word	0x6f632074
d000d448:	00746e75 	.word	0x00746e75
d000d44c:	20646162 	.word	0x20646162
d000d450:	20534f53 	.word	0x20534f53
d000d454:	006e656c 	.word	0x006e656c
d000d458:	20646162 	.word	0x20646162
d000d45c:	68204344 	.word	0x68204344
d000d460:	00666675 	.word	0x00666675
d000d464:	20646162 	.word	0x20646162
d000d468:	68204341 	.word	0x68204341
d000d46c:	00666675 	.word	0x00666675
d000d470:	20646162 	.word	0x20646162
d000d474:	00534f53 	.word	0x00534f53
d000d478:	20646162 	.word	0x20646162
d000d47c:	204c4e44 	.word	0x204c4e44
d000d480:	006e656c 	.word	0x006e656c
d000d484:	20646162 	.word	0x20646162
d000d488:	204c4e44 	.word	0x204c4e44
d000d48c:	67696568 	.word	0x67696568
d000d490:	00007468 	.word	0x00007468
d000d494:	6e6b6e75 	.word	0x6e6b6e75
d000d498:	206e776f 	.word	0x206e776f
d000d49c:	67616d69 	.word	0x67616d69
d000d4a0:	79742065 	.word	0x79742065
d000d4a4:	00006570 	.word	0x00006570

d000d4a8 <__func__.6929>:
d000d4a8:	69627473 706a5f5f 685f6765 5f666675     stbi__jpeg_huff_
d000d4b8:	6f636564 00006564                       decode..

d000d4c0 <rgb.7252>:
d000d4c0:	00424752                                RGB.

d000d4c4 <stbi__bmask>:
d000d4c4:	00000000 00000001 00000003 00000007     ................
d000d4d4:	0000000f 0000001f 0000003f 0000007f     ........?.......
d000d4e4:	000000ff 000001ff 000003ff 000007ff     ................
d000d4f4:	00000fff 00001fff 00003fff 00007fff     .........?......
d000d504:	0000ffff                                ....

d000d508 <stbi__jbias>:
d000d508:	00000000 ffffffff fffffffd fffffff9     ................
d000d518:	fffffff1 ffffffe1 ffffffc1 ffffff81     ................
d000d528:	ffffff01 fffffe01 fffffc01 fffff801     ................
d000d538:	fffff001 ffffe001 ffffc001 ffff8001     ................

d000d548 <stbi__jpeg_dezigzag>:
d000d548:	10080100 0a030209 19201811 05040b12     .......... .....
d000d558:	211a130c 22293028 060d141b 1c150e07     ...!(0)"........
d000d568:	38312a23 242b3239 170f161d 332c251e     #*1892+$.....%,3
d000d578:	2d343b3a 2e271f26 363d3c35 3f3e372f     :;4-&.'.5<=6/7>?
d000d588:	3f3f3f3f 3f3f3f3f 3f3f3f3f 003f3f3f     ???????????????.

d000d598 <CSWTCH.309>:
d000d598:	00020001 00080004 00200010 00800040     .......... .@...
d000d5a8:	02000100 08000400 20001000 00004000     ........... .@..

d000d5b8 <CSWTCH.311>:
d000d5b8:	fffdffff fff1fff9 ffc1ffe1 ff01ff81     ................
d000d5c8:	fc01fe01 f001f801 c001e001 00008001     ................

d000d5d8 <CSWTCH.316>:
d000d5d8:	d000df74 d000dfc4 d000e014 d000e064     t...........d...

d000d5e8 <CSWTCH.318>:
d000d5e8:	d000e0b4 d000e0c4 d000e0d4 d000e1d4     ................

d000d5f8 <ZAG>:
d000d5f8:	10080100 0a030209 19201811 05040b12     .......... .....
d000d608:	211a130c 22293028 060d141b 1c150e07     ...!(0)"........
d000d618:	38312a23 242b3239 170f161d 332c251e     #*1892+$.....%,3
d000d628:	2d343b3a 2e271f26 363d3c35 3f3e372f     :;4-&.'.5<=6/7>?

d000d638 <gWinogradQuant>:
d000d638:	a7b2b280 e897a7f6 d18097e8 6580d1db     ...............e
d000d648:	b2c5c5b2 a78b4565 458ba7b1 97836023     ....eE.....E#`..
d000d658:	23608397 80765b31 2e315b76 51656551     ..`#1[v.v[1.QeeQ
d000d668:	4f452a2e 36232a45 251c2336 0a13131c     .*EOE*#66#.%....
d000d678:	0000000a 67616d49 69562065 72657765     ....Image Viewer
d000d688:	00000000 20746f6e 504a2061 00004745     ....not a JPEG..
d000d698:	676f7270 73736572 20657669 4745504a     progressive JPEG
d000d6a8:	00000000 4745504a 63656420 2065646f     ....JPEG decode 
d000d6b8:	6f727265 00000072 75736e75 726f7070     error...unsuppor
d000d6c8:	20646574 4745504a 6c6f6320 7372756f     ted JPEG colours
d000d6d8:	65636170 00000000 75736e75 726f7070     pace....unsuppor
d000d6e8:	20646574 4745504a 6d617320 6e696c70     ted JPEG samplin
d000d6f8:	00000067 6e75614c 77206863 20687469     g...Launch with 
d000d708:	2c504d42 46464920 424c492f 47202c4d     BMP, IFF/ILBM, G
d000d718:	6f204649 504a2072 00002e47 6e65704f     IF or JPG...Open
d000d728:	69616620 2064656c 25205246 25203a75      failed FR %u: %
d000d738:	00000073 656c6946 20736920 74706d65     s...File is empt
d000d748:	00000079 20746f4e 756f6e65 6d206867     y...Not enough m
d000d758:	726f6d65 6f662079 69662072 0000656c     emory for file..
d000d768:	64616552 69616620 2064656c 25205246     Read failed FR %
d000d778:	00000075 20746f4e 4d422061 69662050     u...Not a BMP fi
d000d788:	0000656c 75736e55 726f7070 20646574     le..Unsupported 
d000d798:	20504d42 64616568 00007265 61766e49     BMP header..Inva
d000d7a8:	2064696c 20504d42 656d6964 6f69736e     lid BMP dimensio
d000d7b8:	0000736e 20504d42 74207369 6c206f6f     ns..BMP is too l
d000d7c8:	65677261 726f6620 69687420 70612073     arge for this ap
d000d7d8:	74656c70 00000000 20504d42 65786970     plet....BMP pixe
d000d7e8:	666f206c 74657366 20736920 7374756f     l offset is outs
d000d7f8:	20656469 20656874 656c6966 00000000     ide the file....
d000d808:	796c6e4f 636e7520 72706d6f 65737365     Only uncompresse
d000d818:	4d422064 69662050 2073656c 20657261     d BMP files are 
d000d828:	70707573 6574726f 00000064 20504d42     supported...BMP 
d000d838:	656c6170 20657474 74207369 636e7572     palette is trunc
d000d848:	64657461 00000000 20504d42 65786970     ated....BMP pixe
d000d858:	6164206c 69206174 72742073 61636e75     l data is trunca
d000d868:	00646574 20746f4e 756f6e65 6d206867     ted.Not enough m
d000d878:	726f6d65 6f662079 4d422072 69702050     emory for BMP pi
d000d888:	736c6578 00000000 75736e55 726f7070     xels....Unsuppor
d000d898:	20646574 20504d42 20746962 74706564     ted BMP bit dept
d000d8a8:	00000068 20746f4e 756f6e65 6d206867     h...Not enough m
d000d8b8:	726f6d65 6f662079 4d422072 72742050     emory for BMP tr
d000d8c8:	6f636575 72756f6c 00000000 20464649     uecolour....IFF 
d000d8d8:	656c6966 20736920 20746f6e 4d424c49     file is not ILBM
d000d8e8:	4d42502f 00000000 20464649 6e756863     /PBM....IFF chun
d000d8f8:	7369206b 75727420 7461636e 00006465     k is truncated..
d000d908:	61766e49 2064696c 44484d42 75686320     Invalid BMHD chu
d000d918:	00006b6e 20464649 6d207369 69737369     nk..IFF is missi
d000d928:	4220676e 2044484d 4220726f 0059444f     ng BMHD or BODY.
d000d938:	75736e55 726f7070 20646574 20464649     Unsupported IFF 
d000d948:	706d6f63 73736572 006e6f69 20464649     compression.IFF 
d000d958:	74207369 6c206f6f 65677261 726f6620     is too large for
d000d968:	69687420 70612073 74656c70 00000000      this applet....
d000d978:	20464649 20736168 65726f6d 61687420     IFF has more tha
d000d988:	2038206e 6e616c70 203b7365 796c6e6f     n 8 planes; only
d000d998:	4d414820 2d34322f 20746962 20657261      HAM/24-bit are 
d000d9a8:	70707573 6574726f 00000064 20746f4e     supported...Not 
d000d9b8:	756f6e65 6d206867 726f6d65 6f662079     enough memory fo
d000d9c8:	46492072 6f722046 00000077 20746f4e     r IFF row...Not 
d000d9d8:	756f6e65 6d206867 726f6d65 6f662079     enough memory fo
d000d9e8:	46492072 69702046 736c6578 00000000     r IFF pixels....
d000d9f8:	20464649 59444f42 20736920 6e757274     IFF BODY is trun
d000da08:	65746163 00000064 20464649 65747942     cated...IFF Byte
d000da18:	316e7552 74616420 73692061 726f6320     Run1 data is cor
d000da28:	74707572 00000000 00464947 00613738     rupt....GIF.87a.
d000da38:	00613938 20746f4e 49472061 69662046     89a.Not a GIF fi
d000da48:	0000656c 20464947 74207369 6c206f6f     le..GIF is too l
d000da58:	65677261 726f6620 69687420 70612073     arge for this ap
d000da68:	74656c70 00000000 20464947 626f6c67     plet....GIF glob
d000da78:	70206c61 74656c61 69206574 72742073     al palette is tr
d000da88:	61636e75 00646574 20746f4e 756f6e65     uncated.Not enou
d000da98:	6d206867 726f6d65 6f662079 49472072     gh memory for GI
d000daa8:	69702046 736c6578 00000000 20464947     F pixels....GIF 
d000dab8:	20736168 69206f6e 6567616d 61726620     has no image fra
d000dac8:	0000656d 20464947 65747865 6f69736e     me..GIF extensio
d000dad8:	7369206e 75727420 7461636e 00006465     n is truncated..
d000dae8:	20464947 746e6f63 206c6f72 636f6c62     GIF control bloc
d000daf8:	7369206b 75727420 7461636e 00006465     k is truncated..
d000db08:	20646142 20464947 746e6f63 206c6f72     Bad GIF control 
d000db18:	636f6c62 0000006b 20646142 20464947     block...Bad GIF 
d000db28:	746e6f63 206c6f72 6d726574 74616e69     control terminat
d000db38:	0000726f 20464947 67616d69 65642065     or..GIF image de
d000db48:	69726373 726f7470 20736920 6e757274     scriptor is trun
d000db58:	65746163 00000064 61766e49 2064696c     cated...Invalid 
d000db68:	20464947 6d617266 69642065 736e656d     GIF frame dimens
d000db78:	736e6f69 00000000 20464947 61636f6c     ions....GIF loca
d000db88:	6170206c 7474656c 73692065 75727420     l palette is tru
d000db98:	7461636e 00006465 20464947 67616d69     ncated..GIF imag
d000dba8:	61642065 69206174 696d2073 6e697373     e data is missin
d000dbb8:	00000067 20746f4e 756f6e65 6d206867     g...Not enough m
d000dbc8:	726f6d65 6f662079 49472072 61642046     emory for GIF da
d000dbd8:	00006174 75736e55 726f7070 20646574     ta..Unsupported 
d000dbe8:	20464947 65646f63 7a697320 00000065     GIF code size...
d000dbf8:	20746f4e 756f6e65 6d206867 726f6d65     Not enough memor
d000dc08:	6f662079 49472072 5a4c2046 00000057     y for GIF LZW...
d000dc18:	20464947 636f6c62 616d206b 72656b72     GIF block marker
d000dc28:	20736920 75736e75 726f7070 00646574      is unsupported.
d000dc38:	20464947 65646e65 65622064 65726f66     GIF ended before
d000dc48:	616d6920 64206567 00617461 4745504a      image data.JPEG
d000dc58:	6c696620 73692065 6f6f7420 72616c20      file is too lar
d000dc68:	00006567 4745504a 6c616620 6361626c     ge..JPEG fallbac
d000dc78:	6564206b 65646f63 61662072 64656c69     k decoder failed
d000dc88:	00000000 4745504a 20736920 206f6f74     ....JPEG is too 
d000dc98:	6772616c 6f662065 68742072 61207369     large for this a
d000dca8:	656c7070 00000074 20746f4e 756f6e65     pplet...Not enou
d000dcb8:	6d206867 726f6d65 6f662079 504a2072     gh memory for JP
d000dcc8:	70204745 6c657869 00000073 28207325     EG pixels...%s (
d000dcd8:	00297525 4745504a 63656420 2065646f     %u).JPEG decode 
d000dce8:	6c696166 25206465 00000075 6e6b6e55     failed %u...Unkn
d000dcf8:	206e776f 67616d69 6f662065 74616d72     own image format
d000dd08:	00000000 64616f4c 25206465 75257875     ....Loaded %ux%u
d000dd18:	7325203a 00000000 67616d49 6f642065     : %s....Image do
d000dd28:	0021656e 20464947 20575a4c 61746164     ne!.GIF LZW data
d000dd38:	20736920 72726f63 00747075 20464947      is corrupt.GIF 
d000dd48:	67616d69 61642065 69206174 72742073     image data is tr
d000dd58:	61636e75 00646574 64616f4c 20676e69     uncated.Loading 
d000dd68:	67616d69 2e2e2e65 00000000              image.......

d000dd74 <starts.9954>:
d000dd74:	01020400                                ....

d000dd78 <steps.9955>:
d000dd78:	02040808 7566202c 6974636e 203a6e6f     ...., function: 
d000dd88:	73736100 69747265 22206e6f 20227325     .assertion "%s" 
d000dd98:	6c696166 203a6465 656c6966 73252220     failed: file "%s
d000dda8:	6c202c22 20656e69 73256425 000a7325     ", line %d%s%s..

d000ddb8 <_global_impure_ptr>:
d000ddb8:	d000de5c 2b302d23 6c680020 6665004c     \...#-0+ .hlL.ef
d000ddc8:	47464567 32313000 36353433 41393837     gEFG.0123456789A
d000ddd8:	45444342 31300046 35343332 39383736     BCDEF.0123456789
d000dde8:	64636261 00006665                       abcdef..

d000ddf0 <__sf_fake_stderr>:
	...

d000de10 <__sf_fake_stdin>:
	...

d000de30 <__sf_fake_stdout>:
	...

Disassembly of section .init:

d000de50 <_init>:
d000de50:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000de52:	bf00      	nop

Disassembly of section .fini:

d000de54 <_fini>:
d000de54:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d000de56:	bf00      	nop
