#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "main.h"
#include "apis.h"


#include "resources.h"

#include "screensavers.h"

#define APP_TITLE       "TOOTH ACHE"


extern const char txtTitle[];

MEMALIGN32 volatile gfx_bitmap_t *front_a;
MEMALIGN32 volatile gfx_bitmap_t *front_b;
//MEMALIGN32 volatile gfx_bitmap_t *backbuff;
volatile static uint8_t db;

MEMALIGN32 volatile gfx_bitmap_t backbitmap;    // background image



int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    //DIVZEROOFF;

    configure_runmode(GAMEMODE_PROFILE_1);
    initMalloc();

    gfx_setlcd(DEFAULT_RENDER_ORDER, FPS_50);
    gfx_mode(SCREEN_W, SCREEN_H, SCREEN_W, SCREEN_H, DISPFLAG_DUALLAYER);
    //set_audio_dma(512); // a few ms about 7ms enough for a full frame.
    //set_music_dma = 1;

    front_a = gfx_getdrawbuffer();
    front_b = gfx_getshowbuffer();

    
    gfx_usebpalette(thePallete);
    
    gfx_usefpalette(clut);
    
    

    gfx_showbbuffer(&backbitmap);
    gfx_showfbuffer(front_a);
    gfx_usebuffer(front_b);
    //lcd_bright(23);

    init_scene();

    //music_play("sdcard:/level1.mod", 0);
    uint8_t joy = 0;
    while(joy = getjoyport()){
        gfx_lcdwait();
        gfx_cls();



        {
            //do demo here
        }
        
        
        
        
        flip_front_buffer();

        gfx_displaynow();
        music_update();

        if ((joy & BTN_FIRE) && (joy & BTN_FIRE2)){
            while((getjoyport() & BTN_FIRE) && (getjoyport() & BTN_FIRE2));
            break;
        }
        
    }

    printf("Cube demo :)\n");
    restore_lcd_desktop_mode();
    HWKERNAL->exitgamemode();

    return 0x00;
}

