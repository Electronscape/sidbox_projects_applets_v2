
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0080010 <applet_entry>:
d0080010:	b570      	push	{r4, r5, r6, lr}
d0080012:	4e09      	ldr	r6, [pc, #36]	; (d0080038 <applet_entry+0x28>)
d0080014:	460d      	mov	r5, r1
d0080016:	4604      	mov	r4, r0
d0080018:	2100      	movs	r1, #0
d008001a:	6833      	ldr	r3, [r6, #0]
d008001c:	6898      	ldr	r0, [r3, #8]
d008001e:	f003 ff33 	bl	d0083e88 <setbuf>
d0080022:	6833      	ldr	r3, [r6, #0]
d0080024:	2100      	movs	r1, #0
d0080026:	68d8      	ldr	r0, [r3, #12]
d0080028:	f003 ff2e 	bl	d0083e88 <setbuf>
d008002c:	4629      	mov	r1, r5
d008002e:	4620      	mov	r0, r4
d0080030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0080034:	f003 bb9c 	b.w	d0083770 <main>
d0080038:	d0084ab0 	.word	0xd0084ab0

d008003c <initMalloc>:
d008003c:	4902      	ldr	r1, [pc, #8]	; (d0080048 <initMalloc+0xc>)
d008003e:	4b03      	ldr	r3, [pc, #12]	; (d008004c <initMalloc+0x10>)
d0080040:	4a03      	ldr	r2, [pc, #12]	; (d0080050 <initMalloc+0x14>)
d0080042:	1a5b      	subs	r3, r3, r1
d0080044:	6013      	str	r3, [r2, #0]
d0080046:	4770      	bx	lr
d0080048:	d00b6d60 	.word	0xd00b6d60
d008004c:	d0600000 	.word	0xd0600000
d0080050:	d00b4d48 	.word	0xd00b4d48

d0080054 <_write_r>:
d0080054:	3901      	subs	r1, #1
d0080056:	2901      	cmp	r1, #1
d0080058:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008005a:	d81f      	bhi.n	d008009c <_write_r+0x48>
d008005c:	b1e2      	cbz	r2, d0080098 <_write_r+0x44>
d008005e:	461c      	mov	r4, r3
d0080060:	b1d3      	cbz	r3, d0080098 <_write_r+0x44>
d0080062:	4d12      	ldr	r5, [pc, #72]	; (d00800ac <_write_r+0x58>)
d0080064:	682e      	ldr	r6, [r5, #0]
d0080066:	b9ae      	cbnz	r6, d0080094 <_write_r+0x40>
d0080068:	4f11      	ldr	r7, [pc, #68]	; (d00800b0 <_write_r+0x5c>)
d008006a:	2301      	movs	r3, #1
d008006c:	4611      	mov	r1, r2
d008006e:	4630      	mov	r0, r6
d0080070:	602b      	str	r3, [r5, #0]
d0080072:	4622      	mov	r2, r4
d0080074:	7a3b      	ldrb	r3, [r7, #8]
d0080076:	f897 c009 	ldrb.w	ip, [r7, #9]
d008007a:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d008007e:	f897 c00a 	ldrb.w	ip, [r7, #10]
d0080082:	7aff      	ldrb	r7, [r7, #11]
d0080084:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0080088:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d008008c:	681b      	ldr	r3, [r3, #0]
d008008e:	685b      	ldr	r3, [r3, #4]
d0080090:	4798      	blx	r3
d0080092:	602e      	str	r6, [r5, #0]
d0080094:	4620      	mov	r0, r4
d0080096:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0080098:	2000      	movs	r0, #0
d008009a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d008009c:	f003 fe26 	bl	d0083cec <__errno>
d00800a0:	2209      	movs	r2, #9
d00800a2:	4603      	mov	r3, r0
d00800a4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800a8:	601a      	str	r2, [r3, #0]
d00800aa:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800ac:	d0084b24 	.word	0xd0084b24
d00800b0:	2001f000 	.word	0x2001f000

d00800b4 <_read>:
d00800b4:	b508      	push	{r3, lr}
d00800b6:	f003 fe19 	bl	d0083cec <__errno>
d00800ba:	2258      	movs	r2, #88	; 0x58
d00800bc:	4603      	mov	r3, r0
d00800be:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800c2:	601a      	str	r2, [r3, #0]
d00800c4:	bd08      	pop	{r3, pc}
d00800c6:	bf00      	nop

d00800c8 <_close>:
d00800c8:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800cc:	4770      	bx	lr
d00800ce:	bf00      	nop

d00800d0 <_fstat>:
d00800d0:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d00800d4:	2000      	movs	r0, #0
d00800d6:	604b      	str	r3, [r1, #4]
d00800d8:	4770      	bx	lr
d00800da:	bf00      	nop

d00800dc <_lseek>:
d00800dc:	2000      	movs	r0, #0
d00800de:	4770      	bx	lr

d00800e0 <_sbrk_r>:
d00800e0:	4b0c      	ldr	r3, [pc, #48]	; (d0080114 <_sbrk_r+0x34>)
d00800e2:	4a0d      	ldr	r2, [pc, #52]	; (d0080118 <_sbrk_r+0x38>)
d00800e4:	6818      	ldr	r0, [r3, #0]
d00800e6:	b510      	push	{r4, lr}
d00800e8:	b918      	cbnz	r0, d00800f2 <_sbrk_r+0x12>
d00800ea:	1dd0      	adds	r0, r2, #7
d00800ec:	f020 0007 	bic.w	r0, r0, #7
d00800f0:	6018      	str	r0, [r3, #0]
d00800f2:	4401      	add	r1, r0
d00800f4:	4c09      	ldr	r4, [pc, #36]	; (d008011c <_sbrk_r+0x3c>)
d00800f6:	42a1      	cmp	r1, r4
d00800f8:	d803      	bhi.n	d0080102 <_sbrk_r+0x22>
d00800fa:	4291      	cmp	r1, r2
d00800fc:	d301      	bcc.n	d0080102 <_sbrk_r+0x22>
d00800fe:	6019      	str	r1, [r3, #0]
d0080100:	bd10      	pop	{r4, pc}
d0080102:	f003 fdf3 	bl	d0083cec <__errno>
d0080106:	220c      	movs	r2, #12
d0080108:	4603      	mov	r3, r0
d008010a:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008010e:	601a      	str	r2, [r3, #0]
d0080110:	bd10      	pop	{r4, pc}
d0080112:	bf00      	nop
d0080114:	d0084b20 	.word	0xd0084b20
d0080118:	d00b6d60 	.word	0xd00b6d60
d008011c:	d0600000 	.word	0xd0600000

d0080120 <emit_phone.constprop.0>:
d0080120:	4603      	mov	r3, r0
d0080122:	8800      	ldrh	r0, [r0, #0]
d0080124:	f5b0 7f40 	cmp.w	r0, #768	; 0x300
d0080128:	d235      	bcs.n	d0080196 <emit_phone.constprop.0+0x76>
d008012a:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008012e:	460c      	mov	r4, r1
d0080130:	f8df 806c 	ldr.w	r8, [pc, #108]	; d00801a0 <emit_phone.constprop.0+0x80>
d0080134:	b332      	cbz	r2, d0080184 <emit_phone.constprop.0+0x64>
d0080136:	008f      	lsls	r7, r1, #2
d0080138:	4d17      	ldr	r5, [pc, #92]	; (d0080198 <emit_phone.constprop.0+0x78>)
d008013a:	4e18      	ldr	r6, [pc, #96]	; (d008019c <emit_phone.constprop.0+0x7c>)
d008013c:	f805 4020 	strb.w	r4, [r5, r0, lsl #2]
d0080140:	443c      	add	r4, r7
d0080142:	8819      	ldrh	r1, [r3, #0]
d0080144:	4630      	mov	r0, r6
d0080146:	eb05 0581 	add.w	r5, r5, r1, lsl #2
d008014a:	806a      	strh	r2, [r5, #2]
d008014c:	881a      	ldrh	r2, [r3, #0]
d008014e:	3201      	adds	r2, #1
d0080150:	801a      	strh	r2, [r3, #0]
d0080152:	f003 ff76 	bl	d0084042 <strlen>
d0080156:	f858 4024 	ldr.w	r4, [r8, r4, lsl #2]
d008015a:	4605      	mov	r5, r0
d008015c:	4620      	mov	r0, r4
d008015e:	f003 ff70 	bl	d0084042 <strlen>
d0080162:	182b      	adds	r3, r5, r0
d0080164:	3302      	adds	r3, #2
d0080166:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008016a:	d212      	bcs.n	d0080192 <emit_phone.constprop.0+0x72>
d008016c:	b125      	cbz	r5, d0080178 <emit_phone.constprop.0+0x58>
d008016e:	2120      	movs	r1, #32
d0080170:	1973      	adds	r3, r6, r5
d0080172:	2200      	movs	r2, #0
d0080174:	5571      	strb	r1, [r6, r5]
d0080176:	705a      	strb	r2, [r3, #1]
d0080178:	4621      	mov	r1, r4
d008017a:	4808      	ldr	r0, [pc, #32]	; (d008019c <emit_phone.constprop.0+0x7c>)
d008017c:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d0080180:	f003 bf50 	b.w	d0084024 <strcat>
d0080184:	eb01 0281 	add.w	r2, r1, r1, lsl #2
d0080188:	008f      	lsls	r7, r1, #2
d008018a:	eb08 0282 	add.w	r2, r8, r2, lsl #2
d008018e:	8a12      	ldrh	r2, [r2, #16]
d0080190:	e7d2      	b.n	d0080138 <emit_phone.constprop.0+0x18>
d0080192:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0080196:	4770      	bx	lr
d0080198:	d0084b28 	.word	0xd0084b28
d008019c:	d00b4540 	.word	0xd00b4540
d00801a0:	d00846c0 	.word	0xd00846c0

d00801a4 <has_magic_e>:
d00801a4:	1c93      	adds	r3, r2, #2
d00801a6:	428b      	cmp	r3, r1
d00801a8:	d216      	bcs.n	d00801d8 <has_magic_e+0x34>
d00801aa:	4402      	add	r2, r0
d00801ac:	b410      	push	{r4}
d00801ae:	7854      	ldrb	r4, [r2, #1]
d00801b0:	f1a4 0341 	sub.w	r3, r4, #65	; 0x41
d00801b4:	b2da      	uxtb	r2, r3
d00801b6:	2a19      	cmp	r2, #25
d00801b8:	d902      	bls.n	d00801c0 <has_magic_e+0x1c>
d00801ba:	f1a4 0361 	sub.w	r3, r4, #97	; 0x61
d00801be:	b2da      	uxtb	r2, r3
d00801c0:	2a18      	cmp	r2, #24
d00801c2:	d80b      	bhi.n	d00801dc <has_magic_e+0x38>
d00801c4:	4b0e      	ldr	r3, [pc, #56]	; (d0080200 <has_magic_e+0x5c>)
d00801c6:	40d3      	lsrs	r3, r2
d00801c8:	43db      	mvns	r3, r3
d00801ca:	f013 0301 	ands.w	r3, r3, #1
d00801ce:	d105      	bne.n	d00801dc <has_magic_e+0x38>
d00801d0:	4618      	mov	r0, r3
d00801d2:	f85d 4b04 	ldr.w	r4, [sp], #4
d00801d6:	4770      	bx	lr
d00801d8:	2000      	movs	r0, #0
d00801da:	4770      	bx	lr
d00801dc:	4408      	add	r0, r1
d00801de:	f810 0c01 	ldrb.w	r0, [r0, #-1]
d00801e2:	f1a0 0341 	sub.w	r3, r0, #65	; 0x41
d00801e6:	2b19      	cmp	r3, #25
d00801e8:	d907      	bls.n	d00801fa <has_magic_e+0x56>
d00801ea:	f1a0 0065 	sub.w	r0, r0, #101	; 0x65
d00801ee:	f85d 4b04 	ldr.w	r4, [sp], #4
d00801f2:	fab0 f080 	clz	r0, r0
d00801f6:	0940      	lsrs	r0, r0, #5
d00801f8:	4770      	bx	lr
d00801fa:	3020      	adds	r0, #32
d00801fc:	b2c0      	uxtb	r0, r0
d00801fe:	e7f4      	b.n	d00801ea <has_magic_e+0x46>
d0080200:	01104111 	.word	0x01104111

d0080204 <emit_ey.constprop.0>:
d0080204:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0080206:	8803      	ldrh	r3, [r0, #0]
d0080208:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008020c:	d24b      	bcs.n	d00802a6 <emit_ey.constprop.0+0xa2>
d008020e:	4e26      	ldr	r6, [pc, #152]	; (d00802a8 <emit_ey.constprop.0+0xa4>)
d0080210:	2105      	movs	r1, #5
d0080212:	4604      	mov	r4, r0
d0080214:	2248      	movs	r2, #72	; 0x48
d0080216:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d008021a:	8803      	ldrh	r3, [r0, #0]
d008021c:	4f23      	ldr	r7, [pc, #140]	; (d00802ac <emit_ey.constprop.0+0xa8>)
d008021e:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080222:	4638      	mov	r0, r7
d0080224:	805a      	strh	r2, [r3, #2]
d0080226:	8825      	ldrh	r5, [r4, #0]
d0080228:	3501      	adds	r5, #1
d008022a:	b2ad      	uxth	r5, r5
d008022c:	8025      	strh	r5, [r4, #0]
d008022e:	f003 ff08 	bl	d0084042 <strlen>
d0080232:	1d03      	adds	r3, r0, #4
d0080234:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080238:	d20e      	bcs.n	d0080258 <emit_ey.constprop.0+0x54>
d008023a:	b138      	cbz	r0, d008024c <emit_ey.constprop.0+0x48>
d008023c:	2120      	movs	r1, #32
d008023e:	183b      	adds	r3, r7, r0
d0080240:	2200      	movs	r2, #0
d0080242:	5439      	strb	r1, [r7, r0]
d0080244:	4638      	mov	r0, r7
d0080246:	705a      	strb	r2, [r3, #1]
d0080248:	f003 fefb 	bl	d0084042 <strlen>
d008024c:	4438      	add	r0, r7
d008024e:	2203      	movs	r2, #3
d0080250:	4917      	ldr	r1, [pc, #92]	; (d00802b0 <emit_ey.constprop.0+0xac>)
d0080252:	f003 fd59 	bl	d0083d08 <memcpy>
d0080256:	8825      	ldrh	r5, [r4, #0]
d0080258:	f5b5 7f40 	cmp.w	r5, #768	; 0x300
d008025c:	d223      	bcs.n	d00802a6 <emit_ey.constprop.0+0xa2>
d008025e:	2208      	movs	r2, #8
d0080260:	234c      	movs	r3, #76	; 0x4c
d0080262:	4812      	ldr	r0, [pc, #72]	; (d00802ac <emit_ey.constprop.0+0xa8>)
d0080264:	f806 2025 	strb.w	r2, [r6, r5, lsl #2]
d0080268:	8822      	ldrh	r2, [r4, #0]
d008026a:	eb06 0682 	add.w	r6, r6, r2, lsl #2
d008026e:	8073      	strh	r3, [r6, #2]
d0080270:	8823      	ldrh	r3, [r4, #0]
d0080272:	3301      	adds	r3, #1
d0080274:	8023      	strh	r3, [r4, #0]
d0080276:	f003 fee4 	bl	d0084042 <strlen>
d008027a:	1d02      	adds	r2, r0, #4
d008027c:	4603      	mov	r3, r0
d008027e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080282:	d210      	bcs.n	d00802a6 <emit_ey.constprop.0+0xa2>
d0080284:	b140      	cbz	r0, d0080298 <emit_ey.constprop.0+0x94>
d0080286:	183a      	adds	r2, r7, r0
d0080288:	2100      	movs	r1, #0
d008028a:	2420      	movs	r4, #32
d008028c:	4807      	ldr	r0, [pc, #28]	; (d00802ac <emit_ey.constprop.0+0xa8>)
d008028e:	54fc      	strb	r4, [r7, r3]
d0080290:	7051      	strb	r1, [r2, #1]
d0080292:	f003 fed6 	bl	d0084042 <strlen>
d0080296:	4603      	mov	r3, r0
d0080298:	18f8      	adds	r0, r7, r3
d008029a:	2203      	movs	r2, #3
d008029c:	4905      	ldr	r1, [pc, #20]	; (d00802b4 <emit_ey.constprop.0+0xb0>)
d008029e:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
d00802a2:	f003 bd31 	b.w	d0083d08 <memcpy>
d00802a6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00802a8:	d0084b28 	.word	0xd0084b28
d00802ac:	d00b4540 	.word	0xd00b4540
d00802b0:	d008453c 	.word	0xd008453c
d00802b4:	d0084540 	.word	0xd0084540

d00802b8 <emit_ay.constprop.0>:
d00802b8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00802ba:	8803      	ldrh	r3, [r0, #0]
d00802bc:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00802c0:	d24b      	bcs.n	d008035a <emit_ay.constprop.0+0xa2>
d00802c2:	4e26      	ldr	r6, [pc, #152]	; (d008035c <emit_ay.constprop.0+0xa4>)
d00802c4:	2103      	movs	r1, #3
d00802c6:	4604      	mov	r4, r0
d00802c8:	224b      	movs	r2, #75	; 0x4b
d00802ca:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d00802ce:	8803      	ldrh	r3, [r0, #0]
d00802d0:	4f23      	ldr	r7, [pc, #140]	; (d0080360 <emit_ay.constprop.0+0xa8>)
d00802d2:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00802d6:	4638      	mov	r0, r7
d00802d8:	805a      	strh	r2, [r3, #2]
d00802da:	8825      	ldrh	r5, [r4, #0]
d00802dc:	3501      	adds	r5, #1
d00802de:	b2ad      	uxth	r5, r5
d00802e0:	8025      	strh	r5, [r4, #0]
d00802e2:	f003 feae 	bl	d0084042 <strlen>
d00802e6:	1d03      	adds	r3, r0, #4
d00802e8:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00802ec:	d20e      	bcs.n	d008030c <emit_ay.constprop.0+0x54>
d00802ee:	b138      	cbz	r0, d0080300 <emit_ay.constprop.0+0x48>
d00802f0:	2120      	movs	r1, #32
d00802f2:	183b      	adds	r3, r7, r0
d00802f4:	2200      	movs	r2, #0
d00802f6:	5439      	strb	r1, [r7, r0]
d00802f8:	4638      	mov	r0, r7
d00802fa:	705a      	strb	r2, [r3, #1]
d00802fc:	f003 fea1 	bl	d0084042 <strlen>
d0080300:	4438      	add	r0, r7
d0080302:	2203      	movs	r2, #3
d0080304:	4917      	ldr	r1, [pc, #92]	; (d0080364 <emit_ay.constprop.0+0xac>)
d0080306:	f003 fcff 	bl	d0083d08 <memcpy>
d008030a:	8825      	ldrh	r5, [r4, #0]
d008030c:	f5b5 7f40 	cmp.w	r5, #768	; 0x300
d0080310:	d223      	bcs.n	d008035a <emit_ay.constprop.0+0xa2>
d0080312:	2208      	movs	r2, #8
d0080314:	2352      	movs	r3, #82	; 0x52
d0080316:	4812      	ldr	r0, [pc, #72]	; (d0080360 <emit_ay.constprop.0+0xa8>)
d0080318:	f806 2025 	strb.w	r2, [r6, r5, lsl #2]
d008031c:	8822      	ldrh	r2, [r4, #0]
d008031e:	eb06 0682 	add.w	r6, r6, r2, lsl #2
d0080322:	8073      	strh	r3, [r6, #2]
d0080324:	8823      	ldrh	r3, [r4, #0]
d0080326:	3301      	adds	r3, #1
d0080328:	8023      	strh	r3, [r4, #0]
d008032a:	f003 fe8a 	bl	d0084042 <strlen>
d008032e:	1d02      	adds	r2, r0, #4
d0080330:	4603      	mov	r3, r0
d0080332:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080336:	d210      	bcs.n	d008035a <emit_ay.constprop.0+0xa2>
d0080338:	b140      	cbz	r0, d008034c <emit_ay.constprop.0+0x94>
d008033a:	183a      	adds	r2, r7, r0
d008033c:	2100      	movs	r1, #0
d008033e:	2420      	movs	r4, #32
d0080340:	4807      	ldr	r0, [pc, #28]	; (d0080360 <emit_ay.constprop.0+0xa8>)
d0080342:	54fc      	strb	r4, [r7, r3]
d0080344:	7051      	strb	r1, [r2, #1]
d0080346:	f003 fe7c 	bl	d0084042 <strlen>
d008034a:	4603      	mov	r3, r0
d008034c:	18f8      	adds	r0, r7, r3
d008034e:	2203      	movs	r2, #3
d0080350:	4905      	ldr	r1, [pc, #20]	; (d0080368 <emit_ay.constprop.0+0xb0>)
d0080352:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
d0080356:	f003 bcd7 	b.w	d0083d08 <memcpy>
d008035a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d008035c:	d0084b28 	.word	0xd0084b28
d0080360:	d00b4540 	.word	0xd00b4540
d0080364:	d0084544 	.word	0xd0084544
d0080368:	d0084540 	.word	0xd0084540

d008036c <emit_known_word.constprop.0>:
d008036c:	2900      	cmp	r1, #0
d008036e:	f000 85b7 	beq.w	d0080ee0 <emit_known_word.constprop.0+0xb74>
d0080372:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0080376:	4614      	mov	r4, r2
d0080378:	f8df e7ec 	ldr.w	lr, [pc, #2028]	; d0080b68 <emit_known_word.constprop.0+0x7fc>
d008037c:	1e42      	subs	r2, r0, #1
d008037e:	b083      	sub	sp, #12
d0080380:	2500      	movs	r5, #0
d0080382:	2674      	movs	r6, #116	; 0x74
d0080384:	4694      	mov	ip, r2
d0080386:	4677      	mov	r7, lr
d0080388:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d008038c:	3501      	adds	r5, #1
d008038e:	f1a3 0841 	sub.w	r8, r3, #65	; 0x41
d0080392:	b2ad      	uxth	r5, r5
d0080394:	f1b8 0f19 	cmp.w	r8, #25
d0080398:	d801      	bhi.n	d008039e <emit_known_word.constprop.0+0x32>
d008039a:	3320      	adds	r3, #32
d008039c:	b2db      	uxtb	r3, r3
d008039e:	42b3      	cmp	r3, r6
d00803a0:	d106      	bne.n	d00803b0 <emit_known_word.constprop.0+0x44>
d00803a2:	42a9      	cmp	r1, r5
d00803a4:	f000 828e 	beq.w	d00808c4 <emit_known_word.constprop.0+0x558>
d00803a8:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d00803ac:	2e00      	cmp	r6, #0
d00803ae:	d1eb      	bne.n	d0080388 <emit_known_word.constprop.0+0x1c>
d00803b0:	f8df 87b8 	ldr.w	r8, [pc, #1976]	; d0080b6c <emit_known_word.constprop.0+0x800>
d00803b4:	4694      	mov	ip, r2
d00803b6:	2500      	movs	r5, #0
d00803b8:	2674      	movs	r6, #116	; 0x74
d00803ba:	4647      	mov	r7, r8
d00803bc:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d00803c0:	3501      	adds	r5, #1
d00803c2:	f1a3 0e41 	sub.w	lr, r3, #65	; 0x41
d00803c6:	b2ad      	uxth	r5, r5
d00803c8:	f1be 0f19 	cmp.w	lr, #25
d00803cc:	d801      	bhi.n	d00803d2 <emit_known_word.constprop.0+0x66>
d00803ce:	3320      	adds	r3, #32
d00803d0:	b2db      	uxtb	r3, r3
d00803d2:	42b3      	cmp	r3, r6
d00803d4:	d106      	bne.n	d00803e4 <emit_known_word.constprop.0+0x78>
d00803d6:	42a9      	cmp	r1, r5
d00803d8:	f000 82d3 	beq.w	d0080982 <emit_known_word.constprop.0+0x616>
d00803dc:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d00803e0:	2e00      	cmp	r6, #0
d00803e2:	d1eb      	bne.n	d00803bc <emit_known_word.constprop.0+0x50>
d00803e4:	f8df 8788 	ldr.w	r8, [pc, #1928]	; d0080b70 <emit_known_word.constprop.0+0x804>
d00803e8:	4694      	mov	ip, r2
d00803ea:	2500      	movs	r5, #0
d00803ec:	2674      	movs	r6, #116	; 0x74
d00803ee:	4647      	mov	r7, r8
d00803f0:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d00803f4:	3501      	adds	r5, #1
d00803f6:	f1a3 0e41 	sub.w	lr, r3, #65	; 0x41
d00803fa:	b2ad      	uxth	r5, r5
d00803fc:	f1be 0f19 	cmp.w	lr, #25
d0080400:	d801      	bhi.n	d0080406 <emit_known_word.constprop.0+0x9a>
d0080402:	3320      	adds	r3, #32
d0080404:	b2db      	uxtb	r3, r3
d0080406:	42b3      	cmp	r3, r6
d0080408:	d106      	bne.n	d0080418 <emit_known_word.constprop.0+0xac>
d008040a:	42a9      	cmp	r1, r5
d008040c:	f000 8328 	beq.w	d0080a60 <emit_known_word.constprop.0+0x6f4>
d0080410:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d0080414:	2e00      	cmp	r6, #0
d0080416:	d1eb      	bne.n	d00803f0 <emit_known_word.constprop.0+0x84>
d0080418:	f8df 8758 	ldr.w	r8, [pc, #1880]	; d0080b74 <emit_known_word.constprop.0+0x808>
d008041c:	4694      	mov	ip, r2
d008041e:	2500      	movs	r5, #0
d0080420:	2674      	movs	r6, #116	; 0x74
d0080422:	4647      	mov	r7, r8
d0080424:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d0080428:	3501      	adds	r5, #1
d008042a:	f1a3 0e41 	sub.w	lr, r3, #65	; 0x41
d008042e:	b2ad      	uxth	r5, r5
d0080430:	f1be 0f19 	cmp.w	lr, #25
d0080434:	d801      	bhi.n	d008043a <emit_known_word.constprop.0+0xce>
d0080436:	3320      	adds	r3, #32
d0080438:	b2db      	uxtb	r3, r3
d008043a:	429e      	cmp	r6, r3
d008043c:	d106      	bne.n	d008044c <emit_known_word.constprop.0+0xe0>
d008043e:	42a9      	cmp	r1, r5
d0080440:	f000 83bc 	beq.w	d0080bbc <emit_known_word.constprop.0+0x850>
d0080444:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d0080448:	2e00      	cmp	r6, #0
d008044a:	d1eb      	bne.n	d0080424 <emit_known_word.constprop.0+0xb8>
d008044c:	f8df 8728 	ldr.w	r8, [pc, #1832]	; d0080b78 <emit_known_word.constprop.0+0x80c>
d0080450:	4694      	mov	ip, r2
d0080452:	2500      	movs	r5, #0
d0080454:	2674      	movs	r6, #116	; 0x74
d0080456:	4647      	mov	r7, r8
d0080458:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d008045c:	3501      	adds	r5, #1
d008045e:	f1a3 0e41 	sub.w	lr, r3, #65	; 0x41
d0080462:	b2ad      	uxth	r5, r5
d0080464:	f1be 0f19 	cmp.w	lr, #25
d0080468:	d801      	bhi.n	d008046e <emit_known_word.constprop.0+0x102>
d008046a:	3320      	adds	r3, #32
d008046c:	b2db      	uxtb	r3, r3
d008046e:	429e      	cmp	r6, r3
d0080470:	d106      	bne.n	d0080480 <emit_known_word.constprop.0+0x114>
d0080472:	42a9      	cmp	r1, r5
d0080474:	f000 8421 	beq.w	d0080cba <emit_known_word.constprop.0+0x94e>
d0080478:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d008047c:	2e00      	cmp	r6, #0
d008047e:	d1eb      	bne.n	d0080458 <emit_known_word.constprop.0+0xec>
d0080480:	f8df 86f8 	ldr.w	r8, [pc, #1784]	; d0080b7c <emit_known_word.constprop.0+0x810>
d0080484:	4694      	mov	ip, r2
d0080486:	2679      	movs	r6, #121	; 0x79
d0080488:	2500      	movs	r5, #0
d008048a:	4647      	mov	r7, r8
d008048c:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d0080490:	3501      	adds	r5, #1
d0080492:	f1a3 0e41 	sub.w	lr, r3, #65	; 0x41
d0080496:	b2ad      	uxth	r5, r5
d0080498:	f1be 0f19 	cmp.w	lr, #25
d008049c:	d801      	bhi.n	d00804a2 <emit_known_word.constprop.0+0x136>
d008049e:	3320      	adds	r3, #32
d00804a0:	b2db      	uxtb	r3, r3
d00804a2:	429e      	cmp	r6, r3
d00804a4:	d106      	bne.n	d00804b4 <emit_known_word.constprop.0+0x148>
d00804a6:	42a9      	cmp	r1, r5
d00804a8:	f000 825c 	beq.w	d0080964 <emit_known_word.constprop.0+0x5f8>
d00804ac:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d00804b0:	2e00      	cmp	r6, #0
d00804b2:	d1eb      	bne.n	d008048c <emit_known_word.constprop.0+0x120>
d00804b4:	f8df 86c8 	ldr.w	r8, [pc, #1736]	; d0080b80 <emit_known_word.constprop.0+0x814>
d00804b8:	4694      	mov	ip, r2
d00804ba:	2679      	movs	r6, #121	; 0x79
d00804bc:	2500      	movs	r5, #0
d00804be:	4647      	mov	r7, r8
d00804c0:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d00804c4:	3501      	adds	r5, #1
d00804c6:	f1a3 0e41 	sub.w	lr, r3, #65	; 0x41
d00804ca:	b2ad      	uxth	r5, r5
d00804cc:	f1be 0f19 	cmp.w	lr, #25
d00804d0:	d801      	bhi.n	d00804d6 <emit_known_word.constprop.0+0x16a>
d00804d2:	3320      	adds	r3, #32
d00804d4:	b2db      	uxtb	r3, r3
d00804d6:	429e      	cmp	r6, r3
d00804d8:	d106      	bne.n	d00804e8 <emit_known_word.constprop.0+0x17c>
d00804da:	42a9      	cmp	r1, r5
d00804dc:	f000 83f3 	beq.w	d0080cc6 <emit_known_word.constprop.0+0x95a>
d00804e0:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d00804e4:	2e00      	cmp	r6, #0
d00804e6:	d1eb      	bne.n	d00804c0 <emit_known_word.constprop.0+0x154>
d00804e8:	f8df 8698 	ldr.w	r8, [pc, #1688]	; d0080b84 <emit_known_word.constprop.0+0x818>
d00804ec:	4694      	mov	ip, r2
d00804ee:	2674      	movs	r6, #116	; 0x74
d00804f0:	2300      	movs	r3, #0
d00804f2:	4647      	mov	r7, r8
d00804f4:	f81c 5f01 	ldrb.w	r5, [ip, #1]!
d00804f8:	3301      	adds	r3, #1
d00804fa:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00804fe:	b29b      	uxth	r3, r3
d0080500:	f1be 0f19 	cmp.w	lr, #25
d0080504:	d801      	bhi.n	d008050a <emit_known_word.constprop.0+0x19e>
d0080506:	3520      	adds	r5, #32
d0080508:	b2ed      	uxtb	r5, r5
d008050a:	42ae      	cmp	r6, r5
d008050c:	d106      	bne.n	d008051c <emit_known_word.constprop.0+0x1b0>
d008050e:	4299      	cmp	r1, r3
d0080510:	f000 8432 	beq.w	d0080d78 <emit_known_word.constprop.0+0xa0c>
d0080514:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d0080518:	2e00      	cmp	r6, #0
d008051a:	d1eb      	bne.n	d00804f4 <emit_known_word.constprop.0+0x188>
d008051c:	f8df 8668 	ldr.w	r8, [pc, #1640]	; d0080b88 <emit_known_word.constprop.0+0x81c>
d0080520:	4694      	mov	ip, r2
d0080522:	2300      	movs	r3, #0
d0080524:	2674      	movs	r6, #116	; 0x74
d0080526:	4647      	mov	r7, r8
d0080528:	f81c 5f01 	ldrb.w	r5, [ip, #1]!
d008052c:	3301      	adds	r3, #1
d008052e:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080532:	b29b      	uxth	r3, r3
d0080534:	f1be 0f19 	cmp.w	lr, #25
d0080538:	d801      	bhi.n	d008053e <emit_known_word.constprop.0+0x1d2>
d008053a:	3520      	adds	r5, #32
d008053c:	b2ed      	uxtb	r5, r5
d008053e:	42ae      	cmp	r6, r5
d0080540:	d106      	bne.n	d0080550 <emit_known_word.constprop.0+0x1e4>
d0080542:	4299      	cmp	r1, r3
d0080544:	f000 84c5 	beq.w	d0080ed2 <emit_known_word.constprop.0+0xb66>
d0080548:	f817 6f01 	ldrb.w	r6, [r7, #1]!
d008054c:	2e00      	cmp	r6, #0
d008054e:	d1eb      	bne.n	d0080528 <emit_known_word.constprop.0+0x1bc>
d0080550:	f8df b638 	ldr.w	fp, [pc, #1592]	; d0080b8c <emit_known_word.constprop.0+0x820>
d0080554:	f101 3aff 	add.w	sl, r1, #4294967295	; 0xffffffff
d0080558:	4616      	mov	r6, r2
d008055a:	f04f 0c74 	mov.w	ip, #116	; 0x74
d008055e:	fa10 f98a 	uxtah	r9, r0, sl
d0080562:	465f      	mov	r7, fp
d0080564:	f1cb 0801 	rsb	r8, fp, #1
d0080568:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008056c:	eb08 0307 	add.w	r3, r8, r7
d0080570:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080574:	b29b      	uxth	r3, r3
d0080576:	f1be 0f19 	cmp.w	lr, #25
d008057a:	d801      	bhi.n	d0080580 <emit_known_word.constprop.0+0x214>
d008057c:	3520      	adds	r5, #32
d008057e:	b2ed      	uxtb	r5, r5
d0080580:	45ac      	cmp	ip, r5
d0080582:	d107      	bne.n	d0080594 <emit_known_word.constprop.0+0x228>
d0080584:	454e      	cmp	r6, r9
d0080586:	f000 84bf 	beq.w	d0080f08 <emit_known_word.constprop.0+0xb9c>
d008058a:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d008058e:	f1bc 0f00 	cmp.w	ip, #0
d0080592:	d1e9      	bne.n	d0080568 <emit_known_word.constprop.0+0x1fc>
d0080594:	f8df b5f8 	ldr.w	fp, [pc, #1528]	; d0080b90 <emit_known_word.constprop.0+0x824>
d0080598:	4616      	mov	r6, r2
d008059a:	fa10 f98a 	uxtah	r9, r0, sl
d008059e:	f04f 0c6f 	mov.w	ip, #111	; 0x6f
d00805a2:	465f      	mov	r7, fp
d00805a4:	f1cb 0801 	rsb	r8, fp, #1
d00805a8:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d00805ac:	eb08 0307 	add.w	r3, r8, r7
d00805b0:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00805b4:	b29b      	uxth	r3, r3
d00805b6:	f1be 0f19 	cmp.w	lr, #25
d00805ba:	d801      	bhi.n	d00805c0 <emit_known_word.constprop.0+0x254>
d00805bc:	3520      	adds	r5, #32
d00805be:	b2ed      	uxtb	r5, r5
d00805c0:	4565      	cmp	r5, ip
d00805c2:	d107      	bne.n	d00805d4 <emit_known_word.constprop.0+0x268>
d00805c4:	45b1      	cmp	r9, r6
d00805c6:	f000 84a9 	beq.w	d0080f1c <emit_known_word.constprop.0+0xbb0>
d00805ca:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d00805ce:	f1bc 0f00 	cmp.w	ip, #0
d00805d2:	d1e9      	bne.n	d00805a8 <emit_known_word.constprop.0+0x23c>
d00805d4:	f8df b5bc 	ldr.w	fp, [pc, #1468]	; d0080b94 <emit_known_word.constprop.0+0x828>
d00805d8:	4616      	mov	r6, r2
d00805da:	fa10 f98a 	uxtah	r9, r0, sl
d00805de:	f04f 0c69 	mov.w	ip, #105	; 0x69
d00805e2:	465f      	mov	r7, fp
d00805e4:	f1cb 0801 	rsb	r8, fp, #1
d00805e8:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d00805ec:	eb08 0307 	add.w	r3, r8, r7
d00805f0:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00805f4:	b29b      	uxth	r3, r3
d00805f6:	f1be 0f19 	cmp.w	lr, #25
d00805fa:	d801      	bhi.n	d0080600 <emit_known_word.constprop.0+0x294>
d00805fc:	3520      	adds	r5, #32
d00805fe:	b2ed      	uxtb	r5, r5
d0080600:	4565      	cmp	r5, ip
d0080602:	d107      	bne.n	d0080614 <emit_known_word.constprop.0+0x2a8>
d0080604:	45b1      	cmp	r9, r6
d0080606:	f000 84e6 	beq.w	d0080fd6 <emit_known_word.constprop.0+0xc6a>
d008060a:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d008060e:	f1bc 0f00 	cmp.w	ip, #0
d0080612:	d1e9      	bne.n	d00805e8 <emit_known_word.constprop.0+0x27c>
d0080614:	f8df b580 	ldr.w	fp, [pc, #1408]	; d0080b98 <emit_known_word.constprop.0+0x82c>
d0080618:	4616      	mov	r6, r2
d008061a:	fa10 f98a 	uxtah	r9, r0, sl
d008061e:	f04f 0c61 	mov.w	ip, #97	; 0x61
d0080622:	465f      	mov	r7, fp
d0080624:	f1cb 0801 	rsb	r8, fp, #1
d0080628:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008062c:	eb08 0307 	add.w	r3, r8, r7
d0080630:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080634:	b29b      	uxth	r3, r3
d0080636:	f1be 0f19 	cmp.w	lr, #25
d008063a:	d801      	bhi.n	d0080640 <emit_known_word.constprop.0+0x2d4>
d008063c:	3520      	adds	r5, #32
d008063e:	b2ed      	uxtb	r5, r5
d0080640:	45ac      	cmp	ip, r5
d0080642:	d107      	bne.n	d0080654 <emit_known_word.constprop.0+0x2e8>
d0080644:	45b1      	cmp	r9, r6
d0080646:	f000 8523 	beq.w	d0081090 <emit_known_word.constprop.0+0xd24>
d008064a:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d008064e:	f1bc 0f00 	cmp.w	ip, #0
d0080652:	d1e9      	bne.n	d0080628 <emit_known_word.constprop.0+0x2bc>
d0080654:	7803      	ldrb	r3, [r0, #0]
d0080656:	f1a3 0641 	sub.w	r6, r3, #65	; 0x41
d008065a:	461d      	mov	r5, r3
d008065c:	2e19      	cmp	r6, #25
d008065e:	d802      	bhi.n	d0080666 <emit_known_word.constprop.0+0x2fa>
d0080660:	f103 0520 	add.w	r5, r3, #32
d0080664:	b2ed      	uxtb	r5, r5
d0080666:	2d69      	cmp	r5, #105	; 0x69
d0080668:	d102      	bne.n	d0080670 <emit_known_word.constprop.0+0x304>
d008066a:	2901      	cmp	r1, #1
d008066c:	f000 8546 	beq.w	d00810fc <emit_known_word.constprop.0+0xd90>
d0080670:	f1a3 0541 	sub.w	r5, r3, #65	; 0x41
d0080674:	2d19      	cmp	r5, #25
d0080676:	d801      	bhi.n	d008067c <emit_known_word.constprop.0+0x310>
d0080678:	3320      	adds	r3, #32
d008067a:	b2db      	uxtb	r3, r3
d008067c:	2b61      	cmp	r3, #97	; 0x61
d008067e:	d102      	bne.n	d0080686 <emit_known_word.constprop.0+0x31a>
d0080680:	2901      	cmp	r1, #1
d0080682:	f000 85be 	beq.w	d0081202 <emit_known_word.constprop.0+0xe96>
d0080686:	f8df b514 	ldr.w	fp, [pc, #1300]	; d0080b9c <emit_known_word.constprop.0+0x830>
d008068a:	4616      	mov	r6, r2
d008068c:	fa10 f98a 	uxtah	r9, r0, sl
d0080690:	f04f 0c61 	mov.w	ip, #97	; 0x61
d0080694:	465f      	mov	r7, fp
d0080696:	f1cb 0801 	rsb	r8, fp, #1
d008069a:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008069e:	eb08 0307 	add.w	r3, r8, r7
d00806a2:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00806a6:	b29b      	uxth	r3, r3
d00806a8:	f1be 0f19 	cmp.w	lr, #25
d00806ac:	d801      	bhi.n	d00806b2 <emit_known_word.constprop.0+0x346>
d00806ae:	3520      	adds	r5, #32
d00806b0:	b2ed      	uxtb	r5, r5
d00806b2:	45ac      	cmp	ip, r5
d00806b4:	d107      	bne.n	d00806c6 <emit_known_word.constprop.0+0x35a>
d00806b6:	45b1      	cmp	r9, r6
d00806b8:	f000 8527 	beq.w	d008110a <emit_known_word.constprop.0+0xd9e>
d00806bc:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d00806c0:	f1bc 0f00 	cmp.w	ip, #0
d00806c4:	d1e9      	bne.n	d008069a <emit_known_word.constprop.0+0x32e>
d00806c6:	f8df b4d8 	ldr.w	fp, [pc, #1240]	; d0080ba0 <emit_known_word.constprop.0+0x834>
d00806ca:	4616      	mov	r6, r2
d00806cc:	fa10 f98a 	uxtah	r9, r0, sl
d00806d0:	f04f 0c68 	mov.w	ip, #104	; 0x68
d00806d4:	465f      	mov	r7, fp
d00806d6:	f1cb 0801 	rsb	r8, fp, #1
d00806da:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d00806de:	eb08 0307 	add.w	r3, r8, r7
d00806e2:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00806e6:	b29b      	uxth	r3, r3
d00806e8:	f1be 0f19 	cmp.w	lr, #25
d00806ec:	d801      	bhi.n	d00806f2 <emit_known_word.constprop.0+0x386>
d00806ee:	3520      	adds	r5, #32
d00806f0:	b2ed      	uxtb	r5, r5
d00806f2:	4565      	cmp	r5, ip
d00806f4:	d107      	bne.n	d0080706 <emit_known_word.constprop.0+0x39a>
d00806f6:	45b1      	cmp	r9, r6
d00806f8:	f000 85c0 	beq.w	d008127c <emit_known_word.constprop.0+0xf10>
d00806fc:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d0080700:	f1bc 0f00 	cmp.w	ip, #0
d0080704:	d1e9      	bne.n	d00806da <emit_known_word.constprop.0+0x36e>
d0080706:	f8df b49c 	ldr.w	fp, [pc, #1180]	; d0080ba4 <emit_known_word.constprop.0+0x838>
d008070a:	4616      	mov	r6, r2
d008070c:	fa10 f98a 	uxtah	r9, r0, sl
d0080710:	f04f 0c61 	mov.w	ip, #97	; 0x61
d0080714:	465f      	mov	r7, fp
d0080716:	f1cb 0801 	rsb	r8, fp, #1
d008071a:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008071e:	eb08 0307 	add.w	r3, r8, r7
d0080722:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080726:	b29b      	uxth	r3, r3
d0080728:	f1be 0f19 	cmp.w	lr, #25
d008072c:	d801      	bhi.n	d0080732 <emit_known_word.constprop.0+0x3c6>
d008072e:	3520      	adds	r5, #32
d0080730:	b2ed      	uxtb	r5, r5
d0080732:	45ac      	cmp	ip, r5
d0080734:	d107      	bne.n	d0080746 <emit_known_word.constprop.0+0x3da>
d0080736:	45b1      	cmp	r9, r6
d0080738:	f000 8666 	beq.w	d0081408 <emit_known_word.constprop.0+0x109c>
d008073c:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d0080740:	f1bc 0f00 	cmp.w	ip, #0
d0080744:	d1e9      	bne.n	d008071a <emit_known_word.constprop.0+0x3ae>
d0080746:	f8df b460 	ldr.w	fp, [pc, #1120]	; d0080ba8 <emit_known_word.constprop.0+0x83c>
d008074a:	4616      	mov	r6, r2
d008074c:	fa10 f98a 	uxtah	r9, r0, sl
d0080750:	f04f 0c6e 	mov.w	ip, #110	; 0x6e
d0080754:	465f      	mov	r7, fp
d0080756:	f1cb 0801 	rsb	r8, fp, #1
d008075a:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008075e:	eb08 0307 	add.w	r3, r8, r7
d0080762:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080766:	b29b      	uxth	r3, r3
d0080768:	f1be 0f19 	cmp.w	lr, #25
d008076c:	d801      	bhi.n	d0080772 <emit_known_word.constprop.0+0x406>
d008076e:	3520      	adds	r5, #32
d0080770:	b2ed      	uxtb	r5, r5
d0080772:	45ac      	cmp	ip, r5
d0080774:	d107      	bne.n	d0080786 <emit_known_word.constprop.0+0x41a>
d0080776:	45b1      	cmp	r9, r6
d0080778:	f000 8722 	beq.w	d00815c0 <emit_known_word.constprop.0+0x1254>
d008077c:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d0080780:	f1bc 0f00 	cmp.w	ip, #0
d0080784:	d1e9      	bne.n	d008075a <emit_known_word.constprop.0+0x3ee>
d0080786:	f8df b424 	ldr.w	fp, [pc, #1060]	; d0080bac <emit_known_word.constprop.0+0x840>
d008078a:	4616      	mov	r6, r2
d008078c:	fa10 f98a 	uxtah	r9, r0, sl
d0080790:	f04f 0c65 	mov.w	ip, #101	; 0x65
d0080794:	465f      	mov	r7, fp
d0080796:	f1cb 0801 	rsb	r8, fp, #1
d008079a:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008079e:	eb08 0307 	add.w	r3, r8, r7
d00807a2:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00807a6:	b29b      	uxth	r3, r3
d00807a8:	f1be 0f19 	cmp.w	lr, #25
d00807ac:	d801      	bhi.n	d00807b2 <emit_known_word.constprop.0+0x446>
d00807ae:	3520      	adds	r5, #32
d00807b0:	b2ed      	uxtb	r5, r5
d00807b2:	4565      	cmp	r5, ip
d00807b4:	d107      	bne.n	d00807c6 <emit_known_word.constprop.0+0x45a>
d00807b6:	45b1      	cmp	r9, r6
d00807b8:	f000 87b6 	beq.w	d0081728 <emit_known_word.constprop.0+0x13bc>
d00807bc:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d00807c0:	f1bc 0f00 	cmp.w	ip, #0
d00807c4:	d1e9      	bne.n	d008079a <emit_known_word.constprop.0+0x42e>
d00807c6:	f8df b3e8 	ldr.w	fp, [pc, #1000]	; d0080bb0 <emit_known_word.constprop.0+0x844>
d00807ca:	4616      	mov	r6, r2
d00807cc:	fa10 f98a 	uxtah	r9, r0, sl
d00807d0:	f04f 0c73 	mov.w	ip, #115	; 0x73
d00807d4:	465f      	mov	r7, fp
d00807d6:	f1cb 0801 	rsb	r8, fp, #1
d00807da:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d00807de:	eb08 0307 	add.w	r3, r8, r7
d00807e2:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d00807e6:	b29b      	uxth	r3, r3
d00807e8:	f1be 0f19 	cmp.w	lr, #25
d00807ec:	d801      	bhi.n	d00807f2 <emit_known_word.constprop.0+0x486>
d00807ee:	3520      	adds	r5, #32
d00807f0:	b2ed      	uxtb	r5, r5
d00807f2:	45ac      	cmp	ip, r5
d00807f4:	d107      	bne.n	d0080806 <emit_known_word.constprop.0+0x49a>
d00807f6:	45b1      	cmp	r9, r6
d00807f8:	f001 805e 	beq.w	d00818b8 <emit_known_word.constprop.0+0x154c>
d00807fc:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d0080800:	f1bc 0f00 	cmp.w	ip, #0
d0080804:	d1e9      	bne.n	d00807da <emit_known_word.constprop.0+0x46e>
d0080806:	f8df b3ac 	ldr.w	fp, [pc, #940]	; d0080bb4 <emit_known_word.constprop.0+0x848>
d008080a:	4616      	mov	r6, r2
d008080c:	fa10 f98a 	uxtah	r9, r0, sl
d0080810:	f04f 0c73 	mov.w	ip, #115	; 0x73
d0080814:	465f      	mov	r7, fp
d0080816:	f1cb 0801 	rsb	r8, fp, #1
d008081a:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008081e:	eb08 0307 	add.w	r3, r8, r7
d0080822:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080826:	b29b      	uxth	r3, r3
d0080828:	f1be 0f19 	cmp.w	lr, #25
d008082c:	d801      	bhi.n	d0080832 <emit_known_word.constprop.0+0x4c6>
d008082e:	3520      	adds	r5, #32
d0080830:	b2ed      	uxtb	r5, r5
d0080832:	4565      	cmp	r5, ip
d0080834:	d107      	bne.n	d0080846 <emit_known_word.constprop.0+0x4da>
d0080836:	45b1      	cmp	r9, r6
d0080838:	f001 80e0 	beq.w	d00819fc <emit_known_word.constprop.0+0x1690>
d008083c:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d0080840:	f1bc 0f00 	cmp.w	ip, #0
d0080844:	d1e9      	bne.n	d008081a <emit_known_word.constprop.0+0x4ae>
d0080846:	f8df b370 	ldr.w	fp, [pc, #880]	; d0080bb8 <emit_known_word.constprop.0+0x84c>
d008084a:	4616      	mov	r6, r2
d008084c:	fa10 f98a 	uxtah	r9, r0, sl
d0080850:	f04f 0c68 	mov.w	ip, #104	; 0x68
d0080854:	465f      	mov	r7, fp
d0080856:	f1cb 0801 	rsb	r8, fp, #1
d008085a:	f816 5f01 	ldrb.w	r5, [r6, #1]!
d008085e:	eb08 0307 	add.w	r3, r8, r7
d0080862:	f1a5 0e41 	sub.w	lr, r5, #65	; 0x41
d0080866:	b29b      	uxth	r3, r3
d0080868:	f1be 0f19 	cmp.w	lr, #25
d008086c:	d801      	bhi.n	d0080872 <emit_known_word.constprop.0+0x506>
d008086e:	3520      	adds	r5, #32
d0080870:	b2ed      	uxtb	r5, r5
d0080872:	45ac      	cmp	ip, r5
d0080874:	d107      	bne.n	d0080886 <emit_known_word.constprop.0+0x51a>
d0080876:	45b1      	cmp	r9, r6
d0080878:	f001 80ca 	beq.w	d0081a10 <emit_known_word.constprop.0+0x16a4>
d008087c:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d0080880:	f1bc 0f00 	cmp.w	ip, #0
d0080884:	d1e9      	bne.n	d008085a <emit_known_word.constprop.0+0x4ee>
d0080886:	4eaf      	ldr	r6, [pc, #700]	; (d0080b44 <emit_known_word.constprop.0+0x7d8>)
d0080888:	fa10 fa8a 	uxtah	sl, r0, sl
d008088c:	2068      	movs	r0, #104	; 0x68
d008088e:	4637      	mov	r7, r6
d0080890:	f1c6 0e01 	rsb	lr, r6, #1
d0080894:	e006      	b.n	d00808a4 <emit_known_word.constprop.0+0x538>
d0080896:	4592      	cmp	sl, r2
d0080898:	f001 816d 	beq.w	d0081b76 <emit_known_word.constprop.0+0x180a>
d008089c:	f817 0f01 	ldrb.w	r0, [r7, #1]!
d00808a0:	2800      	cmp	r0, #0
d00808a2:	d06b      	beq.n	d008097c <emit_known_word.constprop.0+0x610>
d00808a4:	f812 5f01 	ldrb.w	r5, [r2, #1]!
d00808a8:	eb0e 0307 	add.w	r3, lr, r7
d00808ac:	f1a5 0c41 	sub.w	ip, r5, #65	; 0x41
d00808b0:	b29b      	uxth	r3, r3
d00808b2:	f1bc 0f19 	cmp.w	ip, #25
d00808b6:	d801      	bhi.n	d00808bc <emit_known_word.constprop.0+0x550>
d00808b8:	3520      	adds	r5, #32
d00808ba:	b2ed      	uxtb	r5, r5
d00808bc:	42a8      	cmp	r0, r5
d00808be:	d0ea      	beq.n	d0080896 <emit_known_word.constprop.0+0x52a>
d00808c0:	2000      	movs	r0, #0
d00808c2:	e05b      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d00808c4:	f81e 8001 	ldrb.w	r8, [lr, r1]
d00808c8:	f1b8 0f00 	cmp.w	r8, #0
d00808cc:	f47f ad70 	bne.w	d00803b0 <emit_known_word.constprop.0+0x44>
d00808d0:	8823      	ldrh	r3, [r4, #0]
d00808d2:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00808d6:	d250      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d00808d8:	4d9b      	ldr	r5, [pc, #620]	; (d0080b48 <emit_known_word.constprop.0+0x7dc>)
d00808da:	210e      	movs	r1, #14
d00808dc:	2244      	movs	r2, #68	; 0x44
d00808de:	4e9b      	ldr	r6, [pc, #620]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d00808e0:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00808e4:	8823      	ldrh	r3, [r4, #0]
d00808e6:	4630      	mov	r0, r6
d00808e8:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00808ec:	805a      	strh	r2, [r3, #2]
d00808ee:	8827      	ldrh	r7, [r4, #0]
d00808f0:	3701      	adds	r7, #1
d00808f2:	b2bf      	uxth	r7, r7
d00808f4:	8027      	strh	r7, [r4, #0]
d00808f6:	f003 fba4 	bl	d0084042 <strlen>
d00808fa:	1d02      	adds	r2, r0, #4
d00808fc:	4603      	mov	r3, r0
d00808fe:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080902:	d208      	bcs.n	d0080916 <emit_known_word.constprop.0+0x5aa>
d0080904:	2800      	cmp	r0, #0
d0080906:	f040 828e 	bne.w	d0080e26 <emit_known_word.constprop.0+0xaba>
d008090a:	18f0      	adds	r0, r6, r3
d008090c:	2203      	movs	r2, #3
d008090e:	4990      	ldr	r1, [pc, #576]	; (d0080b50 <emit_known_word.constprop.0+0x7e4>)
d0080910:	f003 f9fa 	bl	d0083d08 <memcpy>
d0080914:	8827      	ldrh	r7, [r4, #0]
d0080916:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d008091a:	d22e      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d008091c:	2301      	movs	r3, #1
d008091e:	2278      	movs	r2, #120	; 0x78
d0080920:	488a      	ldr	r0, [pc, #552]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080922:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080926:	8823      	ldrh	r3, [r4, #0]
d0080928:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d008092c:	806a      	strh	r2, [r5, #2]
d008092e:	8823      	ldrh	r3, [r4, #0]
d0080930:	3301      	adds	r3, #1
d0080932:	8023      	strh	r3, [r4, #0]
d0080934:	f003 fb85 	bl	d0084042 <strlen>
d0080938:	1d02      	adds	r2, r0, #4
d008093a:	4603      	mov	r3, r0
d008093c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080940:	d21b      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d0080942:	b140      	cbz	r0, d0080956 <emit_known_word.constprop.0+0x5ea>
d0080944:	1832      	adds	r2, r6, r0
d0080946:	2100      	movs	r1, #0
d0080948:	2420      	movs	r4, #32
d008094a:	4880      	ldr	r0, [pc, #512]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d008094c:	54f4      	strb	r4, [r6, r3]
d008094e:	7051      	strb	r1, [r2, #1]
d0080950:	f003 fb77 	bl	d0084042 <strlen>
d0080954:	4603      	mov	r3, r0
d0080956:	18f0      	adds	r0, r6, r3
d0080958:	2203      	movs	r2, #3
d008095a:	497e      	ldr	r1, [pc, #504]	; (d0080b54 <emit_known_word.constprop.0+0x7e8>)
d008095c:	f003 f9d4 	bl	d0083d08 <memcpy>
d0080960:	2001      	movs	r0, #1
d0080962:	e00b      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0080964:	f818 8001 	ldrb.w	r8, [r8, r1]
d0080968:	f1b8 0f00 	cmp.w	r8, #0
d008096c:	f47f ada2 	bne.w	d00804b4 <emit_known_word.constprop.0+0x148>
d0080970:	8823      	ldrh	r3, [r4, #0]
d0080972:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080976:	f0c0 8260 	bcc.w	d0080e3a <emit_known_word.constprop.0+0xace>
d008097a:	2001      	movs	r0, #1
d008097c:	b003      	add	sp, #12
d008097e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0080982:	f818 8001 	ldrb.w	r8, [r8, r1]
d0080986:	f1b8 0f00 	cmp.w	r8, #0
d008098a:	f47f ad2b 	bne.w	d00803e4 <emit_known_word.constprop.0+0x78>
d008098e:	8823      	ldrh	r3, [r4, #0]
d0080990:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080994:	d2f1      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d0080996:	4d6c      	ldr	r5, [pc, #432]	; (d0080b48 <emit_known_word.constprop.0+0x7dc>)
d0080998:	210e      	movs	r1, #14
d008099a:	2244      	movs	r2, #68	; 0x44
d008099c:	4e6b      	ldr	r6, [pc, #428]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d008099e:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00809a2:	8823      	ldrh	r3, [r4, #0]
d00809a4:	4630      	mov	r0, r6
d00809a6:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00809aa:	805a      	strh	r2, [r3, #2]
d00809ac:	8827      	ldrh	r7, [r4, #0]
d00809ae:	3701      	adds	r7, #1
d00809b0:	b2bf      	uxth	r7, r7
d00809b2:	8027      	strh	r7, [r4, #0]
d00809b4:	f003 fb45 	bl	d0084042 <strlen>
d00809b8:	1d02      	adds	r2, r0, #4
d00809ba:	4603      	mov	r3, r0
d00809bc:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00809c0:	d208      	bcs.n	d00809d4 <emit_known_word.constprop.0+0x668>
d00809c2:	2800      	cmp	r0, #0
d00809c4:	f040 8268 	bne.w	d0080e98 <emit_known_word.constprop.0+0xb2c>
d00809c8:	18f0      	adds	r0, r6, r3
d00809ca:	2203      	movs	r2, #3
d00809cc:	4960      	ldr	r1, [pc, #384]	; (d0080b50 <emit_known_word.constprop.0+0x7e4>)
d00809ce:	f003 f99b 	bl	d0083d08 <memcpy>
d00809d2:	8827      	ldrh	r7, [r4, #0]
d00809d4:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d00809d8:	d2cf      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d00809da:	2307      	movs	r3, #7
d00809dc:	226e      	movs	r2, #110	; 0x6e
d00809de:	485b      	ldr	r0, [pc, #364]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d00809e0:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d00809e4:	8823      	ldrh	r3, [r4, #0]
d00809e6:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00809ea:	805a      	strh	r2, [r3, #2]
d00809ec:	8827      	ldrh	r7, [r4, #0]
d00809ee:	3701      	adds	r7, #1
d00809f0:	b2bf      	uxth	r7, r7
d00809f2:	8027      	strh	r7, [r4, #0]
d00809f4:	f003 fb25 	bl	d0084042 <strlen>
d00809f8:	1d03      	adds	r3, r0, #4
d00809fa:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00809fe:	d208      	bcs.n	d0080a12 <emit_known_word.constprop.0+0x6a6>
d0080a00:	2800      	cmp	r0, #0
d0080a02:	f040 8240 	bne.w	d0080e86 <emit_known_word.constprop.0+0xb1a>
d0080a06:	4430      	add	r0, r6
d0080a08:	2203      	movs	r2, #3
d0080a0a:	4953      	ldr	r1, [pc, #332]	; (d0080b58 <emit_known_word.constprop.0+0x7ec>)
d0080a0c:	f003 f97c 	bl	d0083d08 <memcpy>
d0080a10:	8827      	ldrh	r7, [r4, #0]
d0080a12:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080a16:	d2b0      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d0080a18:	231a      	movs	r3, #26
d0080a1a:	2252      	movs	r2, #82	; 0x52
d0080a1c:	484b      	ldr	r0, [pc, #300]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080a1e:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080a22:	8823      	ldrh	r3, [r4, #0]
d0080a24:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0080a28:	806a      	strh	r2, [r5, #2]
d0080a2a:	8823      	ldrh	r3, [r4, #0]
d0080a2c:	3301      	adds	r3, #1
d0080a2e:	8023      	strh	r3, [r4, #0]
d0080a30:	f003 fb07 	bl	d0084042 <strlen>
d0080a34:	1cc2      	adds	r2, r0, #3
d0080a36:	4603      	mov	r3, r0
d0080a38:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080a3c:	d29d      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d0080a3e:	b140      	cbz	r0, d0080a52 <emit_known_word.constprop.0+0x6e6>
d0080a40:	1832      	adds	r2, r6, r0
d0080a42:	2100      	movs	r1, #0
d0080a44:	2420      	movs	r4, #32
d0080a46:	4841      	ldr	r0, [pc, #260]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080a48:	54f4      	strb	r4, [r6, r3]
d0080a4a:	7051      	strb	r1, [r2, #1]
d0080a4c:	f003 faf9 	bl	d0084042 <strlen>
d0080a50:	4603      	mov	r3, r0
d0080a52:	18f0      	adds	r0, r6, r3
d0080a54:	2202      	movs	r2, #2
d0080a56:	4941      	ldr	r1, [pc, #260]	; (d0080b5c <emit_known_word.constprop.0+0x7f0>)
d0080a58:	f003 f956 	bl	d0083d08 <memcpy>
d0080a5c:	2001      	movs	r0, #1
d0080a5e:	e78d      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0080a60:	f818 8001 	ldrb.w	r8, [r8, r1]
d0080a64:	f1b8 0f00 	cmp.w	r8, #0
d0080a68:	f47f acd6 	bne.w	d0080418 <emit_known_word.constprop.0+0xac>
d0080a6c:	8823      	ldrh	r3, [r4, #0]
d0080a6e:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080a72:	d282      	bcs.n	d008097a <emit_known_word.constprop.0+0x60e>
d0080a74:	4d34      	ldr	r5, [pc, #208]	; (d0080b48 <emit_known_word.constprop.0+0x7dc>)
d0080a76:	210e      	movs	r1, #14
d0080a78:	2244      	movs	r2, #68	; 0x44
d0080a7a:	4e34      	ldr	r6, [pc, #208]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080a7c:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0080a80:	8823      	ldrh	r3, [r4, #0]
d0080a82:	4630      	mov	r0, r6
d0080a84:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080a88:	805a      	strh	r2, [r3, #2]
d0080a8a:	8827      	ldrh	r7, [r4, #0]
d0080a8c:	3701      	adds	r7, #1
d0080a8e:	b2bf      	uxth	r7, r7
d0080a90:	8027      	strh	r7, [r4, #0]
d0080a92:	f003 fad6 	bl	d0084042 <strlen>
d0080a96:	1d02      	adds	r2, r0, #4
d0080a98:	4603      	mov	r3, r0
d0080a9a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080a9e:	d208      	bcs.n	d0080ab2 <emit_known_word.constprop.0+0x746>
d0080aa0:	2800      	cmp	r0, #0
d0080aa2:	f040 8203 	bne.w	d0080eac <emit_known_word.constprop.0+0xb40>
d0080aa6:	18f0      	adds	r0, r6, r3
d0080aa8:	2203      	movs	r2, #3
d0080aaa:	4929      	ldr	r1, [pc, #164]	; (d0080b50 <emit_known_word.constprop.0+0x7e4>)
d0080aac:	f003 f92c 	bl	d0083d08 <memcpy>
d0080ab0:	8827      	ldrh	r7, [r4, #0]
d0080ab2:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080ab6:	f4bf af60 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080aba:	2302      	movs	r3, #2
d0080abc:	2282      	movs	r2, #130	; 0x82
d0080abe:	4823      	ldr	r0, [pc, #140]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080ac0:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080ac4:	8823      	ldrh	r3, [r4, #0]
d0080ac6:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080aca:	805a      	strh	r2, [r3, #2]
d0080acc:	8827      	ldrh	r7, [r4, #0]
d0080ace:	3701      	adds	r7, #1
d0080ad0:	b2bf      	uxth	r7, r7
d0080ad2:	8027      	strh	r7, [r4, #0]
d0080ad4:	f003 fab5 	bl	d0084042 <strlen>
d0080ad8:	1d03      	adds	r3, r0, #4
d0080ada:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080ade:	d208      	bcs.n	d0080af2 <emit_known_word.constprop.0+0x786>
d0080ae0:	2800      	cmp	r0, #0
d0080ae2:	f040 81ed 	bne.w	d0080ec0 <emit_known_word.constprop.0+0xb54>
d0080ae6:	4430      	add	r0, r6
d0080ae8:	2203      	movs	r2, #3
d0080aea:	491d      	ldr	r1, [pc, #116]	; (d0080b60 <emit_known_word.constprop.0+0x7f4>)
d0080aec:	f003 f90c 	bl	d0083d08 <memcpy>
d0080af0:	8827      	ldrh	r7, [r4, #0]
d0080af2:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080af6:	f4bf af40 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080afa:	231c      	movs	r3, #28
d0080afc:	223a      	movs	r2, #58	; 0x3a
d0080afe:	4813      	ldr	r0, [pc, #76]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080b00:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080b04:	8823      	ldrh	r3, [r4, #0]
d0080b06:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0080b0a:	806a      	strh	r2, [r5, #2]
d0080b0c:	8823      	ldrh	r3, [r4, #0]
d0080b0e:	3301      	adds	r3, #1
d0080b10:	8023      	strh	r3, [r4, #0]
d0080b12:	f003 fa96 	bl	d0084042 <strlen>
d0080b16:	1cc2      	adds	r2, r0, #3
d0080b18:	4603      	mov	r3, r0
d0080b1a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080b1e:	f4bf af2c 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080b22:	b140      	cbz	r0, d0080b36 <emit_known_word.constprop.0+0x7ca>
d0080b24:	1832      	adds	r2, r6, r0
d0080b26:	2100      	movs	r1, #0
d0080b28:	2420      	movs	r4, #32
d0080b2a:	4808      	ldr	r0, [pc, #32]	; (d0080b4c <emit_known_word.constprop.0+0x7e0>)
d0080b2c:	54f4      	strb	r4, [r6, r3]
d0080b2e:	7051      	strb	r1, [r2, #1]
d0080b30:	f003 fa87 	bl	d0084042 <strlen>
d0080b34:	4603      	mov	r3, r0
d0080b36:	18f0      	adds	r0, r6, r3
d0080b38:	2202      	movs	r2, #2
d0080b3a:	490a      	ldr	r1, [pc, #40]	; (d0080b64 <emit_known_word.constprop.0+0x7f8>)
d0080b3c:	f003 f8e4 	bl	d0083d08 <memcpy>
d0080b40:	2001      	movs	r0, #1
d0080b42:	e71b      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0080b44:	d0084620 	.word	0xd0084620
d0080b48:	d0084b28 	.word	0xd0084b28
d0080b4c:	d00b4540 	.word	0xd00b4540
d0080b50:	d008454c 	.word	0xd008454c
d0080b54:	d0084550 	.word	0xd0084550
d0080b58:	d008455c 	.word	0xd008455c
d0080b5c:	d0084560 	.word	0xd0084560
d0080b60:	d008456c 	.word	0xd008456c
d0080b64:	d0084570 	.word	0xd0084570
d0080b68:	d0084548 	.word	0xd0084548
d0080b6c:	d0084554 	.word	0xd0084554
d0080b70:	d0084564 	.word	0xd0084564
d0080b74:	d0084574 	.word	0xd0084574
d0080b78:	d008457c 	.word	0xd008457c
d0080b7c:	d0084588 	.word	0xd0084588
d0080b80:	d0084594 	.word	0xd0084594
d0080b84:	d00845a0 	.word	0xd00845a0
d0080b88:	d00845a4 	.word	0xd00845a4
d0080b8c:	d00845a8 	.word	0xd00845a8
d0080b90:	d00845ac 	.word	0xd00845ac
d0080b94:	d00845b4 	.word	0xd00845b4
d0080b98:	d00845bc 	.word	0xd00845bc
d0080b9c:	d00845c0 	.word	0xd00845c0
d0080ba0:	d00845cc 	.word	0xd00845cc
d0080ba4:	d00845e0 	.word	0xd00845e0
d0080ba8:	d00845f0 	.word	0xd00845f0
d0080bac:	d00845fc 	.word	0xd00845fc
d0080bb0:	d0084608 	.word	0xd0084608
d0080bb4:	d0084610 	.word	0xd0084610
d0080bb8:	d0084618 	.word	0xd0084618
d0080bbc:	f818 3001 	ldrb.w	r3, [r8, r1]
d0080bc0:	2b00      	cmp	r3, #0
d0080bc2:	f47f ac43 	bne.w	d008044c <emit_known_word.constprop.0+0xe0>
d0080bc6:	8823      	ldrh	r3, [r4, #0]
d0080bc8:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080bcc:	f4bf aed5 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080bd0:	4dc4      	ldr	r5, [pc, #784]	; (d0080ee4 <emit_known_word.constprop.0+0xb78>)
d0080bd2:	210e      	movs	r1, #14
d0080bd4:	2244      	movs	r2, #68	; 0x44
d0080bd6:	4ec4      	ldr	r6, [pc, #784]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080bd8:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0080bdc:	8823      	ldrh	r3, [r4, #0]
d0080bde:	4630      	mov	r0, r6
d0080be0:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080be4:	805a      	strh	r2, [r3, #2]
d0080be6:	8827      	ldrh	r7, [r4, #0]
d0080be8:	3701      	adds	r7, #1
d0080bea:	b2bf      	uxth	r7, r7
d0080bec:	8027      	strh	r7, [r4, #0]
d0080bee:	f003 fa28 	bl	d0084042 <strlen>
d0080bf2:	1d03      	adds	r3, r0, #4
d0080bf4:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080bf8:	d20e      	bcs.n	d0080c18 <emit_known_word.constprop.0+0x8ac>
d0080bfa:	b138      	cbz	r0, d0080c0c <emit_known_word.constprop.0+0x8a0>
d0080bfc:	2120      	movs	r1, #32
d0080bfe:	1833      	adds	r3, r6, r0
d0080c00:	2200      	movs	r2, #0
d0080c02:	5431      	strb	r1, [r6, r0]
d0080c04:	4630      	mov	r0, r6
d0080c06:	705a      	strb	r2, [r3, #1]
d0080c08:	f003 fa1b 	bl	d0084042 <strlen>
d0080c0c:	4430      	add	r0, r6
d0080c0e:	2203      	movs	r2, #3
d0080c10:	49b6      	ldr	r1, [pc, #728]	; (d0080eec <emit_known_word.constprop.0+0xb80>)
d0080c12:	f003 f879 	bl	d0083d08 <memcpy>
d0080c16:	8827      	ldrh	r7, [r4, #0]
d0080c18:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080c1c:	f4bf aead 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080c20:	2305      	movs	r3, #5
d0080c22:	227d      	movs	r2, #125	; 0x7d
d0080c24:	48b0      	ldr	r0, [pc, #704]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080c26:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080c2a:	8823      	ldrh	r3, [r4, #0]
d0080c2c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080c30:	805a      	strh	r2, [r3, #2]
d0080c32:	8827      	ldrh	r7, [r4, #0]
d0080c34:	3701      	adds	r7, #1
d0080c36:	b2bf      	uxth	r7, r7
d0080c38:	8027      	strh	r7, [r4, #0]
d0080c3a:	f003 fa02 	bl	d0084042 <strlen>
d0080c3e:	1d03      	adds	r3, r0, #4
d0080c40:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080c44:	d20e      	bcs.n	d0080c64 <emit_known_word.constprop.0+0x8f8>
d0080c46:	b138      	cbz	r0, d0080c58 <emit_known_word.constprop.0+0x8ec>
d0080c48:	2120      	movs	r1, #32
d0080c4a:	1833      	adds	r3, r6, r0
d0080c4c:	2200      	movs	r2, #0
d0080c4e:	5431      	strb	r1, [r6, r0]
d0080c50:	48a5      	ldr	r0, [pc, #660]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080c52:	705a      	strb	r2, [r3, #1]
d0080c54:	f003 f9f5 	bl	d0084042 <strlen>
d0080c58:	4430      	add	r0, r6
d0080c5a:	2203      	movs	r2, #3
d0080c5c:	49a4      	ldr	r1, [pc, #656]	; (d0080ef0 <emit_known_word.constprop.0+0xb84>)
d0080c5e:	f003 f853 	bl	d0083d08 <memcpy>
d0080c62:	8827      	ldrh	r7, [r4, #0]
d0080c64:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080c68:	f4bf ae87 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080c6c:	2319      	movs	r3, #25
d0080c6e:	2258      	movs	r2, #88	; 0x58
d0080c70:	489d      	ldr	r0, [pc, #628]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080c72:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080c76:	8823      	ldrh	r3, [r4, #0]
d0080c78:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0080c7c:	806a      	strh	r2, [r5, #2]
d0080c7e:	8823      	ldrh	r3, [r4, #0]
d0080c80:	3301      	adds	r3, #1
d0080c82:	8023      	strh	r3, [r4, #0]
d0080c84:	f003 f9dd 	bl	d0084042 <strlen>
d0080c88:	1cc2      	adds	r2, r0, #3
d0080c8a:	4603      	mov	r3, r0
d0080c8c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080c90:	f4bf ae73 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080c94:	b140      	cbz	r0, d0080ca8 <emit_known_word.constprop.0+0x93c>
d0080c96:	1832      	adds	r2, r6, r0
d0080c98:	2100      	movs	r1, #0
d0080c9a:	2420      	movs	r4, #32
d0080c9c:	4892      	ldr	r0, [pc, #584]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080c9e:	54f4      	strb	r4, [r6, r3]
d0080ca0:	7051      	strb	r1, [r2, #1]
d0080ca2:	f003 f9ce 	bl	d0084042 <strlen>
d0080ca6:	4603      	mov	r3, r0
d0080ca8:	18f0      	adds	r0, r6, r3
d0080caa:	2202      	movs	r2, #2
d0080cac:	4991      	ldr	r1, [pc, #580]	; (d0080ef4 <emit_known_word.constprop.0+0xb88>)
d0080cae:	f003 f82b 	bl	d0083d08 <memcpy>
d0080cb2:	2001      	movs	r0, #1
d0080cb4:	b003      	add	sp, #12
d0080cb6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0080cba:	f818 3001 	ldrb.w	r3, [r8, r1]
d0080cbe:	2b00      	cmp	r3, #0
d0080cc0:	d081      	beq.n	d0080bc6 <emit_known_word.constprop.0+0x85a>
d0080cc2:	f7ff bbdd 	b.w	d0080480 <emit_known_word.constprop.0+0x114>
d0080cc6:	f818 8001 	ldrb.w	r8, [r8, r1]
d0080cca:	f1b8 0f00 	cmp.w	r8, #0
d0080cce:	f47f ac0b 	bne.w	d00804e8 <emit_known_word.constprop.0+0x17c>
d0080cd2:	8823      	ldrh	r3, [r4, #0]
d0080cd4:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080cd8:	f4bf ae4f 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080cdc:	4d81      	ldr	r5, [pc, #516]	; (d0080ee4 <emit_known_word.constprop.0+0xb78>)
d0080cde:	f04f 0920 	mov.w	r9, #32
d0080ce2:	2246      	movs	r2, #70	; 0x46
d0080ce4:	4e80      	ldr	r6, [pc, #512]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080ce6:	f805 9023 	strb.w	r9, [r5, r3, lsl #2]
d0080cea:	8823      	ldrh	r3, [r4, #0]
d0080cec:	4630      	mov	r0, r6
d0080cee:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080cf2:	805a      	strh	r2, [r3, #2]
d0080cf4:	8827      	ldrh	r7, [r4, #0]
d0080cf6:	3701      	adds	r7, #1
d0080cf8:	b2bf      	uxth	r7, r7
d0080cfa:	8027      	strh	r7, [r4, #0]
d0080cfc:	f003 f9a1 	bl	d0084042 <strlen>
d0080d00:	1cc3      	adds	r3, r0, #3
d0080d02:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080d06:	d20e      	bcs.n	d0080d26 <emit_known_word.constprop.0+0x9ba>
d0080d08:	b138      	cbz	r0, d0080d1a <emit_known_word.constprop.0+0x9ae>
d0080d0a:	1833      	adds	r3, r6, r0
d0080d0c:	f806 9000 	strb.w	r9, [r6, r0]
d0080d10:	4630      	mov	r0, r6
d0080d12:	f883 8001 	strb.w	r8, [r3, #1]
d0080d16:	f003 f994 	bl	d0084042 <strlen>
d0080d1a:	4430      	add	r0, r6
d0080d1c:	2202      	movs	r2, #2
d0080d1e:	4976      	ldr	r1, [pc, #472]	; (d0080ef8 <emit_known_word.constprop.0+0xb8c>)
d0080d20:	f002 fff2 	bl	d0083d08 <memcpy>
d0080d24:	8827      	ldrh	r7, [r4, #0]
d0080d26:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080d2a:	f4bf ae26 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080d2e:	2306      	movs	r3, #6
d0080d30:	2287      	movs	r2, #135	; 0x87
d0080d32:	486d      	ldr	r0, [pc, #436]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080d34:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080d38:	8823      	ldrh	r3, [r4, #0]
d0080d3a:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0080d3e:	806a      	strh	r2, [r5, #2]
d0080d40:	8823      	ldrh	r3, [r4, #0]
d0080d42:	3301      	adds	r3, #1
d0080d44:	8023      	strh	r3, [r4, #0]
d0080d46:	f003 f97c 	bl	d0084042 <strlen>
d0080d4a:	1d02      	adds	r2, r0, #4
d0080d4c:	4603      	mov	r3, r0
d0080d4e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080d52:	f4bf ae12 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080d56:	b140      	cbz	r0, d0080d6a <emit_known_word.constprop.0+0x9fe>
d0080d58:	1832      	adds	r2, r6, r0
d0080d5a:	2100      	movs	r1, #0
d0080d5c:	2420      	movs	r4, #32
d0080d5e:	4862      	ldr	r0, [pc, #392]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080d60:	54f4      	strb	r4, [r6, r3]
d0080d62:	7051      	strb	r1, [r2, #1]
d0080d64:	f003 f96d 	bl	d0084042 <strlen>
d0080d68:	4603      	mov	r3, r0
d0080d6a:	18f0      	adds	r0, r6, r3
d0080d6c:	2203      	movs	r2, #3
d0080d6e:	4963      	ldr	r1, [pc, #396]	; (d0080efc <emit_known_word.constprop.0+0xb90>)
d0080d70:	f002 ffca 	bl	d0083d08 <memcpy>
d0080d74:	2001      	movs	r0, #1
d0080d76:	e601      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0080d78:	f818 3001 	ldrb.w	r3, [r8, r1]
d0080d7c:	2b00      	cmp	r3, #0
d0080d7e:	f47f abcd 	bne.w	d008051c <emit_known_word.constprop.0+0x1b0>
d0080d82:	8823      	ldrh	r3, [r4, #0]
d0080d84:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080d88:	f4bf adf7 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080d8c:	4d55      	ldr	r5, [pc, #340]	; (d0080ee4 <emit_known_word.constprop.0+0xb78>)
d0080d8e:	211c      	movs	r1, #28
d0080d90:	223a      	movs	r2, #58	; 0x3a
d0080d92:	4e55      	ldr	r6, [pc, #340]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080d94:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0080d98:	8823      	ldrh	r3, [r4, #0]
d0080d9a:	4630      	mov	r0, r6
d0080d9c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080da0:	805a      	strh	r2, [r3, #2]
d0080da2:	8827      	ldrh	r7, [r4, #0]
d0080da4:	3701      	adds	r7, #1
d0080da6:	b2bf      	uxth	r7, r7
d0080da8:	8027      	strh	r7, [r4, #0]
d0080daa:	f003 f94a 	bl	d0084042 <strlen>
d0080dae:	1cc3      	adds	r3, r0, #3
d0080db0:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080db4:	d20e      	bcs.n	d0080dd4 <emit_known_word.constprop.0+0xa68>
d0080db6:	b138      	cbz	r0, d0080dc8 <emit_known_word.constprop.0+0xa5c>
d0080db8:	2120      	movs	r1, #32
d0080dba:	1833      	adds	r3, r6, r0
d0080dbc:	2200      	movs	r2, #0
d0080dbe:	5431      	strb	r1, [r6, r0]
d0080dc0:	4630      	mov	r0, r6
d0080dc2:	705a      	strb	r2, [r3, #1]
d0080dc4:	f003 f93d 	bl	d0084042 <strlen>
d0080dc8:	4430      	add	r0, r6
d0080dca:	2202      	movs	r2, #2
d0080dcc:	494c      	ldr	r1, [pc, #304]	; (d0080f00 <emit_known_word.constprop.0+0xb94>)
d0080dce:	f002 ff9b 	bl	d0083d08 <memcpy>
d0080dd2:	8827      	ldrh	r7, [r4, #0]
d0080dd4:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080dd8:	f4bf adcf 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080ddc:	230a      	movs	r3, #10
d0080dde:	2287      	movs	r2, #135	; 0x87
d0080de0:	4841      	ldr	r0, [pc, #260]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080de2:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080de6:	8823      	ldrh	r3, [r4, #0]
d0080de8:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0080dec:	806a      	strh	r2, [r5, #2]
d0080dee:	8823      	ldrh	r3, [r4, #0]
d0080df0:	3301      	adds	r3, #1
d0080df2:	8023      	strh	r3, [r4, #0]
d0080df4:	f003 f925 	bl	d0084042 <strlen>
d0080df8:	1d02      	adds	r2, r0, #4
d0080dfa:	4603      	mov	r3, r0
d0080dfc:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080e00:	f4bf adbb 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080e04:	b140      	cbz	r0, d0080e18 <emit_known_word.constprop.0+0xaac>
d0080e06:	1832      	adds	r2, r6, r0
d0080e08:	2100      	movs	r1, #0
d0080e0a:	2420      	movs	r4, #32
d0080e0c:	4836      	ldr	r0, [pc, #216]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080e0e:	54f4      	strb	r4, [r6, r3]
d0080e10:	7051      	strb	r1, [r2, #1]
d0080e12:	f003 f916 	bl	d0084042 <strlen>
d0080e16:	4603      	mov	r3, r0
d0080e18:	18f0      	adds	r0, r6, r3
d0080e1a:	2203      	movs	r2, #3
d0080e1c:	4939      	ldr	r1, [pc, #228]	; (d0080f04 <emit_known_word.constprop.0+0xb98>)
d0080e1e:	f002 ff73 	bl	d0083d08 <memcpy>
d0080e22:	2001      	movs	r0, #1
d0080e24:	e5aa      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0080e26:	1832      	adds	r2, r6, r0
d0080e28:	2120      	movs	r1, #32
d0080e2a:	4630      	mov	r0, r6
d0080e2c:	54f1      	strb	r1, [r6, r3]
d0080e2e:	f882 8001 	strb.w	r8, [r2, #1]
d0080e32:	f003 f906 	bl	d0084042 <strlen>
d0080e36:	4603      	mov	r3, r0
d0080e38:	e567      	b.n	d008090a <emit_known_word.constprop.0+0x59e>
d0080e3a:	4d2a      	ldr	r5, [pc, #168]	; (d0080ee4 <emit_known_word.constprop.0+0xb78>)
d0080e3c:	f04f 0920 	mov.w	r9, #32
d0080e40:	2246      	movs	r2, #70	; 0x46
d0080e42:	4e29      	ldr	r6, [pc, #164]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080e44:	f805 9023 	strb.w	r9, [r5, r3, lsl #2]
d0080e48:	8823      	ldrh	r3, [r4, #0]
d0080e4a:	4630      	mov	r0, r6
d0080e4c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080e50:	805a      	strh	r2, [r3, #2]
d0080e52:	8827      	ldrh	r7, [r4, #0]
d0080e54:	3701      	adds	r7, #1
d0080e56:	b2bf      	uxth	r7, r7
d0080e58:	8027      	strh	r7, [r4, #0]
d0080e5a:	f003 f8f2 	bl	d0084042 <strlen>
d0080e5e:	1cc3      	adds	r3, r0, #3
d0080e60:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080e64:	d2b6      	bcs.n	d0080dd4 <emit_known_word.constprop.0+0xa68>
d0080e66:	b138      	cbz	r0, d0080e78 <emit_known_word.constprop.0+0xb0c>
d0080e68:	1833      	adds	r3, r6, r0
d0080e6a:	f806 9000 	strb.w	r9, [r6, r0]
d0080e6e:	4630      	mov	r0, r6
d0080e70:	f883 8001 	strb.w	r8, [r3, #1]
d0080e74:	f003 f8e5 	bl	d0084042 <strlen>
d0080e78:	4430      	add	r0, r6
d0080e7a:	2202      	movs	r2, #2
d0080e7c:	491e      	ldr	r1, [pc, #120]	; (d0080ef8 <emit_known_word.constprop.0+0xb8c>)
d0080e7e:	f002 ff43 	bl	d0083d08 <memcpy>
d0080e82:	8827      	ldrh	r7, [r4, #0]
d0080e84:	e7a6      	b.n	d0080dd4 <emit_known_word.constprop.0+0xa68>
d0080e86:	2120      	movs	r1, #32
d0080e88:	1833      	adds	r3, r6, r0
d0080e8a:	2200      	movs	r2, #0
d0080e8c:	5431      	strb	r1, [r6, r0]
d0080e8e:	4816      	ldr	r0, [pc, #88]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080e90:	705a      	strb	r2, [r3, #1]
d0080e92:	f003 f8d6 	bl	d0084042 <strlen>
d0080e96:	e5b6      	b.n	d0080a06 <emit_known_word.constprop.0+0x69a>
d0080e98:	1832      	adds	r2, r6, r0
d0080e9a:	2120      	movs	r1, #32
d0080e9c:	4630      	mov	r0, r6
d0080e9e:	54f1      	strb	r1, [r6, r3]
d0080ea0:	f882 8001 	strb.w	r8, [r2, #1]
d0080ea4:	f003 f8cd 	bl	d0084042 <strlen>
d0080ea8:	4603      	mov	r3, r0
d0080eaa:	e58d      	b.n	d00809c8 <emit_known_word.constprop.0+0x65c>
d0080eac:	1832      	adds	r2, r6, r0
d0080eae:	2120      	movs	r1, #32
d0080eb0:	4630      	mov	r0, r6
d0080eb2:	54f1      	strb	r1, [r6, r3]
d0080eb4:	f882 8001 	strb.w	r8, [r2, #1]
d0080eb8:	f003 f8c3 	bl	d0084042 <strlen>
d0080ebc:	4603      	mov	r3, r0
d0080ebe:	e5f2      	b.n	d0080aa6 <emit_known_word.constprop.0+0x73a>
d0080ec0:	2120      	movs	r1, #32
d0080ec2:	1833      	adds	r3, r6, r0
d0080ec4:	2200      	movs	r2, #0
d0080ec6:	5431      	strb	r1, [r6, r0]
d0080ec8:	4807      	ldr	r0, [pc, #28]	; (d0080ee8 <emit_known_word.constprop.0+0xb7c>)
d0080eca:	705a      	strb	r2, [r3, #1]
d0080ecc:	f003 f8b9 	bl	d0084042 <strlen>
d0080ed0:	e609      	b.n	d0080ae6 <emit_known_word.constprop.0+0x77a>
d0080ed2:	f818 3001 	ldrb.w	r3, [r8, r1]
d0080ed6:	2b00      	cmp	r3, #0
d0080ed8:	f43f af53 	beq.w	d0080d82 <emit_known_word.constprop.0+0xa16>
d0080edc:	f7ff bb38 	b.w	d0080550 <emit_known_word.constprop.0+0x1e4>
d0080ee0:	4608      	mov	r0, r1
d0080ee2:	4770      	bx	lr
d0080ee4:	d0084b28 	.word	0xd0084b28
d0080ee8:	d00b4540 	.word	0xd00b4540
d0080eec:	d008454c 	.word	0xd008454c
d0080ef0:	d008453c 	.word	0xd008453c
d0080ef4:	d0084584 	.word	0xd0084584
d0080ef8:	d008458c 	.word	0xd008458c
d0080efc:	d008459c 	.word	0xd008459c
d0080f00:	d0084570 	.word	0xd0084570
d0080f04:	d0084590 	.word	0xd0084590
d0080f08:	4299      	cmp	r1, r3
d0080f0a:	f47f ab43 	bne.w	d0080594 <emit_known_word.constprop.0+0x228>
d0080f0e:	f81b 3001 	ldrb.w	r3, [fp, r1]
d0080f12:	2b00      	cmp	r3, #0
d0080f14:	f43f af35 	beq.w	d0080d82 <emit_known_word.constprop.0+0xa16>
d0080f18:	f7ff bb3c 	b.w	d0080594 <emit_known_word.constprop.0+0x228>
d0080f1c:	4299      	cmp	r1, r3
d0080f1e:	f47f ab59 	bne.w	d00805d4 <emit_known_word.constprop.0+0x268>
d0080f22:	f81b 8001 	ldrb.w	r8, [fp, r1]
d0080f26:	f1b8 0f00 	cmp.w	r8, #0
d0080f2a:	f47f ab53 	bne.w	d00805d4 <emit_known_word.constprop.0+0x268>
d0080f2e:	8823      	ldrh	r3, [r4, #0]
d0080f30:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080f34:	f4bf ad21 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080f38:	2101      	movs	r1, #1
d0080f3a:	4dc6      	ldr	r5, [pc, #792]	; (d0081254 <emit_known_word.constprop.0+0xee8>)
d0080f3c:	2278      	movs	r2, #120	; 0x78
d0080f3e:	4ec6      	ldr	r6, [pc, #792]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0080f40:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0080f44:	8823      	ldrh	r3, [r4, #0]
d0080f46:	4630      	mov	r0, r6
d0080f48:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0080f4c:	805a      	strh	r2, [r3, #2]
d0080f4e:	8827      	ldrh	r7, [r4, #0]
d0080f50:	440f      	add	r7, r1
d0080f52:	b2bf      	uxth	r7, r7
d0080f54:	8027      	strh	r7, [r4, #0]
d0080f56:	f003 f874 	bl	d0084042 <strlen>
d0080f5a:	1d02      	adds	r2, r0, #4
d0080f5c:	4603      	mov	r3, r0
d0080f5e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080f62:	d20f      	bcs.n	d0080f84 <emit_known_word.constprop.0+0xc18>
d0080f64:	b140      	cbz	r0, d0080f78 <emit_known_word.constprop.0+0xc0c>
d0080f66:	1832      	adds	r2, r6, r0
d0080f68:	2120      	movs	r1, #32
d0080f6a:	4630      	mov	r0, r6
d0080f6c:	54f1      	strb	r1, [r6, r3]
d0080f6e:	f882 8001 	strb.w	r8, [r2, #1]
d0080f72:	f003 f866 	bl	d0084042 <strlen>
d0080f76:	4603      	mov	r3, r0
d0080f78:	18f0      	adds	r0, r6, r3
d0080f7a:	2203      	movs	r2, #3
d0080f7c:	49b7      	ldr	r1, [pc, #732]	; (d008125c <emit_known_word.constprop.0+0xef0>)
d0080f7e:	f002 fec3 	bl	d0083d08 <memcpy>
d0080f82:	8827      	ldrh	r7, [r4, #0]
d0080f84:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0080f88:	f4bf acf7 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080f8c:	231e      	movs	r3, #30
d0080f8e:	2248      	movs	r2, #72	; 0x48
d0080f90:	48b1      	ldr	r0, [pc, #708]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0080f92:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0080f96:	8823      	ldrh	r3, [r4, #0]
d0080f98:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0080f9c:	806a      	strh	r2, [r5, #2]
d0080f9e:	8823      	ldrh	r3, [r4, #0]
d0080fa0:	3301      	adds	r3, #1
d0080fa2:	8023      	strh	r3, [r4, #0]
d0080fa4:	f003 f84d 	bl	d0084042 <strlen>
d0080fa8:	1cc2      	adds	r2, r0, #3
d0080faa:	4603      	mov	r3, r0
d0080fac:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080fb0:	f4bf ace3 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080fb4:	b140      	cbz	r0, d0080fc8 <emit_known_word.constprop.0+0xc5c>
d0080fb6:	1832      	adds	r2, r6, r0
d0080fb8:	2100      	movs	r1, #0
d0080fba:	2420      	movs	r4, #32
d0080fbc:	48a6      	ldr	r0, [pc, #664]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0080fbe:	54f4      	strb	r4, [r6, r3]
d0080fc0:	7051      	strb	r1, [r2, #1]
d0080fc2:	f003 f83e 	bl	d0084042 <strlen>
d0080fc6:	4603      	mov	r3, r0
d0080fc8:	18f0      	adds	r0, r6, r3
d0080fca:	2202      	movs	r2, #2
d0080fcc:	49a4      	ldr	r1, [pc, #656]	; (d0081260 <emit_known_word.constprop.0+0xef4>)
d0080fce:	f002 fe9b 	bl	d0083d08 <memcpy>
d0080fd2:	2001      	movs	r0, #1
d0080fd4:	e4d2      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0080fd6:	4299      	cmp	r1, r3
d0080fd8:	f47f ab1c 	bne.w	d0080614 <emit_known_word.constprop.0+0x2a8>
d0080fdc:	f81b 8001 	ldrb.w	r8, [fp, r1]
d0080fe0:	f1b8 0f00 	cmp.w	r8, #0
d0080fe4:	f47f ab16 	bne.w	d0080614 <emit_known_word.constprop.0+0x2a8>
d0080fe8:	8823      	ldrh	r3, [r4, #0]
d0080fea:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080fee:	f4bf acc4 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0080ff2:	4d98      	ldr	r5, [pc, #608]	; (d0081254 <emit_known_word.constprop.0+0xee8>)
d0080ff4:	2107      	movs	r1, #7
d0080ff6:	226e      	movs	r2, #110	; 0x6e
d0080ff8:	4e97      	ldr	r6, [pc, #604]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0080ffa:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0080ffe:	8823      	ldrh	r3, [r4, #0]
d0081000:	4630      	mov	r0, r6
d0081002:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081006:	805a      	strh	r2, [r3, #2]
d0081008:	8827      	ldrh	r7, [r4, #0]
d008100a:	3701      	adds	r7, #1
d008100c:	b2bf      	uxth	r7, r7
d008100e:	8027      	strh	r7, [r4, #0]
d0081010:	f003 f817 	bl	d0084042 <strlen>
d0081014:	1d02      	adds	r2, r0, #4
d0081016:	4603      	mov	r3, r0
d0081018:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008101c:	d20f      	bcs.n	d008103e <emit_known_word.constprop.0+0xcd2>
d008101e:	b140      	cbz	r0, d0081032 <emit_known_word.constprop.0+0xcc6>
d0081020:	1832      	adds	r2, r6, r0
d0081022:	2120      	movs	r1, #32
d0081024:	4630      	mov	r0, r6
d0081026:	54f1      	strb	r1, [r6, r3]
d0081028:	f882 8001 	strb.w	r8, [r2, #1]
d008102c:	f003 f809 	bl	d0084042 <strlen>
d0081030:	4603      	mov	r3, r0
d0081032:	18f0      	adds	r0, r6, r3
d0081034:	2203      	movs	r2, #3
d0081036:	498b      	ldr	r1, [pc, #556]	; (d0081264 <emit_known_word.constprop.0+0xef8>)
d0081038:	f002 fe66 	bl	d0083d08 <memcpy>
d008103c:	8827      	ldrh	r7, [r4, #0]
d008103e:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d0081042:	f4bf ac9a 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081046:	2321      	movs	r3, #33	; 0x21
d0081048:	2252      	movs	r2, #82	; 0x52
d008104a:	4883      	ldr	r0, [pc, #524]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d008104c:	f805 3027 	strb.w	r3, [r5, r7, lsl #2]
d0081050:	8823      	ldrh	r3, [r4, #0]
d0081052:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0081056:	806a      	strh	r2, [r5, #2]
d0081058:	8823      	ldrh	r3, [r4, #0]
d008105a:	3301      	adds	r3, #1
d008105c:	8023      	strh	r3, [r4, #0]
d008105e:	f002 fff0 	bl	d0084042 <strlen>
d0081062:	1cc2      	adds	r2, r0, #3
d0081064:	4603      	mov	r3, r0
d0081066:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008106a:	f4bf ac86 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008106e:	b140      	cbz	r0, d0081082 <emit_known_word.constprop.0+0xd16>
d0081070:	1832      	adds	r2, r6, r0
d0081072:	2100      	movs	r1, #0
d0081074:	2420      	movs	r4, #32
d0081076:	4878      	ldr	r0, [pc, #480]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0081078:	54f4      	strb	r4, [r6, r3]
d008107a:	7051      	strb	r1, [r2, #1]
d008107c:	f002 ffe1 	bl	d0084042 <strlen>
d0081080:	4603      	mov	r3, r0
d0081082:	18f0      	adds	r0, r6, r3
d0081084:	2202      	movs	r2, #2
d0081086:	4978      	ldr	r1, [pc, #480]	; (d0081268 <emit_known_word.constprop.0+0xefc>)
d0081088:	f002 fe3e 	bl	d0083d08 <memcpy>
d008108c:	2001      	movs	r0, #1
d008108e:	e475      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d0081090:	4299      	cmp	r1, r3
d0081092:	f47f aadf 	bne.w	d0080654 <emit_known_word.constprop.0+0x2e8>
d0081096:	f81b 8001 	ldrb.w	r8, [fp, r1]
d008109a:	f1b8 0f00 	cmp.w	r8, #0
d008109e:	f47f aad9 	bne.w	d0080654 <emit_known_word.constprop.0+0x2e8>
d00810a2:	8823      	ldrh	r3, [r4, #0]
d00810a4:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00810a8:	f4bf ac67 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00810ac:	4d69      	ldr	r5, [pc, #420]	; (d0081254 <emit_known_word.constprop.0+0xee8>)
d00810ae:	2103      	movs	r1, #3
d00810b0:	228c      	movs	r2, #140	; 0x8c
d00810b2:	4e69      	ldr	r6, [pc, #420]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d00810b4:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00810b8:	8823      	ldrh	r3, [r4, #0]
d00810ba:	4630      	mov	r0, r6
d00810bc:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00810c0:	805a      	strh	r2, [r3, #2]
d00810c2:	8827      	ldrh	r7, [r4, #0]
d00810c4:	3701      	adds	r7, #1
d00810c6:	b2bf      	uxth	r7, r7
d00810c8:	8027      	strh	r7, [r4, #0]
d00810ca:	f002 ffba 	bl	d0084042 <strlen>
d00810ce:	1d02      	adds	r2, r0, #4
d00810d0:	4603      	mov	r3, r0
d00810d2:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00810d6:	f4bf adc5 	bcs.w	d0080c64 <emit_known_word.constprop.0+0x8f8>
d00810da:	b140      	cbz	r0, d00810ee <emit_known_word.constprop.0+0xd82>
d00810dc:	1832      	adds	r2, r6, r0
d00810de:	2120      	movs	r1, #32
d00810e0:	4630      	mov	r0, r6
d00810e2:	54f1      	strb	r1, [r6, r3]
d00810e4:	f882 8001 	strb.w	r8, [r2, #1]
d00810e8:	f002 ffab 	bl	d0084042 <strlen>
d00810ec:	4603      	mov	r3, r0
d00810ee:	18f0      	adds	r0, r6, r3
d00810f0:	2203      	movs	r2, #3
d00810f2:	495e      	ldr	r1, [pc, #376]	; (d008126c <emit_known_word.constprop.0+0xf00>)
d00810f4:	f002 fe08 	bl	d0083d08 <memcpy>
d00810f8:	8827      	ldrh	r7, [r4, #0]
d00810fa:	e5b3      	b.n	d0080c64 <emit_known_word.constprop.0+0x8f8>
d00810fc:	4620      	mov	r0, r4
d00810fe:	9101      	str	r1, [sp, #4]
d0081100:	f7ff f8da 	bl	d00802b8 <emit_ay.constprop.0>
d0081104:	9901      	ldr	r1, [sp, #4]
d0081106:	4608      	mov	r0, r1
d0081108:	e438      	b.n	d008097c <emit_known_word.constprop.0+0x610>
d008110a:	4299      	cmp	r1, r3
d008110c:	f47f aadb 	bne.w	d00806c6 <emit_known_word.constprop.0+0x35a>
d0081110:	f81b 7001 	ldrb.w	r7, [fp, r1]
d0081114:	2f00      	cmp	r7, #0
d0081116:	f47f aad6 	bne.w	d00806c6 <emit_known_word.constprop.0+0x35a>
d008111a:	8823      	ldrh	r3, [r4, #0]
d008111c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081120:	f4bf ac2b 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081124:	4d4b      	ldr	r5, [pc, #300]	; (d0081254 <emit_known_word.constprop.0+0xee8>)
d0081126:	2102      	movs	r1, #2
d0081128:	2282      	movs	r2, #130	; 0x82
d008112a:	4e4b      	ldr	r6, [pc, #300]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d008112c:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081130:	8823      	ldrh	r3, [r4, #0]
d0081132:	4630      	mov	r0, r6
d0081134:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081138:	805a      	strh	r2, [r3, #2]
d008113a:	8823      	ldrh	r3, [r4, #0]
d008113c:	3301      	adds	r3, #1
d008113e:	8023      	strh	r3, [r4, #0]
d0081140:	f002 ff7f 	bl	d0084042 <strlen>
d0081144:	1d03      	adds	r3, r0, #4
d0081146:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008114a:	d20c      	bcs.n	d0081166 <emit_known_word.constprop.0+0xdfa>
d008114c:	b118      	cbz	r0, d0081156 <emit_known_word.constprop.0+0xdea>
d008114e:	2220      	movs	r2, #32
d0081150:	1833      	adds	r3, r6, r0
d0081152:	5432      	strb	r2, [r6, r0]
d0081154:	705f      	strb	r7, [r3, #1]
d0081156:	4840      	ldr	r0, [pc, #256]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0081158:	f002 ff73 	bl	d0084042 <strlen>
d008115c:	2203      	movs	r2, #3
d008115e:	4944      	ldr	r1, [pc, #272]	; (d0081270 <emit_known_word.constprop.0+0xf04>)
d0081160:	4430      	add	r0, r6
d0081162:	f002 fdd1 	bl	d0083d08 <memcpy>
d0081166:	8823      	ldrh	r3, [r4, #0]
d0081168:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008116c:	f4bf ac05 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081170:	2116      	movs	r1, #22
d0081172:	224b      	movs	r2, #75	; 0x4b
d0081174:	4838      	ldr	r0, [pc, #224]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0081176:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d008117a:	8823      	ldrh	r3, [r4, #0]
d008117c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081180:	805a      	strh	r2, [r3, #2]
d0081182:	8823      	ldrh	r3, [r4, #0]
d0081184:	3301      	adds	r3, #1
d0081186:	8023      	strh	r3, [r4, #0]
d0081188:	f002 ff5b 	bl	d0084042 <strlen>
d008118c:	1cc3      	adds	r3, r0, #3
d008118e:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081192:	d20d      	bcs.n	d00811b0 <emit_known_word.constprop.0+0xe44>
d0081194:	b120      	cbz	r0, d00811a0 <emit_known_word.constprop.0+0xe34>
d0081196:	2120      	movs	r1, #32
d0081198:	1833      	adds	r3, r6, r0
d008119a:	2200      	movs	r2, #0
d008119c:	5431      	strb	r1, [r6, r0]
d008119e:	705a      	strb	r2, [r3, #1]
d00811a0:	482d      	ldr	r0, [pc, #180]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d00811a2:	f002 ff4e 	bl	d0084042 <strlen>
d00811a6:	2202      	movs	r2, #2
d00811a8:	4932      	ldr	r1, [pc, #200]	; (d0081274 <emit_known_word.constprop.0+0xf08>)
d00811aa:	4430      	add	r0, r6
d00811ac:	f002 fdac 	bl	d0083d08 <memcpy>
d00811b0:	8823      	ldrh	r3, [r4, #0]
d00811b2:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00811b6:	f4bf abe0 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00811ba:	210d      	movs	r1, #13
d00811bc:	223a      	movs	r2, #58	; 0x3a
d00811be:	4826      	ldr	r0, [pc, #152]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d00811c0:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00811c4:	8823      	ldrh	r3, [r4, #0]
d00811c6:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d00811ca:	806a      	strh	r2, [r5, #2]
d00811cc:	8823      	ldrh	r3, [r4, #0]
d00811ce:	3301      	adds	r3, #1
d00811d0:	8023      	strh	r3, [r4, #0]
d00811d2:	f002 ff36 	bl	d0084042 <strlen>
d00811d6:	1cc3      	adds	r3, r0, #3
d00811d8:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00811dc:	f4bf abcd 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00811e0:	b120      	cbz	r0, d00811ec <emit_known_word.constprop.0+0xe80>
d00811e2:	2120      	movs	r1, #32
d00811e4:	1833      	adds	r3, r6, r0
d00811e6:	2200      	movs	r2, #0
d00811e8:	5431      	strb	r1, [r6, r0]
d00811ea:	705a      	strb	r2, [r3, #1]
d00811ec:	481a      	ldr	r0, [pc, #104]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d00811ee:	f002 ff28 	bl	d0084042 <strlen>
d00811f2:	2202      	movs	r2, #2
d00811f4:	4920      	ldr	r1, [pc, #128]	; (d0081278 <emit_known_word.constprop.0+0xf0c>)
d00811f6:	4430      	add	r0, r6
d00811f8:	f002 fd86 	bl	d0083d08 <memcpy>
d00811fc:	2001      	movs	r0, #1
d00811fe:	f7ff bbbd 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d0081202:	8822      	ldrh	r2, [r4, #0]
d0081204:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0081208:	f4bf abb7 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008120c:	4b11      	ldr	r3, [pc, #68]	; (d0081254 <emit_known_word.constprop.0+0xee8>)
d008120e:	2578      	movs	r5, #120	; 0x78
d0081210:	4e11      	ldr	r6, [pc, #68]	; (d0081258 <emit_known_word.constprop.0+0xeec>)
d0081212:	f803 1022 	strb.w	r1, [r3, r2, lsl #2]
d0081216:	8822      	ldrh	r2, [r4, #0]
d0081218:	4630      	mov	r0, r6
d008121a:	eb03 0382 	add.w	r3, r3, r2, lsl #2
d008121e:	805d      	strh	r5, [r3, #2]
d0081220:	8823      	ldrh	r3, [r4, #0]
d0081222:	3301      	adds	r3, #1
d0081224:	8023      	strh	r3, [r4, #0]
d0081226:	f002 ff0c 	bl	d0084042 <strlen>
d008122a:	1d02      	adds	r2, r0, #4
d008122c:	4603      	mov	r3, r0
d008122e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0081232:	f4bf aba2 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081236:	2800      	cmp	r0, #0
d0081238:	f43f ab8d 	beq.w	d0080956 <emit_known_word.constprop.0+0x5ea>
d008123c:	1832      	adds	r2, r6, r0
d008123e:	2100      	movs	r1, #0
d0081240:	2420      	movs	r4, #32
d0081242:	4630      	mov	r0, r6
d0081244:	54f4      	strb	r4, [r6, r3]
d0081246:	7051      	strb	r1, [r2, #1]
d0081248:	f002 fefb 	bl	d0084042 <strlen>
d008124c:	4603      	mov	r3, r0
d008124e:	f7ff bb82 	b.w	d0080956 <emit_known_word.constprop.0+0x5ea>
d0081252:	bf00      	nop
d0081254:	d0084b28 	.word	0xd0084b28
d0081258:	d00b4540 	.word	0xd00b4540
d008125c:	d0084550 	.word	0xd0084550
d0081260:	d00845b0 	.word	0xd00845b0
d0081264:	d008455c 	.word	0xd008455c
d0081268:	d00845b8 	.word	0xd00845b8
d008126c:	d0084544 	.word	0xd0084544
d0081270:	d008456c 	.word	0xd008456c
d0081274:	d00845c4 	.word	0xd00845c4
d0081278:	d00845c8 	.word	0xd00845c8
d008127c:	4299      	cmp	r1, r3
d008127e:	f47f aa42 	bne.w	d0080706 <emit_known_word.constprop.0+0x39a>
d0081282:	f81b 7001 	ldrb.w	r7, [fp, r1]
d0081286:	2f00      	cmp	r7, #0
d0081288:	f47f aa3d 	bne.w	d0080706 <emit_known_word.constprop.0+0x39a>
d008128c:	8823      	ldrh	r3, [r4, #0]
d008128e:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081292:	f4bf ab72 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081296:	4dbf      	ldr	r5, [pc, #764]	; (d0081594 <emit_known_word.constprop.0+0x1228>)
d0081298:	2111      	movs	r1, #17
d008129a:	2237      	movs	r2, #55	; 0x37
d008129c:	4ebe      	ldr	r6, [pc, #760]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d008129e:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00812a2:	8823      	ldrh	r3, [r4, #0]
d00812a4:	4630      	mov	r0, r6
d00812a6:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00812aa:	805a      	strh	r2, [r3, #2]
d00812ac:	8823      	ldrh	r3, [r4, #0]
d00812ae:	3301      	adds	r3, #1
d00812b0:	8023      	strh	r3, [r4, #0]
d00812b2:	f002 fec6 	bl	d0084042 <strlen>
d00812b6:	1cc3      	adds	r3, r0, #3
d00812b8:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00812bc:	d20c      	bcs.n	d00812d8 <emit_known_word.constprop.0+0xf6c>
d00812be:	b118      	cbz	r0, d00812c8 <emit_known_word.constprop.0+0xf5c>
d00812c0:	2220      	movs	r2, #32
d00812c2:	1833      	adds	r3, r6, r0
d00812c4:	5432      	strb	r2, [r6, r0]
d00812c6:	705f      	strb	r7, [r3, #1]
d00812c8:	48b3      	ldr	r0, [pc, #716]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00812ca:	f002 feba 	bl	d0084042 <strlen>
d00812ce:	2202      	movs	r2, #2
d00812d0:	49b2      	ldr	r1, [pc, #712]	; (d008159c <emit_known_word.constprop.0+0x1230>)
d00812d2:	4430      	add	r0, r6
d00812d4:	f002 fd18 	bl	d0083d08 <memcpy>
d00812d8:	8823      	ldrh	r3, [r4, #0]
d00812da:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00812de:	f4bf ab4c 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00812e2:	2105      	movs	r1, #5
d00812e4:	227d      	movs	r2, #125	; 0x7d
d00812e6:	48ac      	ldr	r0, [pc, #688]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00812e8:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00812ec:	8823      	ldrh	r3, [r4, #0]
d00812ee:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00812f2:	805a      	strh	r2, [r3, #2]
d00812f4:	8823      	ldrh	r3, [r4, #0]
d00812f6:	3301      	adds	r3, #1
d00812f8:	8023      	strh	r3, [r4, #0]
d00812fa:	f002 fea2 	bl	d0084042 <strlen>
d00812fe:	1d03      	adds	r3, r0, #4
d0081300:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081304:	d20d      	bcs.n	d0081322 <emit_known_word.constprop.0+0xfb6>
d0081306:	b120      	cbz	r0, d0081312 <emit_known_word.constprop.0+0xfa6>
d0081308:	2120      	movs	r1, #32
d008130a:	1833      	adds	r3, r6, r0
d008130c:	2200      	movs	r2, #0
d008130e:	5431      	strb	r1, [r6, r0]
d0081310:	705a      	strb	r2, [r3, #1]
d0081312:	48a1      	ldr	r0, [pc, #644]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081314:	f002 fe95 	bl	d0084042 <strlen>
d0081318:	2203      	movs	r2, #3
d008131a:	49a1      	ldr	r1, [pc, #644]	; (d00815a0 <emit_known_word.constprop.0+0x1234>)
d008131c:	4430      	add	r0, r6
d008131e:	f002 fcf3 	bl	d0083d08 <memcpy>
d0081322:	8823      	ldrh	r3, [r4, #0]
d0081324:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081328:	f4bf ab27 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008132c:	2114      	movs	r1, #20
d008132e:	224e      	movs	r2, #78	; 0x4e
d0081330:	4899      	ldr	r0, [pc, #612]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081332:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081336:	8823      	ldrh	r3, [r4, #0]
d0081338:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d008133c:	805a      	strh	r2, [r3, #2]
d008133e:	8823      	ldrh	r3, [r4, #0]
d0081340:	3301      	adds	r3, #1
d0081342:	8023      	strh	r3, [r4, #0]
d0081344:	f002 fe7d 	bl	d0084042 <strlen>
d0081348:	1cc3      	adds	r3, r0, #3
d008134a:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008134e:	d20d      	bcs.n	d008136c <emit_known_word.constprop.0+0x1000>
d0081350:	b120      	cbz	r0, d008135c <emit_known_word.constprop.0+0xff0>
d0081352:	2120      	movs	r1, #32
d0081354:	1833      	adds	r3, r6, r0
d0081356:	2200      	movs	r2, #0
d0081358:	5431      	strb	r1, [r6, r0]
d008135a:	705a      	strb	r2, [r3, #1]
d008135c:	488e      	ldr	r0, [pc, #568]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d008135e:	f002 fe70 	bl	d0084042 <strlen>
d0081362:	2202      	movs	r2, #2
d0081364:	498f      	ldr	r1, [pc, #572]	; (d00815a4 <emit_known_word.constprop.0+0x1238>)
d0081366:	4430      	add	r0, r6
d0081368:	f002 fcce 	bl	d0083d08 <memcpy>
d008136c:	8823      	ldrh	r3, [r4, #0]
d008136e:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081372:	f4bf ab02 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081376:	2104      	movs	r1, #4
d0081378:	2248      	movs	r2, #72	; 0x48
d008137a:	4887      	ldr	r0, [pc, #540]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d008137c:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081380:	8823      	ldrh	r3, [r4, #0]
d0081382:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081386:	805a      	strh	r2, [r3, #2]
d0081388:	8823      	ldrh	r3, [r4, #0]
d008138a:	3301      	adds	r3, #1
d008138c:	8023      	strh	r3, [r4, #0]
d008138e:	f002 fe58 	bl	d0084042 <strlen>
d0081392:	1d03      	adds	r3, r0, #4
d0081394:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081398:	d20d      	bcs.n	d00813b6 <emit_known_word.constprop.0+0x104a>
d008139a:	b120      	cbz	r0, d00813a6 <emit_known_word.constprop.0+0x103a>
d008139c:	2120      	movs	r1, #32
d008139e:	1833      	adds	r3, r6, r0
d00813a0:	2200      	movs	r2, #0
d00813a2:	5431      	strb	r1, [r6, r0]
d00813a4:	705a      	strb	r2, [r3, #1]
d00813a6:	487c      	ldr	r0, [pc, #496]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00813a8:	f002 fe4b 	bl	d0084042 <strlen>
d00813ac:	2203      	movs	r2, #3
d00813ae:	497e      	ldr	r1, [pc, #504]	; (d00815a8 <emit_known_word.constprop.0+0x123c>)
d00813b0:	4430      	add	r0, r6
d00813b2:	f002 fca9 	bl	d0083d08 <memcpy>
d00813b6:	8823      	ldrh	r3, [r4, #0]
d00813b8:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00813bc:	f4bf aadd 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00813c0:	210a      	movs	r1, #10
d00813c2:	2252      	movs	r2, #82	; 0x52
d00813c4:	4874      	ldr	r0, [pc, #464]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00813c6:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00813ca:	8823      	ldrh	r3, [r4, #0]
d00813cc:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d00813d0:	806a      	strh	r2, [r5, #2]
d00813d2:	8823      	ldrh	r3, [r4, #0]
d00813d4:	3301      	adds	r3, #1
d00813d6:	8023      	strh	r3, [r4, #0]
d00813d8:	f002 fe33 	bl	d0084042 <strlen>
d00813dc:	1d03      	adds	r3, r0, #4
d00813de:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00813e2:	f4bf aaca 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00813e6:	b120      	cbz	r0, d00813f2 <emit_known_word.constprop.0+0x1086>
d00813e8:	2120      	movs	r1, #32
d00813ea:	1833      	adds	r3, r6, r0
d00813ec:	2200      	movs	r2, #0
d00813ee:	5431      	strb	r1, [r6, r0]
d00813f0:	705a      	strb	r2, [r3, #1]
d00813f2:	4869      	ldr	r0, [pc, #420]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00813f4:	f002 fe25 	bl	d0084042 <strlen>
d00813f8:	2203      	movs	r2, #3
d00813fa:	496c      	ldr	r1, [pc, #432]	; (d00815ac <emit_known_word.constprop.0+0x1240>)
d00813fc:	4430      	add	r0, r6
d00813fe:	f002 fc83 	bl	d0083d08 <memcpy>
d0081402:	2001      	movs	r0, #1
d0081404:	f7ff baba 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d0081408:	4299      	cmp	r1, r3
d008140a:	f47f a99c 	bne.w	d0080746 <emit_known_word.constprop.0+0x3da>
d008140e:	f81b 7001 	ldrb.w	r7, [fp, r1]
d0081412:	2f00      	cmp	r7, #0
d0081414:	f47f a997 	bne.w	d0080746 <emit_known_word.constprop.0+0x3da>
d0081418:	8823      	ldrh	r3, [r4, #0]
d008141a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008141e:	f4bf aaac 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081422:	2101      	movs	r1, #1
d0081424:	4d5b      	ldr	r5, [pc, #364]	; (d0081594 <emit_known_word.constprop.0+0x1228>)
d0081426:	2278      	movs	r2, #120	; 0x78
d0081428:	4e5b      	ldr	r6, [pc, #364]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d008142a:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d008142e:	8823      	ldrh	r3, [r4, #0]
d0081430:	4630      	mov	r0, r6
d0081432:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081436:	805a      	strh	r2, [r3, #2]
d0081438:	8823      	ldrh	r3, [r4, #0]
d008143a:	440b      	add	r3, r1
d008143c:	8023      	strh	r3, [r4, #0]
d008143e:	f002 fe00 	bl	d0084042 <strlen>
d0081442:	1d03      	adds	r3, r0, #4
d0081444:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081448:	d20c      	bcs.n	d0081464 <emit_known_word.constprop.0+0x10f8>
d008144a:	b118      	cbz	r0, d0081454 <emit_known_word.constprop.0+0x10e8>
d008144c:	2220      	movs	r2, #32
d008144e:	1833      	adds	r3, r6, r0
d0081450:	5432      	strb	r2, [r6, r0]
d0081452:	705f      	strb	r7, [r3, #1]
d0081454:	4850      	ldr	r0, [pc, #320]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081456:	f002 fdf4 	bl	d0084042 <strlen>
d008145a:	2203      	movs	r2, #3
d008145c:	4954      	ldr	r1, [pc, #336]	; (d00815b0 <emit_known_word.constprop.0+0x1244>)
d008145e:	4430      	add	r0, r6
d0081460:	f002 fc52 	bl	d0083d08 <memcpy>
d0081464:	8823      	ldrh	r3, [r4, #0]
d0081466:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008146a:	f4bf aa86 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008146e:	2115      	movs	r1, #21
d0081470:	2252      	movs	r2, #82	; 0x52
d0081472:	4849      	ldr	r0, [pc, #292]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081474:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081478:	8823      	ldrh	r3, [r4, #0]
d008147a:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d008147e:	805a      	strh	r2, [r3, #2]
d0081480:	8823      	ldrh	r3, [r4, #0]
d0081482:	3301      	adds	r3, #1
d0081484:	8023      	strh	r3, [r4, #0]
d0081486:	f002 fddc 	bl	d0084042 <strlen>
d008148a:	1cc3      	adds	r3, r0, #3
d008148c:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081490:	d20d      	bcs.n	d00814ae <emit_known_word.constprop.0+0x1142>
d0081492:	b120      	cbz	r0, d008149e <emit_known_word.constprop.0+0x1132>
d0081494:	2120      	movs	r1, #32
d0081496:	1833      	adds	r3, r6, r0
d0081498:	2200      	movs	r2, #0
d008149a:	5431      	strb	r1, [r6, r0]
d008149c:	705a      	strb	r2, [r3, #1]
d008149e:	483e      	ldr	r0, [pc, #248]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00814a0:	f002 fdcf 	bl	d0084042 <strlen>
d00814a4:	2202      	movs	r2, #2
d00814a6:	4943      	ldr	r1, [pc, #268]	; (d00815b4 <emit_known_word.constprop.0+0x1248>)
d00814a8:	4430      	add	r0, r6
d00814aa:	f002 fc2d 	bl	d0083d08 <memcpy>
d00814ae:	8823      	ldrh	r3, [r4, #0]
d00814b0:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00814b4:	f4bf aa61 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00814b8:	2108      	movs	r1, #8
d00814ba:	2282      	movs	r2, #130	; 0x82
d00814bc:	4836      	ldr	r0, [pc, #216]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00814be:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00814c2:	8823      	ldrh	r3, [r4, #0]
d00814c4:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00814c8:	805a      	strh	r2, [r3, #2]
d00814ca:	8823      	ldrh	r3, [r4, #0]
d00814cc:	3301      	adds	r3, #1
d00814ce:	8023      	strh	r3, [r4, #0]
d00814d0:	f002 fdb7 	bl	d0084042 <strlen>
d00814d4:	1d03      	adds	r3, r0, #4
d00814d6:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00814da:	d20d      	bcs.n	d00814f8 <emit_known_word.constprop.0+0x118c>
d00814dc:	b120      	cbz	r0, d00814e8 <emit_known_word.constprop.0+0x117c>
d00814de:	2120      	movs	r1, #32
d00814e0:	1833      	adds	r3, r6, r0
d00814e2:	2200      	movs	r2, #0
d00814e4:	5431      	strb	r1, [r6, r0]
d00814e6:	705a      	strb	r2, [r3, #1]
d00814e8:	482b      	ldr	r0, [pc, #172]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d00814ea:	f002 fdaa 	bl	d0084042 <strlen>
d00814ee:	2203      	movs	r2, #3
d00814f0:	4931      	ldr	r1, [pc, #196]	; (d00815b8 <emit_known_word.constprop.0+0x124c>)
d00814f2:	4430      	add	r0, r6
d00814f4:	f002 fc08 	bl	d0083d08 <memcpy>
d00814f8:	8823      	ldrh	r3, [r4, #0]
d00814fa:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00814fe:	f4bf aa3c 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081502:	2110      	movs	r1, #16
d0081504:	2246      	movs	r2, #70	; 0x46
d0081506:	4824      	ldr	r0, [pc, #144]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081508:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d008150c:	8823      	ldrh	r3, [r4, #0]
d008150e:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081512:	805a      	strh	r2, [r3, #2]
d0081514:	8823      	ldrh	r3, [r4, #0]
d0081516:	3301      	adds	r3, #1
d0081518:	8023      	strh	r3, [r4, #0]
d008151a:	f002 fd92 	bl	d0084042 <strlen>
d008151e:	1cc3      	adds	r3, r0, #3
d0081520:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081524:	d20d      	bcs.n	d0081542 <emit_known_word.constprop.0+0x11d6>
d0081526:	b120      	cbz	r0, d0081532 <emit_known_word.constprop.0+0x11c6>
d0081528:	2120      	movs	r1, #32
d008152a:	1833      	adds	r3, r6, r0
d008152c:	2200      	movs	r2, #0
d008152e:	5431      	strb	r1, [r6, r0]
d0081530:	705a      	strb	r2, [r3, #1]
d0081532:	4819      	ldr	r0, [pc, #100]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081534:	f002 fd85 	bl	d0084042 <strlen>
d0081538:	2202      	movs	r2, #2
d008153a:	4920      	ldr	r1, [pc, #128]	; (d00815bc <emit_known_word.constprop.0+0x1250>)
d008153c:	4430      	add	r0, r6
d008153e:	f002 fbe3 	bl	d0083d08 <memcpy>
d0081542:	8823      	ldrh	r3, [r4, #0]
d0081544:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081548:	f4bf aa17 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008154c:	2101      	movs	r1, #1
d008154e:	2278      	movs	r2, #120	; 0x78
d0081550:	4811      	ldr	r0, [pc, #68]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081552:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081556:	8823      	ldrh	r3, [r4, #0]
d0081558:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d008155c:	806a      	strh	r2, [r5, #2]
d008155e:	8823      	ldrh	r3, [r4, #0]
d0081560:	440b      	add	r3, r1
d0081562:	8023      	strh	r3, [r4, #0]
d0081564:	f002 fd6d 	bl	d0084042 <strlen>
d0081568:	1d03      	adds	r3, r0, #4
d008156a:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008156e:	f4bf aa04 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081572:	b120      	cbz	r0, d008157e <emit_known_word.constprop.0+0x1212>
d0081574:	2120      	movs	r1, #32
d0081576:	1833      	adds	r3, r6, r0
d0081578:	2200      	movs	r2, #0
d008157a:	5431      	strb	r1, [r6, r0]
d008157c:	705a      	strb	r2, [r3, #1]
d008157e:	4806      	ldr	r0, [pc, #24]	; (d0081598 <emit_known_word.constprop.0+0x122c>)
d0081580:	f002 fd5f 	bl	d0084042 <strlen>
d0081584:	2203      	movs	r2, #3
d0081586:	490a      	ldr	r1, [pc, #40]	; (d00815b0 <emit_known_word.constprop.0+0x1244>)
d0081588:	4430      	add	r0, r6
d008158a:	f002 fbbd 	bl	d0083d08 <memcpy>
d008158e:	2001      	movs	r0, #1
d0081590:	f7ff b9f4 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d0081594:	d0084b28 	.word	0xd0084b28
d0081598:	d00b4540 	.word	0xd00b4540
d008159c:	d00845d4 	.word	0xd00845d4
d00815a0:	d008453c 	.word	0xd008453c
d00815a4:	d00845d8 	.word	0xd00845d8
d00815a8:	d00845dc 	.word	0xd00845dc
d00815ac:	d0084590 	.word	0xd0084590
d00815b0:	d0084550 	.word	0xd0084550
d00815b4:	d00845e8 	.word	0xd00845e8
d00815b8:	d0084540 	.word	0xd0084540
d00815bc:	d00845ec 	.word	0xd00845ec
d00815c0:	4299      	cmp	r1, r3
d00815c2:	f47f a8e0 	bne.w	d0080786 <emit_known_word.constprop.0+0x41a>
d00815c6:	f81b 7001 	ldrb.w	r7, [fp, r1]
d00815ca:	2f00      	cmp	r7, #0
d00815cc:	f47f a8db 	bne.w	d0080786 <emit_known_word.constprop.0+0x41a>
d00815d0:	8823      	ldrh	r3, [r4, #0]
d00815d2:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00815d6:	d25c      	bcs.n	d0081692 <emit_known_word.constprop.0+0x1326>
d00815d8:	4dac      	ldr	r5, [pc, #688]	; (d008188c <emit_known_word.constprop.0+0x1520>)
d00815da:	2116      	movs	r1, #22
d00815dc:	224b      	movs	r2, #75	; 0x4b
d00815de:	4eac      	ldr	r6, [pc, #688]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00815e0:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00815e4:	8823      	ldrh	r3, [r4, #0]
d00815e6:	4630      	mov	r0, r6
d00815e8:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00815ec:	805a      	strh	r2, [r3, #2]
d00815ee:	8823      	ldrh	r3, [r4, #0]
d00815f0:	3301      	adds	r3, #1
d00815f2:	8023      	strh	r3, [r4, #0]
d00815f4:	f002 fd25 	bl	d0084042 <strlen>
d00815f8:	1cc3      	adds	r3, r0, #3
d00815fa:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00815fe:	d208      	bcs.n	d0081612 <emit_known_word.constprop.0+0x12a6>
d0081600:	b118      	cbz	r0, d008160a <emit_known_word.constprop.0+0x129e>
d0081602:	2220      	movs	r2, #32
d0081604:	1833      	adds	r3, r6, r0
d0081606:	5432      	strb	r2, [r6, r0]
d0081608:	705f      	strb	r7, [r3, #1]
d008160a:	49a2      	ldr	r1, [pc, #648]	; (d0081894 <emit_known_word.constprop.0+0x1528>)
d008160c:	48a0      	ldr	r0, [pc, #640]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008160e:	f002 fd09 	bl	d0084024 <strcat>
d0081612:	8823      	ldrh	r3, [r4, #0]
d0081614:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081618:	d23b      	bcs.n	d0081692 <emit_known_word.constprop.0+0x1326>
d008161a:	2102      	movs	r1, #2
d008161c:	2282      	movs	r2, #130	; 0x82
d008161e:	489c      	ldr	r0, [pc, #624]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d0081620:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081624:	8823      	ldrh	r3, [r4, #0]
d0081626:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d008162a:	805a      	strh	r2, [r3, #2]
d008162c:	8823      	ldrh	r3, [r4, #0]
d008162e:	3301      	adds	r3, #1
d0081630:	8023      	strh	r3, [r4, #0]
d0081632:	f002 fd06 	bl	d0084042 <strlen>
d0081636:	1d03      	adds	r3, r0, #4
d0081638:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008163c:	d209      	bcs.n	d0081652 <emit_known_word.constprop.0+0x12e6>
d008163e:	b120      	cbz	r0, d008164a <emit_known_word.constprop.0+0x12de>
d0081640:	2120      	movs	r1, #32
d0081642:	1833      	adds	r3, r6, r0
d0081644:	2200      	movs	r2, #0
d0081646:	5431      	strb	r1, [r6, r0]
d0081648:	705a      	strb	r2, [r3, #1]
d008164a:	4993      	ldr	r1, [pc, #588]	; (d0081898 <emit_known_word.constprop.0+0x152c>)
d008164c:	4890      	ldr	r0, [pc, #576]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008164e:	f002 fce9 	bl	d0084024 <strcat>
d0081652:	8823      	ldrh	r3, [r4, #0]
d0081654:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081658:	d21b      	bcs.n	d0081692 <emit_known_word.constprop.0+0x1326>
d008165a:	2119      	movs	r1, #25
d008165c:	2258      	movs	r2, #88	; 0x58
d008165e:	488c      	ldr	r0, [pc, #560]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d0081660:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081664:	8823      	ldrh	r3, [r4, #0]
d0081666:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d008166a:	806a      	strh	r2, [r5, #2]
d008166c:	8823      	ldrh	r3, [r4, #0]
d008166e:	3301      	adds	r3, #1
d0081670:	8023      	strh	r3, [r4, #0]
d0081672:	f002 fce6 	bl	d0084042 <strlen>
d0081676:	1cc3      	adds	r3, r0, #3
d0081678:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008167c:	d209      	bcs.n	d0081692 <emit_known_word.constprop.0+0x1326>
d008167e:	b120      	cbz	r0, d008168a <emit_known_word.constprop.0+0x131e>
d0081680:	2120      	movs	r1, #32
d0081682:	1833      	adds	r3, r6, r0
d0081684:	2200      	movs	r2, #0
d0081686:	5431      	strb	r1, [r6, r0]
d0081688:	705a      	strb	r2, [r3, #1]
d008168a:	4984      	ldr	r1, [pc, #528]	; (d008189c <emit_known_word.constprop.0+0x1530>)
d008168c:	4880      	ldr	r0, [pc, #512]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008168e:	f002 fcc9 	bl	d0084024 <strcat>
d0081692:	4620      	mov	r0, r4
d0081694:	f7fe fdb6 	bl	d0080204 <emit_ey.constprop.0>
d0081698:	8823      	ldrh	r3, [r4, #0]
d008169a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008169e:	f4bf a96c 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00816a2:	4d7a      	ldr	r5, [pc, #488]	; (d008188c <emit_known_word.constprop.0+0x1520>)
d00816a4:	211c      	movs	r1, #28
d00816a6:	223a      	movs	r2, #58	; 0x3a
d00816a8:	4e79      	ldr	r6, [pc, #484]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00816aa:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00816ae:	8823      	ldrh	r3, [r4, #0]
d00816b0:	4630      	mov	r0, r6
d00816b2:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00816b6:	805a      	strh	r2, [r3, #2]
d00816b8:	8823      	ldrh	r3, [r4, #0]
d00816ba:	3301      	adds	r3, #1
d00816bc:	8023      	strh	r3, [r4, #0]
d00816be:	f002 fcc0 	bl	d0084042 <strlen>
d00816c2:	1cc3      	adds	r3, r0, #3
d00816c4:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00816c8:	d209      	bcs.n	d00816de <emit_known_word.constprop.0+0x1372>
d00816ca:	b120      	cbz	r0, d00816d6 <emit_known_word.constprop.0+0x136a>
d00816cc:	2120      	movs	r1, #32
d00816ce:	1833      	adds	r3, r6, r0
d00816d0:	2200      	movs	r2, #0
d00816d2:	5431      	strb	r1, [r6, r0]
d00816d4:	705a      	strb	r2, [r3, #1]
d00816d6:	4972      	ldr	r1, [pc, #456]	; (d00818a0 <emit_known_word.constprop.0+0x1534>)
d00816d8:	486d      	ldr	r0, [pc, #436]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00816da:	f002 fca3 	bl	d0084024 <strcat>
d00816de:	8823      	ldrh	r3, [r4, #0]
d00816e0:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00816e4:	f4bf a949 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00816e8:	2106      	movs	r1, #6
d00816ea:	2287      	movs	r2, #135	; 0x87
d00816ec:	4868      	ldr	r0, [pc, #416]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00816ee:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00816f2:	8823      	ldrh	r3, [r4, #0]
d00816f4:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d00816f8:	806a      	strh	r2, [r5, #2]
d00816fa:	8823      	ldrh	r3, [r4, #0]
d00816fc:	3301      	adds	r3, #1
d00816fe:	8023      	strh	r3, [r4, #0]
d0081700:	f002 fc9f 	bl	d0084042 <strlen>
d0081704:	1d03      	adds	r3, r0, #4
d0081706:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008170a:	f4bf a936 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008170e:	b120      	cbz	r0, d008171a <emit_known_word.constprop.0+0x13ae>
d0081710:	2120      	movs	r1, #32
d0081712:	1833      	adds	r3, r6, r0
d0081714:	2200      	movs	r2, #0
d0081716:	5431      	strb	r1, [r6, r0]
d0081718:	705a      	strb	r2, [r3, #1]
d008171a:	4962      	ldr	r1, [pc, #392]	; (d00818a4 <emit_known_word.constprop.0+0x1538>)
d008171c:	485c      	ldr	r0, [pc, #368]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008171e:	f002 fc81 	bl	d0084024 <strcat>
d0081722:	2001      	movs	r0, #1
d0081724:	f7ff b92a 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d0081728:	4299      	cmp	r1, r3
d008172a:	f47f a84c 	bne.w	d00807c6 <emit_known_word.constprop.0+0x45a>
d008172e:	f81b 7001 	ldrb.w	r7, [fp, r1]
d0081732:	2f00      	cmp	r7, #0
d0081734:	f47f a847 	bne.w	d00807c6 <emit_known_word.constprop.0+0x45a>
d0081738:	8823      	ldrh	r3, [r4, #0]
d008173a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008173e:	f4bf a91c 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081742:	4d52      	ldr	r5, [pc, #328]	; (d008188c <emit_known_word.constprop.0+0x1520>)
d0081744:	2105      	movs	r1, #5
d0081746:	227d      	movs	r2, #125	; 0x7d
d0081748:	4e51      	ldr	r6, [pc, #324]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008174a:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d008174e:	8823      	ldrh	r3, [r4, #0]
d0081750:	4630      	mov	r0, r6
d0081752:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081756:	805a      	strh	r2, [r3, #2]
d0081758:	8823      	ldrh	r3, [r4, #0]
d008175a:	3301      	adds	r3, #1
d008175c:	8023      	strh	r3, [r4, #0]
d008175e:	f002 fc70 	bl	d0084042 <strlen>
d0081762:	1d03      	adds	r3, r0, #4
d0081764:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081768:	d208      	bcs.n	d008177c <emit_known_word.constprop.0+0x1410>
d008176a:	b118      	cbz	r0, d0081774 <emit_known_word.constprop.0+0x1408>
d008176c:	2220      	movs	r2, #32
d008176e:	1833      	adds	r3, r6, r0
d0081770:	5432      	strb	r2, [r6, r0]
d0081772:	705f      	strb	r7, [r3, #1]
d0081774:	494c      	ldr	r1, [pc, #304]	; (d00818a8 <emit_known_word.constprop.0+0x153c>)
d0081776:	4846      	ldr	r0, [pc, #280]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d0081778:	f002 fc54 	bl	d0084024 <strcat>
d008177c:	8823      	ldrh	r3, [r4, #0]
d008177e:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081782:	f4bf a8fa 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081786:	2118      	movs	r1, #24
d0081788:	223e      	movs	r2, #62	; 0x3e
d008178a:	4841      	ldr	r0, [pc, #260]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008178c:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081790:	8823      	ldrh	r3, [r4, #0]
d0081792:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081796:	805a      	strh	r2, [r3, #2]
d0081798:	8823      	ldrh	r3, [r4, #0]
d008179a:	3301      	adds	r3, #1
d008179c:	8023      	strh	r3, [r4, #0]
d008179e:	f002 fc50 	bl	d0084042 <strlen>
d00817a2:	1cc3      	adds	r3, r0, #3
d00817a4:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00817a8:	d209      	bcs.n	d00817be <emit_known_word.constprop.0+0x1452>
d00817aa:	b120      	cbz	r0, d00817b6 <emit_known_word.constprop.0+0x144a>
d00817ac:	2120      	movs	r1, #32
d00817ae:	1833      	adds	r3, r6, r0
d00817b0:	2200      	movs	r2, #0
d00817b2:	5431      	strb	r1, [r6, r0]
d00817b4:	705a      	strb	r2, [r3, #1]
d00817b6:	493d      	ldr	r1, [pc, #244]	; (d00818ac <emit_known_word.constprop.0+0x1540>)
d00817b8:	4835      	ldr	r0, [pc, #212]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00817ba:	f002 fc33 	bl	d0084024 <strcat>
d00817be:	8823      	ldrh	r3, [r4, #0]
d00817c0:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00817c4:	f4bf a8d9 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00817c8:	211a      	movs	r1, #26
d00817ca:	2252      	movs	r2, #82	; 0x52
d00817cc:	4830      	ldr	r0, [pc, #192]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00817ce:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00817d2:	8823      	ldrh	r3, [r4, #0]
d00817d4:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00817d8:	805a      	strh	r2, [r3, #2]
d00817da:	8823      	ldrh	r3, [r4, #0]
d00817dc:	3301      	adds	r3, #1
d00817de:	8023      	strh	r3, [r4, #0]
d00817e0:	f002 fc2f 	bl	d0084042 <strlen>
d00817e4:	1cc3      	adds	r3, r0, #3
d00817e6:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00817ea:	d209      	bcs.n	d0081800 <emit_known_word.constprop.0+0x1494>
d00817ec:	b120      	cbz	r0, d00817f8 <emit_known_word.constprop.0+0x148c>
d00817ee:	2120      	movs	r1, #32
d00817f0:	1833      	adds	r3, r6, r0
d00817f2:	2200      	movs	r2, #0
d00817f4:	5431      	strb	r1, [r6, r0]
d00817f6:	705a      	strb	r2, [r3, #1]
d00817f8:	492d      	ldr	r1, [pc, #180]	; (d00818b0 <emit_known_word.constprop.0+0x1544>)
d00817fa:	4825      	ldr	r0, [pc, #148]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d00817fc:	f002 fc12 	bl	d0084024 <strcat>
d0081800:	8823      	ldrh	r3, [r4, #0]
d0081802:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081806:	f4bf a8b8 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008180a:	2101      	movs	r1, #1
d008180c:	2278      	movs	r2, #120	; 0x78
d008180e:	4820      	ldr	r0, [pc, #128]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d0081810:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081814:	8823      	ldrh	r3, [r4, #0]
d0081816:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d008181a:	805a      	strh	r2, [r3, #2]
d008181c:	8823      	ldrh	r3, [r4, #0]
d008181e:	440b      	add	r3, r1
d0081820:	8023      	strh	r3, [r4, #0]
d0081822:	f002 fc0e 	bl	d0084042 <strlen>
d0081826:	1d03      	adds	r3, r0, #4
d0081828:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008182c:	d209      	bcs.n	d0081842 <emit_known_word.constprop.0+0x14d6>
d008182e:	b120      	cbz	r0, d008183a <emit_known_word.constprop.0+0x14ce>
d0081830:	2120      	movs	r1, #32
d0081832:	1833      	adds	r3, r6, r0
d0081834:	2200      	movs	r2, #0
d0081836:	5431      	strb	r1, [r6, r0]
d0081838:	705a      	strb	r2, [r3, #1]
d008183a:	491e      	ldr	r1, [pc, #120]	; (d00818b4 <emit_known_word.constprop.0+0x1548>)
d008183c:	4814      	ldr	r0, [pc, #80]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d008183e:	f002 fbf1 	bl	d0084024 <strcat>
d0081842:	8823      	ldrh	r3, [r4, #0]
d0081844:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081848:	f4bf a897 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008184c:	2116      	movs	r1, #22
d008184e:	224b      	movs	r2, #75	; 0x4b
d0081850:	480f      	ldr	r0, [pc, #60]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d0081852:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081856:	8823      	ldrh	r3, [r4, #0]
d0081858:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d008185c:	806a      	strh	r2, [r5, #2]
d008185e:	8823      	ldrh	r3, [r4, #0]
d0081860:	3301      	adds	r3, #1
d0081862:	8023      	strh	r3, [r4, #0]
d0081864:	f002 fbed 	bl	d0084042 <strlen>
d0081868:	1cc3      	adds	r3, r0, #3
d008186a:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008186e:	f4bf a884 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081872:	b120      	cbz	r0, d008187e <emit_known_word.constprop.0+0x1512>
d0081874:	2120      	movs	r1, #32
d0081876:	1833      	adds	r3, r6, r0
d0081878:	2200      	movs	r2, #0
d008187a:	5431      	strb	r1, [r6, r0]
d008187c:	705a      	strb	r2, [r3, #1]
d008187e:	4905      	ldr	r1, [pc, #20]	; (d0081894 <emit_known_word.constprop.0+0x1528>)
d0081880:	4803      	ldr	r0, [pc, #12]	; (d0081890 <emit_known_word.constprop.0+0x1524>)
d0081882:	f002 fbcf 	bl	d0084024 <strcat>
d0081886:	2001      	movs	r0, #1
d0081888:	f7ff b878 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d008188c:	d0084b28 	.word	0xd0084b28
d0081890:	d00b4540 	.word	0xd00b4540
d0081894:	d00845c4 	.word	0xd00845c4
d0081898:	d008456c 	.word	0xd008456c
d008189c:	d0084584 	.word	0xd0084584
d00818a0:	d0084570 	.word	0xd0084570
d00818a4:	d008459c 	.word	0xd008459c
d00818a8:	d008453c 	.word	0xd008453c
d00818ac:	d0084604 	.word	0xd0084604
d00818b0:	d0084560 	.word	0xd0084560
d00818b4:	d0084550 	.word	0xd0084550
d00818b8:	4299      	cmp	r1, r3
d00818ba:	f47e afa4 	bne.w	d0080806 <emit_known_word.constprop.0+0x49a>
d00818be:	f81b 3001 	ldrb.w	r3, [fp, r1]
d00818c2:	2b00      	cmp	r3, #0
d00818c4:	f47e af9f 	bne.w	d0080806 <emit_known_word.constprop.0+0x49a>
d00818c8:	8823      	ldrh	r3, [r4, #0]
d00818ca:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00818ce:	f4bf a854 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00818d2:	4dad      	ldr	r5, [pc, #692]	; (d0081b88 <emit_known_word.constprop.0+0x181c>)
d00818d4:	211a      	movs	r1, #26
d00818d6:	2252      	movs	r2, #82	; 0x52
d00818d8:	4eac      	ldr	r6, [pc, #688]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d00818da:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00818de:	8823      	ldrh	r3, [r4, #0]
d00818e0:	4630      	mov	r0, r6
d00818e2:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d00818e6:	805a      	strh	r2, [r3, #2]
d00818e8:	8823      	ldrh	r3, [r4, #0]
d00818ea:	3301      	adds	r3, #1
d00818ec:	8023      	strh	r3, [r4, #0]
d00818ee:	f002 fba8 	bl	d0084042 <strlen>
d00818f2:	1cc3      	adds	r3, r0, #3
d00818f4:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00818f8:	d20d      	bcs.n	d0081916 <emit_known_word.constprop.0+0x15aa>
d00818fa:	b120      	cbz	r0, d0081906 <emit_known_word.constprop.0+0x159a>
d00818fc:	2120      	movs	r1, #32
d00818fe:	1833      	adds	r3, r6, r0
d0081900:	2200      	movs	r2, #0
d0081902:	5431      	strb	r1, [r6, r0]
d0081904:	705a      	strb	r2, [r3, #1]
d0081906:	48a1      	ldr	r0, [pc, #644]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081908:	f002 fb9b 	bl	d0084042 <strlen>
d008190c:	2202      	movs	r2, #2
d008190e:	49a0      	ldr	r1, [pc, #640]	; (d0081b90 <emit_known_word.constprop.0+0x1824>)
d0081910:	4430      	add	r0, r6
d0081912:	f002 f9f9 	bl	d0083d08 <memcpy>
d0081916:	8823      	ldrh	r3, [r4, #0]
d0081918:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008191c:	f4bf a82d 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081920:	211c      	movs	r1, #28
d0081922:	223a      	movs	r2, #58	; 0x3a
d0081924:	4899      	ldr	r0, [pc, #612]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081926:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d008192a:	8823      	ldrh	r3, [r4, #0]
d008192c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081930:	805a      	strh	r2, [r3, #2]
d0081932:	8823      	ldrh	r3, [r4, #0]
d0081934:	3301      	adds	r3, #1
d0081936:	8023      	strh	r3, [r4, #0]
d0081938:	f002 fb83 	bl	d0084042 <strlen>
d008193c:	1cc3      	adds	r3, r0, #3
d008193e:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081942:	d20d      	bcs.n	d0081960 <emit_known_word.constprop.0+0x15f4>
d0081944:	b120      	cbz	r0, d0081950 <emit_known_word.constprop.0+0x15e4>
d0081946:	2120      	movs	r1, #32
d0081948:	1833      	adds	r3, r6, r0
d008194a:	2200      	movs	r2, #0
d008194c:	5431      	strb	r1, [r6, r0]
d008194e:	705a      	strb	r2, [r3, #1]
d0081950:	488e      	ldr	r0, [pc, #568]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081952:	f002 fb76 	bl	d0084042 <strlen>
d0081956:	2202      	movs	r2, #2
d0081958:	498e      	ldr	r1, [pc, #568]	; (d0081b94 <emit_known_word.constprop.0+0x1828>)
d008195a:	4430      	add	r0, r6
d008195c:	f002 f9d4 	bl	d0083d08 <memcpy>
d0081960:	8823      	ldrh	r3, [r4, #0]
d0081962:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081966:	f4bf a808 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d008196a:	2108      	movs	r1, #8
d008196c:	2282      	movs	r2, #130	; 0x82
d008196e:	4887      	ldr	r0, [pc, #540]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081970:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081974:	8823      	ldrh	r3, [r4, #0]
d0081976:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d008197a:	805a      	strh	r2, [r3, #2]
d008197c:	8823      	ldrh	r3, [r4, #0]
d008197e:	3301      	adds	r3, #1
d0081980:	8023      	strh	r3, [r4, #0]
d0081982:	f002 fb5e 	bl	d0084042 <strlen>
d0081986:	1d03      	adds	r3, r0, #4
d0081988:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008198c:	d20d      	bcs.n	d00819aa <emit_known_word.constprop.0+0x163e>
d008198e:	b120      	cbz	r0, d008199a <emit_known_word.constprop.0+0x162e>
d0081990:	2120      	movs	r1, #32
d0081992:	1833      	adds	r3, r6, r0
d0081994:	2200      	movs	r2, #0
d0081996:	5431      	strb	r1, [r6, r0]
d0081998:	705a      	strb	r2, [r3, #1]
d008199a:	487c      	ldr	r0, [pc, #496]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d008199c:	f002 fb51 	bl	d0084042 <strlen>
d00819a0:	2203      	movs	r2, #3
d00819a2:	497d      	ldr	r1, [pc, #500]	; (d0081b98 <emit_known_word.constprop.0+0x182c>)
d00819a4:	4430      	add	r0, r6
d00819a6:	f002 f9af 	bl	d0083d08 <memcpy>
d00819aa:	8823      	ldrh	r3, [r4, #0]
d00819ac:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00819b0:	f4be afe3 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00819b4:	211e      	movs	r1, #30
d00819b6:	2248      	movs	r2, #72	; 0x48
d00819b8:	4874      	ldr	r0, [pc, #464]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d00819ba:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d00819be:	8823      	ldrh	r3, [r4, #0]
d00819c0:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d00819c4:	806a      	strh	r2, [r5, #2]
d00819c6:	8823      	ldrh	r3, [r4, #0]
d00819c8:	3301      	adds	r3, #1
d00819ca:	8023      	strh	r3, [r4, #0]
d00819cc:	f002 fb39 	bl	d0084042 <strlen>
d00819d0:	1cc3      	adds	r3, r0, #3
d00819d2:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00819d6:	f4be afd0 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d00819da:	b120      	cbz	r0, d00819e6 <emit_known_word.constprop.0+0x167a>
d00819dc:	2120      	movs	r1, #32
d00819de:	1833      	adds	r3, r6, r0
d00819e0:	2200      	movs	r2, #0
d00819e2:	5431      	strb	r1, [r6, r0]
d00819e4:	705a      	strb	r2, [r3, #1]
d00819e6:	4869      	ldr	r0, [pc, #420]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d00819e8:	f002 fb2b 	bl	d0084042 <strlen>
d00819ec:	2202      	movs	r2, #2
d00819ee:	496b      	ldr	r1, [pc, #428]	; (d0081b9c <emit_known_word.constprop.0+0x1830>)
d00819f0:	4430      	add	r0, r6
d00819f2:	f002 f989 	bl	d0083d08 <memcpy>
d00819f6:	2001      	movs	r0, #1
d00819f8:	f7fe bfc0 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d00819fc:	4299      	cmp	r1, r3
d00819fe:	f47e af22 	bne.w	d0080846 <emit_known_word.constprop.0+0x4da>
d0081a02:	f81b 3001 	ldrb.w	r3, [fp, r1]
d0081a06:	2b00      	cmp	r3, #0
d0081a08:	f43f af5e 	beq.w	d00818c8 <emit_known_word.constprop.0+0x155c>
d0081a0c:	f7fe bf1b 	b.w	d0080846 <emit_known_word.constprop.0+0x4da>
d0081a10:	4299      	cmp	r1, r3
d0081a12:	f47e af38 	bne.w	d0080886 <emit_known_word.constprop.0+0x51a>
d0081a16:	f81b 3001 	ldrb.w	r3, [fp, r1]
d0081a1a:	2b00      	cmp	r3, #0
d0081a1c:	f47e af33 	bne.w	d0080886 <emit_known_word.constprop.0+0x51a>
d0081a20:	8823      	ldrh	r3, [r4, #0]
d0081a22:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081a26:	f4be afa8 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081a2a:	4d57      	ldr	r5, [pc, #348]	; (d0081b88 <emit_known_word.constprop.0+0x181c>)
d0081a2c:	2111      	movs	r1, #17
d0081a2e:	2237      	movs	r2, #55	; 0x37
d0081a30:	4e56      	ldr	r6, [pc, #344]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081a32:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081a36:	8823      	ldrh	r3, [r4, #0]
d0081a38:	4630      	mov	r0, r6
d0081a3a:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081a3e:	805a      	strh	r2, [r3, #2]
d0081a40:	8823      	ldrh	r3, [r4, #0]
d0081a42:	3301      	adds	r3, #1
d0081a44:	8023      	strh	r3, [r4, #0]
d0081a46:	f002 fafc 	bl	d0084042 <strlen>
d0081a4a:	1cc3      	adds	r3, r0, #3
d0081a4c:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081a50:	d209      	bcs.n	d0081a66 <emit_known_word.constprop.0+0x16fa>
d0081a52:	b120      	cbz	r0, d0081a5e <emit_known_word.constprop.0+0x16f2>
d0081a54:	2120      	movs	r1, #32
d0081a56:	1833      	adds	r3, r6, r0
d0081a58:	2200      	movs	r2, #0
d0081a5a:	5431      	strb	r1, [r6, r0]
d0081a5c:	705a      	strb	r2, [r3, #1]
d0081a5e:	4950      	ldr	r1, [pc, #320]	; (d0081ba0 <emit_known_word.constprop.0+0x1834>)
d0081a60:	484a      	ldr	r0, [pc, #296]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081a62:	f002 fadf 	bl	d0084024 <strcat>
d0081a66:	8823      	ldrh	r3, [r4, #0]
d0081a68:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081a6c:	f4be af85 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081a70:	2104      	movs	r1, #4
d0081a72:	2287      	movs	r2, #135	; 0x87
d0081a74:	4845      	ldr	r0, [pc, #276]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081a76:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081a7a:	8823      	ldrh	r3, [r4, #0]
d0081a7c:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081a80:	805a      	strh	r2, [r3, #2]
d0081a82:	8823      	ldrh	r3, [r4, #0]
d0081a84:	3301      	adds	r3, #1
d0081a86:	8023      	strh	r3, [r4, #0]
d0081a88:	f002 fadb 	bl	d0084042 <strlen>
d0081a8c:	1d03      	adds	r3, r0, #4
d0081a8e:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081a92:	d209      	bcs.n	d0081aa8 <emit_known_word.constprop.0+0x173c>
d0081a94:	b120      	cbz	r0, d0081aa0 <emit_known_word.constprop.0+0x1734>
d0081a96:	2120      	movs	r1, #32
d0081a98:	1833      	adds	r3, r6, r0
d0081a9a:	2200      	movs	r2, #0
d0081a9c:	5431      	strb	r1, [r6, r0]
d0081a9e:	705a      	strb	r2, [r3, #1]
d0081aa0:	4940      	ldr	r1, [pc, #256]	; (d0081ba4 <emit_known_word.constprop.0+0x1838>)
d0081aa2:	483a      	ldr	r0, [pc, #232]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081aa4:	f002 fabe 	bl	d0084024 <strcat>
d0081aa8:	8823      	ldrh	r3, [r4, #0]
d0081aaa:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081aae:	f4be af64 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081ab2:	2113      	movs	r1, #19
d0081ab4:	2246      	movs	r2, #70	; 0x46
d0081ab6:	4835      	ldr	r0, [pc, #212]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081ab8:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081abc:	8823      	ldrh	r3, [r4, #0]
d0081abe:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081ac2:	805a      	strh	r2, [r3, #2]
d0081ac4:	8823      	ldrh	r3, [r4, #0]
d0081ac6:	3301      	adds	r3, #1
d0081ac8:	8023      	strh	r3, [r4, #0]
d0081aca:	f002 faba 	bl	d0084042 <strlen>
d0081ace:	1cc3      	adds	r3, r0, #3
d0081ad0:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081ad4:	d209      	bcs.n	d0081aea <emit_known_word.constprop.0+0x177e>
d0081ad6:	b120      	cbz	r0, d0081ae2 <emit_known_word.constprop.0+0x1776>
d0081ad8:	2120      	movs	r1, #32
d0081ada:	1833      	adds	r3, r6, r0
d0081adc:	2200      	movs	r2, #0
d0081ade:	5431      	strb	r1, [r6, r0]
d0081ae0:	705a      	strb	r2, [r3, #1]
d0081ae2:	4931      	ldr	r1, [pc, #196]	; (d0081ba8 <emit_known_word.constprop.0+0x183c>)
d0081ae4:	4829      	ldr	r0, [pc, #164]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081ae6:	f002 fa9d 	bl	d0084024 <strcat>
d0081aea:	8823      	ldrh	r3, [r4, #0]
d0081aec:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081af0:	f4be af43 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081af4:	2107      	movs	r1, #7
d0081af6:	226e      	movs	r2, #110	; 0x6e
d0081af8:	4824      	ldr	r0, [pc, #144]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081afa:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081afe:	8823      	ldrh	r3, [r4, #0]
d0081b00:	eb05 0383 	add.w	r3, r5, r3, lsl #2
d0081b04:	805a      	strh	r2, [r3, #2]
d0081b06:	8823      	ldrh	r3, [r4, #0]
d0081b08:	3301      	adds	r3, #1
d0081b0a:	8023      	strh	r3, [r4, #0]
d0081b0c:	f002 fa99 	bl	d0084042 <strlen>
d0081b10:	1d03      	adds	r3, r0, #4
d0081b12:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081b16:	d209      	bcs.n	d0081b2c <emit_known_word.constprop.0+0x17c0>
d0081b18:	b120      	cbz	r0, d0081b24 <emit_known_word.constprop.0+0x17b8>
d0081b1a:	2120      	movs	r1, #32
d0081b1c:	1833      	adds	r3, r6, r0
d0081b1e:	2200      	movs	r2, #0
d0081b20:	5431      	strb	r1, [r6, r0]
d0081b22:	705a      	strb	r2, [r3, #1]
d0081b24:	4921      	ldr	r1, [pc, #132]	; (d0081bac <emit_known_word.constprop.0+0x1840>)
d0081b26:	4819      	ldr	r0, [pc, #100]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081b28:	f002 fa7c 	bl	d0084024 <strcat>
d0081b2c:	8823      	ldrh	r3, [r4, #0]
d0081b2e:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0081b32:	f4be af22 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081b36:	2117      	movs	r1, #23
d0081b38:	225a      	movs	r2, #90	; 0x5a
d0081b3a:	4814      	ldr	r0, [pc, #80]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081b3c:	f805 1023 	strb.w	r1, [r5, r3, lsl #2]
d0081b40:	8823      	ldrh	r3, [r4, #0]
d0081b42:	eb05 0583 	add.w	r5, r5, r3, lsl #2
d0081b46:	806a      	strh	r2, [r5, #2]
d0081b48:	8823      	ldrh	r3, [r4, #0]
d0081b4a:	3301      	adds	r3, #1
d0081b4c:	8023      	strh	r3, [r4, #0]
d0081b4e:	f002 fa78 	bl	d0084042 <strlen>
d0081b52:	1d03      	adds	r3, r0, #4
d0081b54:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0081b58:	f4be af0f 	bcs.w	d008097a <emit_known_word.constprop.0+0x60e>
d0081b5c:	b120      	cbz	r0, d0081b68 <emit_known_word.constprop.0+0x17fc>
d0081b5e:	2120      	movs	r1, #32
d0081b60:	1833      	adds	r3, r6, r0
d0081b62:	2200      	movs	r2, #0
d0081b64:	5431      	strb	r1, [r6, r0]
d0081b66:	705a      	strb	r2, [r3, #1]
d0081b68:	4911      	ldr	r1, [pc, #68]	; (d0081bb0 <emit_known_word.constprop.0+0x1844>)
d0081b6a:	4808      	ldr	r0, [pc, #32]	; (d0081b8c <emit_known_word.constprop.0+0x1820>)
d0081b6c:	f002 fa5a 	bl	d0084024 <strcat>
d0081b70:	2001      	movs	r0, #1
d0081b72:	f7fe bf03 	b.w	d008097c <emit_known_word.constprop.0+0x610>
d0081b76:	4299      	cmp	r1, r3
d0081b78:	f47e aea2 	bne.w	d00808c0 <emit_known_word.constprop.0+0x554>
d0081b7c:	5c73      	ldrb	r3, [r6, r1]
d0081b7e:	2b00      	cmp	r3, #0
d0081b80:	f43f af4e 	beq.w	d0081a20 <emit_known_word.constprop.0+0x16b4>
d0081b84:	f7fe be9c 	b.w	d00808c0 <emit_known_word.constprop.0+0x554>
d0081b88:	d0084b28 	.word	0xd0084b28
d0081b8c:	d00b4540 	.word	0xd00b4540
d0081b90:	d0084560 	.word	0xd0084560
d0081b94:	d0084570 	.word	0xd0084570
d0081b98:	d0084540 	.word	0xd0084540
d0081b9c:	d00845b0 	.word	0xd00845b0
d0081ba0:	d00845d4 	.word	0xd00845d4
d0081ba4:	d00845dc 	.word	0xd00845dc
d0081ba8:	d0084628 	.word	0xd0084628
d0081bac:	d008455c 	.word	0xd008455c
d0081bb0:	d008462c 	.word	0xd008462c

d0081bb4 <speech_synth_render>:
d0081bb4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0081bb8:	4bc9      	ldr	r3, [pc, #804]	; (d0081ee0 <speech_synth_render+0x32c>)
d0081bba:	2400      	movs	r4, #0
d0081bbc:	ed2d 8b10 	vpush	{d8-d15}
d0081bc0:	701c      	strb	r4, [r3, #0]
d0081bc2:	b0b5      	sub	sp, #212	; 0xd4
d0081bc4:	7805      	ldrb	r5, [r0, #0]
d0081bc6:	f8ad 4098 	strh.w	r4, [sp, #152]	; 0x98
d0081bca:	2d00      	cmp	r5, #0
d0081bcc:	f001 80db 	beq.w	d0082d86 <speech_synth_render+0x11d2>
d0081bd0:	4683      	mov	fp, r0
d0081bd2:	4626      	mov	r6, r4
d0081bd4:	9000      	str	r0, [sp, #0]
d0081bd6:	e03d      	b.n	d0081c54 <speech_synth_render+0xa0>
d0081bd8:	f1a5 0321 	sub.w	r3, r5, #33	; 0x21
d0081bdc:	b2db      	uxtb	r3, r3
d0081bde:	2b1e      	cmp	r3, #30
d0081be0:	d82a      	bhi.n	d0081c38 <speech_synth_render+0x84>
d0081be2:	4ac0      	ldr	r2, [pc, #768]	; (d0081ee4 <speech_synth_render+0x330>)
d0081be4:	fa22 f303 	lsr.w	r3, r2, r3
d0081be8:	43db      	mvns	r3, r3
d0081bea:	f013 0701 	ands.w	r7, r3, #1
d0081bee:	f040 8230 	bne.w	d0082052 <speech_synth_render+0x49e>
d0081bf2:	4bbd      	ldr	r3, [pc, #756]	; (d0081ee8 <speech_synth_render+0x334>)
d0081bf4:	1c71      	adds	r1, r6, #1
d0081bf6:	22be      	movs	r2, #190	; 0xbe
d0081bf8:	48b9      	ldr	r0, [pc, #740]	; (d0081ee0 <speech_synth_render+0x32c>)
d0081bfa:	f803 7026 	strb.w	r7, [r3, r6, lsl #2]
d0081bfe:	eb03 0386 	add.w	r3, r3, r6, lsl #2
d0081c02:	b28e      	uxth	r6, r1
d0081c04:	805a      	strh	r2, [r3, #2]
d0081c06:	f8ad 6098 	strh.w	r6, [sp, #152]	; 0x98
d0081c0a:	f002 fa1a 	bl	d0084042 <strlen>
d0081c0e:	1cc2      	adds	r2, r0, #3
d0081c10:	4603      	mov	r3, r0
d0081c12:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0081c16:	d20f      	bcs.n	d0081c38 <speech_synth_render+0x84>
d0081c18:	b140      	cbz	r0, d0081c2c <speech_synth_render+0x78>
d0081c1a:	4db1      	ldr	r5, [pc, #708]	; (d0081ee0 <speech_synth_render+0x32c>)
d0081c1c:	2120      	movs	r1, #32
d0081c1e:	182a      	adds	r2, r5, r0
d0081c20:	4628      	mov	r0, r5
d0081c22:	54e9      	strb	r1, [r5, r3]
d0081c24:	7057      	strb	r7, [r2, #1]
d0081c26:	f002 fa0c 	bl	d0084042 <strlen>
d0081c2a:	4603      	mov	r3, r0
d0081c2c:	4aac      	ldr	r2, [pc, #688]	; (d0081ee0 <speech_synth_render+0x32c>)
d0081c2e:	49af      	ldr	r1, [pc, #700]	; (d0081eec <speech_synth_render+0x338>)
d0081c30:	18d0      	adds	r0, r2, r3
d0081c32:	2202      	movs	r2, #2
d0081c34:	f002 f868 	bl	d0083d08 <memcpy>
d0081c38:	3401      	adds	r4, #1
d0081c3a:	9b00      	ldr	r3, [sp, #0]
d0081c3c:	b2a4      	uxth	r4, r4
d0081c3e:	eb03 0b04 	add.w	fp, r3, r4
d0081c42:	f89b 5000 	ldrb.w	r5, [fp]
d0081c46:	2d00      	cmp	r5, #0
d0081c48:	f000 8267 	beq.w	d008211a <speech_synth_render+0x566>
d0081c4c:	f5b6 7f40 	cmp.w	r6, #768	; 0x300
d0081c50:	f001 8095 	beq.w	d0082d7e <speech_synth_render+0x11ca>
d0081c54:	f025 0320 	bic.w	r3, r5, #32
d0081c58:	f1a3 0241 	sub.w	r2, r3, #65	; 0x41
d0081c5c:	2a19      	cmp	r2, #25
d0081c5e:	d8bb      	bhi.n	d0081bd8 <speech_synth_render+0x24>
d0081c60:	46a2      	mov	sl, r4
d0081c62:	9a00      	ldr	r2, [sp, #0]
d0081c64:	e001      	b.n	d0081c6a <speech_synth_render+0xb6>
d0081c66:	f025 0320 	bic.w	r3, r5, #32
d0081c6a:	3b41      	subs	r3, #65	; 0x41
d0081c6c:	f10a 0101 	add.w	r1, sl, #1
d0081c70:	b2db      	uxtb	r3, r3
d0081c72:	2b19      	cmp	r3, #25
d0081c74:	d904      	bls.n	d0081c80 <speech_synth_render+0xcc>
d0081c76:	2d2d      	cmp	r5, #45	; 0x2d
d0081c78:	d002      	beq.n	d0081c80 <speech_synth_render+0xcc>
d0081c7a:	2d27      	cmp	r5, #39	; 0x27
d0081c7c:	f040 8783 	bne.w	d0082b86 <speech_synth_render+0xfd2>
d0081c80:	fa1f fa81 	uxth.w	sl, r1
d0081c84:	f812 500a 	ldrb.w	r5, [r2, sl]
d0081c88:	eb02 030a 	add.w	r3, r2, sl
d0081c8c:	2d00      	cmp	r5, #0
d0081c8e:	d1ea      	bne.n	d0081c66 <speech_synth_render+0xb2>
d0081c90:	9301      	str	r3, [sp, #4]
d0081c92:	ebaa 0404 	sub.w	r4, sl, r4
d0081c96:	aa26      	add	r2, sp, #152	; 0x98
d0081c98:	4658      	mov	r0, fp
d0081c9a:	b2a4      	uxth	r4, r4
d0081c9c:	4621      	mov	r1, r4
d0081c9e:	f7fe fb65 	bl	d008036c <emit_known_word.constprop.0>
d0081ca2:	2800      	cmp	r0, #0
d0081ca4:	f040 8204 	bne.w	d00820b0 <speech_synth_render+0x4fc>
d0081ca8:	2c00      	cmp	r4, #0
d0081caa:	f000 8201 	beq.w	d00820b0 <speech_synth_render+0x4fc>
d0081cae:	1e63      	subs	r3, r4, #1
d0081cb0:	f89b c000 	ldrb.w	ip, [fp]
d0081cb4:	4a8c      	ldr	r2, [pc, #560]	; (d0081ee8 <speech_synth_render+0x334>)
d0081cb6:	4605      	mov	r5, r0
d0081cb8:	9303      	str	r3, [sp, #12]
d0081cba:	f1ac 0e41 	sub.w	lr, ip, #65	; 0x41
d0081cbe:	fa1b f383 	uxtah	r3, fp, r3
d0081cc2:	9212      	str	r2, [sp, #72]	; 0x48
d0081cc4:	9302      	str	r3, [sp, #8]
d0081cc6:	fa5f f38e 	uxtb.w	r3, lr
d0081cca:	2b19      	cmp	r3, #25
d0081ccc:	f240 8185 	bls.w	d0081fda <speech_synth_render+0x426>
d0081cd0:	1c6e      	adds	r6, r5, #1
d0081cd2:	4661      	mov	r1, ip
d0081cd4:	42a6      	cmp	r6, r4
d0081cd6:	f0c0 81b2 	bcc.w	d008203e <speech_synth_render+0x48a>
d0081cda:	2000      	movs	r0, #0
d0081cdc:	2927      	cmp	r1, #39	; 0x27
d0081cde:	f000 8170 	beq.w	d0081fc2 <speech_synth_render+0x40e>
d0081ce2:	292d      	cmp	r1, #45	; 0x2d
d0081ce4:	f000 816d 	beq.w	d0081fc2 <speech_synth_render+0x40e>
d0081ce8:	42a5      	cmp	r5, r4
d0081cea:	f280 8181 	bge.w	d0081ff0 <speech_synth_render+0x43c>
d0081cee:	4663      	mov	r3, ip
d0081cf0:	2774      	movs	r7, #116	; 0x74
d0081cf2:	2200      	movs	r2, #0
d0081cf4:	f8df 91f8 	ldr.w	r9, [pc, #504]	; d0081ef0 <speech_synth_render+0x33c>
d0081cf8:	4680      	mov	r8, r0
d0081cfa:	e008      	b.n	d0081d0e <speech_synth_render+0x15a>
d0081cfc:	f812 7009 	ldrb.w	r7, [r2, r9]
d0081d00:	2f00      	cmp	r7, #0
d0081d02:	f000 85e3 	beq.w	d00828cc <speech_synth_render+0xd18>
d0081d06:	42a0      	cmp	r0, r4
d0081d08:	da0e      	bge.n	d0081d28 <speech_synth_render+0x174>
d0081d0a:	f81b 3000 	ldrb.w	r3, [fp, r0]
d0081d0e:	f1a3 0041 	sub.w	r0, r3, #65	; 0x41
d0081d12:	3201      	adds	r2, #1
d0081d14:	b2c0      	uxtb	r0, r0
d0081d16:	b292      	uxth	r2, r2
d0081d18:	2819      	cmp	r0, #25
d0081d1a:	eb02 0005 	add.w	r0, r2, r5
d0081d1e:	d801      	bhi.n	d0081d24 <speech_synth_render+0x170>
d0081d20:	3320      	adds	r3, #32
d0081d22:	b2db      	uxtb	r3, r3
d0081d24:	42bb      	cmp	r3, r7
d0081d26:	d0e9      	beq.n	d0081cfc <speech_synth_render+0x148>
d0081d28:	4640      	mov	r0, r8
d0081d2a:	2763      	movs	r7, #99	; 0x63
d0081d2c:	46e0      	mov	r8, ip
d0081d2e:	2300      	movs	r3, #0
d0081d30:	f8df 91c0 	ldr.w	r9, [pc, #448]	; d0081ef4 <speech_synth_render+0x340>
d0081d34:	e008      	b.n	d0081d48 <speech_synth_render+0x194>
d0081d36:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081d3a:	2f00      	cmp	r7, #0
d0081d3c:	f000 85e9 	beq.w	d0082912 <speech_synth_render+0xd5e>
d0081d40:	42a2      	cmp	r2, r4
d0081d42:	da10      	bge.n	d0081d66 <speech_synth_render+0x1b2>
d0081d44:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081d48:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081d4c:	3301      	adds	r3, #1
d0081d4e:	b2d2      	uxtb	r2, r2
d0081d50:	b29b      	uxth	r3, r3
d0081d52:	2a19      	cmp	r2, #25
d0081d54:	eb03 0205 	add.w	r2, r3, r5
d0081d58:	d803      	bhi.n	d0081d62 <speech_synth_render+0x1ae>
d0081d5a:	f108 0820 	add.w	r8, r8, #32
d0081d5e:	fa5f f888 	uxtb.w	r8, r8
d0081d62:	45b8      	cmp	r8, r7
d0081d64:	d0e7      	beq.n	d0081d36 <speech_synth_render+0x182>
d0081d66:	46e0      	mov	r8, ip
d0081d68:	2773      	movs	r7, #115	; 0x73
d0081d6a:	2300      	movs	r3, #0
d0081d6c:	f8df 9188 	ldr.w	r9, [pc, #392]	; d0081ef8 <speech_synth_render+0x344>
d0081d70:	e008      	b.n	d0081d84 <speech_synth_render+0x1d0>
d0081d72:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081d76:	2f00      	cmp	r7, #0
d0081d78:	f000 86d4 	beq.w	d0082b24 <speech_synth_render+0xf70>
d0081d7c:	42a2      	cmp	r2, r4
d0081d7e:	da10      	bge.n	d0081da2 <speech_synth_render+0x1ee>
d0081d80:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081d84:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081d88:	3301      	adds	r3, #1
d0081d8a:	b2d2      	uxtb	r2, r2
d0081d8c:	b29b      	uxth	r3, r3
d0081d8e:	2a19      	cmp	r2, #25
d0081d90:	eb03 0205 	add.w	r2, r3, r5
d0081d94:	d803      	bhi.n	d0081d9e <speech_synth_render+0x1ea>
d0081d96:	f108 0820 	add.w	r8, r8, #32
d0081d9a:	fa5f f888 	uxtb.w	r8, r8
d0081d9e:	45b8      	cmp	r8, r7
d0081da0:	d0e7      	beq.n	d0081d72 <speech_synth_render+0x1be>
d0081da2:	46e0      	mov	r8, ip
d0081da4:	2774      	movs	r7, #116	; 0x74
d0081da6:	2300      	movs	r3, #0
d0081da8:	f8df 9150 	ldr.w	r9, [pc, #336]	; d0081efc <speech_synth_render+0x348>
d0081dac:	e008      	b.n	d0081dc0 <speech_synth_render+0x20c>
d0081dae:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081db2:	2f00      	cmp	r7, #0
d0081db4:	f000 86f1 	beq.w	d0082b9a <speech_synth_render+0xfe6>
d0081db8:	42a2      	cmp	r2, r4
d0081dba:	da10      	bge.n	d0081dde <speech_synth_render+0x22a>
d0081dbc:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081dc0:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081dc4:	3301      	adds	r3, #1
d0081dc6:	b2d2      	uxtb	r2, r2
d0081dc8:	b29b      	uxth	r3, r3
d0081dca:	2a19      	cmp	r2, #25
d0081dcc:	eb03 0205 	add.w	r2, r3, r5
d0081dd0:	d803      	bhi.n	d0081dda <speech_synth_render+0x226>
d0081dd2:	f108 0820 	add.w	r8, r8, #32
d0081dd6:	fa5f f888 	uxtb.w	r8, r8
d0081dda:	45b8      	cmp	r8, r7
d0081ddc:	d0e7      	beq.n	d0081dae <speech_synth_render+0x1fa>
d0081dde:	46e0      	mov	r8, ip
d0081de0:	2770      	movs	r7, #112	; 0x70
d0081de2:	2300      	movs	r3, #0
d0081de4:	f8df 9118 	ldr.w	r9, [pc, #280]	; d0081f00 <speech_synth_render+0x34c>
d0081de8:	e008      	b.n	d0081dfc <speech_synth_render+0x248>
d0081dea:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081dee:	2f00      	cmp	r7, #0
d0081df0:	f000 876f 	beq.w	d0082cd2 <speech_synth_render+0x111e>
d0081df4:	42a2      	cmp	r2, r4
d0081df6:	da10      	bge.n	d0081e1a <speech_synth_render+0x266>
d0081df8:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081dfc:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081e00:	3301      	adds	r3, #1
d0081e02:	b2d2      	uxtb	r2, r2
d0081e04:	b29b      	uxth	r3, r3
d0081e06:	2a19      	cmp	r2, #25
d0081e08:	eb03 0205 	add.w	r2, r3, r5
d0081e0c:	d803      	bhi.n	d0081e16 <speech_synth_render+0x262>
d0081e0e:	f108 0820 	add.w	r8, r8, #32
d0081e12:	fa5f f888 	uxtb.w	r8, r8
d0081e16:	45b8      	cmp	r8, r7
d0081e18:	d0e7      	beq.n	d0081dea <speech_synth_render+0x236>
d0081e1a:	46e0      	mov	r8, ip
d0081e1c:	2777      	movs	r7, #119	; 0x77
d0081e1e:	2300      	movs	r3, #0
d0081e20:	f8df 90e0 	ldr.w	r9, [pc, #224]	; d0081f04 <speech_synth_render+0x350>
d0081e24:	e008      	b.n	d0081e38 <speech_synth_render+0x284>
d0081e26:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081e2a:	2f00      	cmp	r7, #0
d0081e2c:	f000 877c 	beq.w	d0082d28 <speech_synth_render+0x1174>
d0081e30:	42a2      	cmp	r2, r4
d0081e32:	da10      	bge.n	d0081e56 <speech_synth_render+0x2a2>
d0081e34:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081e38:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081e3c:	3301      	adds	r3, #1
d0081e3e:	b2d2      	uxtb	r2, r2
d0081e40:	b29b      	uxth	r3, r3
d0081e42:	2a19      	cmp	r2, #25
d0081e44:	eb03 0205 	add.w	r2, r3, r5
d0081e48:	d803      	bhi.n	d0081e52 <speech_synth_render+0x29e>
d0081e4a:	f108 0820 	add.w	r8, r8, #32
d0081e4e:	fa5f f888 	uxtb.w	r8, r8
d0081e52:	45b8      	cmp	r8, r7
d0081e54:	d0e7      	beq.n	d0081e26 <speech_synth_render+0x272>
d0081e56:	46e0      	mov	r8, ip
d0081e58:	2777      	movs	r7, #119	; 0x77
d0081e5a:	2300      	movs	r3, #0
d0081e5c:	f8df 90a8 	ldr.w	r9, [pc, #168]	; d0081f08 <speech_synth_render+0x354>
d0081e60:	e008      	b.n	d0081e74 <speech_synth_render+0x2c0>
d0081e62:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081e66:	2f00      	cmp	r7, #0
d0081e68:	f001 82a4 	beq.w	d00833b4 <speech_synth_render+0x1800>
d0081e6c:	42a2      	cmp	r2, r4
d0081e6e:	da10      	bge.n	d0081e92 <speech_synth_render+0x2de>
d0081e70:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081e74:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081e78:	3301      	adds	r3, #1
d0081e7a:	b2d2      	uxtb	r2, r2
d0081e7c:	b29b      	uxth	r3, r3
d0081e7e:	2a19      	cmp	r2, #25
d0081e80:	eb03 0205 	add.w	r2, r3, r5
d0081e84:	d803      	bhi.n	d0081e8e <speech_synth_render+0x2da>
d0081e86:	f108 0820 	add.w	r8, r8, #32
d0081e8a:	fa5f f888 	uxtb.w	r8, r8
d0081e8e:	45b8      	cmp	r8, r7
d0081e90:	d0e7      	beq.n	d0081e62 <speech_synth_render+0x2ae>
d0081e92:	2d00      	cmp	r5, #0
d0081e94:	f000 8700 	beq.w	d0082c98 <speech_synth_render+0x10e4>
d0081e98:	46e0      	mov	r8, ip
d0081e9a:	276e      	movs	r7, #110	; 0x6e
d0081e9c:	2300      	movs	r3, #0
d0081e9e:	f8df 906c 	ldr.w	r9, [pc, #108]	; d0081f0c <speech_synth_render+0x358>
d0081ea2:	e008      	b.n	d0081eb6 <speech_synth_render+0x302>
d0081ea4:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081ea8:	2f00      	cmp	r7, #0
d0081eaa:	f001 8257 	beq.w	d008335c <speech_synth_render+0x17a8>
d0081eae:	42a2      	cmp	r2, r4
d0081eb0:	da10      	bge.n	d0081ed4 <speech_synth_render+0x320>
d0081eb2:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081eb6:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081eba:	3301      	adds	r3, #1
d0081ebc:	b2d2      	uxtb	r2, r2
d0081ebe:	b29b      	uxth	r3, r3
d0081ec0:	2a19      	cmp	r2, #25
d0081ec2:	eb03 0205 	add.w	r2, r3, r5
d0081ec6:	d803      	bhi.n	d0081ed0 <speech_synth_render+0x31c>
d0081ec8:	f108 0820 	add.w	r8, r8, #32
d0081ecc:	fa5f f888 	uxtb.w	r8, r8
d0081ed0:	45b8      	cmp	r8, r7
d0081ed2:	d0e7      	beq.n	d0081ea4 <speech_synth_render+0x2f0>
d0081ed4:	46e0      	mov	r8, ip
d0081ed6:	2763      	movs	r7, #99	; 0x63
d0081ed8:	2300      	movs	r3, #0
d0081eda:	f8df 9034 	ldr.w	r9, [pc, #52]	; d0081f10 <speech_synth_render+0x35c>
d0081ede:	e022      	b.n	d0081f26 <speech_synth_render+0x372>
d0081ee0:	d00b4540 	.word	0xd00b4540
d0081ee4:	40002001 	.word	0x40002001
d0081ee8:	d0084b28 	.word	0xd0084b28
d0081eec:	d00846a8 	.word	0xd00846a8
d0081ef0:	d0084630 	.word	0xd0084630
d0081ef4:	d0084638 	.word	0xd0084638
d0081ef8:	d008463c 	.word	0xd008463c
d0081efc:	d0084644 	.word	0xd0084644
d0081f00:	d008464c 	.word	0xd008464c
d0081f04:	d0084654 	.word	0xd0084654
d0081f08:	d008465c 	.word	0xd008465c
d0081f0c:	d0084660 	.word	0xd0084660
d0081f10:	d0084664 	.word	0xd0084664
d0081f14:	f813 7009 	ldrb.w	r7, [r3, r9]
d0081f18:	2f00      	cmp	r7, #0
d0081f1a:	f001 82b2 	beq.w	d0083482 <speech_synth_render+0x18ce>
d0081f1e:	42a2      	cmp	r2, r4
d0081f20:	da10      	bge.n	d0081f44 <speech_synth_render+0x390>
d0081f22:	f81b 8002 	ldrb.w	r8, [fp, r2]
d0081f26:	f1a8 0241 	sub.w	r2, r8, #65	; 0x41
d0081f2a:	3301      	adds	r3, #1
d0081f2c:	b2d2      	uxtb	r2, r2
d0081f2e:	b29b      	uxth	r3, r3
d0081f30:	2a19      	cmp	r2, #25
d0081f32:	eb03 0205 	add.w	r2, r3, r5
d0081f36:	d803      	bhi.n	d0081f40 <speech_synth_render+0x38c>
d0081f38:	f108 0820 	add.w	r8, r8, #32
d0081f3c:	fa5f f888 	uxtb.w	r8, r8
d0081f40:	45b8      	cmp	r8, r7
d0081f42:	d0e7      	beq.n	d0081f14 <speech_synth_render+0x360>
d0081f44:	2771      	movs	r7, #113	; 0x71
d0081f46:	2300      	movs	r3, #0
d0081f48:	f8df 8160 	ldr.w	r8, [pc, #352]	; d00820ac <speech_synth_render+0x4f8>
d0081f4c:	e00a      	b.n	d0081f64 <speech_synth_render+0x3b0>
d0081f4e:	f813 7008 	ldrb.w	r7, [r3, r8]
d0081f52:	2f00      	cmp	r7, #0
d0081f54:	f001 82c4 	beq.w	d00834e0 <speech_synth_render+0x192c>
d0081f58:	42a2      	cmp	r2, r4
d0081f5a:	da11      	bge.n	d0081f80 <speech_synth_render+0x3cc>
d0081f5c:	f81b c002 	ldrb.w	ip, [fp, r2]
d0081f60:	f1ac 0e41 	sub.w	lr, ip, #65	; 0x41
d0081f64:	fa5f f28e 	uxtb.w	r2, lr
d0081f68:	3301      	adds	r3, #1
d0081f6a:	2a19      	cmp	r2, #25
d0081f6c:	b29b      	uxth	r3, r3
d0081f6e:	eb03 0205 	add.w	r2, r3, r5
d0081f72:	d803      	bhi.n	d0081f7c <speech_synth_render+0x3c8>
d0081f74:	f10c 0c20 	add.w	ip, ip, #32
d0081f78:	fa5f fc8c 	uxtb.w	ip, ip
d0081f7c:	45bc      	cmp	ip, r7
d0081f7e:	d0e6      	beq.n	d0081f4e <speech_synth_render+0x39a>
d0081f80:	f1a1 0361 	sub.w	r3, r1, #97	; 0x61
d0081f84:	2b19      	cmp	r3, #25
d0081f86:	f200 87c7 	bhi.w	d0082f18 <speech_synth_render+0x1364>
d0081f8a:	e8df f013 	tbh	[pc, r3, lsl #1]
d0081f8e:	0706      	.short	0x0706
d0081f90:	08e708f1 	.word	0x08e708f1
d0081f94:	088708e0 	.word	0x088708e0
d0081f98:	08710880 	.word	0x08710880
d0081f9c:	0821086a 	.word	0x0821086a
d0081fa0:	0771090d 	.word	0x0771090d
d0081fa4:	08f808ff 	.word	0x08f808ff
d0081fa8:	091409db 	.word	0x091409db
d0081fac:	077107a2 	.word	0x077107a2
d0081fb0:	0813081a 	.word	0x0813081a
d0081fb4:	07e1080c 	.word	0x07e1080c
d0081fb8:	07d307da 	.word	0x07d307da
d0081fbc:	07a907c7 	.word	0x07a907c7
d0081fc0:	0906      	.short	0x0906
d0081fc2:	b2b5      	uxth	r5, r6
d0081fc4:	42ac      	cmp	r4, r5
d0081fc6:	d975      	bls.n	d00820b4 <speech_synth_render+0x500>
d0081fc8:	f81b c005 	ldrb.w	ip, [fp, r5]
d0081fcc:	f1ac 0e41 	sub.w	lr, ip, #65	; 0x41
d0081fd0:	fa5f f38e 	uxtb.w	r3, lr
d0081fd4:	2b19      	cmp	r3, #25
d0081fd6:	f63f ae7b 	bhi.w	d0081cd0 <speech_synth_render+0x11c>
d0081fda:	1c6e      	adds	r6, r5, #1
d0081fdc:	f10c 0120 	add.w	r1, ip, #32
d0081fe0:	42a6      	cmp	r6, r4
d0081fe2:	b2c9      	uxtb	r1, r1
d0081fe4:	d32b      	bcc.n	d008203e <speech_synth_render+0x48a>
d0081fe6:	42a5      	cmp	r5, r4
d0081fe8:	f04f 0000 	mov.w	r0, #0
d0081fec:	f6ff ae7f 	blt.w	d0081cee <speech_synth_render+0x13a>
d0081ff0:	2d00      	cmp	r5, #0
d0081ff2:	f000 8651 	beq.w	d0082c98 <speech_synth_render+0x10e4>
d0081ff6:	42a5      	cmp	r5, r4
d0081ff8:	f6ff af4e 	blt.w	d0081e98 <speech_synth_render+0x2e4>
d0081ffc:	f1a1 0361 	sub.w	r3, r1, #97	; 0x61
d0082000:	2b19      	cmp	r3, #25
d0082002:	f200 8789 	bhi.w	d0082f18 <speech_synth_render+0x1364>
d0082006:	e8df f013 	tbh	[pc, r3, lsl #1]
d008200a:	0a01      	.short	0x0a01
d008200c:	08a908b3 	.word	0x08a908b3
d0082010:	084908a2 	.word	0x084908a2
d0082014:	08330842 	.word	0x08330842
d0082018:	07e3082c 	.word	0x07e3082c
d008201c:	073308cf 	.word	0x073308cf
d0082020:	08ba08c1 	.word	0x08ba08c1
d0082024:	08d6099d 	.word	0x08d6099d
d0082028:	07330764 	.word	0x07330764
d008202c:	07d507dc 	.word	0x07d507dc
d0082030:	07a307ce 	.word	0x07a307ce
d0082034:	0795079c 	.word	0x0795079c
d0082038:	076b0789 	.word	0x076b0789
d008203c:	08c8      	.short	0x08c8
d008203e:	f81b 0006 	ldrb.w	r0, [fp, r6]
d0082042:	f1a0 0341 	sub.w	r3, r0, #65	; 0x41
d0082046:	2b19      	cmp	r3, #25
d0082048:	f63f ae48 	bhi.w	d0081cdc <speech_synth_render+0x128>
d008204c:	3020      	adds	r0, #32
d008204e:	b2c0      	uxtb	r0, r0
d0082050:	e644      	b.n	d0081cdc <speech_synth_render+0x128>
d0082052:	f1a5 033a 	sub.w	r3, r5, #58	; 0x3a
d0082056:	2b01      	cmp	r3, #1
d0082058:	d902      	bls.n	d0082060 <speech_synth_render+0x4ac>
d008205a:	2d2c      	cmp	r5, #44	; 0x2c
d008205c:	f47f adec 	bne.w	d0081c38 <speech_synth_render+0x84>
d0082060:	4810      	ldr	r0, [pc, #64]	; (d00820a4 <speech_synth_render+0x4f0>)
d0082062:	1c71      	adds	r1, r6, #1
d0082064:	2500      	movs	r5, #0
d0082066:	2278      	movs	r2, #120	; 0x78
d0082068:	eb00 0386 	add.w	r3, r0, r6, lsl #2
d008206c:	f800 5026 	strb.w	r5, [r0, r6, lsl #2]
d0082070:	b28e      	uxth	r6, r1
d0082072:	805a      	strh	r2, [r3, #2]
d0082074:	480c      	ldr	r0, [pc, #48]	; (d00820a8 <speech_synth_render+0x4f4>)
d0082076:	f8ad 6098 	strh.w	r6, [sp, #152]	; 0x98
d008207a:	f001 ffe2 	bl	d0084042 <strlen>
d008207e:	1cc2      	adds	r2, r0, #3
d0082080:	4603      	mov	r3, r0
d0082082:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082086:	f4bf add7 	bcs.w	d0081c38 <speech_synth_render+0x84>
d008208a:	2800      	cmp	r0, #0
d008208c:	f43f adce 	beq.w	d0081c2c <speech_synth_render+0x78>
d0082090:	4f05      	ldr	r7, [pc, #20]	; (d00820a8 <speech_synth_render+0x4f4>)
d0082092:	2120      	movs	r1, #32
d0082094:	183a      	adds	r2, r7, r0
d0082096:	4638      	mov	r0, r7
d0082098:	54f9      	strb	r1, [r7, r3]
d008209a:	7055      	strb	r5, [r2, #1]
d008209c:	f001 ffd1 	bl	d0084042 <strlen>
d00820a0:	4603      	mov	r3, r0
d00820a2:	e5c3      	b.n	d0081c2c <speech_synth_render+0x78>
d00820a4:	d0084b28 	.word	0xd0084b28
d00820a8:	d00b4540 	.word	0xd00b4540
d00820ac:	d0084668 	.word	0xd0084668
d00820b0:	4bbd      	ldr	r3, [pc, #756]	; (d00823a8 <speech_synth_render+0x7f4>)
d00820b2:	9312      	str	r3, [sp, #72]	; 0x48
d00820b4:	f8bd 6098 	ldrh.w	r6, [sp, #152]	; 0x98
d00820b8:	f5b6 7f40 	cmp.w	r6, #768	; 0x300
d00820bc:	f080 8520 	bcs.w	d0082b00 <speech_synth_render+0xf4c>
d00820c0:	9a12      	ldr	r2, [sp, #72]	; 0x48
d00820c2:	2400      	movs	r4, #0
d00820c4:	1c71      	adds	r1, r6, #1
d00820c6:	48b9      	ldr	r0, [pc, #740]	; (d00823ac <speech_synth_render+0x7f8>)
d00820c8:	eb02 0386 	add.w	r3, r2, r6, lsl #2
d00820cc:	f802 4026 	strb.w	r4, [r2, r6, lsl #2]
d00820d0:	221a      	movs	r2, #26
d00820d2:	b28e      	uxth	r6, r1
d00820d4:	805a      	strh	r2, [r3, #2]
d00820d6:	f8ad 6098 	strh.w	r6, [sp, #152]	; 0x98
d00820da:	f001 ffb2 	bl	d0084042 <strlen>
d00820de:	1cc2      	adds	r2, r0, #3
d00820e0:	4603      	mov	r3, r0
d00820e2:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00820e6:	f080 8553 	bcs.w	d0082b90 <speech_synth_render+0xfdc>
d00820ea:	b140      	cbz	r0, d00820fe <speech_synth_render+0x54a>
d00820ec:	4daf      	ldr	r5, [pc, #700]	; (d00823ac <speech_synth_render+0x7f8>)
d00820ee:	2120      	movs	r1, #32
d00820f0:	182a      	adds	r2, r5, r0
d00820f2:	4628      	mov	r0, r5
d00820f4:	54e9      	strb	r1, [r5, r3]
d00820f6:	7054      	strb	r4, [r2, #1]
d00820f8:	f001 ffa3 	bl	d0084042 <strlen>
d00820fc:	4603      	mov	r3, r0
d00820fe:	4aab      	ldr	r2, [pc, #684]	; (d00823ac <speech_synth_render+0x7f8>)
d0082100:	4654      	mov	r4, sl
d0082102:	f8dd b004 	ldr.w	fp, [sp, #4]
d0082106:	18d0      	adds	r0, r2, r3
d0082108:	49a9      	ldr	r1, [pc, #676]	; (d00823b0 <speech_synth_render+0x7fc>)
d008210a:	2202      	movs	r2, #2
d008210c:	f001 fdfc 	bl	d0083d08 <memcpy>
d0082110:	f89b 5000 	ldrb.w	r5, [fp]
d0082114:	2d00      	cmp	r5, #0
d0082116:	f47f ad99 	bne.w	d0081c4c <speech_synth_render+0x98>
d008211a:	4aa6      	ldr	r2, [pc, #664]	; (d00823b4 <speech_synth_render+0x800>)
d008211c:	2180      	movs	r1, #128	; 0x80
d008211e:	48a6      	ldr	r0, [pc, #664]	; (d00823b8 <speech_synth_render+0x804>)
d0082120:	9623      	str	r6, [sp, #140]	; 0x8c
d0082122:	f001 fdff 	bl	d0083d24 <memset>
d0082126:	2238      	movs	r2, #56	; 0x38
d0082128:	4629      	mov	r1, r5
d008212a:	a826      	add	r0, sp, #152	; 0x98
d008212c:	f001 fdfa 	bl	d0083d24 <memset>
d0082130:	4ba2      	ldr	r3, [pc, #648]	; (d00823bc <speech_synth_render+0x808>)
d0082132:	461a      	mov	r2, r3
d0082134:	9325      	str	r3, [sp, #148]	; 0x94
d0082136:	4ba2      	ldr	r3, [pc, #648]	; (d00823c0 <speech_synth_render+0x80c>)
d0082138:	6013      	str	r3, [r2, #0]
d008213a:	2e00      	cmp	r6, #0
d008213c:	f001 8261 	beq.w	d0083602 <speech_synth_render+0x1a4e>
d0082140:	4b99      	ldr	r3, [pc, #612]	; (d00823a8 <speech_synth_render+0x7f4>)
d0082142:	9312      	str	r3, [sp, #72]	; 0x48
d0082144:	9b23      	ldr	r3, [sp, #140]	; 0x8c
d0082146:	2200      	movs	r2, #0
d0082148:	ed9f 7a9e 	vldr	s14, [pc, #632]	; d00823c4 <speech_synth_render+0x810>
d008214c:	f04f 0901 	mov.w	r9, #1
d0082150:	3b01      	subs	r3, #1
d0082152:	f8df b26c 	ldr.w	fp, [pc, #620]	; d00823c0 <speech_synth_render+0x80c>
d0082156:	eeb0 aa47 	vmov.f32	s20, s14
d008215a:	eddf ba9b 	vldr	s23, [pc, #620]	; d00823c8 <speech_synth_render+0x814>
d008215e:	b29b      	uxth	r3, r3
d0082160:	eeb0 4a47 	vmov.f32	s8, s14
d0082164:	eef0 fa47 	vmov.f32	s31, s14
d0082168:	ed9f ba98 	vldr	s22, [pc, #608]	; d00823cc <speech_synth_render+0x818>
d008216c:	eef0 4a47 	vmov.f32	s9, s14
d0082170:	3302      	adds	r3, #2
d0082172:	eef0 9a47 	vmov.f32	s19, s14
d0082176:	9213      	str	r2, [sp, #76]	; 0x4c
d0082178:	eeb0 9a47 	vmov.f32	s18, s14
d008217c:	9324      	str	r3, [sp, #144]	; 0x90
d008217e:	eeb0 ca47 	vmov.f32	s24, s14
d0082182:	f8cd 9038 	str.w	r9, [sp, #56]	; 0x38
d0082186:	eef0 8a47 	vmov.f32	s17, s14
d008218a:	9202      	str	r2, [sp, #8]
d008218c:	eef0 ca47 	vmov.f32	s25, s14
d0082190:	eef0 aa47 	vmov.f32	s21, s14
d0082194:	eef0 7a47 	vmov.f32	s15, s14
d0082198:	eeb0 fa47 	vmov.f32	s30, s14
d008219c:	990e      	ldr	r1, [sp, #56]	; 0x38
d008219e:	9812      	ldr	r0, [sp, #72]	; 0x48
d00821a0:	9c23      	ldr	r4, [sp, #140]	; 0x8c
d00821a2:	008a      	lsls	r2, r1, #2
d00821a4:	eb00 0381 	add.w	r3, r0, r1, lsl #2
d00821a8:	42a1      	cmp	r1, r4
d00821aa:	f813 3c04 	ldrb.w	r3, [r3, #-4]
d00821ae:	9301      	str	r3, [sp, #4]
d00821b0:	f080 8466 	bcs.w	d0082a80 <speech_synth_render+0xecc>
d00821b4:	f810 3021 	ldrb.w	r3, [r0, r1, lsl #2]
d00821b8:	4619      	mov	r1, r3
d00821ba:	9317      	str	r3, [sp, #92]	; 0x5c
d00821bc:	4603      	mov	r3, r0
d00821be:	441a      	add	r2, r3
d00821c0:	f44f 567a 	mov.w	r6, #16000	; 0x3e80
d00821c4:	f832 3c02 	ldrh.w	r3, [r2, #-2]
d00821c8:	fb06 f603 	mul.w	r6, r6, r3
d00821cc:	4b80      	ldr	r3, [pc, #512]	; (d00823d0 <speech_synth_render+0x81c>)
d00821ce:	fba3 3006 	umull	r3, r0, r3, r6
d00821d2:	0983      	lsrs	r3, r0, #6
d00821d4:	930d      	str	r3, [sp, #52]	; 0x34
d00821d6:	9b01      	ldr	r3, [sp, #4]
d00821d8:	2b00      	cmp	r3, #0
d00821da:	f000 8456 	beq.w	d0082a8a <speech_synth_render+0xed6>
d00821de:	0987      	lsrs	r7, r0, #6
d00821e0:	4a7c      	ldr	r2, [pc, #496]	; (d00823d4 <speech_synth_render+0x820>)
d00821e2:	4b7d      	ldr	r3, [pc, #500]	; (d00823d8 <speech_synth_render+0x824>)
d00821e4:	463d      	mov	r5, r7
d00821e6:	4296      	cmp	r6, r2
d00821e8:	bf88      	it	hi
d00821ea:	f44f 75fa 	movhi.w	r5, #500	; 0x1f4
d00821ee:	9a02      	ldr	r2, [sp, #8]
d00821f0:	429a      	cmp	r2, r3
d00821f2:	9518      	str	r5, [sp, #96]	; 0x60
d00821f4:	bf8c      	ite	hi
d00821f6:	2300      	movhi	r3, #0
d00821f8:	2301      	movls	r3, #1
d00821fa:	f5b6 7f7a 	cmp.w	r6, #1000	; 0x3e8
d00821fe:	f0c0 8429 	bcc.w	d0082a54 <speech_synth_render+0xea0>
d0082202:	2b00      	cmp	r3, #0
d0082204:	f000 8426 	beq.w	d0082a54 <speech_synth_render+0xea0>
d0082208:	9c01      	ldr	r4, [sp, #4]
d008220a:	eb01 0381 	add.w	r3, r1, r1, lsl #2
d008220e:	4973      	ldr	r1, [pc, #460]	; (d00823dc <speech_synth_render+0x828>)
d0082210:	eef0 ea64 	vmov.f32	s29, s9
d0082214:	eb04 0284 	add.w	r2, r4, r4, lsl #2
d0082218:	4c71      	ldr	r4, [pc, #452]	; (d00823e0 <speech_synth_render+0x82c>)
d008221a:	eb01 0383 	add.w	r3, r1, r3, lsl #2
d008221e:	f8df c1c8 	ldr.w	ip, [pc, #456]	; d00823e8 <speech_synth_render+0x834>
d0082222:	fba4 4606 	umull	r4, r6, r4, r6
d0082226:	eb01 0282 	add.w	r2, r1, r2, lsl #2
d008222a:	1be9      	subs	r1, r5, r7
d008222c:	889d      	ldrh	r5, [r3, #4]
d008222e:	09b4      	lsrs	r4, r6, #6
d0082230:	88d7      	ldrh	r7, [r2, #6]
d0082232:	8896      	ldrh	r6, [r2, #4]
d0082234:	ebc1 2101 	rsb	r1, r1, r1, lsl #8
d0082238:	9420      	str	r4, [sp, #128]	; 0x80
d008223a:	09c4      	lsrs	r4, r0, #7
d008223c:	88d8      	ldrh	r0, [r3, #6]
d008223e:	1bad      	subs	r5, r5, r6
d0082240:	9606      	str	r6, [sp, #24]
d0082242:	eeb0 da67 	vmov.f32	s26, s15
d0082246:	1bc6      	subs	r6, r0, r7
d0082248:	9422      	str	r4, [sp, #136]	; 0x88
d008224a:	7a98      	ldrb	r0, [r3, #10]
d008224c:	8914      	ldrh	r4, [r2, #8]
d008224e:	9519      	str	r5, [sp, #100]	; 0x64
d0082250:	961a      	str	r6, [sp, #104]	; 0x68
d0082252:	891d      	ldrh	r5, [r3, #8]
d0082254:	7a96      	ldrb	r6, [r2, #10]
d0082256:	9408      	str	r4, [sp, #32]
d0082258:	1b2c      	subs	r4, r5, r4
d008225a:	9609      	str	r6, [sp, #36]	; 0x24
d008225c:	1b86      	subs	r6, r0, r6
d008225e:	9802      	ldr	r0, [sp, #8]
d0082260:	7add      	ldrb	r5, [r3, #11]
d0082262:	4460      	add	r0, ip
d0082264:	941b      	str	r4, [sp, #108]	; 0x6c
d0082266:	7ad4      	ldrb	r4, [r2, #11]
d0082268:	9211      	str	r2, [sp, #68]	; 0x44
d008226a:	940a      	str	r4, [sp, #40]	; 0x28
d008226c:	1b2c      	subs	r4, r5, r4
d008226e:	961c      	str	r6, [sp, #112]	; 0x70
d0082270:	900f      	str	r0, [sp, #60]	; 0x3c
d0082272:	7b16      	ldrb	r6, [r2, #12]
d0082274:	7b18      	ldrb	r0, [r3, #12]
d0082276:	7b52      	ldrb	r2, [r2, #13]
d0082278:	9321      	str	r3, [sp, #132]	; 0x84
d008227a:	9707      	str	r7, [sp, #28]
d008227c:	ed8d 7a10 	vstr	s14, [sp, #64]	; 0x40
d0082280:	960b      	str	r6, [sp, #44]	; 0x2c
d0082282:	941d      	str	r4, [sp, #116]	; 0x74
d0082284:	920c      	str	r2, [sp, #48]	; 0x30
d0082286:	7b5b      	ldrb	r3, [r3, #13]
d0082288:	9105      	str	r1, [sp, #20]
d008228a:	1b81      	subs	r1, r0, r6
d008228c:	1a9b      	subs	r3, r3, r2
d008228e:	9a18      	ldr	r2, [sp, #96]	; 0x60
d0082290:	911e      	str	r1, [sp, #120]	; 0x78
d0082292:	2100      	movs	r1, #0
d0082294:	931f      	str	r3, [sp, #124]	; 0x7c
d0082296:	9100      	str	r1, [sp, #0]
d0082298:	2a00      	cmp	r2, #0
d008229a:	f000 82f5 	beq.w	d0082888 <speech_synth_render+0xcd4>
d008229e:	9b00      	ldr	r3, [sp, #0]
d00822a0:	990d      	ldr	r1, [sp, #52]	; 0x34
d00822a2:	4413      	add	r3, r2
d00822a4:	4299      	cmp	r1, r3
d00822a6:	f200 82ef 	bhi.w	d0082888 <speech_synth_render+0xcd4>
d00822aa:	9b05      	ldr	r3, [sp, #20]
d00822ac:	9c1e      	ldr	r4, [sp, #120]	; 0x78
d00822ae:	4f4d      	ldr	r7, [pc, #308]	; (d00823e4 <speech_synth_render+0x830>)
d00822b0:	981d      	ldr	r0, [sp, #116]	; 0x74
d00822b2:	fbb3 fef2 	udiv	lr, r3, r2
d00822b6:	9a19      	ldr	r2, [sp, #100]	; 0x64
d00822b8:	fa1f f68e 	uxth.w	r6, lr
d00822bc:	fa0f f38e 	sxth.w	r3, lr
d00822c0:	fb06 f502 	mul.w	r5, r6, r2
d00822c4:	9a1a      	ldr	r2, [sp, #104]	; 0x68
d00822c6:	fb03 fc04 	mul.w	ip, r3, r4
d00822ca:	46b6      	mov	lr, r6
d00822cc:	fb06 f102 	mul.w	r1, r6, r2
d00822d0:	9a1b      	ldr	r2, [sp, #108]	; 0x6c
d00822d2:	9c1f      	ldr	r4, [sp, #124]	; 0x7c
d00822d4:	fb03 f000 	mul.w	r0, r3, r0
d00822d8:	fb06 f602 	mul.w	r6, r6, r2
d00822dc:	9a1c      	ldr	r2, [sp, #112]	; 0x70
d00822de:	ea4f 7ae5 	mov.w	sl, r5, asr #31
d00822e2:	fb03 f202 	mul.w	r2, r3, r2
d00822e6:	ea4f 78e1 	mov.w	r8, r1, asr #31
d00822ea:	fb03 f304 	mul.w	r3, r3, r4
d00822ee:	fb87 4905 	smull	r4, r9, r7, r5
d00822f2:	17f4      	asrs	r4, r6, #31
d00822f4:	444d      	add	r5, r9
d00822f6:	9403      	str	r4, [sp, #12]
d00822f8:	fb87 4901 	smull	r4, r9, r7, r1
d00822fc:	ebca 15e5 	rsb	r5, sl, r5, asr #7
d0082300:	fb87 4a02 	smull	r4, sl, r7, r2
d0082304:	4449      	add	r1, r9
d0082306:	fb87 4906 	smull	r4, r9, r7, r6
d008230a:	4492      	add	sl, r2
d008230c:	17d2      	asrs	r2, r2, #31
d008230e:	444e      	add	r6, r9
d0082310:	ebc8 11e1 	rsb	r1, r8, r1, asr #7
d0082314:	fb87 4900 	smull	r4, r9, r7, r0
d0082318:	ebc2 12ea 	rsb	r2, r2, sl, asr #7
d008231c:	fb87 480c 	smull	r4, r8, r7, ip
d0082320:	fb87 4703 	smull	r4, r7, r7, r3
d0082324:	4481      	add	r9, r0
d0082326:	17c0      	asrs	r0, r0, #31
d0082328:	44e0      	add	r8, ip
d008232a:	441f      	add	r7, r3
d008232c:	17db      	asrs	r3, r3, #31
d008232e:	ebc0 19e9 	rsb	r9, r0, r9, asr #7
d0082332:	9c03      	ldr	r4, [sp, #12]
d0082334:	ebc3 17e7 	rsb	r7, r3, r7, asr #7
d0082338:	9b09      	ldr	r3, [sp, #36]	; 0x24
d008233a:	ea4f 7cec 	mov.w	ip, ip, asr #31
d008233e:	9807      	ldr	r0, [sp, #28]
d0082340:	441a      	add	r2, r3
d0082342:	9b0a      	ldr	r3, [sp, #40]	; 0x28
d0082344:	ebcc 1ce8 	rsb	ip, ip, r8, asr #7
d0082348:	4401      	add	r1, r0
d008234a:	4499      	add	r9, r3
d008234c:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d008234e:	ebc4 16e6 	rsb	r6, r4, r6, asr #7
d0082352:	9c06      	ldr	r4, [sp, #24]
d0082354:	449c      	add	ip, r3
d0082356:	9b0c      	ldr	r3, [sp, #48]	; 0x30
d0082358:	4425      	add	r5, r4
d008235a:	fa1f f881 	uxth.w	r8, r1
d008235e:	19dc      	adds	r4, r3, r7
d0082360:	9917      	ldr	r1, [sp, #92]	; 0x5c
d0082362:	9b01      	ldr	r3, [sp, #4]
d0082364:	b2ad      	uxth	r5, r5
d0082366:	9808      	ldr	r0, [sp, #32]
d0082368:	fa5f f989 	uxtb.w	r9, r9
d008236c:	f1be 0f7f 	cmp.w	lr, #127	; 0x7f
d0082370:	bf88      	it	hi
d0082372:	460b      	movhi	r3, r1
d0082374:	f1be 0f7f 	cmp.w	lr, #127	; 0x7f
d0082378:	4406      	add	r6, r0
d008237a:	b2e4      	uxtb	r4, r4
d008237c:	461f      	mov	r7, r3
d008237e:	b2d3      	uxtb	r3, r2
d0082380:	b2b6      	uxth	r6, r6
d0082382:	9303      	str	r3, [sp, #12]
d0082384:	fa5f f38c 	uxtb.w	r3, ip
d0082388:	9304      	str	r3, [sp, #16]
d008238a:	f240 8289 	bls.w	d00828a0 <speech_synth_render+0xcec>
d008238e:	9b21      	ldr	r3, [sp, #132]	; 0x84
d0082390:	f893 a00e 	ldrb.w	sl, [r3, #14]
d0082394:	f1a7 0315 	sub.w	r3, r7, #21
d0082398:	b2db      	uxtb	r3, r3
d008239a:	f00a 0a01 	and.w	sl, sl, #1
d008239e:	2b02      	cmp	r3, #2
d00823a0:	f240 8289 	bls.w	d00828b6 <speech_synth_render+0xd02>
d00823a4:	e022      	b.n	d00823ec <speech_synth_render+0x838>
d00823a6:	bf00      	nop
d00823a8:	d0084b28 	.word	0xd0084b28
d00823ac:	d00b4540 	.word	0xd00b4540
d00823b0:	d00846a8 	.word	0xd00846a8
d00823b4:	0002ee00 	.word	0x0002ee00
d00823b8:	d0085740 	.word	0xd0085740
d00823bc:	d0084aac 	.word	0xd0084aac
d00823c0:	1234abcd 	.word	0x1234abcd
d00823c4:	00000000 	.word	0x00000000
d00823c8:	3fdc28f6 	.word	0x3fdc28f6
d00823cc:	3d3851ec 	.word	0x3d3851ec
d00823d0:	10624dd3 	.word	0x10624dd3
d00823d4:	0007a11f 	.word	0x0007a11f
d00823d8:	0002edff 	.word	0x0002edff
d00823dc:	d00846c0 	.word	0xd00846c0
d00823e0:	057619f1 	.word	0x057619f1
d00823e4:	80808081 	.word	0x80808081
d00823e8:	d008573f 	.word	0xd008573f
d00823ec:	f1a7 0314 	sub.w	r3, r7, #20
d00823f0:	b2db      	uxtb	r3, r3
d00823f2:	2b0c      	cmp	r3, #12
d00823f4:	f240 8312 	bls.w	d0082a1c <speech_synth_render+0xe68>
d00823f8:	f1a7 030e 	sub.w	r3, r7, #14
d00823fc:	b2db      	uxtb	r3, r3
d00823fe:	2b14      	cmp	r3, #20
d0082400:	f240 836d 	bls.w	d0082ade <speech_synth_render+0xf2a>
d0082404:	2f1c      	cmp	r7, #28
d0082406:	f200 83f6 	bhi.w	d0082bf6 <speech_synth_render+0x1042>
d008240a:	4bf2      	ldr	r3, [pc, #968]	; (d00827d4 <speech_synth_render+0xc20>)
d008240c:	eddf 7af2 	vldr	s15, [pc, #968]	; d00827d8 <speech_synth_render+0xc24>
d0082410:	40fb      	lsrs	r3, r7
d0082412:	ed9f 8af2 	vldr	s16, [pc, #968]	; d00827dc <speech_synth_render+0xc28>
d0082416:	eddf 4af2 	vldr	s9, [pc, #968]	; d00827e0 <speech_synth_render+0xc2c>
d008241a:	43db      	mvns	r3, r3
d008241c:	eddf 5af1 	vldr	s11, [pc, #964]	; d00827e4 <speech_synth_render+0xc30>
d0082420:	ed9f 5af1 	vldr	s10, [pc, #964]	; d00827e8 <speech_synth_render+0xc34>
d0082424:	f003 0301 	and.w	r3, r3, #1
d0082428:	ed9f 6af0 	vldr	s12, [pc, #960]	; d00827ec <speech_synth_render+0xc38>
d008242c:	eddf daf0 	vldr	s27, [pc, #960]	; d00827f0 <speech_synth_render+0xc3c>
d0082430:	2b00      	cmp	r3, #0
d0082432:	ed9f 7af0 	vldr	s14, [pc, #960]	; d00827f4 <speech_synth_render+0xc40>
d0082436:	ed9f eaf0 	vldr	s28, [pc, #960]	; d00827f8 <speech_synth_render+0xc44>
d008243a:	fe08 8a27 	vseleq.f32	s16, s16, s15
d008243e:	eddf 7aef 	vldr	s15, [pc, #956]	; d00827fc <speech_synth_render+0xc48>
d0082442:	fe44 4aa5 	vseleq.f32	s9, s9, s11
d0082446:	fe05 5a06 	vseleq.f32	s10, s10, s12
d008244a:	fe4d da87 	vseleq.f32	s27, s27, s14
d008244e:	fe0e ea27 	vseleq.f32	s28, s28, s15
d0082452:	9b02      	ldr	r3, [sp, #8]
d0082454:	f44f 527a 	mov.w	r2, #16000	; 0x3e80
d0082458:	2000      	movs	r0, #0
d008245a:	ed8d 4a16 	vstr	s8, [sp, #88]	; 0x58
d008245e:	0ad9      	lsrs	r1, r3, #11
d0082460:	2300      	movs	r3, #0
d0082462:	edcd 4a15 	vstr	s9, [sp, #84]	; 0x54
d0082466:	f001 010b 	and.w	r1, r1, #11
d008246a:	ed8d 5a14 	vstr	s10, [sp, #80]	; 0x50
d008246e:	316c      	adds	r1, #108	; 0x6c
d0082470:	f001 fac0 	bl	d00839f4 <__aeabi_uldivmod>
d0082474:	9b13      	ldr	r3, [sp, #76]	; 0x4c
d0082476:	ed9f 6ae2 	vldr	s12, [pc, #904]	; d0082800 <speech_synth_render+0xc4c>
d008247a:	4403      	add	r3, r0
d008247c:	ed9f 7ae1 	vldr	s14, [pc, #900]	; d0082804 <speech_synth_render+0xc50>
d0082480:	ed9d 5a14 	vldr	s10, [sp, #80]	; 0x50
d0082484:	9313      	str	r3, [sp, #76]	; 0x4c
d0082486:	0c1b      	lsrs	r3, r3, #16
d0082488:	eddd 4a15 	vldr	s9, [sp, #84]	; 0x54
d008248c:	ee07 3a90 	vmov	s15, r3
d0082490:	ed9d 4a16 	vldr	s8, [sp, #88]	; 0x58
d0082494:	eef8 7ae7 	vcvt.f32.s32	s15, s15
d0082498:	eef4 7ac6 	vcmpe.f32	s15, s12
d008249c:	ee27 7a87 	vmul.f32	s14, s15, s14
d00824a0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00824a4:	f100 82ab 	bmi.w	d00829fe <speech_synth_render+0xe4a>
d00824a8:	ed9f 6ad7 	vldr	s12, [pc, #860]	; d0082808 <speech_synth_render+0xc54>
d00824ac:	eef4 7ac6 	vcmpe.f32	s15, s12
d00824b0:	eef1 fa10 	vmrs	APSR_nzcv, fpscr
d00824b4:	f100 828e 	bmi.w	d00829d4 <speech_synth_render+0xe20>
d00824b8:	eddf 7ad4 	vldr	s15, [pc, #848]	; d008280c <speech_synth_render+0xc58>
d00824bc:	f1ba 0f00 	cmp.w	sl, #0
d00824c0:	f040 8273 	bne.w	d00829aa <speech_synth_render+0xdf6>
d00824c4:	ed9d 7a03 	vldr	s14, [sp, #12]
d00824c8:	eeb8 6a47 	vcvt.f32.u32	s12, s14
d00824cc:	ed9f 7acf 	vldr	s14, [pc, #828]	; d008280c <speech_synth_render+0xc58>
d00824d0:	2c00      	cmp	r4, #0
d00824d2:	f000 8254 	beq.w	d008297e <speech_synth_render+0xdca>
d00824d6:	9b11      	ldr	r3, [sp, #68]	; 0x44
d00824d8:	ee06 4a90 	vmov	s13, r4
d00824dc:	7b9b      	ldrb	r3, [r3, #14]
d00824de:	eef8 5a66 	vcvt.f32.u32	s11, s13
d00824e2:	eddf 6acb 	vldr	s13, [pc, #812]	; d0082810 <speech_synth_render+0xc5c>
d00824e6:	079b      	lsls	r3, r3, #30
d00824e8:	ee65 6aa6 	vmul.f32	s13, s11, s13
d00824ec:	d50c      	bpl.n	d0082508 <speech_synth_render+0x954>
d00824ee:	9b00      	ldr	r3, [sp, #0]
d00824f0:	9a20      	ldr	r2, [sp, #128]	; 0x80
d00824f2:	4293      	cmp	r3, r2
d00824f4:	f080 82a3 	bcs.w	d0082a3e <speech_synth_render+0xe8a>
d00824f8:	eddf 3ac6 	vldr	s7, [pc, #792]	; d0082814 <speech_synth_render+0xc60>
d00824fc:	eddf 5ac6 	vldr	s11, [pc, #792]	; d0082818 <speech_synth_render+0xc64>
d0082500:	ee27 7a23 	vmul.f32	s14, s14, s7
d0082504:	ee66 6aa5 	vmul.f32	s13, s13, s11
d0082508:	ea8b 3b4b 	eor.w	fp, fp, fp, lsl #13
d008250c:	2f11      	cmp	r7, #17
d008250e:	ea8b 4b5b 	eor.w	fp, fp, fp, lsr #17
d0082512:	ea8b 1b4b 	eor.w	fp, fp, fp, lsl #5
d0082516:	ea4f 432b 	mov.w	r3, fp, asr #16
d008251a:	ee05 3a90 	vmov	s11, r3
d008251e:	eefa 5ae8 	vcvt.f32.s32	s11, s11, #15
d0082522:	ee65 5aa6 	vmul.f32	s11, s11, s13
d0082526:	f000 822f 	beq.w	d0082988 <speech_synth_render+0xdd4>
d008252a:	f1ba 0f00 	cmp.w	sl, #0
d008252e:	f000 8239 	beq.w	d00829a4 <speech_synth_render+0xdf0>
d0082532:	ea8b 3b4b 	eor.w	fp, fp, fp, lsl #13
d0082536:	eddf 3ab9 	vldr	s7, [pc, #740]	; d008281c <speech_synth_render+0xc68>
d008253a:	ea8b 4b5b 	eor.w	fp, fp, fp, lsr #17
d008253e:	ea8b 1b4b 	eor.w	fp, fp, fp, lsl #5
d0082542:	ea4f 432b 	mov.w	r3, fp, asr #16
d0082546:	ee06 3a90 	vmov	s13, r3
d008254a:	eef8 6ae6 	vcvt.f32.s32	s13, s13
d008254e:	ee66 6aa3 	vmul.f32	s13, s13, s7
d0082552:	1c6b      	adds	r3, r5, #1
d0082554:	ee37 7a6a 	vsub.f32	s14, s14, s21
d0082558:	ed9f 3ab1 	vldr	s6, [pc, #708]	; d0082820 <speech_synth_render+0xc6c>
d008255c:	2d59      	cmp	r5, #89	; 0x59
d008255e:	ee03 3a90 	vmov	s7, r3
d0082562:	ee77 6a26 	vadd.f32	s13, s14, s13
d0082566:	eef8 3ae3 	vcvt.f32.s32	s7, s7
d008256a:	eee6 aa83 	vfma.f32	s21, s13, s6
d008256e:	ee84 7aa3 	vdiv.f32	s14, s9, s7
d0082572:	f240 8214 	bls.w	d008299e <speech_synth_render+0xdea>
d0082576:	ee06 5a90 	vmov	s13, r5
d008257a:	eddf 4aaa 	vldr	s9, [pc, #680]	; d0082824 <speech_synth_render+0xc70>
d008257e:	eef8 3a66 	vcvt.f32.u32	s7, s13
d0082582:	eddf 6aa9 	vldr	s13, [pc, #676]	; d0082828 <speech_synth_render+0xc74>
d0082586:	ee63 4aa4 	vmul.f32	s9, s7, s9
d008258a:	fec4 4ae6 	vminnm.f32	s9, s9, s13
d008258e:	eeb0 2a6c 	vmov.f32	s4, s25
d0082592:	fe87 7a6b 	vminnm.f32	s14, s14, s23
d0082596:	eef0 6a6a 	vmov.f32	s13, s21
d008259a:	fe87 7a0b 	vmaxnm.f32	s14, s14, s22
d008259e:	f108 0301 	add.w	r3, r8, #1
d00825a2:	eef2 2a00 	vmov.f32	s5, #32	; 0x41000000  8.0
d00825a6:	eea8 2aa4 	vfma.f32	s4, s17, s9
d00825aa:	f1b8 0f59 	cmp.w	r8, #89	; 0x59
d00825ae:	eee8 6ac7 	vfms.f32	s13, s17, s14
d00825b2:	ee07 3a10 	vmov	s14, r3
d00825b6:	eeba 3a00 	vmov.f32	s6, #160	; 0xc1000000 -8.0
d00825ba:	eef8 3ac7 	vcvt.f32.s32	s7, s14
d00825be:	fec2 ca62 	vminnm.f32	s25, s4, s5
d00825c2:	ee85 7a23 	vdiv.f32	s14, s10, s7
d00825c6:	fecc ca83 	vmaxnm.f32	s25, s25, s6
d00825ca:	ee76 6ac2 	vsub.f32	s13, s13, s4
d00825ce:	eee4 8aa6 	vfma.f32	s17, s9, s13
d00825d2:	fec8 8ae2 	vminnm.f32	s17, s17, s5
d00825d6:	fec8 8a83 	vmaxnm.f32	s17, s17, s6
d00825da:	f240 81dd 	bls.w	d0082998 <speech_synth_render+0xde4>
d00825de:	ee06 8a90 	vmov	s13, r8
d00825e2:	ed9f 5a90 	vldr	s10, [pc, #576]	; d0082824 <speech_synth_render+0xc70>
d00825e6:	eef8 4a66 	vcvt.f32.u32	s9, s13
d00825ea:	eddf 6a8f 	vldr	s13, [pc, #572]	; d0082828 <speech_synth_render+0xc74>
d00825ee:	ee24 5a85 	vmul.f32	s10, s9, s10
d00825f2:	fe85 5a66 	vminnm.f32	s10, s10, s13
d00825f6:	eef0 6a6a 	vmov.f32	s13, s21
d00825fa:	fe87 7a6b 	vminnm.f32	s14, s14, s23
d00825fe:	eef0 2a4c 	vmov.f32	s5, s24
d0082602:	fe87 7a0b 	vmaxnm.f32	s14, s14, s22
d0082606:	1c73      	adds	r3, r6, #1
d0082608:	eeb2 3a00 	vmov.f32	s6, #32	; 0x41000000  8.0
d008260c:	eee9 6a47 	vfms.f32	s13, s18, s14
d0082610:	2e59      	cmp	r6, #89	; 0x59
d0082612:	eee9 2a05 	vfma.f32	s5, s18, s10
d0082616:	ee04 3a90 	vmov	s9, r3
d008261a:	eef8 4ae4 	vcvt.f32.s32	s9, s9
d008261e:	eeb0 7a66 	vmov.f32	s14, s13
d0082622:	eefa 6a00 	vmov.f32	s13, #160	; 0xc1000000 -8.0
d0082626:	fe82 cac3 	vminnm.f32	s24, s5, s6
d008262a:	eec8 1a24 	vdiv.f32	s3, s16, s9
d008262e:	fe8c ca26 	vmaxnm.f32	s24, s24, s13
d0082632:	ee37 7a62 	vsub.f32	s14, s14, s5
d0082636:	eea5 9a07 	vfma.f32	s18, s10, s14
d008263a:	fe89 9a43 	vminnm.f32	s18, s18, s6
d008263e:	fe89 9a26 	vmaxnm.f32	s18, s18, s13
d0082642:	f240 81a6 	bls.w	d0082992 <speech_synth_render+0xdde>
d0082646:	ee07 6a10 	vmov	s14, r6
d008264a:	eddf 6a76 	vldr	s13, [pc, #472]	; d0082824 <speech_synth_render+0xc70>
d008264e:	eeb8 3a47 	vcvt.f32.u32	s6, s14
d0082652:	ed9f 7a75 	vldr	s14, [pc, #468]	; d0082828 <speech_synth_render+0xc74>
d0082656:	ee63 6a26 	vmul.f32	s13, s6, s13
d008265a:	fec6 6ac7 	vminnm.f32	s13, s13, s14
d008265e:	ee8d 2aa3 	vdiv.f32	s4, s27, s7
d0082662:	ed9f 1a72 	vldr	s2, [pc, #456]	; d008282c <speech_synth_render+0xc78>
d0082666:	fec1 1aeb 	vminnm.f32	s3, s3, s23
d008266a:	fec1 1a8b 	vmaxnm.f32	s3, s3, s22
d008266e:	ed9f 7a70 	vldr	s14, [pc, #448]	; d0082830 <speech_synth_render+0xc7c>
d0082672:	ed9f 3a70 	vldr	s6, [pc, #448]	; d0082834 <speech_synth_render+0xc80>
d0082676:	eddf da70 	vldr	s27, [pc, #448]	; d0082838 <speech_synth_render+0xc84>
d008267a:	eece 2a24 	vdiv.f32	s5, s28, s9
d008267e:	eddf 3a6f 	vldr	s7, [pc, #444]	; d008283c <speech_synth_render+0xc88>
d0082682:	ed9f da6f 	vldr	s26, [pc, #444]	; d0082840 <speech_synth_render+0xc8c>
d0082686:	ed9f 8a6f 	vldr	s16, [pc, #444]	; d0082844 <speech_synth_render+0xc90>
d008268a:	ed9f 0a6f 	vldr	s0, [pc, #444]	; d0082848 <speech_synth_render+0xc94>
d008268e:	9b05      	ldr	r3, [sp, #20]
d0082690:	ee26 6a01 	vmul.f32	s12, s12, s2
d0082694:	9a02      	ldr	r2, [sp, #8]
d0082696:	eeb0 1a65 	vmov.f32	s2, s11
d008269a:	33ff      	adds	r3, #255	; 0xff
d008269c:	eef0 4a6e 	vmov.f32	s9, s29
d00826a0:	3201      	adds	r2, #1
d00826a2:	eef0 0a6a 	vmov.f32	s1, s21
d00826a6:	9305      	str	r3, [sp, #20]
d00826a8:	eeaa 4a26 	vfma.f32	s8, s20, s13
d00826ac:	4b67      	ldr	r3, [pc, #412]	; (d008284c <speech_synth_render+0xc98>)
d00826ae:	eee5 4a2f 	vfma.f32	s9, s10, s31
d00826b2:	9202      	str	r2, [sp, #8]
d00826b4:	fe82 2a6b 	vminnm.f32	s4, s4, s23
d00826b8:	fe82 2a0b 	vmaxnm.f32	s4, s4, s22
d00826bc:	eea2 1a6f 	vfms.f32	s2, s4, s31
d00826c0:	429a      	cmp	r2, r3
d00826c2:	eee9 0ae1 	vfms.f32	s1, s19, s3
d00826c6:	9900      	ldr	r1, [sp, #0]
d00826c8:	eea9 faa6 	vfma.f32	s30, s19, s13
d00826cc:	980f      	ldr	r0, [sp, #60]	; 0x3c
d00826ce:	eeba ea00 	vmov.f32	s28, #160	; 0xc1000000 -8.0
d00826d2:	f101 0101 	add.w	r1, r1, #1
d00826d6:	fec2 2aeb 	vminnm.f32	s5, s5, s23
d00826da:	fec2 2a8b 	vmaxnm.f32	s5, s5, s22
d00826de:	eeea 5a62 	vfms.f32	s11, s20, s5
d00826e2:	bf88      	it	hi
d00826e4:	2300      	movhi	r3, #0
d00826e6:	eeb0 2a41 	vmov.f32	s4, s2
d00826ea:	ed9f 1a59 	vldr	s2, [pc, #356]	; d0082850 <speech_synth_render+0xc9c>
d00826ee:	eef0 1a60 	vmov.f32	s3, s1
d00826f2:	eddf 0a58 	vldr	s1, [pc, #352]	; d0082854 <speech_synth_render+0xca0>
d00826f6:	ee2a 7a87 	vmul.f32	s14, s21, s14
d00826fa:	bf98      	it	ls
d00826fc:	2301      	movls	r3, #1
d00826fe:	ee72 2a64 	vsub.f32	s5, s4, s9
d0082702:	ed9f 2a55 	vldr	s4, [pc, #340]	; d0082858 <speech_synth_render+0xca4>
d0082706:	9100      	str	r1, [sp, #0]
d0082708:	ee75 5ac4 	vsub.f32	s11, s11, s8
d008270c:	eee2 fa85 	vfma.f32	s31, s5, s10
d0082710:	eddf 2a52 	vldr	s5, [pc, #328]	; d008285c <speech_synth_render+0xca8>
d0082714:	eeb2 5a00 	vmov.f32	s10, #32	; 0x41000000  8.0
d0082718:	eea5 aaa6 	vfma.f32	s20, s11, s13
d008271c:	eea8 7a86 	vfma.f32	s14, s17, s12
d0082720:	ee31 6acf 	vsub.f32	s12, s3, s30
d0082724:	eddf 1a4e 	vldr	s3, [pc, #312]	; d0082860 <speech_synth_render+0xcac>
d0082728:	eef7 5a00 	vmov.f32	s11, #112	; 0x3f800000  1.0
d008272c:	fe8f fa45 	vminnm.f32	s30, s30, s10
d0082730:	fecf fac5 	vminnm.f32	s31, s31, s10
d0082734:	fecf fa8e 	vmaxnm.f32	s31, s31, s28
d0082738:	ee2f 3a83 	vmul.f32	s6, s31, s6
d008273c:	fec4 eac5 	vminnm.f32	s29, s9, s10
d0082740:	eee6 9a86 	vfma.f32	s19, s13, s12
d0082744:	ee06 9a10 	vmov	s12, r9
d0082748:	fe8a aa45 	vminnm.f32	s20, s20, s10
d008274c:	fe8a aa0e 	vmaxnm.f32	s20, s20, s28
d0082750:	eea9 3a2d 	vfma.f32	s6, s18, s27
d0082754:	eddd 6a04 	vldr	s13, [sp, #16]
d0082758:	eeb8 6a46 	vcvt.f32.u32	s12, s12
d008275c:	fe84 4a45 	vminnm.f32	s8, s8, s10
d0082760:	ee6a 3a23 	vmul.f32	s7, s20, s7
d0082764:	fe8f fa0e 	vmaxnm.f32	s30, s30, s28
d0082768:	eef8 6a66 	vcvt.f32.u32	s13, s13
d008276c:	fece ea8e 	vmaxnm.f32	s29, s29, s28
d0082770:	fec9 9ac5 	vminnm.f32	s19, s19, s10
d0082774:	fec9 9a8e 	vmaxnm.f32	s19, s19, s28
d0082778:	eee9 3a8d 	vfma.f32	s7, s19, s26
d008277c:	fe84 4a0e 	vmaxnm.f32	s8, s8, s28
d0082780:	eea6 7a03 	vfma.f32	s14, s12, s6
d0082784:	eea3 7aa6 	vfma.f32	s14, s7, s13
d0082788:	eddd 6a10 	vldr	s13, [sp, #64]	; 0x40
d008278c:	ee77 6a66 	vsub.f32	s13, s14, s13
d0082790:	ee26 8a88 	vmul.f32	s16, s13, s16
d0082794:	eea7 8a00 	vfma.f32	s16, s14, s0
d0082798:	ee68 0a20 	vmul.f32	s1, s16, s1
d008279c:	eef0 6ae0 	vabs.f32	s13, s1
d00827a0:	eee6 5a81 	vfma.f32	s11, s13, s2
d00827a4:	eec0 6aa5 	vdiv.f32	s13, s1, s11
d00827a8:	fec6 6ae1 	vminnm.f32	s13, s13, s3
d00827ac:	fec6 6a82 	vmaxnm.f32	s13, s13, s4
d00827b0:	ee66 2aa2 	vmul.f32	s5, s13, s5
d00827b4:	eefd 2ae2 	vcvt.s32.f32	s5, s5
d00827b8:	ee12 2a90 	vmov	r2, s5
d00827bc:	3a80      	subs	r2, #128	; 0x80
d00827be:	f800 2f01 	strb.w	r2, [r0, #1]!
d00827c2:	9a0d      	ldr	r2, [sp, #52]	; 0x34
d00827c4:	900f      	str	r0, [sp, #60]	; 0x3c
d00827c6:	428a      	cmp	r2, r1
d00827c8:	f240 8142 	bls.w	d0082a50 <speech_synth_render+0xe9c>
d00827cc:	2b00      	cmp	r3, #0
d00827ce:	f000 813f 	beq.w	d0082a50 <speech_synth_render+0xe9c>
d00827d2:	e051      	b.n	d0082878 <speech_synth_render+0xcc4>
d00827d4:	110d3800 	.word	0x110d3800
d00827d8:	435ec000 	.word	0x435ec000
d00827dc:	44148000 	.word	0x44148000
d00827e0:	43948000 	.word	0x43948000
d00827e4:	42e70000 	.word	0x42e70000
d00827e8:	43d68000 	.word	0x43d68000
d00827ec:	431cc000 	.word	0x431cc000
d00827f0:	44460000 	.word	0x44460000
d00827f4:	4401f000 	.word	0x4401f000
d00827f8:	447fc000 	.word	0x447fc000
d00827fc:	4422f000 	.word	0x4422f000
d0082800:	47147ae1 	.word	0x47147ae1
d0082804:	37800000 	.word	0x37800000
d0082808:	4751eb85 	.word	0x4751eb85
d008280c:	00000000 	.word	0x00000000
d0082810:	3aaec33f 	.word	0x3aaec33f
d0082814:	3da3d70a 	.word	0x3da3d70a
d0082818:	3df5c28f 	.word	0x3df5c28f
d008281c:	3403126f 	.word	0x3403126f
d0082820:	3e6b851f 	.word	0x3e6b851f
d0082824:	39cde32f 	.word	0x39cde32f
d0082828:	3fe8f5c3 	.word	0x3fe8f5c3
d008282c:	3c1c09c1 	.word	0x3c1c09c1
d0082830:	3e23d70a 	.word	0x3e23d70a
d0082834:	3b360b61 	.word	0x3b360b61
d0082838:	3c088889 	.word	0x3c088889
d008283c:	3b46980c 	.word	0x3b46980c
d0082840:	3bd3680d 	.word	0x3bd3680d
d0082844:	3ec28f5c 	.word	0x3ec28f5c
d0082848:	3f866666 	.word	0x3f866666
d008284c:	0002edff 	.word	0x0002edff
d0082850:	3ed70a3d 	.word	0x3ed70a3d
d0082854:	3faccccd 	.word	0x3faccccd
d0082858:	bf7ae148 	.word	0xbf7ae148
d008285c:	42f60000 	.word	0x42f60000
d0082860:	3f7ae148 	.word	0x3f7ae148
d0082864:	42948000 	.word	0x42948000
d0082868:	438c4000 	.word	0x438c4000
d008286c:	43bdc000 	.word	0x43bdc000
d0082870:	4420e000 	.word	0x4420e000
d0082874:	444a2000 	.word	0x444a2000
d0082878:	9a18      	ldr	r2, [sp, #96]	; 0x60
d008287a:	eeb0 da67 	vmov.f32	s26, s15
d008287e:	ed8d 7a10 	vstr	s14, [sp, #64]	; 0x40
d0082882:	2a00      	cmp	r2, #0
d0082884:	f47f ad0b 	bne.w	d008229e <speech_synth_render+0x6ea>
d0082888:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d008288a:	f8dd 9028 	ldr.w	r9, [sp, #40]	; 0x28
d008288e:	9304      	str	r3, [sp, #16]
d0082890:	9e08      	ldr	r6, [sp, #32]
d0082892:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0082894:	f8dd 801c 	ldr.w	r8, [sp, #28]
d0082898:	9d06      	ldr	r5, [sp, #24]
d008289a:	9c0c      	ldr	r4, [sp, #48]	; 0x30
d008289c:	9f01      	ldr	r7, [sp, #4]
d008289e:	9303      	str	r3, [sp, #12]
d00828a0:	9b11      	ldr	r3, [sp, #68]	; 0x44
d00828a2:	f893 a00e 	ldrb.w	sl, [r3, #14]
d00828a6:	f1a7 0315 	sub.w	r3, r7, #21
d00828aa:	b2db      	uxtb	r3, r3
d00828ac:	f00a 0a01 	and.w	sl, sl, #1
d00828b0:	2b02      	cmp	r3, #2
d00828b2:	f63f ad9b 	bhi.w	d00823ec <speech_synth_render+0x838>
d00828b6:	ed5f 4a15 	vldr	s9, [pc, #-84]	; d0082864 <speech_synth_render+0xcb0>
d00828ba:	ed1f 5a15 	vldr	s10, [pc, #-84]	; d0082868 <speech_synth_render+0xcb4>
d00828be:	ed1f 8a15 	vldr	s16, [pc, #-84]	; d008286c <speech_synth_render+0xcb8>
d00828c2:	ed5f da15 	vldr	s27, [pc, #-84]	; d0082870 <speech_synth_render+0xcbc>
d00828c6:	ed1f ea15 	vldr	s28, [pc, #-84]	; d0082874 <speech_synth_render+0xcc0>
d00828ca:	e5c2      	b.n	d0082452 <speech_synth_render+0x89e>
d00828cc:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d00828d0:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00828d4:	d219      	bcs.n	d008290a <speech_synth_render+0xd56>
d00828d6:	200c      	movs	r0, #12
d00828d8:	9e12      	ldr	r6, [sp, #72]	; 0x48
d00828da:	1c59      	adds	r1, r3, #1
d00828dc:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d00828e0:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d00828e4:	2358      	movs	r3, #88	; 0x58
d00828e6:	48c9      	ldr	r0, [pc, #804]	; (d0082c0c <speech_synth_render+0x1058>)
d00828e8:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d00828ec:	8053      	strh	r3, [r2, #2]
d00828ee:	f001 fba8 	bl	d0084042 <strlen>
d00828f2:	1d02      	adds	r2, r0, #4
d00828f4:	4603      	mov	r3, r0
d00828f6:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00828fa:	d206      	bcs.n	d008290a <speech_synth_render+0xd56>
d00828fc:	bba8      	cbnz	r0, d008296a <speech_synth_render+0xdb6>
d00828fe:	4ac3      	ldr	r2, [pc, #780]	; (d0082c0c <speech_synth_render+0x1058>)
d0082900:	49c3      	ldr	r1, [pc, #780]	; (d0082c10 <speech_synth_render+0x105c>)
d0082902:	18d0      	adds	r0, r2, r3
d0082904:	2203      	movs	r2, #3
d0082906:	f001 f9ff 	bl	d0083d08 <memcpy>
d008290a:	3503      	adds	r5, #3
d008290c:	b2ad      	uxth	r5, r5
d008290e:	f7ff bb59 	b.w	d0081fc4 <speech_synth_render+0x410>
d0082912:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0082916:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008291a:	d222      	bcs.n	d0082962 <speech_synth_render+0xdae>
d008291c:	200c      	movs	r0, #12
d008291e:	9e12      	ldr	r6, [sp, #72]	; 0x48
d0082920:	1c59      	adds	r1, r3, #1
d0082922:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0082926:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d008292a:	2358      	movs	r3, #88	; 0x58
d008292c:	48b7      	ldr	r0, [pc, #732]	; (d0082c0c <speech_synth_render+0x1058>)
d008292e:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d0082932:	8053      	strh	r3, [r2, #2]
d0082934:	f001 fb85 	bl	d0084042 <strlen>
d0082938:	1d02      	adds	r2, r0, #4
d008293a:	4603      	mov	r3, r0
d008293c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082940:	d20f      	bcs.n	d0082962 <speech_synth_render+0xdae>
d0082942:	b140      	cbz	r0, d0082956 <speech_synth_render+0xda2>
d0082944:	4eb1      	ldr	r6, [pc, #708]	; (d0082c0c <speech_synth_render+0x1058>)
d0082946:	2120      	movs	r1, #32
d0082948:	1832      	adds	r2, r6, r0
d008294a:	4630      	mov	r0, r6
d008294c:	54f1      	strb	r1, [r6, r3]
d008294e:	7057      	strb	r7, [r2, #1]
d0082950:	f001 fb77 	bl	d0084042 <strlen>
d0082954:	4603      	mov	r3, r0
d0082956:	4aad      	ldr	r2, [pc, #692]	; (d0082c0c <speech_synth_render+0x1058>)
d0082958:	49ad      	ldr	r1, [pc, #692]	; (d0082c10 <speech_synth_render+0x105c>)
d008295a:	18d0      	adds	r0, r2, r3
d008295c:	2203      	movs	r2, #3
d008295e:	f001 f9d3 	bl	d0083d08 <memcpy>
d0082962:	3502      	adds	r5, #2
d0082964:	b2ad      	uxth	r5, r5
d0082966:	f7ff bb2d 	b.w	d0081fc4 <speech_synth_render+0x410>
d008296a:	4ea8      	ldr	r6, [pc, #672]	; (d0082c0c <speech_synth_render+0x1058>)
d008296c:	2120      	movs	r1, #32
d008296e:	1832      	adds	r2, r6, r0
d0082970:	4630      	mov	r0, r6
d0082972:	54f1      	strb	r1, [r6, r3]
d0082974:	7057      	strb	r7, [r2, #1]
d0082976:	f001 fb64 	bl	d0084042 <strlen>
d008297a:	4603      	mov	r3, r0
d008297c:	e7bf      	b.n	d00828fe <speech_synth_render+0xd4a>
d008297e:	2f11      	cmp	r7, #17
d0082980:	eddf 5aa4 	vldr	s11, [pc, #656]	; d0082c14 <speech_synth_render+0x1060>
d0082984:	f47f add1 	bne.w	d008252a <speech_synth_render+0x976>
d0082988:	ea8b 3b4b 	eor.w	fp, fp, fp, lsl #13
d008298c:	eddf 3aa2 	vldr	s7, [pc, #648]	; d0082c18 <speech_synth_render+0x1064>
d0082990:	e5d3      	b.n	d008253a <speech_synth_render+0x986>
d0082992:	eddf 6aa2 	vldr	s13, [pc, #648]	; d0082c1c <speech_synth_render+0x1068>
d0082996:	e662      	b.n	d008265e <speech_synth_render+0xaaa>
d0082998:	ed9f 5aa0 	vldr	s10, [pc, #640]	; d0082c1c <speech_synth_render+0x1068>
d008299c:	e62b      	b.n	d00825f6 <speech_synth_render+0xa42>
d008299e:	eddf 4a9f 	vldr	s9, [pc, #636]	; d0082c1c <speech_synth_render+0x1068>
d00829a2:	e5f4      	b.n	d008258e <speech_synth_render+0x9da>
d00829a4:	eddf 6a9b 	vldr	s13, [pc, #620]	; d0082c14 <speech_synth_render+0x1060>
d00829a8:	e5d3      	b.n	d0082552 <speech_synth_render+0x99e>
d00829aa:	ed9f 7a9d 	vldr	s14, [pc, #628]	; d0082c20 <speech_synth_render+0x106c>
d00829ae:	ee77 3acd 	vsub.f32	s7, s15, s26
d00829b2:	eddd 6a03 	vldr	s13, [sp, #12]
d00829b6:	ee27 7a87 	vmul.f32	s14, s15, s14
d00829ba:	eddf 5a9a 	vldr	s11, [pc, #616]	; d0082c24 <speech_synth_render+0x1070>
d00829be:	eeb8 6a66 	vcvt.f32.u32	s12, s13
d00829c2:	eddf 6a99 	vldr	s13, [pc, #612]	; d0082c28 <speech_synth_render+0x1074>
d00829c6:	eea3 7aa5 	vfma.f32	s14, s7, s11
d00829ca:	ee66 6a26 	vmul.f32	s13, s12, s13
d00829ce:	ee26 7a87 	vmul.f32	s14, s13, s14
d00829d2:	e57d      	b.n	d00824d0 <speech_synth_render+0x91c>
d00829d4:	eddf 7a95 	vldr	s15, [pc, #596]	; d0082c2c <speech_synth_render+0x1078>
d00829d8:	eef0 5a00 	vmov.f32	s11, #0	; 0x40000000  2.0
d00829dc:	eddf 3a94 	vldr	s7, [pc, #592]	; d0082c30 <speech_synth_render+0x107c>
d00829e0:	eeb8 6a08 	vmov.f32	s12, #136	; 0xc0400000 -3.0
d00829e4:	ee37 7a67 	vsub.f32	s14, s14, s15
d00829e8:	eef7 7a00 	vmov.f32	s15, #112	; 0x3f800000  1.0
d00829ec:	ee27 7a23 	vmul.f32	s14, s14, s7
d00829f0:	eea7 6a25 	vfma.f32	s12, s14, s11
d00829f4:	ee27 7a07 	vmul.f32	s14, s14, s14
d00829f8:	eee6 7a07 	vfma.f32	s15, s12, s14
d00829fc:	e55e      	b.n	d00824bc <speech_synth_render+0x908>
d00829fe:	eddf 5a8d 	vldr	s11, [pc, #564]	; d0082c34 <speech_synth_render+0x1080>
d0082a02:	eeb0 6a00 	vmov.f32	s12, #0	; 0x40000000  2.0
d0082a06:	eef0 7a08 	vmov.f32	s15, #8	; 0x40400000  3.0
d0082a0a:	ee27 7a25 	vmul.f32	s14, s14, s11
d0082a0e:	eee7 7a46 	vfms.f32	s15, s14, s12
d0082a12:	ee27 7a07 	vmul.f32	s14, s14, s14
d0082a16:	ee67 7a27 	vmul.f32	s15, s14, s15
d0082a1a:	e54f      	b.n	d00824bc <speech_synth_render+0x908>
d0082a1c:	f641 0221 	movw	r2, #6177	; 0x1821
d0082a20:	fa22 f303 	lsr.w	r3, r2, r3
d0082a24:	07d9      	lsls	r1, r3, #31
d0082a26:	d557      	bpl.n	d0082ad8 <speech_synth_render+0xf24>
d0082a28:	eddf 4a83 	vldr	s9, [pc, #524]	; d0082c38 <speech_synth_render+0x1084>
d0082a2c:	ed9f 5a83 	vldr	s10, [pc, #524]	; d0082c3c <speech_synth_render+0x1088>
d0082a30:	ed9f 8a83 	vldr	s16, [pc, #524]	; d0082c40 <speech_synth_render+0x108c>
d0082a34:	eddf da83 	vldr	s27, [pc, #524]	; d0082c44 <speech_synth_render+0x1090>
d0082a38:	ed9f ea83 	vldr	s28, [pc, #524]	; d0082c48 <speech_synth_render+0x1094>
d0082a3c:	e509      	b.n	d0082452 <speech_synth_render+0x89e>
d0082a3e:	9a22      	ldr	r2, [sp, #136]	; 0x88
d0082a40:	4293      	cmp	r3, r2
d0082a42:	f67f ad61 	bls.w	d0082508 <speech_synth_render+0x954>
d0082a46:	eddf 5a81 	vldr	s11, [pc, #516]	; d0082c4c <speech_synth_render+0x1098>
d0082a4a:	ee66 6aa5 	vmul.f32	s13, s13, s11
d0082a4e:	e55b      	b.n	d0082508 <speech_synth_render+0x954>
d0082a50:	eef0 4a6e 	vmov.f32	s9, s29
d0082a54:	b133      	cbz	r3, d0082a64 <speech_synth_render+0xeb0>
d0082a56:	9b0e      	ldr	r3, [sp, #56]	; 0x38
d0082a58:	9a24      	ldr	r2, [sp, #144]	; 0x90
d0082a5a:	3301      	adds	r3, #1
d0082a5c:	4293      	cmp	r3, r2
d0082a5e:	930e      	str	r3, [sp, #56]	; 0x38
d0082a60:	f47f ab9c 	bne.w	d008219c <speech_synth_render+0x5e8>
d0082a64:	9b25      	ldr	r3, [sp, #148]	; 0x94
d0082a66:	f8dd a008 	ldr.w	sl, [sp, #8]
d0082a6a:	f8c3 b000 	str.w	fp, [r3]
d0082a6e:	4b78      	ldr	r3, [pc, #480]	; (d0082c50 <speech_synth_render+0x109c>)
d0082a70:	4650      	mov	r0, sl
d0082a72:	f8c3 a000 	str.w	sl, [r3]
d0082a76:	b035      	add	sp, #212	; 0xd4
d0082a78:	ecbd 8b10 	vpop	{d8-d15}
d0082a7c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0082a80:	2100      	movs	r1, #0
d0082a82:	4603      	mov	r3, r0
d0082a84:	9117      	str	r1, [sp, #92]	; 0x5c
d0082a86:	f7ff bb9a 	b.w	d00821be <speech_synth_render+0x60a>
d0082a8a:	9a02      	ldr	r2, [sp, #8]
d0082a8c:	4c71      	ldr	r4, [pc, #452]	; (d0082c54 <speech_synth_render+0x10a0>)
d0082a8e:	4613      	mov	r3, r2
d0082a90:	42a2      	cmp	r2, r4
d0082a92:	bf8c      	ite	hi
d0082a94:	2300      	movhi	r3, #0
d0082a96:	2301      	movls	r3, #1
d0082a98:	f5b6 7f7a 	cmp.w	r6, #1000	; 0x3e8
d0082a9c:	d370      	bcc.n	d0082b80 <speech_synth_render+0xfcc>
d0082a9e:	2b00      	cmp	r3, #0
d0082aa0:	d06e      	beq.n	d0082b80 <speech_synth_render+0xfcc>
d0082aa2:	1e51      	subs	r1, r2, #1
d0082aa4:	4d6c      	ldr	r5, [pc, #432]	; (d0082c58 <speech_synth_render+0x10a4>)
d0082aa6:	4613      	mov	r3, r2
d0082aa8:	4610      	mov	r0, r2
d0082aaa:	4429      	add	r1, r5
d0082aac:	2680      	movs	r6, #128	; 0x80
d0082aae:	9f0d      	ldr	r7, [sp, #52]	; 0x34
d0082ab0:	4694      	mov	ip, r2
d0082ab2:	e000      	b.n	d0082ab6 <speech_synth_render+0xf02>
d0082ab4:	b173      	cbz	r3, d0082ad4 <speech_synth_render+0xf20>
d0082ab6:	460a      	mov	r2, r1
d0082ab8:	3001      	adds	r0, #1
d0082aba:	f801 6f01 	strb.w	r6, [r1, #1]!
d0082abe:	3202      	adds	r2, #2
d0082ac0:	42a0      	cmp	r0, r4
d0082ac2:	eba2 0205 	sub.w	r2, r2, r5
d0082ac6:	bf8c      	ite	hi
d0082ac8:	2300      	movhi	r3, #0
d0082aca:	2301      	movls	r3, #1
d0082acc:	eba2 020c 	sub.w	r2, r2, ip
d0082ad0:	4297      	cmp	r7, r2
d0082ad2:	d8ef      	bhi.n	d0082ab4 <speech_synth_render+0xf00>
d0082ad4:	9002      	str	r0, [sp, #8]
d0082ad6:	e7bd      	b.n	d0082a54 <speech_synth_render+0xea0>
d0082ad8:	f1a7 030e 	sub.w	r3, r7, #14
d0082adc:	b2db      	uxtb	r3, r3
d0082ade:	4a5f      	ldr	r2, [pc, #380]	; (d0082c5c <speech_synth_render+0x10a8>)
d0082ae0:	fa22 f303 	lsr.w	r3, r2, r3
d0082ae4:	07da      	lsls	r2, r3, #31
d0082ae6:	f57f ac8d 	bpl.w	d0082404 <speech_synth_render+0x850>
d0082aea:	eddf 4a5d 	vldr	s9, [pc, #372]	; d0082c60 <speech_synth_render+0x10ac>
d0082aee:	ed9f 5a5d 	vldr	s10, [pc, #372]	; d0082c64 <speech_synth_render+0x10b0>
d0082af2:	ed9f 8a55 	vldr	s16, [pc, #340]	; d0082c48 <speech_synth_render+0x1094>
d0082af6:	eddf da5c 	vldr	s27, [pc, #368]	; d0082c68 <speech_synth_render+0x10b4>
d0082afa:	ed9f ea5c 	vldr	s28, [pc, #368]	; d0082c6c <speech_synth_render+0x10b8>
d0082afe:	e4a8      	b.n	d0082452 <speech_synth_render+0x89e>
d0082b00:	9623      	str	r6, [sp, #140]	; 0x8c
d0082b02:	4a5b      	ldr	r2, [pc, #364]	; (d0082c70 <speech_synth_render+0x10bc>)
d0082b04:	2180      	movs	r1, #128	; 0x80
d0082b06:	4854      	ldr	r0, [pc, #336]	; (d0082c58 <speech_synth_render+0x10a4>)
d0082b08:	f001 f90c 	bl	d0083d24 <memset>
d0082b0c:	2238      	movs	r2, #56	; 0x38
d0082b0e:	a826      	add	r0, sp, #152	; 0x98
d0082b10:	2100      	movs	r1, #0
d0082b12:	f001 f907 	bl	d0083d24 <memset>
d0082b16:	4b57      	ldr	r3, [pc, #348]	; (d0082c74 <speech_synth_render+0x10c0>)
d0082b18:	461a      	mov	r2, r3
d0082b1a:	9325      	str	r3, [sp, #148]	; 0x94
d0082b1c:	4b56      	ldr	r3, [pc, #344]	; (d0082c78 <speech_synth_render+0x10c4>)
d0082b1e:	6013      	str	r3, [r2, #0]
d0082b20:	f7ff bb10 	b.w	d0082144 <speech_synth_render+0x590>
d0082b24:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0082b28:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082b2c:	f4bf af19 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082b30:	201b      	movs	r0, #27
d0082b32:	9e12      	ldr	r6, [sp, #72]	; 0x48
d0082b34:	1c59      	adds	r1, r3, #1
d0082b36:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0082b3a:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0082b3e:	2358      	movs	r3, #88	; 0x58
d0082b40:	4832      	ldr	r0, [pc, #200]	; (d0082c0c <speech_synth_render+0x1058>)
d0082b42:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d0082b46:	8053      	strh	r3, [r2, #2]
d0082b48:	f001 fa7b 	bl	d0084042 <strlen>
d0082b4c:	1d02      	adds	r2, r0, #4
d0082b4e:	4603      	mov	r3, r0
d0082b50:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082b54:	f4bf af05 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082b58:	b140      	cbz	r0, d0082b6c <speech_synth_render+0xfb8>
d0082b5a:	4e2c      	ldr	r6, [pc, #176]	; (d0082c0c <speech_synth_render+0x1058>)
d0082b5c:	2120      	movs	r1, #32
d0082b5e:	1832      	adds	r2, r6, r0
d0082b60:	4630      	mov	r0, r6
d0082b62:	54f1      	strb	r1, [r6, r3]
d0082b64:	7057      	strb	r7, [r2, #1]
d0082b66:	f001 fa6c 	bl	d0084042 <strlen>
d0082b6a:	4603      	mov	r3, r0
d0082b6c:	4a27      	ldr	r2, [pc, #156]	; (d0082c0c <speech_synth_render+0x1058>)
d0082b6e:	3502      	adds	r5, #2
d0082b70:	4942      	ldr	r1, [pc, #264]	; (d0082c7c <speech_synth_render+0x10c8>)
d0082b72:	18d0      	adds	r0, r2, r3
d0082b74:	2203      	movs	r2, #3
d0082b76:	b2ad      	uxth	r5, r5
d0082b78:	f001 f8c6 	bl	d0083d08 <memcpy>
d0082b7c:	f7ff ba22 	b.w	d0081fc4 <speech_synth_render+0x410>
d0082b80:	9802      	ldr	r0, [sp, #8]
d0082b82:	9002      	str	r0, [sp, #8]
d0082b84:	e766      	b.n	d0082a54 <speech_synth_render+0xea0>
d0082b86:	9b00      	ldr	r3, [sp, #0]
d0082b88:	4453      	add	r3, sl
d0082b8a:	9301      	str	r3, [sp, #4]
d0082b8c:	f7ff b881 	b.w	d0081c92 <speech_synth_render+0xde>
d0082b90:	f8dd b004 	ldr.w	fp, [sp, #4]
d0082b94:	4654      	mov	r4, sl
d0082b96:	f7ff b854 	b.w	d0081c42 <speech_synth_render+0x8e>
d0082b9a:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0082b9e:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082ba2:	f4bf aede 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082ba6:	201d      	movs	r0, #29
d0082ba8:	9e12      	ldr	r6, [sp, #72]	; 0x48
d0082baa:	1c59      	adds	r1, r3, #1
d0082bac:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0082bb0:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0082bb4:	234a      	movs	r3, #74	; 0x4a
d0082bb6:	4815      	ldr	r0, [pc, #84]	; (d0082c0c <speech_synth_render+0x1058>)
d0082bb8:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d0082bbc:	8053      	strh	r3, [r2, #2]
d0082bbe:	f001 fa40 	bl	d0084042 <strlen>
d0082bc2:	1d02      	adds	r2, r0, #4
d0082bc4:	4603      	mov	r3, r0
d0082bc6:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082bca:	f4bf aeca 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082bce:	b140      	cbz	r0, d0082be2 <speech_synth_render+0x102e>
d0082bd0:	4e0e      	ldr	r6, [pc, #56]	; (d0082c0c <speech_synth_render+0x1058>)
d0082bd2:	2120      	movs	r1, #32
d0082bd4:	1832      	adds	r2, r6, r0
d0082bd6:	4630      	mov	r0, r6
d0082bd8:	54f1      	strb	r1, [r6, r3]
d0082bda:	7057      	strb	r7, [r2, #1]
d0082bdc:	f001 fa31 	bl	d0084042 <strlen>
d0082be0:	4603      	mov	r3, r0
d0082be2:	4a0a      	ldr	r2, [pc, #40]	; (d0082c0c <speech_synth_render+0x1058>)
d0082be4:	3502      	adds	r5, #2
d0082be6:	4926      	ldr	r1, [pc, #152]	; (d0082c80 <speech_synth_render+0x10cc>)
d0082be8:	18d0      	adds	r0, r2, r3
d0082bea:	2203      	movs	r2, #3
d0082bec:	b2ad      	uxth	r5, r5
d0082bee:	f001 f88b 	bl	d0083d08 <memcpy>
d0082bf2:	f7ff b9e7 	b.w	d0081fc4 <speech_synth_render+0x410>
d0082bf6:	eddf 4a23 	vldr	s9, [pc, #140]	; d0082c84 <speech_synth_render+0x10d0>
d0082bfa:	ed9f 5a23 	vldr	s10, [pc, #140]	; d0082c88 <speech_synth_render+0x10d4>
d0082bfe:	ed9f 8a23 	vldr	s16, [pc, #140]	; d0082c8c <speech_synth_render+0x10d8>
d0082c02:	eddf da23 	vldr	s27, [pc, #140]	; d0082c90 <speech_synth_render+0x10dc>
d0082c06:	ed9f ea23 	vldr	s28, [pc, #140]	; d0082c94 <speech_synth_render+0x10e0>
d0082c0a:	e422      	b.n	d0082452 <speech_synth_render+0x89e>
d0082c0c:	d00b4540 	.word	0xd00b4540
d0082c10:	d0084634 	.word	0xd0084634
d0082c14:	00000000 	.word	0x00000000
d0082c18:	35e147ae 	.word	0x35e147ae
d0082c1c:	3d0f5c29 	.word	0x3d0f5c29
d0082c20:	3eeb851f 	.word	0x3eeb851f
d0082c24:	40b66666 	.word	0x40b66666
d0082c28:	3b808081 	.word	0x3b808081
d0082c2c:	3f147ae1 	.word	0x3f147ae1
d0082c30:	40855556 	.word	0x40855556
d0082c34:	3fdcb08e 	.word	0x3fdcb08e
d0082c38:	43040000 	.word	0x43040000
d0082c3c:	43460000 	.word	0x43460000
d0082c40:	43840000 	.word	0x43840000
d0082c44:	440c4000 	.word	0x440c4000
d0082c48:	442d4000 	.word	0x442d4000
d0082c4c:	3f51eb85 	.word	0x3f51eb85
d0082c50:	d0085728 	.word	0xd0085728
d0082c54:	0002edff 	.word	0x0002edff
d0082c58:	d0085740 	.word	0xd0085740
d0082c5c:	0019b003 	.word	0x0019b003
d0082c60:	43b58000 	.word	0x43b58000
d0082c64:	43f78000 	.word	0x43f78000
d0082c68:	44568000 	.word	0x44568000
d0082c6c:	448c4000 	.word	0x448c4000
d0082c70:	0002ee00 	.word	0x0002ee00
d0082c74:	d0084aac 	.word	0xd0084aac
d0082c78:	1234abcd 	.word	0x1234abcd
d0082c7c:	d0084640 	.word	0xd0084640
d0082c80:	d0084648 	.word	0xd0084648
d0082c84:	42e70000 	.word	0x42e70000
d0082c88:	431cc000 	.word	0x431cc000
d0082c8c:	435ec000 	.word	0x435ec000
d0082c90:	4401f000 	.word	0x4401f000
d0082c94:	4422f000 	.word	0x4422f000
d0082c98:	f10b 32ff 	add.w	r2, fp, #4294967295	; 0xffffffff
d0082c9c:	f8df 8378 	ldr.w	r8, [pc, #888]	; d0083018 <speech_synth_render+0x1464>
d0082ca0:	276b      	movs	r7, #107	; 0x6b
d0082ca2:	f8dd 9008 	ldr.w	r9, [sp, #8]
d0082ca6:	9004      	str	r0, [sp, #16]
d0082ca8:	e006      	b.n	d0082cb8 <speech_synth_render+0x1104>
d0082caa:	f818 7f01 	ldrb.w	r7, [r8, #1]!
d0082cae:	2f00      	cmp	r7, #0
d0082cb0:	f000 83bc 	beq.w	d008342c <speech_synth_render+0x1878>
d0082cb4:	454a      	cmp	r2, r9
d0082cb6:	d009      	beq.n	d0082ccc <speech_synth_render+0x1118>
d0082cb8:	f812 3f01 	ldrb.w	r3, [r2, #1]!
d0082cbc:	f1a3 0041 	sub.w	r0, r3, #65	; 0x41
d0082cc0:	2819      	cmp	r0, #25
d0082cc2:	d801      	bhi.n	d0082cc8 <speech_synth_render+0x1114>
d0082cc4:	3320      	adds	r3, #32
d0082cc6:	b2db      	uxtb	r3, r3
d0082cc8:	42bb      	cmp	r3, r7
d0082cca:	d0ee      	beq.n	d0082caa <speech_synth_render+0x10f6>
d0082ccc:	9804      	ldr	r0, [sp, #16]
d0082cce:	f7ff b8e3 	b.w	d0081e98 <speech_synth_render+0x2e4>
d0082cd2:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0082cd6:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082cda:	f4bf ae42 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082cde:	200f      	movs	r0, #15
d0082ce0:	9e12      	ldr	r6, [sp, #72]	; 0x48
d0082ce2:	1c59      	adds	r1, r3, #1
d0082ce4:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0082ce8:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0082cec:	2348      	movs	r3, #72	; 0x48
d0082cee:	48bb      	ldr	r0, [pc, #748]	; (d0082fdc <speech_synth_render+0x1428>)
d0082cf0:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d0082cf4:	8053      	strh	r3, [r2, #2]
d0082cf6:	f001 f9a4 	bl	d0084042 <strlen>
d0082cfa:	1cc2      	adds	r2, r0, #3
d0082cfc:	4603      	mov	r3, r0
d0082cfe:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082d02:	f4bf ae2e 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082d06:	b140      	cbz	r0, d0082d1a <speech_synth_render+0x1166>
d0082d08:	4eb4      	ldr	r6, [pc, #720]	; (d0082fdc <speech_synth_render+0x1428>)
d0082d0a:	2120      	movs	r1, #32
d0082d0c:	1832      	adds	r2, r6, r0
d0082d0e:	4630      	mov	r0, r6
d0082d10:	54f1      	strb	r1, [r6, r3]
d0082d12:	7057      	strb	r7, [r2, #1]
d0082d14:	f001 f995 	bl	d0084042 <strlen>
d0082d18:	4603      	mov	r3, r0
d0082d1a:	4ab0      	ldr	r2, [pc, #704]	; (d0082fdc <speech_synth_render+0x1428>)
d0082d1c:	49b0      	ldr	r1, [pc, #704]	; (d0082fe0 <speech_synth_render+0x142c>)
d0082d1e:	18d0      	adds	r0, r2, r3
d0082d20:	2202      	movs	r2, #2
d0082d22:	f000 fff1 	bl	d0083d08 <memcpy>
d0082d26:	e61c      	b.n	d0082962 <speech_synth_render+0xdae>
d0082d28:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0082d2c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082d30:	f4bf ae17 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082d34:	201f      	movs	r0, #31
d0082d36:	9e12      	ldr	r6, [sp, #72]	; 0x48
d0082d38:	1c59      	adds	r1, r3, #1
d0082d3a:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0082d3e:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0082d42:	2352      	movs	r3, #82	; 0x52
d0082d44:	48a5      	ldr	r0, [pc, #660]	; (d0082fdc <speech_synth_render+0x1428>)
d0082d46:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d0082d4a:	8053      	strh	r3, [r2, #2]
d0082d4c:	f001 f979 	bl	d0084042 <strlen>
d0082d50:	1cc2      	adds	r2, r0, #3
d0082d52:	4603      	mov	r3, r0
d0082d54:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082d58:	f4bf ae03 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0082d5c:	b140      	cbz	r0, d0082d70 <speech_synth_render+0x11bc>
d0082d5e:	4e9f      	ldr	r6, [pc, #636]	; (d0082fdc <speech_synth_render+0x1428>)
d0082d60:	2120      	movs	r1, #32
d0082d62:	1832      	adds	r2, r6, r0
d0082d64:	4630      	mov	r0, r6
d0082d66:	54f1      	strb	r1, [r6, r3]
d0082d68:	7057      	strb	r7, [r2, #1]
d0082d6a:	f001 f96a 	bl	d0084042 <strlen>
d0082d6e:	4603      	mov	r3, r0
d0082d70:	4a9a      	ldr	r2, [pc, #616]	; (d0082fdc <speech_synth_render+0x1428>)
d0082d72:	499c      	ldr	r1, [pc, #624]	; (d0082fe4 <speech_synth_render+0x1430>)
d0082d74:	18d0      	adds	r0, r2, r3
d0082d76:	2202      	movs	r2, #2
d0082d78:	f000 ffc6 	bl	d0083d08 <memcpy>
d0082d7c:	e5f1      	b.n	d0082962 <speech_synth_render+0xdae>
d0082d7e:	4b9a      	ldr	r3, [pc, #616]	; (d0082fe8 <speech_synth_render+0x1434>)
d0082d80:	9623      	str	r6, [sp, #140]	; 0x8c
d0082d82:	9312      	str	r3, [sp, #72]	; 0x48
d0082d84:	e6bd      	b.n	d0082b02 <speech_synth_render+0xf4e>
d0082d86:	4a99      	ldr	r2, [pc, #612]	; (d0082fec <speech_synth_render+0x1438>)
d0082d88:	2180      	movs	r1, #128	; 0x80
d0082d8a:	4899      	ldr	r0, [pc, #612]	; (d0082ff0 <speech_synth_render+0x143c>)
d0082d8c:	46aa      	mov	sl, r5
d0082d8e:	f000 ffc9 	bl	d0083d24 <memset>
d0082d92:	4b98      	ldr	r3, [pc, #608]	; (d0082ff4 <speech_synth_render+0x1440>)
d0082d94:	4a98      	ldr	r2, [pc, #608]	; (d0082ff8 <speech_synth_render+0x1444>)
d0082d96:	601a      	str	r2, [r3, #0]
d0082d98:	e669      	b.n	d0082a6e <speech_synth_render+0xeba>
d0082d9a:	4608      	mov	r0, r1
d0082d9c:	462a      	mov	r2, r5
d0082d9e:	2300      	movs	r3, #0
d0082da0:	4f96      	ldr	r7, [pc, #600]	; (d0082ffc <speech_synth_render+0x1448>)
d0082da2:	e005      	b.n	d0082db0 <speech_synth_render+0x11fc>
d0082da4:	5dd8      	ldrb	r0, [r3, r7]
d0082da6:	2800      	cmp	r0, #0
d0082da8:	f000 83ff 	beq.w	d00835aa <speech_synth_render+0x19f6>
d0082dac:	42a2      	cmp	r2, r4
d0082dae:	da10      	bge.n	d0082dd2 <speech_synth_render+0x121e>
d0082db0:	f81b c002 	ldrb.w	ip, [fp, r2]
d0082db4:	3301      	adds	r3, #1
d0082db6:	f1ac 0e41 	sub.w	lr, ip, #65	; 0x41
d0082dba:	b29b      	uxth	r3, r3
d0082dbc:	f1be 0f19 	cmp.w	lr, #25
d0082dc0:	eb03 0205 	add.w	r2, r3, r5
d0082dc4:	d803      	bhi.n	d0082dce <speech_synth_render+0x121a>
d0082dc6:	f10c 0c20 	add.w	ip, ip, #32
d0082dca:	fa5f fc8c 	uxtb.w	ip, ip
d0082dce:	4584      	cmp	ip, r0
d0082dd0:	d0e8      	beq.n	d0082da4 <speech_synth_render+0x11f0>
d0082dd2:	4628      	mov	r0, r5
d0082dd4:	2300      	movs	r3, #0
d0082dd6:	4f8a      	ldr	r7, [pc, #552]	; (d0083000 <speech_synth_render+0x144c>)
d0082dd8:	e005      	b.n	d0082de6 <speech_synth_render+0x1232>
d0082dda:	5dd9      	ldrb	r1, [r3, r7]
d0082ddc:	2900      	cmp	r1, #0
d0082dde:	f000 83e4 	beq.w	d00835aa <speech_synth_render+0x19f6>
d0082de2:	42a0      	cmp	r0, r4
d0082de4:	da0e      	bge.n	d0082e04 <speech_synth_render+0x1250>
d0082de6:	f81b 2000 	ldrb.w	r2, [fp, r0]
d0082dea:	3301      	adds	r3, #1
d0082dec:	f1a2 0c41 	sub.w	ip, r2, #65	; 0x41
d0082df0:	b29b      	uxth	r3, r3
d0082df2:	f1bc 0f19 	cmp.w	ip, #25
d0082df6:	eb03 0005 	add.w	r0, r3, r5
d0082dfa:	d801      	bhi.n	d0082e00 <speech_synth_render+0x124c>
d0082dfc:	3220      	adds	r2, #32
d0082dfe:	b2d2      	uxtb	r2, r2
d0082e00:	428a      	cmp	r2, r1
d0082e02:	d0ea      	beq.n	d0082dda <speech_synth_render+0x1226>
d0082e04:	4629      	mov	r1, r5
d0082e06:	2061      	movs	r0, #97	; 0x61
d0082e08:	2300      	movs	r3, #0
d0082e0a:	4f7e      	ldr	r7, [pc, #504]	; (d0083004 <speech_synth_render+0x1450>)
d0082e0c:	f81b 2001 	ldrb.w	r2, [fp, r1]
d0082e10:	3301      	adds	r3, #1
d0082e12:	f1a2 0c41 	sub.w	ip, r2, #65	; 0x41
d0082e16:	b29b      	uxth	r3, r3
d0082e18:	f1bc 0f19 	cmp.w	ip, #25
d0082e1c:	eb03 0105 	add.w	r1, r3, r5
d0082e20:	d801      	bhi.n	d0082e26 <speech_synth_render+0x1272>
d0082e22:	3220      	adds	r2, #32
d0082e24:	b2d2      	uxtb	r2, r2
d0082e26:	4282      	cmp	r2, r0
d0082e28:	d103      	bne.n	d0082e32 <speech_synth_render+0x127e>
d0082e2a:	5dd8      	ldrb	r0, [r3, r7]
d0082e2c:	b1c0      	cbz	r0, d0082e60 <speech_synth_render+0x12ac>
d0082e2e:	42a1      	cmp	r1, r4
d0082e30:	dbec      	blt.n	d0082e0c <speech_synth_render+0x1258>
d0082e32:	2161      	movs	r1, #97	; 0x61
d0082e34:	2200      	movs	r2, #0
d0082e36:	4874      	ldr	r0, [pc, #464]	; (d0083008 <speech_synth_render+0x1454>)
d0082e38:	1953      	adds	r3, r2, r5
d0082e3a:	1c57      	adds	r7, r2, #1
d0082e3c:	42a3      	cmp	r3, r4
d0082e3e:	b2ba      	uxth	r2, r7
d0082e40:	f280 82e7 	bge.w	d0083412 <speech_synth_render+0x185e>
d0082e44:	f81b 3003 	ldrb.w	r3, [fp, r3]
d0082e48:	f1a3 0741 	sub.w	r7, r3, #65	; 0x41
d0082e4c:	2f19      	cmp	r7, #25
d0082e4e:	d801      	bhi.n	d0082e54 <speech_synth_render+0x12a0>
d0082e50:	3320      	adds	r3, #32
d0082e52:	b2db      	uxtb	r3, r3
d0082e54:	428b      	cmp	r3, r1
d0082e56:	f040 82dc 	bne.w	d0083412 <speech_synth_render+0x185e>
d0082e5a:	5c11      	ldrb	r1, [r2, r0]
d0082e5c:	2900      	cmp	r1, #0
d0082e5e:	d1eb      	bne.n	d0082e38 <speech_synth_render+0x1284>
d0082e60:	3502      	adds	r5, #2
d0082e62:	2200      	movs	r2, #0
d0082e64:	2104      	movs	r1, #4
d0082e66:	a826      	add	r0, sp, #152	; 0x98
d0082e68:	b2ad      	uxth	r5, r5
d0082e6a:	f7fd f959 	bl	d0080120 <emit_phone.constprop.0>
d0082e6e:	e005      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082e70:	2200      	movs	r2, #0
d0082e72:	2113      	movs	r1, #19
d0082e74:	a826      	add	r0, sp, #152	; 0x98
d0082e76:	b2b5      	uxth	r5, r6
d0082e78:	f7fd f952 	bl	d0080120 <emit_phone.constprop.0>
d0082e7c:	42ac      	cmp	r4, r5
d0082e7e:	f67f a919 	bls.w	d00820b4 <speech_synth_render+0x500>
d0082e82:	2d00      	cmp	r5, #0
d0082e84:	f43f a89e 	beq.w	d0081fc4 <speech_synth_render+0x410>
d0082e88:	f81b c005 	ldrb.w	ip, [fp, r5]
d0082e8c:	f1ac 0e41 	sub.w	lr, ip, #65	; 0x41
d0082e90:	fa5f f38e 	uxtb.w	r3, lr
d0082e94:	2b19      	cmp	r3, #25
d0082e96:	f240 837a 	bls.w	d008358e <speech_synth_render+0x19da>
d0082e9a:	4662      	mov	r2, ip
d0082e9c:	eb0b 0305 	add.w	r3, fp, r5
d0082ea0:	f813 3c01 	ldrb.w	r3, [r3, #-1]
d0082ea4:	f1a3 0141 	sub.w	r1, r3, #65	; 0x41
d0082ea8:	2919      	cmp	r1, #25
d0082eaa:	d801      	bhi.n	d0082eb0 <speech_synth_render+0x12fc>
d0082eac:	3320      	adds	r3, #32
d0082eae:	b2db      	uxtb	r3, r3
d0082eb0:	4293      	cmp	r3, r2
d0082eb2:	f47e af08 	bne.w	d0081cc6 <speech_synth_render+0x112>
d0082eb6:	3b61      	subs	r3, #97	; 0x61
d0082eb8:	b2db      	uxtb	r3, r3
d0082eba:	2b18      	cmp	r3, #24
d0082ebc:	d805      	bhi.n	d0082eca <speech_synth_render+0x1316>
d0082ebe:	4a53      	ldr	r2, [pc, #332]	; (d008300c <speech_synth_render+0x1458>)
d0082ec0:	fa22 f303 	lsr.w	r3, r2, r3
d0082ec4:	07d8      	lsls	r0, r3, #31
d0082ec6:	f53e aefe 	bmi.w	d0081cc6 <speech_synth_render+0x112>
d0082eca:	3501      	adds	r5, #1
d0082ecc:	b2ad      	uxth	r5, r5
d0082ece:	f7ff b879 	b.w	d0081fc4 <speech_synth_render+0x410>
d0082ed2:	2200      	movs	r2, #0
d0082ed4:	2118      	movs	r1, #24
d0082ed6:	a826      	add	r0, sp, #152	; 0x98
d0082ed8:	b2b5      	uxth	r5, r6
d0082eda:	f7fd f921 	bl	d0080120 <emit_phone.constprop.0>
d0082ede:	e7cd      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082ee0:	9b03      	ldr	r3, [sp, #12]
d0082ee2:	429d      	cmp	r5, r3
d0082ee4:	f000 8357 	beq.w	d0083596 <speech_synth_render+0x19e2>
d0082ee8:	b19d      	cbz	r5, d0082f12 <speech_synth_render+0x135e>
d0082eea:	445d      	add	r5, fp
d0082eec:	f815 3c01 	ldrb.w	r3, [r5, #-1]
d0082ef0:	f1a3 0241 	sub.w	r2, r3, #65	; 0x41
d0082ef4:	2a19      	cmp	r2, #25
d0082ef6:	d801      	bhi.n	d0082efc <speech_synth_render+0x1348>
d0082ef8:	3320      	adds	r3, #32
d0082efa:	b2db      	uxtb	r3, r3
d0082efc:	3b61      	subs	r3, #97	; 0x61
d0082efe:	b2db      	uxtb	r3, r3
d0082f00:	2b14      	cmp	r3, #20
d0082f02:	f200 8348 	bhi.w	d0083596 <speech_synth_render+0x19e2>
d0082f06:	4a42      	ldr	r2, [pc, #264]	; (d0083010 <speech_synth_render+0x145c>)
d0082f08:	fa22 f303 	lsr.w	r3, r2, r3
d0082f0c:	07dd      	lsls	r5, r3, #31
d0082f0e:	f140 8342 	bpl.w	d0083596 <speech_synth_render+0x19e2>
d0082f12:	a826      	add	r0, sp, #152	; 0x98
d0082f14:	f7fd f9d0 	bl	d00802b8 <emit_ay.constprop.0>
d0082f18:	b2b5      	uxth	r5, r6
d0082f1a:	e7af      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082f1c:	a826      	add	r0, sp, #152	; 0x98
d0082f1e:	2200      	movs	r2, #0
d0082f20:	2113      	movs	r1, #19
d0082f22:	b2b5      	uxth	r5, r6
d0082f24:	f7fd f8fc 	bl	d0080120 <emit_phone.constprop.0>
d0082f28:	2200      	movs	r2, #0
d0082f2a:	211a      	movs	r1, #26
d0082f2c:	a826      	add	r0, sp, #152	; 0x98
d0082f2e:	f7fd f8f7 	bl	d0080120 <emit_phone.constprop.0>
d0082f32:	e7a3      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082f34:	2200      	movs	r2, #0
d0082f36:	211f      	movs	r1, #31
d0082f38:	a826      	add	r0, sp, #152	; 0x98
d0082f3a:	b2b5      	uxth	r5, r6
d0082f3c:	f7fd f8f0 	bl	d0080120 <emit_phone.constprop.0>
d0082f40:	e79c      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082f42:	2200      	movs	r2, #0
d0082f44:	211e      	movs	r1, #30
d0082f46:	a826      	add	r0, sp, #152	; 0x98
d0082f48:	b2b5      	uxth	r5, r6
d0082f4a:	f7fd f8e9 	bl	d0080120 <emit_phone.constprop.0>
d0082f4e:	e795      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082f50:	42a5      	cmp	r5, r4
d0082f52:	da19      	bge.n	d0082f88 <speech_synth_render+0x13d4>
d0082f54:	4628      	mov	r0, r5
d0082f56:	2275      	movs	r2, #117	; 0x75
d0082f58:	2300      	movs	r3, #0
d0082f5a:	4f2e      	ldr	r7, [pc, #184]	; (d0083014 <speech_synth_render+0x1460>)
d0082f5c:	e005      	b.n	d0082f6a <speech_synth_render+0x13b6>
d0082f5e:	5dda      	ldrb	r2, [r3, r7]
d0082f60:	2a00      	cmp	r2, #0
d0082f62:	f000 80ed 	beq.w	d0083140 <speech_synth_render+0x158c>
d0082f66:	42a0      	cmp	r0, r4
d0082f68:	da0e      	bge.n	d0082f88 <speech_synth_render+0x13d4>
d0082f6a:	f81b 1000 	ldrb.w	r1, [fp, r0]
d0082f6e:	3301      	adds	r3, #1
d0082f70:	f1a1 0c41 	sub.w	ip, r1, #65	; 0x41
d0082f74:	b29b      	uxth	r3, r3
d0082f76:	f1bc 0f19 	cmp.w	ip, #25
d0082f7a:	eb03 0005 	add.w	r0, r3, r5
d0082f7e:	d801      	bhi.n	d0082f84 <speech_synth_render+0x13d0>
d0082f80:	3120      	adds	r1, #32
d0082f82:	b2c9      	uxtb	r1, r1
d0082f84:	4291      	cmp	r1, r2
d0082f86:	d0ea      	beq.n	d0082f5e <speech_synth_render+0x13aa>
d0082f88:	462a      	mov	r2, r5
d0082f8a:	4621      	mov	r1, r4
d0082f8c:	4658      	mov	r0, fp
d0082f8e:	f7fd f909 	bl	d00801a4 <has_magic_e>
d0082f92:	4602      	mov	r2, r0
d0082f94:	2800      	cmp	r0, #0
d0082f96:	f000 8323 	beq.w	d00835e0 <speech_synth_render+0x1a2c>
d0082f9a:	2200      	movs	r2, #0
d0082f9c:	210a      	movs	r1, #10
d0082f9e:	a826      	add	r0, sp, #152	; 0x98
d0082fa0:	f7fd f8be 	bl	d0080120 <emit_phone.constprop.0>
d0082fa4:	e7b8      	b.n	d0082f18 <speech_synth_render+0x1364>
d0082fa6:	2200      	movs	r2, #0
d0082fa8:	211c      	movs	r1, #28
d0082faa:	a826      	add	r0, sp, #152	; 0x98
d0082fac:	b2b5      	uxth	r5, r6
d0082fae:	f7fd f8b7 	bl	d0080120 <emit_phone.constprop.0>
d0082fb2:	e763      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082fb4:	2200      	movs	r2, #0
d0082fb6:	211a      	movs	r1, #26
d0082fb8:	a826      	add	r0, sp, #152	; 0x98
d0082fba:	b2b5      	uxth	r5, r6
d0082fbc:	f7fd f8b0 	bl	d0080120 <emit_phone.constprop.0>
d0082fc0:	e75c      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082fc2:	2200      	movs	r2, #0
d0082fc4:	2119      	movs	r1, #25
d0082fc6:	a826      	add	r0, sp, #152	; 0x98
d0082fc8:	b2b5      	uxth	r5, r6
d0082fca:	f7fd f8a9 	bl	d0080120 <emit_phone.constprop.0>
d0082fce:	e755      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0082fd0:	42a5      	cmp	r5, r4
d0082fd2:	da38      	bge.n	d0083046 <speech_synth_render+0x1492>
d0082fd4:	4628      	mov	r0, r5
d0082fd6:	2269      	movs	r2, #105	; 0x69
d0082fd8:	2300      	movs	r3, #0
d0082fda:	e026      	b.n	d008302a <speech_synth_render+0x1476>
d0082fdc:	d00b4540 	.word	0xd00b4540
d0082fe0:	d0084650 	.word	0xd0084650
d0082fe4:	d0084658 	.word	0xd0084658
d0082fe8:	d0084b28 	.word	0xd0084b28
d0082fec:	0002ee00 	.word	0x0002ee00
d0082ff0:	d0085740 	.word	0xd0085740
d0082ff4:	d0084aac 	.word	0xd0084aac
d0082ff8:	1234abcd 	.word	0x1234abcd
d0082ffc:	d008466c 	.word	0xd008466c
d0083000:	d0084670 	.word	0xd0084670
d0083004:	d0084674 	.word	0xd0084674
d0083008:	d0084678 	.word	0xd0084678
d008300c:	01104111 	.word	0x01104111
d0083010:	00104111 	.word	0x00104111
d0083014:	d00846a4 	.word	0xd00846a4
d0083018:	d00846ac 	.word	0xd00846ac
d008301c:	4abe      	ldr	r2, [pc, #760]	; (d0083318 <speech_synth_render+0x1764>)
d008301e:	5c9a      	ldrb	r2, [r3, r2]
d0083020:	2a00      	cmp	r2, #0
d0083022:	f000 808d 	beq.w	d0083140 <speech_synth_render+0x158c>
d0083026:	42a0      	cmp	r0, r4
d0083028:	da0d      	bge.n	d0083046 <speech_synth_render+0x1492>
d008302a:	f81b 1000 	ldrb.w	r1, [fp, r0]
d008302e:	3301      	adds	r3, #1
d0083030:	f1a1 0741 	sub.w	r7, r1, #65	; 0x41
d0083034:	b29b      	uxth	r3, r3
d0083036:	2f19      	cmp	r7, #25
d0083038:	eb03 0005 	add.w	r0, r3, r5
d008303c:	d801      	bhi.n	d0083042 <speech_synth_render+0x148e>
d008303e:	3120      	adds	r1, #32
d0083040:	b2c9      	uxtb	r1, r1
d0083042:	4291      	cmp	r1, r2
d0083044:	d0ea      	beq.n	d008301c <speech_synth_render+0x1468>
d0083046:	462a      	mov	r2, r5
d0083048:	4621      	mov	r1, r4
d008304a:	4658      	mov	r0, fp
d008304c:	f7fd f8aa 	bl	d00801a4 <has_magic_e>
d0083050:	4602      	mov	r2, r0
d0083052:	2800      	cmp	r0, #0
d0083054:	f47f af5d 	bne.w	d0082f12 <speech_synth_render+0x135e>
d0083058:	2107      	movs	r1, #7
d008305a:	a826      	add	r0, sp, #152	; 0x98
d008305c:	f7fd f860 	bl	d0080120 <emit_phone.constprop.0>
d0083060:	e75a      	b.n	d0082f18 <speech_synth_render+0x1364>
d0083062:	2200      	movs	r2, #0
d0083064:	2111      	movs	r1, #17
d0083066:	a826      	add	r0, sp, #152	; 0x98
d0083068:	b2b5      	uxth	r5, r6
d008306a:	f7fd f859 	bl	d0080120 <emit_phone.constprop.0>
d008306e:	e705      	b.n	d0082e7c <speech_synth_render+0x12c8>
d0083070:	f000 03ef 	and.w	r3, r0, #239	; 0xef
d0083074:	2b69      	cmp	r3, #105	; 0x69
d0083076:	f000 8294 	beq.w	d00835a2 <speech_synth_render+0x19ee>
d008307a:	2865      	cmp	r0, #101	; 0x65
d008307c:	f000 8291 	beq.w	d00835a2 <speech_synth_render+0x19ee>
d0083080:	2110      	movs	r1, #16
d0083082:	2200      	movs	r2, #0
d0083084:	a826      	add	r0, sp, #152	; 0x98
d0083086:	b2b5      	uxth	r5, r6
d0083088:	f7fd f84a 	bl	d0080120 <emit_phone.constprop.0>
d008308c:	e6f6      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008308e:	2200      	movs	r2, #0
d0083090:	210f      	movs	r1, #15
d0083092:	a826      	add	r0, sp, #152	; 0x98
d0083094:	b2b5      	uxth	r5, r6
d0083096:	f7fd f843 	bl	d0080120 <emit_phone.constprop.0>
d008309a:	e6ef      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008309c:	9b03      	ldr	r3, [sp, #12]
d008309e:	429d      	cmp	r5, r3
d00830a0:	f43f af3a 	beq.w	d0082f18 <speech_synth_render+0x1364>
d00830a4:	42a5      	cmp	r5, r4
d00830a6:	f280 82a0 	bge.w	d00835ea <speech_synth_render+0x1a36>
d00830aa:	4628      	mov	r0, r5
d00830ac:	2165      	movs	r1, #101	; 0x65
d00830ae:	2300      	movs	r3, #0
d00830b0:	4f9a      	ldr	r7, [pc, #616]	; (d008331c <speech_synth_render+0x1768>)
d00830b2:	e005      	b.n	d00830c0 <speech_synth_render+0x150c>
d00830b4:	5dd9      	ldrb	r1, [r3, r7]
d00830b6:	2900      	cmp	r1, #0
d00830b8:	f000 828a 	beq.w	d00835d0 <speech_synth_render+0x1a1c>
d00830bc:	42a0      	cmp	r0, r4
d00830be:	da0e      	bge.n	d00830de <speech_synth_render+0x152a>
d00830c0:	f81b 2000 	ldrb.w	r2, [fp, r0]
d00830c4:	3301      	adds	r3, #1
d00830c6:	f1a2 0c41 	sub.w	ip, r2, #65	; 0x41
d00830ca:	b29b      	uxth	r3, r3
d00830cc:	f1bc 0f19 	cmp.w	ip, #25
d00830d0:	eb03 0005 	add.w	r0, r3, r5
d00830d4:	d801      	bhi.n	d00830da <speech_synth_render+0x1526>
d00830d6:	3220      	adds	r2, #32
d00830d8:	b2d2      	uxtb	r2, r2
d00830da:	428a      	cmp	r2, r1
d00830dc:	d0ea      	beq.n	d00830b4 <speech_synth_render+0x1500>
d00830de:	4629      	mov	r1, r5
d00830e0:	2065      	movs	r0, #101	; 0x65
d00830e2:	2300      	movs	r3, #0
d00830e4:	4f8e      	ldr	r7, [pc, #568]	; (d0083320 <speech_synth_render+0x176c>)
d00830e6:	e005      	b.n	d00830f4 <speech_synth_render+0x1540>
d00830e8:	5dd8      	ldrb	r0, [r3, r7]
d00830ea:	2800      	cmp	r0, #0
d00830ec:	f000 8270 	beq.w	d00835d0 <speech_synth_render+0x1a1c>
d00830f0:	42a1      	cmp	r1, r4
d00830f2:	da0e      	bge.n	d0083112 <speech_synth_render+0x155e>
d00830f4:	f81b 2001 	ldrb.w	r2, [fp, r1]
d00830f8:	3301      	adds	r3, #1
d00830fa:	f1a2 0c41 	sub.w	ip, r2, #65	; 0x41
d00830fe:	b29b      	uxth	r3, r3
d0083100:	f1bc 0f19 	cmp.w	ip, #25
d0083104:	eb03 0105 	add.w	r1, r3, r5
d0083108:	d801      	bhi.n	d008310e <speech_synth_render+0x155a>
d008310a:	3220      	adds	r2, #32
d008310c:	b2d2      	uxtb	r2, r2
d008310e:	4282      	cmp	r2, r0
d0083110:	d0ea      	beq.n	d00830e8 <speech_synth_render+0x1534>
d0083112:	2265      	movs	r2, #101	; 0x65
d0083114:	2100      	movs	r1, #0
d0083116:	4883      	ldr	r0, [pc, #524]	; (d0083324 <speech_synth_render+0x1770>)
d0083118:	194b      	adds	r3, r1, r5
d008311a:	1c4f      	adds	r7, r1, #1
d008311c:	42a3      	cmp	r3, r4
d008311e:	b2b9      	uxth	r1, r7
d0083120:	f280 8263 	bge.w	d00835ea <speech_synth_render+0x1a36>
d0083124:	f81b 3003 	ldrb.w	r3, [fp, r3]
d0083128:	f1a3 0741 	sub.w	r7, r3, #65	; 0x41
d008312c:	2f19      	cmp	r7, #25
d008312e:	d801      	bhi.n	d0083134 <speech_synth_render+0x1580>
d0083130:	3320      	adds	r3, #32
d0083132:	b2db      	uxtb	r3, r3
d0083134:	4293      	cmp	r3, r2
d0083136:	f040 8258 	bne.w	d00835ea <speech_synth_render+0x1a36>
d008313a:	5c0a      	ldrb	r2, [r1, r0]
d008313c:	2a00      	cmp	r2, #0
d008313e:	d1eb      	bne.n	d0083118 <speech_synth_render+0x1564>
d0083140:	2106      	movs	r1, #6
d0083142:	a826      	add	r0, sp, #152	; 0x98
d0083144:	f7fc ffec 	bl	d0080120 <emit_phone.constprop.0>
d0083148:	3502      	adds	r5, #2
d008314a:	b2ad      	uxth	r5, r5
d008314c:	e696      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008314e:	2200      	movs	r2, #0
d0083150:	210d      	movs	r1, #13
d0083152:	a826      	add	r0, sp, #152	; 0x98
d0083154:	b2b5      	uxth	r5, r6
d0083156:	f7fc ffe3 	bl	d0080120 <emit_phone.constprop.0>
d008315a:	e68f      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008315c:	f000 03ef 	and.w	r3, r0, #239	; 0xef
d0083160:	2b69      	cmp	r3, #105	; 0x69
d0083162:	f000 8220 	beq.w	d00835a6 <speech_synth_render+0x19f2>
d0083166:	2865      	cmp	r0, #101	; 0x65
d0083168:	f000 821d 	beq.w	d00835a6 <speech_synth_render+0x19f2>
d008316c:	2113      	movs	r1, #19
d008316e:	e788      	b.n	d0083082 <speech_synth_render+0x14ce>
d0083170:	2200      	movs	r2, #0
d0083172:	210b      	movs	r1, #11
d0083174:	a826      	add	r0, sp, #152	; 0x98
d0083176:	b2b5      	uxth	r5, r6
d0083178:	f7fc ffd2 	bl	d0080120 <emit_phone.constprop.0>
d008317c:	e67e      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008317e:	2200      	movs	r2, #0
d0083180:	2115      	movs	r1, #21
d0083182:	a826      	add	r0, sp, #152	; 0x98
d0083184:	b2b5      	uxth	r5, r6
d0083186:	f7fc ffcb 	bl	d0080120 <emit_phone.constprop.0>
d008318a:	e677      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008318c:	2200      	movs	r2, #0
d008318e:	2114      	movs	r1, #20
d0083190:	a826      	add	r0, sp, #152	; 0x98
d0083192:	b2b5      	uxth	r5, r6
d0083194:	f7fc ffc4 	bl	d0080120 <emit_phone.constprop.0>
d0083198:	e670      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008319a:	2200      	movs	r2, #0
d008319c:	2121      	movs	r1, #33	; 0x21
d008319e:	a826      	add	r0, sp, #152	; 0x98
d00831a0:	b2b5      	uxth	r5, r6
d00831a2:	f7fc ffbd 	bl	d0080120 <emit_phone.constprop.0>
d00831a6:	e669      	b.n	d0082e7c <speech_synth_render+0x12c8>
d00831a8:	2200      	movs	r2, #0
d00831aa:	2112      	movs	r1, #18
d00831ac:	a826      	add	r0, sp, #152	; 0x98
d00831ae:	b2b5      	uxth	r5, r6
d00831b0:	f7fc ffb6 	bl	d0080120 <emit_phone.constprop.0>
d00831b4:	e662      	b.n	d0082e7c <speech_synth_render+0x12c8>
d00831b6:	42a5      	cmp	r5, r4
d00831b8:	f280 8227 	bge.w	d008360a <speech_synth_render+0x1a56>
d00831bc:	4628      	mov	r0, r5
d00831be:	226f      	movs	r2, #111	; 0x6f
d00831c0:	2300      	movs	r3, #0
d00831c2:	4f59      	ldr	r7, [pc, #356]	; (d0083328 <speech_synth_render+0x1774>)
d00831c4:	e005      	b.n	d00831d2 <speech_synth_render+0x161e>
d00831c6:	5dda      	ldrb	r2, [r3, r7]
d00831c8:	2a00      	cmp	r2, #0
d00831ca:	f000 81fa 	beq.w	d00835c2 <speech_synth_render+0x1a0e>
d00831ce:	42a0      	cmp	r0, r4
d00831d0:	da0e      	bge.n	d00831f0 <speech_synth_render+0x163c>
d00831d2:	f81b 1000 	ldrb.w	r1, [fp, r0]
d00831d6:	3301      	adds	r3, #1
d00831d8:	f1a1 0c41 	sub.w	ip, r1, #65	; 0x41
d00831dc:	b29b      	uxth	r3, r3
d00831de:	f1bc 0f19 	cmp.w	ip, #25
d00831e2:	eb03 0005 	add.w	r0, r3, r5
d00831e6:	d801      	bhi.n	d00831ec <speech_synth_render+0x1638>
d00831e8:	3120      	adds	r1, #32
d00831ea:	b2c9      	uxtb	r1, r1
d00831ec:	4291      	cmp	r1, r2
d00831ee:	d0ea      	beq.n	d00831c6 <speech_synth_render+0x1612>
d00831f0:	4629      	mov	r1, r5
d00831f2:	206f      	movs	r0, #111	; 0x6f
d00831f4:	2300      	movs	r3, #0
d00831f6:	4f4d      	ldr	r7, [pc, #308]	; (d008332c <speech_synth_render+0x1778>)
d00831f8:	e005      	b.n	d0083206 <speech_synth_render+0x1652>
d00831fa:	5dd8      	ldrb	r0, [r3, r7]
d00831fc:	2800      	cmp	r0, #0
d00831fe:	f000 81da 	beq.w	d00835b6 <speech_synth_render+0x1a02>
d0083202:	42a1      	cmp	r1, r4
d0083204:	da0e      	bge.n	d0083224 <speech_synth_render+0x1670>
d0083206:	f81b 2001 	ldrb.w	r2, [fp, r1]
d008320a:	3301      	adds	r3, #1
d008320c:	f1a2 0c41 	sub.w	ip, r2, #65	; 0x41
d0083210:	b29b      	uxth	r3, r3
d0083212:	f1bc 0f19 	cmp.w	ip, #25
d0083216:	eb03 0105 	add.w	r1, r3, r5
d008321a:	d801      	bhi.n	d0083220 <speech_synth_render+0x166c>
d008321c:	3220      	adds	r2, #32
d008321e:	b2d2      	uxtb	r2, r2
d0083220:	4282      	cmp	r2, r0
d0083222:	d0ea      	beq.n	d00831fa <speech_synth_render+0x1646>
d0083224:	4629      	mov	r1, r5
d0083226:	206f      	movs	r0, #111	; 0x6f
d0083228:	2300      	movs	r3, #0
d008322a:	4f41      	ldr	r7, [pc, #260]	; (d0083330 <speech_synth_render+0x177c>)
d008322c:	e005      	b.n	d008323a <speech_synth_render+0x1686>
d008322e:	5dd8      	ldrb	r0, [r3, r7]
d0083230:	2800      	cmp	r0, #0
d0083232:	f000 81c0 	beq.w	d00835b6 <speech_synth_render+0x1a02>
d0083236:	42a1      	cmp	r1, r4
d0083238:	da0e      	bge.n	d0083258 <speech_synth_render+0x16a4>
d008323a:	f81b 2001 	ldrb.w	r2, [fp, r1]
d008323e:	3301      	adds	r3, #1
d0083240:	f1a2 0c41 	sub.w	ip, r2, #65	; 0x41
d0083244:	b29b      	uxth	r3, r3
d0083246:	f1bc 0f19 	cmp.w	ip, #25
d008324a:	eb03 0105 	add.w	r1, r3, r5
d008324e:	d801      	bhi.n	d0083254 <speech_synth_render+0x16a0>
d0083250:	3220      	adds	r2, #32
d0083252:	b2d2      	uxtb	r2, r2
d0083254:	4282      	cmp	r2, r0
d0083256:	d0ea      	beq.n	d008322e <speech_synth_render+0x167a>
d0083258:	216f      	movs	r1, #111	; 0x6f
d008325a:	2200      	movs	r2, #0
d008325c:	4835      	ldr	r0, [pc, #212]	; (d0083334 <speech_synth_render+0x1780>)
d008325e:	1953      	adds	r3, r2, r5
d0083260:	1c57      	adds	r7, r2, #1
d0083262:	42a3      	cmp	r3, r4
d0083264:	b2ba      	uxth	r2, r7
d0083266:	f280 81d0 	bge.w	d008360a <speech_synth_render+0x1a56>
d008326a:	f81b 3003 	ldrb.w	r3, [fp, r3]
d008326e:	f1a3 0741 	sub.w	r7, r3, #65	; 0x41
d0083272:	2f19      	cmp	r7, #25
d0083274:	d801      	bhi.n	d008327a <speech_synth_render+0x16c6>
d0083276:	3320      	adds	r3, #32
d0083278:	b2db      	uxtb	r3, r3
d008327a:	428b      	cmp	r3, r1
d008327c:	f040 81c5 	bne.w	d008360a <speech_synth_render+0x1a56>
d0083280:	5c11      	ldrb	r1, [r2, r0]
d0083282:	2900      	cmp	r1, #0
d0083284:	d1eb      	bne.n	d008325e <speech_synth_render+0x16aa>
d0083286:	f8bd 7098 	ldrh.w	r7, [sp, #152]	; 0x98
d008328a:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d008328e:	f4bf af5b 	bcs.w	d0083148 <speech_synth_render+0x1594>
d0083292:	9812      	ldr	r0, [sp, #72]	; 0x48
d0083294:	1c7e      	adds	r6, r7, #1
d0083296:	2104      	movs	r1, #4
d0083298:	224c      	movs	r2, #76	; 0x4c
d008329a:	eb00 0387 	add.w	r3, r0, r7, lsl #2
d008329e:	b2b6      	uxth	r6, r6
d00832a0:	f800 1027 	strb.w	r1, [r0, r7, lsl #2]
d00832a4:	805a      	strh	r2, [r3, #2]
d00832a6:	4824      	ldr	r0, [pc, #144]	; (d0083338 <speech_synth_render+0x1784>)
d00832a8:	f8ad 6098 	strh.w	r6, [sp, #152]	; 0x98
d00832ac:	f000 fec9 	bl	d0084042 <strlen>
d00832b0:	1d03      	adds	r3, r0, #4
d00832b2:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00832b6:	d20c      	bcs.n	d00832d2 <speech_synth_render+0x171e>
d00832b8:	b138      	cbz	r0, d00832ca <speech_synth_render+0x1716>
d00832ba:	4b1f      	ldr	r3, [pc, #124]	; (d0083338 <speech_synth_render+0x1784>)
d00832bc:	2120      	movs	r1, #32
d00832be:	2200      	movs	r2, #0
d00832c0:	eb03 0c00 	add.w	ip, r3, r0
d00832c4:	5419      	strb	r1, [r3, r0]
d00832c6:	f88c 2001 	strb.w	r2, [ip, #1]
d00832ca:	491c      	ldr	r1, [pc, #112]	; (d008333c <speech_synth_render+0x1788>)
d00832cc:	481a      	ldr	r0, [pc, #104]	; (d0083338 <speech_synth_render+0x1784>)
d00832ce:	f000 fea9 	bl	d0084024 <strcat>
d00832d2:	f5b6 7f40 	cmp.w	r6, #768	; 0x300
d00832d6:	f43f af37 	beq.w	d0083148 <speech_synth_render+0x1594>
d00832da:	9812      	ldr	r0, [sp, #72]	; 0x48
d00832dc:	2108      	movs	r1, #8
d00832de:	2256      	movs	r2, #86	; 0x56
d00832e0:	3702      	adds	r7, #2
d00832e2:	eb00 0386 	add.w	r3, r0, r6, lsl #2
d00832e6:	f800 1026 	strb.w	r1, [r0, r6, lsl #2]
d00832ea:	4813      	ldr	r0, [pc, #76]	; (d0083338 <speech_synth_render+0x1784>)
d00832ec:	805a      	strh	r2, [r3, #2]
d00832ee:	f8ad 7098 	strh.w	r7, [sp, #152]	; 0x98
d00832f2:	f000 fea6 	bl	d0084042 <strlen>
d00832f6:	1d03      	adds	r3, r0, #4
d00832f8:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00832fc:	f4bf af24 	bcs.w	d0083148 <speech_synth_render+0x1594>
d0083300:	b128      	cbz	r0, d008330e <speech_synth_render+0x175a>
d0083302:	4e0d      	ldr	r6, [pc, #52]	; (d0083338 <speech_synth_render+0x1784>)
d0083304:	2120      	movs	r1, #32
d0083306:	2200      	movs	r2, #0
d0083308:	1833      	adds	r3, r6, r0
d008330a:	5431      	strb	r1, [r6, r0]
d008330c:	705a      	strb	r2, [r3, #1]
d008330e:	490c      	ldr	r1, [pc, #48]	; (d0083340 <speech_synth_render+0x178c>)
d0083310:	4809      	ldr	r0, [pc, #36]	; (d0083338 <speech_synth_render+0x1784>)
d0083312:	f000 fe87 	bl	d0084024 <strcat>
d0083316:	e717      	b.n	d0083148 <speech_synth_render+0x1594>
d0083318:	d0084688 	.word	0xd0084688
d008331c:	d008467c 	.word	0xd008467c
d0083320:	d0084680 	.word	0xd0084680
d0083324:	d0084684 	.word	0xd0084684
d0083328:	d008468c 	.word	0xd008468c
d008332c:	d0084690 	.word	0xd0084690
d0083330:	d0084694 	.word	0xd0084694
d0083334:	d0084698 	.word	0xd0084698
d0083338:	d00b4540 	.word	0xd00b4540
d008333c:	d00845dc 	.word	0xd00845dc
d0083340:	d0084540 	.word	0xd0084540
d0083344:	2867      	cmp	r0, #103	; 0x67
d0083346:	f000 8201 	beq.w	d008374c <speech_synth_render+0x1b98>
d008334a:	2200      	movs	r2, #0
d008334c:	2116      	movs	r1, #22
d008334e:	a826      	add	r0, sp, #152	; 0x98
d0083350:	f7fc fee6 	bl	d0080120 <emit_phone.constprop.0>
d0083354:	2301      	movs	r3, #1
d0083356:	441d      	add	r5, r3
d0083358:	b2ad      	uxth	r5, r5
d008335a:	e58f      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008335c:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0083360:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0083364:	f4bf aafd 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0083368:	2017      	movs	r0, #23
d008336a:	9e12      	ldr	r6, [sp, #72]	; 0x48
d008336c:	1c59      	adds	r1, r3, #1
d008336e:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0083372:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0083376:	235a      	movs	r3, #90	; 0x5a
d0083378:	48c0      	ldr	r0, [pc, #768]	; (d008367c <speech_synth_render+0x1ac8>)
d008337a:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d008337e:	8053      	strh	r3, [r2, #2]
d0083380:	f000 fe5f 	bl	d0084042 <strlen>
d0083384:	1d02      	adds	r2, r0, #4
d0083386:	4603      	mov	r3, r0
d0083388:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008338c:	f4bf aae9 	bcs.w	d0082962 <speech_synth_render+0xdae>
d0083390:	b140      	cbz	r0, d00833a4 <speech_synth_render+0x17f0>
d0083392:	4eba      	ldr	r6, [pc, #744]	; (d008367c <speech_synth_render+0x1ac8>)
d0083394:	2120      	movs	r1, #32
d0083396:	1832      	adds	r2, r6, r0
d0083398:	4630      	mov	r0, r6
d008339a:	54f1      	strb	r1, [r6, r3]
d008339c:	7057      	strb	r7, [r2, #1]
d008339e:	f000 fe50 	bl	d0084042 <strlen>
d00833a2:	4603      	mov	r3, r0
d00833a4:	4ab5      	ldr	r2, [pc, #724]	; (d008367c <speech_synth_render+0x1ac8>)
d00833a6:	49b6      	ldr	r1, [pc, #728]	; (d0083680 <speech_synth_render+0x1acc>)
d00833a8:	18d0      	adds	r0, r2, r3
d00833aa:	2203      	movs	r2, #3
d00833ac:	f000 fcac 	bl	d0083d08 <memcpy>
d00833b0:	f7ff bad7 	b.w	d0082962 <speech_synth_render+0xdae>
d00833b4:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d00833b8:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00833bc:	f4bf aad1 	bcs.w	d0082962 <speech_synth_render+0xdae>
d00833c0:	2019      	movs	r0, #25
d00833c2:	9e12      	ldr	r6, [sp, #72]	; 0x48
d00833c4:	1c59      	adds	r1, r3, #1
d00833c6:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d00833ca:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d00833ce:	2358      	movs	r3, #88	; 0x58
d00833d0:	48aa      	ldr	r0, [pc, #680]	; (d008367c <speech_synth_render+0x1ac8>)
d00833d2:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d00833d6:	8053      	strh	r3, [r2, #2]
d00833d8:	f000 fe33 	bl	d0084042 <strlen>
d00833dc:	1cc2      	adds	r2, r0, #3
d00833de:	4603      	mov	r3, r0
d00833e0:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00833e4:	f4bf aabd 	bcs.w	d0082962 <speech_synth_render+0xdae>
d00833e8:	b140      	cbz	r0, d00833fc <speech_synth_render+0x1848>
d00833ea:	4ea4      	ldr	r6, [pc, #656]	; (d008367c <speech_synth_render+0x1ac8>)
d00833ec:	2120      	movs	r1, #32
d00833ee:	1832      	adds	r2, r6, r0
d00833f0:	4630      	mov	r0, r6
d00833f2:	54f1      	strb	r1, [r6, r3]
d00833f4:	7057      	strb	r7, [r2, #1]
d00833f6:	f000 fe24 	bl	d0084042 <strlen>
d00833fa:	4603      	mov	r3, r0
d00833fc:	4a9f      	ldr	r2, [pc, #636]	; (d008367c <speech_synth_render+0x1ac8>)
d00833fe:	49a1      	ldr	r1, [pc, #644]	; (d0083684 <speech_synth_render+0x1ad0>)
d0083400:	18d0      	adds	r0, r2, r3
d0083402:	2202      	movs	r2, #2
d0083404:	f000 fc80 	bl	d0083d08 <memcpy>
d0083408:	f7ff baab 	b.w	d0082962 <speech_synth_render+0xdae>
d008340c:	42a5      	cmp	r5, r4
d008340e:	f6ff ace0 	blt.w	d0082dd2 <speech_synth_render+0x121e>
d0083412:	462a      	mov	r2, r5
d0083414:	4621      	mov	r1, r4
d0083416:	4658      	mov	r0, fp
d0083418:	f7fc fec4 	bl	d00801a4 <has_magic_e>
d008341c:	4602      	mov	r2, r0
d008341e:	2800      	cmp	r0, #0
d0083420:	f000 80ea 	beq.w	d00835f8 <speech_synth_render+0x1a44>
d0083424:	a826      	add	r0, sp, #152	; 0x98
d0083426:	f7fc feed 	bl	d0080204 <emit_ey.constprop.0>
d008342a:	e575      	b.n	d0082f18 <speech_synth_render+0x1364>
d008342c:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0083430:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0083434:	d251      	bcs.n	d00834da <speech_synth_render+0x1926>
d0083436:	2016      	movs	r0, #22
d0083438:	9d12      	ldr	r5, [sp, #72]	; 0x48
d008343a:	1c59      	adds	r1, r3, #1
d008343c:	eb05 0283 	add.w	r2, r5, r3, lsl #2
d0083440:	f805 0023 	strb.w	r0, [r5, r3, lsl #2]
d0083444:	234b      	movs	r3, #75	; 0x4b
d0083446:	488d      	ldr	r0, [pc, #564]	; (d008367c <speech_synth_render+0x1ac8>)
d0083448:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d008344c:	8053      	strh	r3, [r2, #2]
d008344e:	f000 fdf8 	bl	d0084042 <strlen>
d0083452:	1cc2      	adds	r2, r0, #3
d0083454:	4603      	mov	r3, r0
d0083456:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008345a:	d23e      	bcs.n	d00834da <speech_synth_render+0x1926>
d008345c:	b140      	cbz	r0, d0083470 <speech_synth_render+0x18bc>
d008345e:	4d87      	ldr	r5, [pc, #540]	; (d008367c <speech_synth_render+0x1ac8>)
d0083460:	2120      	movs	r1, #32
d0083462:	182a      	adds	r2, r5, r0
d0083464:	4628      	mov	r0, r5
d0083466:	54e9      	strb	r1, [r5, r3]
d0083468:	7057      	strb	r7, [r2, #1]
d008346a:	f000 fdea 	bl	d0084042 <strlen>
d008346e:	4603      	mov	r3, r0
d0083470:	4a82      	ldr	r2, [pc, #520]	; (d008367c <speech_synth_render+0x1ac8>)
d0083472:	4985      	ldr	r1, [pc, #532]	; (d0083688 <speech_synth_render+0x1ad4>)
d0083474:	18d0      	adds	r0, r2, r3
d0083476:	2202      	movs	r2, #2
d0083478:	4615      	mov	r5, r2
d008347a:	f000 fc45 	bl	d0083d08 <memcpy>
d008347e:	f7fe bda1 	b.w	d0081fc4 <speech_synth_render+0x410>
d0083482:	f8bd 3098 	ldrh.w	r3, [sp, #152]	; 0x98
d0083486:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008348a:	f4bf aa6a 	bcs.w	d0082962 <speech_synth_render+0xdae>
d008348e:	2013      	movs	r0, #19
d0083490:	9e12      	ldr	r6, [sp, #72]	; 0x48
d0083492:	1c59      	adds	r1, r3, #1
d0083494:	eb06 0283 	add.w	r2, r6, r3, lsl #2
d0083498:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d008349c:	2346      	movs	r3, #70	; 0x46
d008349e:	4877      	ldr	r0, [pc, #476]	; (d008367c <speech_synth_render+0x1ac8>)
d00834a0:	f8ad 1098 	strh.w	r1, [sp, #152]	; 0x98
d00834a4:	8053      	strh	r3, [r2, #2]
d00834a6:	f000 fdcc 	bl	d0084042 <strlen>
d00834aa:	1cc2      	adds	r2, r0, #3
d00834ac:	4603      	mov	r3, r0
d00834ae:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00834b2:	f4bf aa56 	bcs.w	d0082962 <speech_synth_render+0xdae>
d00834b6:	b140      	cbz	r0, d00834ca <speech_synth_render+0x1916>
d00834b8:	4e70      	ldr	r6, [pc, #448]	; (d008367c <speech_synth_render+0x1ac8>)
d00834ba:	2120      	movs	r1, #32
d00834bc:	1832      	adds	r2, r6, r0
d00834be:	4630      	mov	r0, r6
d00834c0:	54f1      	strb	r1, [r6, r3]
d00834c2:	7057      	strb	r7, [r2, #1]
d00834c4:	f000 fdbd 	bl	d0084042 <strlen>
d00834c8:	4603      	mov	r3, r0
d00834ca:	4a6c      	ldr	r2, [pc, #432]	; (d008367c <speech_synth_render+0x1ac8>)
d00834cc:	496f      	ldr	r1, [pc, #444]	; (d008368c <speech_synth_render+0x1ad8>)
d00834ce:	18d0      	adds	r0, r2, r3
d00834d0:	2202      	movs	r2, #2
d00834d2:	f000 fc19 	bl	d0083d08 <memcpy>
d00834d6:	f7ff ba44 	b.w	d0082962 <speech_synth_render+0xdae>
d00834da:	2502      	movs	r5, #2
d00834dc:	f7fe bd72 	b.w	d0081fc4 <speech_synth_render+0x410>
d00834e0:	f8bd 8098 	ldrh.w	r8, [sp, #152]	; 0x98
d00834e4:	f5b8 7f40 	cmp.w	r8, #768	; 0x300
d00834e8:	f4bf aa3b 	bcs.w	d0082962 <speech_synth_render+0xdae>
d00834ec:	9812      	ldr	r0, [sp, #72]	; 0x48
d00834ee:	f108 0601 	add.w	r6, r8, #1
d00834f2:	2246      	movs	r2, #70	; 0x46
d00834f4:	2113      	movs	r1, #19
d00834f6:	eb00 0388 	add.w	r3, r0, r8, lsl #2
d00834fa:	b2b6      	uxth	r6, r6
d00834fc:	f800 1028 	strb.w	r1, [r0, r8, lsl #2]
d0083500:	805a      	strh	r2, [r3, #2]
d0083502:	485e      	ldr	r0, [pc, #376]	; (d008367c <speech_synth_render+0x1ac8>)
d0083504:	f8ad 6098 	strh.w	r6, [sp, #152]	; 0x98
d0083508:	f000 fd9b 	bl	d0084042 <strlen>
d008350c:	1cc2      	adds	r2, r0, #3
d008350e:	4603      	mov	r3, r0
d0083510:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083514:	d211      	bcs.n	d008353a <speech_synth_render+0x1986>
d0083516:	b150      	cbz	r0, d008352e <speech_synth_render+0x197a>
d0083518:	4a58      	ldr	r2, [pc, #352]	; (d008367c <speech_synth_render+0x1ac8>)
d008351a:	2120      	movs	r1, #32
d008351c:	eb02 0c00 	add.w	ip, r2, r0
d0083520:	4610      	mov	r0, r2
d0083522:	54d1      	strb	r1, [r2, r3]
d0083524:	f88c 7001 	strb.w	r7, [ip, #1]
d0083528:	f000 fd8b 	bl	d0084042 <strlen>
d008352c:	4603      	mov	r3, r0
d008352e:	4a53      	ldr	r2, [pc, #332]	; (d008367c <speech_synth_render+0x1ac8>)
d0083530:	4956      	ldr	r1, [pc, #344]	; (d008368c <speech_synth_render+0x1ad8>)
d0083532:	18d0      	adds	r0, r2, r3
d0083534:	2202      	movs	r2, #2
d0083536:	f000 fbe7 	bl	d0083d08 <memcpy>
d008353a:	f5b6 7f40 	cmp.w	r6, #768	; 0x300
d008353e:	f43f aa10 	beq.w	d0082962 <speech_synth_render+0xdae>
d0083542:	9812      	ldr	r0, [sp, #72]	; 0x48
d0083544:	211f      	movs	r1, #31
d0083546:	2252      	movs	r2, #82	; 0x52
d0083548:	f108 0802 	add.w	r8, r8, #2
d008354c:	eb00 0386 	add.w	r3, r0, r6, lsl #2
d0083550:	f800 1026 	strb.w	r1, [r0, r6, lsl #2]
d0083554:	4849      	ldr	r0, [pc, #292]	; (d008367c <speech_synth_render+0x1ac8>)
d0083556:	805a      	strh	r2, [r3, #2]
d0083558:	f8ad 8098 	strh.w	r8, [sp, #152]	; 0x98
d008355c:	f000 fd71 	bl	d0084042 <strlen>
d0083560:	1cc3      	adds	r3, r0, #3
d0083562:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0083566:	f4bf a9fc 	bcs.w	d0082962 <speech_synth_render+0xdae>
d008356a:	b140      	cbz	r0, d008357e <speech_synth_render+0x19ca>
d008356c:	4e43      	ldr	r6, [pc, #268]	; (d008367c <speech_synth_render+0x1ac8>)
d008356e:	2120      	movs	r1, #32
d0083570:	2200      	movs	r2, #0
d0083572:	1833      	adds	r3, r6, r0
d0083574:	5431      	strb	r1, [r6, r0]
d0083576:	4630      	mov	r0, r6
d0083578:	705a      	strb	r2, [r3, #1]
d008357a:	f000 fd62 	bl	d0084042 <strlen>
d008357e:	4b3f      	ldr	r3, [pc, #252]	; (d008367c <speech_synth_render+0x1ac8>)
d0083580:	2202      	movs	r2, #2
d0083582:	4943      	ldr	r1, [pc, #268]	; (d0083690 <speech_synth_render+0x1adc>)
d0083584:	4418      	add	r0, r3
d0083586:	f000 fbbf 	bl	d0083d08 <memcpy>
d008358a:	f7ff b9ea 	b.w	d0082962 <speech_synth_render+0xdae>
d008358e:	f10c 0220 	add.w	r2, ip, #32
d0083592:	b2d2      	uxtb	r2, r2
d0083594:	e482      	b.n	d0082e9c <speech_synth_render+0x12e8>
d0083596:	2200      	movs	r2, #0
d0083598:	2108      	movs	r1, #8
d008359a:	a826      	add	r0, sp, #152	; 0x98
d008359c:	f7fc fdc0 	bl	d0080120 <emit_phone.constprop.0>
d00835a0:	e4ba      	b.n	d0082f18 <speech_synth_render+0x1364>
d00835a2:	2112      	movs	r1, #18
d00835a4:	e56d      	b.n	d0083082 <speech_synth_render+0x14ce>
d00835a6:	211a      	movs	r1, #26
d00835a8:	e56b      	b.n	d0083082 <speech_synth_render+0x14ce>
d00835aa:	3502      	adds	r5, #2
d00835ac:	a826      	add	r0, sp, #152	; 0x98
d00835ae:	f7fc fe29 	bl	d0080204 <emit_ey.constprop.0>
d00835b2:	b2ad      	uxth	r5, r5
d00835b4:	e462      	b.n	d0082e7c <speech_synth_render+0x12c8>
d00835b6:	224c      	movs	r2, #76	; 0x4c
d00835b8:	2103      	movs	r1, #3
d00835ba:	a826      	add	r0, sp, #152	; 0x98
d00835bc:	f7fc fdb0 	bl	d0080120 <emit_phone.constprop.0>
d00835c0:	2256      	movs	r2, #86	; 0x56
d00835c2:	3502      	adds	r5, #2
d00835c4:	210a      	movs	r1, #10
d00835c6:	a826      	add	r0, sp, #152	; 0x98
d00835c8:	b2ad      	uxth	r5, r5
d00835ca:	f7fc fda9 	bl	d0080120 <emit_phone.constprop.0>
d00835ce:	e455      	b.n	d0082e7c <speech_synth_render+0x12c8>
d00835d0:	3502      	adds	r5, #2
d00835d2:	2200      	movs	r2, #0
d00835d4:	2108      	movs	r1, #8
d00835d6:	a826      	add	r0, sp, #152	; 0x98
d00835d8:	b2ad      	uxth	r5, r5
d00835da:	f7fc fda1 	bl	d0080120 <emit_phone.constprop.0>
d00835de:	e44d      	b.n	d0082e7c <speech_synth_render+0x12c8>
d00835e0:	2101      	movs	r1, #1
d00835e2:	a826      	add	r0, sp, #152	; 0x98
d00835e4:	f7fc fd9c 	bl	d0080120 <emit_phone.constprop.0>
d00835e8:	e496      	b.n	d0082f18 <speech_synth_render+0x1364>
d00835ea:	2200      	movs	r2, #0
d00835ec:	2105      	movs	r1, #5
d00835ee:	a826      	add	r0, sp, #152	; 0x98
d00835f0:	b2b5      	uxth	r5, r6
d00835f2:	f7fc fd95 	bl	d0080120 <emit_phone.constprop.0>
d00835f6:	e441      	b.n	d0082e7c <speech_synth_render+0x12c8>
d00835f8:	2102      	movs	r1, #2
d00835fa:	a826      	add	r0, sp, #152	; 0x98
d00835fc:	f7fc fd90 	bl	d0080120 <emit_phone.constprop.0>
d0083600:	e48a      	b.n	d0082f18 <speech_synth_render+0x1364>
d0083602:	f8dd a08c 	ldr.w	sl, [sp, #140]	; 0x8c
d0083606:	f7ff ba32 	b.w	d0082a6e <speech_synth_render+0xeba>
d008360a:	216f      	movs	r1, #111	; 0x6f
d008360c:	2300      	movs	r3, #0
d008360e:	4821      	ldr	r0, [pc, #132]	; (d0083694 <speech_synth_render+0x1ae0>)
d0083610:	195a      	adds	r2, r3, r5
d0083612:	1c5f      	adds	r7, r3, #1
d0083614:	42a2      	cmp	r2, r4
d0083616:	b2bb      	uxth	r3, r7
d0083618:	da0d      	bge.n	d0083636 <speech_synth_render+0x1a82>
d008361a:	f81b 2002 	ldrb.w	r2, [fp, r2]
d008361e:	f1a2 0741 	sub.w	r7, r2, #65	; 0x41
d0083622:	2f19      	cmp	r7, #25
d0083624:	d801      	bhi.n	d008362a <speech_synth_render+0x1a76>
d0083626:	3220      	adds	r2, #32
d0083628:	b2d2      	uxtb	r2, r2
d008362a:	428a      	cmp	r2, r1
d008362c:	d103      	bne.n	d0083636 <speech_synth_render+0x1a82>
d008362e:	5c19      	ldrb	r1, [r3, r0]
d0083630:	2900      	cmp	r1, #0
d0083632:	d1ed      	bne.n	d0083610 <speech_synth_render+0x1a5c>
d0083634:	e627      	b.n	d0083286 <speech_synth_render+0x16d2>
d0083636:	276f      	movs	r7, #111	; 0x6f
d0083638:	2200      	movs	r2, #0
d008363a:	4917      	ldr	r1, [pc, #92]	; (d0083698 <speech_synth_render+0x1ae4>)
d008363c:	1953      	adds	r3, r2, r5
d008363e:	1c50      	adds	r0, r2, #1
d0083640:	42a3      	cmp	r3, r4
d0083642:	b282      	uxth	r2, r0
d0083644:	da2a      	bge.n	d008369c <speech_synth_render+0x1ae8>
d0083646:	f81b 3003 	ldrb.w	r3, [fp, r3]
d008364a:	f1a3 0041 	sub.w	r0, r3, #65	; 0x41
d008364e:	2819      	cmp	r0, #25
d0083650:	d801      	bhi.n	d0083656 <speech_synth_render+0x1aa2>
d0083652:	3320      	adds	r3, #32
d0083654:	b2db      	uxtb	r3, r3
d0083656:	42bb      	cmp	r3, r7
d0083658:	d120      	bne.n	d008369c <speech_synth_render+0x1ae8>
d008365a:	5c57      	ldrb	r7, [r2, r1]
d008365c:	2f00      	cmp	r7, #0
d008365e:	d1ed      	bne.n	d008363c <speech_synth_render+0x1a88>
d0083660:	463a      	mov	r2, r7
d0083662:	2104      	movs	r1, #4
d0083664:	a826      	add	r0, sp, #152	; 0x98
d0083666:	3502      	adds	r5, #2
d0083668:	f7fc fd5a 	bl	d0080120 <emit_phone.constprop.0>
d008366c:	463a      	mov	r2, r7
d008366e:	2119      	movs	r1, #25
d0083670:	a826      	add	r0, sp, #152	; 0x98
d0083672:	b2ad      	uxth	r5, r5
d0083674:	f7fc fd54 	bl	d0080120 <emit_phone.constprop.0>
d0083678:	e400      	b.n	d0082e7c <speech_synth_render+0x12c8>
d008367a:	bf00      	nop
d008367c:	d00b4540 	.word	0xd00b4540
d0083680:	d008462c 	.word	0xd008462c
d0083684:	d0084584 	.word	0xd0084584
d0083688:	d00845c4 	.word	0xd00845c4
d008368c:	d0084628 	.word	0xd0084628
d0083690:	d0084658 	.word	0xd0084658
d0083694:	d008469c 	.word	0xd008469c
d0083698:	d00846a0 	.word	0xd00846a0
d008369c:	462a      	mov	r2, r5
d008369e:	4621      	mov	r1, r4
d00836a0:	4658      	mov	r0, fp
d00836a2:	f7fc fd7f 	bl	d00801a4 <has_magic_e>
d00836a6:	4602      	mov	r2, r0
d00836a8:	2800      	cmp	r0, #0
d00836aa:	d049      	beq.n	d0083740 <speech_synth_render+0x1b8c>
d00836ac:	f8bd 7098 	ldrh.w	r7, [sp, #152]	; 0x98
d00836b0:	f5b7 7f40 	cmp.w	r7, #768	; 0x300
d00836b4:	f4bf ac30 	bcs.w	d0082f18 <speech_synth_render+0x1364>
d00836b8:	9812      	ldr	r0, [sp, #72]	; 0x48
d00836ba:	1c7d      	adds	r5, r7, #1
d00836bc:	2104      	movs	r1, #4
d00836be:	2248      	movs	r2, #72	; 0x48
d00836c0:	eb00 0387 	add.w	r3, r0, r7, lsl #2
d00836c4:	b2ad      	uxth	r5, r5
d00836c6:	f800 1027 	strb.w	r1, [r0, r7, lsl #2]
d00836ca:	805a      	strh	r2, [r3, #2]
d00836cc:	4823      	ldr	r0, [pc, #140]	; (d008375c <speech_synth_render+0x1ba8>)
d00836ce:	f8ad 5098 	strh.w	r5, [sp, #152]	; 0x98
d00836d2:	f000 fcb6 	bl	d0084042 <strlen>
d00836d6:	1d03      	adds	r3, r0, #4
d00836d8:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d00836dc:	d20c      	bcs.n	d00836f8 <speech_synth_render+0x1b44>
d00836de:	b138      	cbz	r0, d00836f0 <speech_synth_render+0x1b3c>
d00836e0:	4b1e      	ldr	r3, [pc, #120]	; (d008375c <speech_synth_render+0x1ba8>)
d00836e2:	2120      	movs	r1, #32
d00836e4:	2200      	movs	r2, #0
d00836e6:	eb03 0c00 	add.w	ip, r3, r0
d00836ea:	5419      	strb	r1, [r3, r0]
d00836ec:	f88c 2001 	strb.w	r2, [ip, #1]
d00836f0:	491b      	ldr	r1, [pc, #108]	; (d0083760 <speech_synth_render+0x1bac>)
d00836f2:	481a      	ldr	r0, [pc, #104]	; (d008375c <speech_synth_render+0x1ba8>)
d00836f4:	f000 fc96 	bl	d0084024 <strcat>
d00836f8:	f5b5 7f40 	cmp.w	r5, #768	; 0x300
d00836fc:	f43f ac0c 	beq.w	d0082f18 <speech_synth_render+0x1364>
d0083700:	9812      	ldr	r0, [sp, #72]	; 0x48
d0083702:	210a      	movs	r1, #10
d0083704:	2252      	movs	r2, #82	; 0x52
d0083706:	3702      	adds	r7, #2
d0083708:	eb00 0385 	add.w	r3, r0, r5, lsl #2
d008370c:	f800 1025 	strb.w	r1, [r0, r5, lsl #2]
d0083710:	4812      	ldr	r0, [pc, #72]	; (d008375c <speech_synth_render+0x1ba8>)
d0083712:	805a      	strh	r2, [r3, #2]
d0083714:	f8ad 7098 	strh.w	r7, [sp, #152]	; 0x98
d0083718:	f000 fc93 	bl	d0084042 <strlen>
d008371c:	1d03      	adds	r3, r0, #4
d008371e:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0083722:	f4bf abf9 	bcs.w	d0082f18 <speech_synth_render+0x1364>
d0083726:	b128      	cbz	r0, d0083734 <speech_synth_render+0x1b80>
d0083728:	4d0c      	ldr	r5, [pc, #48]	; (d008375c <speech_synth_render+0x1ba8>)
d008372a:	2120      	movs	r1, #32
d008372c:	2200      	movs	r2, #0
d008372e:	182b      	adds	r3, r5, r0
d0083730:	5429      	strb	r1, [r5, r0]
d0083732:	705a      	strb	r2, [r3, #1]
d0083734:	490b      	ldr	r1, [pc, #44]	; (d0083764 <speech_synth_render+0x1bb0>)
d0083736:	4809      	ldr	r0, [pc, #36]	; (d008375c <speech_synth_render+0x1ba8>)
d0083738:	f000 fc74 	bl	d0084024 <strcat>
d008373c:	f7ff bbec 	b.w	d0082f18 <speech_synth_render+0x1364>
d0083740:	2103      	movs	r1, #3
d0083742:	a826      	add	r0, sp, #152	; 0x98
d0083744:	f7fc fcec 	bl	d0080120 <emit_phone.constprop.0>
d0083748:	f7ff bbe6 	b.w	d0082f18 <speech_synth_render+0x1364>
d008374c:	2200      	movs	r2, #0
d008374e:	2117      	movs	r1, #23
d0083750:	a826      	add	r0, sp, #152	; 0x98
d0083752:	f7fc fce5 	bl	d0080120 <emit_phone.constprop.0>
d0083756:	2302      	movs	r3, #2
d0083758:	e5fd      	b.n	d0083356 <speech_synth_render+0x17a2>
d008375a:	bf00      	nop
d008375c:	d00b4540 	.word	0xd00b4540
d0083760:	d00845dc 	.word	0xd00845dc
d0083764:	d0084590 	.word	0xd0084590

d0083768 <speech_synth_samples>:
d0083768:	4800      	ldr	r0, [pc, #0]	; (d008376c <speech_synth_samples+0x4>)
d008376a:	4770      	bx	lr
d008376c:	d0085740 	.word	0xd0085740

d0083770 <main>:
d0083770:	b5f0      	push	{r4, r5, r6, r7, lr}
d0083772:	b083      	sub	sp, #12
d0083774:	2900      	cmp	r1, #0
d0083776:	f000 8131 	beq.w	d00839dc <main+0x26c>
d008377a:	684e      	ldr	r6, [r1, #4]
d008377c:	4b98      	ldr	r3, [pc, #608]	; (d00839e0 <main+0x270>)
d008377e:	2e00      	cmp	r6, #0
d0083780:	bf08      	it	eq
d0083782:	461e      	moveq	r6, r3
d0083784:	4c97      	ldr	r4, [pc, #604]	; (d00839e4 <main+0x274>)
d0083786:	f44f 2000 	mov.w	r0, #524288	; 0x80000
d008378a:	2501      	movs	r5, #1
d008378c:	7823      	ldrb	r3, [r4, #0]
d008378e:	7862      	ldrb	r2, [r4, #1]
d0083790:	78a1      	ldrb	r1, [r4, #2]
d0083792:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0083796:	78e2      	ldrb	r2, [r4, #3]
d0083798:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d008379c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00837a0:	681b      	ldr	r3, [r3, #0]
d00837a2:	4798      	blx	r3
d00837a4:	f7fc fc4a 	bl	d008003c <initMalloc>
d00837a8:	7d23      	ldrb	r3, [r4, #20]
d00837aa:	7d62      	ldrb	r2, [r4, #21]
d00837ac:	2040      	movs	r0, #64	; 0x40
d00837ae:	7da1      	ldrb	r1, [r4, #22]
d00837b0:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00837b4:	7de2      	ldrb	r2, [r4, #23]
d00837b6:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00837ba:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00837be:	681b      	ldr	r3, [r3, #0]
d00837c0:	681b      	ldr	r3, [r3, #0]
d00837c2:	4798      	blx	r3
d00837c4:	7d22      	ldrb	r2, [r4, #20]
d00837c6:	7d63      	ldrb	r3, [r4, #21]
d00837c8:	7da0      	ldrb	r0, [r4, #22]
d00837ca:	ea42 2203 	orr.w	r2, r2, r3, lsl #8
d00837ce:	7de1      	ldrb	r1, [r4, #23]
d00837d0:	7f23      	ldrb	r3, [r4, #28]
d00837d2:	ea42 4200 	orr.w	r2, r2, r0, lsl #16
d00837d6:	7f67      	ldrb	r7, [r4, #29]
d00837d8:	7fa0      	ldrb	r0, [r4, #30]
d00837da:	ea42 6201 	orr.w	r2, r2, r1, lsl #24
d00837de:	7fe1      	ldrb	r1, [r4, #31]
d00837e0:	ea43 2307 	orr.w	r3, r3, r7, lsl #8
d00837e4:	6812      	ldr	r2, [r2, #0]
d00837e6:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d00837ea:	6852      	ldr	r2, [r2, #4]
d00837ec:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00837f0:	7015      	strb	r5, [r2, #0]
d00837f2:	685b      	ldr	r3, [r3, #4]
d00837f4:	4798      	blx	r3
d00837f6:	7f23      	ldrb	r3, [r4, #28]
d00837f8:	7f62      	ldrb	r2, [r4, #29]
d00837fa:	2000      	movs	r0, #0
d00837fc:	7fa1      	ldrb	r1, [r4, #30]
d00837fe:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0083802:	7fe2      	ldrb	r2, [r4, #31]
d0083804:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0083808:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008380c:	6a1b      	ldr	r3, [r3, #32]
d008380e:	4798      	blx	r3
d0083810:	7f23      	ldrb	r3, [r4, #28]
d0083812:	7f62      	ldrb	r2, [r4, #29]
d0083814:	4628      	mov	r0, r5
d0083816:	7fa1      	ldrb	r1, [r4, #30]
d0083818:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008381c:	7fe2      	ldrb	r2, [r4, #31]
d008381e:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0083822:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0083826:	691b      	ldr	r3, [r3, #16]
d0083828:	4798      	blx	r3
d008382a:	7f25      	ldrb	r5, [r4, #28]
d008382c:	7f60      	ldrb	r0, [r4, #29]
d008382e:	2108      	movs	r1, #8
d0083830:	7fa2      	ldrb	r2, [r4, #30]
d0083832:	230d      	movs	r3, #13
d0083834:	ea45 2500 	orr.w	r5, r5, r0, lsl #8
d0083838:	7fe7      	ldrb	r7, [r4, #31]
d008383a:	4608      	mov	r0, r1
d008383c:	ea45 4502 	orr.w	r5, r5, r2, lsl #16
d0083840:	4a69      	ldr	r2, [pc, #420]	; (d00839e8 <main+0x278>)
d0083842:	ea45 6507 	orr.w	r5, r5, r7, lsl #24
d0083846:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d0083848:	47a8      	blx	r5
d008384a:	7f25      	ldrb	r5, [r4, #28]
d008384c:	7f62      	ldrb	r2, [r4, #29]
d008384e:	2307      	movs	r3, #7
d0083850:	7fa0      	ldrb	r0, [r4, #30]
d0083852:	211c      	movs	r1, #28
d0083854:	ea45 2502 	orr.w	r5, r5, r2, lsl #8
d0083858:	7fe7      	ldrb	r7, [r4, #31]
d008385a:	4a64      	ldr	r2, [pc, #400]	; (d00839ec <main+0x27c>)
d008385c:	ea45 4500 	orr.w	r5, r5, r0, lsl #16
d0083860:	2008      	movs	r0, #8
d0083862:	ea45 6507 	orr.w	r5, r5, r7, lsl #24
d0083866:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d0083868:	47a8      	blx	r5
d008386a:	7f25      	ldrb	r5, [r4, #28]
d008386c:	7f62      	ldrb	r2, [r4, #29]
d008386e:	230e      	movs	r3, #14
d0083870:	7fa0      	ldrb	r0, [r4, #30]
d0083872:	212e      	movs	r1, #46	; 0x2e
d0083874:	ea45 2502 	orr.w	r5, r5, r2, lsl #8
d0083878:	7fe7      	ldrb	r7, [r4, #31]
d008387a:	4a5d      	ldr	r2, [pc, #372]	; (d00839f0 <main+0x280>)
d008387c:	ea45 4500 	orr.w	r5, r5, r0, lsl #16
d0083880:	2008      	movs	r0, #8
d0083882:	ea45 6507 	orr.w	r5, r5, r7, lsl #24
d0083886:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d0083888:	47a8      	blx	r5
d008388a:	7f25      	ldrb	r5, [r4, #28]
d008388c:	7f61      	ldrb	r1, [r4, #29]
d008388e:	4632      	mov	r2, r6
d0083890:	7fa0      	ldrb	r0, [r4, #30]
d0083892:	230c      	movs	r3, #12
d0083894:	ea45 2501 	orr.w	r5, r5, r1, lsl #8
d0083898:	7fe7      	ldrb	r7, [r4, #31]
d008389a:	2148      	movs	r1, #72	; 0x48
d008389c:	ea45 4500 	orr.w	r5, r5, r0, lsl #16
d00838a0:	2008      	movs	r0, #8
d00838a2:	ea45 6507 	orr.w	r5, r5, r7, lsl #24
d00838a6:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d00838a8:	47a8      	blx	r5
d00838aa:	7f23      	ldrb	r3, [r4, #28]
d00838ac:	7f62      	ldrb	r2, [r4, #29]
d00838ae:	7fa1      	ldrb	r1, [r4, #30]
d00838b0:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00838b4:	7fe2      	ldrb	r2, [r4, #31]
d00838b6:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00838ba:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00838be:	6b1b      	ldr	r3, [r3, #48]	; 0x30
d00838c0:	4798      	blx	r3
d00838c2:	4630      	mov	r0, r6
d00838c4:	f7fe f976 	bl	d0081bb4 <speech_synth_render>
d00838c8:	7d23      	ldrb	r3, [r4, #20]
d00838ca:	7d61      	ldrb	r1, [r4, #21]
d00838cc:	9001      	str	r0, [sp, #4]
d00838ce:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d00838d2:	7da0      	ldrb	r0, [r4, #22]
d00838d4:	7de1      	ldrb	r1, [r4, #23]
d00838d6:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d00838da:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00838de:	689b      	ldr	r3, [r3, #8]
d00838e0:	68dd      	ldr	r5, [r3, #12]
d00838e2:	f7ff ff41 	bl	d0083768 <speech_synth_samples>
d00838e6:	2300      	movs	r3, #0
d00838e8:	4601      	mov	r1, r0
d00838ea:	9a01      	ldr	r2, [sp, #4]
d00838ec:	4618      	mov	r0, r3
d00838ee:	47a8      	blx	r5
d00838f0:	7d23      	ldrb	r3, [r4, #20]
d00838f2:	7d62      	ldrb	r2, [r4, #21]
d00838f4:	f44f 517a 	mov.w	r1, #16000	; 0x3e80
d00838f8:	7da5      	ldrb	r5, [r4, #22]
d00838fa:	2000      	movs	r0, #0
d00838fc:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0083900:	7de2      	ldrb	r2, [r4, #23]
d0083902:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0083906:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008390a:	689b      	ldr	r3, [r3, #8]
d008390c:	691b      	ldr	r3, [r3, #16]
d008390e:	4798      	blx	r3
d0083910:	7d23      	ldrb	r3, [r4, #20]
d0083912:	7d62      	ldrb	r2, [r4, #21]
d0083914:	21ff      	movs	r1, #255	; 0xff
d0083916:	7da5      	ldrb	r5, [r4, #22]
d0083918:	2000      	movs	r0, #0
d008391a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008391e:	7de2      	ldrb	r2, [r4, #23]
d0083920:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0083924:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0083928:	689b      	ldr	r3, [r3, #8]
d008392a:	695b      	ldr	r3, [r3, #20]
d008392c:	4798      	blx	r3
d008392e:	7d23      	ldrb	r3, [r4, #20]
d0083930:	7d62      	ldrb	r2, [r4, #21]
d0083932:	2100      	movs	r1, #0
d0083934:	7da5      	ldrb	r5, [r4, #22]
d0083936:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008393a:	7de2      	ldrb	r2, [r4, #23]
d008393c:	4608      	mov	r0, r1
d008393e:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0083942:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0083946:	689b      	ldr	r3, [r3, #8]
d0083948:	699b      	ldr	r3, [r3, #24]
d008394a:	4798      	blx	r3
d008394c:	7d23      	ldrb	r3, [r4, #20]
d008394e:	7d62      	ldrb	r2, [r4, #21]
d0083950:	2100      	movs	r1, #0
d0083952:	7da5      	ldrb	r5, [r4, #22]
d0083954:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0083958:	7de2      	ldrb	r2, [r4, #23]
d008395a:	4608      	mov	r0, r1
d008395c:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0083960:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0083964:	689b      	ldr	r3, [r3, #8]
d0083966:	6a1b      	ldr	r3, [r3, #32]
d0083968:	4798      	blx	r3
d008396a:	7d23      	ldrb	r3, [r4, #20]
d008396c:	7d62      	ldrb	r2, [r4, #21]
d008396e:	2000      	movs	r0, #0
d0083970:	7da1      	ldrb	r1, [r4, #22]
d0083972:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0083976:	7de2      	ldrb	r2, [r4, #23]
d0083978:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d008397c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0083980:	689b      	ldr	r3, [r3, #8]
d0083982:	685b      	ldr	r3, [r3, #4]
d0083984:	4798      	blx	r3
d0083986:	7d23      	ldrb	r3, [r4, #20]
d0083988:	7d62      	ldrb	r2, [r4, #21]
d008398a:	2000      	movs	r0, #0
d008398c:	7da1      	ldrb	r1, [r4, #22]
d008398e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0083992:	7de2      	ldrb	r2, [r4, #23]
d0083994:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0083998:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008399c:	689b      	ldr	r3, [r3, #8]
d008399e:	689b      	ldr	r3, [r3, #8]
d00839a0:	4798      	blx	r3
d00839a2:	7d23      	ldrb	r3, [r4, #20]
d00839a4:	7d62      	ldrb	r2, [r4, #21]
d00839a6:	2000      	movs	r0, #0
d00839a8:	7da1      	ldrb	r1, [r4, #22]
d00839aa:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00839ae:	7de2      	ldrb	r2, [r4, #23]
d00839b0:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00839b4:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00839b8:	689b      	ldr	r3, [r3, #8]
d00839ba:	685b      	ldr	r3, [r3, #4]
d00839bc:	4798      	blx	r3
d00839be:	7823      	ldrb	r3, [r4, #0]
d00839c0:	7862      	ldrb	r2, [r4, #1]
d00839c2:	78a1      	ldrb	r1, [r4, #2]
d00839c4:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00839c8:	78e2      	ldrb	r2, [r4, #3]
d00839ca:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00839ce:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00839d2:	685b      	ldr	r3, [r3, #4]
d00839d4:	4798      	blx	r3
d00839d6:	2000      	movs	r0, #0
d00839d8:	b003      	add	sp, #12
d00839da:	bdf0      	pop	{r4, r5, r6, r7, pc}
d00839dc:	4e00      	ldr	r6, [pc, #0]	; (d00839e0 <main+0x270>)
d00839de:	e6d1      	b.n	d0083784 <main+0x14>
d00839e0:	d008497c 	.word	0xd008497c
d00839e4:	2001f000 	.word	0x2001f000
d00839e8:	d00849f0 	.word	0xd00849f0
d00839ec:	d0084a00 	.word	0xd0084a00
d00839f0:	d0084a20 	.word	0xd0084a20

d00839f4 <__aeabi_uldivmod>:
d00839f4:	b953      	cbnz	r3, d0083a0c <__aeabi_uldivmod+0x18>
d00839f6:	b94a      	cbnz	r2, d0083a0c <__aeabi_uldivmod+0x18>
d00839f8:	2900      	cmp	r1, #0
d00839fa:	bf08      	it	eq
d00839fc:	2800      	cmpeq	r0, #0
d00839fe:	bf1c      	itt	ne
d0083a00:	f04f 31ff 	movne.w	r1, #4294967295	; 0xffffffff
d0083a04:	f04f 30ff 	movne.w	r0, #4294967295	; 0xffffffff
d0083a08:	f000 b96e 	b.w	d0083ce8 <__aeabi_idiv0>
d0083a0c:	f1ad 0c08 	sub.w	ip, sp, #8
d0083a10:	e96d ce04 	strd	ip, lr, [sp, #-16]!
d0083a14:	f000 f806 	bl	d0083a24 <__udivmoddi4>
d0083a18:	f8dd e004 	ldr.w	lr, [sp, #4]
d0083a1c:	e9dd 2302 	ldrd	r2, r3, [sp, #8]
d0083a20:	b004      	add	sp, #16
d0083a22:	4770      	bx	lr

d0083a24 <__udivmoddi4>:
d0083a24:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d0083a28:	9d08      	ldr	r5, [sp, #32]
d0083a2a:	4604      	mov	r4, r0
d0083a2c:	468c      	mov	ip, r1
d0083a2e:	2b00      	cmp	r3, #0
d0083a30:	f040 8083 	bne.w	d0083b3a <__udivmoddi4+0x116>
d0083a34:	428a      	cmp	r2, r1
d0083a36:	4617      	mov	r7, r2
d0083a38:	d947      	bls.n	d0083aca <__udivmoddi4+0xa6>
d0083a3a:	fab2 f282 	clz	r2, r2
d0083a3e:	b142      	cbz	r2, d0083a52 <__udivmoddi4+0x2e>
d0083a40:	f1c2 0020 	rsb	r0, r2, #32
d0083a44:	fa24 f000 	lsr.w	r0, r4, r0
d0083a48:	4091      	lsls	r1, r2
d0083a4a:	4097      	lsls	r7, r2
d0083a4c:	ea40 0c01 	orr.w	ip, r0, r1
d0083a50:	4094      	lsls	r4, r2
d0083a52:	ea4f 4817 	mov.w	r8, r7, lsr #16
d0083a56:	0c23      	lsrs	r3, r4, #16
d0083a58:	fbbc f6f8 	udiv	r6, ip, r8
d0083a5c:	fa1f fe87 	uxth.w	lr, r7
d0083a60:	fb08 c116 	mls	r1, r8, r6, ip
d0083a64:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0083a68:	fb06 f10e 	mul.w	r1, r6, lr
d0083a6c:	4299      	cmp	r1, r3
d0083a6e:	d909      	bls.n	d0083a84 <__udivmoddi4+0x60>
d0083a70:	18fb      	adds	r3, r7, r3
d0083a72:	f106 30ff 	add.w	r0, r6, #4294967295	; 0xffffffff
d0083a76:	f080 8119 	bcs.w	d0083cac <__udivmoddi4+0x288>
d0083a7a:	4299      	cmp	r1, r3
d0083a7c:	f240 8116 	bls.w	d0083cac <__udivmoddi4+0x288>
d0083a80:	3e02      	subs	r6, #2
d0083a82:	443b      	add	r3, r7
d0083a84:	1a5b      	subs	r3, r3, r1
d0083a86:	b2a4      	uxth	r4, r4
d0083a88:	fbb3 f0f8 	udiv	r0, r3, r8
d0083a8c:	fb08 3310 	mls	r3, r8, r0, r3
d0083a90:	ea44 4403 	orr.w	r4, r4, r3, lsl #16
d0083a94:	fb00 fe0e 	mul.w	lr, r0, lr
d0083a98:	45a6      	cmp	lr, r4
d0083a9a:	d909      	bls.n	d0083ab0 <__udivmoddi4+0x8c>
d0083a9c:	193c      	adds	r4, r7, r4
d0083a9e:	f100 33ff 	add.w	r3, r0, #4294967295	; 0xffffffff
d0083aa2:	f080 8105 	bcs.w	d0083cb0 <__udivmoddi4+0x28c>
d0083aa6:	45a6      	cmp	lr, r4
d0083aa8:	f240 8102 	bls.w	d0083cb0 <__udivmoddi4+0x28c>
d0083aac:	3802      	subs	r0, #2
d0083aae:	443c      	add	r4, r7
d0083ab0:	ea40 4006 	orr.w	r0, r0, r6, lsl #16
d0083ab4:	eba4 040e 	sub.w	r4, r4, lr
d0083ab8:	2600      	movs	r6, #0
d0083aba:	b11d      	cbz	r5, d0083ac4 <__udivmoddi4+0xa0>
d0083abc:	40d4      	lsrs	r4, r2
d0083abe:	2300      	movs	r3, #0
d0083ac0:	e9c5 4300 	strd	r4, r3, [r5]
d0083ac4:	4631      	mov	r1, r6
d0083ac6:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d0083aca:	b902      	cbnz	r2, d0083ace <__udivmoddi4+0xaa>
d0083acc:	deff      	udf	#255	; 0xff
d0083ace:	fab2 f282 	clz	r2, r2
d0083ad2:	2a00      	cmp	r2, #0
d0083ad4:	d150      	bne.n	d0083b78 <__udivmoddi4+0x154>
d0083ad6:	1bcb      	subs	r3, r1, r7
d0083ad8:	ea4f 4e17 	mov.w	lr, r7, lsr #16
d0083adc:	fa1f f887 	uxth.w	r8, r7
d0083ae0:	2601      	movs	r6, #1
d0083ae2:	fbb3 fcfe 	udiv	ip, r3, lr
d0083ae6:	0c21      	lsrs	r1, r4, #16
d0083ae8:	fb0e 331c 	mls	r3, lr, ip, r3
d0083aec:	ea41 4103 	orr.w	r1, r1, r3, lsl #16
d0083af0:	fb08 f30c 	mul.w	r3, r8, ip
d0083af4:	428b      	cmp	r3, r1
d0083af6:	d907      	bls.n	d0083b08 <__udivmoddi4+0xe4>
d0083af8:	1879      	adds	r1, r7, r1
d0083afa:	f10c 30ff 	add.w	r0, ip, #4294967295	; 0xffffffff
d0083afe:	d202      	bcs.n	d0083b06 <__udivmoddi4+0xe2>
d0083b00:	428b      	cmp	r3, r1
d0083b02:	f200 80e9 	bhi.w	d0083cd8 <__udivmoddi4+0x2b4>
d0083b06:	4684      	mov	ip, r0
d0083b08:	1ac9      	subs	r1, r1, r3
d0083b0a:	b2a3      	uxth	r3, r4
d0083b0c:	fbb1 f0fe 	udiv	r0, r1, lr
d0083b10:	fb0e 1110 	mls	r1, lr, r0, r1
d0083b14:	ea43 4401 	orr.w	r4, r3, r1, lsl #16
d0083b18:	fb08 f800 	mul.w	r8, r8, r0
d0083b1c:	45a0      	cmp	r8, r4
d0083b1e:	d907      	bls.n	d0083b30 <__udivmoddi4+0x10c>
d0083b20:	193c      	adds	r4, r7, r4
d0083b22:	f100 33ff 	add.w	r3, r0, #4294967295	; 0xffffffff
d0083b26:	d202      	bcs.n	d0083b2e <__udivmoddi4+0x10a>
d0083b28:	45a0      	cmp	r8, r4
d0083b2a:	f200 80d9 	bhi.w	d0083ce0 <__udivmoddi4+0x2bc>
d0083b2e:	4618      	mov	r0, r3
d0083b30:	eba4 0408 	sub.w	r4, r4, r8
d0083b34:	ea40 400c 	orr.w	r0, r0, ip, lsl #16
d0083b38:	e7bf      	b.n	d0083aba <__udivmoddi4+0x96>
d0083b3a:	428b      	cmp	r3, r1
d0083b3c:	d909      	bls.n	d0083b52 <__udivmoddi4+0x12e>
d0083b3e:	2d00      	cmp	r5, #0
d0083b40:	f000 80b1 	beq.w	d0083ca6 <__udivmoddi4+0x282>
d0083b44:	2600      	movs	r6, #0
d0083b46:	e9c5 0100 	strd	r0, r1, [r5]
d0083b4a:	4630      	mov	r0, r6
d0083b4c:	4631      	mov	r1, r6
d0083b4e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d0083b52:	fab3 f683 	clz	r6, r3
d0083b56:	2e00      	cmp	r6, #0
d0083b58:	d14a      	bne.n	d0083bf0 <__udivmoddi4+0x1cc>
d0083b5a:	428b      	cmp	r3, r1
d0083b5c:	d302      	bcc.n	d0083b64 <__udivmoddi4+0x140>
d0083b5e:	4282      	cmp	r2, r0
d0083b60:	f200 80b8 	bhi.w	d0083cd4 <__udivmoddi4+0x2b0>
d0083b64:	1a84      	subs	r4, r0, r2
d0083b66:	eb61 0103 	sbc.w	r1, r1, r3
d0083b6a:	2001      	movs	r0, #1
d0083b6c:	468c      	mov	ip, r1
d0083b6e:	2d00      	cmp	r5, #0
d0083b70:	d0a8      	beq.n	d0083ac4 <__udivmoddi4+0xa0>
d0083b72:	e9c5 4c00 	strd	r4, ip, [r5]
d0083b76:	e7a5      	b.n	d0083ac4 <__udivmoddi4+0xa0>
d0083b78:	f1c2 0320 	rsb	r3, r2, #32
d0083b7c:	fa20 f603 	lsr.w	r6, r0, r3
d0083b80:	4097      	lsls	r7, r2
d0083b82:	fa01 f002 	lsl.w	r0, r1, r2
d0083b86:	ea4f 4e17 	mov.w	lr, r7, lsr #16
d0083b8a:	40d9      	lsrs	r1, r3
d0083b8c:	4330      	orrs	r0, r6
d0083b8e:	0c03      	lsrs	r3, r0, #16
d0083b90:	fbb1 f6fe 	udiv	r6, r1, lr
d0083b94:	fa1f f887 	uxth.w	r8, r7
d0083b98:	fb0e 1116 	mls	r1, lr, r6, r1
d0083b9c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0083ba0:	fb06 f108 	mul.w	r1, r6, r8
d0083ba4:	4299      	cmp	r1, r3
d0083ba6:	fa04 f402 	lsl.w	r4, r4, r2
d0083baa:	d909      	bls.n	d0083bc0 <__udivmoddi4+0x19c>
d0083bac:	18fb      	adds	r3, r7, r3
d0083bae:	f106 3cff 	add.w	ip, r6, #4294967295	; 0xffffffff
d0083bb2:	f080 808d 	bcs.w	d0083cd0 <__udivmoddi4+0x2ac>
d0083bb6:	4299      	cmp	r1, r3
d0083bb8:	f240 808a 	bls.w	d0083cd0 <__udivmoddi4+0x2ac>
d0083bbc:	3e02      	subs	r6, #2
d0083bbe:	443b      	add	r3, r7
d0083bc0:	1a5b      	subs	r3, r3, r1
d0083bc2:	b281      	uxth	r1, r0
d0083bc4:	fbb3 f0fe 	udiv	r0, r3, lr
d0083bc8:	fb0e 3310 	mls	r3, lr, r0, r3
d0083bcc:	ea41 4103 	orr.w	r1, r1, r3, lsl #16
d0083bd0:	fb00 f308 	mul.w	r3, r0, r8
d0083bd4:	428b      	cmp	r3, r1
d0083bd6:	d907      	bls.n	d0083be8 <__udivmoddi4+0x1c4>
d0083bd8:	1879      	adds	r1, r7, r1
d0083bda:	f100 3cff 	add.w	ip, r0, #4294967295	; 0xffffffff
d0083bde:	d273      	bcs.n	d0083cc8 <__udivmoddi4+0x2a4>
d0083be0:	428b      	cmp	r3, r1
d0083be2:	d971      	bls.n	d0083cc8 <__udivmoddi4+0x2a4>
d0083be4:	3802      	subs	r0, #2
d0083be6:	4439      	add	r1, r7
d0083be8:	1acb      	subs	r3, r1, r3
d0083bea:	ea40 4606 	orr.w	r6, r0, r6, lsl #16
d0083bee:	e778      	b.n	d0083ae2 <__udivmoddi4+0xbe>
d0083bf0:	f1c6 0c20 	rsb	ip, r6, #32
d0083bf4:	fa03 f406 	lsl.w	r4, r3, r6
d0083bf8:	fa22 f30c 	lsr.w	r3, r2, ip
d0083bfc:	431c      	orrs	r4, r3
d0083bfe:	fa20 f70c 	lsr.w	r7, r0, ip
d0083c02:	fa01 f306 	lsl.w	r3, r1, r6
d0083c06:	ea4f 4e14 	mov.w	lr, r4, lsr #16
d0083c0a:	fa21 f10c 	lsr.w	r1, r1, ip
d0083c0e:	431f      	orrs	r7, r3
d0083c10:	0c3b      	lsrs	r3, r7, #16
d0083c12:	fbb1 f9fe 	udiv	r9, r1, lr
d0083c16:	fa1f f884 	uxth.w	r8, r4
d0083c1a:	fb0e 1119 	mls	r1, lr, r9, r1
d0083c1e:	ea43 4101 	orr.w	r1, r3, r1, lsl #16
d0083c22:	fb09 fa08 	mul.w	sl, r9, r8
d0083c26:	458a      	cmp	sl, r1
d0083c28:	fa02 f206 	lsl.w	r2, r2, r6
d0083c2c:	fa00 f306 	lsl.w	r3, r0, r6
d0083c30:	d908      	bls.n	d0083c44 <__udivmoddi4+0x220>
d0083c32:	1861      	adds	r1, r4, r1
d0083c34:	f109 30ff 	add.w	r0, r9, #4294967295	; 0xffffffff
d0083c38:	d248      	bcs.n	d0083ccc <__udivmoddi4+0x2a8>
d0083c3a:	458a      	cmp	sl, r1
d0083c3c:	d946      	bls.n	d0083ccc <__udivmoddi4+0x2a8>
d0083c3e:	f1a9 0902 	sub.w	r9, r9, #2
d0083c42:	4421      	add	r1, r4
d0083c44:	eba1 010a 	sub.w	r1, r1, sl
d0083c48:	b2bf      	uxth	r7, r7
d0083c4a:	fbb1 f0fe 	udiv	r0, r1, lr
d0083c4e:	fb0e 1110 	mls	r1, lr, r0, r1
d0083c52:	ea47 4701 	orr.w	r7, r7, r1, lsl #16
d0083c56:	fb00 f808 	mul.w	r8, r0, r8
d0083c5a:	45b8      	cmp	r8, r7
d0083c5c:	d907      	bls.n	d0083c6e <__udivmoddi4+0x24a>
d0083c5e:	19e7      	adds	r7, r4, r7
d0083c60:	f100 31ff 	add.w	r1, r0, #4294967295	; 0xffffffff
d0083c64:	d22e      	bcs.n	d0083cc4 <__udivmoddi4+0x2a0>
d0083c66:	45b8      	cmp	r8, r7
d0083c68:	d92c      	bls.n	d0083cc4 <__udivmoddi4+0x2a0>
d0083c6a:	3802      	subs	r0, #2
d0083c6c:	4427      	add	r7, r4
d0083c6e:	ea40 4009 	orr.w	r0, r0, r9, lsl #16
d0083c72:	eba7 0708 	sub.w	r7, r7, r8
d0083c76:	fba0 8902 	umull	r8, r9, r0, r2
d0083c7a:	454f      	cmp	r7, r9
d0083c7c:	46c6      	mov	lr, r8
d0083c7e:	4649      	mov	r1, r9
d0083c80:	d31a      	bcc.n	d0083cb8 <__udivmoddi4+0x294>
d0083c82:	d017      	beq.n	d0083cb4 <__udivmoddi4+0x290>
d0083c84:	b15d      	cbz	r5, d0083c9e <__udivmoddi4+0x27a>
d0083c86:	ebb3 020e 	subs.w	r2, r3, lr
d0083c8a:	eb67 0701 	sbc.w	r7, r7, r1
d0083c8e:	fa07 fc0c 	lsl.w	ip, r7, ip
d0083c92:	40f2      	lsrs	r2, r6
d0083c94:	ea4c 0202 	orr.w	r2, ip, r2
d0083c98:	40f7      	lsrs	r7, r6
d0083c9a:	e9c5 2700 	strd	r2, r7, [r5]
d0083c9e:	2600      	movs	r6, #0
d0083ca0:	4631      	mov	r1, r6
d0083ca2:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d0083ca6:	462e      	mov	r6, r5
d0083ca8:	4628      	mov	r0, r5
d0083caa:	e70b      	b.n	d0083ac4 <__udivmoddi4+0xa0>
d0083cac:	4606      	mov	r6, r0
d0083cae:	e6e9      	b.n	d0083a84 <__udivmoddi4+0x60>
d0083cb0:	4618      	mov	r0, r3
d0083cb2:	e6fd      	b.n	d0083ab0 <__udivmoddi4+0x8c>
d0083cb4:	4543      	cmp	r3, r8
d0083cb6:	d2e5      	bcs.n	d0083c84 <__udivmoddi4+0x260>
d0083cb8:	ebb8 0e02 	subs.w	lr, r8, r2
d0083cbc:	eb69 0104 	sbc.w	r1, r9, r4
d0083cc0:	3801      	subs	r0, #1
d0083cc2:	e7df      	b.n	d0083c84 <__udivmoddi4+0x260>
d0083cc4:	4608      	mov	r0, r1
d0083cc6:	e7d2      	b.n	d0083c6e <__udivmoddi4+0x24a>
d0083cc8:	4660      	mov	r0, ip
d0083cca:	e78d      	b.n	d0083be8 <__udivmoddi4+0x1c4>
d0083ccc:	4681      	mov	r9, r0
d0083cce:	e7b9      	b.n	d0083c44 <__udivmoddi4+0x220>
d0083cd0:	4666      	mov	r6, ip
d0083cd2:	e775      	b.n	d0083bc0 <__udivmoddi4+0x19c>
d0083cd4:	4630      	mov	r0, r6
d0083cd6:	e74a      	b.n	d0083b6e <__udivmoddi4+0x14a>
d0083cd8:	f1ac 0c02 	sub.w	ip, ip, #2
d0083cdc:	4439      	add	r1, r7
d0083cde:	e713      	b.n	d0083b08 <__udivmoddi4+0xe4>
d0083ce0:	3802      	subs	r0, #2
d0083ce2:	443c      	add	r4, r7
d0083ce4:	e724      	b.n	d0083b30 <__udivmoddi4+0x10c>
d0083ce6:	bf00      	nop

d0083ce8 <__aeabi_idiv0>:
d0083ce8:	4770      	bx	lr
d0083cea:	bf00      	nop

d0083cec <__errno>:
d0083cec:	4b01      	ldr	r3, [pc, #4]	; (d0083cf4 <__errno+0x8>)
d0083cee:	6818      	ldr	r0, [r3, #0]
d0083cf0:	4770      	bx	lr
d0083cf2:	bf00      	nop
d0083cf4:	d0084ab0 	.word	0xd0084ab0

d0083cf8 <malloc>:
d0083cf8:	4b02      	ldr	r3, [pc, #8]	; (d0083d04 <malloc+0xc>)
d0083cfa:	4601      	mov	r1, r0
d0083cfc:	6818      	ldr	r0, [r3, #0]
d0083cfe:	f000 b869 	b.w	d0083dd4 <_malloc_r>
d0083d02:	bf00      	nop
d0083d04:	d0084ab0 	.word	0xd0084ab0

d0083d08 <memcpy>:
d0083d08:	440a      	add	r2, r1
d0083d0a:	4291      	cmp	r1, r2
d0083d0c:	f100 33ff 	add.w	r3, r0, #4294967295	; 0xffffffff
d0083d10:	d100      	bne.n	d0083d14 <memcpy+0xc>
d0083d12:	4770      	bx	lr
d0083d14:	b510      	push	{r4, lr}
d0083d16:	f811 4b01 	ldrb.w	r4, [r1], #1
d0083d1a:	f803 4f01 	strb.w	r4, [r3, #1]!
d0083d1e:	4291      	cmp	r1, r2
d0083d20:	d1f9      	bne.n	d0083d16 <memcpy+0xe>
d0083d22:	bd10      	pop	{r4, pc}

d0083d24 <memset>:
d0083d24:	4402      	add	r2, r0
d0083d26:	4603      	mov	r3, r0
d0083d28:	4293      	cmp	r3, r2
d0083d2a:	d100      	bne.n	d0083d2e <memset+0xa>
d0083d2c:	4770      	bx	lr
d0083d2e:	f803 1b01 	strb.w	r1, [r3], #1
d0083d32:	e7f9      	b.n	d0083d28 <memset+0x4>

d0083d34 <_free_r>:
d0083d34:	b537      	push	{r0, r1, r2, r4, r5, lr}
d0083d36:	2900      	cmp	r1, #0
d0083d38:	d048      	beq.n	d0083dcc <_free_r+0x98>
d0083d3a:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0083d3e:	9001      	str	r0, [sp, #4]
d0083d40:	2b00      	cmp	r3, #0
d0083d42:	f1a1 0404 	sub.w	r4, r1, #4
d0083d46:	bfb8      	it	lt
d0083d48:	18e4      	addlt	r4, r4, r3
d0083d4a:	f000 fb61 	bl	d0084410 <__malloc_lock>
d0083d4e:	4a20      	ldr	r2, [pc, #128]	; (d0083dd0 <_free_r+0x9c>)
d0083d50:	9801      	ldr	r0, [sp, #4]
d0083d52:	6813      	ldr	r3, [r2, #0]
d0083d54:	4615      	mov	r5, r2
d0083d56:	b933      	cbnz	r3, d0083d66 <_free_r+0x32>
d0083d58:	6063      	str	r3, [r4, #4]
d0083d5a:	6014      	str	r4, [r2, #0]
d0083d5c:	b003      	add	sp, #12
d0083d5e:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d0083d62:	f000 bb5b 	b.w	d008441c <__malloc_unlock>
d0083d66:	42a3      	cmp	r3, r4
d0083d68:	d90b      	bls.n	d0083d82 <_free_r+0x4e>
d0083d6a:	6821      	ldr	r1, [r4, #0]
d0083d6c:	1862      	adds	r2, r4, r1
d0083d6e:	4293      	cmp	r3, r2
d0083d70:	bf04      	itt	eq
d0083d72:	681a      	ldreq	r2, [r3, #0]
d0083d74:	685b      	ldreq	r3, [r3, #4]
d0083d76:	6063      	str	r3, [r4, #4]
d0083d78:	bf04      	itt	eq
d0083d7a:	1852      	addeq	r2, r2, r1
d0083d7c:	6022      	streq	r2, [r4, #0]
d0083d7e:	602c      	str	r4, [r5, #0]
d0083d80:	e7ec      	b.n	d0083d5c <_free_r+0x28>
d0083d82:	461a      	mov	r2, r3
d0083d84:	685b      	ldr	r3, [r3, #4]
d0083d86:	b10b      	cbz	r3, d0083d8c <_free_r+0x58>
d0083d88:	42a3      	cmp	r3, r4
d0083d8a:	d9fa      	bls.n	d0083d82 <_free_r+0x4e>
d0083d8c:	6811      	ldr	r1, [r2, #0]
d0083d8e:	1855      	adds	r5, r2, r1
d0083d90:	42a5      	cmp	r5, r4
d0083d92:	d10b      	bne.n	d0083dac <_free_r+0x78>
d0083d94:	6824      	ldr	r4, [r4, #0]
d0083d96:	4421      	add	r1, r4
d0083d98:	1854      	adds	r4, r2, r1
d0083d9a:	42a3      	cmp	r3, r4
d0083d9c:	6011      	str	r1, [r2, #0]
d0083d9e:	d1dd      	bne.n	d0083d5c <_free_r+0x28>
d0083da0:	681c      	ldr	r4, [r3, #0]
d0083da2:	685b      	ldr	r3, [r3, #4]
d0083da4:	6053      	str	r3, [r2, #4]
d0083da6:	4421      	add	r1, r4
d0083da8:	6011      	str	r1, [r2, #0]
d0083daa:	e7d7      	b.n	d0083d5c <_free_r+0x28>
d0083dac:	d902      	bls.n	d0083db4 <_free_r+0x80>
d0083dae:	230c      	movs	r3, #12
d0083db0:	6003      	str	r3, [r0, #0]
d0083db2:	e7d3      	b.n	d0083d5c <_free_r+0x28>
d0083db4:	6825      	ldr	r5, [r4, #0]
d0083db6:	1961      	adds	r1, r4, r5
d0083db8:	428b      	cmp	r3, r1
d0083dba:	bf04      	itt	eq
d0083dbc:	6819      	ldreq	r1, [r3, #0]
d0083dbe:	685b      	ldreq	r3, [r3, #4]
d0083dc0:	6063      	str	r3, [r4, #4]
d0083dc2:	bf04      	itt	eq
d0083dc4:	1949      	addeq	r1, r1, r5
d0083dc6:	6021      	streq	r1, [r4, #0]
d0083dc8:	6054      	str	r4, [r2, #4]
d0083dca:	e7c7      	b.n	d0083d5c <_free_r+0x28>
d0083dcc:	b003      	add	sp, #12
d0083dce:	bd30      	pop	{r4, r5, pc}
d0083dd0:	d00b4d40 	.word	0xd00b4d40

d0083dd4 <_malloc_r>:
d0083dd4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0083dd6:	1ccd      	adds	r5, r1, #3
d0083dd8:	f025 0503 	bic.w	r5, r5, #3
d0083ddc:	3508      	adds	r5, #8
d0083dde:	2d0c      	cmp	r5, #12
d0083de0:	bf38      	it	cc
d0083de2:	250c      	movcc	r5, #12
d0083de4:	2d00      	cmp	r5, #0
d0083de6:	4606      	mov	r6, r0
d0083de8:	db01      	blt.n	d0083dee <_malloc_r+0x1a>
d0083dea:	42a9      	cmp	r1, r5
d0083dec:	d903      	bls.n	d0083df6 <_malloc_r+0x22>
d0083dee:	230c      	movs	r3, #12
d0083df0:	6033      	str	r3, [r6, #0]
d0083df2:	2000      	movs	r0, #0
d0083df4:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0083df6:	f000 fb0b 	bl	d0084410 <__malloc_lock>
d0083dfa:	4921      	ldr	r1, [pc, #132]	; (d0083e80 <_malloc_r+0xac>)
d0083dfc:	680a      	ldr	r2, [r1, #0]
d0083dfe:	4614      	mov	r4, r2
d0083e00:	b99c      	cbnz	r4, d0083e2a <_malloc_r+0x56>
d0083e02:	4f20      	ldr	r7, [pc, #128]	; (d0083e84 <_malloc_r+0xb0>)
d0083e04:	683b      	ldr	r3, [r7, #0]
d0083e06:	b923      	cbnz	r3, d0083e12 <_malloc_r+0x3e>
d0083e08:	4621      	mov	r1, r4
d0083e0a:	4630      	mov	r0, r6
d0083e0c:	f7fc f968 	bl	d00800e0 <_sbrk_r>
d0083e10:	6038      	str	r0, [r7, #0]
d0083e12:	4629      	mov	r1, r5
d0083e14:	4630      	mov	r0, r6
d0083e16:	f7fc f963 	bl	d00800e0 <_sbrk_r>
d0083e1a:	1c43      	adds	r3, r0, #1
d0083e1c:	d123      	bne.n	d0083e66 <_malloc_r+0x92>
d0083e1e:	230c      	movs	r3, #12
d0083e20:	6033      	str	r3, [r6, #0]
d0083e22:	4630      	mov	r0, r6
d0083e24:	f000 fafa 	bl	d008441c <__malloc_unlock>
d0083e28:	e7e3      	b.n	d0083df2 <_malloc_r+0x1e>
d0083e2a:	6823      	ldr	r3, [r4, #0]
d0083e2c:	1b5b      	subs	r3, r3, r5
d0083e2e:	d417      	bmi.n	d0083e60 <_malloc_r+0x8c>
d0083e30:	2b0b      	cmp	r3, #11
d0083e32:	d903      	bls.n	d0083e3c <_malloc_r+0x68>
d0083e34:	6023      	str	r3, [r4, #0]
d0083e36:	441c      	add	r4, r3
d0083e38:	6025      	str	r5, [r4, #0]
d0083e3a:	e004      	b.n	d0083e46 <_malloc_r+0x72>
d0083e3c:	6863      	ldr	r3, [r4, #4]
d0083e3e:	42a2      	cmp	r2, r4
d0083e40:	bf0c      	ite	eq
d0083e42:	600b      	streq	r3, [r1, #0]
d0083e44:	6053      	strne	r3, [r2, #4]
d0083e46:	4630      	mov	r0, r6
d0083e48:	f000 fae8 	bl	d008441c <__malloc_unlock>
d0083e4c:	f104 000b 	add.w	r0, r4, #11
d0083e50:	1d23      	adds	r3, r4, #4
d0083e52:	f020 0007 	bic.w	r0, r0, #7
d0083e56:	1ac2      	subs	r2, r0, r3
d0083e58:	d0cc      	beq.n	d0083df4 <_malloc_r+0x20>
d0083e5a:	1a1b      	subs	r3, r3, r0
d0083e5c:	50a3      	str	r3, [r4, r2]
d0083e5e:	e7c9      	b.n	d0083df4 <_malloc_r+0x20>
d0083e60:	4622      	mov	r2, r4
d0083e62:	6864      	ldr	r4, [r4, #4]
d0083e64:	e7cc      	b.n	d0083e00 <_malloc_r+0x2c>
d0083e66:	1cc4      	adds	r4, r0, #3
d0083e68:	f024 0403 	bic.w	r4, r4, #3
d0083e6c:	42a0      	cmp	r0, r4
d0083e6e:	d0e3      	beq.n	d0083e38 <_malloc_r+0x64>
d0083e70:	1a21      	subs	r1, r4, r0
d0083e72:	4630      	mov	r0, r6
d0083e74:	f7fc f934 	bl	d00800e0 <_sbrk_r>
d0083e78:	3001      	adds	r0, #1
d0083e7a:	d1dd      	bne.n	d0083e38 <_malloc_r+0x64>
d0083e7c:	e7cf      	b.n	d0083e1e <_malloc_r+0x4a>
d0083e7e:	bf00      	nop
d0083e80:	d00b4d40 	.word	0xd00b4d40
d0083e84:	d00b4d44 	.word	0xd00b4d44

d0083e88 <setbuf>:
d0083e88:	2900      	cmp	r1, #0
d0083e8a:	f44f 6380 	mov.w	r3, #1024	; 0x400
d0083e8e:	bf0c      	ite	eq
d0083e90:	2202      	moveq	r2, #2
d0083e92:	2200      	movne	r2, #0
d0083e94:	f000 b800 	b.w	d0083e98 <setvbuf>

d0083e98 <setvbuf>:
d0083e98:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d0083e9c:	461d      	mov	r5, r3
d0083e9e:	4b5d      	ldr	r3, [pc, #372]	; (d0084014 <setvbuf+0x17c>)
d0083ea0:	681f      	ldr	r7, [r3, #0]
d0083ea2:	4604      	mov	r4, r0
d0083ea4:	460e      	mov	r6, r1
d0083ea6:	4690      	mov	r8, r2
d0083ea8:	b127      	cbz	r7, d0083eb4 <setvbuf+0x1c>
d0083eaa:	69bb      	ldr	r3, [r7, #24]
d0083eac:	b913      	cbnz	r3, d0083eb4 <setvbuf+0x1c>
d0083eae:	4638      	mov	r0, r7
d0083eb0:	f000 f9ea 	bl	d0084288 <__sinit>
d0083eb4:	4b58      	ldr	r3, [pc, #352]	; (d0084018 <setvbuf+0x180>)
d0083eb6:	429c      	cmp	r4, r3
d0083eb8:	d167      	bne.n	d0083f8a <setvbuf+0xf2>
d0083eba:	687c      	ldr	r4, [r7, #4]
d0083ebc:	f1b8 0f02 	cmp.w	r8, #2
d0083ec0:	d006      	beq.n	d0083ed0 <setvbuf+0x38>
d0083ec2:	f1b8 0f01 	cmp.w	r8, #1
d0083ec6:	f200 809f 	bhi.w	d0084008 <setvbuf+0x170>
d0083eca:	2d00      	cmp	r5, #0
d0083ecc:	f2c0 809c 	blt.w	d0084008 <setvbuf+0x170>
d0083ed0:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0083ed2:	07db      	lsls	r3, r3, #31
d0083ed4:	d405      	bmi.n	d0083ee2 <setvbuf+0x4a>
d0083ed6:	89a3      	ldrh	r3, [r4, #12]
d0083ed8:	0598      	lsls	r0, r3, #22
d0083eda:	d402      	bmi.n	d0083ee2 <setvbuf+0x4a>
d0083edc:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0083ede:	f000 fa71 	bl	d00843c4 <__retarget_lock_acquire_recursive>
d0083ee2:	4621      	mov	r1, r4
d0083ee4:	4638      	mov	r0, r7
d0083ee6:	f000 f93b 	bl	d0084160 <_fflush_r>
d0083eea:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0083eec:	b141      	cbz	r1, d0083f00 <setvbuf+0x68>
d0083eee:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0083ef2:	4299      	cmp	r1, r3
d0083ef4:	d002      	beq.n	d0083efc <setvbuf+0x64>
d0083ef6:	4638      	mov	r0, r7
d0083ef8:	f7ff ff1c 	bl	d0083d34 <_free_r>
d0083efc:	2300      	movs	r3, #0
d0083efe:	6363      	str	r3, [r4, #52]	; 0x34
d0083f00:	2300      	movs	r3, #0
d0083f02:	61a3      	str	r3, [r4, #24]
d0083f04:	6063      	str	r3, [r4, #4]
d0083f06:	89a3      	ldrh	r3, [r4, #12]
d0083f08:	0619      	lsls	r1, r3, #24
d0083f0a:	d503      	bpl.n	d0083f14 <setvbuf+0x7c>
d0083f0c:	6921      	ldr	r1, [r4, #16]
d0083f0e:	4638      	mov	r0, r7
d0083f10:	f7ff ff10 	bl	d0083d34 <_free_r>
d0083f14:	89a3      	ldrh	r3, [r4, #12]
d0083f16:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d0083f1a:	f023 0303 	bic.w	r3, r3, #3
d0083f1e:	f1b8 0f02 	cmp.w	r8, #2
d0083f22:	81a3      	strh	r3, [r4, #12]
d0083f24:	d06c      	beq.n	d0084000 <setvbuf+0x168>
d0083f26:	ab01      	add	r3, sp, #4
d0083f28:	466a      	mov	r2, sp
d0083f2a:	4621      	mov	r1, r4
d0083f2c:	4638      	mov	r0, r7
d0083f2e:	f000 fa4b 	bl	d00843c8 <__swhatbuf_r>
d0083f32:	89a3      	ldrh	r3, [r4, #12]
d0083f34:	4318      	orrs	r0, r3
d0083f36:	81a0      	strh	r0, [r4, #12]
d0083f38:	2d00      	cmp	r5, #0
d0083f3a:	d130      	bne.n	d0083f9e <setvbuf+0x106>
d0083f3c:	9d00      	ldr	r5, [sp, #0]
d0083f3e:	4628      	mov	r0, r5
d0083f40:	f7ff feda 	bl	d0083cf8 <malloc>
d0083f44:	4606      	mov	r6, r0
d0083f46:	2800      	cmp	r0, #0
d0083f48:	d155      	bne.n	d0083ff6 <setvbuf+0x15e>
d0083f4a:	f8dd 9000 	ldr.w	r9, [sp]
d0083f4e:	45a9      	cmp	r9, r5
d0083f50:	d14a      	bne.n	d0083fe8 <setvbuf+0x150>
d0083f52:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0083f56:	2200      	movs	r2, #0
d0083f58:	60a2      	str	r2, [r4, #8]
d0083f5a:	f104 0247 	add.w	r2, r4, #71	; 0x47
d0083f5e:	6022      	str	r2, [r4, #0]
d0083f60:	6122      	str	r2, [r4, #16]
d0083f62:	2201      	movs	r2, #1
d0083f64:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0083f68:	6162      	str	r2, [r4, #20]
d0083f6a:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0083f6c:	f043 0302 	orr.w	r3, r3, #2
d0083f70:	07d2      	lsls	r2, r2, #31
d0083f72:	81a3      	strh	r3, [r4, #12]
d0083f74:	d405      	bmi.n	d0083f82 <setvbuf+0xea>
d0083f76:	f413 7f00 	tst.w	r3, #512	; 0x200
d0083f7a:	d102      	bne.n	d0083f82 <setvbuf+0xea>
d0083f7c:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0083f7e:	f000 fa22 	bl	d00843c6 <__retarget_lock_release_recursive>
d0083f82:	4628      	mov	r0, r5
d0083f84:	b003      	add	sp, #12
d0083f86:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0083f8a:	4b24      	ldr	r3, [pc, #144]	; (d008401c <setvbuf+0x184>)
d0083f8c:	429c      	cmp	r4, r3
d0083f8e:	d101      	bne.n	d0083f94 <setvbuf+0xfc>
d0083f90:	68bc      	ldr	r4, [r7, #8]
d0083f92:	e793      	b.n	d0083ebc <setvbuf+0x24>
d0083f94:	4b22      	ldr	r3, [pc, #136]	; (d0084020 <setvbuf+0x188>)
d0083f96:	429c      	cmp	r4, r3
d0083f98:	bf08      	it	eq
d0083f9a:	68fc      	ldreq	r4, [r7, #12]
d0083f9c:	e78e      	b.n	d0083ebc <setvbuf+0x24>
d0083f9e:	2e00      	cmp	r6, #0
d0083fa0:	d0cd      	beq.n	d0083f3e <setvbuf+0xa6>
d0083fa2:	69bb      	ldr	r3, [r7, #24]
d0083fa4:	b913      	cbnz	r3, d0083fac <setvbuf+0x114>
d0083fa6:	4638      	mov	r0, r7
d0083fa8:	f000 f96e 	bl	d0084288 <__sinit>
d0083fac:	f1b8 0f01 	cmp.w	r8, #1
d0083fb0:	bf08      	it	eq
d0083fb2:	89a3      	ldrheq	r3, [r4, #12]
d0083fb4:	6026      	str	r6, [r4, #0]
d0083fb6:	bf04      	itt	eq
d0083fb8:	f043 0301 	orreq.w	r3, r3, #1
d0083fbc:	81a3      	strheq	r3, [r4, #12]
d0083fbe:	89a2      	ldrh	r2, [r4, #12]
d0083fc0:	f012 0308 	ands.w	r3, r2, #8
d0083fc4:	e9c4 6504 	strd	r6, r5, [r4, #16]
d0083fc8:	d01c      	beq.n	d0084004 <setvbuf+0x16c>
d0083fca:	07d3      	lsls	r3, r2, #31
d0083fcc:	bf41      	itttt	mi
d0083fce:	2300      	movmi	r3, #0
d0083fd0:	426d      	negmi	r5, r5
d0083fd2:	60a3      	strmi	r3, [r4, #8]
d0083fd4:	61a5      	strmi	r5, [r4, #24]
d0083fd6:	bf58      	it	pl
d0083fd8:	60a5      	strpl	r5, [r4, #8]
d0083fda:	6e65      	ldr	r5, [r4, #100]	; 0x64
d0083fdc:	f015 0501 	ands.w	r5, r5, #1
d0083fe0:	d115      	bne.n	d008400e <setvbuf+0x176>
d0083fe2:	f412 7f00 	tst.w	r2, #512	; 0x200
d0083fe6:	e7c8      	b.n	d0083f7a <setvbuf+0xe2>
d0083fe8:	4648      	mov	r0, r9
d0083fea:	f7ff fe85 	bl	d0083cf8 <malloc>
d0083fee:	4606      	mov	r6, r0
d0083ff0:	2800      	cmp	r0, #0
d0083ff2:	d0ae      	beq.n	d0083f52 <setvbuf+0xba>
d0083ff4:	464d      	mov	r5, r9
d0083ff6:	89a3      	ldrh	r3, [r4, #12]
d0083ff8:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0083ffc:	81a3      	strh	r3, [r4, #12]
d0083ffe:	e7d0      	b.n	d0083fa2 <setvbuf+0x10a>
d0084000:	2500      	movs	r5, #0
d0084002:	e7a8      	b.n	d0083f56 <setvbuf+0xbe>
d0084004:	60a3      	str	r3, [r4, #8]
d0084006:	e7e8      	b.n	d0083fda <setvbuf+0x142>
d0084008:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d008400c:	e7b9      	b.n	d0083f82 <setvbuf+0xea>
d008400e:	2500      	movs	r5, #0
d0084010:	e7b7      	b.n	d0083f82 <setvbuf+0xea>
d0084012:	bf00      	nop
d0084014:	d0084ab0 	.word	0xd0084ab0
d0084018:	d0084a5c 	.word	0xd0084a5c
d008401c:	d0084a7c 	.word	0xd0084a7c
d0084020:	d0084a3c 	.word	0xd0084a3c

d0084024 <strcat>:
d0084024:	b510      	push	{r4, lr}
d0084026:	4602      	mov	r2, r0
d0084028:	7814      	ldrb	r4, [r2, #0]
d008402a:	4613      	mov	r3, r2
d008402c:	3201      	adds	r2, #1
d008402e:	2c00      	cmp	r4, #0
d0084030:	d1fa      	bne.n	d0084028 <strcat+0x4>
d0084032:	3b01      	subs	r3, #1
d0084034:	f811 2b01 	ldrb.w	r2, [r1], #1
d0084038:	f803 2f01 	strb.w	r2, [r3, #1]!
d008403c:	2a00      	cmp	r2, #0
d008403e:	d1f9      	bne.n	d0084034 <strcat+0x10>
d0084040:	bd10      	pop	{r4, pc}

d0084042 <strlen>:
d0084042:	4603      	mov	r3, r0
d0084044:	f813 2b01 	ldrb.w	r2, [r3], #1
d0084048:	2a00      	cmp	r2, #0
d008404a:	d1fb      	bne.n	d0084044 <strlen+0x2>
d008404c:	1a18      	subs	r0, r3, r0
d008404e:	3801      	subs	r0, #1
d0084050:	4770      	bx	lr
	...

d0084054 <__sflush_r>:
d0084054:	898a      	ldrh	r2, [r1, #12]
d0084056:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008405a:	4605      	mov	r5, r0
d008405c:	0710      	lsls	r0, r2, #28
d008405e:	460c      	mov	r4, r1
d0084060:	d458      	bmi.n	d0084114 <__sflush_r+0xc0>
d0084062:	684b      	ldr	r3, [r1, #4]
d0084064:	2b00      	cmp	r3, #0
d0084066:	dc05      	bgt.n	d0084074 <__sflush_r+0x20>
d0084068:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d008406a:	2b00      	cmp	r3, #0
d008406c:	dc02      	bgt.n	d0084074 <__sflush_r+0x20>
d008406e:	2000      	movs	r0, #0
d0084070:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0084074:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0084076:	2e00      	cmp	r6, #0
d0084078:	d0f9      	beq.n	d008406e <__sflush_r+0x1a>
d008407a:	2300      	movs	r3, #0
d008407c:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d0084080:	682f      	ldr	r7, [r5, #0]
d0084082:	602b      	str	r3, [r5, #0]
d0084084:	d032      	beq.n	d00840ec <__sflush_r+0x98>
d0084086:	6d60      	ldr	r0, [r4, #84]	; 0x54
d0084088:	89a3      	ldrh	r3, [r4, #12]
d008408a:	075a      	lsls	r2, r3, #29
d008408c:	d505      	bpl.n	d008409a <__sflush_r+0x46>
d008408e:	6863      	ldr	r3, [r4, #4]
d0084090:	1ac0      	subs	r0, r0, r3
d0084092:	6b63      	ldr	r3, [r4, #52]	; 0x34
d0084094:	b10b      	cbz	r3, d008409a <__sflush_r+0x46>
d0084096:	6c23      	ldr	r3, [r4, #64]	; 0x40
d0084098:	1ac0      	subs	r0, r0, r3
d008409a:	2300      	movs	r3, #0
d008409c:	4602      	mov	r2, r0
d008409e:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d00840a0:	6a21      	ldr	r1, [r4, #32]
d00840a2:	4628      	mov	r0, r5
d00840a4:	47b0      	blx	r6
d00840a6:	1c43      	adds	r3, r0, #1
d00840a8:	89a3      	ldrh	r3, [r4, #12]
d00840aa:	d106      	bne.n	d00840ba <__sflush_r+0x66>
d00840ac:	6829      	ldr	r1, [r5, #0]
d00840ae:	291d      	cmp	r1, #29
d00840b0:	d82c      	bhi.n	d008410c <__sflush_r+0xb8>
d00840b2:	4a2a      	ldr	r2, [pc, #168]	; (d008415c <__sflush_r+0x108>)
d00840b4:	40ca      	lsrs	r2, r1
d00840b6:	07d6      	lsls	r6, r2, #31
d00840b8:	d528      	bpl.n	d008410c <__sflush_r+0xb8>
d00840ba:	2200      	movs	r2, #0
d00840bc:	6062      	str	r2, [r4, #4]
d00840be:	04d9      	lsls	r1, r3, #19
d00840c0:	6922      	ldr	r2, [r4, #16]
d00840c2:	6022      	str	r2, [r4, #0]
d00840c4:	d504      	bpl.n	d00840d0 <__sflush_r+0x7c>
d00840c6:	1c42      	adds	r2, r0, #1
d00840c8:	d101      	bne.n	d00840ce <__sflush_r+0x7a>
d00840ca:	682b      	ldr	r3, [r5, #0]
d00840cc:	b903      	cbnz	r3, d00840d0 <__sflush_r+0x7c>
d00840ce:	6560      	str	r0, [r4, #84]	; 0x54
d00840d0:	6b61      	ldr	r1, [r4, #52]	; 0x34
d00840d2:	602f      	str	r7, [r5, #0]
d00840d4:	2900      	cmp	r1, #0
d00840d6:	d0ca      	beq.n	d008406e <__sflush_r+0x1a>
d00840d8:	f104 0344 	add.w	r3, r4, #68	; 0x44
d00840dc:	4299      	cmp	r1, r3
d00840de:	d002      	beq.n	d00840e6 <__sflush_r+0x92>
d00840e0:	4628      	mov	r0, r5
d00840e2:	f7ff fe27 	bl	d0083d34 <_free_r>
d00840e6:	2000      	movs	r0, #0
d00840e8:	6360      	str	r0, [r4, #52]	; 0x34
d00840ea:	e7c1      	b.n	d0084070 <__sflush_r+0x1c>
d00840ec:	6a21      	ldr	r1, [r4, #32]
d00840ee:	2301      	movs	r3, #1
d00840f0:	4628      	mov	r0, r5
d00840f2:	47b0      	blx	r6
d00840f4:	1c41      	adds	r1, r0, #1
d00840f6:	d1c7      	bne.n	d0084088 <__sflush_r+0x34>
d00840f8:	682b      	ldr	r3, [r5, #0]
d00840fa:	2b00      	cmp	r3, #0
d00840fc:	d0c4      	beq.n	d0084088 <__sflush_r+0x34>
d00840fe:	2b1d      	cmp	r3, #29
d0084100:	d001      	beq.n	d0084106 <__sflush_r+0xb2>
d0084102:	2b16      	cmp	r3, #22
d0084104:	d101      	bne.n	d008410a <__sflush_r+0xb6>
d0084106:	602f      	str	r7, [r5, #0]
d0084108:	e7b1      	b.n	d008406e <__sflush_r+0x1a>
d008410a:	89a3      	ldrh	r3, [r4, #12]
d008410c:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0084110:	81a3      	strh	r3, [r4, #12]
d0084112:	e7ad      	b.n	d0084070 <__sflush_r+0x1c>
d0084114:	690f      	ldr	r7, [r1, #16]
d0084116:	2f00      	cmp	r7, #0
d0084118:	d0a9      	beq.n	d008406e <__sflush_r+0x1a>
d008411a:	0793      	lsls	r3, r2, #30
d008411c:	680e      	ldr	r6, [r1, #0]
d008411e:	bf08      	it	eq
d0084120:	694b      	ldreq	r3, [r1, #20]
d0084122:	600f      	str	r7, [r1, #0]
d0084124:	bf18      	it	ne
d0084126:	2300      	movne	r3, #0
d0084128:	eba6 0807 	sub.w	r8, r6, r7
d008412c:	608b      	str	r3, [r1, #8]
d008412e:	f1b8 0f00 	cmp.w	r8, #0
d0084132:	dd9c      	ble.n	d008406e <__sflush_r+0x1a>
d0084134:	6a21      	ldr	r1, [r4, #32]
d0084136:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d0084138:	4643      	mov	r3, r8
d008413a:	463a      	mov	r2, r7
d008413c:	4628      	mov	r0, r5
d008413e:	47b0      	blx	r6
d0084140:	2800      	cmp	r0, #0
d0084142:	dc06      	bgt.n	d0084152 <__sflush_r+0xfe>
d0084144:	89a3      	ldrh	r3, [r4, #12]
d0084146:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d008414a:	81a3      	strh	r3, [r4, #12]
d008414c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0084150:	e78e      	b.n	d0084070 <__sflush_r+0x1c>
d0084152:	4407      	add	r7, r0
d0084154:	eba8 0800 	sub.w	r8, r8, r0
d0084158:	e7e9      	b.n	d008412e <__sflush_r+0xda>
d008415a:	bf00      	nop
d008415c:	20400001 	.word	0x20400001

d0084160 <_fflush_r>:
d0084160:	b538      	push	{r3, r4, r5, lr}
d0084162:	690b      	ldr	r3, [r1, #16]
d0084164:	4605      	mov	r5, r0
d0084166:	460c      	mov	r4, r1
d0084168:	b913      	cbnz	r3, d0084170 <_fflush_r+0x10>
d008416a:	2500      	movs	r5, #0
d008416c:	4628      	mov	r0, r5
d008416e:	bd38      	pop	{r3, r4, r5, pc}
d0084170:	b118      	cbz	r0, d008417a <_fflush_r+0x1a>
d0084172:	6983      	ldr	r3, [r0, #24]
d0084174:	b90b      	cbnz	r3, d008417a <_fflush_r+0x1a>
d0084176:	f000 f887 	bl	d0084288 <__sinit>
d008417a:	4b14      	ldr	r3, [pc, #80]	; (d00841cc <_fflush_r+0x6c>)
d008417c:	429c      	cmp	r4, r3
d008417e:	d11b      	bne.n	d00841b8 <_fflush_r+0x58>
d0084180:	686c      	ldr	r4, [r5, #4]
d0084182:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0084186:	2b00      	cmp	r3, #0
d0084188:	d0ef      	beq.n	d008416a <_fflush_r+0xa>
d008418a:	6e62      	ldr	r2, [r4, #100]	; 0x64
d008418c:	07d0      	lsls	r0, r2, #31
d008418e:	d404      	bmi.n	d008419a <_fflush_r+0x3a>
d0084190:	0599      	lsls	r1, r3, #22
d0084192:	d402      	bmi.n	d008419a <_fflush_r+0x3a>
d0084194:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0084196:	f000 f915 	bl	d00843c4 <__retarget_lock_acquire_recursive>
d008419a:	4628      	mov	r0, r5
d008419c:	4621      	mov	r1, r4
d008419e:	f7ff ff59 	bl	d0084054 <__sflush_r>
d00841a2:	6e63      	ldr	r3, [r4, #100]	; 0x64
d00841a4:	07da      	lsls	r2, r3, #31
d00841a6:	4605      	mov	r5, r0
d00841a8:	d4e0      	bmi.n	d008416c <_fflush_r+0xc>
d00841aa:	89a3      	ldrh	r3, [r4, #12]
d00841ac:	059b      	lsls	r3, r3, #22
d00841ae:	d4dd      	bmi.n	d008416c <_fflush_r+0xc>
d00841b0:	6da0      	ldr	r0, [r4, #88]	; 0x58
d00841b2:	f000 f908 	bl	d00843c6 <__retarget_lock_release_recursive>
d00841b6:	e7d9      	b.n	d008416c <_fflush_r+0xc>
d00841b8:	4b05      	ldr	r3, [pc, #20]	; (d00841d0 <_fflush_r+0x70>)
d00841ba:	429c      	cmp	r4, r3
d00841bc:	d101      	bne.n	d00841c2 <_fflush_r+0x62>
d00841be:	68ac      	ldr	r4, [r5, #8]
d00841c0:	e7df      	b.n	d0084182 <_fflush_r+0x22>
d00841c2:	4b04      	ldr	r3, [pc, #16]	; (d00841d4 <_fflush_r+0x74>)
d00841c4:	429c      	cmp	r4, r3
d00841c6:	bf08      	it	eq
d00841c8:	68ec      	ldreq	r4, [r5, #12]
d00841ca:	e7da      	b.n	d0084182 <_fflush_r+0x22>
d00841cc:	d0084a5c 	.word	0xd0084a5c
d00841d0:	d0084a7c 	.word	0xd0084a7c
d00841d4:	d0084a3c 	.word	0xd0084a3c

d00841d8 <std>:
d00841d8:	2300      	movs	r3, #0
d00841da:	b510      	push	{r4, lr}
d00841dc:	4604      	mov	r4, r0
d00841de:	e9c0 3300 	strd	r3, r3, [r0]
d00841e2:	e9c0 3304 	strd	r3, r3, [r0, #16]
d00841e6:	6083      	str	r3, [r0, #8]
d00841e8:	8181      	strh	r1, [r0, #12]
d00841ea:	6643      	str	r3, [r0, #100]	; 0x64
d00841ec:	81c2      	strh	r2, [r0, #14]
d00841ee:	6183      	str	r3, [r0, #24]
d00841f0:	4619      	mov	r1, r3
d00841f2:	2208      	movs	r2, #8
d00841f4:	305c      	adds	r0, #92	; 0x5c
d00841f6:	f7ff fd95 	bl	d0083d24 <memset>
d00841fa:	4b05      	ldr	r3, [pc, #20]	; (d0084210 <std+0x38>)
d00841fc:	6263      	str	r3, [r4, #36]	; 0x24
d00841fe:	4b05      	ldr	r3, [pc, #20]	; (d0084214 <std+0x3c>)
d0084200:	62a3      	str	r3, [r4, #40]	; 0x28
d0084202:	4b05      	ldr	r3, [pc, #20]	; (d0084218 <std+0x40>)
d0084204:	62e3      	str	r3, [r4, #44]	; 0x2c
d0084206:	4b05      	ldr	r3, [pc, #20]	; (d008421c <std+0x44>)
d0084208:	6224      	str	r4, [r4, #32]
d008420a:	6323      	str	r3, [r4, #48]	; 0x30
d008420c:	bd10      	pop	{r4, pc}
d008420e:	bf00      	nop
d0084210:	d0084429 	.word	0xd0084429
d0084214:	d008444b 	.word	0xd008444b
d0084218:	d0084483 	.word	0xd0084483
d008421c:	d00844a7 	.word	0xd00844a7

d0084220 <_cleanup_r>:
d0084220:	4901      	ldr	r1, [pc, #4]	; (d0084228 <_cleanup_r+0x8>)
d0084222:	f000 b8af 	b.w	d0084384 <_fwalk_reent>
d0084226:	bf00      	nop
d0084228:	d0084161 	.word	0xd0084161

d008422c <__sfmoreglue>:
d008422c:	b570      	push	{r4, r5, r6, lr}
d008422e:	1e4a      	subs	r2, r1, #1
d0084230:	2568      	movs	r5, #104	; 0x68
d0084232:	4355      	muls	r5, r2
d0084234:	460e      	mov	r6, r1
d0084236:	f105 0174 	add.w	r1, r5, #116	; 0x74
d008423a:	f7ff fdcb 	bl	d0083dd4 <_malloc_r>
d008423e:	4604      	mov	r4, r0
d0084240:	b140      	cbz	r0, d0084254 <__sfmoreglue+0x28>
d0084242:	2100      	movs	r1, #0
d0084244:	e9c0 1600 	strd	r1, r6, [r0]
d0084248:	300c      	adds	r0, #12
d008424a:	60a0      	str	r0, [r4, #8]
d008424c:	f105 0268 	add.w	r2, r5, #104	; 0x68
d0084250:	f7ff fd68 	bl	d0083d24 <memset>
d0084254:	4620      	mov	r0, r4
d0084256:	bd70      	pop	{r4, r5, r6, pc}

d0084258 <__sfp_lock_acquire>:
d0084258:	4801      	ldr	r0, [pc, #4]	; (d0084260 <__sfp_lock_acquire+0x8>)
d008425a:	f000 b8b3 	b.w	d00843c4 <__retarget_lock_acquire_recursive>
d008425e:	bf00      	nop
d0084260:	d00b4d54 	.word	0xd00b4d54

d0084264 <__sfp_lock_release>:
d0084264:	4801      	ldr	r0, [pc, #4]	; (d008426c <__sfp_lock_release+0x8>)
d0084266:	f000 b8ae 	b.w	d00843c6 <__retarget_lock_release_recursive>
d008426a:	bf00      	nop
d008426c:	d00b4d54 	.word	0xd00b4d54

d0084270 <__sinit_lock_acquire>:
d0084270:	4801      	ldr	r0, [pc, #4]	; (d0084278 <__sinit_lock_acquire+0x8>)
d0084272:	f000 b8a7 	b.w	d00843c4 <__retarget_lock_acquire_recursive>
d0084276:	bf00      	nop
d0084278:	d00b4d4f 	.word	0xd00b4d4f

d008427c <__sinit_lock_release>:
d008427c:	4801      	ldr	r0, [pc, #4]	; (d0084284 <__sinit_lock_release+0x8>)
d008427e:	f000 b8a2 	b.w	d00843c6 <__retarget_lock_release_recursive>
d0084282:	bf00      	nop
d0084284:	d00b4d4f 	.word	0xd00b4d4f

d0084288 <__sinit>:
d0084288:	b510      	push	{r4, lr}
d008428a:	4604      	mov	r4, r0
d008428c:	f7ff fff0 	bl	d0084270 <__sinit_lock_acquire>
d0084290:	69a3      	ldr	r3, [r4, #24]
d0084292:	b11b      	cbz	r3, d008429c <__sinit+0x14>
d0084294:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d0084298:	f7ff bff0 	b.w	d008427c <__sinit_lock_release>
d008429c:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d00842a0:	6523      	str	r3, [r4, #80]	; 0x50
d00842a2:	4b13      	ldr	r3, [pc, #76]	; (d00842f0 <__sinit+0x68>)
d00842a4:	4a13      	ldr	r2, [pc, #76]	; (d00842f4 <__sinit+0x6c>)
d00842a6:	681b      	ldr	r3, [r3, #0]
d00842a8:	62a2      	str	r2, [r4, #40]	; 0x28
d00842aa:	42a3      	cmp	r3, r4
d00842ac:	bf04      	itt	eq
d00842ae:	2301      	moveq	r3, #1
d00842b0:	61a3      	streq	r3, [r4, #24]
d00842b2:	4620      	mov	r0, r4
d00842b4:	f000 f820 	bl	d00842f8 <__sfp>
d00842b8:	6060      	str	r0, [r4, #4]
d00842ba:	4620      	mov	r0, r4
d00842bc:	f000 f81c 	bl	d00842f8 <__sfp>
d00842c0:	60a0      	str	r0, [r4, #8]
d00842c2:	4620      	mov	r0, r4
d00842c4:	f000 f818 	bl	d00842f8 <__sfp>
d00842c8:	2200      	movs	r2, #0
d00842ca:	60e0      	str	r0, [r4, #12]
d00842cc:	2104      	movs	r1, #4
d00842ce:	6860      	ldr	r0, [r4, #4]
d00842d0:	f7ff ff82 	bl	d00841d8 <std>
d00842d4:	68a0      	ldr	r0, [r4, #8]
d00842d6:	2201      	movs	r2, #1
d00842d8:	2109      	movs	r1, #9
d00842da:	f7ff ff7d 	bl	d00841d8 <std>
d00842de:	68e0      	ldr	r0, [r4, #12]
d00842e0:	2202      	movs	r2, #2
d00842e2:	2112      	movs	r1, #18
d00842e4:	f7ff ff78 	bl	d00841d8 <std>
d00842e8:	2301      	movs	r3, #1
d00842ea:	61a3      	str	r3, [r4, #24]
d00842ec:	e7d2      	b.n	d0084294 <__sinit+0xc>
d00842ee:	bf00      	nop
d00842f0:	d0084a38 	.word	0xd0084a38
d00842f4:	d0084221 	.word	0xd0084221

d00842f8 <__sfp>:
d00842f8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00842fa:	4607      	mov	r7, r0
d00842fc:	f7ff ffac 	bl	d0084258 <__sfp_lock_acquire>
d0084300:	4b1e      	ldr	r3, [pc, #120]	; (d008437c <__sfp+0x84>)
d0084302:	681e      	ldr	r6, [r3, #0]
d0084304:	69b3      	ldr	r3, [r6, #24]
d0084306:	b913      	cbnz	r3, d008430e <__sfp+0x16>
d0084308:	4630      	mov	r0, r6
d008430a:	f7ff ffbd 	bl	d0084288 <__sinit>
d008430e:	3648      	adds	r6, #72	; 0x48
d0084310:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d0084314:	3b01      	subs	r3, #1
d0084316:	d503      	bpl.n	d0084320 <__sfp+0x28>
d0084318:	6833      	ldr	r3, [r6, #0]
d008431a:	b30b      	cbz	r3, d0084360 <__sfp+0x68>
d008431c:	6836      	ldr	r6, [r6, #0]
d008431e:	e7f7      	b.n	d0084310 <__sfp+0x18>
d0084320:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d0084324:	b9d5      	cbnz	r5, d008435c <__sfp+0x64>
d0084326:	4b16      	ldr	r3, [pc, #88]	; (d0084380 <__sfp+0x88>)
d0084328:	60e3      	str	r3, [r4, #12]
d008432a:	f104 0058 	add.w	r0, r4, #88	; 0x58
d008432e:	6665      	str	r5, [r4, #100]	; 0x64
d0084330:	f000 f847 	bl	d00843c2 <__retarget_lock_init_recursive>
d0084334:	f7ff ff96 	bl	d0084264 <__sfp_lock_release>
d0084338:	e9c4 5501 	strd	r5, r5, [r4, #4]
d008433c:	e9c4 5504 	strd	r5, r5, [r4, #16]
d0084340:	6025      	str	r5, [r4, #0]
d0084342:	61a5      	str	r5, [r4, #24]
d0084344:	2208      	movs	r2, #8
d0084346:	4629      	mov	r1, r5
d0084348:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d008434c:	f7ff fcea 	bl	d0083d24 <memset>
d0084350:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d0084354:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d0084358:	4620      	mov	r0, r4
d008435a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d008435c:	3468      	adds	r4, #104	; 0x68
d008435e:	e7d9      	b.n	d0084314 <__sfp+0x1c>
d0084360:	2104      	movs	r1, #4
d0084362:	4638      	mov	r0, r7
d0084364:	f7ff ff62 	bl	d008422c <__sfmoreglue>
d0084368:	4604      	mov	r4, r0
d008436a:	6030      	str	r0, [r6, #0]
d008436c:	2800      	cmp	r0, #0
d008436e:	d1d5      	bne.n	d008431c <__sfp+0x24>
d0084370:	f7ff ff78 	bl	d0084264 <__sfp_lock_release>
d0084374:	230c      	movs	r3, #12
d0084376:	603b      	str	r3, [r7, #0]
d0084378:	e7ee      	b.n	d0084358 <__sfp+0x60>
d008437a:	bf00      	nop
d008437c:	d0084a38 	.word	0xd0084a38
d0084380:	ffff0001 	.word	0xffff0001

d0084384 <_fwalk_reent>:
d0084384:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0084388:	4606      	mov	r6, r0
d008438a:	4688      	mov	r8, r1
d008438c:	f100 0448 	add.w	r4, r0, #72	; 0x48
d0084390:	2700      	movs	r7, #0
d0084392:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d0084396:	f1b9 0901 	subs.w	r9, r9, #1
d008439a:	d505      	bpl.n	d00843a8 <_fwalk_reent+0x24>
d008439c:	6824      	ldr	r4, [r4, #0]
d008439e:	2c00      	cmp	r4, #0
d00843a0:	d1f7      	bne.n	d0084392 <_fwalk_reent+0xe>
d00843a2:	4638      	mov	r0, r7
d00843a4:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d00843a8:	89ab      	ldrh	r3, [r5, #12]
d00843aa:	2b01      	cmp	r3, #1
d00843ac:	d907      	bls.n	d00843be <_fwalk_reent+0x3a>
d00843ae:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d00843b2:	3301      	adds	r3, #1
d00843b4:	d003      	beq.n	d00843be <_fwalk_reent+0x3a>
d00843b6:	4629      	mov	r1, r5
d00843b8:	4630      	mov	r0, r6
d00843ba:	47c0      	blx	r8
d00843bc:	4307      	orrs	r7, r0
d00843be:	3568      	adds	r5, #104	; 0x68
d00843c0:	e7e9      	b.n	d0084396 <_fwalk_reent+0x12>

d00843c2 <__retarget_lock_init_recursive>:
d00843c2:	4770      	bx	lr

d00843c4 <__retarget_lock_acquire_recursive>:
d00843c4:	4770      	bx	lr

d00843c6 <__retarget_lock_release_recursive>:
d00843c6:	4770      	bx	lr

d00843c8 <__swhatbuf_r>:
d00843c8:	b570      	push	{r4, r5, r6, lr}
d00843ca:	460e      	mov	r6, r1
d00843cc:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00843d0:	2900      	cmp	r1, #0
d00843d2:	b096      	sub	sp, #88	; 0x58
d00843d4:	4614      	mov	r4, r2
d00843d6:	461d      	mov	r5, r3
d00843d8:	da07      	bge.n	d00843ea <__swhatbuf_r+0x22>
d00843da:	2300      	movs	r3, #0
d00843dc:	602b      	str	r3, [r5, #0]
d00843de:	89b3      	ldrh	r3, [r6, #12]
d00843e0:	061a      	lsls	r2, r3, #24
d00843e2:	d410      	bmi.n	d0084406 <__swhatbuf_r+0x3e>
d00843e4:	f44f 6380 	mov.w	r3, #1024	; 0x400
d00843e8:	e00e      	b.n	d0084408 <__swhatbuf_r+0x40>
d00843ea:	466a      	mov	r2, sp
d00843ec:	f000 f870 	bl	d00844d0 <_fstat_r>
d00843f0:	2800      	cmp	r0, #0
d00843f2:	dbf2      	blt.n	d00843da <__swhatbuf_r+0x12>
d00843f4:	9a01      	ldr	r2, [sp, #4]
d00843f6:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d00843fa:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d00843fe:	425a      	negs	r2, r3
d0084400:	415a      	adcs	r2, r3
d0084402:	602a      	str	r2, [r5, #0]
d0084404:	e7ee      	b.n	d00843e4 <__swhatbuf_r+0x1c>
d0084406:	2340      	movs	r3, #64	; 0x40
d0084408:	2000      	movs	r0, #0
d008440a:	6023      	str	r3, [r4, #0]
d008440c:	b016      	add	sp, #88	; 0x58
d008440e:	bd70      	pop	{r4, r5, r6, pc}

d0084410 <__malloc_lock>:
d0084410:	4801      	ldr	r0, [pc, #4]	; (d0084418 <__malloc_lock+0x8>)
d0084412:	f7ff bfd7 	b.w	d00843c4 <__retarget_lock_acquire_recursive>
d0084416:	bf00      	nop
d0084418:	d00b4d50 	.word	0xd00b4d50

d008441c <__malloc_unlock>:
d008441c:	4801      	ldr	r0, [pc, #4]	; (d0084424 <__malloc_unlock+0x8>)
d008441e:	f7ff bfd2 	b.w	d00843c6 <__retarget_lock_release_recursive>
d0084422:	bf00      	nop
d0084424:	d00b4d50 	.word	0xd00b4d50

d0084428 <__sread>:
d0084428:	b510      	push	{r4, lr}
d008442a:	460c      	mov	r4, r1
d008442c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0084430:	f000 f872 	bl	d0084518 <_read_r>
d0084434:	2800      	cmp	r0, #0
d0084436:	bfab      	itete	ge
d0084438:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d008443a:	89a3      	ldrhlt	r3, [r4, #12]
d008443c:	181b      	addge	r3, r3, r0
d008443e:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d0084442:	bfac      	ite	ge
d0084444:	6563      	strge	r3, [r4, #84]	; 0x54
d0084446:	81a3      	strhlt	r3, [r4, #12]
d0084448:	bd10      	pop	{r4, pc}

d008444a <__swrite>:
d008444a:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008444e:	461f      	mov	r7, r3
d0084450:	898b      	ldrh	r3, [r1, #12]
d0084452:	05db      	lsls	r3, r3, #23
d0084454:	4605      	mov	r5, r0
d0084456:	460c      	mov	r4, r1
d0084458:	4616      	mov	r6, r2
d008445a:	d505      	bpl.n	d0084468 <__swrite+0x1e>
d008445c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0084460:	2302      	movs	r3, #2
d0084462:	2200      	movs	r2, #0
d0084464:	f000 f846 	bl	d00844f4 <_lseek_r>
d0084468:	89a3      	ldrh	r3, [r4, #12]
d008446a:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d008446e:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d0084472:	81a3      	strh	r3, [r4, #12]
d0084474:	4632      	mov	r2, r6
d0084476:	463b      	mov	r3, r7
d0084478:	4628      	mov	r0, r5
d008447a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d008447e:	f7fb bde9 	b.w	d0080054 <_write_r>

d0084482 <__sseek>:
d0084482:	b510      	push	{r4, lr}
d0084484:	460c      	mov	r4, r1
d0084486:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d008448a:	f000 f833 	bl	d00844f4 <_lseek_r>
d008448e:	1c43      	adds	r3, r0, #1
d0084490:	89a3      	ldrh	r3, [r4, #12]
d0084492:	bf15      	itete	ne
d0084494:	6560      	strne	r0, [r4, #84]	; 0x54
d0084496:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d008449a:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d008449e:	81a3      	strheq	r3, [r4, #12]
d00844a0:	bf18      	it	ne
d00844a2:	81a3      	strhne	r3, [r4, #12]
d00844a4:	bd10      	pop	{r4, pc}

d00844a6 <__sclose>:
d00844a6:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00844aa:	f000 b801 	b.w	d00844b0 <_close_r>
	...

d00844b0 <_close_r>:
d00844b0:	b538      	push	{r3, r4, r5, lr}
d00844b2:	4d06      	ldr	r5, [pc, #24]	; (d00844cc <_close_r+0x1c>)
d00844b4:	2300      	movs	r3, #0
d00844b6:	4604      	mov	r4, r0
d00844b8:	4608      	mov	r0, r1
d00844ba:	602b      	str	r3, [r5, #0]
d00844bc:	f7fb fe04 	bl	d00800c8 <_close>
d00844c0:	1c43      	adds	r3, r0, #1
d00844c2:	d102      	bne.n	d00844ca <_close_r+0x1a>
d00844c4:	682b      	ldr	r3, [r5, #0]
d00844c6:	b103      	cbz	r3, d00844ca <_close_r+0x1a>
d00844c8:	6023      	str	r3, [r4, #0]
d00844ca:	bd38      	pop	{r3, r4, r5, pc}
d00844cc:	d00b4d58 	.word	0xd00b4d58

d00844d0 <_fstat_r>:
d00844d0:	b538      	push	{r3, r4, r5, lr}
d00844d2:	4d07      	ldr	r5, [pc, #28]	; (d00844f0 <_fstat_r+0x20>)
d00844d4:	2300      	movs	r3, #0
d00844d6:	4604      	mov	r4, r0
d00844d8:	4608      	mov	r0, r1
d00844da:	4611      	mov	r1, r2
d00844dc:	602b      	str	r3, [r5, #0]
d00844de:	f7fb fdf7 	bl	d00800d0 <_fstat>
d00844e2:	1c43      	adds	r3, r0, #1
d00844e4:	d102      	bne.n	d00844ec <_fstat_r+0x1c>
d00844e6:	682b      	ldr	r3, [r5, #0]
d00844e8:	b103      	cbz	r3, d00844ec <_fstat_r+0x1c>
d00844ea:	6023      	str	r3, [r4, #0]
d00844ec:	bd38      	pop	{r3, r4, r5, pc}
d00844ee:	bf00      	nop
d00844f0:	d00b4d58 	.word	0xd00b4d58

d00844f4 <_lseek_r>:
d00844f4:	b538      	push	{r3, r4, r5, lr}
d00844f6:	4d07      	ldr	r5, [pc, #28]	; (d0084514 <_lseek_r+0x20>)
d00844f8:	4604      	mov	r4, r0
d00844fa:	4608      	mov	r0, r1
d00844fc:	4611      	mov	r1, r2
d00844fe:	2200      	movs	r2, #0
d0084500:	602a      	str	r2, [r5, #0]
d0084502:	461a      	mov	r2, r3
d0084504:	f7fb fdea 	bl	d00800dc <_lseek>
d0084508:	1c43      	adds	r3, r0, #1
d008450a:	d102      	bne.n	d0084512 <_lseek_r+0x1e>
d008450c:	682b      	ldr	r3, [r5, #0]
d008450e:	b103      	cbz	r3, d0084512 <_lseek_r+0x1e>
d0084510:	6023      	str	r3, [r4, #0]
d0084512:	bd38      	pop	{r3, r4, r5, pc}
d0084514:	d00b4d58 	.word	0xd00b4d58

d0084518 <_read_r>:
d0084518:	b538      	push	{r3, r4, r5, lr}
d008451a:	4d07      	ldr	r5, [pc, #28]	; (d0084538 <_read_r+0x20>)
d008451c:	4604      	mov	r4, r0
d008451e:	4608      	mov	r0, r1
d0084520:	4611      	mov	r1, r2
d0084522:	2200      	movs	r2, #0
d0084524:	602a      	str	r2, [r5, #0]
d0084526:	461a      	mov	r2, r3
d0084528:	f7fb fdc4 	bl	d00800b4 <_read>
d008452c:	1c43      	adds	r3, r0, #1
d008452e:	d102      	bne.n	d0084536 <_read_r+0x1e>
d0084530:	682b      	ldr	r3, [r5, #0]
d0084532:	b103      	cbz	r3, d0084536 <_read_r+0x1e>
d0084534:	6023      	str	r3, [r4, #0]
d0084536:	bd38      	pop	{r3, r4, r5, pc}
d0084538:	d00b4d58 	.word	0xd00b4d58
d008453c:	00004845 	.word	0x00004845
d0084540:	00005949 	.word	0x00005949
d0084544:	00004141 	.word	0x00004141
d0084548:	00656874 	.word	0x00656874
d008454c:	00004844 	.word	0x00004844
d0084550:	00004841 	.word	0x00004841
d0084554:	73696874 	.word	0x73696874
d0084558:	00000000 	.word	0x00000000
d008455c:	00004849 	.word	0x00004849
d0084560:	00000053 	.word	0x00000053
d0084564:	74616874 	.word	0x74616874
d0084568:	00000000 	.word	0x00000000
d008456c:	00004541 	.word	0x00004541
d0084570:	00000054 	.word	0x00000054
d0084574:	72656874 	.word	0x72656874
d0084578:	00000065 	.word	0x00000065
d008457c:	69656874 	.word	0x69656874
d0084580:	00000072 	.word	0x00000072
d0084584:	00000052 	.word	0x00000052
d0084588:	00756f79 	.word	0x00756f79
d008458c:	00000059 	.word	0x00000059
d0084590:	00005755 	.word	0x00005755
d0084594:	72756f79 	.word	0x72756f79
d0084598:	00000000 	.word	0x00000000
d008459c:	00005245 	.word	0x00005245
d00845a0:	00006f74 	.word	0x00006f74
d00845a4:	006f6f74 	.word	0x006f6f74
d00845a8:	006f7774 	.word	0x006f7774
d00845ac:	0000666f 	.word	0x0000666f
d00845b0:	00000056 	.word	0x00000056
d00845b4:	00007369 	.word	0x00007369
d00845b8:	0000005a 	.word	0x0000005a
d00845bc:	00657261 	.word	0x00657261
d00845c0:	00646e61 	.word	0x00646e61
d00845c4:	0000004e 	.word	0x0000004e
d00845c8:	00000044 	.word	0x00000044
d00845cc:	6c6c6568 	.word	0x6c6c6568
d00845d0:	0000006f 	.word	0x0000006f
d00845d4:	00000048 	.word	0x00000048
d00845d8:	0000004c 	.word	0x0000004c
d00845dc:	00004f41 	.word	0x00004f41
d00845e0:	67696d61 	.word	0x67696d61
d00845e4:	00000061 	.word	0x00000061
d00845e8:	0000004d 	.word	0x0000004d
d00845ec:	00000047 	.word	0x00000047
d00845f0:	7272616e 	.word	0x7272616e
d00845f4:	726f7461 	.word	0x726f7461
d00845f8:	00000000 	.word	0x00000000
d00845fc:	6f737065 	.word	0x6f737065
d0084600:	0000006e 	.word	0x0000006e
d0084604:	00000050 	.word	0x00000050
d0084608:	70657473 	.word	0x70657473
d008460c:	006e6568 	.word	0x006e6568
d0084610:	76657473 	.word	0x76657473
d0084614:	00000065 	.word	0x00000065
d0084618:	6b776168 	.word	0x6b776168
d008461c:	00676e69 	.word	0x00676e69
d0084620:	6b776168 	.word	0x6b776168
d0084624:	00736e69 	.word	0x00736e69
d0084628:	0000004b 	.word	0x0000004b
d008462c:	0000474e 	.word	0x0000474e
d0084630:	00686374 	.word	0x00686374
d0084634:	00004843 	.word	0x00004843
d0084638:	00006863 	.word	0x00006863
d008463c:	00006873 	.word	0x00006873
d0084640:	00004853 	.word	0x00004853
d0084644:	00006874 	.word	0x00006874
d0084648:	00004854 	.word	0x00004854
d008464c:	00006870 	.word	0x00006870
d0084650:	00000046 	.word	0x00000046
d0084654:	00006877 	.word	0x00006877
d0084658:	00000057 	.word	0x00000057
d008465c:	00007277 	.word	0x00007277
d0084660:	0000676e 	.word	0x0000676e
d0084664:	00006b63 	.word	0x00006b63
d0084668:	00007571 	.word	0x00007571
d008466c:	00006961 	.word	0x00006961
d0084670:	00007961 	.word	0x00007961
d0084674:	00007561 	.word	0x00007561
d0084678:	00007761 	.word	0x00007761
d008467c:	00006565 	.word	0x00006565
d0084680:	00006165 	.word	0x00006165
d0084684:	00007265 	.word	0x00007265
d0084688:	00007269 	.word	0x00007269
d008468c:	00006f6f 	.word	0x00006f6f
d0084690:	0000756f 	.word	0x0000756f
d0084694:	0000776f 	.word	0x0000776f
d0084698:	0000696f 	.word	0x0000696f
d008469c:	0000796f 	.word	0x0000796f
d00846a0:	0000726f 	.word	0x0000726f
d00846a4:	00007275 	.word	0x00007275
d00846a8:	0000005f 	.word	0x0000005f
d00846ac:	00006e6b 	.word	0x00006e6b
d00846b0:	00004855 	.word	0x00004855
d00846b4:	00000042 	.word	0x00000042
d00846b8:	0000004a 	.word	0x0000004a
d00846bc:	0000485a 	.word	0x0000485a

d00846c0 <g_specs>:
d00846c0:	d00846a8 00000000 00000000 00000000     .F..............
d00846d0:	00000046 d0084550 04a60280 50dc0956     F...PE......V..P
d00846e0:	00010023 00000078 d008456c 06b80294     #...x...lE......
d00846f0:	64e6096a 0001002d 00000082 d0084544     j..d-.......DE..
d0084700:	044202da 52e60988 00010023 0000008c     ..B....R#.......
d0084710:	d00845dc 0348023a 5cdc096a 00010023     .E..:.H.j..\#...
d0084720:	00000087 d008453c 07300212 69dc09b0     ....<E....0....i
d0084730:	0001002d 0000007d d008459c 054601ea     -...}....E....F.
d0084740:	64d2069a 00010041 00000087 d008455c     ...dA.......\E..
d0084750:	07c60186 69d209f6 00010030 0000006e     .......i0...n...
d0084760:	d0084540 08f2010e 6ecd0bc2 00010037     @E.........n7...
d0084770:	00000082 d00846b0 03fc01b8 50d708c0     .....F.........P
d0084780:	00010023 0000006e d0084590 0366012c     #...n....E..,.f.
d0084790:	50dc08c0 00010028 00000087 d00846b4     ...P(........F..
d00847a0:	044c010e 237d0866 00032d14 0000003e     ..L.f.}#.-..>...
d00847b0:	d0084634 076c0168 46320a8c 00026950     4F..h.l...2FPi..
d00847c0:	00000058 d00845c8 06a40140 2d780a28     X....E..@...(.x-
d00847d0:	00032819 0000003a d008454c 05aa0168     .(..:...LE..h...
d00847e0:	286e09c4 00014614 00000044 d0084650     ..n(.F..D...PF..
d00847f0:	0514012c 19000a28 00004e28 00000048     ,...(...(N..H...
d0084800:	d00845ec 0578012c 287d0960 00032d14     .E..,.x.`.}(.-..
d0084810:	00000046 d00845d4 05dc0208 26370a28     F....E......(.7&
d0084820:	00014619 00000037 d00846b8 06a40168     .F..7....F..h...
d0084830:	46500a8c 00034837 00000055 d0084628     ..PF7H..U...(F..
d0084840:	06a4012c 2d000af0 00025c37 00000046     ,......-7\..F...
d0084850:	d00845d8 09600190 50b40bb8 0001002a     .E....`....P*...
d0084860:	0000004e d00845e8 04b000fa 2ab90898     N....E.........*
d0084870:	00010016 00000052 d00845c4 06a400fa     ....R....E......
d0084880:	37b40a28 0001001c 0000004b d008462c     (..7....K...,F..
d0084890:	07d000fa 3ab40abe 0001001e 0000005a     .......:....Z...
d00848a0:	d0084604 04b0012c 23000a28 00025628     .F..,...(..#(V..
d00848b0:	0000003e d0084584 0514012c 64be0640     >....E..,...@..d
d00848c0:	0001004b 00000058 d0084560 0c800140     K...X...`E..@...
d00848d0:	2d001068 00005855 00000052 d0084640     h..-UX..R...@F..
d00848e0:	08340140 41000bb8 00005c46 00000058     @.4....AF\..X...
d00848f0:	d0084570 06a40140 2d000b54 00025a3a     pE..@...T..-:Z..
d0084900:	0000003a d0084648 05aa0168 1e000a28     :...HF..h...(...
d0084910:	00004832 0000004a d00845b0 0514012c     2H..J....E..,...
d0084920:	1e640a28 00014b19 00000048 d0084658     (.d..K..H...XF..
d0084930:	02f8012c 4bc30898 00010023 00000052     ,......K#...R...
d0084940:	d008458c 08980118 69a50bb8 00010032     .E.........i2...
d0084950:	00000046 d00845b8 0bb80140 2d5a1004     F....E..@.....Z-
d0084960:	0001464b 00000052 d00846bc 08340140     KF..R....F..@.4.
d0084970:	41500bb8 00014446 00000056 6c6c6548     ..PAFD..V...Hell
d0084980:	49202e6f 206d6120 70732061 68636565     o. I am a speech
d0084990:	6e797320 73656874 72657a69 726f6620      synthesizer for
d00849a0:	64695320 2e786f62 206f4e20 706d6173      Sidbox. No samp
d00849b0:	2e73656c 73754a20 68702074 6d656e6f     les. Just phonem
d00849c0:	202c7365 6d726f66 73746e61 6e61202c     es, formants, an
d00849d0:	75712064 69747365 62616e6f 6520656c     d questionable e
d00849e0:	74686769 20736569 72616863 00002e6d     ighties charm...
d00849f0:	45455053 53204843 48544e59 00000000     SPEECH SYNTH....
d0084a00:	6d726f46 20746e61 65657073 202c6863     Formant speech, 
d0084a10:	656e6567 65746172 696c2064 002e6576     generated live..
d0084a20:	73657250 49462073 74204552 6572206f     Press FIRE to re
d0084a30:	79616c70 0000002e                       play....

d0084a38 <_global_impure_ptr>:
d0084a38:	d0084ab4                                .J..

d0084a3c <__sf_fake_stderr>:
	...

d0084a5c <__sf_fake_stdin>:
	...

d0084a7c <__sf_fake_stdout>:
	...

Disassembly of section .init:

d0084a9c <_init>:
d0084a9c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0084a9e:	bf00      	nop

Disassembly of section .fini:

d0084aa0 <_fini>:
d0084aa0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0084aa2:	bf00      	nop
