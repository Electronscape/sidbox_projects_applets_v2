#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "main.h"
#include "apis.h"
#include "speech_synth.h"


#define APP_TITLE       "SPEECH SYNTH"
#define SPEECH_CHANNEL  0u

static const char *say_text =
    "Hello. This is the SIDBOX speech synth. "
    "It turns English into phonemes, and speaks with a formant voice.";

static void draw_screen(uint32_t sample_count)
{
    char line[80];

    crt_enable();
    crt_setborder(API_CRT_COLOUR_BLUE);
    crt_clear(API_CRT_COLOUR_BLACK);
    crt_text(12, 18, APP_TITLE, API_CRT_COLOUR_BCYAN);
    crt_text(12, 42, "HARMONIC FRAME VOICE", API_CRT_COLOUR_WHITE);
    crt_text(12, 66, say_text, API_CRT_COLOUR_BYELLOW);
    snprintf(line, sizeof(line), "%lu samples at %u hz",
             (unsigned long)sample_count,
             (unsigned int)SPEECH_SYNTH_SAMPLE_RATE);
    crt_text(12, 104, line, API_CRT_COLOUR_BGREEN);
    crt_text(12, 128, "FIRE: replay", API_CRT_COLOUR_BWHITE);
    crt_flush();
}

static void play_speech(uint32_t sample_count)
{
    sound_stop(SPEECH_CHANNEL);
    sound_assign(SPEECH_CHANNEL, speech_synth_samples(), sample_count, SAMP_S8);
    sound_setfrequency(SPEECH_CHANNEL, SPEECH_SYNTH_SAMPLE_RATE);
    sound_setvolume(SPEECH_CHANNEL, 255);
    sound_setpanning(SPEECH_CHANNEL, 0);
    sound_enableloop(SPEECH_CHANNEL, 0);
    sound_play(SPEECH_CHANNEL);
}


int main(int argc, char *argv[])
{
    uint32_t sample_count;
    uint8_t old_joy = 0;
    
    
    configure_runmode(GAMEMODE_PROFILE_1);
    
    initMalloc();
    
    set_audio_dma(64);
    set_music_dma = 1;

    if (argc > 1) {
        say_text = argv[1];
    }

    sample_count = speech_synth_render(say_text);
    draw_screen(sample_count);
    play_speech(sample_count);

    //for (;;) 
    {
        uint8_t joy = getjoyport();

        music_update();
        sysevents();
        crt_waitframe();

        if ((joy & BTN_FIRE) && !(old_joy & BTN_FIRE)) {
            play_speech(sample_count);
        }

        old_joy = joy;
    }


    HWKERNAL->exitgamemode();
    return 0;
}
