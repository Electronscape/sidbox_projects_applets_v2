#include "speech_synth.h"

#include <stdint.h>
#include <string.h>

#define MAX_PHONES 768u
#define TRACE_CAP 2048u

#define FLG_VOICED 0x01u
#define FLG_FRIC   0x02u
#define FLG_STOP   0x04u
#define FLG_NASAL  0x08u
#define FLG_LIQUID 0x10u

typedef enum {
    PH_PAUSE = 0,
    PH_AH,
    PH_AE,
    PH_AA,
    PH_AO,
    PH_EH,
    PH_ER,
    PH_IH,
    PH_IY,
    PH_UH,
    PH_UW,
    PH_EY,
    PH_AY,
    PH_OW,
    PH_AW,
    PH_OY,
    PH_B,
    PH_CH,
    PH_D,
    PH_DH,
    PH_F,
    PH_G,
    PH_H,
    PH_J,
    PH_K,
    PH_L,
    PH_M,
    PH_N,
    PH_NG,
    PH_P,
    PH_R,
    PH_S,
    PH_SH,
    PH_T,
    PH_TH,
    PH_V,
    PH_W,
    PH_Y,
    PH_Z,
    PH_ZH,
    PH_COUNT
} PhoneCode;

typedef struct {
    uint8_t code;
    uint8_t stress;
    uint16_t ms;
} PhoneToken;

typedef struct {
    const char *name;
    uint16_t f1;
    uint16_t f2;
    uint16_t f3;
    uint8_t a1;
    uint8_t a2;
    uint8_t a3;
    uint8_t noise;
    uint8_t flags;
    uint16_t ms;
} PhoneSpec;

typedef struct {
    uint16_t freq;
    uint16_t width;
    uint8_t height;
} PeakSpec;

typedef struct {
    float low;
    float band;
} NoiseBandState;

#define MAX_HARMONICS 96u
#define N_PEAKS_LOCAL 6u

typedef struct {
    uint16_t phase;
    uint32_t noise;
    int32_t harm_amp[MAX_HARMONICS + 1u];
    int32_t harm_inc[MAX_HARMONICS + 1u];
    uint8_t max_harmonic;
    uint8_t cycle_pos;
    uint8_t agc;
    int16_t last_noise;
    NoiseBandState noise_band1;
    NoiseBandState noise_band2;
    NoiseBandState noise_band3;
} WavegenState;

static uint8_t speech_pcm[SPEECH_SYNTH_MAX_SAMPLES] __attribute__((aligned(32)));
static uint32_t speech_pcm_count;
static char phoneme_trace[TRACE_CAP];
static uint16_t phoneme_trace_len;
static PhoneToken phone_tokens[MAX_PHONES];
static WavegenState wavegen_state;

static const PhoneSpec phone_specs[PH_COUNT] = {
    {"_",  0,    0,    0,   0,   0,   0,   0, 0,                                45},
    {"AH", 720,  1240, 2550, 112, 78,  38,  5, FLG_VOICED,                     120},
    {"AE", 690,  1720, 2500, 112, 92,  40,  3, FLG_VOICED,                     130},
    {"AA", 760,  1120, 2450, 116, 66,  36,  3, FLG_VOICED,                     135},
    {"AO", 560,  930,  2440, 112, 62,  34,  3, FLG_VOICED,                     135},
    {"EH", 560,  1840, 2480, 106, 98,  42,  3, FLG_VOICED,                     120},
    {"ER", 470,  1320, 1710, 108, 76,  78,  2, FLG_VOICED | FLG_LIQUID,        145},
    {"IH", 390,  1990, 2600, 98,  108, 48,  2, FLG_VOICED,                     105},
    {"IY", 300,  2250, 2920, 90,  118, 56,  1, FLG_VOICED,                     125},
    {"UH", 460,  1120, 2380, 96,  66,  34,  2, FLG_VOICED,                     105},
    {"UW", 330,  900,  2240, 88,  64,  36,  1, FLG_VOICED,                     130},
    {"EY", 440,  2050, 2660, 98,  110, 46,  1, FLG_VOICED,                     80},
    {"AY", 650,  1500, 2550, 112, 84,  42,  2, FLG_VOICED,                     85},
    {"OW", 500,  950,  2400, 104, 70,  38,  1, FLG_VOICED,                     90},
    {"AW", 720,  1240, 2460, 112, 74,  38,  2, FLG_VOICED,                     90},
    {"OY", 560,  1040, 2420, 106, 74,  38,  2, FLG_VOICED,                     90},
    {"B",  260,  720,  2200, 70,  30,  18,  8, FLG_VOICED | FLG_STOP,          62},
    {"CH", 430,  1880, 2860, 40,  64,  84,  92, FLG_FRIC | FLG_STOP,           86},
    {"D",  310,  1620, 2600, 62,  46,  26,  8, FLG_VOICED | FLG_STOP,          58},
    {"DH", 340,  1420, 2540, 50,  38,  25,  42, FLG_VOICED | FLG_FRIC,         72},
    {"F",  300,  1220, 3300, 18,  24,  92,  110, FLG_FRIC,                    86},
    {"G",  300,  1120, 2450, 62,  38,  22,  8, FLG_VOICED | FLG_STOP,          64},
    {"HH", 520,  1500, 2700, 42,  32,  30,  46, FLG_FRIC,                     65},
    {"JH", 430,  1820, 2750, 48,  64,  70,  58, FLG_VOICED | FLG_FRIC | FLG_STOP, 86},
    {"K",  330,  1540, 2700, 26,  44,  78,  118, FLG_STOP,                    76},
    {"L",  360,  1080, 2600, 92,  56,  30,  1, FLG_VOICED | FLG_LIQUID,       82},
    {"M",  250,  980,  2100, 104, 32,  16,  1, FLG_VOICED | FLG_NASAL,        82},
    {"N",  280,  1400, 2500, 96,  44,  22,  1, FLG_VOICED | FLG_NASAL,        76},
    {"NG", 300,  1120, 2380, 94,  38,  20,  1, FLG_VOICED | FLG_NASAL,        92},
    {"P",  260,  900,  2400, 18,  24,  60,  112, FLG_STOP,                    72},
    {"R",  360,  1200, 1680, 84,  62,  82,  1, FLG_VOICED | FLG_LIQUID,       90},
    {"S",  330,  1700, 4100, 8,   18,  124, 125, FLG_FRIC,                    92},
    {"SH", 360,  1500, 2950, 12,  38,  116, 118, FLG_FRIC,                    100},
    {"T",  330,  1700, 3300, 18,  36,  92,  130, FLG_STOP,                    64},
    {"TH", 340,  1320, 3100, 18,  30,  98,  92, FLG_FRIC,                     78},
    {"V",  300,  1220, 3300, 30,  28,  82,  72, FLG_VOICED | FLG_FRIC,        80},
    {"W",  300,  760,  2220, 82,  54,  28,  1, FLG_VOICED | FLG_LIQUID,       72},
    {"Y",  280,  2100, 2920, 70,  108, 46,  1, FLG_VOICED | FLG_LIQUID,       70},
    {"Z",  330,  1700, 4100, 24,  26,  112, 80, FLG_VOICED | FLG_FRIC,        86},
    {"ZH", 360,  1520, 3000, 24,  42,  108, 75, FLG_VOICED | FLG_FRIC,        90}
};

static uint8_t is_alpha_char(char c)
{
    return ((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z'));
}

static uint8_t is_vowel_char(char c)
{
    return (c == 'a') || (c == 'e') || (c == 'i') || (c == 'o') || (c == 'u') || (c == 'y');
}

static char lower_char(char c)
{
    if ((c >= 'A') && (c <= 'Z')) {
        return (char)(c + ('a' - 'A'));
    }
    return c;
}

static uint8_t starts_with(const char *s, const char *prefix)
{
    while (*prefix) {
        if (*s++ != *prefix++) {
            return 0;
        }
    }
    return 1;
}

static void trace_text(const char *s)
{
    while (*s && (phoneme_trace_len + 1u < TRACE_CAP)) {
        phoneme_trace[phoneme_trace_len++] = *s++;
    }
    phoneme_trace[phoneme_trace_len] = '\0';
}

static void trace_phone(uint8_t code, uint8_t stress)
{
    const char *name = phone_specs[code].name;
    if (phoneme_trace_len != 0u) {
        trace_text(" ");
    }
    trace_text(name);
    if (stress != 0u) {
        trace_text("'");
    }
}

static void emit_phone(PhoneToken *out, uint16_t *count, uint8_t code, uint16_t ms, uint8_t stress)
{
    if (*count >= MAX_PHONES) {
        return;
    }
    if (ms == 0u) {
        ms = phone_specs[code].ms;
    }
    out[*count].code = code;
    out[*count].ms = ms;
    out[*count].stress = stress;
    (*count)++;
    trace_phone(code, stress);
}

static void emit_pause(PhoneToken *out, uint16_t *count, uint16_t ms)
{
    if (*count >= MAX_PHONES) {
        return;
    }
    out[*count].code = PH_PAUSE;
    out[*count].ms = ms;
    out[*count].stress = 0u;
    (*count)++;
    trace_phone(PH_PAUSE, 0u);
}

static void stress_last_vowel(PhoneToken *out, uint16_t from, uint16_t to)
{
    uint16_t i = to;
    while (i > from) {
        uint8_t code = out[i - 1u].code;
        if ((code >= PH_AH) && (code <= PH_OY)) {
            out[i - 1u].stress = 1u;
            return;
        }
        i--;
    }
}

static void emit_diphthong(PhoneToken *out, uint16_t *count, uint8_t first, uint8_t second, uint8_t stress)
{
    emit_phone(out, count, first, 72u, stress);
    emit_phone(out, count, second, 60u, 0u);
}

static uint8_t emit_dictionary_word(const char *word, PhoneToken *out, uint16_t *count)
{
    uint16_t start = *count;

    if (!strcmp(word, "a")) { emit_phone(out, count, PH_AH, 95u, 0u); return 1u; }
    if (!strcmp(word, "i")) { emit_phone(out, count, PH_AY, 140u, 1u); return 1u; }
    if (!strcmp(word, "am")) { emit_phone(out, count, PH_AE, 115u, 1u); emit_phone(out, count, PH_M, 70u, 0u); return 1u; }
    if (!strcmp(word, "an")) { emit_phone(out, count, PH_AE, 90u, 0u); emit_phone(out, count, PH_N, 64u, 0u); return 1u; }
    if (!strcmp(word, "and")) { emit_phone(out, count, PH_AE, 86u, 0u); emit_phone(out, count, PH_N, 50u, 0u); emit_phone(out, count, PH_D, 44u, 0u); return 1u; }
    if (!strcmp(word, "are")) { emit_phone(out, count, PH_AA, 120u, 1u); emit_phone(out, count, PH_R, 70u, 0u); return 1u; }
    if (!strcmp(word, "be")) { emit_phone(out, count, PH_B, 54u, 0u); emit_phone(out, count, PH_IY, 122u, 1u); return 1u; }
    if (!strcmp(word, "computer")) { emit_phone(out, count, PH_K, 62u, 0u); emit_phone(out, count, PH_AH, 74u, 0u); emit_phone(out, count, PH_M, 60u, 0u); emit_phone(out, count, PH_P, 58u, 0u); emit_phone(out, count, PH_Y, 46u, 0u); emit_phone(out, count, PH_UW, 95u, 1u); emit_phone(out, count, PH_T, 42u, 0u); emit_phone(out, count, PH_ER, 118u, 0u); return 1u; }
    if (!strcmp(word, "device")) { emit_phone(out, count, PH_D, 58u, 0u); emit_phone(out, count, PH_IH, 68u, 0u); emit_phone(out, count, PH_V, 64u, 0u); emit_diphthong(out, count, PH_AY, PH_IY, 1u); emit_phone(out, count, PH_S, 74u, 0u); return 1u; }
    if (!strcmp(word, "english")) { emit_phone(out, count, PH_IH, 95u, 1u); emit_phone(out, count, PH_NG, 70u, 0u); emit_phone(out, count, PH_G, 46u, 0u); emit_phone(out, count, PH_L, 48u, 0u); emit_phone(out, count, PH_IH, 75u, 0u); emit_phone(out, count, PH_SH, 78u, 0u); return 1u; }
    if (!strcmp(word, "epson")) { emit_phone(out, count, PH_EH, 115u, 1u); emit_phone(out, count, PH_P, 50u, 0u); emit_phone(out, count, PH_S, 65u, 0u); emit_phone(out, count, PH_AH, 80u, 0u); emit_phone(out, count, PH_N, 60u, 0u); return 1u; }
    if (!strcmp(word, "eight")) { emit_phone(out, count, PH_EY, 120u, 1u); emit_phone(out, count, PH_T, 48u, 0u); return 1u; }
    if (!strcmp(word, "espeak")) { emit_phone(out, count, PH_IY, 92u, 0u); emit_phone(out, count, PH_S, 72u, 0u); emit_phone(out, count, PH_P, 54u, 0u); emit_phone(out, count, PH_IY, 126u, 1u); emit_phone(out, count, PH_K, 56u, 0u); return 1u; }
    if (!strcmp(word, "five")) { emit_phone(out, count, PH_F, 60u, 0u); emit_diphthong(out, count, PH_AY, PH_IY, 1u); emit_phone(out, count, PH_V, 58u, 0u); return 1u; }
    if (!strcmp(word, "four")) { emit_phone(out, count, PH_F, 62u, 0u); emit_phone(out, count, PH_AO, 118u, 1u); emit_phone(out, count, PH_R, 60u, 0u); return 1u; }
    if (!strcmp(word, "from")) { emit_phone(out, count, PH_F, 58u, 0u); emit_phone(out, count, PH_R, 48u, 0u); emit_phone(out, count, PH_AH, 76u, 0u); emit_phone(out, count, PH_M, 54u, 0u); return 1u; }
    if (!strcmp(word, "hawking") || !strcmp(word, "hawkins")) { emit_phone(out, count, PH_H, 42u, 0u); emit_phone(out, count, PH_AO, 118u, 1u); emit_phone(out, count, PH_K, 54u, 0u); emit_phone(out, count, PH_IH, 74u, 0u); emit_phone(out, count, PH_NG, 72u, 0u); return 1u; }
    if (!strcmp(word, "hello")) { emit_phone(out, count, PH_H, 45u, 0u); emit_phone(out, count, PH_EH, 90u, 0u); emit_phone(out, count, PH_L, 55u, 0u); emit_phone(out, count, PH_OW, 135u, 1u); return 1u; }
    if (!strcmp(word, "is")) { emit_phone(out, count, PH_IH, 78u, 0u); emit_phone(out, count, PH_Z, 60u, 0u); return 1u; }
    if (!strcmp(word, "macintosh")) { emit_phone(out, count, PH_M, 56u, 0u); emit_phone(out, count, PH_AE, 105u, 1u); emit_phone(out, count, PH_K, 48u, 0u); emit_phone(out, count, PH_IH, 70u, 0u); emit_phone(out, count, PH_N, 50u, 0u); emit_phone(out, count, PH_T, 45u, 0u); emit_phone(out, count, PH_AA, 92u, 0u); emit_phone(out, count, PH_SH, 78u, 0u); return 1u; }
    if (!strcmp(word, "narrator")) { emit_phone(out, count, PH_N, 54u, 0u); emit_phone(out, count, PH_AE, 88u, 1u); emit_phone(out, count, PH_R, 54u, 0u); emit_phone(out, count, PH_EY, 78u, 0u); emit_phone(out, count, PH_T, 42u, 0u); emit_phone(out, count, PH_ER, 110u, 0u); return 1u; }
    if (!strcmp(word, "nine")) { emit_phone(out, count, PH_N, 58u, 0u); emit_diphthong(out, count, PH_AY, PH_IY, 1u); emit_phone(out, count, PH_N, 58u, 0u); return 1u; }
    if (!strcmp(word, "of")) { emit_phone(out, count, PH_AH, 64u, 0u); emit_phone(out, count, PH_V, 54u, 0u); return 1u; }
    if (!strcmp(word, "one")) { emit_phone(out, count, PH_W, 52u, 0u); emit_phone(out, count, PH_AH, 112u, 1u); emit_phone(out, count, PH_N, 56u, 0u); return 1u; }
    if (!strcmp(word, "phoneme") || !strcmp(word, "phonemes")) { emit_phone(out, count, PH_F, 62u, 0u); emit_phone(out, count, PH_OW, 108u, 1u); emit_phone(out, count, PH_N, 52u, 0u); emit_phone(out, count, PH_IY, 100u, 0u); emit_phone(out, count, PH_M, 58u, 0u); if (word[7] == 's') emit_phone(out, count, PH_Z, 54u, 0u); return 1u; }
    if (!strcmp(word, "quality")) { emit_phone(out, count, PH_K, 54u, 0u); emit_phone(out, count, PH_W, 42u, 0u); emit_phone(out, count, PH_AA, 105u, 1u); emit_phone(out, count, PH_L, 45u, 0u); emit_phone(out, count, PH_IH, 55u, 0u); emit_phone(out, count, PH_T, 40u, 0u); emit_phone(out, count, PH_IY, 75u, 0u); return 1u; }
    if (!strcmp(word, "sidbox")) { emit_phone(out, count, PH_S, 70u, 0u); emit_phone(out, count, PH_IH, 98u, 1u); emit_phone(out, count, PH_D, 45u, 0u); emit_phone(out, count, PH_B, 55u, 0u); emit_phone(out, count, PH_AA, 100u, 0u); emit_phone(out, count, PH_K, 50u, 0u); emit_phone(out, count, PH_S, 62u, 0u); return 1u; }
    if (!strcmp(word, "speak") || !strcmp(word, "speaks")) { emit_phone(out, count, PH_S, 58u, 0u); emit_phone(out, count, PH_P, 48u, 0u); emit_phone(out, count, PH_IY, 124u, 1u); emit_phone(out, count, PH_K, 50u, 0u); if (word[5] == 's') emit_phone(out, count, PH_S, 54u, 0u); return 1u; }
    if (!strcmp(word, "speech")) { emit_phone(out, count, PH_S, 62u, 0u); emit_phone(out, count, PH_P, 48u, 0u); emit_phone(out, count, PH_IY, 120u, 1u); emit_phone(out, count, PH_CH, 80u, 0u); return 1u; }
    if (!strcmp(word, "stephen") || !strcmp(word, "steven") || !strcmp(word, "steve")) { emit_phone(out, count, PH_S, 58u, 0u); emit_phone(out, count, PH_T, 42u, 0u); emit_phone(out, count, PH_IY, 118u, 1u); emit_phone(out, count, PH_V, 55u, 0u); if (strcmp(word, "steve")) { emit_phone(out, count, PH_AH, 65u, 0u); emit_phone(out, count, PH_N, 54u, 0u); } return 1u; }
    if (!strcmp(word, "seven")) { emit_phone(out, count, PH_S, 62u, 0u); emit_phone(out, count, PH_EH, 105u, 1u); emit_phone(out, count, PH_V, 52u, 0u); emit_phone(out, count, PH_AH, 66u, 0u); emit_phone(out, count, PH_N, 55u, 0u); return 1u; }
    if (!strcmp(word, "six")) { emit_phone(out, count, PH_S, 64u, 0u); emit_phone(out, count, PH_IH, 105u, 1u); emit_phone(out, count, PH_K, 42u, 0u); emit_phone(out, count, PH_S, 56u, 0u); return 1u; }
    if (!strcmp(word, "synth") || !strcmp(word, "synthesis")) { emit_phone(out, count, PH_S, 62u, 0u); emit_phone(out, count, PH_IH, 88u, 1u); emit_phone(out, count, PH_N, 42u, 0u); emit_phone(out, count, PH_TH, 74u, 0u); if (!strcmp(word, "synthesis")) { emit_phone(out, count, PH_AH, 60u, 0u); emit_phone(out, count, PH_S, 54u, 0u); emit_phone(out, count, PH_IH, 62u, 0u); emit_phone(out, count, PH_S, 58u, 0u); } return 1u; }
    if (!strcmp(word, "that")) { emit_phone(out, count, PH_DH, 62u, 0u); emit_phone(out, count, PH_AE, 105u, 1u); emit_phone(out, count, PH_T, 52u, 0u); return 1u; }
    if (!strcmp(word, "the")) { emit_phone(out, count, PH_DH, 54u, 0u); emit_phone(out, count, PH_AH, 78u, 0u); return 1u; }
    if (!strcmp(word, "three")) { emit_phone(out, count, PH_TH, 72u, 0u); emit_phone(out, count, PH_R, 50u, 0u); emit_phone(out, count, PH_IY, 126u, 1u); return 1u; }
    if (!strcmp(word, "this")) { emit_phone(out, count, PH_DH, 58u, 0u); emit_phone(out, count, PH_IH, 90u, 1u); emit_phone(out, count, PH_S, 58u, 0u); return 1u; }
    if (!strcmp(word, "to") || !strcmp(word, "too") || !strcmp(word, "two")) { emit_phone(out, count, PH_T, 48u, 0u); emit_phone(out, count, PH_UW, 116u, 1u); return 1u; }
    if (!strcmp(word, "voice")) { emit_phone(out, count, PH_V, 60u, 0u); emit_phone(out, count, PH_OY, 125u, 1u); emit_phone(out, count, PH_S, 64u, 0u); return 1u; }
    if (!strcmp(word, "was")) { emit_phone(out, count, PH_W, 48u, 0u); emit_phone(out, count, PH_AH, 82u, 0u); emit_phone(out, count, PH_Z, 58u, 0u); return 1u; }
    if (!strcmp(word, "you")) { emit_phone(out, count, PH_Y, 46u, 0u); emit_phone(out, count, PH_UW, 124u, 1u); return 1u; }
    if (!strcmp(word, "your")) { emit_phone(out, count, PH_Y, 44u, 0u); emit_phone(out, count, PH_ER, 122u, 1u); return 1u; }
    if (!strcmp(word, "zero")) { emit_phone(out, count, PH_Z, 58u, 0u); emit_phone(out, count, PH_IH, 70u, 0u); emit_phone(out, count, PH_R, 48u, 0u); emit_phone(out, count, PH_OW, 120u, 1u); return 1u; }

    *count = start;
    return 0u;
}

static void emit_vowel_rule(const char *word, uint16_t *i, uint16_t len, PhoneToken *out, uint16_t *count)
{
    char c = word[*i];
    char n = (*i + 1u < len) ? word[*i + 1u] : '\0';
    char nn = (*i + 2u < len) ? word[*i + 2u] : '\0';
    uint8_t magic_e = 0u;

    if ((len > 2u) && (word[len - 1u] == 'e') && (*i + 1u < len - 1u) && !is_vowel_char(n)) {
        magic_e = 1u;
    }

    if ((c == 'e') && ((n == 'e') || (n == 'a') || (n == 'i'))) {
        emit_phone(out, count, PH_IY, 0u, 0u);
        (*i) += 2u;
    } else if ((c == 'a') && ((n == 'i') || (n == 'y'))) {
        emit_phone(out, count, PH_EY, 0u, 0u);
        (*i) += 2u;
    } else if ((c == 'o') && (n == 'o')) {
        emit_phone(out, count, (nn == 'd') ? PH_UH : PH_UW, 0u, 0u);
        (*i) += 2u;
    } else if ((c == 'o') && ((n == 'u') || (n == 'w'))) {
        emit_diphthong(out, count, PH_AW, PH_UH, 0u);
        (*i) += 2u;
    } else if ((c == 'o') && ((n == 'i') || (n == 'y'))) {
        emit_diphthong(out, count, PH_OY, PH_IH, 0u);
        (*i) += 2u;
    } else if ((c == 'a') && ((n == 'u') || (n == 'w'))) {
        emit_phone(out, count, PH_AO, 0u, 0u);
        (*i) += 2u;
    } else if (((c == 'e') || (c == 'i') || (c == 'u')) && (n == 'r')) {
        emit_phone(out, count, PH_ER, 0u, 0u);
        (*i) += 2u;
    } else if ((c == 'o') && (n == 'r')) {
        emit_phone(out, count, PH_AO, 95u, 1u);
        emit_phone(out, count, PH_R, 62u, 0u);
        (*i) += 2u;
    } else if (magic_e) {
        if (c == 'a') emit_phone(out, count, PH_EY, 0u, 0u);
        else if (c == 'e') emit_phone(out, count, PH_IY, 0u, 0u);
        else if (c == 'i') emit_diphthong(out, count, PH_AY, PH_IY, 0u);
        else if (c == 'o') emit_phone(out, count, PH_OW, 0u, 0u);
        else emit_phone(out, count, PH_UW, 0u, 0u);
        (*i)++;
    } else {
        if (c == 'a') emit_phone(out, count, PH_AE, 0u, 0u);
        else if (c == 'e') emit_phone(out, count, PH_EH, 0u, 0u);
        else if (c == 'i') emit_phone(out, count, PH_IH, 0u, 0u);
        else if (c == 'o') emit_phone(out, count, PH_AA, 0u, 0u);
        else if (c == 'u') emit_phone(out, count, PH_AH, 0u, 0u);
        else emit_phone(out, count, PH_IY, 0u, 0u);
        (*i)++;
    }
}

static void emit_rule_word(const char *word, PhoneToken *out, uint16_t *count)
{
    uint16_t start = *count;
    uint16_t len = (uint16_t)strlen(word);
    uint16_t i = 0u;

    if (emit_dictionary_word(word, out, count)) {
        return;
    }

    while (i < len) {
        char c = word[i];
        char n = (i + 1u < len) ? word[i + 1u] : '\0';

        if ((c == 'e') && (i == len - 1u) && (len > 2u)) {
            i++;
        } else if (is_vowel_char(c)) {
            emit_vowel_rule(word, &i, len, out, count);
        } else if (starts_with(&word[i], "ch")) {
            emit_phone(out, count, PH_CH, 0u, 0u); i += 2u;
        } else if (starts_with(&word[i], "sh")) {
            emit_phone(out, count, PH_SH, 0u, 0u); i += 2u;
        } else if (starts_with(&word[i], "th")) {
            emit_phone(out, count, PH_TH, 0u, 0u); i += 2u;
        } else if (starts_with(&word[i], "ph")) {
            emit_phone(out, count, PH_F, 0u, 0u); i += 2u;
        } else if (starts_with(&word[i], "ng")) {
            emit_phone(out, count, PH_NG, 0u, 0u); i += 2u;
        } else if (starts_with(&word[i], "ck")) {
            emit_phone(out, count, PH_K, 0u, 0u); i += 2u;
        } else if (starts_with(&word[i], "qu")) {
            emit_phone(out, count, PH_K, 42u, 0u); emit_phone(out, count, PH_W, 44u, 0u); i += 2u;
        } else if (((i == 0u) && starts_with(&word[i], "kn")) || ((i == 0u) && starts_with(&word[i], "gn"))) {
            emit_phone(out, count, PH_N, 0u, 0u); i += 2u;
        } else if ((i == 0u) && starts_with(&word[i], "wr")) {
            emit_phone(out, count, PH_R, 0u, 0u); i += 2u;
        } else if ((c == n) && (c != 's') && (c != 'z') && !is_vowel_char(c)) {
            i++;
        } else {
            switch (c) {
            case 'b': emit_phone(out, count, PH_B, 0u, 0u); break;
            case 'c': emit_phone(out, count, ((n == 'e') || (n == 'i') || (n == 'y')) ? PH_S : PH_K, 0u, 0u); break;
            case 'd': emit_phone(out, count, PH_D, 0u, 0u); break;
            case 'f': emit_phone(out, count, PH_F, 0u, 0u); break;
            case 'g': emit_phone(out, count, ((n == 'e') || (n == 'i') || (n == 'y')) ? PH_J : PH_G, 0u, 0u); break;
            case 'h': emit_phone(out, count, PH_H, 0u, 0u); break;
            case 'j': emit_phone(out, count, PH_J, 0u, 0u); break;
            case 'k': emit_phone(out, count, PH_K, 0u, 0u); break;
            case 'l': emit_phone(out, count, PH_L, 0u, 0u); break;
            case 'm': emit_phone(out, count, PH_M, 0u, 0u); break;
            case 'n': emit_phone(out, count, PH_N, 0u, 0u); break;
            case 'p': emit_phone(out, count, PH_P, 0u, 0u); break;
            case 'r': emit_phone(out, count, PH_R, 0u, 0u); break;
            case 's': emit_phone(out, count, PH_S, 0u, 0u); break;
            case 't': emit_phone(out, count, PH_T, 0u, 0u); break;
            case 'v': emit_phone(out, count, PH_V, 0u, 0u); break;
            case 'w': emit_phone(out, count, PH_W, 0u, 0u); break;
            case 'x': emit_phone(out, count, PH_K, 45u, 0u); emit_phone(out, count, PH_S, 55u, 0u); break;
            case 'z': emit_phone(out, count, PH_Z, 0u, 0u); break;
            default: break;
            }
            i++;
        }
    }

    stress_last_vowel(out, start, *count);
}

static uint16_t phonemize_text(const char *text, PhoneToken *out)
{
    uint16_t count = 0u;
    uint16_t word_len = 0u;
    char word[48];

    phoneme_trace_len = 0u;
    phoneme_trace[0] = '\0';

    while (*text && (count < MAX_PHONES)) {
        char c = *text++;
        if (is_alpha_char(c)) {
            if (word_len + 1u < sizeof(word)) {
                word[word_len++] = lower_char(c);
            }
        } else {
            if (word_len != 0u) {
                word[word_len] = '\0';
                emit_rule_word(word, out, &count);
                word_len = 0u;
                emit_pause(out, &count, 14u);
            }
            if ((c == '.') || (c == '!') || (c == '?')) {
                emit_pause(out, &count, 185u);
            } else if ((c == ',') || (c == ';') || (c == ':')) {
                emit_pause(out, &count, 95u);
            } else if ((c >= '0') && (c <= '9')) {
                static const char *digits[] = {
                    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"
                };
                emit_rule_word(digits[(uint8_t)(c - '0')], out, &count);
                emit_pause(out, &count, 14u);
            }
        }
    }

    if ((word_len != 0u) && (count < MAX_PHONES)) {
        word[word_len] = '\0';
        emit_rule_word(word, out, &count);
    }

    return count;
}

static uint16_t interp_u16(uint16_t a, uint16_t b, uint32_t pos, uint32_t total)
{
    int32_t delta = (int32_t)b - (int32_t)a;
    if (total == 0u) {
        return b;
    }
    return (uint16_t)((int32_t)a + ((delta * (int32_t)pos) / (int32_t)total));
}

static uint8_t interp_u8(uint8_t a, uint8_t b, uint32_t pos, uint32_t total)
{
    int32_t delta = (int32_t)b - (int32_t)a;
    if (total == 0u) {
        return b;
    }
    return (uint8_t)((int32_t)a + ((delta * (int32_t)pos) / (int32_t)total));
}

static int32_t abs_i32(int32_t v)
{
    return (v < 0) ? -v : v;
}

static int16_t fast_sine16(uint16_t phase)
{
    uint16_t x = phase & 0x7fffu;
    int32_t y;

    if (x > 0x4000u) {
        x = 0x8000u - x;
    }

    y = ((int32_t)x * (int32_t)(32768u - x)) >> 13;
    if (phase & 0x8000u) {
        y = -y;
    }

    return (int16_t)y;
}

static uint16_t phase_inc_for(uint16_t hz)
{
    return (uint16_t)(((uint32_t)hz << 16) / SPEECH_SYNTH_SAMPLE_RATE);
}

static int16_t next_noise(WavegenState *s)
{
    s->noise = (s->noise * 1664525u) + 1013904223u;
    return (int16_t)(s->noise >> 16);
}

static int32_t soft_clip_i32(int32_t v)
{
    int32_t av = abs_i32(v);
    return (v * 32767) / (32767 + av);
}

static float clampf_local(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static uint8_t can_blend_from(PhoneToken prev, PhoneToken cur)
{
    uint8_t cur_flags = phone_specs[cur.code].flags;

    if ((prev.code == PH_PAUSE) || (cur.code == PH_PAUSE)) {
        return 0u;
    }
    if (cur_flags & FLG_STOP) {
        return 0u;
    }
    return 1u;
}

static uint8_t can_blend_to(PhoneToken cur, PhoneToken next)
{
    uint8_t next_flags = phone_specs[next.code].flags;

    if ((cur.code == PH_PAUSE) || (next.code == PH_PAUSE)) {
        return 0u;
    }
    if (next_flags & FLG_STOP) {
        return 0u;
    }
    return 1u;
}

static uint16_t envelope_q8(uint32_t i, uint32_t samples, uint8_t flags,
                            uint8_t blend_in, uint8_t blend_out)
{
    uint32_t attack = SPEECH_SYNTH_SAMPLE_RATE / 190u;
    uint32_t release = SPEECH_SYNTH_SAMPLE_RATE / 155u;
    uint32_t env = 256u;

    if (attack == 0u) {
        attack = 1u;
    }
    if (release == 0u) {
        release = 1u;
    }

    if (!blend_in && (i < attack)) {
        env = (i * 256u) / attack;
    } else if (!blend_out && (i + release > samples)) {
        env = ((samples - i) * 256u) / release;
    }

    if (flags & FLG_STOP) {
        if (i < (samples / 3u)) {
            env = (env * 20u) / 256u;
        } else if (i < ((samples / 3u) + (SPEECH_SYNTH_SAMPLE_RATE / 240u))) {
            env = (env * 340u) / 256u;
        }
    }

    if (env > 320u) {
        env = 320u;
    }
    return (uint16_t)env;
}

static uint16_t peak_width_for(uint8_t index, uint8_t flags)
{
    if (flags & FLG_FRIC) {
        static const uint16_t widths[N_PEAKS_LOCAL] = {260u, 420u, 700u, 960u, 1200u, 1500u};
        return widths[index];
    }
    if (flags & FLG_NASAL) {
        static const uint16_t widths[N_PEAKS_LOCAL] = {95u, 160u, 260u, 480u, 720u, 1000u};
        return widths[index];
    }
    if (flags & FLG_LIQUID) {
        static const uint16_t widths[N_PEAKS_LOCAL] = {125u, 210u, 340u, 560u, 820u, 1120u};
        return widths[index];
    }
    {
        static const uint16_t widths[N_PEAKS_LOCAL] = {110u, 180u, 300u, 520u, 760u, 1050u};
        return widths[index];
    }
}

static void make_peaks(PhoneToken cur, PhoneToken next, uint32_t pos, uint32_t total,
                       PeakSpec peaks[N_PEAKS_LOCAL], uint8_t *noise_amt)
{
    const PhoneSpec *p = &phone_specs[cur.code];
    const PhoneSpec *n = &phone_specs[next.code];
    uint16_t f1 = interp_u16(p->f1, n->f1 ? n->f1 : p->f1, pos, total);
    uint16_t f2 = interp_u16(p->f2, n->f2 ? n->f2 : p->f2, pos, total);
    uint16_t f3 = interp_u16(p->f3, n->f3 ? n->f3 : p->f3, pos, total);
    uint8_t a1 = interp_u8(p->a1, n->a1, pos, total);
    uint8_t a2 = interp_u8(p->a2, n->a2, pos, total);
    uint8_t a3 = interp_u8(p->a3, n->a3, pos, total);
    uint8_t noise = interp_u8(p->noise, n->noise, pos, total);
    uint8_t flags = p->flags;
    uint16_t f4 = (uint16_t)(f3 + 850u);
    uint16_t f5 = (flags & FLG_FRIC) ? (uint16_t)(f3 + 1450u) : 4700u;
    uint16_t f6 = (flags & FLG_FRIC) ? 6500u : 7200u;
    uint8_t hf = (flags & FLG_FRIC) ? noise : (uint8_t)(a3 / 4u);

    if (f4 > 6100u) {
        f4 = 6100u;
    }
    if (f5 > 7600u) {
        f5 = 7600u;
    }

    peaks[0].freq = f1;
    peaks[0].height = a1;
    peaks[0].width = peak_width_for(0u, flags);
    peaks[1].freq = f2;
    peaks[1].height = a2;
    peaks[1].width = peak_width_for(1u, flags);
    peaks[2].freq = f3;
    peaks[2].height = a3;
    peaks[2].width = peak_width_for(2u, flags);
    peaks[3].freq = f4;
    peaks[3].height = (uint8_t)((a3 / 2u) + (noise / 8u));
    peaks[3].width = peak_width_for(3u, flags);
    peaks[4].freq = f5;
    peaks[4].height = (uint8_t)((hf / 2u) + (a2 / 10u));
    peaks[4].width = peak_width_for(4u, flags);
    peaks[5].freq = f6;
    peaks[5].height = (uint8_t)((hf * 3u) / 4u);
    peaks[5].width = peak_width_for(5u, flags);

    if (flags & FLG_STOP) {
        *noise_amt = (noise < 76u) ? 76u : noise;
    } else {
        *noise_amt = noise;
    }
}

static void build_harmonic_spectrum(WavegenState *s, const PeakSpec peaks[N_PEAKS_LOCAL],
                                    uint16_t pitch, uint8_t voiced)
{
    uint8_t h;
    uint8_t old_max = s->max_harmonic;
    uint8_t max_h = (uint8_t)((SPEECH_SYNTH_SAMPLE_RATE / 2u) / pitch);

    if (max_h > MAX_HARMONICS) {
        max_h = MAX_HARMONICS;
    }
    if (!voiced) {
        max_h = old_max;
    }

    for (h = 1u; h <= MAX_HARMONICS; h++) {
        int32_t target = 0;

        if (voiced && (h <= max_h)) {
            uint8_t pk;
            uint16_t harmonic_freq = (uint16_t)((uint16_t)h * pitch);

            for (pk = 0u; pk < N_PEAKS_LOCAL; pk++) {
                int32_t dist = abs_i32((int32_t)harmonic_freq - (int32_t)peaks[pk].freq);
                if (dist < peaks[pk].width) {
                    int32_t shape = 256 - ((dist * 256) / (int32_t)peaks[pk].width);
                    shape = (shape * shape) >> 8;
                    target += ((int32_t)peaks[pk].height * shape) >> 4;
                }
            }

            if (harmonic_freq < 900u) {
                target += (900 - harmonic_freq) / 4;
            }
        }

        s->harm_inc[h] = (target - s->harm_amp[h]) / 64;
    }

    s->max_harmonic = max_h;
}

static int32_t render_harmonics(WavegenState *s, uint16_t pitch)
{
    uint16_t theta = s->phase;
    uint8_t h;
    int64_t total = 0;
    uint8_t h_switch = (pitch > 0u) ? (uint8_t)(890u / pitch) : 0u;

    for (h = 1u; h <= s->max_harmonic; h++) {
        int32_t part;

        s->harm_amp[h] += s->harm_inc[h];
        part = ((int32_t)fast_sine16(theta) * s->harm_amp[h]);
        if (h <= h_switch) {
            total += part;
        } else {
            total -= part;
        }
        theta = (uint16_t)(theta + s->phase);
    }

    return (int32_t)(total >> 15);
}

static int32_t noise_bandpass(NoiseBandState *state, int32_t input,
                              uint16_t hz, uint16_t bandwidth)
{
    float in = (float)input * (1.0f / 32768.0f);
    float f = (6.2831853f * (float)hz) * (1.0f / (float)SPEECH_SYNTH_SAMPLE_RATE);
    float damp = ((float)bandwidth * 1.52f) / ((float)hz + 1.0f);
    float high;

    f = clampf_local(f, 0.025f, 1.68f);
    damp = clampf_local(damp, 0.055f, 1.62f);

    state->low += f * state->band;
    high = in - state->low - (damp * state->band);
    state->band += f * high;

    state->low = clampf_local(state->low, -5.0f, 5.0f);
    state->band = clampf_local(state->band, -5.0f, 5.0f);

    return (int32_t)(state->band * 32767.0f);
}

static void noise_formants(uint8_t code, uint8_t flags,
                           uint16_t *f1, uint16_t *bw1, uint8_t *g1,
                           uint16_t *f2, uint16_t *bw2, uint8_t *g2,
                           uint16_t *f3, uint16_t *bw3, uint8_t *g3)
{
    *f1 = 2600u; *bw1 = 1200u; *g1 = 100u;
    *f2 = 5200u; *bw2 = 1800u; *g2 = 68u;
    *f3 = 7600u; *bw3 = 2300u; *g3 = 34u;

    switch (code) {
    case PH_S:
    case PH_Z:
        *f1 = 5200u; *bw1 = 760u;  *g1 = 142u;
        *f2 = 6900u; *bw2 = 1180u; *g2 = 82u;
        *f3 = 8400u; *bw3 = 1800u; *g3 = 38u;
        break;
    case PH_SH:
    case PH_ZH:
    case PH_CH:
    case PH_J:
        *f1 = 2550u; *bw1 = 650u;  *g1 = 132u;
        *f2 = 3650u; *bw2 = 920u;  *g2 = 94u;
        *f3 = 5200u; *bw3 = 1600u; *g3 = 38u;
        break;
    case PH_T:
    case PH_D:
        *f1 = 3900u; *bw1 = 700u;  *g1 = 116u;
        *f2 = 5900u; *bw2 = 1050u; *g2 = 118u;
        *f3 = 7900u; *bw3 = 1600u; *g3 = 64u;
        break;
    case PH_K:
    case PH_G:
        *f1 = 2300u; *bw1 = 600u;  *g1 = 98u;
        *f2 = 3550u; *bw2 = 880u;  *g2 = 128u;
        *f3 = 5200u; *bw3 = 1300u; *g3 = 58u;
        break;
    case PH_P:
    case PH_B:
        *f1 = 850u;  *bw1 = 520u;  *g1 = 92u;
        *f2 = 1850u; *bw2 = 840u;  *g2 = 86u;
        *f3 = 3600u; *bw3 = 1200u; *g3 = 48u;
        break;
    case PH_F:
    case PH_V:
    case PH_TH:
    case PH_DH:
        *f1 = 1700u; *bw1 = 1300u; *g1 = 72u;
        *f2 = 3900u; *bw2 = 1900u; *g2 = 70u;
        *f3 = 6700u; *bw3 = 2300u; *g3 = 44u;
        break;
    case PH_H:
        *f1 = 1150u; *bw1 = 900u;  *g1 = 64u;
        *f2 = 2550u; *bw2 = 1300u; *g2 = 52u;
        *f3 = 4700u; *bw3 = 1900u; *g3 = 28u;
        break;
    default:
        if (flags & FLG_STOP) {
            *f1 = 2400u; *bw1 = 900u; *g1 = 94u;
            *f2 = 4800u; *bw2 = 1400u; *g2 = 80u;
            *f3 = 7200u; *bw3 = 2100u; *g3 = 44u;
        }
        break;
    }
}

static int32_t render_noise(WavegenState *s, uint8_t code, uint8_t amount, uint8_t flags)
{
    int16_t raw = next_noise(s);
    int32_t high = (int32_t)raw - (int32_t)s->last_noise;
    int32_t body = raw >> 2;
    int32_t source;
    int32_t shaped;
    uint16_t f1;
    uint16_t f2;
    uint16_t f3;
    uint16_t bw1;
    uint16_t bw2;
    uint16_t bw3;
    uint8_t g1;
    uint8_t g2;
    uint8_t g3;

    s->last_noise = raw;

    if (flags & FLG_FRIC) {
        source = (high * 3 + body) / 4;
    } else if (flags & FLG_STOP) {
        source = (high * 2 + body) / 3;
    } else {
        source = body;
    }

    noise_formants(code, flags, &f1, &bw1, &g1, &f2, &bw2, &g2, &f3, &bw3, &g3);

    shaped = (noise_bandpass(&s->noise_band1, source, f1, bw1) * (int32_t)g1) / 128;
    shaped += (noise_bandpass(&s->noise_band2, source, f2, bw2) * (int32_t)g2) / 128;
    shaped += (noise_bandpass(&s->noise_band3, source, f3, bw3) * (int32_t)g3) / 128;

    if (flags & FLG_FRIC) {
        shaped += source / 7;
    } else if (flags & FLG_STOP) {
        shaped += source / 10;
    }

    shaped = soft_clip_i32(shaped);
    return (shaped * (int32_t)amount) / 1850;
}

static uint8_t stop_noise_floor(uint8_t code)
{
    switch (code) {
    case PH_T: return 160u;
    case PH_K: return 150u;
    case PH_P: return 132u;
    case PH_CH: return 142u;
    default: return 112u;
    }
}

static uint16_t stop_burst_env_q8(uint8_t code, uint32_t i, uint32_t samples)
{
    uint32_t release = samples / 3u;
    uint32_t click_len = SPEECH_SYNTH_SAMPLE_RATE / 330u;
    uint32_t aspir_len = SPEECH_SYNTH_SAMPLE_RATE / 58u;
    uint32_t d;
    uint32_t peak;

    if (i < release) {
        return 0u;
    }

    d = i - release;
    if (click_len == 0u) {
        click_len = 1u;
    }
    if (aspir_len <= click_len) {
        aspir_len = click_len + 1u;
    }
    if (d >= aspir_len) {
        return 0u;
    }

    switch (code) {
    case PH_T:
        peak = 760u;
        break;
    case PH_K:
        peak = 700u;
        break;
    case PH_P:
        peak = 600u;
        break;
    case PH_CH:
        peak = 520u;
        break;
    default:
        peak = 480u;
        break;
    }

    if (d < click_len) {
        return (uint16_t)(peak - ((d * (peak - 340u)) / click_len));
    }

    d -= click_len;
    return (uint16_t)(340u - ((d * 300u) / (aspir_len - click_len)));
}

static int32_t stop_click_sample(WavegenState *s, uint8_t code, uint8_t flags, uint16_t burst_q8)
{
    int16_t raw = next_noise(s);
    int32_t high = (int32_t)raw - (int32_t)s->last_noise;
    int32_t shaped;
    int32_t gain;
    uint16_t f1;
    uint16_t f2;
    uint16_t f3;
    uint16_t bw1;
    uint16_t bw2;
    uint16_t bw3;
    uint8_t g1;
    uint8_t g2;
    uint8_t g3;

    s->last_noise = raw;
    noise_formants(code, flags, &f1, &bw1, &g1, &f2, &bw2, &g2, &f3, &bw3, &g3);

    shaped = (noise_bandpass(&s->noise_band1, high, f1, bw1) * (int32_t)g1) / 128;
    shaped += (noise_bandpass(&s->noise_band2, high, f2, bw2) * (int32_t)g2) / 128;
    shaped += (noise_bandpass(&s->noise_band3, high, f3, bw3) * (int32_t)g3) / 128;
    shaped += high / 18;
    shaped = soft_clip_i32(shaped);

    switch (code) {
    case PH_T:
        gain = 105;
        break;
    case PH_K:
        gain = 96;
        break;
    case PH_P:
        gain = 78;
        break;
    default:
        gain = 86;
        break;
    }

    return (((shaped * gain) / 256) * (int32_t)burst_q8) / 256;
}

static uint16_t pitch_for_sample(uint32_t sample_index, uint8_t stress)
{
    static const int8_t flutter[32] = {
        0, 1, 1, 2, 1, 0, -1, -2,
        -2, -1, 0, 1, 2, 2, 1, 0,
        -1, -2, -3, -2, -1, 0, 1, 1,
        0, -1, -1, 0, 1, 2, 1, 0
    };
    uint16_t base = stress ? 151u : 126u;
    int16_t bend = flutter[(sample_index / (SPEECH_SYNTH_SAMPLE_RATE / 48u)) & 31u];
    return (uint16_t)((int16_t)base + bend);
}

static uint32_t render_phone(WavegenState *s, uint8_t *dst, uint32_t dst_pos,
                             PhoneToken prev, PhoneToken cur, PhoneToken next)
{
    const PhoneSpec *p = &phone_specs[cur.code];
    uint32_t samples = ((uint32_t)cur.ms * SPEECH_SYNTH_SAMPLE_RATE) / 1000u;
    uint32_t i;
    PeakSpec peaks[N_PEAKS_LOCAL];
    uint8_t voiced = (p->flags & FLG_VOICED) ? 1u : 0u;
    uint8_t noise_amt = p->noise;
    uint8_t blend_in = can_blend_from(prev, cur);
    uint8_t blend_out = can_blend_to(cur, next);

    if (cur.code == PH_PAUSE) {
        memset(s->harm_amp, 0, sizeof(s->harm_amp));
        memset(s->harm_inc, 0, sizeof(s->harm_inc));
        s->max_harmonic = 0u;
        for (i = 0u; (i < samples) && (dst_pos < SPEECH_SYNTH_MAX_SAMPLES); i++) {
            dst[dst_pos++] = 128u;
        }
        return dst_pos;
    }

    if (samples < 30u) {
        samples = 30u;
    }

    for (i = 0u; (i < samples) && (dst_pos < SPEECH_SYNTH_MAX_SAMPLES); i++) {
        uint16_t pitch = pitch_for_sample(i, cur.stress);
        uint16_t env = envelope_q8(i, samples, p->flags, blend_in, blend_out);
        uint16_t burst_env = 0u;
        int32_t voiced_sample = 0;
        int32_t noise_sample = 0;
        int32_t sample;
        int32_t out;

        if ((i & 63u) == 0u) {
            make_peaks(cur, next, i, samples, peaks, &noise_amt);
            build_harmonic_spectrum(s, peaks, pitch, voiced);
        }

        if (voiced) {
            uint16_t old_phase = s->phase;
            s->phase = (uint16_t)(s->phase + phase_inc_for(pitch));
            if (s->phase < old_phase) {
                s->cycle_pos++;
            }
            voiced_sample = render_harmonics(s, pitch);
            if ((s->cycle_pos & 7u) == 0u) {
                voiced_sample = (voiced_sample * 13) / 16;
            }
        }

        if (p->flags & FLG_STOP) {
            burst_env = stop_burst_env_q8(cur.code, i, samples);
            if (burst_env != 0u) {
                uint8_t active_noise = noise_amt;
                uint8_t floor = stop_noise_floor(cur.code);

                if (active_noise < floor) {
                    active_noise = floor;
                }
                noise_sample = render_noise(s, cur.code, active_noise, p->flags);
                noise_sample = (noise_sample * (int32_t)burst_env) / 256;
                noise_sample += stop_click_sample(s, cur.code, p->flags, burst_env);
            }
        } else if (noise_amt != 0u) {
            noise_sample = render_noise(s, cur.code, noise_amt, p->flags);
        }

        sample = ((voiced_sample * 16) / 5) + noise_sample;
        sample = (sample * env) / 256;
        if (p->flags & FLG_FRIC) {
            sample = (sample * 7) / 10;
        }

        sample = soft_clip_i32(sample);
        out = 128 + (sample >> 7);
        if (out < 0) out = 0;
        if (out > 255) out = 255;
        dst[dst_pos++] = (uint8_t)out;
    }

    return dst_pos;
}

uint32_t speech_synth_render(const char *text)
{
    uint16_t phone_count;
    uint16_t i;
    uint32_t pos = 0u;

    memset(&wavegen_state, 0, sizeof(wavegen_state));
    wavegen_state.noise = 0x1234abcdu;
    wavegen_state.agc = 255u;

    if ((text == 0) || (*text == '\0')) {
        text = "hello from sidbox speech synth";
    }

    phone_count = phonemize_text(text, phone_tokens);
    if (phone_count == 0u) {
        speech_pcm[0] = 128u;
        speech_pcm_count = 1u;
        return speech_pcm_count;
    }

    emit_pause(phone_tokens, &phone_count, 120u);

    for (i = 0u; i < phone_count; i++) {
        PhoneToken prev = (i > 0u) ? phone_tokens[i - 1u] : phone_tokens[i];
        PhoneToken next = (i + 1u < phone_count) ? phone_tokens[i + 1u] : phone_tokens[i];
        pos = render_phone(&wavegen_state, speech_pcm, pos, prev, phone_tokens[i], next);
        if (pos >= SPEECH_SYNTH_MAX_SAMPLES) {
            break;
        }
    }

    speech_pcm_count = pos;
    return speech_pcm_count;
}

uint8_t *speech_synth_samples(void)
{
    return speech_pcm;
}

uint32_t speech_synth_sample_count(void)
{
    return speech_pcm_count;
}

const char *speech_synth_phoneme_trace(void)
{
    return phoneme_trace;
}
