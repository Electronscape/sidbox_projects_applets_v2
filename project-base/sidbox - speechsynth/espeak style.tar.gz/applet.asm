
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0080010 <applet_entry>:
d0080010:	b570      	push	{r4, r5, r6, lr}
d0080012:	4e09      	ldr	r6, [pc, #36]	; (d0080038 <applet_entry+0x28>)
d0080014:	460d      	mov	r5, r1
d0080016:	4604      	mov	r4, r0
d0080018:	2100      	movs	r1, #0
d008001a:	6833      	ldr	r3, [r6, #0]
d008001c:	6898      	ldr	r0, [r3, #8]
d008001e:	f004 fd9d 	bl	d0084b5c <setbuf>
d0080022:	6833      	ldr	r3, [r6, #0]
d0080024:	2100      	movs	r1, #0
d0080026:	68d8      	ldr	r0, [r3, #12]
d0080028:	f004 fd98 	bl	d0084b5c <setbuf>
d008002c:	4629      	mov	r1, r5
d008002e:	4620      	mov	r0, r4
d0080030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0080034:	f004 bbae 	b.w	d0084794 <main>
d0080038:	d0086114 	.word	0xd0086114

d008003c <initMalloc>:
d008003c:	4902      	ldr	r1, [pc, #8]	; (d0080048 <initMalloc+0xc>)
d008003e:	4b03      	ldr	r3, [pc, #12]	; (d008004c <initMalloc+0x10>)
d0080040:	4a03      	ldr	r2, [pc, #12]	; (d0080050 <initMalloc+0x14>)
d0080042:	1a5b      	subs	r3, r3, r1
d0080044:	6013      	str	r3, [r2, #0]
d0080046:	4770      	bx	lr
d0080048:	d00ca288 	.word	0xd00ca288
d008004c:	d0600000 	.word	0xd0600000
d0080050:	d00c8274 	.word	0xd00c8274

d0080054 <_write_r>:
d0080054:	3901      	subs	r1, #1
d0080056:	2901      	cmp	r1, #1
d0080058:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008005a:	d81f      	bhi.n	d008009c <_write_r+0x48>
d008005c:	b1e2      	cbz	r2, d0080098 <_write_r+0x44>
d008005e:	461c      	mov	r4, r3
d0080060:	b1d3      	cbz	r3, d0080098 <_write_r+0x44>
d0080062:	4d12      	ldr	r5, [pc, #72]	; (d00800ac <_write_r+0x58>)
d0080064:	682e      	ldr	r6, [r5, #0]
d0080066:	b9ae      	cbnz	r6, d0080094 <_write_r+0x40>
d0080068:	4f11      	ldr	r7, [pc, #68]	; (d00800b0 <_write_r+0x5c>)
d008006a:	2301      	movs	r3, #1
d008006c:	4611      	mov	r1, r2
d008006e:	4630      	mov	r0, r6
d0080070:	602b      	str	r3, [r5, #0]
d0080072:	4622      	mov	r2, r4
d0080074:	7a3b      	ldrb	r3, [r7, #8]
d0080076:	f897 c009 	ldrb.w	ip, [r7, #9]
d008007a:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d008007e:	f897 c00a 	ldrb.w	ip, [r7, #10]
d0080082:	7aff      	ldrb	r7, [r7, #11]
d0080084:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0080088:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d008008c:	681b      	ldr	r3, [r3, #0]
d008008e:	685b      	ldr	r3, [r3, #4]
d0080090:	4798      	blx	r3
d0080092:	602e      	str	r6, [r5, #0]
d0080094:	4620      	mov	r0, r4
d0080096:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0080098:	2000      	movs	r0, #0
d008009a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d008009c:	f004 fc9e 	bl	d00849dc <__errno>
d00800a0:	2209      	movs	r2, #9
d00800a2:	4603      	mov	r3, r0
d00800a4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800a8:	601a      	str	r2, [r3, #0]
d00800aa:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800ac:	d0086184 	.word	0xd0086184
d00800b0:	2001f000 	.word	0x2001f000

d00800b4 <_read>:
d00800b4:	b508      	push	{r3, lr}
d00800b6:	f004 fc91 	bl	d00849dc <__errno>
d00800ba:	2258      	movs	r2, #88	; 0x58
d00800bc:	4603      	mov	r3, r0
d00800be:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800c2:	601a      	str	r2, [r3, #0]
d00800c4:	bd08      	pop	{r3, pc}
d00800c6:	bf00      	nop

d00800c8 <_close>:
d00800c8:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800cc:	4770      	bx	lr
d00800ce:	bf00      	nop

d00800d0 <_fstat>:
d00800d0:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d00800d4:	2000      	movs	r0, #0
d00800d6:	604b      	str	r3, [r1, #4]
d00800d8:	4770      	bx	lr
d00800da:	bf00      	nop

d00800dc <_lseek>:
d00800dc:	2000      	movs	r0, #0
d00800de:	4770      	bx	lr

d00800e0 <_sbrk_r>:
d00800e0:	4b0c      	ldr	r3, [pc, #48]	; (d0080114 <_sbrk_r+0x34>)
d00800e2:	4a0d      	ldr	r2, [pc, #52]	; (d0080118 <_sbrk_r+0x38>)
d00800e4:	6818      	ldr	r0, [r3, #0]
d00800e6:	b510      	push	{r4, lr}
d00800e8:	b918      	cbnz	r0, d00800f2 <_sbrk_r+0x12>
d00800ea:	1dd0      	adds	r0, r2, #7
d00800ec:	f020 0007 	bic.w	r0, r0, #7
d00800f0:	6018      	str	r0, [r3, #0]
d00800f2:	4401      	add	r1, r0
d00800f4:	4c09      	ldr	r4, [pc, #36]	; (d008011c <_sbrk_r+0x3c>)
d00800f6:	42a1      	cmp	r1, r4
d00800f8:	d803      	bhi.n	d0080102 <_sbrk_r+0x22>
d00800fa:	4291      	cmp	r1, r2
d00800fc:	d301      	bcc.n	d0080102 <_sbrk_r+0x22>
d00800fe:	6019      	str	r1, [r3, #0]
d0080100:	bd10      	pop	{r4, pc}
d0080102:	f004 fc6b 	bl	d00849dc <__errno>
d0080106:	220c      	movs	r2, #12
d0080108:	4603      	mov	r3, r0
d008010a:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008010e:	601a      	str	r2, [r3, #0]
d0080110:	bd10      	pop	{r4, pc}
d0080112:	bf00      	nop
d0080114:	d0086180 	.word	0xd0086180
d0080118:	d00ca288 	.word	0xd00ca288
d008011c:	d0600000 	.word	0xd0600000

d0080120 <emit_pause.constprop.0>:
d0080120:	8802      	ldrh	r2, [r0, #0]
d0080122:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0080126:	d300      	bcc.n	d008012a <emit_pause.constprop.0+0xa>
d0080128:	4770      	bx	lr
d008012a:	b470      	push	{r4, r5, r6}
d008012c:	4b18      	ldr	r3, [pc, #96]	; (d0080190 <emit_pause.constprop.0+0x70>)
d008012e:	2600      	movs	r6, #0
d0080130:	4d18      	ldr	r5, [pc, #96]	; (d0080194 <emit_pause.constprop.0+0x74>)
d0080132:	f803 6022 	strb.w	r6, [r3, r2, lsl #2]
d0080136:	8802      	ldrh	r2, [r0, #0]
d0080138:	882c      	ldrh	r4, [r5, #0]
d008013a:	eb03 0282 	add.w	r2, r3, r2, lsl #2
d008013e:	8051      	strh	r1, [r2, #2]
d0080140:	8802      	ldrh	r2, [r0, #0]
d0080142:	eb03 0382 	add.w	r3, r3, r2, lsl #2
d0080146:	705e      	strb	r6, [r3, #1]
d0080148:	8803      	ldrh	r3, [r0, #0]
d008014a:	3301      	adds	r3, #1
d008014c:	8003      	strh	r3, [r0, #0]
d008014e:	b95c      	cbnz	r4, d0080168 <emit_pause.constprop.0+0x48>
d0080150:	4622      	mov	r2, r4
d0080152:	4911      	ldr	r1, [pc, #68]	; (d0080198 <emit_pause.constprop.0+0x78>)
d0080154:	2301      	movs	r3, #1
d0080156:	b29b      	uxth	r3, r3
d0080158:	205f      	movs	r0, #95	; 0x5f
d008015a:	5488      	strb	r0, [r1, r2]
d008015c:	461a      	mov	r2, r3
d008015e:	802b      	strh	r3, [r5, #0]
d0080160:	2300      	movs	r3, #0
d0080162:	548b      	strb	r3, [r1, r2]
d0080164:	bc70      	pop	{r4, r5, r6}
d0080166:	4770      	bx	lr
d0080168:	1c63      	adds	r3, r4, #1
d008016a:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d008016e:	d20b      	bcs.n	d0080188 <emit_pause.constprop.0+0x68>
d0080170:	b29b      	uxth	r3, r3
d0080172:	4909      	ldr	r1, [pc, #36]	; (d0080198 <emit_pause.constprop.0+0x78>)
d0080174:	2020      	movs	r0, #32
d0080176:	461a      	mov	r2, r3
d0080178:	802b      	strh	r3, [r5, #0]
d008017a:	3301      	adds	r3, #1
d008017c:	5508      	strb	r0, [r1, r4]
d008017e:	548e      	strb	r6, [r1, r2]
d0080180:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0080184:	d3e7      	bcc.n	d0080156 <emit_pause.constprop.0+0x36>
d0080186:	e7eb      	b.n	d0080160 <emit_pause.constprop.0+0x40>
d0080188:	4903      	ldr	r1, [pc, #12]	; (d0080198 <emit_pause.constprop.0+0x78>)
d008018a:	4622      	mov	r2, r4
d008018c:	550e      	strb	r6, [r1, r4]
d008018e:	e7e7      	b.n	d0080160 <emit_pause.constprop.0+0x40>
d0080190:	d0086188 	.word	0xd0086188
d0080194:	d0087588 	.word	0xd0087588
d0080198:	d0086d88 	.word	0xd0086d88

d008019c <emit_phone.constprop.0>:
d008019c:	b4f0      	push	{r4, r5, r6, r7}
d008019e:	8804      	ldrh	r4, [r0, #0]
d00801a0:	f5b4 7f40 	cmp.w	r4, #768	; 0x300
d00801a4:	d22e      	bcs.n	d0080204 <emit_phone.constprop.0+0x68>
d00801a6:	4e2e      	ldr	r6, [pc, #184]	; (d0080260 <emit_phone.constprop.0+0xc4>)
d00801a8:	b372      	cbz	r2, d0080208 <emit_phone.constprop.0+0x6c>
d00801aa:	008d      	lsls	r5, r1, #2
d00801ac:	4f2d      	ldr	r7, [pc, #180]	; (d0080264 <emit_phone.constprop.0+0xc8>)
d00801ae:	440d      	add	r5, r1
d00801b0:	f807 1024 	strb.w	r1, [r7, r4, lsl #2]
d00801b4:	8801      	ldrh	r1, [r0, #0]
d00801b6:	f856 5025 	ldr.w	r5, [r6, r5, lsl #2]
d00801ba:	eb07 0181 	add.w	r1, r7, r1, lsl #2
d00801be:	4e2a      	ldr	r6, [pc, #168]	; (d0080268 <emit_phone.constprop.0+0xcc>)
d00801c0:	804a      	strh	r2, [r1, #2]
d00801c2:	8802      	ldrh	r2, [r0, #0]
d00801c4:	8834      	ldrh	r4, [r6, #0]
d00801c6:	eb07 0782 	add.w	r7, r7, r2, lsl #2
d00801ca:	707b      	strb	r3, [r7, #1]
d00801cc:	8802      	ldrh	r2, [r0, #0]
d00801ce:	3201      	adds	r2, #1
d00801d0:	8002      	strh	r2, [r0, #0]
d00801d2:	bb04      	cbnz	r4, d0080216 <emit_phone.constprop.0+0x7a>
d00801d4:	4621      	mov	r1, r4
d00801d6:	4825      	ldr	r0, [pc, #148]	; (d008026c <emit_phone.constprop.0+0xd0>)
d00801d8:	782f      	ldrb	r7, [r5, #0]
d00801da:	2f00      	cmp	r7, #0
d00801dc:	d03d      	beq.n	d008025a <emit_phone.constprop.0+0xbe>
d00801de:	4629      	mov	r1, r5
d00801e0:	e004      	b.n	d00801ec <emit_phone.constprop.0+0x50>
d00801e2:	5507      	strb	r7, [r0, r4]
d00801e4:	4614      	mov	r4, r2
d00801e6:	f811 7f01 	ldrb.w	r7, [r1, #1]!
d00801ea:	b30f      	cbz	r7, d0080230 <emit_phone.constprop.0+0x94>
d00801ec:	1c62      	adds	r2, r4, #1
d00801ee:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00801f2:	b292      	uxth	r2, r2
d00801f4:	d3f5      	bcc.n	d00801e2 <emit_phone.constprop.0+0x46>
d00801f6:	2200      	movs	r2, #0
d00801f8:	4621      	mov	r1, r4
d00801fa:	8034      	strh	r4, [r6, #0]
d00801fc:	5502      	strb	r2, [r0, r4]
d00801fe:	b10b      	cbz	r3, d0080204 <emit_phone.constprop.0+0x68>
d0080200:	2300      	movs	r3, #0
d0080202:	5443      	strb	r3, [r0, r1]
d0080204:	bcf0      	pop	{r4, r5, r6, r7}
d0080206:	4770      	bx	lr
d0080208:	eb01 0281 	add.w	r2, r1, r1, lsl #2
d008020c:	008d      	lsls	r5, r1, #2
d008020e:	eb06 0282 	add.w	r2, r6, r2, lsl #2
d0080212:	8a12      	ldrh	r2, [r2, #16]
d0080214:	e7ca      	b.n	d00801ac <emit_phone.constprop.0+0x10>
d0080216:	1c61      	adds	r1, r4, #1
d0080218:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008021c:	d21a      	bcs.n	d0080254 <emit_phone.constprop.0+0xb8>
d008021e:	b289      	uxth	r1, r1
d0080220:	4812      	ldr	r0, [pc, #72]	; (d008026c <emit_phone.constprop.0+0xd0>)
d0080222:	2220      	movs	r2, #32
d0080224:	8031      	strh	r1, [r6, #0]
d0080226:	5502      	strb	r2, [r0, r4]
d0080228:	2200      	movs	r2, #0
d008022a:	460c      	mov	r4, r1
d008022c:	5442      	strb	r2, [r0, r1]
d008022e:	e7d3      	b.n	d00801d8 <emit_phone.constprop.0+0x3c>
d0080230:	4611      	mov	r1, r2
d0080232:	8032      	strh	r2, [r6, #0]
d0080234:	2400      	movs	r4, #0
d0080236:	5444      	strb	r4, [r0, r1]
d0080238:	2b00      	cmp	r3, #0
d008023a:	d0e3      	beq.n	d0080204 <emit_phone.constprop.0+0x68>
d008023c:	3201      	adds	r2, #1
d008023e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080242:	d2dd      	bcs.n	d0080200 <emit_phone.constprop.0+0x64>
d0080244:	b292      	uxth	r2, r2
d0080246:	2327      	movs	r3, #39	; 0x27
d0080248:	5443      	strb	r3, [r0, r1]
d008024a:	4611      	mov	r1, r2
d008024c:	2300      	movs	r3, #0
d008024e:	8032      	strh	r2, [r6, #0]
d0080250:	5443      	strb	r3, [r0, r1]
d0080252:	e7d7      	b.n	d0080204 <emit_phone.constprop.0+0x68>
d0080254:	4621      	mov	r1, r4
d0080256:	4805      	ldr	r0, [pc, #20]	; (d008026c <emit_phone.constprop.0+0xd0>)
d0080258:	e7e6      	b.n	d0080228 <emit_phone.constprop.0+0x8c>
d008025a:	4622      	mov	r2, r4
d008025c:	e7ea      	b.n	d0080234 <emit_phone.constprop.0+0x98>
d008025e:	bf00      	nop
d0080260:	d0085c94 	.word	0xd0085c94
d0080264:	d0086188 	.word	0xd0086188
d0080268:	d0087588 	.word	0xd0087588
d008026c:	d0086d88 	.word	0xd0086d88

d0080270 <render_noise.constprop.0>:
d0080270:	b4f0      	push	{r4, r5, r6, r7}
d0080272:	4ecd      	ldr	r6, [pc, #820]	; (d00805a8 <render_noise.constprop.0+0x338>)
d0080274:	f012 0c02 	ands.w	ip, r2, #2
d0080278:	4dcc      	ldr	r5, [pc, #816]	; (d00805ac <render_noise.constprop.0+0x33c>)
d008027a:	6877      	ldr	r7, [r6, #4]
d008027c:	4bcc      	ldr	r3, [pc, #816]	; (d00805b0 <render_noise.constprop.0+0x340>)
d008027e:	f9b6 4314 	ldrsh.w	r4, [r6, #788]	; 0x314
d0080282:	fb05 3707 	mla	r7, r5, r7, r3
d0080286:	ea4f 4527 	mov.w	r5, r7, asr #16
d008028a:	6077      	str	r7, [r6, #4]
d008028c:	ebc4 4327 	rsb	r3, r4, r7, asr #16
d0080290:	f8a6 5314 	strh.w	r5, [r6, #788]	; 0x314
d0080294:	ea4f 47a7 	mov.w	r7, r7, asr #18
d0080298:	d023      	beq.n	d00802e2 <render_noise.constprop.0+0x72>
d008029a:	eb03 0343 	add.w	r3, r3, r3, lsl #1
d008029e:	19df      	adds	r7, r3, r7
d00802a0:	bf48      	it	mi
d00802a2:	3703      	addmi	r7, #3
d00802a4:	10bf      	asrs	r7, r7, #2
d00802a6:	3810      	subs	r0, #16
d00802a8:	2817      	cmp	r0, #23
d00802aa:	f200 80f5 	bhi.w	d0080498 <render_noise.constprop.0+0x228>
d00802ae:	e8df f010 	tbh	[pc, r0, lsl #1]
d00802b2:	0140      	.short	0x0140
d00802b4:	01300022 	.word	0x01300022
d00802b8:	00e300e3 	.word	0x00e300e3
d00802bc:	01600120 	.word	0x01600120
d00802c0:	01200022 	.word	0x01200022
d00802c4:	00f300f3 	.word	0x00f300f3
d00802c8:	00f300f3 	.word	0x00f300f3
d00802cc:	00f30140 	.word	0x00f30140
d00802d0:	00220150 	.word	0x00220150
d00802d4:	00e30130 	.word	0x00e30130
d00802d8:	00f300e3 	.word	0x00f300e3
d00802dc:	015000f3 	.word	0x015000f3
d00802e0:	0022      	.short	0x0022
d00802e2:	0754      	lsls	r4, r2, #29
d00802e4:	d5df      	bpl.n	d00802a6 <render_noise.constprop.0+0x36>
d00802e6:	eb07 0743 	add.w	r7, r7, r3, lsl #1
d00802ea:	4bb2      	ldr	r3, [pc, #712]	; (d00805b4 <render_noise.constprop.0+0x344>)
d00802ec:	fb83 4307 	smull	r4, r3, r3, r7
d00802f0:	eba3 77e7 	sub.w	r7, r3, r7, asr #31
d00802f4:	e7d7      	b.n	d00802a6 <render_noise.constprop.0+0x36>
d00802f6:	ed9f 6ab0 	vldr	s12, [pc, #704]	; d00805b8 <render_noise.constprop.0+0x348>
d00802fa:	2326      	movs	r3, #38	; 0x26
d00802fc:	eddf 2aaf 	vldr	s5, [pc, #700]	; d00805bc <render_noise.constprop.0+0x34c>
d0080300:	205e      	movs	r0, #94	; 0x5e
d0080302:	eddf 6aaf 	vldr	s13, [pc, #700]	; d00805c0 <render_noise.constprop.0+0x350>
d0080306:	2584      	movs	r5, #132	; 0x84
d0080308:	ed9f 3aae 	vldr	s6, [pc, #696]	; d00805c4 <render_noise.constprop.0+0x354>
d008030c:	ed9f 7aae 	vldr	s14, [pc, #696]	; d00805c8 <render_noise.constprop.0+0x358>
d0080310:	eddf 4aae 	vldr	s9, [pc, #696]	; d00805cc <render_noise.constprop.0+0x35c>
d0080314:	edd6 7ac7 	vldr	s15, [r6, #796]	; 0x31c
d0080318:	ee05 7a90 	vmov	s11, r7
d008031c:	eddf 3aac 	vldr	s7, [pc, #688]	; d00805d0 <render_noise.constprop.0+0x360>
d0080320:	eef1 1a04 	vmov.f32	s3, #20	; 0x40a00000  5.0
d0080324:	eeb8 4ae5 	vcvt.f32.s32	s8, s11
d0080328:	ed96 5ac6 	vldr	s10, [r6, #792]	; 0x318
d008032c:	ee26 6a67 	vnmul.f32	s12, s12, s15
d0080330:	eddf 5aa8 	vldr	s11, [pc, #672]	; d00805d4 <render_noise.constprop.0+0x364>
d0080334:	eea7 5aa2 	vfma.f32	s10, s15, s5
d0080338:	eeb9 2a04 	vmov.f32	s4, #148	; 0xc0a00000 -5.0
d008033c:	eea4 6a23 	vfma.f32	s12, s8, s7
d0080340:	fec5 3a61 	vminnm.f32	s7, s10, s3
d0080344:	fec3 3a82 	vmaxnm.f32	s7, s7, s4
d0080348:	edc6 3ac6 	vstr	s7, [r6, #792]	; 0x318
d008034c:	eef9 3a04 	vmov.f32	s7, #148	; 0xc0a00000 -5.0
d0080350:	ee36 6a45 	vsub.f32	s12, s12, s10
d0080354:	ed9f 5a9e 	vldr	s10, [pc, #632]	; d00805d0 <render_noise.constprop.0+0x360>
d0080358:	eee6 7a22 	vfma.f32	s15, s12, s5
d008035c:	eef1 2a04 	vmov.f32	s5, #20	; 0x40a00000  5.0
d0080360:	fec7 7ae1 	vminnm.f32	s15, s15, s3
d0080364:	fec7 7a82 	vmaxnm.f32	s15, s15, s4
d0080368:	ee27 6aa5 	vmul.f32	s12, s15, s11
d008036c:	edc6 7ac7 	vstr	s15, [r6, #796]	; 0x31c
d0080370:	edd6 7ac9 	vldr	s15, [r6, #804]	; 0x324
d0080374:	edd6 5ac8 	vldr	s11, [r6, #800]	; 0x320
d0080378:	ee66 6ae7 	vnmul.f32	s13, s13, s15
d008037c:	eee7 5a83 	vfma.f32	s11, s15, s6
d0080380:	eebd 6ac6 	vcvt.s32.f32	s12, s12
d0080384:	eee4 6a05 	vfma.f32	s13, s8, s10
d0080388:	ee16 4a10 	vmov	r4, s12
d008038c:	ed9f 6a91 	vldr	s12, [pc, #580]	; d00805d4 <render_noise.constprop.0+0x364>
d0080390:	fe85 5ae2 	vminnm.f32	s10, s11, s5
d0080394:	fe85 5a23 	vmaxnm.f32	s10, s10, s7
d0080398:	ed86 5ac8 	vstr	s10, [r6, #800]	; 0x320
d008039c:	eeb9 5a04 	vmov.f32	s10, #148	; 0xc0a00000 -5.0
d00803a0:	ee76 6ae5 	vsub.f32	s13, s13, s11
d00803a4:	eddf 5a8a 	vldr	s11, [pc, #552]	; d00805d0 <render_noise.constprop.0+0x360>
d00803a8:	fb05 f404 	mul.w	r4, r5, r4
d00803ac:	eee6 7a83 	vfma.f32	s15, s13, s6
d00803b0:	2c00      	cmp	r4, #0
d00803b2:	bfb8      	it	lt
d00803b4:	347f      	addlt	r4, #127	; 0x7f
d00803b6:	11e4      	asrs	r4, r4, #7
d00803b8:	fec7 7ae2 	vminnm.f32	s15, s15, s5
d00803bc:	fec7 7aa3 	vmaxnm.f32	s15, s15, s7
d00803c0:	ee67 6a86 	vmul.f32	s13, s15, s12
d00803c4:	edc6 7ac9 	vstr	s15, [r6, #804]	; 0x324
d00803c8:	edd6 7acb 	vldr	s15, [r6, #812]	; 0x32c
d00803cc:	eef1 3a04 	vmov.f32	s7, #20	; 0x40a00000  5.0
d00803d0:	ed96 6aca 	vldr	s12, [r6, #808]	; 0x328
d00803d4:	ee27 7a67 	vnmul.f32	s14, s14, s15
d00803d8:	eea7 6aa4 	vfma.f32	s12, s15, s9
d00803dc:	eefd 6ae6 	vcvt.s32.f32	s13, s13
d00803e0:	eea4 7a25 	vfma.f32	s14, s8, s11
d00803e4:	ee16 5a90 	vmov	r5, s13
d00803e8:	eddf 6a7a 	vldr	s13, [pc, #488]	; d00805d4 <render_noise.constprop.0+0x364>
d00803ec:	fb00 f005 	mul.w	r0, r0, r5
d00803f0:	fec6 5a63 	vminnm.f32	s11, s12, s7
d00803f4:	fec5 5a85 	vmaxnm.f32	s11, s11, s10
d00803f8:	edc6 5aca 	vstr	s11, [r6, #808]	; 0x328
d00803fc:	ee37 7a46 	vsub.f32	s14, s14, s12
d0080400:	2800      	cmp	r0, #0
d0080402:	bfb8      	it	lt
d0080404:	307f      	addlt	r0, #127	; 0x7f
d0080406:	eee7 7a24 	vfma.f32	s15, s14, s9
d008040a:	eb04 14e0 	add.w	r4, r4, r0, asr #7
d008040e:	fec7 7ae3 	vminnm.f32	s15, s15, s7
d0080412:	fec7 7a85 	vmaxnm.f32	s15, s15, s10
d0080416:	ee27 7aa6 	vmul.f32	s14, s15, s13
d008041a:	edc6 7acb 	vstr	s15, [r6, #812]	; 0x32c
d008041e:	eebd 7ac7 	vcvt.s32.f32	s14, s14
d0080422:	ee17 0a10 	vmov	r0, s14
d0080426:	fb03 f300 	mul.w	r3, r3, r0
d008042a:	2b00      	cmp	r3, #0
d008042c:	bfb8      	it	lt
d008042e:	337f      	addlt	r3, #127	; 0x7f
d0080430:	eb04 13e3 	add.w	r3, r4, r3, asr #7
d0080434:	f1bc 0f00 	cmp.w	ip, #0
d0080438:	f000 80ab 	beq.w	d0080592 <render_noise.constprop.0+0x322>
d008043c:	4a66      	ldr	r2, [pc, #408]	; (d00805d8 <render_noise.constprop.0+0x368>)
d008043e:	17f8      	asrs	r0, r7, #31
d0080440:	fb82 4207 	smull	r4, r2, r2, r7
d0080444:	4417      	add	r7, r2
d0080446:	ebc0 07a7 	rsb	r7, r0, r7, asr #2
d008044a:	443b      	add	r3, r7
d008044c:	ea83 74e3 	eor.w	r4, r3, r3, asr #31
d0080450:	f647 72ff 	movw	r2, #32767	; 0x7fff
d0080454:	4861      	ldr	r0, [pc, #388]	; (d00805dc <render_noise.constprop.0+0x36c>)
d0080456:	eba4 74e3 	sub.w	r4, r4, r3, asr #31
d008045a:	ebc3 33c3 	rsb	r3, r3, r3, lsl #15
d008045e:	4422      	add	r2, r4
d0080460:	fb93 f3f2 	sdiv	r3, r3, r2
d0080464:	fb01 f103 	mul.w	r1, r1, r3
d0080468:	fb80 2301 	smull	r2, r3, r0, r1
d008046c:	17c8      	asrs	r0, r1, #31
d008046e:	440b      	add	r3, r1
d0080470:	bcf0      	pop	{r4, r5, r6, r7}
d0080472:	ebc0 20a3 	rsb	r0, r0, r3, asr #10
d0080476:	4770      	bx	lr
d0080478:	ed9f 6a59 	vldr	s12, [pc, #356]	; d00805e0 <render_noise.constprop.0+0x370>
d008047c:	232c      	movs	r3, #44	; 0x2c
d008047e:	eddf 2a59 	vldr	s5, [pc, #356]	; d00805e4 <render_noise.constprop.0+0x374>
d0080482:	2046      	movs	r0, #70	; 0x46
d0080484:	eddf 6a58 	vldr	s13, [pc, #352]	; d00805e8 <render_noise.constprop.0+0x378>
d0080488:	2548      	movs	r5, #72	; 0x48
d008048a:	ed9f 3a58 	vldr	s6, [pc, #352]	; d00805ec <render_noise.constprop.0+0x37c>
d008048e:	ed9f 7a58 	vldr	s14, [pc, #352]	; d00805f0 <render_noise.constprop.0+0x380>
d0080492:	eddf 4a58 	vldr	s9, [pc, #352]	; d00805f4 <render_noise.constprop.0+0x384>
d0080496:	e73d      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d0080498:	f002 0304 	and.w	r3, r2, #4
d008049c:	eddf 7a56 	vldr	s15, [pc, #344]	; d00805f8 <render_noise.constprop.0+0x388>
d00804a0:	ed9f 6a56 	vldr	s12, [pc, #344]	; d00805fc <render_noise.constprop.0+0x38c>
d00804a4:	2b00      	cmp	r3, #0
d00804a6:	ed9f 7a56 	vldr	s14, [pc, #344]	; d0080600 <render_noise.constprop.0+0x390>
d00804aa:	eddf 2a56 	vldr	s5, [pc, #344]	; d0080604 <render_noise.constprop.0+0x394>
d00804ae:	eddf 6a56 	vldr	s13, [pc, #344]	; d0080608 <render_noise.constprop.0+0x398>
d00804b2:	fe06 6a27 	vseleq.f32	s12, s12, s15
d00804b6:	eddf 7a55 	vldr	s15, [pc, #340]	; d008060c <render_noise.constprop.0+0x39c>
d00804ba:	fe42 2a87 	vseleq.f32	s5, s5, s14
d00804be:	ed9f 3a43 	vldr	s6, [pc, #268]	; d00805cc <render_noise.constprop.0+0x35c>
d00804c2:	bf08      	it	eq
d00804c4:	2322      	moveq	r3, #34	; 0x22
d00804c6:	eddf 5a52 	vldr	s11, [pc, #328]	; d0080610 <render_noise.constprop.0+0x3a0>
d00804ca:	fe46 6aa7 	vseleq.f32	s13, s13, s15
d00804ce:	ed9f 7a51 	vldr	s14, [pc, #324]	; d0080614 <render_noise.constprop.0+0x3a4>
d00804d2:	bf18      	it	ne
d00804d4:	232c      	movne	r3, #44	; 0x2c
d00804d6:	eddf 7a50 	vldr	s15, [pc, #320]	; d0080618 <render_noise.constprop.0+0x3a8>
d00804da:	bf0b      	itete	eq
d00804dc:	2044      	moveq	r0, #68	; 0x44
d00804de:	2050      	movne	r0, #80	; 0x50
d00804e0:	2564      	moveq	r5, #100	; 0x64
d00804e2:	255e      	movne	r5, #94	; 0x5e
d00804e4:	eddf 4a43 	vldr	s9, [pc, #268]	; d00805f4 <render_noise.constprop.0+0x384>
d00804e8:	fe03 3a25 	vseleq.f32	s6, s6, s11
d00804ec:	fe07 7a27 	vseleq.f32	s14, s14, s15
d00804f0:	e710      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d00804f2:	ed9f 6a4a 	vldr	s12, [pc, #296]	; d008061c <render_noise.constprop.0+0x3ac>
d00804f6:	233a      	movs	r3, #58	; 0x3a
d00804f8:	eddf 2a49 	vldr	s5, [pc, #292]	; d0080620 <render_noise.constprop.0+0x3b0>
d00804fc:	2080      	movs	r0, #128	; 0x80
d00804fe:	eddf 6a49 	vldr	s13, [pc, #292]	; d0080624 <render_noise.constprop.0+0x3b4>
d0080502:	2562      	movs	r5, #98	; 0x62
d0080504:	ed9f 3a48 	vldr	s6, [pc, #288]	; d0080628 <render_noise.constprop.0+0x3b8>
d0080508:	ed9f 7a48 	vldr	s14, [pc, #288]	; d008062c <render_noise.constprop.0+0x3bc>
d008050c:	eddf 4a2f 	vldr	s9, [pc, #188]	; d00805cc <render_noise.constprop.0+0x35c>
d0080510:	e700      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d0080512:	ed9f 3a38 	vldr	s6, [pc, #224]	; d00805f4 <render_noise.constprop.0+0x384>
d0080516:	2340      	movs	r3, #64	; 0x40
d0080518:	ed9f 6a45 	vldr	s12, [pc, #276]	; d0080630 <render_noise.constprop.0+0x3c0>
d008051c:	2076      	movs	r0, #118	; 0x76
d008051e:	eef0 4a43 	vmov.f32	s9, s6
d0080522:	eddf 2a32 	vldr	s5, [pc, #200]	; d00805ec <render_noise.constprop.0+0x37c>
d0080526:	eddf 6a43 	vldr	s13, [pc, #268]	; d0080634 <render_noise.constprop.0+0x3c4>
d008052a:	2574      	movs	r5, #116	; 0x74
d008052c:	ed9f 7a42 	vldr	s14, [pc, #264]	; d0080638 <render_noise.constprop.0+0x3c8>
d0080530:	e6f0      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d0080532:	ed9f 6a42 	vldr	s12, [pc, #264]	; d008063c <render_noise.constprop.0+0x3cc>
d0080536:	2330      	movs	r3, #48	; 0x30
d0080538:	eddf 2a41 	vldr	s5, [pc, #260]	; d0080640 <render_noise.constprop.0+0x3d0>
d008053c:	2056      	movs	r0, #86	; 0x56
d008053e:	eddf 6a41 	vldr	s13, [pc, #260]	; d0080644 <render_noise.constprop.0+0x3d4>
d0080542:	255c      	movs	r5, #92	; 0x5c
d0080544:	ed9f 3a40 	vldr	s6, [pc, #256]	; d0080648 <render_noise.constprop.0+0x3d8>
d0080548:	ed9f 7a40 	vldr	s14, [pc, #256]	; d008064c <render_noise.constprop.0+0x3dc>
d008054c:	eddf 4a40 	vldr	s9, [pc, #256]	; d0080650 <render_noise.constprop.0+0x3e0>
d0080550:	e6e0      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d0080552:	ed9f 3a28 	vldr	s6, [pc, #160]	; d00805f4 <render_noise.constprop.0+0x384>
d0080556:	2326      	movs	r3, #38	; 0x26
d0080558:	ed9f 6a3e 	vldr	s12, [pc, #248]	; d0080654 <render_noise.constprop.0+0x3e4>
d008055c:	2052      	movs	r0, #82	; 0x52
d008055e:	eef0 4a43 	vmov.f32	s9, s6
d0080562:	eddf 2a1a 	vldr	s5, [pc, #104]	; d00805cc <render_noise.constprop.0+0x35c>
d0080566:	eddf 6a3c 	vldr	s13, [pc, #240]	; d0080658 <render_noise.constprop.0+0x3e8>
d008056a:	258e      	movs	r5, #142	; 0x8e
d008056c:	ed9f 7a3b 	vldr	s14, [pc, #236]	; d008065c <render_noise.constprop.0+0x3ec>
d0080570:	e6d0      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d0080572:	ed9f 6a3b 	vldr	s12, [pc, #236]	; d0080660 <render_noise.constprop.0+0x3f0>
d0080576:	231c      	movs	r3, #28
d0080578:	eddf 2a3a 	vldr	s5, [pc, #232]	; d0080664 <render_noise.constprop.0+0x3f4>
d008057c:	2034      	movs	r0, #52	; 0x34
d008057e:	eddf 6a3a 	vldr	s13, [pc, #232]	; d0080668 <render_noise.constprop.0+0x3f8>
d0080582:	2540      	movs	r5, #64	; 0x40
d0080584:	ed9f 3a0d 	vldr	s6, [pc, #52]	; d00805bc <render_noise.constprop.0+0x34c>
d0080588:	ed9f 7a38 	vldr	s14, [pc, #224]	; d008066c <render_noise.constprop.0+0x3fc>
d008058c:	eddf 4a38 	vldr	s9, [pc, #224]	; d0080670 <render_noise.constprop.0+0x400>
d0080590:	e6c0      	b.n	d0080314 <render_noise.constprop.0+0xa4>
d0080592:	0752      	lsls	r2, r2, #29
d0080594:	f57f af5a 	bpl.w	d008044c <render_noise.constprop.0+0x1dc>
d0080598:	4836      	ldr	r0, [pc, #216]	; (d0080674 <render_noise.constprop.0+0x404>)
d008059a:	17fa      	asrs	r2, r7, #31
d008059c:	fb80 0707 	smull	r0, r7, r0, r7
d00805a0:	ebc2 07a7 	rsb	r7, r2, r7, asr #2
d00805a4:	443b      	add	r3, r7
d00805a6:	e751      	b.n	d008044c <render_noise.constprop.0+0x1dc>
d00805a8:	d00c7f3c 	.word	0xd00c7f3c
d00805ac:	0019660d 	.word	0x0019660d
d00805b0:	3c6ef35f 	.word	0x3c6ef35f
d00805b4:	55555556 	.word	0x55555556
d00805b8:	3ec64c11 	.word	0x3ec64c11
d00805bc:	3f3a0438 	.word	0x3f3a0438
d00805c0:	3ec41afb 	.word	0x3ec41afb
d00805c4:	3f852123 	.word	0x3f852123
d00805c8:	3eef6994 	.word	0x3eef6994
d00805cc:	3fbda9f2 	.word	0x3fbda9f2
d00805d0:	38000000 	.word	0x38000000
d00805d4:	46fffe00 	.word	0x46fffe00
d00805d8:	92492493 	.word	0x92492493
d00805dc:	8db30fc7 	.word	0x8db30fc7
d00805e0:	3f94b197 	.word	0x3f94b197
d00805e4:	3ef8059f 	.word	0x3ef8059f
d00805e8:	3f3d85cf 	.word	0x3f3d85cf
d00805ec:	3f8e3f76 	.word	0x3f8e3f76
d00805f0:	3f058eff 	.word	0x3f058eff
d00805f4:	3fd70a3d 	.word	0x3fd70a3d
d00805f8:	3f11dbf6 	.word	0x3f11dbf6
d00805fc:	3f338659 	.word	0x3f338659
d0080600:	3f2f1307 	.word	0x3f2f1307
d0080604:	3f3da9f2 	.word	0x3f3da9f2
d0080608:	3f06ab63 	.word	0x3f06ab63
d008060c:	3ee2f07c 	.word	0x3ee2f07c
d0080610:	3faf1307 	.word	0x3faf1307
d0080614:	3eeb7d30 	.word	0x3eeb7d30
d0080618:	3ee2f484 	.word	0x3ee2f484
d008061c:	3ecaee4f 	.word	0x3ecaee4f
d0080620:	3f27c791 	.word	0x3f27c791
d0080624:	3ec0dc8b 	.word	0x3ec0dc8b
d0080628:	3f817b68 	.word	0x3f817b68
d008062c:	3ec285c9 	.word	0x3ec285c9
d0080630:	3e8ba5f7 	.word	0x3e8ba5f7
d0080634:	3e8a7a14 	.word	0x3e8a7a14
d0080638:	3e9d9929 	.word	0x3e9d9929
d008063c:	3f6dc528 	.word	0x3f6dc528
d0080640:	3e78059f 	.word	0x3e78059f
d0080644:	3f309607 	.word	0x3f309607
d0080648:	3f06f400 	.word	0x3f06f400
d008064c:	3f01abb0 	.word	0x3f01abb0
d0080650:	3f834e45 	.word	0x3f834e45
d0080654:	3e637119 	.word	0x3e637119
d0080658:	3e85122f 	.word	0x3e85122f
d008065c:	3ea6bef1 	.word	0x3ea6bef1
d0080660:	3f9821cf 	.word	0x3f9821cf
d0080664:	3ea7c791 	.word	0x3ea7c791
d0080668:	3f464c11 	.word	0x3f464c11
d008066c:	3f1d4537 	.word	0x3f1d4537
d0080670:	3fab6d4c 	.word	0x3fab6d4c
d0080674:	66666667 	.word	0x66666667

d0080678 <emit_dictionary_word.constprop.0>:
d0080678:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008067c:	7803      	ldrb	r3, [r0, #0]
d008067e:	b082      	sub	sp, #8
d0080680:	4604      	mov	r4, r0
d0080682:	460d      	mov	r5, r1
d0080684:	2b61      	cmp	r3, #97	; 0x61
d0080686:	d133      	bne.n	d00806f0 <emit_dictionary_word.constprop.0+0x78>
d0080688:	7842      	ldrb	r2, [r0, #1]
d008068a:	2a00      	cmp	r2, #0
d008068c:	d130      	bne.n	d00806f0 <emit_dictionary_word.constprop.0+0x78>
d008068e:	8809      	ldrh	r1, [r1, #0]
d0080690:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080694:	f080 81db 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080698:	4ba0      	ldr	r3, [pc, #640]	; (d008091c <emit_dictionary_word.constprop.0+0x2a4>)
d008069a:	2401      	movs	r4, #1
d008069c:	205f      	movs	r0, #95	; 0x5f
d008069e:	f803 4021 	strb.w	r4, [r3, r1, lsl #2]
d00806a2:	8829      	ldrh	r1, [r5, #0]
d00806a4:	4c9e      	ldr	r4, [pc, #632]	; (d0080920 <emit_dictionary_word.constprop.0+0x2a8>)
d00806a6:	eb03 0181 	add.w	r1, r3, r1, lsl #2
d00806aa:	8826      	ldrh	r6, [r4, #0]
d00806ac:	8048      	strh	r0, [r1, #2]
d00806ae:	8829      	ldrh	r1, [r5, #0]
d00806b0:	eb03 0381 	add.w	r3, r3, r1, lsl #2
d00806b4:	705a      	strb	r2, [r3, #1]
d00806b6:	882b      	ldrh	r3, [r5, #0]
d00806b8:	3301      	adds	r3, #1
d00806ba:	802b      	strh	r3, [r5, #0]
d00806bc:	2e00      	cmp	r6, #0
d00806be:	f040 8208 	bne.w	d0080ad2 <emit_dictionary_word.constprop.0+0x45a>
d00806c2:	4b98      	ldr	r3, [pc, #608]	; (d0080924 <emit_dictionary_word.constprop.0+0x2ac>)
d00806c4:	4898      	ldr	r0, [pc, #608]	; (d0080928 <emit_dictionary_word.constprop.0+0x2b0>)
d00806c6:	2141      	movs	r1, #65	; 0x41
d00806c8:	e006      	b.n	d00806d8 <emit_dictionary_word.constprop.0+0x60>
d00806ca:	5599      	strb	r1, [r3, r6]
d00806cc:	4616      	mov	r6, r2
d00806ce:	f810 1f01 	ldrb.w	r1, [r0, #1]!
d00806d2:	2900      	cmp	r1, #0
d00806d4:	f000 835b 	beq.w	d0080d8e <emit_dictionary_word.constprop.0+0x716>
d00806d8:	1c72      	adds	r2, r6, #1
d00806da:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00806de:	b292      	uxth	r2, r2
d00806e0:	d3f3      	bcc.n	d00806ca <emit_dictionary_word.constprop.0+0x52>
d00806e2:	8026      	strh	r6, [r4, #0]
d00806e4:	2200      	movs	r2, #0
d00806e6:	2001      	movs	r0, #1
d00806e8:	559a      	strb	r2, [r3, r6]
d00806ea:	b002      	add	sp, #8
d00806ec:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d00806f0:	2b69      	cmp	r3, #105	; 0x69
d00806f2:	d137      	bne.n	d0080764 <emit_dictionary_word.constprop.0+0xec>
d00806f4:	7863      	ldrb	r3, [r4, #1]
d00806f6:	2b00      	cmp	r3, #0
d00806f8:	d134      	bne.n	d0080764 <emit_dictionary_word.constprop.0+0xec>
d00806fa:	882a      	ldrh	r2, [r5, #0]
d00806fc:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0080700:	f080 81a5 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080704:	4b85      	ldr	r3, [pc, #532]	; (d008091c <emit_dictionary_word.constprop.0+0x2a4>)
d0080706:	240c      	movs	r4, #12
d0080708:	208c      	movs	r0, #140	; 0x8c
d008070a:	2101      	movs	r1, #1
d008070c:	f803 4022 	strb.w	r4, [r3, r2, lsl #2]
d0080710:	882a      	ldrh	r2, [r5, #0]
d0080712:	4c83      	ldr	r4, [pc, #524]	; (d0080920 <emit_dictionary_word.constprop.0+0x2a8>)
d0080714:	eb03 0282 	add.w	r2, r3, r2, lsl #2
d0080718:	8050      	strh	r0, [r2, #2]
d008071a:	8828      	ldrh	r0, [r5, #0]
d008071c:	8822      	ldrh	r2, [r4, #0]
d008071e:	eb03 0380 	add.w	r3, r3, r0, lsl #2
d0080722:	7059      	strb	r1, [r3, #1]
d0080724:	882b      	ldrh	r3, [r5, #0]
d0080726:	440b      	add	r3, r1
d0080728:	802b      	strh	r3, [r5, #0]
d008072a:	2a00      	cmp	r2, #0
d008072c:	f040 81de 	bne.w	d0080aec <emit_dictionary_word.constprop.0+0x474>
d0080730:	4b7c      	ldr	r3, [pc, #496]	; (d0080924 <emit_dictionary_word.constprop.0+0x2ac>)
d0080732:	4d7e      	ldr	r5, [pc, #504]	; (d008092c <emit_dictionary_word.constprop.0+0x2b4>)
d0080734:	2041      	movs	r0, #65	; 0x41
d0080736:	e006      	b.n	d0080746 <emit_dictionary_word.constprop.0+0xce>
d0080738:	5498      	strb	r0, [r3, r2]
d008073a:	f815 0f01 	ldrb.w	r0, [r5, #1]!
d008073e:	2800      	cmp	r0, #0
d0080740:	f000 81e1 	beq.w	d0080b06 <emit_dictionary_word.constprop.0+0x48e>
d0080744:	460a      	mov	r2, r1
d0080746:	1c51      	adds	r1, r2, #1
d0080748:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008074c:	b289      	uxth	r1, r1
d008074e:	d3f3      	bcc.n	d0080738 <emit_dictionary_word.constprop.0+0xc0>
d0080750:	2100      	movs	r1, #0
d0080752:	4615      	mov	r5, r2
d0080754:	8022      	strh	r2, [r4, #0]
d0080756:	5499      	strb	r1, [r3, r2]
d0080758:	2200      	movs	r2, #0
d008075a:	2001      	movs	r0, #1
d008075c:	555a      	strb	r2, [r3, r5]
d008075e:	b002      	add	sp, #8
d0080760:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0080764:	7826      	ldrb	r6, [r4, #0]
d0080766:	2e61      	cmp	r6, #97	; 0x61
d0080768:	d066      	beq.n	d0080838 <emit_dictionary_word.constprop.0+0x1c0>
d008076a:	4971      	ldr	r1, [pc, #452]	; (d0080930 <emit_dictionary_word.constprop.0+0x2b8>)
d008076c:	4620      	mov	r0, r4
d008076e:	f004 faf7 	bl	d0084d60 <strcmp>
d0080772:	2800      	cmp	r0, #0
d0080774:	f000 81d6 	beq.w	d0080b24 <emit_dictionary_word.constprop.0+0x4ac>
d0080778:	496e      	ldr	r1, [pc, #440]	; (d0080934 <emit_dictionary_word.constprop.0+0x2bc>)
d008077a:	4620      	mov	r0, r4
d008077c:	f004 faf0 	bl	d0084d60 <strcmp>
d0080780:	2800      	cmp	r0, #0
d0080782:	f000 82b2 	beq.w	d0080cea <emit_dictionary_word.constprop.0+0x672>
d0080786:	2e62      	cmp	r6, #98	; 0x62
d0080788:	f040 80da 	bne.w	d0080940 <emit_dictionary_word.constprop.0+0x2c8>
d008078c:	7863      	ldrb	r3, [r4, #1]
d008078e:	2b65      	cmp	r3, #101	; 0x65
d0080790:	f040 80d6 	bne.w	d0080940 <emit_dictionary_word.constprop.0+0x2c8>
d0080794:	78a0      	ldrb	r0, [r4, #2]
d0080796:	4684      	mov	ip, r0
d0080798:	2800      	cmp	r0, #0
d008079a:	f040 80d1 	bne.w	d0080940 <emit_dictionary_word.constprop.0+0x2c8>
d008079e:	882b      	ldrh	r3, [r5, #0]
d00807a0:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00807a4:	f080 8153 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00807a8:	4e5c      	ldr	r6, [pc, #368]	; (d008091c <emit_dictionary_word.constprop.0+0x2a4>)
d00807aa:	2110      	movs	r1, #16
d00807ac:	2236      	movs	r2, #54	; 0x36
d00807ae:	4c5c      	ldr	r4, [pc, #368]	; (d0080920 <emit_dictionary_word.constprop.0+0x2a8>)
d00807b0:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d00807b4:	882b      	ldrh	r3, [r5, #0]
d00807b6:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00807ba:	805a      	strh	r2, [r3, #2]
d00807bc:	882b      	ldrh	r3, [r5, #0]
d00807be:	8822      	ldrh	r2, [r4, #0]
d00807c0:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00807c4:	7058      	strb	r0, [r3, #1]
d00807c6:	882b      	ldrh	r3, [r5, #0]
d00807c8:	3301      	adds	r3, #1
d00807ca:	802b      	strh	r3, [r5, #0]
d00807cc:	2a00      	cmp	r2, #0
d00807ce:	f040 84bc 	bne.w	d008114a <emit_dictionary_word.constprop.0+0xad2>
d00807d2:	4b54      	ldr	r3, [pc, #336]	; (d0080924 <emit_dictionary_word.constprop.0+0x2ac>)
d00807d4:	2201      	movs	r2, #1
d00807d6:	b292      	uxth	r2, r2
d00807d8:	2142      	movs	r1, #66	; 0x42
d00807da:	5419      	strb	r1, [r3, r0]
d00807dc:	4610      	mov	r0, r2
d00807de:	8022      	strh	r2, [r4, #0]
d00807e0:	2100      	movs	r1, #0
d00807e2:	5419      	strb	r1, [r3, r0]
d00807e4:	8829      	ldrh	r1, [r5, #0]
d00807e6:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d00807ea:	f080 8130 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00807ee:	2708      	movs	r7, #8
d00807f0:	f04f 0c7a 	mov.w	ip, #122	; 0x7a
d00807f4:	f806 7021 	strb.w	r7, [r6, r1, lsl #2]
d00807f8:	2101      	movs	r1, #1
d00807fa:	882f      	ldrh	r7, [r5, #0]
d00807fc:	eb06 0787 	add.w	r7, r6, r7, lsl #2
d0080800:	f8a7 c002 	strh.w	ip, [r7, #2]
d0080804:	882f      	ldrh	r7, [r5, #0]
d0080806:	eb06 0687 	add.w	r6, r6, r7, lsl #2
d008080a:	7071      	strb	r1, [r6, #1]
d008080c:	882e      	ldrh	r6, [r5, #0]
d008080e:	440e      	add	r6, r1
d0080810:	802e      	strh	r6, [r5, #0]
d0080812:	2a00      	cmp	r2, #0
d0080814:	f040 848c 	bne.w	d0081130 <emit_dictionary_word.constprop.0+0xab8>
d0080818:	4d47      	ldr	r5, [pc, #284]	; (d0080938 <emit_dictionary_word.constprop.0+0x2c0>)
d008081a:	2049      	movs	r0, #73	; 0x49
d008081c:	e007      	b.n	d008082e <emit_dictionary_word.constprop.0+0x1b6>
d008081e:	5498      	strb	r0, [r3, r2]
d0080820:	f815 0f01 	ldrb.w	r0, [r5, #1]!
d0080824:	2800      	cmp	r0, #0
d0080826:	f000 816e 	beq.w	d0080b06 <emit_dictionary_word.constprop.0+0x48e>
d008082a:	460a      	mov	r2, r1
d008082c:	3101      	adds	r1, #1
d008082e:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080832:	b289      	uxth	r1, r1
d0080834:	d3f3      	bcc.n	d008081e <emit_dictionary_word.constprop.0+0x1a6>
d0080836:	e78b      	b.n	d0080750 <emit_dictionary_word.constprop.0+0xd8>
d0080838:	7863      	ldrb	r3, [r4, #1]
d008083a:	2b6d      	cmp	r3, #109	; 0x6d
d008083c:	f000 810b 	beq.w	d0080a56 <emit_dictionary_word.constprop.0+0x3de>
d0080840:	2e61      	cmp	r6, #97	; 0x61
d0080842:	d192      	bne.n	d008076a <emit_dictionary_word.constprop.0+0xf2>
d0080844:	7863      	ldrb	r3, [r4, #1]
d0080846:	2b6e      	cmp	r3, #110	; 0x6e
d0080848:	d18f      	bne.n	d008076a <emit_dictionary_word.constprop.0+0xf2>
d008084a:	78a7      	ldrb	r7, [r4, #2]
d008084c:	2f00      	cmp	r7, #0
d008084e:	d18c      	bne.n	d008076a <emit_dictionary_word.constprop.0+0xf2>
d0080850:	882b      	ldrh	r3, [r5, #0]
d0080852:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080856:	f080 80fa 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d008085a:	4e30      	ldr	r6, [pc, #192]	; (d008091c <emit_dictionary_word.constprop.0+0x2a4>)
d008085c:	2102      	movs	r1, #2
d008085e:	225a      	movs	r2, #90	; 0x5a
d0080860:	4c2f      	ldr	r4, [pc, #188]	; (d0080920 <emit_dictionary_word.constprop.0+0x2a8>)
d0080862:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d0080866:	882b      	ldrh	r3, [r5, #0]
d0080868:	f8b4 c000 	ldrh.w	ip, [r4]
d008086c:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080870:	805a      	strh	r2, [r3, #2]
d0080872:	882b      	ldrh	r3, [r5, #0]
d0080874:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080878:	705f      	strb	r7, [r3, #1]
d008087a:	882b      	ldrh	r3, [r5, #0]
d008087c:	3301      	adds	r3, #1
d008087e:	802b      	strh	r3, [r5, #0]
d0080880:	f1bc 0f00 	cmp.w	ip, #0
d0080884:	f000 83dd 	beq.w	d0081042 <emit_dictionary_word.constprop.0+0x9ca>
d0080888:	f10c 0101 	add.w	r1, ip, #1
d008088c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080890:	f081 803a 	bcs.w	d0081908 <emit_dictionary_word.constprop.0+0x1290>
d0080894:	4b23      	ldr	r3, [pc, #140]	; (d0080924 <emit_dictionary_word.constprop.0+0x2ac>)
d0080896:	2220      	movs	r2, #32
d0080898:	b289      	uxth	r1, r1
d008089a:	f803 200c 	strb.w	r2, [r3, ip]
d008089e:	2200      	movs	r2, #0
d00808a0:	468c      	mov	ip, r1
d00808a2:	545a      	strb	r2, [r3, r1]
d00808a4:	4825      	ldr	r0, [pc, #148]	; (d008093c <emit_dictionary_word.constprop.0+0x2c4>)
d00808a6:	2141      	movs	r1, #65	; 0x41
d00808a8:	e007      	b.n	d00808ba <emit_dictionary_word.constprop.0+0x242>
d00808aa:	f803 100c 	strb.w	r1, [r3, ip]
d00808ae:	4694      	mov	ip, r2
d00808b0:	f810 1f01 	ldrb.w	r1, [r0, #1]!
d00808b4:	2900      	cmp	r1, #0
d00808b6:	f000 8669 	beq.w	d008158c <emit_dictionary_word.constprop.0+0xf14>
d00808ba:	f10c 0201 	add.w	r2, ip, #1
d00808be:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00808c2:	b292      	uxth	r2, r2
d00808c4:	d3f1      	bcc.n	d00808aa <emit_dictionary_word.constprop.0+0x232>
d00808c6:	f8a4 c000 	strh.w	ip, [r4]
d00808ca:	f04f 0e00 	mov.w	lr, #0
d00808ce:	4661      	mov	r1, ip
d00808d0:	f803 e00c 	strb.w	lr, [r3, ip]
d00808d4:	882a      	ldrh	r2, [r5, #0]
d00808d6:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d00808da:	f080 80b8 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00808de:	f04f 081b 	mov.w	r8, #27
d00808e2:	2040      	movs	r0, #64	; 0x40
d00808e4:	f806 8022 	strb.w	r8, [r6, r2, lsl #2]
d00808e8:	882a      	ldrh	r2, [r5, #0]
d00808ea:	eb06 0282 	add.w	r2, r6, r2, lsl #2
d00808ee:	8050      	strh	r0, [r2, #2]
d00808f0:	882a      	ldrh	r2, [r5, #0]
d00808f2:	eb06 0682 	add.w	r6, r6, r2, lsl #2
d00808f6:	f886 e001 	strb.w	lr, [r6, #1]
d00808fa:	882a      	ldrh	r2, [r5, #0]
d00808fc:	3201      	adds	r2, #1
d00808fe:	802a      	strh	r2, [r5, #0]
d0080900:	f1bc 0f00 	cmp.w	ip, #0
d0080904:	f040 83bb 	bne.w	d008107e <emit_dictionary_word.constprop.0+0xa06>
d0080908:	2201      	movs	r2, #1
d008090a:	b292      	uxth	r2, r2
d008090c:	204e      	movs	r0, #78	; 0x4e
d008090e:	4611      	mov	r1, r2
d0080910:	8022      	strh	r2, [r4, #0]
d0080912:	55d8      	strb	r0, [r3, r7]
d0080914:	2200      	movs	r2, #0
d0080916:	2001      	movs	r0, #1
d0080918:	545a      	strb	r2, [r3, r1]
d008091a:	e099      	b.n	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008091c:	d0086188 	.word	0xd0086188
d0080920:	d0087588 	.word	0xd0087588
d0080924:	d0086d88 	.word	0xd0086d88
d0080928:	d00859a0 	.word	0xd00859a0
d008092c:	d00859a4 	.word	0xd00859a4
d0080930:	d00859ac 	.word	0xd00859ac
d0080934:	d00859b0 	.word	0xd00859b0
d0080938:	d00859b8 	.word	0xd00859b8
d008093c:	d00859a8 	.word	0xd00859a8
d0080940:	49b8      	ldr	r1, [pc, #736]	; (d0080c24 <emit_dictionary_word.constprop.0+0x5ac>)
d0080942:	4620      	mov	r0, r4
d0080944:	f004 fa0c 	bl	d0084d60 <strcmp>
d0080948:	2800      	cmp	r0, #0
d008094a:	f000 8226 	beq.w	d0080d9a <emit_dictionary_word.constprop.0+0x722>
d008094e:	49b6      	ldr	r1, [pc, #728]	; (d0080c28 <emit_dictionary_word.constprop.0+0x5b0>)
d0080950:	4620      	mov	r0, r4
d0080952:	f004 fa05 	bl	d0084d60 <strcmp>
d0080956:	2800      	cmp	r0, #0
d0080958:	f000 849e 	beq.w	d0081298 <emit_dictionary_word.constprop.0+0xc20>
d008095c:	49b3      	ldr	r1, [pc, #716]	; (d0080c2c <emit_dictionary_word.constprop.0+0x5b4>)
d008095e:	4620      	mov	r0, r4
d0080960:	f004 f9fe 	bl	d0084d60 <strcmp>
d0080964:	4607      	mov	r7, r0
d0080966:	2800      	cmp	r0, #0
d0080968:	f000 8613 	beq.w	d0081592 <emit_dictionary_word.constprop.0+0xf1a>
d008096c:	49b0      	ldr	r1, [pc, #704]	; (d0080c30 <emit_dictionary_word.constprop.0+0x5b8>)
d008096e:	4620      	mov	r0, r4
d0080970:	f004 f9f6 	bl	d0084d60 <strcmp>
d0080974:	4607      	mov	r7, r0
d0080976:	2800      	cmp	r0, #0
d0080978:	f000 874e 	beq.w	d0081818 <emit_dictionary_word.constprop.0+0x11a0>
d008097c:	49ad      	ldr	r1, [pc, #692]	; (d0080c34 <emit_dictionary_word.constprop.0+0x5bc>)
d008097e:	4620      	mov	r0, r4
d0080980:	f004 f9ee 	bl	d0084d60 <strcmp>
d0080984:	4607      	mov	r7, r0
d0080986:	2800      	cmp	r0, #0
d0080988:	f000 87af 	beq.w	d00818ea <emit_dictionary_word.constprop.0+0x1272>
d008098c:	49aa      	ldr	r1, [pc, #680]	; (d0080c38 <emit_dictionary_word.constprop.0+0x5c0>)
d008098e:	4620      	mov	r0, r4
d0080990:	f004 f9e6 	bl	d0084d60 <strcmp>
d0080994:	4607      	mov	r7, r0
d0080996:	2800      	cmp	r0, #0
d0080998:	f000 87ba 	beq.w	d0081910 <emit_dictionary_word.constprop.0+0x1298>
d008099c:	49a7      	ldr	r1, [pc, #668]	; (d0080c3c <emit_dictionary_word.constprop.0+0x5c4>)
d008099e:	4620      	mov	r0, r4
d00809a0:	f004 f9de 	bl	d0084d60 <strcmp>
d00809a4:	4607      	mov	r7, r0
d00809a6:	2800      	cmp	r0, #0
d00809a8:	f000 834f 	beq.w	d008104a <emit_dictionary_word.constprop.0+0x9d2>
d00809ac:	49a4      	ldr	r1, [pc, #656]	; (d0080c40 <emit_dictionary_word.constprop.0+0x5c8>)
d00809ae:	4620      	mov	r0, r4
d00809b0:	f004 f9d6 	bl	d0084d60 <strcmp>
d00809b4:	4607      	mov	r7, r0
d00809b6:	2800      	cmp	r0, #0
d00809b8:	f001 802d 	beq.w	d0081a16 <emit_dictionary_word.constprop.0+0x139e>
d00809bc:	49a1      	ldr	r1, [pc, #644]	; (d0080c44 <emit_dictionary_word.constprop.0+0x5cc>)
d00809be:	4620      	mov	r0, r4
d00809c0:	f004 f9ce 	bl	d0084d60 <strcmp>
d00809c4:	4607      	mov	r7, r0
d00809c6:	2800      	cmp	r0, #0
d00809c8:	f001 8041 	beq.w	d0081a4e <emit_dictionary_word.constprop.0+0x13d6>
d00809cc:	499e      	ldr	r1, [pc, #632]	; (d0080c48 <emit_dictionary_word.constprop.0+0x5d0>)
d00809ce:	4620      	mov	r0, r4
d00809d0:	f004 f9c6 	bl	d0084d60 <strcmp>
d00809d4:	2800      	cmp	r0, #0
d00809d6:	f000 87c0 	beq.w	d008195a <emit_dictionary_word.constprop.0+0x12e2>
d00809da:	499c      	ldr	r1, [pc, #624]	; (d0080c4c <emit_dictionary_word.constprop.0+0x5d4>)
d00809dc:	4620      	mov	r0, r4
d00809de:	f004 f9bf 	bl	d0084d60 <strcmp>
d00809e2:	2800      	cmp	r0, #0
d00809e4:	f000 87b9 	beq.w	d008195a <emit_dictionary_word.constprop.0+0x12e2>
d00809e8:	4999      	ldr	r1, [pc, #612]	; (d0080c50 <emit_dictionary_word.constprop.0+0x5d8>)
d00809ea:	4620      	mov	r0, r4
d00809ec:	f004 f9b8 	bl	d0084d60 <strcmp>
d00809f0:	4607      	mov	r7, r0
d00809f2:	2800      	cmp	r0, #0
d00809f4:	f001 813a 	beq.w	d0081c6c <emit_dictionary_word.constprop.0+0x15f4>
d00809f8:	2e69      	cmp	r6, #105	; 0x69
d00809fa:	f040 87dd 	bne.w	d00819b8 <emit_dictionary_word.constprop.0+0x1340>
d00809fe:	7863      	ldrb	r3, [r4, #1]
d0080a00:	2b73      	cmp	r3, #115	; 0x73
d0080a02:	f040 87d9 	bne.w	d00819b8 <emit_dictionary_word.constprop.0+0x1340>
d0080a06:	78a3      	ldrb	r3, [r4, #2]
d0080a08:	2b00      	cmp	r3, #0
d0080a0a:	f040 87d5 	bne.w	d00819b8 <emit_dictionary_word.constprop.0+0x1340>
d0080a0e:	224e      	movs	r2, #78	; 0x4e
d0080a10:	2107      	movs	r1, #7
d0080a12:	4628      	mov	r0, r5
d0080a14:	9301      	str	r3, [sp, #4]
d0080a16:	f7ff fbc1 	bl	d008019c <emit_phone.constprop.0>
d0080a1a:	4628      	mov	r0, r5
d0080a1c:	9b01      	ldr	r3, [sp, #4]
d0080a1e:	223c      	movs	r2, #60	; 0x3c
d0080a20:	2126      	movs	r1, #38	; 0x26
d0080a22:	f7ff fbbb 	bl	d008019c <emit_phone.constprop.0>
d0080a26:	2001      	movs	r0, #1
d0080a28:	e012      	b.n	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0080a2a:	4603      	mov	r3, r0
d0080a2c:	223a      	movs	r2, #58	; 0x3a
d0080a2e:	2113      	movs	r1, #19
d0080a30:	4628      	mov	r0, r5
d0080a32:	f7ff fbb3 	bl	d008019c <emit_phone.constprop.0>
d0080a36:	2301      	movs	r3, #1
d0080a38:	225a      	movs	r2, #90	; 0x5a
d0080a3a:	2107      	movs	r1, #7
d0080a3c:	4628      	mov	r0, r5
d0080a3e:	f7ff fbad 	bl	d008019c <emit_phone.constprop.0>
d0080a42:	4633      	mov	r3, r6
d0080a44:	4628      	mov	r0, r5
d0080a46:	223a      	movs	r2, #58	; 0x3a
d0080a48:	211f      	movs	r1, #31
d0080a4a:	f7ff fba7 	bl	d008019c <emit_phone.constprop.0>
d0080a4e:	2001      	movs	r0, #1
d0080a50:	b002      	add	sp, #8
d0080a52:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0080a56:	78a3      	ldrb	r3, [r4, #2]
d0080a58:	2b00      	cmp	r3, #0
d0080a5a:	f47f aef1 	bne.w	d0080840 <emit_dictionary_word.constprop.0+0x1c8>
d0080a5e:	882b      	ldrh	r3, [r5, #0]
d0080a60:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080a64:	d2f3      	bcs.n	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080a66:	4e7b      	ldr	r6, [pc, #492]	; (d0080c54 <emit_dictionary_word.constprop.0+0x5dc>)
d0080a68:	2002      	movs	r0, #2
d0080a6a:	2273      	movs	r2, #115	; 0x73
d0080a6c:	2101      	movs	r1, #1
d0080a6e:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0080a72:	882b      	ldrh	r3, [r5, #0]
d0080a74:	4c78      	ldr	r4, [pc, #480]	; (d0080c58 <emit_dictionary_word.constprop.0+0x5e0>)
d0080a76:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080a7a:	805a      	strh	r2, [r3, #2]
d0080a7c:	882b      	ldrh	r3, [r5, #0]
d0080a7e:	8822      	ldrh	r2, [r4, #0]
d0080a80:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080a84:	7059      	strb	r1, [r3, #1]
d0080a86:	882b      	ldrh	r3, [r5, #0]
d0080a88:	440b      	add	r3, r1
d0080a8a:	802b      	strh	r3, [r5, #0]
d0080a8c:	2a00      	cmp	r2, #0
d0080a8e:	f000 8182 	beq.w	d0080d96 <emit_dictionary_word.constprop.0+0x71e>
d0080a92:	1c51      	adds	r1, r2, #1
d0080a94:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080a98:	f080 8723 	bcs.w	d00818e2 <emit_dictionary_word.constprop.0+0x126a>
d0080a9c:	4b6f      	ldr	r3, [pc, #444]	; (d0080c5c <emit_dictionary_word.constprop.0+0x5e4>)
d0080a9e:	2020      	movs	r0, #32
d0080aa0:	b289      	uxth	r1, r1
d0080aa2:	5498      	strb	r0, [r3, r2]
d0080aa4:	2000      	movs	r0, #0
d0080aa6:	460a      	mov	r2, r1
d0080aa8:	5458      	strb	r0, [r3, r1]
d0080aaa:	4f6d      	ldr	r7, [pc, #436]	; (d0080c60 <emit_dictionary_word.constprop.0+0x5e8>)
d0080aac:	2041      	movs	r0, #65	; 0x41
d0080aae:	e006      	b.n	d0080abe <emit_dictionary_word.constprop.0+0x446>
d0080ab0:	5498      	strb	r0, [r3, r2]
d0080ab2:	f817 0f01 	ldrb.w	r0, [r7, #1]!
d0080ab6:	2800      	cmp	r0, #0
d0080ab8:	f000 80d4 	beq.w	d0080c64 <emit_dictionary_word.constprop.0+0x5ec>
d0080abc:	460a      	mov	r2, r1
d0080abe:	1c51      	adds	r1, r2, #1
d0080ac0:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080ac4:	b289      	uxth	r1, r1
d0080ac6:	d3f3      	bcc.n	d0080ab0 <emit_dictionary_word.constprop.0+0x438>
d0080ac8:	2100      	movs	r1, #0
d0080aca:	4617      	mov	r7, r2
d0080acc:	8022      	strh	r2, [r4, #0]
d0080ace:	5499      	strb	r1, [r3, r2]
d0080ad0:	e0d6      	b.n	d0080c80 <emit_dictionary_word.constprop.0+0x608>
d0080ad2:	1c72      	adds	r2, r6, #1
d0080ad4:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080ad8:	f080 8554 	bcs.w	d0081584 <emit_dictionary_word.constprop.0+0xf0c>
d0080adc:	4b5f      	ldr	r3, [pc, #380]	; (d0080c5c <emit_dictionary_word.constprop.0+0x5e4>)
d0080ade:	2120      	movs	r1, #32
d0080ae0:	b292      	uxth	r2, r2
d0080ae2:	5599      	strb	r1, [r3, r6]
d0080ae4:	2100      	movs	r1, #0
d0080ae6:	4616      	mov	r6, r2
d0080ae8:	5499      	strb	r1, [r3, r2]
d0080aea:	e5eb      	b.n	d00806c4 <emit_dictionary_word.constprop.0+0x4c>
d0080aec:	1c51      	adds	r1, r2, #1
d0080aee:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080af2:	f080 868a 	bcs.w	d008180a <emit_dictionary_word.constprop.0+0x1192>
d0080af6:	4b59      	ldr	r3, [pc, #356]	; (d0080c5c <emit_dictionary_word.constprop.0+0x5e4>)
d0080af8:	2020      	movs	r0, #32
d0080afa:	b289      	uxth	r1, r1
d0080afc:	5498      	strb	r0, [r3, r2]
d0080afe:	2000      	movs	r0, #0
d0080b00:	460a      	mov	r2, r1
d0080b02:	5458      	strb	r0, [r3, r1]
d0080b04:	e615      	b.n	d0080732 <emit_dictionary_word.constprop.0+0xba>
d0080b06:	460d      	mov	r5, r1
d0080b08:	8021      	strh	r1, [r4, #0]
d0080b0a:	3101      	adds	r1, #1
d0080b0c:	5558      	strb	r0, [r3, r5]
d0080b0e:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080b12:	f4bf ae21 	bcs.w	d0080758 <emit_dictionary_word.constprop.0+0xe0>
d0080b16:	3202      	adds	r2, #2
d0080b18:	2127      	movs	r1, #39	; 0x27
d0080b1a:	b292      	uxth	r2, r2
d0080b1c:	5559      	strb	r1, [r3, r5]
d0080b1e:	8022      	strh	r2, [r4, #0]
d0080b20:	4615      	mov	r5, r2
d0080b22:	e619      	b.n	d0080758 <emit_dictionary_word.constprop.0+0xe0>
d0080b24:	882b      	ldrh	r3, [r5, #0]
d0080b26:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080b2a:	d290      	bcs.n	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080b2c:	4e49      	ldr	r6, [pc, #292]	; (d0080c54 <emit_dictionary_word.constprop.0+0x5dc>)
d0080b2e:	2102      	movs	r1, #2
d0080b30:	2256      	movs	r2, #86	; 0x56
d0080b32:	4c49      	ldr	r4, [pc, #292]	; (d0080c58 <emit_dictionary_word.constprop.0+0x5e0>)
d0080b34:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d0080b38:	882b      	ldrh	r3, [r5, #0]
d0080b3a:	8821      	ldrh	r1, [r4, #0]
d0080b3c:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080b40:	805a      	strh	r2, [r3, #2]
d0080b42:	882b      	ldrh	r3, [r5, #0]
d0080b44:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080b48:	7058      	strb	r0, [r3, #1]
d0080b4a:	882b      	ldrh	r3, [r5, #0]
d0080b4c:	3301      	adds	r3, #1
d0080b4e:	802b      	strh	r3, [r5, #0]
d0080b50:	2900      	cmp	r1, #0
d0080b52:	f000 8278 	beq.w	d0081046 <emit_dictionary_word.constprop.0+0x9ce>
d0080b56:	1c4a      	adds	r2, r1, #1
d0080b58:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080b5c:	f080 86f9 	bcs.w	d0081952 <emit_dictionary_word.constprop.0+0x12da>
d0080b60:	4b3e      	ldr	r3, [pc, #248]	; (d0080c5c <emit_dictionary_word.constprop.0+0x5e4>)
d0080b62:	2720      	movs	r7, #32
d0080b64:	b292      	uxth	r2, r2
d0080b66:	545f      	strb	r7, [r3, r1]
d0080b68:	2700      	movs	r7, #0
d0080b6a:	4611      	mov	r1, r2
d0080b6c:	549f      	strb	r7, [r3, r2]
d0080b6e:	f8df c0f0 	ldr.w	ip, [pc, #240]	; d0080c60 <emit_dictionary_word.constprop.0+0x5e8>
d0080b72:	2741      	movs	r7, #65	; 0x41
d0080b74:	e006      	b.n	d0080b84 <emit_dictionary_word.constprop.0+0x50c>
d0080b76:	545f      	strb	r7, [r3, r1]
d0080b78:	4611      	mov	r1, r2
d0080b7a:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0080b7e:	2f00      	cmp	r7, #0
d0080b80:	f000 8647 	beq.w	d0081812 <emit_dictionary_word.constprop.0+0x119a>
d0080b84:	1c4a      	adds	r2, r1, #1
d0080b86:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080b8a:	b292      	uxth	r2, r2
d0080b8c:	d3f3      	bcc.n	d0080b76 <emit_dictionary_word.constprop.0+0x4fe>
d0080b8e:	8021      	strh	r1, [r4, #0]
d0080b90:	f04f 0c00 	mov.w	ip, #0
d0080b94:	460f      	mov	r7, r1
d0080b96:	f803 c001 	strb.w	ip, [r3, r1]
d0080b9a:	882a      	ldrh	r2, [r5, #0]
d0080b9c:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0080ba0:	f4bf af55 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080ba4:	f04f 081b 	mov.w	r8, #27
d0080ba8:	f04f 0e32 	mov.w	lr, #50	; 0x32
d0080bac:	f806 8022 	strb.w	r8, [r6, r2, lsl #2]
d0080bb0:	882a      	ldrh	r2, [r5, #0]
d0080bb2:	eb06 0282 	add.w	r2, r6, r2, lsl #2
d0080bb6:	f8a2 e002 	strh.w	lr, [r2, #2]
d0080bba:	882a      	ldrh	r2, [r5, #0]
d0080bbc:	eb06 0282 	add.w	r2, r6, r2, lsl #2
d0080bc0:	f882 c001 	strb.w	ip, [r2, #1]
d0080bc4:	882a      	ldrh	r2, [r5, #0]
d0080bc6:	3201      	adds	r2, #1
d0080bc8:	802a      	strh	r2, [r5, #0]
d0080bca:	2900      	cmp	r1, #0
d0080bcc:	f040 827f 	bne.w	d00810ce <emit_dictionary_word.constprop.0+0xa56>
d0080bd0:	2201      	movs	r2, #1
d0080bd2:	b291      	uxth	r1, r2
d0080bd4:	224e      	movs	r2, #78	; 0x4e
d0080bd6:	460f      	mov	r7, r1
d0080bd8:	8021      	strh	r1, [r4, #0]
d0080bda:	541a      	strb	r2, [r3, r0]
d0080bdc:	f04f 0c00 	mov.w	ip, #0
d0080be0:	f803 c001 	strb.w	ip, [r3, r1]
d0080be4:	882a      	ldrh	r2, [r5, #0]
d0080be6:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0080bea:	f4bf af30 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080bee:	f04f 0e12 	mov.w	lr, #18
d0080bf2:	202c      	movs	r0, #44	; 0x2c
d0080bf4:	f806 e022 	strb.w	lr, [r6, r2, lsl #2]
d0080bf8:	882a      	ldrh	r2, [r5, #0]
d0080bfa:	eb06 0282 	add.w	r2, r6, r2, lsl #2
d0080bfe:	8050      	strh	r0, [r2, #2]
d0080c00:	882a      	ldrh	r2, [r5, #0]
d0080c02:	eb06 0682 	add.w	r6, r6, r2, lsl #2
d0080c06:	f886 c001 	strb.w	ip, [r6, #1]
d0080c0a:	882a      	ldrh	r2, [r5, #0]
d0080c0c:	3201      	adds	r2, #1
d0080c0e:	802a      	strh	r2, [r5, #0]
d0080c10:	2900      	cmp	r1, #0
d0080c12:	f040 824a 	bne.w	d00810aa <emit_dictionary_word.constprop.0+0xa32>
d0080c16:	2201      	movs	r2, #1
d0080c18:	b292      	uxth	r2, r2
d0080c1a:	2044      	movs	r0, #68	; 0x44
d0080c1c:	4617      	mov	r7, r2
d0080c1e:	8022      	strh	r2, [r4, #0]
d0080c20:	5458      	strb	r0, [r3, r1]
d0080c22:	e05c      	b.n	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0080c24:	d00859bc 	.word	0xd00859bc
d0080c28:	d00859d0 	.word	0xd00859d0
d0080c2c:	d00859dc 	.word	0xd00859dc
d0080c30:	d00859ec 	.word	0xd00859ec
d0080c34:	d00859f4 	.word	0xd00859f4
d0080c38:	d00859fc 	.word	0xd00859fc
d0080c3c:	d0085a04 	.word	0xd0085a04
d0080c40:	d0085a0c 	.word	0xd0085a0c
d0080c44:	d0085a14 	.word	0xd0085a14
d0080c48:	d0085a1c 	.word	0xd0085a1c
d0080c4c:	d0085a24 	.word	0xd0085a24
d0080c50:	d0085a2c 	.word	0xd0085a2c
d0080c54:	d0086188 	.word	0xd0086188
d0080c58:	d0087588 	.word	0xd0087588
d0080c5c:	d0086d88 	.word	0xd0086d88
d0080c60:	d00859a8 	.word	0xd00859a8
d0080c64:	460f      	mov	r7, r1
d0080c66:	8021      	strh	r1, [r4, #0]
d0080c68:	3101      	adds	r1, #1
d0080c6a:	55d8      	strb	r0, [r3, r7]
d0080c6c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080c70:	f081 821e 	bcs.w	d00820b0 <emit_dictionary_word.constprop.0+0x1a38>
d0080c74:	3202      	adds	r2, #2
d0080c76:	2127      	movs	r1, #39	; 0x27
d0080c78:	b292      	uxth	r2, r2
d0080c7a:	55d9      	strb	r1, [r3, r7]
d0080c7c:	4617      	mov	r7, r2
d0080c7e:	8022      	strh	r2, [r4, #0]
d0080c80:	2000      	movs	r0, #0
d0080c82:	55d8      	strb	r0, [r3, r7]
d0080c84:	8829      	ldrh	r1, [r5, #0]
d0080c86:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080c8a:	f4bf aee0 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080c8e:	f04f 0e1a 	mov.w	lr, #26
d0080c92:	f04f 0c46 	mov.w	ip, #70	; 0x46
d0080c96:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d0080c9a:	8829      	ldrh	r1, [r5, #0]
d0080c9c:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080ca0:	f8a1 c002 	strh.w	ip, [r1, #2]
d0080ca4:	8829      	ldrh	r1, [r5, #0]
d0080ca6:	eb06 0681 	add.w	r6, r6, r1, lsl #2
d0080caa:	7070      	strb	r0, [r6, #1]
d0080cac:	8829      	ldrh	r1, [r5, #0]
d0080cae:	3101      	adds	r1, #1
d0080cb0:	8029      	strh	r1, [r5, #0]
d0080cb2:	2a00      	cmp	r2, #0
d0080cb4:	d06d      	beq.n	d0080d92 <emit_dictionary_word.constprop.0+0x71a>
d0080cb6:	3201      	adds	r2, #1
d0080cb8:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0080cbc:	f080 86c4 	bcs.w	d0081a48 <emit_dictionary_word.constprop.0+0x13d0>
d0080cc0:	b292      	uxth	r2, r2
d0080cc2:	2120      	movs	r1, #32
d0080cc4:	55d9      	strb	r1, [r3, r7]
d0080cc6:	1c51      	adds	r1, r2, #1
d0080cc8:	4617      	mov	r7, r2
d0080cca:	8022      	strh	r2, [r4, #0]
d0080ccc:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080cd0:	5498      	strb	r0, [r3, r2]
d0080cd2:	d204      	bcs.n	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0080cd4:	b289      	uxth	r1, r1
d0080cd6:	224d      	movs	r2, #77	; 0x4d
d0080cd8:	55da      	strb	r2, [r3, r7]
d0080cda:	460f      	mov	r7, r1
d0080cdc:	8021      	strh	r1, [r4, #0]
d0080cde:	2200      	movs	r2, #0
d0080ce0:	2001      	movs	r0, #1
d0080ce2:	55da      	strb	r2, [r3, r7]
d0080ce4:	b002      	add	sp, #8
d0080ce6:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0080cea:	882b      	ldrh	r3, [r5, #0]
d0080cec:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080cf0:	f4bf aead 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080cf4:	4ec3      	ldr	r6, [pc, #780]	; (d0081004 <emit_dictionary_word.constprop.0+0x98c>)
d0080cf6:	2003      	movs	r0, #3
d0080cf8:	2278      	movs	r2, #120	; 0x78
d0080cfa:	2101      	movs	r1, #1
d0080cfc:	f806 0023 	strb.w	r0, [r6, r3, lsl #2]
d0080d00:	882b      	ldrh	r3, [r5, #0]
d0080d02:	4cc1      	ldr	r4, [pc, #772]	; (d0081008 <emit_dictionary_word.constprop.0+0x990>)
d0080d04:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080d08:	805a      	strh	r2, [r3, #2]
d0080d0a:	882b      	ldrh	r3, [r5, #0]
d0080d0c:	8822      	ldrh	r2, [r4, #0]
d0080d0e:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080d12:	7059      	strb	r1, [r3, #1]
d0080d14:	882b      	ldrh	r3, [r5, #0]
d0080d16:	440b      	add	r3, r1
d0080d18:	802b      	strh	r3, [r5, #0]
d0080d1a:	2a00      	cmp	r2, #0
d0080d1c:	f040 81ea 	bne.w	d00810f4 <emit_dictionary_word.constprop.0+0xa7c>
d0080d20:	4bba      	ldr	r3, [pc, #744]	; (d008100c <emit_dictionary_word.constprop.0+0x994>)
d0080d22:	4fbb      	ldr	r7, [pc, #748]	; (d0081010 <emit_dictionary_word.constprop.0+0x998>)
d0080d24:	2041      	movs	r0, #65	; 0x41
d0080d26:	e006      	b.n	d0080d36 <emit_dictionary_word.constprop.0+0x6be>
d0080d28:	5498      	strb	r0, [r3, r2]
d0080d2a:	f817 0f01 	ldrb.w	r0, [r7, #1]!
d0080d2e:	2800      	cmp	r0, #0
d0080d30:	f000 82a3 	beq.w	d008127a <emit_dictionary_word.constprop.0+0xc02>
d0080d34:	460a      	mov	r2, r1
d0080d36:	1c51      	adds	r1, r2, #1
d0080d38:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080d3c:	b289      	uxth	r1, r1
d0080d3e:	d3f3      	bcc.n	d0080d28 <emit_dictionary_word.constprop.0+0x6b0>
d0080d40:	2100      	movs	r1, #0
d0080d42:	4617      	mov	r7, r2
d0080d44:	8022      	strh	r2, [r4, #0]
d0080d46:	5499      	strb	r1, [r3, r2]
d0080d48:	2000      	movs	r0, #0
d0080d4a:	55d8      	strb	r0, [r3, r7]
d0080d4c:	8829      	ldrh	r1, [r5, #0]
d0080d4e:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080d52:	f4bf ae7c 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080d56:	f04f 0e1e 	mov.w	lr, #30
d0080d5a:	f04f 0c46 	mov.w	ip, #70	; 0x46
d0080d5e:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d0080d62:	8829      	ldrh	r1, [r5, #0]
d0080d64:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080d68:	f8a1 c002 	strh.w	ip, [r1, #2]
d0080d6c:	8829      	ldrh	r1, [r5, #0]
d0080d6e:	eb06 0681 	add.w	r6, r6, r1, lsl #2
d0080d72:	7070      	strb	r0, [r6, #1]
d0080d74:	8829      	ldrh	r1, [r5, #0]
d0080d76:	3101      	adds	r1, #1
d0080d78:	8029      	strh	r1, [r5, #0]
d0080d7a:	2a00      	cmp	r2, #0
d0080d7c:	f040 81c7 	bne.w	d008110e <emit_dictionary_word.constprop.0+0xa96>
d0080d80:	2101      	movs	r1, #1
d0080d82:	b289      	uxth	r1, r1
d0080d84:	2252      	movs	r2, #82	; 0x52
d0080d86:	8021      	strh	r1, [r4, #0]
d0080d88:	55da      	strb	r2, [r3, r7]
d0080d8a:	460f      	mov	r7, r1
d0080d8c:	e7a7      	b.n	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0080d8e:	8022      	strh	r2, [r4, #0]
d0080d90:	e4a8      	b.n	d00806e4 <emit_dictionary_word.constprop.0+0x6c>
d0080d92:	2101      	movs	r1, #1
d0080d94:	e79e      	b.n	d0080cd4 <emit_dictionary_word.constprop.0+0x65c>
d0080d96:	4b9d      	ldr	r3, [pc, #628]	; (d008100c <emit_dictionary_word.constprop.0+0x994>)
d0080d98:	e687      	b.n	d0080aaa <emit_dictionary_word.constprop.0+0x432>
d0080d9a:	882b      	ldrh	r3, [r5, #0]
d0080d9c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0080da0:	f4bf ae55 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080da4:	4e97      	ldr	r6, [pc, #604]	; (d0081004 <emit_dictionary_word.constprop.0+0x98c>)
d0080da6:	2118      	movs	r1, #24
d0080da8:	223e      	movs	r2, #62	; 0x3e
d0080daa:	4c97      	ldr	r4, [pc, #604]	; (d0081008 <emit_dictionary_word.constprop.0+0x990>)
d0080dac:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d0080db0:	882b      	ldrh	r3, [r5, #0]
d0080db2:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080db6:	805a      	strh	r2, [r3, #2]
d0080db8:	882b      	ldrh	r3, [r5, #0]
d0080dba:	8822      	ldrh	r2, [r4, #0]
d0080dbc:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d0080dc0:	7058      	strb	r0, [r3, #1]
d0080dc2:	882b      	ldrh	r3, [r5, #0]
d0080dc4:	3301      	adds	r3, #1
d0080dc6:	802b      	strh	r3, [r5, #0]
d0080dc8:	2a00      	cmp	r2, #0
d0080dca:	f040 822f 	bne.w	d008122c <emit_dictionary_word.constprop.0+0xbb4>
d0080dce:	4607      	mov	r7, r0
d0080dd0:	4b8e      	ldr	r3, [pc, #568]	; (d008100c <emit_dictionary_word.constprop.0+0x994>)
d0080dd2:	2201      	movs	r2, #1
d0080dd4:	b292      	uxth	r2, r2
d0080dd6:	214b      	movs	r1, #75	; 0x4b
d0080dd8:	55d9      	strb	r1, [r3, r7]
d0080dda:	4617      	mov	r7, r2
d0080ddc:	8022      	strh	r2, [r4, #0]
d0080dde:	f04f 0e00 	mov.w	lr, #0
d0080de2:	f803 e007 	strb.w	lr, [r3, r7]
d0080de6:	f8b5 c000 	ldrh.w	ip, [r5]
d0080dea:	f5bc 7f40 	cmp.w	ip, #768	; 0x300
d0080dee:	f4bf ae2e 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080df2:	2101      	movs	r1, #1
d0080df4:	f04f 084a 	mov.w	r8, #74	; 0x4a
d0080df8:	f806 102c 	strb.w	r1, [r6, ip, lsl #2]
d0080dfc:	f8b5 c000 	ldrh.w	ip, [r5]
d0080e00:	eb06 0c8c 	add.w	ip, r6, ip, lsl #2
d0080e04:	f8ac 8002 	strh.w	r8, [ip, #2]
d0080e08:	f8b5 c000 	ldrh.w	ip, [r5]
d0080e0c:	eb06 0c8c 	add.w	ip, r6, ip, lsl #2
d0080e10:	f88c e001 	strb.w	lr, [ip, #1]
d0080e14:	f8b5 c000 	ldrh.w	ip, [r5]
d0080e18:	448c      	add	ip, r1
d0080e1a:	f8a5 c000 	strh.w	ip, [r5]
d0080e1e:	2a00      	cmp	r2, #0
d0080e20:	f040 81d1 	bne.w	d00811c6 <emit_dictionary_word.constprop.0+0xb4e>
d0080e24:	f8df e1f4 	ldr.w	lr, [pc, #500]	; d008101c <emit_dictionary_word.constprop.0+0x9a4>
d0080e28:	2741      	movs	r7, #65	; 0x41
d0080e2a:	e007      	b.n	d0080e3c <emit_dictionary_word.constprop.0+0x7c4>
d0080e2c:	549f      	strb	r7, [r3, r2]
d0080e2e:	4662      	mov	r2, ip
d0080e30:	f81e 7f01 	ldrb.w	r7, [lr, #1]!
d0080e34:	1c51      	adds	r1, r2, #1
d0080e36:	2f00      	cmp	r7, #0
d0080e38:	f000 85b0 	beq.w	d008199c <emit_dictionary_word.constprop.0+0x1324>
d0080e3c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080e40:	fa1f fc81 	uxth.w	ip, r1
d0080e44:	d3f2      	bcc.n	d0080e2c <emit_dictionary_word.constprop.0+0x7b4>
d0080e46:	8022      	strh	r2, [r4, #0]
d0080e48:	f04f 0c00 	mov.w	ip, #0
d0080e4c:	4617      	mov	r7, r2
d0080e4e:	f803 c002 	strb.w	ip, [r3, r2]
d0080e52:	8829      	ldrh	r1, [r5, #0]
d0080e54:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080e58:	f4bf adf9 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080e5c:	f04f 081a 	mov.w	r8, #26
d0080e60:	f04f 0e3c 	mov.w	lr, #60	; 0x3c
d0080e64:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d0080e68:	8829      	ldrh	r1, [r5, #0]
d0080e6a:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080e6e:	f8a1 e002 	strh.w	lr, [r1, #2]
d0080e72:	8829      	ldrh	r1, [r5, #0]
d0080e74:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080e78:	f881 c001 	strb.w	ip, [r1, #1]
d0080e7c:	8829      	ldrh	r1, [r5, #0]
d0080e7e:	3101      	adds	r1, #1
d0080e80:	8029      	strh	r1, [r5, #0]
d0080e82:	2a00      	cmp	r2, #0
d0080e84:	f040 81bf 	bne.w	d0081206 <emit_dictionary_word.constprop.0+0xb8e>
d0080e88:	2101      	movs	r1, #1
d0080e8a:	b28a      	uxth	r2, r1
d0080e8c:	214d      	movs	r1, #77	; 0x4d
d0080e8e:	4617      	mov	r7, r2
d0080e90:	8022      	strh	r2, [r4, #0]
d0080e92:	5419      	strb	r1, [r3, r0]
d0080e94:	f04f 0c00 	mov.w	ip, #0
d0080e98:	f803 c002 	strb.w	ip, [r3, r2]
d0080e9c:	8829      	ldrh	r1, [r5, #0]
d0080e9e:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080ea2:	f4bf add4 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080ea6:	f04f 0e1d 	mov.w	lr, #29
d0080eaa:	203a      	movs	r0, #58	; 0x3a
d0080eac:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d0080eb0:	8829      	ldrh	r1, [r5, #0]
d0080eb2:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080eb6:	8048      	strh	r0, [r1, #2]
d0080eb8:	8829      	ldrh	r1, [r5, #0]
d0080eba:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080ebe:	f881 c001 	strb.w	ip, [r1, #1]
d0080ec2:	8829      	ldrh	r1, [r5, #0]
d0080ec4:	3101      	adds	r1, #1
d0080ec6:	8029      	strh	r1, [r5, #0]
d0080ec8:	2a00      	cmp	r2, #0
d0080eca:	f040 818a 	bne.w	d00811e2 <emit_dictionary_word.constprop.0+0xb6a>
d0080ece:	2101      	movs	r1, #1
d0080ed0:	b28a      	uxth	r2, r1
d0080ed2:	2150      	movs	r1, #80	; 0x50
d0080ed4:	55d9      	strb	r1, [r3, r7]
d0080ed6:	4617      	mov	r7, r2
d0080ed8:	8022      	strh	r2, [r4, #0]
d0080eda:	f04f 0c00 	mov.w	ip, #0
d0080ede:	f803 c002 	strb.w	ip, [r3, r2]
d0080ee2:	8829      	ldrh	r1, [r5, #0]
d0080ee4:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080ee8:	f4bf adb1 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080eec:	f04f 0e25 	mov.w	lr, #37	; 0x25
d0080ef0:	202e      	movs	r0, #46	; 0x2e
d0080ef2:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d0080ef6:	8829      	ldrh	r1, [r5, #0]
d0080ef8:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080efc:	8048      	strh	r0, [r1, #2]
d0080efe:	8829      	ldrh	r1, [r5, #0]
d0080f00:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080f04:	f881 c001 	strb.w	ip, [r1, #1]
d0080f08:	8829      	ldrh	r1, [r5, #0]
d0080f0a:	3101      	adds	r1, #1
d0080f0c:	8029      	strh	r1, [r5, #0]
d0080f0e:	2a00      	cmp	r2, #0
d0080f10:	f040 81a1 	bne.w	d0081256 <emit_dictionary_word.constprop.0+0xbde>
d0080f14:	2101      	movs	r1, #1
d0080f16:	b28a      	uxth	r2, r1
d0080f18:	2159      	movs	r1, #89	; 0x59
d0080f1a:	55d9      	strb	r1, [r3, r7]
d0080f1c:	4617      	mov	r7, r2
d0080f1e:	8022      	strh	r2, [r4, #0]
d0080f20:	2100      	movs	r1, #0
d0080f22:	5499      	strb	r1, [r3, r2]
d0080f24:	8829      	ldrh	r1, [r5, #0]
d0080f26:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080f2a:	f4bf ad90 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080f2e:	200a      	movs	r0, #10
d0080f30:	f04f 0c5f 	mov.w	ip, #95	; 0x5f
d0080f34:	f806 0021 	strb.w	r0, [r6, r1, lsl #2]
d0080f38:	2101      	movs	r1, #1
d0080f3a:	8828      	ldrh	r0, [r5, #0]
d0080f3c:	eb06 0080 	add.w	r0, r6, r0, lsl #2
d0080f40:	f8a0 c002 	strh.w	ip, [r0, #2]
d0080f44:	8828      	ldrh	r0, [r5, #0]
d0080f46:	eb06 0080 	add.w	r0, r6, r0, lsl #2
d0080f4a:	7041      	strb	r1, [r0, #1]
d0080f4c:	8828      	ldrh	r0, [r5, #0]
d0080f4e:	4408      	add	r0, r1
d0080f50:	8028      	strh	r0, [r5, #0]
d0080f52:	2a00      	cmp	r2, #0
d0080f54:	f040 810e 	bne.w	d0081174 <emit_dictionary_word.constprop.0+0xafc>
d0080f58:	482e      	ldr	r0, [pc, #184]	; (d0081014 <emit_dictionary_word.constprop.0+0x99c>)
d0080f5a:	2755      	movs	r7, #85	; 0x55
d0080f5c:	e007      	b.n	d0080f6e <emit_dictionary_word.constprop.0+0x8f6>
d0080f5e:	549f      	strb	r7, [r3, r2]
d0080f60:	f810 7f01 	ldrb.w	r7, [r0, #1]!
d0080f64:	2f00      	cmp	r7, #0
d0080f66:	f000 8440 	beq.w	d00817ea <emit_dictionary_word.constprop.0+0x1172>
d0080f6a:	460a      	mov	r2, r1
d0080f6c:	3101      	adds	r1, #1
d0080f6e:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0080f72:	b289      	uxth	r1, r1
d0080f74:	d3f3      	bcc.n	d0080f5e <emit_dictionary_word.constprop.0+0x8e6>
d0080f76:	2100      	movs	r1, #0
d0080f78:	4610      	mov	r0, r2
d0080f7a:	8022      	strh	r2, [r4, #0]
d0080f7c:	5499      	strb	r1, [r3, r2]
d0080f7e:	f04f 0c00 	mov.w	ip, #0
d0080f82:	f803 c000 	strb.w	ip, [r3, r0]
d0080f86:	8829      	ldrh	r1, [r5, #0]
d0080f88:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080f8c:	f4bf ad5f 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080f90:	f04f 0e21 	mov.w	lr, #33	; 0x21
d0080f94:	272a      	movs	r7, #42	; 0x2a
d0080f96:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d0080f9a:	8829      	ldrh	r1, [r5, #0]
d0080f9c:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080fa0:	804f      	strh	r7, [r1, #2]
d0080fa2:	8829      	ldrh	r1, [r5, #0]
d0080fa4:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080fa8:	f881 c001 	strb.w	ip, [r1, #1]
d0080fac:	8829      	ldrh	r1, [r5, #0]
d0080fae:	3101      	adds	r1, #1
d0080fb0:	8029      	strh	r1, [r5, #0]
d0080fb2:	2a00      	cmp	r2, #0
d0080fb4:	f040 80f5 	bne.w	d00811a2 <emit_dictionary_word.constprop.0+0xb2a>
d0080fb8:	2101      	movs	r1, #1
d0080fba:	b28a      	uxth	r2, r1
d0080fbc:	2154      	movs	r1, #84	; 0x54
d0080fbe:	5419      	strb	r1, [r3, r0]
d0080fc0:	4610      	mov	r0, r2
d0080fc2:	8022      	strh	r2, [r4, #0]
d0080fc4:	2700      	movs	r7, #0
d0080fc6:	541f      	strb	r7, [r3, r0]
d0080fc8:	8829      	ldrh	r1, [r5, #0]
d0080fca:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0080fce:	f4bf ad3e 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0080fd2:	f04f 0e06 	mov.w	lr, #6
d0080fd6:	f04f 0c76 	mov.w	ip, #118	; 0x76
d0080fda:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d0080fde:	8829      	ldrh	r1, [r5, #0]
d0080fe0:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0080fe4:	f8a1 c002 	strh.w	ip, [r1, #2]
d0080fe8:	8829      	ldrh	r1, [r5, #0]
d0080fea:	eb06 0681 	add.w	r6, r6, r1, lsl #2
d0080fee:	7077      	strb	r7, [r6, #1]
d0080ff0:	8829      	ldrh	r1, [r5, #0]
d0080ff2:	3101      	adds	r1, #1
d0080ff4:	8029      	strh	r1, [r5, #0]
d0080ff6:	2a00      	cmp	r2, #0
d0080ff8:	f040 80c7 	bne.w	d008118a <emit_dictionary_word.constprop.0+0xb12>
d0080ffc:	2101      	movs	r1, #1
d0080ffe:	4e06      	ldr	r6, [pc, #24]	; (d0081018 <emit_dictionary_word.constprop.0+0x9a0>)
d0081000:	2045      	movs	r0, #69	; 0x45
d0081002:	e015      	b.n	d0081030 <emit_dictionary_word.constprop.0+0x9b8>
d0081004:	d0086188 	.word	0xd0086188
d0081008:	d0087588 	.word	0xd0087588
d008100c:	d0086d88 	.word	0xd0086d88
d0081010:	d00859b4 	.word	0xd00859b4
d0081014:	d00859c8 	.word	0xd00859c8
d0081018:	d00859cc 	.word	0xd00859cc
d008101c:	d00859a0 	.word	0xd00859a0
d0081020:	5498      	strb	r0, [r3, r2]
d0081022:	1c69      	adds	r1, r5, #1
d0081024:	f816 0f01 	ldrb.w	r0, [r6, #1]!
d0081028:	462a      	mov	r2, r5
d008102a:	2800      	cmp	r0, #0
d008102c:	f000 8456 	beq.w	d00818dc <emit_dictionary_word.constprop.0+0x1264>
d0081030:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081034:	b28d      	uxth	r5, r1
d0081036:	d3f3      	bcc.n	d0081020 <emit_dictionary_word.constprop.0+0x9a8>
d0081038:	8022      	strh	r2, [r4, #0]
d008103a:	2100      	movs	r1, #0
d008103c:	2001      	movs	r0, #1
d008103e:	5499      	strb	r1, [r3, r2]
d0081040:	e506      	b.n	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081042:	4bb8      	ldr	r3, [pc, #736]	; (d0081324 <emit_dictionary_word.constprop.0+0xcac>)
d0081044:	e42e      	b.n	d00808a4 <emit_dictionary_word.constprop.0+0x22c>
d0081046:	4bb7      	ldr	r3, [pc, #732]	; (d0081324 <emit_dictionary_word.constprop.0+0xcac>)
d0081048:	e591      	b.n	d0080b6e <emit_dictionary_word.constprop.0+0x4f6>
d008104a:	4603      	mov	r3, r0
d008104c:	223c      	movs	r2, #60	; 0x3c
d008104e:	2114      	movs	r1, #20
d0081050:	4628      	mov	r0, r5
d0081052:	f7ff f8a3 	bl	d008019c <emit_phone.constprop.0>
d0081056:	2301      	movs	r3, #1
d0081058:	2248      	movs	r2, #72	; 0x48
d008105a:	210c      	movs	r1, #12
d008105c:	4628      	mov	r0, r5
d008105e:	f7ff f89d 	bl	d008019c <emit_phone.constprop.0>
d0081062:	463b      	mov	r3, r7
d0081064:	223c      	movs	r2, #60	; 0x3c
d0081066:	2108      	movs	r1, #8
d0081068:	4628      	mov	r0, r5
d008106a:	f7ff f897 	bl	d008019c <emit_phone.constprop.0>
d008106e:	4628      	mov	r0, r5
d0081070:	463b      	mov	r3, r7
d0081072:	223a      	movs	r2, #58	; 0x3a
d0081074:	2123      	movs	r1, #35	; 0x23
d0081076:	f7ff f891 	bl	d008019c <emit_phone.constprop.0>
d008107a:	2001      	movs	r0, #1
d008107c:	e4e8      	b.n	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008107e:	1c4a      	adds	r2, r1, #1
d0081080:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0081084:	f080 8514 	bcs.w	d0081ab0 <emit_dictionary_word.constprop.0+0x1438>
d0081088:	fa1f fc82 	uxth.w	ip, r2
d008108c:	2020      	movs	r0, #32
d008108e:	f10c 0201 	add.w	r2, ip, #1
d0081092:	5458      	strb	r0, [r3, r1]
d0081094:	4667      	mov	r7, ip
d0081096:	f8a4 c000 	strh.w	ip, [r4]
d008109a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008109e:	f803 e00c 	strb.w	lr, [r3, ip]
d00810a2:	f4ff ac32 	bcc.w	d008090a <emit_dictionary_word.constprop.0+0x292>
d00810a6:	4661      	mov	r1, ip
d00810a8:	e434      	b.n	d0080914 <emit_dictionary_word.constprop.0+0x29c>
d00810aa:	1c4a      	adds	r2, r1, #1
d00810ac:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00810b0:	f080 85d4 	bcs.w	d0081c5c <emit_dictionary_word.constprop.0+0x15e4>
d00810b4:	b291      	uxth	r1, r2
d00810b6:	2020      	movs	r0, #32
d00810b8:	1c4a      	adds	r2, r1, #1
d00810ba:	55d8      	strb	r0, [r3, r7]
d00810bc:	8021      	strh	r1, [r4, #0]
d00810be:	460f      	mov	r7, r1
d00810c0:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00810c4:	f803 c001 	strb.w	ip, [r3, r1]
d00810c8:	f4ff ada6 	bcc.w	d0080c18 <emit_dictionary_word.constprop.0+0x5a0>
d00810cc:	e607      	b.n	d0080cde <emit_dictionary_word.constprop.0+0x666>
d00810ce:	1c4a      	adds	r2, r1, #1
d00810d0:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00810d4:	f080 85c6 	bcs.w	d0081c64 <emit_dictionary_word.constprop.0+0x15ec>
d00810d8:	b291      	uxth	r1, r2
d00810da:	2020      	movs	r0, #32
d00810dc:	1c4a      	adds	r2, r1, #1
d00810de:	55d8      	strb	r0, [r3, r7]
d00810e0:	8021      	strh	r1, [r4, #0]
d00810e2:	4608      	mov	r0, r1
d00810e4:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00810e8:	f803 c001 	strb.w	ip, [r3, r1]
d00810ec:	f4ff ad71 	bcc.w	d0080bd2 <emit_dictionary_word.constprop.0+0x55a>
d00810f0:	460f      	mov	r7, r1
d00810f2:	e573      	b.n	d0080bdc <emit_dictionary_word.constprop.0+0x564>
d00810f4:	1c51      	adds	r1, r2, #1
d00810f6:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00810fa:	f080 8453 	bcs.w	d00819a4 <emit_dictionary_word.constprop.0+0x132c>
d00810fe:	4b89      	ldr	r3, [pc, #548]	; (d0081324 <emit_dictionary_word.constprop.0+0xcac>)
d0081100:	2020      	movs	r0, #32
d0081102:	b289      	uxth	r1, r1
d0081104:	5498      	strb	r0, [r3, r2]
d0081106:	2000      	movs	r0, #0
d0081108:	460a      	mov	r2, r1
d008110a:	5458      	strb	r0, [r3, r1]
d008110c:	e609      	b.n	d0080d22 <emit_dictionary_word.constprop.0+0x6aa>
d008110e:	3201      	adds	r2, #1
d0081110:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0081114:	f080 8498 	bcs.w	d0081a48 <emit_dictionary_word.constprop.0+0x13d0>
d0081118:	b292      	uxth	r2, r2
d008111a:	2120      	movs	r1, #32
d008111c:	55d9      	strb	r1, [r3, r7]
d008111e:	1c51      	adds	r1, r2, #1
d0081120:	4617      	mov	r7, r2
d0081122:	8022      	strh	r2, [r4, #0]
d0081124:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081128:	5498      	strb	r0, [r3, r2]
d008112a:	f4ff ae2a 	bcc.w	d0080d82 <emit_dictionary_word.constprop.0+0x70a>
d008112e:	e5d6      	b.n	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0081130:	1c51      	adds	r1, r2, #1
d0081132:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081136:	d204      	bcs.n	d0081142 <emit_dictionary_word.constprop.0+0xaca>
d0081138:	b28a      	uxth	r2, r1
d008113a:	2120      	movs	r1, #32
d008113c:	5419      	strb	r1, [r3, r0]
d008113e:	1c51      	adds	r1, r2, #1
d0081140:	4610      	mov	r0, r2
d0081142:	2500      	movs	r5, #0
d0081144:	541d      	strb	r5, [r3, r0]
d0081146:	f7ff bb67 	b.w	d0080818 <emit_dictionary_word.constprop.0+0x1a0>
d008114a:	1c51      	adds	r1, r2, #1
d008114c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081150:	f080 85a7 	bcs.w	d0081ca2 <emit_dictionary_word.constprop.0+0x162a>
d0081154:	b289      	uxth	r1, r1
d0081156:	4b73      	ldr	r3, [pc, #460]	; (d0081324 <emit_dictionary_word.constprop.0+0xcac>)
d0081158:	2720      	movs	r7, #32
d008115a:	4608      	mov	r0, r1
d008115c:	8021      	strh	r1, [r4, #0]
d008115e:	549f      	strb	r7, [r3, r2]
d0081160:	1c4a      	adds	r2, r1, #1
d0081162:	f803 c001 	strb.w	ip, [r3, r1]
d0081166:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008116a:	f4ff ab34 	bcc.w	d00807d6 <emit_dictionary_word.constprop.0+0x15e>
d008116e:	460a      	mov	r2, r1
d0081170:	f7ff bb36 	b.w	d00807e0 <emit_dictionary_word.constprop.0+0x168>
d0081174:	1c51      	adds	r1, r2, #1
d0081176:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008117a:	d203      	bcs.n	d0081184 <emit_dictionary_word.constprop.0+0xb0c>
d008117c:	b28a      	uxth	r2, r1
d008117e:	2020      	movs	r0, #32
d0081180:	1c51      	adds	r1, r2, #1
d0081182:	55d8      	strb	r0, [r3, r7]
d0081184:	2000      	movs	r0, #0
d0081186:	5498      	strb	r0, [r3, r2]
d0081188:	e6e6      	b.n	d0080f58 <emit_dictionary_word.constprop.0+0x8e0>
d008118a:	1c51      	adds	r1, r2, #1
d008118c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081190:	d204      	bcs.n	d008119c <emit_dictionary_word.constprop.0+0xb24>
d0081192:	b28a      	uxth	r2, r1
d0081194:	2120      	movs	r1, #32
d0081196:	5419      	strb	r1, [r3, r0]
d0081198:	1c51      	adds	r1, r2, #1
d008119a:	4610      	mov	r0, r2
d008119c:	2500      	movs	r5, #0
d008119e:	541d      	strb	r5, [r3, r0]
d00811a0:	e72d      	b.n	d0080ffe <emit_dictionary_word.constprop.0+0x986>
d00811a2:	1c51      	adds	r1, r2, #1
d00811a4:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00811a8:	f080 85e4 	bcs.w	d0081d74 <emit_dictionary_word.constprop.0+0x16fc>
d00811ac:	b28a      	uxth	r2, r1
d00811ae:	2720      	movs	r7, #32
d00811b0:	1c51      	adds	r1, r2, #1
d00811b2:	541f      	strb	r7, [r3, r0]
d00811b4:	8022      	strh	r2, [r4, #0]
d00811b6:	4610      	mov	r0, r2
d00811b8:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00811bc:	f803 c002 	strb.w	ip, [r3, r2]
d00811c0:	f4ff aefb 	bcc.w	d0080fba <emit_dictionary_word.constprop.0+0x942>
d00811c4:	e6fe      	b.n	d0080fc4 <emit_dictionary_word.constprop.0+0x94c>
d00811c6:	1c51      	adds	r1, r2, #1
d00811c8:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00811cc:	d204      	bcs.n	d00811d8 <emit_dictionary_word.constprop.0+0xb60>
d00811ce:	b28a      	uxth	r2, r1
d00811d0:	2120      	movs	r1, #32
d00811d2:	55d9      	strb	r1, [r3, r7]
d00811d4:	1c51      	adds	r1, r2, #1
d00811d6:	4617      	mov	r7, r2
d00811d8:	f04f 0c00 	mov.w	ip, #0
d00811dc:	f803 c007 	strb.w	ip, [r3, r7]
d00811e0:	e620      	b.n	d0080e24 <emit_dictionary_word.constprop.0+0x7ac>
d00811e2:	1c51      	adds	r1, r2, #1
d00811e4:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00811e8:	f080 85cc 	bcs.w	d0081d84 <emit_dictionary_word.constprop.0+0x170c>
d00811ec:	b28a      	uxth	r2, r1
d00811ee:	2020      	movs	r0, #32
d00811f0:	1c51      	adds	r1, r2, #1
d00811f2:	55d8      	strb	r0, [r3, r7]
d00811f4:	8022      	strh	r2, [r4, #0]
d00811f6:	4617      	mov	r7, r2
d00811f8:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00811fc:	f803 c002 	strb.w	ip, [r3, r2]
d0081200:	f4ff ae66 	bcc.w	d0080ed0 <emit_dictionary_word.constprop.0+0x858>
d0081204:	e669      	b.n	d0080eda <emit_dictionary_word.constprop.0+0x862>
d0081206:	1c51      	adds	r1, r2, #1
d0081208:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008120c:	f080 85b6 	bcs.w	d0081d7c <emit_dictionary_word.constprop.0+0x1704>
d0081210:	b28a      	uxth	r2, r1
d0081212:	2020      	movs	r0, #32
d0081214:	1c51      	adds	r1, r2, #1
d0081216:	55d8      	strb	r0, [r3, r7]
d0081218:	8022      	strh	r2, [r4, #0]
d008121a:	4610      	mov	r0, r2
d008121c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081220:	f803 c002 	strb.w	ip, [r3, r2]
d0081224:	f4ff ae31 	bcc.w	d0080e8a <emit_dictionary_word.constprop.0+0x812>
d0081228:	4617      	mov	r7, r2
d008122a:	e633      	b.n	d0080e94 <emit_dictionary_word.constprop.0+0x81c>
d008122c:	1c51      	adds	r1, r2, #1
d008122e:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081232:	f080 856f 	bcs.w	d0081d14 <emit_dictionary_word.constprop.0+0x169c>
d0081236:	b289      	uxth	r1, r1
d0081238:	4b3a      	ldr	r3, [pc, #232]	; (d0081324 <emit_dictionary_word.constprop.0+0xcac>)
d008123a:	f04f 0c20 	mov.w	ip, #32
d008123e:	460f      	mov	r7, r1
d0081240:	8021      	strh	r1, [r4, #0]
d0081242:	f803 c002 	strb.w	ip, [r3, r2]
d0081246:	1c4a      	adds	r2, r1, #1
d0081248:	5458      	strb	r0, [r3, r1]
d008124a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008124e:	f4ff adc1 	bcc.w	d0080dd4 <emit_dictionary_word.constprop.0+0x75c>
d0081252:	460a      	mov	r2, r1
d0081254:	e5c3      	b.n	d0080dde <emit_dictionary_word.constprop.0+0x766>
d0081256:	1c51      	adds	r1, r2, #1
d0081258:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008125c:	f080 8586 	bcs.w	d0081d6c <emit_dictionary_word.constprop.0+0x16f4>
d0081260:	b28a      	uxth	r2, r1
d0081262:	2020      	movs	r0, #32
d0081264:	1c51      	adds	r1, r2, #1
d0081266:	55d8      	strb	r0, [r3, r7]
d0081268:	8022      	strh	r2, [r4, #0]
d008126a:	4617      	mov	r7, r2
d008126c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081270:	f803 c002 	strb.w	ip, [r3, r2]
d0081274:	f4ff ae4f 	bcc.w	d0080f16 <emit_dictionary_word.constprop.0+0x89e>
d0081278:	e652      	b.n	d0080f20 <emit_dictionary_word.constprop.0+0x8a8>
d008127a:	460f      	mov	r7, r1
d008127c:	8021      	strh	r1, [r4, #0]
d008127e:	3101      	adds	r1, #1
d0081280:	55d8      	strb	r0, [r3, r7]
d0081282:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081286:	f080 8719 	bcs.w	d00820bc <emit_dictionary_word.constprop.0+0x1a44>
d008128a:	3202      	adds	r2, #2
d008128c:	2127      	movs	r1, #39	; 0x27
d008128e:	b292      	uxth	r2, r2
d0081290:	55d9      	strb	r1, [r3, r7]
d0081292:	8022      	strh	r2, [r4, #0]
d0081294:	4617      	mov	r7, r2
d0081296:	e557      	b.n	d0080d48 <emit_dictionary_word.constprop.0+0x6d0>
d0081298:	882b      	ldrh	r3, [r5, #0]
d008129a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008129e:	f4bf abd6 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00812a2:	4e21      	ldr	r6, [pc, #132]	; (d0081328 <emit_dictionary_word.constprop.0+0xcb0>)
d00812a4:	2112      	movs	r1, #18
d00812a6:	223a      	movs	r2, #58	; 0x3a
d00812a8:	4c20      	ldr	r4, [pc, #128]	; (d008132c <emit_dictionary_word.constprop.0+0xcb4>)
d00812aa:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d00812ae:	882b      	ldrh	r3, [r5, #0]
d00812b0:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00812b4:	805a      	strh	r2, [r3, #2]
d00812b6:	882b      	ldrh	r3, [r5, #0]
d00812b8:	8822      	ldrh	r2, [r4, #0]
d00812ba:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00812be:	7058      	strb	r0, [r3, #1]
d00812c0:	882b      	ldrh	r3, [r5, #0]
d00812c2:	3301      	adds	r3, #1
d00812c4:	802b      	strh	r3, [r5, #0]
d00812c6:	2a00      	cmp	r2, #0
d00812c8:	f040 8105 	bne.w	d00814d6 <emit_dictionary_word.constprop.0+0xe5e>
d00812cc:	4607      	mov	r7, r0
d00812ce:	4b15      	ldr	r3, [pc, #84]	; (d0081324 <emit_dictionary_word.constprop.0+0xcac>)
d00812d0:	2201      	movs	r2, #1
d00812d2:	b292      	uxth	r2, r2
d00812d4:	2144      	movs	r1, #68	; 0x44
d00812d6:	55d9      	strb	r1, [r3, r7]
d00812d8:	4617      	mov	r7, r2
d00812da:	8022      	strh	r2, [r4, #0]
d00812dc:	f04f 0c00 	mov.w	ip, #0
d00812e0:	f803 c007 	strb.w	ip, [r3, r7]
d00812e4:	8829      	ldrh	r1, [r5, #0]
d00812e6:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d00812ea:	f4bf abb0 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00812ee:	f04f 0807 	mov.w	r8, #7
d00812f2:	f04f 0e44 	mov.w	lr, #68	; 0x44
d00812f6:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d00812fa:	8829      	ldrh	r1, [r5, #0]
d00812fc:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081300:	f8a1 e002 	strh.w	lr, [r1, #2]
d0081304:	8829      	ldrh	r1, [r5, #0]
d0081306:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d008130a:	f881 c001 	strb.w	ip, [r1, #1]
d008130e:	8829      	ldrh	r1, [r5, #0]
d0081310:	3101      	adds	r1, #1
d0081312:	8029      	strh	r1, [r5, #0]
d0081314:	2a00      	cmp	r2, #0
d0081316:	f040 80f3 	bne.w	d0081500 <emit_dictionary_word.constprop.0+0xe88>
d008131a:	2101      	movs	r1, #1
d008131c:	f8df e010 	ldr.w	lr, [pc, #16]	; d0081330 <emit_dictionary_word.constprop.0+0xcb8>
d0081320:	2749      	movs	r7, #73	; 0x49
d0081322:	e00f      	b.n	d0081344 <emit_dictionary_word.constprop.0+0xccc>
d0081324:	d0086d88 	.word	0xd0086d88
d0081328:	d0086188 	.word	0xd0086188
d008132c:	d0087588 	.word	0xd0087588
d0081330:	d00859d8 	.word	0xd00859d8
d0081334:	549f      	strb	r7, [r3, r2]
d0081336:	4662      	mov	r2, ip
d0081338:	f81e 7f01 	ldrb.w	r7, [lr, #1]!
d008133c:	1c51      	adds	r1, r2, #1
d008133e:	2f00      	cmp	r7, #0
d0081340:	f000 8334 	beq.w	d00819ac <emit_dictionary_word.constprop.0+0x1334>
d0081344:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081348:	fa1f fc81 	uxth.w	ip, r1
d008134c:	d3f2      	bcc.n	d0081334 <emit_dictionary_word.constprop.0+0xcbc>
d008134e:	8022      	strh	r2, [r4, #0]
d0081350:	f04f 0e00 	mov.w	lr, #0
d0081354:	4617      	mov	r7, r2
d0081356:	f803 e002 	strb.w	lr, [r3, r2]
d008135a:	8829      	ldrh	r1, [r5, #0]
d008135c:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0081360:	f4bf ab75 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081364:	f04f 0823 	mov.w	r8, #35	; 0x23
d0081368:	f04f 0c40 	mov.w	ip, #64	; 0x40
d008136c:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d0081370:	8829      	ldrh	r1, [r5, #0]
d0081372:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081376:	f8a1 c002 	strh.w	ip, [r1, #2]
d008137a:	8829      	ldrh	r1, [r5, #0]
d008137c:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081380:	f881 e001 	strb.w	lr, [r1, #1]
d0081384:	8829      	ldrh	r1, [r5, #0]
d0081386:	3101      	adds	r1, #1
d0081388:	8029      	strh	r1, [r5, #0]
d008138a:	2a00      	cmp	r2, #0
d008138c:	f040 80d3 	bne.w	d0081536 <emit_dictionary_word.constprop.0+0xebe>
d0081390:	2101      	movs	r1, #1
d0081392:	b28a      	uxth	r2, r1
d0081394:	2156      	movs	r1, #86	; 0x56
d0081396:	55d9      	strb	r1, [r3, r7]
d0081398:	4617      	mov	r7, r2
d008139a:	8022      	strh	r2, [r4, #0]
d008139c:	2100      	movs	r1, #0
d008139e:	5499      	strb	r1, [r3, r2]
d00813a0:	8829      	ldrh	r1, [r5, #0]
d00813a2:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d00813a6:	f4bf ab52 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00813aa:	f04f 0c0c 	mov.w	ip, #12
d00813ae:	f04f 0e48 	mov.w	lr, #72	; 0x48
d00813b2:	f806 c021 	strb.w	ip, [r6, r1, lsl #2]
d00813b6:	2101      	movs	r1, #1
d00813b8:	f8b5 c000 	ldrh.w	ip, [r5]
d00813bc:	eb06 0c8c 	add.w	ip, r6, ip, lsl #2
d00813c0:	f8ac e002 	strh.w	lr, [ip, #2]
d00813c4:	f8b5 c000 	ldrh.w	ip, [r5]
d00813c8:	eb06 0c8c 	add.w	ip, r6, ip, lsl #2
d00813cc:	f88c 1001 	strb.w	r1, [ip, #1]
d00813d0:	f8b5 c000 	ldrh.w	ip, [r5]
d00813d4:	448c      	add	ip, r1
d00813d6:	f8a5 c000 	strh.w	ip, [r5]
d00813da:	2a00      	cmp	r2, #0
d00813dc:	f040 809e 	bne.w	d008151c <emit_dictionary_word.constprop.0+0xea4>
d00813e0:	4fb9      	ldr	r7, [pc, #740]	; (d00816c8 <emit_dictionary_word.constprop.0+0x1050>)
d00813e2:	f04f 0c41 	mov.w	ip, #65	; 0x41
d00813e6:	e009      	b.n	d00813fc <emit_dictionary_word.constprop.0+0xd84>
d00813e8:	f803 c002 	strb.w	ip, [r3, r2]
d00813ec:	f817 cf01 	ldrb.w	ip, [r7, #1]!
d00813f0:	f1bc 0f00 	cmp.w	ip, #0
d00813f4:	f000 8262 	beq.w	d00818bc <emit_dictionary_word.constprop.0+0x1244>
d00813f8:	460a      	mov	r2, r1
d00813fa:	3101      	adds	r1, #1
d00813fc:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081400:	b289      	uxth	r1, r1
d0081402:	d3f1      	bcc.n	d00813e8 <emit_dictionary_word.constprop.0+0xd70>
d0081404:	2100      	movs	r1, #0
d0081406:	4617      	mov	r7, r2
d0081408:	8022      	strh	r2, [r4, #0]
d008140a:	5499      	strb	r1, [r3, r2]
d008140c:	f04f 0c00 	mov.w	ip, #0
d0081410:	f803 c007 	strb.w	ip, [r3, r7]
d0081414:	8829      	ldrh	r1, [r5, #0]
d0081416:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d008141a:	f4bf ab18 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d008141e:	f04f 0808 	mov.w	r8, #8
d0081422:	f04f 0e3c 	mov.w	lr, #60	; 0x3c
d0081426:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d008142a:	8829      	ldrh	r1, [r5, #0]
d008142c:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081430:	f8a1 e002 	strh.w	lr, [r1, #2]
d0081434:	8829      	ldrh	r1, [r5, #0]
d0081436:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d008143a:	f881 c001 	strb.w	ip, [r1, #1]
d008143e:	8829      	ldrh	r1, [r5, #0]
d0081440:	3101      	adds	r1, #1
d0081442:	8029      	strh	r1, [r5, #0]
d0081444:	2a00      	cmp	r2, #0
d0081446:	d138      	bne.n	d00814ba <emit_dictionary_word.constprop.0+0xe42>
d0081448:	2101      	movs	r1, #1
d008144a:	f8df e28c 	ldr.w	lr, [pc, #652]	; d00816d8 <emit_dictionary_word.constprop.0+0x1060>
d008144e:	2749      	movs	r7, #73	; 0x49
d0081450:	e007      	b.n	d0081462 <emit_dictionary_word.constprop.0+0xdea>
d0081452:	549f      	strb	r7, [r3, r2]
d0081454:	4662      	mov	r2, ip
d0081456:	f81e 7f01 	ldrb.w	r7, [lr, #1]!
d008145a:	1c51      	adds	r1, r2, #1
d008145c:	2f00      	cmp	r7, #0
d008145e:	f000 82a8 	beq.w	d00819b2 <emit_dictionary_word.constprop.0+0x133a>
d0081462:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081466:	fa1f fc81 	uxth.w	ip, r1
d008146a:	d3f2      	bcc.n	d0081452 <emit_dictionary_word.constprop.0+0xdda>
d008146c:	8022      	strh	r2, [r4, #0]
d008146e:	f04f 0c00 	mov.w	ip, #0
d0081472:	4617      	mov	r7, r2
d0081474:	f803 c002 	strb.w	ip, [r3, r2]
d0081478:	8829      	ldrh	r1, [r5, #0]
d008147a:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d008147e:	f4bf aae6 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081482:	f04f 081f 	mov.w	r8, #31
d0081486:	f04f 0e4a 	mov.w	lr, #74	; 0x4a
d008148a:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d008148e:	8829      	ldrh	r1, [r5, #0]
d0081490:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081494:	f8a1 e002 	strh.w	lr, [r1, #2]
d0081498:	8829      	ldrh	r1, [r5, #0]
d008149a:	eb06 0681 	add.w	r6, r6, r1, lsl #2
d008149e:	f886 c001 	strb.w	ip, [r6, #1]
d00814a2:	8829      	ldrh	r1, [r5, #0]
d00814a4:	3101      	adds	r1, #1
d00814a6:	8029      	strh	r1, [r5, #0]
d00814a8:	2a00      	cmp	r2, #0
d00814aa:	d158      	bne.n	d008155e <emit_dictionary_word.constprop.0+0xee6>
d00814ac:	2101      	movs	r1, #1
d00814ae:	b289      	uxth	r1, r1
d00814b0:	2253      	movs	r2, #83	; 0x53
d00814b2:	460f      	mov	r7, r1
d00814b4:	8021      	strh	r1, [r4, #0]
d00814b6:	541a      	strb	r2, [r3, r0]
d00814b8:	e411      	b.n	d0080cde <emit_dictionary_word.constprop.0+0x666>
d00814ba:	1c51      	adds	r1, r2, #1
d00814bc:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00814c0:	d204      	bcs.n	d00814cc <emit_dictionary_word.constprop.0+0xe54>
d00814c2:	b28a      	uxth	r2, r1
d00814c4:	2120      	movs	r1, #32
d00814c6:	55d9      	strb	r1, [r3, r7]
d00814c8:	1c51      	adds	r1, r2, #1
d00814ca:	4617      	mov	r7, r2
d00814cc:	f04f 0c00 	mov.w	ip, #0
d00814d0:	f803 c007 	strb.w	ip, [r3, r7]
d00814d4:	e7b9      	b.n	d008144a <emit_dictionary_word.constprop.0+0xdd2>
d00814d6:	1c51      	adds	r1, r2, #1
d00814d8:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00814dc:	f080 8485 	bcs.w	d0081dea <emit_dictionary_word.constprop.0+0x1772>
d00814e0:	b289      	uxth	r1, r1
d00814e2:	4b7a      	ldr	r3, [pc, #488]	; (d00816cc <emit_dictionary_word.constprop.0+0x1054>)
d00814e4:	f04f 0c20 	mov.w	ip, #32
d00814e8:	460f      	mov	r7, r1
d00814ea:	8021      	strh	r1, [r4, #0]
d00814ec:	f803 c002 	strb.w	ip, [r3, r2]
d00814f0:	1c4a      	adds	r2, r1, #1
d00814f2:	5458      	strb	r0, [r3, r1]
d00814f4:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00814f8:	f4ff aeeb 	bcc.w	d00812d2 <emit_dictionary_word.constprop.0+0xc5a>
d00814fc:	460a      	mov	r2, r1
d00814fe:	e6ed      	b.n	d00812dc <emit_dictionary_word.constprop.0+0xc64>
d0081500:	1c51      	adds	r1, r2, #1
d0081502:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081506:	d204      	bcs.n	d0081512 <emit_dictionary_word.constprop.0+0xe9a>
d0081508:	b28a      	uxth	r2, r1
d008150a:	2120      	movs	r1, #32
d008150c:	55d9      	strb	r1, [r3, r7]
d008150e:	1c51      	adds	r1, r2, #1
d0081510:	4617      	mov	r7, r2
d0081512:	f04f 0c00 	mov.w	ip, #0
d0081516:	f803 c007 	strb.w	ip, [r3, r7]
d008151a:	e6ff      	b.n	d008131c <emit_dictionary_word.constprop.0+0xca4>
d008151c:	1c51      	adds	r1, r2, #1
d008151e:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081522:	d205      	bcs.n	d0081530 <emit_dictionary_word.constprop.0+0xeb8>
d0081524:	b28a      	uxth	r2, r1
d0081526:	f04f 0c20 	mov.w	ip, #32
d008152a:	1c51      	adds	r1, r2, #1
d008152c:	f803 c007 	strb.w	ip, [r3, r7]
d0081530:	2700      	movs	r7, #0
d0081532:	549f      	strb	r7, [r3, r2]
d0081534:	e754      	b.n	d00813e0 <emit_dictionary_word.constprop.0+0xd68>
d0081536:	1c51      	adds	r1, r2, #1
d0081538:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008153c:	f080 8475 	bcs.w	d0081e2a <emit_dictionary_word.constprop.0+0x17b2>
d0081540:	b28a      	uxth	r2, r1
d0081542:	f04f 0c20 	mov.w	ip, #32
d0081546:	1c51      	adds	r1, r2, #1
d0081548:	f803 c007 	strb.w	ip, [r3, r7]
d008154c:	8022      	strh	r2, [r4, #0]
d008154e:	4617      	mov	r7, r2
d0081550:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081554:	f803 e002 	strb.w	lr, [r3, r2]
d0081558:	f4ff af1b 	bcc.w	d0081392 <emit_dictionary_word.constprop.0+0xd1a>
d008155c:	e71e      	b.n	d008139c <emit_dictionary_word.constprop.0+0xd24>
d008155e:	3201      	adds	r2, #1
d0081560:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0081564:	f080 843d 	bcs.w	d0081de2 <emit_dictionary_word.constprop.0+0x176a>
d0081568:	b292      	uxth	r2, r2
d008156a:	2020      	movs	r0, #32
d008156c:	1c51      	adds	r1, r2, #1
d008156e:	55d8      	strb	r0, [r3, r7]
d0081570:	8022      	strh	r2, [r4, #0]
d0081572:	4610      	mov	r0, r2
d0081574:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081578:	f803 c002 	strb.w	ip, [r3, r2]
d008157c:	d397      	bcc.n	d00814ae <emit_dictionary_word.constprop.0+0xe36>
d008157e:	4617      	mov	r7, r2
d0081580:	f7ff bbad 	b.w	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0081584:	4632      	mov	r2, r6
d0081586:	4b51      	ldr	r3, [pc, #324]	; (d00816cc <emit_dictionary_word.constprop.0+0x1054>)
d0081588:	f7ff baac 	b.w	d0080ae4 <emit_dictionary_word.constprop.0+0x46c>
d008158c:	8022      	strh	r2, [r4, #0]
d008158e:	f7ff b99c 	b.w	d00808ca <emit_dictionary_word.constprop.0+0x252>
d0081592:	2301      	movs	r3, #1
d0081594:	225f      	movs	r2, #95	; 0x5f
d0081596:	2107      	movs	r1, #7
d0081598:	4628      	mov	r0, r5
d008159a:	f7fe fdff 	bl	d008019c <emit_phone.constprop.0>
d008159e:	882b      	ldrh	r3, [r5, #0]
d00815a0:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00815a4:	f4bf aa53 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d00815a8:	4e49      	ldr	r6, [pc, #292]	; (d00816d0 <emit_dictionary_word.constprop.0+0x1058>)
d00815aa:	211c      	movs	r1, #28
d00815ac:	2246      	movs	r2, #70	; 0x46
d00815ae:	4c49      	ldr	r4, [pc, #292]	; (d00816d4 <emit_dictionary_word.constprop.0+0x105c>)
d00815b0:	f806 1023 	strb.w	r1, [r6, r3, lsl #2]
d00815b4:	882b      	ldrh	r3, [r5, #0]
d00815b6:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00815ba:	805a      	strh	r2, [r3, #2]
d00815bc:	882b      	ldrh	r3, [r5, #0]
d00815be:	8822      	ldrh	r2, [r4, #0]
d00815c0:	eb06 0383 	add.w	r3, r6, r3, lsl #2
d00815c4:	705f      	strb	r7, [r3, #1]
d00815c6:	882b      	ldrh	r3, [r5, #0]
d00815c8:	3301      	adds	r3, #1
d00815ca:	802b      	strh	r3, [r5, #0]
d00815cc:	2a00      	cmp	r2, #0
d00815ce:	f040 80ff 	bne.w	d00817d0 <emit_dictionary_word.constprop.0+0x1158>
d00815d2:	4b3e      	ldr	r3, [pc, #248]	; (d00816cc <emit_dictionary_word.constprop.0+0x1054>)
d00815d4:	f8df c104 	ldr.w	ip, [pc, #260]	; d00816dc <emit_dictionary_word.constprop.0+0x1064>
d00815d8:	204e      	movs	r0, #78	; 0x4e
d00815da:	e006      	b.n	d00815ea <emit_dictionary_word.constprop.0+0xf72>
d00815dc:	5498      	strb	r0, [r3, r2]
d00815de:	460a      	mov	r2, r1
d00815e0:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d00815e4:	2800      	cmp	r0, #0
d00815e6:	f000 822d 	beq.w	d0081a44 <emit_dictionary_word.constprop.0+0x13cc>
d00815ea:	1c51      	adds	r1, r2, #1
d00815ec:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00815f0:	b289      	uxth	r1, r1
d00815f2:	d3f3      	bcc.n	d00815dc <emit_dictionary_word.constprop.0+0xf64>
d00815f4:	8022      	strh	r2, [r4, #0]
d00815f6:	f04f 0c00 	mov.w	ip, #0
d00815fa:	4696      	mov	lr, r2
d00815fc:	f803 c002 	strb.w	ip, [r3, r2]
d0081600:	8829      	ldrh	r1, [r5, #0]
d0081602:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0081606:	f4bf aa22 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d008160a:	f04f 0815 	mov.w	r8, #21
d008160e:	202e      	movs	r0, #46	; 0x2e
d0081610:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d0081614:	8829      	ldrh	r1, [r5, #0]
d0081616:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d008161a:	8048      	strh	r0, [r1, #2]
d008161c:	8829      	ldrh	r1, [r5, #0]
d008161e:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081622:	f881 c001 	strb.w	ip, [r1, #1]
d0081626:	8829      	ldrh	r1, [r5, #0]
d0081628:	3101      	adds	r1, #1
d008162a:	8029      	strh	r1, [r5, #0]
d008162c:	2a00      	cmp	r2, #0
d008162e:	f040 80bc 	bne.w	d00817aa <emit_dictionary_word.constprop.0+0x1132>
d0081632:	4610      	mov	r0, r2
d0081634:	2101      	movs	r1, #1
d0081636:	b28a      	uxth	r2, r1
d0081638:	2147      	movs	r1, #71	; 0x47
d008163a:	8022      	strh	r2, [r4, #0]
d008163c:	5419      	strb	r1, [r3, r0]
d008163e:	f04f 0c00 	mov.w	ip, #0
d0081642:	4696      	mov	lr, r2
d0081644:	f803 c002 	strb.w	ip, [r3, r2]
d0081648:	8829      	ldrh	r1, [r5, #0]
d008164a:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d008164e:	f4bf a9fe 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081652:	f04f 0819 	mov.w	r8, #25
d0081656:	2030      	movs	r0, #48	; 0x30
d0081658:	f806 8021 	strb.w	r8, [r6, r1, lsl #2]
d008165c:	8829      	ldrh	r1, [r5, #0]
d008165e:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081662:	8048      	strh	r0, [r1, #2]
d0081664:	8829      	ldrh	r1, [r5, #0]
d0081666:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d008166a:	f881 c001 	strb.w	ip, [r1, #1]
d008166e:	8829      	ldrh	r1, [r5, #0]
d0081670:	3101      	adds	r1, #1
d0081672:	8029      	strh	r1, [r5, #0]
d0081674:	2a00      	cmp	r2, #0
d0081676:	f040 8085 	bne.w	d0081784 <emit_dictionary_word.constprop.0+0x110c>
d008167a:	2101      	movs	r1, #1
d008167c:	b28a      	uxth	r2, r1
d008167e:	214c      	movs	r1, #76	; 0x4c
d0081680:	8022      	strh	r2, [r4, #0]
d0081682:	55d9      	strb	r1, [r3, r7]
d0081684:	2000      	movs	r0, #0
d0081686:	4617      	mov	r7, r2
d0081688:	5498      	strb	r0, [r3, r2]
d008168a:	8829      	ldrh	r1, [r5, #0]
d008168c:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d0081690:	f4bf a9dd 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081694:	f04f 0e07 	mov.w	lr, #7
d0081698:	f04f 0c4b 	mov.w	ip, #75	; 0x4b
d008169c:	f806 e021 	strb.w	lr, [r6, r1, lsl #2]
d00816a0:	8829      	ldrh	r1, [r5, #0]
d00816a2:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d00816a6:	f8a1 c002 	strh.w	ip, [r1, #2]
d00816aa:	8829      	ldrh	r1, [r5, #0]
d00816ac:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d00816b0:	7048      	strb	r0, [r1, #1]
d00816b2:	8829      	ldrh	r1, [r5, #0]
d00816b4:	3101      	adds	r1, #1
d00816b6:	8029      	strh	r1, [r5, #0]
d00816b8:	2a00      	cmp	r2, #0
d00816ba:	d14e      	bne.n	d008175a <emit_dictionary_word.constprop.0+0x10e2>
d00816bc:	2101      	movs	r1, #1
d00816be:	f8df c020 	ldr.w	ip, [pc, #32]	; d00816e0 <emit_dictionary_word.constprop.0+0x1068>
d00816c2:	2049      	movs	r0, #73	; 0x49
d00816c4:	e016      	b.n	d00816f4 <emit_dictionary_word.constprop.0+0x107c>
d00816c6:	bf00      	nop
d00816c8:	d00859a4 	.word	0xd00859a4
d00816cc:	d0086d88 	.word	0xd0086d88
d00816d0:	d0086188 	.word	0xd0086188
d00816d4:	d0087588 	.word	0xd0087588
d00816d8:	d00859b8 	.word	0xd00859b8
d00816dc:	d00859e4 	.word	0xd00859e4
d00816e0:	d00859d8 	.word	0xd00859d8
d00816e4:	5498      	strb	r0, [r3, r2]
d00816e6:	1c79      	adds	r1, r7, #1
d00816e8:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d00816ec:	463a      	mov	r2, r7
d00816ee:	2800      	cmp	r0, #0
d00816f0:	f000 81a6 	beq.w	d0081a40 <emit_dictionary_word.constprop.0+0x13c8>
d00816f4:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00816f8:	b28f      	uxth	r7, r1
d00816fa:	d3f3      	bcc.n	d00816e4 <emit_dictionary_word.constprop.0+0x106c>
d00816fc:	8022      	strh	r2, [r4, #0]
d00816fe:	f04f 0c00 	mov.w	ip, #0
d0081702:	4617      	mov	r7, r2
d0081704:	f803 c002 	strb.w	ip, [r3, r2]
d0081708:	8829      	ldrh	r1, [r5, #0]
d008170a:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d008170e:	f4bf a99e 	bcs.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081712:	2020      	movs	r0, #32
d0081714:	f04f 0e4e 	mov.w	lr, #78	; 0x4e
d0081718:	f806 0021 	strb.w	r0, [r6, r1, lsl #2]
d008171c:	8829      	ldrh	r1, [r5, #0]
d008171e:	eb06 0181 	add.w	r1, r6, r1, lsl #2
d0081722:	f8a1 e002 	strh.w	lr, [r1, #2]
d0081726:	8829      	ldrh	r1, [r5, #0]
d0081728:	eb06 0681 	add.w	r6, r6, r1, lsl #2
d008172c:	f886 c001 	strb.w	ip, [r6, #1]
d0081730:	8829      	ldrh	r1, [r5, #0]
d0081732:	3101      	adds	r1, #1
d0081734:	8029      	strh	r1, [r5, #0]
d0081736:	b9da      	cbnz	r2, d0081770 <emit_dictionary_word.constprop.0+0x10f8>
d0081738:	2101      	movs	r1, #1
d008173a:	4ed5      	ldr	r6, [pc, #852]	; (d0081a90 <emit_dictionary_word.constprop.0+0x1418>)
d008173c:	2053      	movs	r0, #83	; 0x53
d008173e:	e007      	b.n	d0081750 <emit_dictionary_word.constprop.0+0x10d8>
d0081740:	5498      	strb	r0, [r3, r2]
d0081742:	1c69      	adds	r1, r5, #1
d0081744:	f816 0f01 	ldrb.w	r0, [r6, #1]!
d0081748:	462a      	mov	r2, r5
d008174a:	2800      	cmp	r0, #0
d008174c:	f000 80c6 	beq.w	d00818dc <emit_dictionary_word.constprop.0+0x1264>
d0081750:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081754:	b28d      	uxth	r5, r1
d0081756:	d3f3      	bcc.n	d0081740 <emit_dictionary_word.constprop.0+0x10c8>
d0081758:	e46e      	b.n	d0081038 <emit_dictionary_word.constprop.0+0x9c0>
d008175a:	1c51      	adds	r1, r2, #1
d008175c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081760:	d203      	bcs.n	d008176a <emit_dictionary_word.constprop.0+0x10f2>
d0081762:	b28a      	uxth	r2, r1
d0081764:	2020      	movs	r0, #32
d0081766:	1c51      	adds	r1, r2, #1
d0081768:	55d8      	strb	r0, [r3, r7]
d008176a:	2000      	movs	r0, #0
d008176c:	5498      	strb	r0, [r3, r2]
d008176e:	e7a6      	b.n	d00816be <emit_dictionary_word.constprop.0+0x1046>
d0081770:	1c51      	adds	r1, r2, #1
d0081772:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d0081776:	d202      	bcs.n	d008177e <emit_dictionary_word.constprop.0+0x1106>
d0081778:	b28a      	uxth	r2, r1
d008177a:	55d8      	strb	r0, [r3, r7]
d008177c:	1c51      	adds	r1, r2, #1
d008177e:	2000      	movs	r0, #0
d0081780:	5498      	strb	r0, [r3, r2]
d0081782:	e7da      	b.n	d008173a <emit_dictionary_word.constprop.0+0x10c2>
d0081784:	1c51      	adds	r1, r2, #1
d0081786:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d008178a:	f080 838b 	bcs.w	d0081ea4 <emit_dictionary_word.constprop.0+0x182c>
d008178e:	b28a      	uxth	r2, r1
d0081790:	2020      	movs	r0, #32
d0081792:	1c51      	adds	r1, r2, #1
d0081794:	f803 000e 	strb.w	r0, [r3, lr]
d0081798:	4617      	mov	r7, r2
d008179a:	8022      	strh	r2, [r4, #0]
d008179c:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00817a0:	f803 c002 	strb.w	ip, [r3, r2]
d00817a4:	f4ff af6a 	bcc.w	d008167c <emit_dictionary_word.constprop.0+0x1004>
d00817a8:	e76c      	b.n	d0081684 <emit_dictionary_word.constprop.0+0x100c>
d00817aa:	1c51      	adds	r1, r2, #1
d00817ac:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00817b0:	f080 837c 	bcs.w	d0081eac <emit_dictionary_word.constprop.0+0x1834>
d00817b4:	b28a      	uxth	r2, r1
d00817b6:	2020      	movs	r0, #32
d00817b8:	1c51      	adds	r1, r2, #1
d00817ba:	f803 000e 	strb.w	r0, [r3, lr]
d00817be:	8022      	strh	r2, [r4, #0]
d00817c0:	4610      	mov	r0, r2
d00817c2:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00817c6:	f803 c002 	strb.w	ip, [r3, r2]
d00817ca:	f4ff af34 	bcc.w	d0081636 <emit_dictionary_word.constprop.0+0xfbe>
d00817ce:	e736      	b.n	d008163e <emit_dictionary_word.constprop.0+0xfc6>
d00817d0:	1c51      	adds	r1, r2, #1
d00817d2:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00817d6:	f080 8157 	bcs.w	d0081a88 <emit_dictionary_word.constprop.0+0x1410>
d00817da:	4bae      	ldr	r3, [pc, #696]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d00817dc:	2020      	movs	r0, #32
d00817de:	b289      	uxth	r1, r1
d00817e0:	5498      	strb	r0, [r3, r2]
d00817e2:	2000      	movs	r0, #0
d00817e4:	460a      	mov	r2, r1
d00817e6:	5458      	strb	r0, [r3, r1]
d00817e8:	e6f4      	b.n	d00815d4 <emit_dictionary_word.constprop.0+0xf5c>
d00817ea:	4608      	mov	r0, r1
d00817ec:	8021      	strh	r1, [r4, #0]
d00817ee:	3101      	adds	r1, #1
d00817f0:	541f      	strb	r7, [r3, r0]
d00817f2:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00817f6:	f080 8464 	bcs.w	d00820c2 <emit_dictionary_word.constprop.0+0x1a4a>
d00817fa:	3202      	adds	r2, #2
d00817fc:	2127      	movs	r1, #39	; 0x27
d00817fe:	b292      	uxth	r2, r2
d0081800:	5419      	strb	r1, [r3, r0]
d0081802:	8022      	strh	r2, [r4, #0]
d0081804:	4610      	mov	r0, r2
d0081806:	f7ff bbba 	b.w	d0080f7e <emit_dictionary_word.constprop.0+0x906>
d008180a:	4611      	mov	r1, r2
d008180c:	4ba1      	ldr	r3, [pc, #644]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d008180e:	f7ff b976 	b.w	d0080afe <emit_dictionary_word.constprop.0+0x486>
d0081812:	8022      	strh	r2, [r4, #0]
d0081814:	f7ff b9bc 	b.w	d0080b90 <emit_dictionary_word.constprop.0+0x518>
d0081818:	2301      	movs	r3, #1
d008181a:	2273      	movs	r2, #115	; 0x73
d008181c:	2105      	movs	r1, #5
d008181e:	4628      	mov	r0, r5
d0081820:	f7fe fcbc 	bl	d008019c <emit_phone.constprop.0>
d0081824:	463b      	mov	r3, r7
d0081826:	2232      	movs	r2, #50	; 0x32
d0081828:	211d      	movs	r1, #29
d008182a:	4628      	mov	r0, r5
d008182c:	f7fe fcb6 	bl	d008019c <emit_phone.constprop.0>
d0081830:	2241      	movs	r2, #65	; 0x41
d0081832:	463b      	mov	r3, r7
d0081834:	211f      	movs	r1, #31
d0081836:	4628      	mov	r0, r5
d0081838:	f7fe fcb0 	bl	d008019c <emit_phone.constprop.0>
d008183c:	882a      	ldrh	r2, [r5, #0]
d008183e:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0081842:	d225      	bcs.n	d0081890 <emit_dictionary_word.constprop.0+0x1218>
d0081844:	4b94      	ldr	r3, [pc, #592]	; (d0081a98 <emit_dictionary_word.constprop.0+0x1420>)
d0081846:	2001      	movs	r0, #1
d0081848:	2150      	movs	r1, #80	; 0x50
d008184a:	4c94      	ldr	r4, [pc, #592]	; (d0081a9c <emit_dictionary_word.constprop.0+0x1424>)
d008184c:	f803 0022 	strb.w	r0, [r3, r2, lsl #2]
d0081850:	882a      	ldrh	r2, [r5, #0]
d0081852:	eb03 0282 	add.w	r2, r3, r2, lsl #2
d0081856:	8051      	strh	r1, [r2, #2]
d0081858:	882a      	ldrh	r2, [r5, #0]
d008185a:	8821      	ldrh	r1, [r4, #0]
d008185c:	eb03 0382 	add.w	r3, r3, r2, lsl #2
d0081860:	705f      	strb	r7, [r3, #1]
d0081862:	882b      	ldrh	r3, [r5, #0]
d0081864:	4403      	add	r3, r0
d0081866:	802b      	strh	r3, [r5, #0]
d0081868:	b9d9      	cbnz	r1, d00818a2 <emit_dictionary_word.constprop.0+0x122a>
d008186a:	4b8a      	ldr	r3, [pc, #552]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d008186c:	4e8c      	ldr	r6, [pc, #560]	; (d0081aa0 <emit_dictionary_word.constprop.0+0x1428>)
d008186e:	2041      	movs	r0, #65	; 0x41
d0081870:	e006      	b.n	d0081880 <emit_dictionary_word.constprop.0+0x1208>
d0081872:	5458      	strb	r0, [r3, r1]
d0081874:	4611      	mov	r1, r2
d0081876:	f816 0f01 	ldrb.w	r0, [r6, #1]!
d008187a:	2800      	cmp	r0, #0
d008187c:	f000 8102 	beq.w	d0081a84 <emit_dictionary_word.constprop.0+0x140c>
d0081880:	1c4a      	adds	r2, r1, #1
d0081882:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0081886:	b292      	uxth	r2, r2
d0081888:	d3f3      	bcc.n	d0081872 <emit_dictionary_word.constprop.0+0x11fa>
d008188a:	8021      	strh	r1, [r4, #0]
d008188c:	2200      	movs	r2, #0
d008188e:	545a      	strb	r2, [r3, r1]
d0081890:	4628      	mov	r0, r5
d0081892:	2300      	movs	r3, #0
d0081894:	223c      	movs	r2, #60	; 0x3c
d0081896:	211b      	movs	r1, #27
d0081898:	f7fe fc80 	bl	d008019c <emit_phone.constprop.0>
d008189c:	2001      	movs	r0, #1
d008189e:	f7ff b8d7 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00818a2:	1c4a      	adds	r2, r1, #1
d00818a4:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00818a8:	f080 81d5 	bcs.w	d0081c56 <emit_dictionary_word.constprop.0+0x15de>
d00818ac:	4b79      	ldr	r3, [pc, #484]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d00818ae:	2020      	movs	r0, #32
d00818b0:	b292      	uxth	r2, r2
d00818b2:	5458      	strb	r0, [r3, r1]
d00818b4:	2000      	movs	r0, #0
d00818b6:	4611      	mov	r1, r2
d00818b8:	5498      	strb	r0, [r3, r2]
d00818ba:	e7d7      	b.n	d008186c <emit_dictionary_word.constprop.0+0x11f4>
d00818bc:	460f      	mov	r7, r1
d00818be:	8021      	strh	r1, [r4, #0]
d00818c0:	3101      	adds	r1, #1
d00818c2:	f803 c007 	strb.w	ip, [r3, r7]
d00818c6:	f5b1 6f00 	cmp.w	r1, #2048	; 0x800
d00818ca:	f080 83f4 	bcs.w	d00820b6 <emit_dictionary_word.constprop.0+0x1a3e>
d00818ce:	3202      	adds	r2, #2
d00818d0:	2127      	movs	r1, #39	; 0x27
d00818d2:	b292      	uxth	r2, r2
d00818d4:	55d9      	strb	r1, [r3, r7]
d00818d6:	8022      	strh	r2, [r4, #0]
d00818d8:	4617      	mov	r7, r2
d00818da:	e597      	b.n	d008140c <emit_dictionary_word.constprop.0+0xd94>
d00818dc:	8025      	strh	r5, [r4, #0]
d00818de:	f7ff bbac 	b.w	d008103a <emit_dictionary_word.constprop.0+0x9c2>
d00818e2:	4611      	mov	r1, r2
d00818e4:	4b6b      	ldr	r3, [pc, #428]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d00818e6:	f7ff b8dd 	b.w	d0080aa4 <emit_dictionary_word.constprop.0+0x42c>
d00818ea:	2301      	movs	r3, #1
d00818ec:	2278      	movs	r2, #120	; 0x78
d00818ee:	210b      	movs	r1, #11
d00818f0:	4628      	mov	r0, r5
d00818f2:	f7fe fc53 	bl	d008019c <emit_phone.constprop.0>
d00818f6:	4628      	mov	r0, r5
d00818f8:	463b      	mov	r3, r7
d00818fa:	2230      	movs	r2, #48	; 0x30
d00818fc:	2121      	movs	r1, #33	; 0x21
d00818fe:	f7fe fc4d 	bl	d008019c <emit_phone.constprop.0>
d0081902:	2001      	movs	r0, #1
d0081904:	f7ff b8a4 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081908:	4661      	mov	r1, ip
d008190a:	4b62      	ldr	r3, [pc, #392]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d008190c:	f7fe bfc7 	b.w	d008089e <emit_dictionary_word.constprop.0+0x226>
d0081910:	4603      	mov	r3, r0
d0081912:	225c      	movs	r2, #92	; 0x5c
d0081914:	2108      	movs	r1, #8
d0081916:	4628      	mov	r0, r5
d0081918:	f7fe fc40 	bl	d008019c <emit_phone.constprop.0>
d008191c:	463b      	mov	r3, r7
d008191e:	2248      	movs	r2, #72	; 0x48
d0081920:	211f      	movs	r1, #31
d0081922:	4628      	mov	r0, r5
d0081924:	f7fe fc3a 	bl	d008019c <emit_phone.constprop.0>
d0081928:	463b      	mov	r3, r7
d008192a:	2236      	movs	r2, #54	; 0x36
d008192c:	211d      	movs	r1, #29
d008192e:	4628      	mov	r0, r5
d0081930:	f7fe fc34 	bl	d008019c <emit_phone.constprop.0>
d0081934:	2301      	movs	r3, #1
d0081936:	227e      	movs	r2, #126	; 0x7e
d0081938:	2108      	movs	r1, #8
d008193a:	4628      	mov	r0, r5
d008193c:	f7fe fc2e 	bl	d008019c <emit_phone.constprop.0>
d0081940:	4628      	mov	r0, r5
d0081942:	463b      	mov	r3, r7
d0081944:	2238      	movs	r2, #56	; 0x38
d0081946:	2118      	movs	r1, #24
d0081948:	f7fe fc28 	bl	d008019c <emit_phone.constprop.0>
d008194c:	2001      	movs	r0, #1
d008194e:	f7ff b87f 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081952:	460a      	mov	r2, r1
d0081954:	4b4f      	ldr	r3, [pc, #316]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d0081956:	f7ff b907 	b.w	d0080b68 <emit_dictionary_word.constprop.0+0x4f0>
d008195a:	2300      	movs	r3, #0
d008195c:	222a      	movs	r2, #42	; 0x2a
d008195e:	2116      	movs	r1, #22
d0081960:	4628      	mov	r0, r5
d0081962:	f7fe fc1b 	bl	d008019c <emit_phone.constprop.0>
d0081966:	2301      	movs	r3, #1
d0081968:	2276      	movs	r2, #118	; 0x76
d008196a:	2104      	movs	r1, #4
d008196c:	4628      	mov	r0, r5
d008196e:	f7fe fc15 	bl	d008019c <emit_phone.constprop.0>
d0081972:	2300      	movs	r3, #0
d0081974:	2236      	movs	r2, #54	; 0x36
d0081976:	2118      	movs	r1, #24
d0081978:	4628      	mov	r0, r5
d008197a:	f7fe fc0f 	bl	d008019c <emit_phone.constprop.0>
d008197e:	2300      	movs	r3, #0
d0081980:	224a      	movs	r2, #74	; 0x4a
d0081982:	2107      	movs	r1, #7
d0081984:	4628      	mov	r0, r5
d0081986:	f7fe fc09 	bl	d008019c <emit_phone.constprop.0>
d008198a:	4628      	mov	r0, r5
d008198c:	2300      	movs	r3, #0
d008198e:	2248      	movs	r2, #72	; 0x48
d0081990:	211c      	movs	r1, #28
d0081992:	f7fe fc03 	bl	d008019c <emit_phone.constprop.0>
d0081996:	2001      	movs	r0, #1
d0081998:	f7ff b85a 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008199c:	f8a4 c000 	strh.w	ip, [r4]
d00819a0:	f7ff ba52 	b.w	d0080e48 <emit_dictionary_word.constprop.0+0x7d0>
d00819a4:	4611      	mov	r1, r2
d00819a6:	4b3b      	ldr	r3, [pc, #236]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d00819a8:	f7ff bbad 	b.w	d0081106 <emit_dictionary_word.constprop.0+0xa8e>
d00819ac:	f8a4 c000 	strh.w	ip, [r4]
d00819b0:	e4ce      	b.n	d0081350 <emit_dictionary_word.constprop.0+0xcd8>
d00819b2:	f8a4 c000 	strh.w	ip, [r4]
d00819b6:	e55a      	b.n	d008146e <emit_dictionary_word.constprop.0+0xdf6>
d00819b8:	493a      	ldr	r1, [pc, #232]	; (d0081aa4 <emit_dictionary_word.constprop.0+0x142c>)
d00819ba:	4620      	mov	r0, r4
d00819bc:	f003 f9d0 	bl	d0084d60 <strcmp>
d00819c0:	4607      	mov	r7, r0
d00819c2:	2800      	cmp	r0, #0
d00819c4:	f000 8173 	beq.w	d0081cae <emit_dictionary_word.constprop.0+0x1636>
d00819c8:	4937      	ldr	r1, [pc, #220]	; (d0081aa8 <emit_dictionary_word.constprop.0+0x1430>)
d00819ca:	4620      	mov	r0, r4
d00819cc:	f003 f9c8 	bl	d0084d60 <strcmp>
d00819d0:	4607      	mov	r7, r0
d00819d2:	2800      	cmp	r0, #0
d00819d4:	f000 81a3 	beq.w	d0081d1e <emit_dictionary_word.constprop.0+0x16a6>
d00819d8:	4934      	ldr	r1, [pc, #208]	; (d0081aac <emit_dictionary_word.constprop.0+0x1434>)
d00819da:	4620      	mov	r0, r4
d00819dc:	f003 f9c0 	bl	d0084d60 <strcmp>
d00819e0:	4607      	mov	r7, r0
d00819e2:	2800      	cmp	r0, #0
d00819e4:	f000 8206 	beq.w	d0081df4 <emit_dictionary_word.constprop.0+0x177c>
d00819e8:	2e6f      	cmp	r6, #111	; 0x6f
d00819ea:	d165      	bne.n	d0081ab8 <emit_dictionary_word.constprop.0+0x1440>
d00819ec:	7863      	ldrb	r3, [r4, #1]
d00819ee:	2b66      	cmp	r3, #102	; 0x66
d00819f0:	d162      	bne.n	d0081ab8 <emit_dictionary_word.constprop.0+0x1440>
d00819f2:	78a3      	ldrb	r3, [r4, #2]
d00819f4:	2b00      	cmp	r3, #0
d00819f6:	d15f      	bne.n	d0081ab8 <emit_dictionary_word.constprop.0+0x1440>
d00819f8:	2240      	movs	r2, #64	; 0x40
d00819fa:	2101      	movs	r1, #1
d00819fc:	4628      	mov	r0, r5
d00819fe:	9301      	str	r3, [sp, #4]
d0081a00:	f7fe fbcc 	bl	d008019c <emit_phone.constprop.0>
d0081a04:	4628      	mov	r0, r5
d0081a06:	9b01      	ldr	r3, [sp, #4]
d0081a08:	2236      	movs	r2, #54	; 0x36
d0081a0a:	2123      	movs	r1, #35	; 0x23
d0081a0c:	f7fe fbc6 	bl	d008019c <emit_phone.constprop.0>
d0081a10:	2001      	movs	r0, #1
d0081a12:	f7ff b81d 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081a16:	4603      	mov	r3, r0
d0081a18:	223e      	movs	r2, #62	; 0x3e
d0081a1a:	2114      	movs	r1, #20
d0081a1c:	4628      	mov	r0, r5
d0081a1e:	f7fe fbbd 	bl	d008019c <emit_phone.constprop.0>
d0081a22:	2301      	movs	r3, #1
d0081a24:	2276      	movs	r2, #118	; 0x76
d0081a26:	2104      	movs	r1, #4
d0081a28:	4628      	mov	r0, r5
d0081a2a:	f7fe fbb7 	bl	d008019c <emit_phone.constprop.0>
d0081a2e:	4628      	mov	r0, r5
d0081a30:	463b      	mov	r3, r7
d0081a32:	223c      	movs	r2, #60	; 0x3c
d0081a34:	211e      	movs	r1, #30
d0081a36:	f7fe fbb1 	bl	d008019c <emit_phone.constprop.0>
d0081a3a:	2001      	movs	r0, #1
d0081a3c:	f7ff b808 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081a40:	8027      	strh	r7, [r4, #0]
d0081a42:	e65c      	b.n	d00816fe <emit_dictionary_word.constprop.0+0x1086>
d0081a44:	8021      	strh	r1, [r4, #0]
d0081a46:	e5d6      	b.n	d00815f6 <emit_dictionary_word.constprop.0+0xf7e>
d0081a48:	55d8      	strb	r0, [r3, r7]
d0081a4a:	f7ff b948 	b.w	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0081a4e:	4603      	mov	r3, r0
d0081a50:	223a      	movs	r2, #58	; 0x3a
d0081a52:	2114      	movs	r1, #20
d0081a54:	4628      	mov	r0, r5
d0081a56:	f7fe fba1 	bl	d008019c <emit_phone.constprop.0>
d0081a5a:	463b      	mov	r3, r7
d0081a5c:	2230      	movs	r2, #48	; 0x30
d0081a5e:	211e      	movs	r1, #30
d0081a60:	4628      	mov	r0, r5
d0081a62:	f7fe fb9b 	bl	d008019c <emit_phone.constprop.0>
d0081a66:	463b      	mov	r3, r7
d0081a68:	224c      	movs	r2, #76	; 0x4c
d0081a6a:	2101      	movs	r1, #1
d0081a6c:	4628      	mov	r0, r5
d0081a6e:	f7fe fb95 	bl	d008019c <emit_phone.constprop.0>
d0081a72:	4628      	mov	r0, r5
d0081a74:	463b      	mov	r3, r7
d0081a76:	2236      	movs	r2, #54	; 0x36
d0081a78:	211a      	movs	r1, #26
d0081a7a:	f7fe fb8f 	bl	d008019c <emit_phone.constprop.0>
d0081a7e:	2001      	movs	r0, #1
d0081a80:	f7fe bfe6 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081a84:	8022      	strh	r2, [r4, #0]
d0081a86:	e701      	b.n	d008188c <emit_dictionary_word.constprop.0+0x1214>
d0081a88:	4611      	mov	r1, r2
d0081a8a:	4b02      	ldr	r3, [pc, #8]	; (d0081a94 <emit_dictionary_word.constprop.0+0x141c>)
d0081a8c:	e6a9      	b.n	d00817e2 <emit_dictionary_word.constprop.0+0x116a>
d0081a8e:	bf00      	nop
d0081a90:	d00859e8 	.word	0xd00859e8
d0081a94:	d0086d88 	.word	0xd0086d88
d0081a98:	d0086188 	.word	0xd0086188
d0081a9c:	d0087588 	.word	0xd0087588
d0081aa0:	d00859a0 	.word	0xd00859a0
d0081aa4:	d0085a34 	.word	0xd0085a34
d0081aa8:	d0085a40 	.word	0xd0085a40
d0081aac:	d0085a4c 	.word	0xd0085a4c
d0081ab0:	f803 e00c 	strb.w	lr, [r3, ip]
d0081ab4:	f7fe bf2e 	b.w	d0080914 <emit_dictionary_word.constprop.0+0x29c>
d0081ab8:	49de      	ldr	r1, [pc, #888]	; (d0081e34 <emit_dictionary_word.constprop.0+0x17bc>)
d0081aba:	4620      	mov	r0, r4
d0081abc:	f003 f950 	bl	d0084d60 <strcmp>
d0081ac0:	4606      	mov	r6, r0
d0081ac2:	2800      	cmp	r0, #0
d0081ac4:	f000 81f6 	beq.w	d0081eb4 <emit_dictionary_word.constprop.0+0x183c>
d0081ac8:	49db      	ldr	r1, [pc, #876]	; (d0081e38 <emit_dictionary_word.constprop.0+0x17c0>)
d0081aca:	4620      	mov	r0, r4
d0081acc:	f003 f948 	bl	d0084d60 <strcmp>
d0081ad0:	2800      	cmp	r0, #0
d0081ad2:	f000 815b 	beq.w	d0081d8c <emit_dictionary_word.constprop.0+0x1714>
d0081ad6:	49d9      	ldr	r1, [pc, #868]	; (d0081e3c <emit_dictionary_word.constprop.0+0x17c4>)
d0081ad8:	4620      	mov	r0, r4
d0081ada:	f003 f941 	bl	d0084d60 <strcmp>
d0081ade:	2800      	cmp	r0, #0
d0081ae0:	f000 8154 	beq.w	d0081d8c <emit_dictionary_word.constprop.0+0x1714>
d0081ae4:	49d6      	ldr	r1, [pc, #856]	; (d0081e40 <emit_dictionary_word.constprop.0+0x17c8>)
d0081ae6:	4620      	mov	r0, r4
d0081ae8:	f003 f93a 	bl	d0084d60 <strcmp>
d0081aec:	4606      	mov	r6, r0
d0081aee:	2800      	cmp	r0, #0
d0081af0:	f000 8248 	beq.w	d0081f84 <emit_dictionary_word.constprop.0+0x190c>
d0081af4:	49d3      	ldr	r1, [pc, #844]	; (d0081e44 <emit_dictionary_word.constprop.0+0x17cc>)
d0081af6:	4620      	mov	r0, r4
d0081af8:	f003 f932 	bl	d0084d60 <strcmp>
d0081afc:	4606      	mov	r6, r0
d0081afe:	2800      	cmp	r0, #0
d0081b00:	f000 826d 	beq.w	d0081fde <emit_dictionary_word.constprop.0+0x1966>
d0081b04:	49d0      	ldr	r1, [pc, #832]	; (d0081e48 <emit_dictionary_word.constprop.0+0x17d0>)
d0081b06:	4620      	mov	r0, r4
d0081b08:	f003 f92a 	bl	d0084d60 <strcmp>
d0081b0c:	2800      	cmp	r0, #0
d0081b0e:	f000 81e6 	beq.w	d0081ede <emit_dictionary_word.constprop.0+0x1866>
d0081b12:	49ce      	ldr	r1, [pc, #824]	; (d0081e4c <emit_dictionary_word.constprop.0+0x17d4>)
d0081b14:	4620      	mov	r0, r4
d0081b16:	f003 f923 	bl	d0084d60 <strcmp>
d0081b1a:	2800      	cmp	r0, #0
d0081b1c:	f000 81df 	beq.w	d0081ede <emit_dictionary_word.constprop.0+0x1866>
d0081b20:	49cb      	ldr	r1, [pc, #812]	; (d0081e50 <emit_dictionary_word.constprop.0+0x17d8>)
d0081b22:	4620      	mov	r0, r4
d0081b24:	f003 f91c 	bl	d0084d60 <strcmp>
d0081b28:	4606      	mov	r6, r0
d0081b2a:	2800      	cmp	r0, #0
d0081b2c:	f000 8284 	beq.w	d0082038 <emit_dictionary_word.constprop.0+0x19c0>
d0081b30:	49c8      	ldr	r1, [pc, #800]	; (d0081e54 <emit_dictionary_word.constprop.0+0x17dc>)
d0081b32:	4620      	mov	r0, r4
d0081b34:	f003 f914 	bl	d0084d60 <strcmp>
d0081b38:	2800      	cmp	r0, #0
d0081b3a:	f000 81f5 	beq.w	d0081f28 <emit_dictionary_word.constprop.0+0x18b0>
d0081b3e:	49c6      	ldr	r1, [pc, #792]	; (d0081e58 <emit_dictionary_word.constprop.0+0x17e0>)
d0081b40:	4620      	mov	r0, r4
d0081b42:	f003 f90d 	bl	d0084d60 <strcmp>
d0081b46:	2800      	cmp	r0, #0
d0081b48:	f000 81ee 	beq.w	d0081f28 <emit_dictionary_word.constprop.0+0x18b0>
d0081b4c:	49c3      	ldr	r1, [pc, #780]	; (d0081e5c <emit_dictionary_word.constprop.0+0x17e4>)
d0081b4e:	4620      	mov	r0, r4
d0081b50:	f003 f906 	bl	d0084d60 <strcmp>
d0081b54:	2800      	cmp	r0, #0
d0081b56:	f000 81e7 	beq.w	d0081f28 <emit_dictionary_word.constprop.0+0x18b0>
d0081b5a:	49c1      	ldr	r1, [pc, #772]	; (d0081e60 <emit_dictionary_word.constprop.0+0x17e8>)
d0081b5c:	4620      	mov	r0, r4
d0081b5e:	f003 f8ff 	bl	d0084d60 <strcmp>
d0081b62:	4606      	mov	r6, r0
d0081b64:	2800      	cmp	r0, #0
d0081b66:	f000 8282 	beq.w	d008206e <emit_dictionary_word.constprop.0+0x19f6>
d0081b6a:	49be      	ldr	r1, [pc, #760]	; (d0081e64 <emit_dictionary_word.constprop.0+0x17ec>)
d0081b6c:	4620      	mov	r0, r4
d0081b6e:	f003 f8f7 	bl	d0084d60 <strcmp>
d0081b72:	4606      	mov	r6, r0
d0081b74:	2800      	cmp	r0, #0
d0081b76:	f000 8385 	beq.w	d0082284 <emit_dictionary_word.constprop.0+0x1c0c>
d0081b7a:	49bb      	ldr	r1, [pc, #748]	; (d0081e68 <emit_dictionary_word.constprop.0+0x17f0>)
d0081b7c:	4620      	mov	r0, r4
d0081b7e:	f003 f8ef 	bl	d0084d60 <strcmp>
d0081b82:	2800      	cmp	r0, #0
d0081b84:	f000 8349 	beq.w	d008221a <emit_dictionary_word.constprop.0+0x1ba2>
d0081b88:	49b8      	ldr	r1, [pc, #736]	; (d0081e6c <emit_dictionary_word.constprop.0+0x17f4>)
d0081b8a:	4620      	mov	r0, r4
d0081b8c:	f003 f8e8 	bl	d0084d60 <strcmp>
d0081b90:	2800      	cmp	r0, #0
d0081b92:	f000 8342 	beq.w	d008221a <emit_dictionary_word.constprop.0+0x1ba2>
d0081b96:	49b6      	ldr	r1, [pc, #728]	; (d0081e70 <emit_dictionary_word.constprop.0+0x17f8>)
d0081b98:	4620      	mov	r0, r4
d0081b9a:	f003 f8e1 	bl	d0084d60 <strcmp>
d0081b9e:	4606      	mov	r6, r0
d0081ba0:	2800      	cmp	r0, #0
d0081ba2:	f000 8325 	beq.w	d00821f0 <emit_dictionary_word.constprop.0+0x1b78>
d0081ba6:	49b3      	ldr	r1, [pc, #716]	; (d0081e74 <emit_dictionary_word.constprop.0+0x17fc>)
d0081ba8:	4620      	mov	r0, r4
d0081baa:	f003 f8d9 	bl	d0084d60 <strcmp>
d0081bae:	4603      	mov	r3, r0
d0081bb0:	2800      	cmp	r0, #0
d0081bb2:	f000 830e 	beq.w	d00821d2 <emit_dictionary_word.constprop.0+0x1b5a>
d0081bb6:	49b0      	ldr	r1, [pc, #704]	; (d0081e78 <emit_dictionary_word.constprop.0+0x1800>)
d0081bb8:	4620      	mov	r0, r4
d0081bba:	f003 f8d1 	bl	d0084d60 <strcmp>
d0081bbe:	4603      	mov	r3, r0
d0081bc0:	2800      	cmp	r0, #0
d0081bc2:	f000 82f1 	beq.w	d00821a8 <emit_dictionary_word.constprop.0+0x1b30>
d0081bc6:	49ad      	ldr	r1, [pc, #692]	; (d0081e7c <emit_dictionary_word.constprop.0+0x1804>)
d0081bc8:	4620      	mov	r0, r4
d0081bca:	f003 f8c9 	bl	d0084d60 <strcmp>
d0081bce:	4606      	mov	r6, r0
d0081bd0:	2800      	cmp	r0, #0
d0081bd2:	f43e af2a 	beq.w	d0080a2a <emit_dictionary_word.constprop.0+0x3b2>
d0081bd6:	49aa      	ldr	r1, [pc, #680]	; (d0081e80 <emit_dictionary_word.constprop.0+0x1808>)
d0081bd8:	4620      	mov	r0, r4
d0081bda:	f003 f8c1 	bl	d0084d60 <strcmp>
d0081bde:	2800      	cmp	r0, #0
d0081be0:	f000 82d3 	beq.w	d008218a <emit_dictionary_word.constprop.0+0x1b12>
d0081be4:	49a7      	ldr	r1, [pc, #668]	; (d0081e84 <emit_dictionary_word.constprop.0+0x180c>)
d0081be6:	4620      	mov	r0, r4
d0081be8:	f003 f8ba 	bl	d0084d60 <strcmp>
d0081bec:	2800      	cmp	r0, #0
d0081bee:	f000 82cc 	beq.w	d008218a <emit_dictionary_word.constprop.0+0x1b12>
d0081bf2:	49a5      	ldr	r1, [pc, #660]	; (d0081e88 <emit_dictionary_word.constprop.0+0x1810>)
d0081bf4:	4620      	mov	r0, r4
d0081bf6:	f003 f8b3 	bl	d0084d60 <strcmp>
d0081bfa:	2800      	cmp	r0, #0
d0081bfc:	f000 82c5 	beq.w	d008218a <emit_dictionary_word.constprop.0+0x1b12>
d0081c00:	49a2      	ldr	r1, [pc, #648]	; (d0081e8c <emit_dictionary_word.constprop.0+0x1814>)
d0081c02:	4620      	mov	r0, r4
d0081c04:	f003 f8ac 	bl	d0084d60 <strcmp>
d0081c08:	4606      	mov	r6, r0
d0081c0a:	2800      	cmp	r0, #0
d0081c0c:	f000 82a8 	beq.w	d0082160 <emit_dictionary_word.constprop.0+0x1ae8>
d0081c10:	499f      	ldr	r1, [pc, #636]	; (d0081e90 <emit_dictionary_word.constprop.0+0x1818>)
d0081c12:	4620      	mov	r0, r4
d0081c14:	f003 f8a4 	bl	d0084d60 <strcmp>
d0081c18:	4603      	mov	r3, r0
d0081c1a:	2800      	cmp	r0, #0
d0081c1c:	f000 828b 	beq.w	d0082136 <emit_dictionary_word.constprop.0+0x1abe>
d0081c20:	499c      	ldr	r1, [pc, #624]	; (d0081e94 <emit_dictionary_word.constprop.0+0x181c>)
d0081c22:	4620      	mov	r0, r4
d0081c24:	f003 f89c 	bl	d0084d60 <strcmp>
d0081c28:	4603      	mov	r3, r0
d0081c2a:	2800      	cmp	r0, #0
d0081c2c:	f000 8275 	beq.w	d008211a <emit_dictionary_word.constprop.0+0x1aa2>
d0081c30:	4999      	ldr	r1, [pc, #612]	; (d0081e98 <emit_dictionary_word.constprop.0+0x1820>)
d0081c32:	4620      	mov	r0, r4
d0081c34:	f003 f894 	bl	d0084d60 <strcmp>
d0081c38:	4603      	mov	r3, r0
d0081c3a:	2800      	cmp	r0, #0
d0081c3c:	f000 825f 	beq.w	d00820fe <emit_dictionary_word.constprop.0+0x1a86>
d0081c40:	4620      	mov	r0, r4
d0081c42:	4996      	ldr	r1, [pc, #600]	; (d0081e9c <emit_dictionary_word.constprop.0+0x1824>)
d0081c44:	f003 f88c 	bl	d0084d60 <strcmp>
d0081c48:	4603      	mov	r3, r0
d0081c4a:	2800      	cmp	r0, #0
d0081c4c:	f000 823c 	beq.w	d00820c8 <emit_dictionary_word.constprop.0+0x1a50>
d0081c50:	2000      	movs	r0, #0
d0081c52:	f7fe befd 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081c56:	460a      	mov	r2, r1
d0081c58:	4b91      	ldr	r3, [pc, #580]	; (d0081ea0 <emit_dictionary_word.constprop.0+0x1828>)
d0081c5a:	e62b      	b.n	d00818b4 <emit_dictionary_word.constprop.0+0x123c>
d0081c5c:	f803 c001 	strb.w	ip, [r3, r1]
d0081c60:	f7ff b83d 	b.w	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0081c64:	f803 c001 	strb.w	ip, [r3, r1]
d0081c68:	f7fe bfb8 	b.w	d0080bdc <emit_dictionary_word.constprop.0+0x564>
d0081c6c:	4603      	mov	r3, r0
d0081c6e:	222d      	movs	r2, #45	; 0x2d
d0081c70:	2116      	movs	r1, #22
d0081c72:	4628      	mov	r0, r5
d0081c74:	f7fe fa92 	bl	d008019c <emit_phone.constprop.0>
d0081c78:	463b      	mov	r3, r7
d0081c7a:	225a      	movs	r2, #90	; 0x5a
d0081c7c:	2105      	movs	r1, #5
d0081c7e:	4628      	mov	r0, r5
d0081c80:	f7fe fa8c 	bl	d008019c <emit_phone.constprop.0>
d0081c84:	463b      	mov	r3, r7
d0081c86:	2237      	movs	r2, #55	; 0x37
d0081c88:	2119      	movs	r1, #25
d0081c8a:	4628      	mov	r0, r5
d0081c8c:	f7fe fa86 	bl	d008019c <emit_phone.constprop.0>
d0081c90:	4628      	mov	r0, r5
d0081c92:	2301      	movs	r3, #1
d0081c94:	2287      	movs	r2, #135	; 0x87
d0081c96:	210d      	movs	r1, #13
d0081c98:	f7fe fa80 	bl	d008019c <emit_phone.constprop.0>
d0081c9c:	2001      	movs	r0, #1
d0081c9e:	f7fe bed7 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081ca2:	4b7f      	ldr	r3, [pc, #508]	; (d0081ea0 <emit_dictionary_word.constprop.0+0x1828>)
d0081ca4:	4610      	mov	r0, r2
d0081ca6:	f803 c002 	strb.w	ip, [r3, r2]
d0081caa:	f7fe bd99 	b.w	d00807e0 <emit_dictionary_word.constprop.0+0x168>
d0081cae:	4603      	mov	r3, r0
d0081cb0:	2238      	movs	r2, #56	; 0x38
d0081cb2:	211a      	movs	r1, #26
d0081cb4:	4628      	mov	r0, r5
d0081cb6:	f7fe fa71 	bl	d008019c <emit_phone.constprop.0>
d0081cba:	2301      	movs	r3, #1
d0081cbc:	2269      	movs	r2, #105	; 0x69
d0081cbe:	2102      	movs	r1, #2
d0081cc0:	4628      	mov	r0, r5
d0081cc2:	f7fe fa6b 	bl	d008019c <emit_phone.constprop.0>
d0081cc6:	463b      	mov	r3, r7
d0081cc8:	2230      	movs	r2, #48	; 0x30
d0081cca:	2118      	movs	r1, #24
d0081ccc:	4628      	mov	r0, r5
d0081cce:	f7fe fa65 	bl	d008019c <emit_phone.constprop.0>
d0081cd2:	463b      	mov	r3, r7
d0081cd4:	2246      	movs	r2, #70	; 0x46
d0081cd6:	2107      	movs	r1, #7
d0081cd8:	4628      	mov	r0, r5
d0081cda:	f7fe fa5f 	bl	d008019c <emit_phone.constprop.0>
d0081cde:	463b      	mov	r3, r7
d0081ce0:	2232      	movs	r2, #50	; 0x32
d0081ce2:	211b      	movs	r1, #27
d0081ce4:	4628      	mov	r0, r5
d0081ce6:	f7fe fa59 	bl	d008019c <emit_phone.constprop.0>
d0081cea:	463b      	mov	r3, r7
d0081cec:	222d      	movs	r2, #45	; 0x2d
d0081cee:	2121      	movs	r1, #33	; 0x21
d0081cf0:	4628      	mov	r0, r5
d0081cf2:	f7fe fa53 	bl	d008019c <emit_phone.constprop.0>
d0081cf6:	463b      	mov	r3, r7
d0081cf8:	225c      	movs	r2, #92	; 0x5c
d0081cfa:	2103      	movs	r1, #3
d0081cfc:	4628      	mov	r0, r5
d0081cfe:	f7fe fa4d 	bl	d008019c <emit_phone.constprop.0>
d0081d02:	4628      	mov	r0, r5
d0081d04:	463b      	mov	r3, r7
d0081d06:	224e      	movs	r2, #78	; 0x4e
d0081d08:	2120      	movs	r1, #32
d0081d0a:	f7fe fa47 	bl	d008019c <emit_phone.constprop.0>
d0081d0e:	2001      	movs	r0, #1
d0081d10:	f7fe be9e 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081d14:	4b62      	ldr	r3, [pc, #392]	; (d0081ea0 <emit_dictionary_word.constprop.0+0x1828>)
d0081d16:	4617      	mov	r7, r2
d0081d18:	5498      	strb	r0, [r3, r2]
d0081d1a:	f7ff b860 	b.w	d0080dde <emit_dictionary_word.constprop.0+0x766>
d0081d1e:	4603      	mov	r3, r0
d0081d20:	2236      	movs	r2, #54	; 0x36
d0081d22:	211b      	movs	r1, #27
d0081d24:	4628      	mov	r0, r5
d0081d26:	f7fe fa39 	bl	d008019c <emit_phone.constprop.0>
d0081d2a:	2301      	movs	r3, #1
d0081d2c:	2258      	movs	r2, #88	; 0x58
d0081d2e:	2102      	movs	r1, #2
d0081d30:	4628      	mov	r0, r5
d0081d32:	f7fe fa33 	bl	d008019c <emit_phone.constprop.0>
d0081d36:	463b      	mov	r3, r7
d0081d38:	2236      	movs	r2, #54	; 0x36
d0081d3a:	211e      	movs	r1, #30
d0081d3c:	4628      	mov	r0, r5
d0081d3e:	f7fe fa2d 	bl	d008019c <emit_phone.constprop.0>
d0081d42:	463b      	mov	r3, r7
d0081d44:	224e      	movs	r2, #78	; 0x4e
d0081d46:	210b      	movs	r1, #11
d0081d48:	4628      	mov	r0, r5
d0081d4a:	f7fe fa27 	bl	d008019c <emit_phone.constprop.0>
d0081d4e:	463b      	mov	r3, r7
d0081d50:	222a      	movs	r2, #42	; 0x2a
d0081d52:	2121      	movs	r1, #33	; 0x21
d0081d54:	4628      	mov	r0, r5
d0081d56:	f7fe fa21 	bl	d008019c <emit_phone.constprop.0>
d0081d5a:	4628      	mov	r0, r5
d0081d5c:	463b      	mov	r3, r7
d0081d5e:	226e      	movs	r2, #110	; 0x6e
d0081d60:	2106      	movs	r1, #6
d0081d62:	f7fe fa1b 	bl	d008019c <emit_phone.constprop.0>
d0081d66:	2001      	movs	r0, #1
d0081d68:	f7fe be72 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081d6c:	f803 c002 	strb.w	ip, [r3, r2]
d0081d70:	f7ff b8d6 	b.w	d0080f20 <emit_dictionary_word.constprop.0+0x8a8>
d0081d74:	f803 c000 	strb.w	ip, [r3, r0]
d0081d78:	f7ff b924 	b.w	d0080fc4 <emit_dictionary_word.constprop.0+0x94c>
d0081d7c:	f803 c002 	strb.w	ip, [r3, r2]
d0081d80:	f7ff b888 	b.w	d0080e94 <emit_dictionary_word.constprop.0+0x81c>
d0081d84:	f803 c002 	strb.w	ip, [r3, r2]
d0081d88:	f7ff b8a7 	b.w	d0080eda <emit_dictionary_word.constprop.0+0x862>
d0081d8c:	2300      	movs	r3, #0
d0081d8e:	223e      	movs	r2, #62	; 0x3e
d0081d90:	2114      	movs	r1, #20
d0081d92:	4628      	mov	r0, r5
d0081d94:	f7fe fa02 	bl	d008019c <emit_phone.constprop.0>
d0081d98:	2301      	movs	r3, #1
d0081d9a:	226c      	movs	r2, #108	; 0x6c
d0081d9c:	210d      	movs	r1, #13
d0081d9e:	4628      	mov	r0, r5
d0081da0:	f7fe f9fc 	bl	d008019c <emit_phone.constprop.0>
d0081da4:	2300      	movs	r3, #0
d0081da6:	2234      	movs	r2, #52	; 0x34
d0081da8:	211b      	movs	r1, #27
d0081daa:	4628      	mov	r0, r5
d0081dac:	f7fe f9f6 	bl	d008019c <emit_phone.constprop.0>
d0081db0:	2300      	movs	r3, #0
d0081db2:	2264      	movs	r2, #100	; 0x64
d0081db4:	2108      	movs	r1, #8
d0081db6:	4628      	mov	r0, r5
d0081db8:	f7fe f9f0 	bl	d008019c <emit_phone.constprop.0>
d0081dbc:	2300      	movs	r3, #0
d0081dbe:	223a      	movs	r2, #58	; 0x3a
d0081dc0:	211a      	movs	r1, #26
d0081dc2:	4628      	mov	r0, r5
d0081dc4:	f7fe f9ea 	bl	d008019c <emit_phone.constprop.0>
d0081dc8:	79e3      	ldrb	r3, [r4, #7]
d0081dca:	2b73      	cmp	r3, #115	; 0x73
d0081dcc:	f47e ae3f 	bne.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081dd0:	4628      	mov	r0, r5
d0081dd2:	2300      	movs	r3, #0
d0081dd4:	2236      	movs	r2, #54	; 0x36
d0081dd6:	2126      	movs	r1, #38	; 0x26
d0081dd8:	f7fe f9e0 	bl	d008019c <emit_phone.constprop.0>
d0081ddc:	2001      	movs	r0, #1
d0081dde:	f7fe be37 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081de2:	f803 c007 	strb.w	ip, [r3, r7]
d0081de6:	f7fe bf7a 	b.w	d0080cde <emit_dictionary_word.constprop.0+0x666>
d0081dea:	4b2d      	ldr	r3, [pc, #180]	; (d0081ea0 <emit_dictionary_word.constprop.0+0x1828>)
d0081dec:	4617      	mov	r7, r2
d0081dee:	5498      	strb	r0, [r3, r2]
d0081df0:	f7ff ba74 	b.w	d00812dc <emit_dictionary_word.constprop.0+0xc64>
d0081df4:	4603      	mov	r3, r0
d0081df6:	223a      	movs	r2, #58	; 0x3a
d0081df8:	211b      	movs	r1, #27
d0081dfa:	4628      	mov	r0, r5
d0081dfc:	f7fe f9ce 	bl	d008019c <emit_phone.constprop.0>
d0081e00:	2301      	movs	r3, #1
d0081e02:	2248      	movs	r2, #72	; 0x48
d0081e04:	210c      	movs	r1, #12
d0081e06:	4628      	mov	r0, r5
d0081e08:	f7fe f9c8 	bl	d008019c <emit_phone.constprop.0>
d0081e0c:	463b      	mov	r3, r7
d0081e0e:	223c      	movs	r2, #60	; 0x3c
d0081e10:	2108      	movs	r1, #8
d0081e12:	4628      	mov	r0, r5
d0081e14:	f7fe f9c2 	bl	d008019c <emit_phone.constprop.0>
d0081e18:	4628      	mov	r0, r5
d0081e1a:	463b      	mov	r3, r7
d0081e1c:	223a      	movs	r2, #58	; 0x3a
d0081e1e:	211b      	movs	r1, #27
d0081e20:	f7fe f9bc 	bl	d008019c <emit_phone.constprop.0>
d0081e24:	2001      	movs	r0, #1
d0081e26:	f7fe be13 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081e2a:	f803 e002 	strb.w	lr, [r3, r2]
d0081e2e:	f7ff bab5 	b.w	d008139c <emit_dictionary_word.constprop.0+0xd24>
d0081e32:	bf00      	nop
d0081e34:	d0085a54 	.word	0xd0085a54
d0081e38:	d0085a58 	.word	0xd0085a58
d0081e3c:	d0085a60 	.word	0xd0085a60
d0081e40:	d0085a6c 	.word	0xd0085a6c
d0081e44:	d0085a74 	.word	0xd0085a74
d0081e48:	d0085a7c 	.word	0xd0085a7c
d0081e4c:	d0085a84 	.word	0xd0085a84
d0081e50:	d0085a8c 	.word	0xd0085a8c
d0081e54:	d0085a94 	.word	0xd0085a94
d0081e58:	d0085a9c 	.word	0xd0085a9c
d0081e5c:	d0085aa4 	.word	0xd0085aa4
d0081e60:	d0085aac 	.word	0xd0085aac
d0081e64:	d0085ab4 	.word	0xd0085ab4
d0081e68:	d0085ab8 	.word	0xd0085ab8
d0081e6c:	d0085ac0 	.word	0xd0085ac0
d0081e70:	d0085acc 	.word	0xd0085acc
d0081e74:	d0085ad4 	.word	0xd0085ad4
d0081e78:	d0085ad8 	.word	0xd0085ad8
d0081e7c:	d0085ae0 	.word	0xd0085ae0
d0081e80:	d0085ae8 	.word	0xd0085ae8
d0081e84:	d0085aec 	.word	0xd0085aec
d0081e88:	d0085af0 	.word	0xd0085af0
d0081e8c:	d0085af4 	.word	0xd0085af4
d0081e90:	d0085afc 	.word	0xd0085afc
d0081e94:	d0085b00 	.word	0xd0085b00
d0081e98:	d0085b04 	.word	0xd0085b04
d0081e9c:	d0085b0c 	.word	0xd0085b0c
d0081ea0:	d0086d88 	.word	0xd0086d88
d0081ea4:	f803 c002 	strb.w	ip, [r3, r2]
d0081ea8:	f7ff bbec 	b.w	d0081684 <emit_dictionary_word.constprop.0+0x100c>
d0081eac:	f803 c002 	strb.w	ip, [r3, r2]
d0081eb0:	f7ff bbc5 	b.w	d008163e <emit_dictionary_word.constprop.0+0xfc6>
d0081eb4:	4603      	mov	r3, r0
d0081eb6:	2234      	movs	r2, #52	; 0x34
d0081eb8:	2124      	movs	r1, #36	; 0x24
d0081eba:	4628      	mov	r0, r5
d0081ebc:	f7fe f96e 	bl	d008019c <emit_phone.constprop.0>
d0081ec0:	2301      	movs	r3, #1
d0081ec2:	2270      	movs	r2, #112	; 0x70
d0081ec4:	4628      	mov	r0, r5
d0081ec6:	4619      	mov	r1, r3
d0081ec8:	f7fe f968 	bl	d008019c <emit_phone.constprop.0>
d0081ecc:	4628      	mov	r0, r5
d0081ece:	4633      	mov	r3, r6
d0081ed0:	2238      	movs	r2, #56	; 0x38
d0081ed2:	211b      	movs	r1, #27
d0081ed4:	f7fe f962 	bl	d008019c <emit_phone.constprop.0>
d0081ed8:	2001      	movs	r0, #1
d0081eda:	f7fe bdb9 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081ede:	2300      	movs	r3, #0
d0081ee0:	223a      	movs	r2, #58	; 0x3a
d0081ee2:	211f      	movs	r1, #31
d0081ee4:	4628      	mov	r0, r5
d0081ee6:	f7fe f959 	bl	d008019c <emit_phone.constprop.0>
d0081eea:	2300      	movs	r3, #0
d0081eec:	2230      	movs	r2, #48	; 0x30
d0081eee:	211d      	movs	r1, #29
d0081ef0:	4628      	mov	r0, r5
d0081ef2:	f7fe f953 	bl	d008019c <emit_phone.constprop.0>
d0081ef6:	2301      	movs	r3, #1
d0081ef8:	227c      	movs	r2, #124	; 0x7c
d0081efa:	2108      	movs	r1, #8
d0081efc:	4628      	mov	r0, r5
d0081efe:	f7fe f94d 	bl	d008019c <emit_phone.constprop.0>
d0081f02:	2300      	movs	r3, #0
d0081f04:	2232      	movs	r2, #50	; 0x32
d0081f06:	2118      	movs	r1, #24
d0081f08:	4628      	mov	r0, r5
d0081f0a:	f7fe f947 	bl	d008019c <emit_phone.constprop.0>
d0081f0e:	7963      	ldrb	r3, [r4, #5]
d0081f10:	2b73      	cmp	r3, #115	; 0x73
d0081f12:	f47e ad9c 	bne.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081f16:	4628      	mov	r0, r5
d0081f18:	2300      	movs	r3, #0
d0081f1a:	2236      	movs	r2, #54	; 0x36
d0081f1c:	211f      	movs	r1, #31
d0081f1e:	f7fe f93d 	bl	d008019c <emit_phone.constprop.0>
d0081f22:	2001      	movs	r0, #1
d0081f24:	f7fe bd94 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081f28:	2300      	movs	r3, #0
d0081f2a:	223a      	movs	r2, #58	; 0x3a
d0081f2c:	211f      	movs	r1, #31
d0081f2e:	4628      	mov	r0, r5
d0081f30:	f7fe f934 	bl	d008019c <emit_phone.constprop.0>
d0081f34:	2300      	movs	r3, #0
d0081f36:	222a      	movs	r2, #42	; 0x2a
d0081f38:	2121      	movs	r1, #33	; 0x21
d0081f3a:	4628      	mov	r0, r5
d0081f3c:	f7fe f92e 	bl	d008019c <emit_phone.constprop.0>
d0081f40:	2301      	movs	r3, #1
d0081f42:	2276      	movs	r2, #118	; 0x76
d0081f44:	2108      	movs	r1, #8
d0081f46:	4628      	mov	r0, r5
d0081f48:	f7fe f928 	bl	d008019c <emit_phone.constprop.0>
d0081f4c:	2123      	movs	r1, #35	; 0x23
d0081f4e:	4628      	mov	r0, r5
d0081f50:	2300      	movs	r3, #0
d0081f52:	2237      	movs	r2, #55	; 0x37
d0081f54:	f7fe f922 	bl	d008019c <emit_phone.constprop.0>
d0081f58:	4620      	mov	r0, r4
d0081f5a:	49d8      	ldr	r1, [pc, #864]	; (d00822bc <emit_dictionary_word.constprop.0+0x1c44>)
d0081f5c:	f002 ff00 	bl	d0084d60 <strcmp>
d0081f60:	2800      	cmp	r0, #0
d0081f62:	f43e ad74 	beq.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d0081f66:	2300      	movs	r3, #0
d0081f68:	2241      	movs	r2, #65	; 0x41
d0081f6a:	2101      	movs	r1, #1
d0081f6c:	4628      	mov	r0, r5
d0081f6e:	f7fe f915 	bl	d008019c <emit_phone.constprop.0>
d0081f72:	4628      	mov	r0, r5
d0081f74:	2300      	movs	r3, #0
d0081f76:	2236      	movs	r2, #54	; 0x36
d0081f78:	211b      	movs	r1, #27
d0081f7a:	f7fe f90f 	bl	d008019c <emit_phone.constprop.0>
d0081f7e:	2001      	movs	r0, #1
d0081f80:	f7fe bd66 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081f84:	4603      	mov	r3, r0
d0081f86:	2236      	movs	r2, #54	; 0x36
d0081f88:	2118      	movs	r1, #24
d0081f8a:	4628      	mov	r0, r5
d0081f8c:	f7fe f906 	bl	d008019c <emit_phone.constprop.0>
d0081f90:	4633      	mov	r3, r6
d0081f92:	222a      	movs	r2, #42	; 0x2a
d0081f94:	2124      	movs	r1, #36	; 0x24
d0081f96:	4628      	mov	r0, r5
d0081f98:	f7fe f900 	bl	d008019c <emit_phone.constprop.0>
d0081f9c:	2301      	movs	r3, #1
d0081f9e:	2269      	movs	r2, #105	; 0x69
d0081fa0:	2103      	movs	r1, #3
d0081fa2:	4628      	mov	r0, r5
d0081fa4:	f7fe f8fa 	bl	d008019c <emit_phone.constprop.0>
d0081fa8:	4633      	mov	r3, r6
d0081faa:	222d      	movs	r2, #45	; 0x2d
d0081fac:	2119      	movs	r1, #25
d0081fae:	4628      	mov	r0, r5
d0081fb0:	f7fe f8f4 	bl	d008019c <emit_phone.constprop.0>
d0081fb4:	4633      	mov	r3, r6
d0081fb6:	2237      	movs	r2, #55	; 0x37
d0081fb8:	2107      	movs	r1, #7
d0081fba:	4628      	mov	r0, r5
d0081fbc:	f7fe f8ee 	bl	d008019c <emit_phone.constprop.0>
d0081fc0:	4633      	mov	r3, r6
d0081fc2:	2228      	movs	r2, #40	; 0x28
d0081fc4:	2121      	movs	r1, #33	; 0x21
d0081fc6:	4628      	mov	r0, r5
d0081fc8:	f7fe f8e8 	bl	d008019c <emit_phone.constprop.0>
d0081fcc:	4628      	mov	r0, r5
d0081fce:	4633      	mov	r3, r6
d0081fd0:	224b      	movs	r2, #75	; 0x4b
d0081fd2:	2108      	movs	r1, #8
d0081fd4:	f7fe f8e2 	bl	d008019c <emit_phone.constprop.0>
d0081fd8:	2001      	movs	r0, #1
d0081fda:	f7fe bd39 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0081fde:	4603      	mov	r3, r0
d0081fe0:	2246      	movs	r2, #70	; 0x46
d0081fe2:	211f      	movs	r1, #31
d0081fe4:	4628      	mov	r0, r5
d0081fe6:	f7fe f8d9 	bl	d008019c <emit_phone.constprop.0>
d0081fea:	2301      	movs	r3, #1
d0081fec:	2262      	movs	r2, #98	; 0x62
d0081fee:	2107      	movs	r1, #7
d0081ff0:	4628      	mov	r0, r5
d0081ff2:	f7fe f8d3 	bl	d008019c <emit_phone.constprop.0>
d0081ff6:	4633      	mov	r3, r6
d0081ff8:	222d      	movs	r2, #45	; 0x2d
d0081ffa:	2112      	movs	r1, #18
d0081ffc:	4628      	mov	r0, r5
d0081ffe:	f7fe f8cd 	bl	d008019c <emit_phone.constprop.0>
d0082002:	4633      	mov	r3, r6
d0082004:	2237      	movs	r2, #55	; 0x37
d0082006:	2110      	movs	r1, #16
d0082008:	4628      	mov	r0, r5
d008200a:	f7fe f8c7 	bl	d008019c <emit_phone.constprop.0>
d008200e:	4633      	mov	r3, r6
d0082010:	2264      	movs	r2, #100	; 0x64
d0082012:	2103      	movs	r1, #3
d0082014:	4628      	mov	r0, r5
d0082016:	f7fe f8c1 	bl	d008019c <emit_phone.constprop.0>
d008201a:	4633      	mov	r3, r6
d008201c:	2232      	movs	r2, #50	; 0x32
d008201e:	2118      	movs	r1, #24
d0082020:	4628      	mov	r0, r5
d0082022:	f7fe f8bb 	bl	d008019c <emit_phone.constprop.0>
d0082026:	4628      	mov	r0, r5
d0082028:	4633      	mov	r3, r6
d008202a:	223e      	movs	r2, #62	; 0x3e
d008202c:	211f      	movs	r1, #31
d008202e:	f7fe f8b5 	bl	d008019c <emit_phone.constprop.0>
d0082032:	2001      	movs	r0, #1
d0082034:	f7fe bd0c 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0082038:	4603      	mov	r3, r0
d008203a:	223e      	movs	r2, #62	; 0x3e
d008203c:	211f      	movs	r1, #31
d008203e:	4628      	mov	r0, r5
d0082040:	f7fe f8ac 	bl	d008019c <emit_phone.constprop.0>
d0082044:	4633      	mov	r3, r6
d0082046:	2230      	movs	r2, #48	; 0x30
d0082048:	211d      	movs	r1, #29
d008204a:	4628      	mov	r0, r5
d008204c:	f7fe f8a6 	bl	d008019c <emit_phone.constprop.0>
d0082050:	2301      	movs	r3, #1
d0082052:	2278      	movs	r2, #120	; 0x78
d0082054:	2108      	movs	r1, #8
d0082056:	4628      	mov	r0, r5
d0082058:	f7fe f8a0 	bl	d008019c <emit_phone.constprop.0>
d008205c:	4628      	mov	r0, r5
d008205e:	4633      	mov	r3, r6
d0082060:	2250      	movs	r2, #80	; 0x50
d0082062:	2111      	movs	r1, #17
d0082064:	f7fe f89a 	bl	d008019c <emit_phone.constprop.0>
d0082068:	2001      	movs	r0, #1
d008206a:	f7fe bcf1 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008206e:	4603      	mov	r3, r0
d0082070:	223e      	movs	r2, #62	; 0x3e
d0082072:	211f      	movs	r1, #31
d0082074:	4628      	mov	r0, r5
d0082076:	f7fe f891 	bl	d008019c <emit_phone.constprop.0>
d008207a:	2301      	movs	r3, #1
d008207c:	2269      	movs	r2, #105	; 0x69
d008207e:	2105      	movs	r1, #5
d0082080:	4628      	mov	r0, r5
d0082082:	f7fe f88b 	bl	d008019c <emit_phone.constprop.0>
d0082086:	4633      	mov	r3, r6
d0082088:	2234      	movs	r2, #52	; 0x34
d008208a:	2123      	movs	r1, #35	; 0x23
d008208c:	4628      	mov	r0, r5
d008208e:	f7fe f885 	bl	d008019c <emit_phone.constprop.0>
d0082092:	4633      	mov	r3, r6
d0082094:	2242      	movs	r2, #66	; 0x42
d0082096:	2101      	movs	r1, #1
d0082098:	4628      	mov	r0, r5
d008209a:	f7fe f87f 	bl	d008019c <emit_phone.constprop.0>
d008209e:	4628      	mov	r0, r5
d00820a0:	4633      	mov	r3, r6
d00820a2:	2237      	movs	r2, #55	; 0x37
d00820a4:	211b      	movs	r1, #27
d00820a6:	f7fe f879 	bl	d008019c <emit_phone.constprop.0>
d00820aa:	2001      	movs	r0, #1
d00820ac:	f7fe bcd0 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00820b0:	463a      	mov	r2, r7
d00820b2:	f7fe bde5 	b.w	d0080c80 <emit_dictionary_word.constprop.0+0x608>
d00820b6:	463a      	mov	r2, r7
d00820b8:	f7ff b9a8 	b.w	d008140c <emit_dictionary_word.constprop.0+0xd94>
d00820bc:	463a      	mov	r2, r7
d00820be:	f7fe be43 	b.w	d0080d48 <emit_dictionary_word.constprop.0+0x6d0>
d00820c2:	4602      	mov	r2, r0
d00820c4:	f7fe bf5b 	b.w	d0080f7e <emit_dictionary_word.constprop.0+0x906>
d00820c8:	223a      	movs	r2, #58	; 0x3a
d00820ca:	2126      	movs	r1, #38	; 0x26
d00820cc:	9001      	str	r0, [sp, #4]
d00820ce:	4628      	mov	r0, r5
d00820d0:	f7fe f864 	bl	d008019c <emit_phone.constprop.0>
d00820d4:	9b01      	ldr	r3, [sp, #4]
d00820d6:	2246      	movs	r2, #70	; 0x46
d00820d8:	2107      	movs	r1, #7
d00820da:	4628      	mov	r0, r5
d00820dc:	f7fe f85e 	bl	d008019c <emit_phone.constprop.0>
d00820e0:	9b01      	ldr	r3, [sp, #4]
d00820e2:	2230      	movs	r2, #48	; 0x30
d00820e4:	211e      	movs	r1, #30
d00820e6:	4628      	mov	r0, r5
d00820e8:	f7fe f858 	bl	d008019c <emit_phone.constprop.0>
d00820ec:	4628      	mov	r0, r5
d00820ee:	2301      	movs	r3, #1
d00820f0:	2278      	movs	r2, #120	; 0x78
d00820f2:	210d      	movs	r1, #13
d00820f4:	f7fe f852 	bl	d008019c <emit_phone.constprop.0>
d00820f8:	2001      	movs	r0, #1
d00820fa:	f7fe bca9 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00820fe:	222c      	movs	r2, #44	; 0x2c
d0082100:	2125      	movs	r1, #37	; 0x25
d0082102:	4628      	mov	r0, r5
d0082104:	f7fe f84a 	bl	d008019c <emit_phone.constprop.0>
d0082108:	4628      	mov	r0, r5
d008210a:	2301      	movs	r3, #1
d008210c:	227a      	movs	r2, #122	; 0x7a
d008210e:	2106      	movs	r1, #6
d0082110:	f7fe f844 	bl	d008019c <emit_phone.constprop.0>
d0082114:	2001      	movs	r0, #1
d0082116:	f7fe bc9b 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008211a:	222e      	movs	r2, #46	; 0x2e
d008211c:	2125      	movs	r1, #37	; 0x25
d008211e:	4628      	mov	r0, r5
d0082120:	f7fe f83c 	bl	d008019c <emit_phone.constprop.0>
d0082124:	4628      	mov	r0, r5
d0082126:	2301      	movs	r3, #1
d0082128:	227c      	movs	r2, #124	; 0x7c
d008212a:	210a      	movs	r1, #10
d008212c:	f7fe f836 	bl	d008019c <emit_phone.constprop.0>
d0082130:	2001      	movs	r0, #1
d0082132:	f7fe bc8d 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0082136:	2230      	movs	r2, #48	; 0x30
d0082138:	2124      	movs	r1, #36	; 0x24
d008213a:	9001      	str	r0, [sp, #4]
d008213c:	4628      	mov	r0, r5
d008213e:	f7fe f82d 	bl	d008019c <emit_phone.constprop.0>
d0082142:	9b01      	ldr	r3, [sp, #4]
d0082144:	2252      	movs	r2, #82	; 0x52
d0082146:	2101      	movs	r1, #1
d0082148:	4628      	mov	r0, r5
d008214a:	f7fe f827 	bl	d008019c <emit_phone.constprop.0>
d008214e:	4628      	mov	r0, r5
d0082150:	9b01      	ldr	r3, [sp, #4]
d0082152:	223a      	movs	r2, #58	; 0x3a
d0082154:	2126      	movs	r1, #38	; 0x26
d0082156:	f7fe f821 	bl	d008019c <emit_phone.constprop.0>
d008215a:	2001      	movs	r0, #1
d008215c:	f7fe bc78 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d0082160:	4603      	mov	r3, r0
d0082162:	223c      	movs	r2, #60	; 0x3c
d0082164:	2123      	movs	r1, #35	; 0x23
d0082166:	4628      	mov	r0, r5
d0082168:	f7fe f818 	bl	d008019c <emit_phone.constprop.0>
d008216c:	2301      	movs	r3, #1
d008216e:	227d      	movs	r2, #125	; 0x7d
d0082170:	210f      	movs	r1, #15
d0082172:	4628      	mov	r0, r5
d0082174:	f7fe f812 	bl	d008019c <emit_phone.constprop.0>
d0082178:	4628      	mov	r0, r5
d008217a:	4633      	mov	r3, r6
d008217c:	2240      	movs	r2, #64	; 0x40
d008217e:	211f      	movs	r1, #31
d0082180:	f7fe f80c 	bl	d008019c <emit_phone.constprop.0>
d0082184:	2001      	movs	r0, #1
d0082186:	f7fe bc63 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008218a:	2300      	movs	r3, #0
d008218c:	2230      	movs	r2, #48	; 0x30
d008218e:	2121      	movs	r1, #33	; 0x21
d0082190:	4628      	mov	r0, r5
d0082192:	f7fe f803 	bl	d008019c <emit_phone.constprop.0>
d0082196:	4628      	mov	r0, r5
d0082198:	2301      	movs	r3, #1
d008219a:	2274      	movs	r2, #116	; 0x74
d008219c:	210a      	movs	r1, #10
d008219e:	f7fd fffd 	bl	d008019c <emit_phone.constprop.0>
d00821a2:	2001      	movs	r0, #1
d00821a4:	f7fe bc54 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00821a8:	2248      	movs	r2, #72	; 0x48
d00821aa:	2122      	movs	r1, #34	; 0x22
d00821ac:	9001      	str	r0, [sp, #4]
d00821ae:	4628      	mov	r0, r5
d00821b0:	f7fd fff4 	bl	d008019c <emit_phone.constprop.0>
d00821b4:	9b01      	ldr	r3, [sp, #4]
d00821b6:	2232      	movs	r2, #50	; 0x32
d00821b8:	211e      	movs	r1, #30
d00821ba:	4628      	mov	r0, r5
d00821bc:	f7fd ffee 	bl	d008019c <emit_phone.constprop.0>
d00821c0:	4628      	mov	r0, r5
d00821c2:	2301      	movs	r3, #1
d00821c4:	227e      	movs	r2, #126	; 0x7e
d00821c6:	2108      	movs	r1, #8
d00821c8:	f7fd ffe8 	bl	d008019c <emit_phone.constprop.0>
d00821cc:	2001      	movs	r0, #1
d00821ce:	f7fe bc3f 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00821d2:	2236      	movs	r2, #54	; 0x36
d00821d4:	2113      	movs	r1, #19
d00821d6:	9001      	str	r0, [sp, #4]
d00821d8:	4628      	mov	r0, r5
d00821da:	f7fd ffdf 	bl	d008019c <emit_phone.constprop.0>
d00821de:	4628      	mov	r0, r5
d00821e0:	9b01      	ldr	r3, [sp, #4]
d00821e2:	224e      	movs	r2, #78	; 0x4e
d00821e4:	2101      	movs	r1, #1
d00821e6:	f7fd ffd9 	bl	d008019c <emit_phone.constprop.0>
d00821ea:	2001      	movs	r0, #1
d00821ec:	f7fe bc30 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00821f0:	4603      	mov	r3, r0
d00821f2:	223e      	movs	r2, #62	; 0x3e
d00821f4:	2113      	movs	r1, #19
d00821f6:	4628      	mov	r0, r5
d00821f8:	f7fd ffd0 	bl	d008019c <emit_phone.constprop.0>
d00821fc:	2301      	movs	r3, #1
d00821fe:	2269      	movs	r2, #105	; 0x69
d0082200:	2102      	movs	r1, #2
d0082202:	4628      	mov	r0, r5
d0082204:	f7fd ffca 	bl	d008019c <emit_phone.constprop.0>
d0082208:	4628      	mov	r0, r5
d008220a:	4633      	mov	r3, r6
d008220c:	2234      	movs	r2, #52	; 0x34
d008220e:	2121      	movs	r1, #33	; 0x21
d0082210:	f7fd ffc4 	bl	d008019c <emit_phone.constprop.0>
d0082214:	2001      	movs	r0, #1
d0082216:	f7fe bc1b 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d008221a:	2300      	movs	r3, #0
d008221c:	223e      	movs	r2, #62	; 0x3e
d008221e:	211f      	movs	r1, #31
d0082220:	4628      	mov	r0, r5
d0082222:	f7fd ffbb 	bl	d008019c <emit_phone.constprop.0>
d0082226:	2301      	movs	r3, #1
d0082228:	2258      	movs	r2, #88	; 0x58
d008222a:	2107      	movs	r1, #7
d008222c:	4628      	mov	r0, r5
d008222e:	f7fd ffb5 	bl	d008019c <emit_phone.constprop.0>
d0082232:	2300      	movs	r3, #0
d0082234:	222a      	movs	r2, #42	; 0x2a
d0082236:	211b      	movs	r1, #27
d0082238:	4628      	mov	r0, r5
d008223a:	f7fd ffaf 	bl	d008019c <emit_phone.constprop.0>
d008223e:	2300      	movs	r3, #0
d0082240:	224a      	movs	r2, #74	; 0x4a
d0082242:	2122      	movs	r1, #34	; 0x22
d0082244:	4628      	mov	r0, r5
d0082246:	f7fd ffa9 	bl	d008019c <emit_phone.constprop.0>
d008224a:	4620      	mov	r0, r4
d008224c:	491c      	ldr	r1, [pc, #112]	; (d00822c0 <emit_dictionary_word.constprop.0+0x1c48>)
d008224e:	f002 fd87 	bl	d0084d60 <strcmp>
d0082252:	4603      	mov	r3, r0
d0082254:	2800      	cmp	r0, #0
d0082256:	f47e abfa 	bne.w	d0080a4e <emit_dictionary_word.constprop.0+0x3d6>
d008225a:	223c      	movs	r2, #60	; 0x3c
d008225c:	2101      	movs	r1, #1
d008225e:	9001      	str	r0, [sp, #4]
d0082260:	4628      	mov	r0, r5
d0082262:	f7fd ff9b 	bl	d008019c <emit_phone.constprop.0>
d0082266:	9b01      	ldr	r3, [sp, #4]
d0082268:	2236      	movs	r2, #54	; 0x36
d008226a:	211f      	movs	r1, #31
d008226c:	4628      	mov	r0, r5
d008226e:	f7fd ff95 	bl	d008019c <emit_phone.constprop.0>
d0082272:	9b01      	ldr	r3, [sp, #4]
d0082274:	223e      	movs	r2, #62	; 0x3e
d0082276:	2107      	movs	r1, #7
d0082278:	4628      	mov	r0, r5
d008227a:	f7fd ff8f 	bl	d008019c <emit_phone.constprop.0>
d008227e:	9b01      	ldr	r3, [sp, #4]
d0082280:	f7fe bbe0 	b.w	d0080a44 <emit_dictionary_word.constprop.0+0x3cc>
d0082284:	4603      	mov	r3, r0
d0082286:	2240      	movs	r2, #64	; 0x40
d0082288:	211f      	movs	r1, #31
d008228a:	4628      	mov	r0, r5
d008228c:	f7fd ff86 	bl	d008019c <emit_phone.constprop.0>
d0082290:	2301      	movs	r3, #1
d0082292:	2269      	movs	r2, #105	; 0x69
d0082294:	2107      	movs	r1, #7
d0082296:	4628      	mov	r0, r5
d0082298:	f7fd ff80 	bl	d008019c <emit_phone.constprop.0>
d008229c:	4633      	mov	r3, r6
d008229e:	222a      	movs	r2, #42	; 0x2a
d00822a0:	2118      	movs	r1, #24
d00822a2:	4628      	mov	r0, r5
d00822a4:	f7fd ff7a 	bl	d008019c <emit_phone.constprop.0>
d00822a8:	4628      	mov	r0, r5
d00822aa:	4633      	mov	r3, r6
d00822ac:	2238      	movs	r2, #56	; 0x38
d00822ae:	211f      	movs	r1, #31
d00822b0:	f7fd ff74 	bl	d008019c <emit_phone.constprop.0>
d00822b4:	2001      	movs	r0, #1
d00822b6:	f7fe bbcb 	b.w	d0080a50 <emit_dictionary_word.constprop.0+0x3d8>
d00822ba:	bf00      	nop
d00822bc:	d0085aa4 	.word	0xd0085aa4
d00822c0:	d0085ac0 	.word	0xd0085ac0

d00822c4 <emit_rule_word.constprop.0>:
d00822c4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d00822c8:	460c      	mov	r4, r1
d00822ca:	b083      	sub	sp, #12
d00822cc:	4605      	mov	r5, r0
d00822ce:	f002 fd51 	bl	d0084d74 <strlen>
d00822d2:	8823      	ldrh	r3, [r4, #0]
d00822d4:	4606      	mov	r6, r0
d00822d6:	4621      	mov	r1, r4
d00822d8:	4628      	mov	r0, r5
d00822da:	9301      	str	r3, [sp, #4]
d00822dc:	f7fe f9cc 	bl	d0080678 <emit_dictionary_word.constprop.0>
d00822e0:	2800      	cmp	r0, #0
d00822e2:	f040 810b 	bne.w	d00824fc <emit_rule_word.constprop.0+0x238>
d00822e6:	fa1f f886 	uxth.w	r8, r6
d00822ea:	f1b8 0f00 	cmp.w	r8, #0
d00822ee:	f000 80ea 	beq.w	d00824c6 <emit_rule_word.constprop.0+0x202>
d00822f2:	4682      	mov	sl, r0
d00822f4:	b2b6      	uxth	r6, r6
d00822f6:	f8df 932c 	ldr.w	r9, [pc, #812]	; d0082624 <emit_rule_word.constprop.0+0x360>
d00822fa:	e03f      	b.n	d008237c <emit_rule_word.constprop.0+0xb8>
d00822fc:	f1a2 0361 	sub.w	r3, r2, #97	; 0x61
d0082300:	b2db      	uxtb	r3, r3
d0082302:	2b18      	cmp	r3, #24
d0082304:	d857      	bhi.n	d00823b6 <emit_rule_word.constprop.0+0xf2>
d0082306:	49c3      	ldr	r1, [pc, #780]	; (d0082614 <emit_rule_word.constprop.0+0x350>)
d0082308:	fa21 f303 	lsr.w	r3, r1, r3
d008230c:	43db      	mvns	r3, r3
d008230e:	f013 0301 	ands.w	r3, r3, #1
d0082312:	d150      	bne.n	d00823b6 <emit_rule_word.constprop.0+0xf2>
d0082314:	f10a 0a02 	add.w	sl, sl, #2
d0082318:	45b2      	cmp	sl, r6
d008231a:	d349      	bcc.n	d00823b0 <emit_rule_word.constprop.0+0xec>
d008231c:	f04f 0c00 	mov.w	ip, #0
d0082320:	f1b8 0f02 	cmp.w	r8, #2
d0082324:	d906      	bls.n	d0082334 <emit_rule_word.constprop.0+0x70>
d0082326:	1e71      	subs	r1, r6, #1
d0082328:	5c68      	ldrb	r0, [r5, r1]
d008232a:	2865      	cmp	r0, #101	; 0x65
d008232c:	d102      	bne.n	d0082334 <emit_rule_word.constprop.0+0x70>
d008232e:	428f      	cmp	r7, r1
d0082330:	f0c0 8251 	bcc.w	d00827d6 <emit_rule_word.constprop.0+0x512>
d0082334:	2000      	movs	r0, #0
d0082336:	2a65      	cmp	r2, #101	; 0x65
d0082338:	f000 80e3 	beq.w	d0082502 <emit_rule_word.constprop.0+0x23e>
d008233c:	2a61      	cmp	r2, #97	; 0x61
d008233e:	f000 8125 	beq.w	d008258c <emit_rule_word.constprop.0+0x2c8>
d0082342:	f1a2 016f 	sub.w	r1, r2, #111	; 0x6f
d0082346:	f1be 0f6f 	cmp.w	lr, #111	; 0x6f
d008234a:	fab1 f181 	clz	r1, r1
d008234e:	ea4f 1151 	mov.w	r1, r1, lsr #5
d0082352:	f040 82cc 	bne.w	d00828ee <emit_rule_word.constprop.0+0x62a>
d0082356:	2900      	cmp	r1, #0
d0082358:	f000 82c9 	beq.w	d00828ee <emit_rule_word.constprop.0+0x62a>
d008235c:	f1bc 0f64 	cmp.w	ip, #100	; 0x64
d0082360:	f04f 0300 	mov.w	r3, #0
d0082364:	4620      	mov	r0, r4
d0082366:	bf0c      	ite	eq
d0082368:	2109      	moveq	r1, #9
d008236a:	210a      	movne	r1, #10
d008236c:	461a      	mov	r2, r3
d008236e:	f7fd ff15 	bl	d008019c <emit_phone.constprop.0>
d0082372:	fa1f fa8a 	uxth.w	sl, sl
d0082376:	45d0      	cmp	r8, sl
d0082378:	f240 80a5 	bls.w	d00824c6 <emit_rule_word.constprop.0+0x202>
d008237c:	f10a 0701 	add.w	r7, sl, #1
d0082380:	f815 200a 	ldrb.w	r2, [r5, sl]
d0082384:	eb05 0b0a 	add.w	fp, r5, sl
d0082388:	42b7      	cmp	r7, r6
d008238a:	bf34      	ite	cc
d008238c:	f815 e007 	ldrbcc.w	lr, [r5, r7]
d0082390:	f04f 0e00 	movcs.w	lr, #0
d0082394:	2a65      	cmp	r2, #101	; 0x65
d0082396:	d1b1      	bne.n	d00822fc <emit_rule_word.constprop.0+0x38>
d0082398:	1e73      	subs	r3, r6, #1
d008239a:	4553      	cmp	r3, sl
d008239c:	d103      	bne.n	d00823a6 <emit_rule_word.constprop.0+0xe2>
d008239e:	f1b8 0f02 	cmp.w	r8, #2
d00823a2:	f200 815a 	bhi.w	d008265a <emit_rule_word.constprop.0+0x396>
d00823a6:	f10a 0a02 	add.w	sl, sl, #2
d00823aa:	2301      	movs	r3, #1
d00823ac:	45b2      	cmp	sl, r6
d00823ae:	d2b5      	bcs.n	d008231c <emit_rule_word.constprop.0+0x58>
d00823b0:	f815 c00a 	ldrb.w	ip, [r5, sl]
d00823b4:	e7b4      	b.n	d0082320 <emit_rule_word.constprop.0+0x5c>
d00823b6:	4998      	ldr	r1, [pc, #608]	; (d0082618 <emit_rule_word.constprop.0+0x354>)
d00823b8:	4658      	mov	r0, fp
d00823ba:	2363      	movs	r3, #99	; 0x63
d00823bc:	f810 cb01 	ldrb.w	ip, [r0], #1
d00823c0:	459c      	cmp	ip, r3
d00823c2:	d13d      	bne.n	d0082440 <emit_rule_word.constprop.0+0x17c>
d00823c4:	f811 3f01 	ldrb.w	r3, [r1, #1]!
d00823c8:	2b00      	cmp	r3, #0
d00823ca:	d1f7      	bne.n	d00823bc <emit_rule_word.constprop.0+0xf8>
d00823cc:	8822      	ldrh	r2, [r4, #0]
d00823ce:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d00823d2:	d232      	bcs.n	d008243a <emit_rule_word.constprop.0+0x176>
d00823d4:	2111      	movs	r1, #17
d00823d6:	2056      	movs	r0, #86	; 0x56
d00823d8:	f809 1022 	strb.w	r1, [r9, r2, lsl #2]
d00823dc:	8822      	ldrh	r2, [r4, #0]
d00823de:	498f      	ldr	r1, [pc, #572]	; (d008261c <emit_rule_word.constprop.0+0x358>)
d00823e0:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d00823e4:	8050      	strh	r0, [r2, #2]
d00823e6:	8822      	ldrh	r2, [r4, #0]
d00823e8:	8808      	ldrh	r0, [r1, #0]
d00823ea:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d00823ee:	7053      	strb	r3, [r2, #1]
d00823f0:	8823      	ldrh	r3, [r4, #0]
d00823f2:	3301      	adds	r3, #1
d00823f4:	8023      	strh	r3, [r4, #0]
d00823f6:	2800      	cmp	r0, #0
d00823f8:	f000 8134 	beq.w	d0082664 <emit_rule_word.constprop.0+0x3a0>
d00823fc:	1c42      	adds	r2, r0, #1
d00823fe:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082402:	f080 832f 	bcs.w	d0082a64 <emit_rule_word.constprop.0+0x7a0>
d0082406:	4b86      	ldr	r3, [pc, #536]	; (d0082620 <emit_rule_word.constprop.0+0x35c>)
d0082408:	2720      	movs	r7, #32
d008240a:	b292      	uxth	r2, r2
d008240c:	541f      	strb	r7, [r3, r0]
d008240e:	2700      	movs	r7, #0
d0082410:	4610      	mov	r0, r2
d0082412:	549f      	strb	r7, [r3, r2]
d0082414:	f8df c210 	ldr.w	ip, [pc, #528]	; d0082628 <emit_rule_word.constprop.0+0x364>
d0082418:	2743      	movs	r7, #67	; 0x43
d008241a:	e006      	b.n	d008242a <emit_rule_word.constprop.0+0x166>
d008241c:	541f      	strb	r7, [r3, r0]
d008241e:	4610      	mov	r0, r2
d0082420:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0082424:	2f00      	cmp	r7, #0
d0082426:	f000 811b 	beq.w	d0082660 <emit_rule_word.constprop.0+0x39c>
d008242a:	1c42      	adds	r2, r0, #1
d008242c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082430:	b292      	uxth	r2, r2
d0082432:	d3f3      	bcc.n	d008241c <emit_rule_word.constprop.0+0x158>
d0082434:	8008      	strh	r0, [r1, #0]
d0082436:	2200      	movs	r2, #0
d0082438:	541a      	strb	r2, [r3, r0]
d008243a:	f10a 0a02 	add.w	sl, sl, #2
d008243e:	e798      	b.n	d0082372 <emit_rule_word.constprop.0+0xae>
d0082440:	f8df c1e8 	ldr.w	ip, [pc, #488]	; d008262c <emit_rule_word.constprop.0+0x368>
d0082444:	4659      	mov	r1, fp
d0082446:	2373      	movs	r3, #115	; 0x73
d0082448:	f811 0b01 	ldrb.w	r0, [r1], #1
d008244c:	4298      	cmp	r0, r3
d008244e:	f040 815b 	bne.w	d0082708 <emit_rule_word.constprop.0+0x444>
d0082452:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d0082456:	2b00      	cmp	r3, #0
d0082458:	d1f6      	bne.n	d0082448 <emit_rule_word.constprop.0+0x184>
d008245a:	8822      	ldrh	r2, [r4, #0]
d008245c:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0082460:	d2eb      	bcs.n	d008243a <emit_rule_word.constprop.0+0x176>
d0082462:	2720      	movs	r7, #32
d0082464:	f04f 0c64 	mov.w	ip, #100	; 0x64
d0082468:	496c      	ldr	r1, [pc, #432]	; (d008261c <emit_rule_word.constprop.0+0x358>)
d008246a:	f809 7022 	strb.w	r7, [r9, r2, lsl #2]
d008246e:	8822      	ldrh	r2, [r4, #0]
d0082470:	8808      	ldrh	r0, [r1, #0]
d0082472:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082476:	f8a2 c002 	strh.w	ip, [r2, #2]
d008247a:	8822      	ldrh	r2, [r4, #0]
d008247c:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082480:	7053      	strb	r3, [r2, #1]
d0082482:	8823      	ldrh	r3, [r4, #0]
d0082484:	3301      	adds	r3, #1
d0082486:	8023      	strh	r3, [r4, #0]
d0082488:	2800      	cmp	r0, #0
d008248a:	f000 81f5 	beq.w	d0082878 <emit_rule_word.constprop.0+0x5b4>
d008248e:	1c42      	adds	r2, r0, #1
d0082490:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082494:	f080 833e 	bcs.w	d0082b14 <emit_rule_word.constprop.0+0x850>
d0082498:	4b61      	ldr	r3, [pc, #388]	; (d0082620 <emit_rule_word.constprop.0+0x35c>)
d008249a:	b292      	uxth	r2, r2
d008249c:	541f      	strb	r7, [r3, r0]
d008249e:	2700      	movs	r7, #0
d00824a0:	4610      	mov	r0, r2
d00824a2:	549f      	strb	r7, [r3, r2]
d00824a4:	f8df c188 	ldr.w	ip, [pc, #392]	; d0082630 <emit_rule_word.constprop.0+0x36c>
d00824a8:	2753      	movs	r7, #83	; 0x53
d00824aa:	e006      	b.n	d00824ba <emit_rule_word.constprop.0+0x1f6>
d00824ac:	541f      	strb	r7, [r3, r0]
d00824ae:	4610      	mov	r0, r2
d00824b0:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d00824b4:	2f00      	cmp	r7, #0
d00824b6:	f000 80d3 	beq.w	d0082660 <emit_rule_word.constprop.0+0x39c>
d00824ba:	1c42      	adds	r2, r0, #1
d00824bc:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00824c0:	b292      	uxth	r2, r2
d00824c2:	d3f3      	bcc.n	d00824ac <emit_rule_word.constprop.0+0x1e8>
d00824c4:	e7b6      	b.n	d0082434 <emit_rule_word.constprop.0+0x170>
d00824c6:	8822      	ldrh	r2, [r4, #0]
d00824c8:	9b01      	ldr	r3, [sp, #4]
d00824ca:	4293      	cmp	r3, r2
d00824cc:	d216      	bcs.n	d00824fc <emit_rule_word.constprop.0+0x238>
d00824ce:	4618      	mov	r0, r3
d00824d0:	1e51      	subs	r1, r2, #1
d00824d2:	4b54      	ldr	r3, [pc, #336]	; (d0082624 <emit_rule_word.constprop.0+0x360>)
d00824d4:	1a09      	subs	r1, r1, r0
d00824d6:	1f18      	subs	r0, r3, #4
d00824d8:	eb03 0382 	add.w	r3, r3, r2, lsl #2
d00824dc:	b289      	uxth	r1, r1
d00824de:	1a52      	subs	r2, r2, r1
d00824e0:	eb00 0082 	add.w	r0, r0, r2, lsl #2
d00824e4:	e001      	b.n	d00824ea <emit_rule_word.constprop.0+0x226>
d00824e6:	4288      	cmp	r0, r1
d00824e8:	d008      	beq.n	d00824fc <emit_rule_word.constprop.0+0x238>
d00824ea:	f813 2c04 	ldrb.w	r2, [r3, #-4]
d00824ee:	1f19      	subs	r1, r3, #4
d00824f0:	3a01      	subs	r2, #1
d00824f2:	460b      	mov	r3, r1
d00824f4:	2a0e      	cmp	r2, #14
d00824f6:	d8f6      	bhi.n	d00824e6 <emit_rule_word.constprop.0+0x222>
d00824f8:	2301      	movs	r3, #1
d00824fa:	704b      	strb	r3, [r1, #1]
d00824fc:	b003      	add	sp, #12
d00824fe:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0082502:	f00e 01fb 	and.w	r1, lr, #251	; 0xfb
d0082506:	f1be 0f69 	cmp.w	lr, #105	; 0x69
d008250a:	bf18      	it	ne
d008250c:	2961      	cmpne	r1, #97	; 0x61
d008250e:	bf0c      	ite	eq
d0082510:	2101      	moveq	r1, #1
d0082512:	2100      	movne	r1, #0
d0082514:	f040 80a8 	bne.w	d0082668 <emit_rule_word.constprop.0+0x3a4>
d0082518:	8823      	ldrh	r3, [r4, #0]
d008251a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008251e:	f4bf af28 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d0082522:	2208      	movs	r2, #8
d0082524:	207d      	movs	r0, #125	; 0x7d
d0082526:	493d      	ldr	r1, [pc, #244]	; (d008261c <emit_rule_word.constprop.0+0x358>)
d0082528:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d008252c:	2200      	movs	r2, #0
d008252e:	8823      	ldrh	r3, [r4, #0]
d0082530:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082534:	8058      	strh	r0, [r3, #2]
d0082536:	8823      	ldrh	r3, [r4, #0]
d0082538:	8808      	ldrh	r0, [r1, #0]
d008253a:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008253e:	705a      	strb	r2, [r3, #1]
d0082540:	8823      	ldrh	r3, [r4, #0]
d0082542:	3301      	adds	r3, #1
d0082544:	8023      	strh	r3, [r4, #0]
d0082546:	2800      	cmp	r0, #0
d0082548:	f000 8194 	beq.w	d0082874 <emit_rule_word.constprop.0+0x5b0>
d008254c:	1c42      	adds	r2, r0, #1
d008254e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082552:	f080 82dc 	bcs.w	d0082b0e <emit_rule_word.constprop.0+0x84a>
d0082556:	4b32      	ldr	r3, [pc, #200]	; (d0082620 <emit_rule_word.constprop.0+0x35c>)
d0082558:	2720      	movs	r7, #32
d008255a:	b292      	uxth	r2, r2
d008255c:	541f      	strb	r7, [r3, r0]
d008255e:	2700      	movs	r7, #0
d0082560:	4610      	mov	r0, r2
d0082562:	549f      	strb	r7, [r3, r2]
d0082564:	f8df c0cc 	ldr.w	ip, [pc, #204]	; d0082634 <emit_rule_word.constprop.0+0x370>
d0082568:	2749      	movs	r7, #73	; 0x49
d008256a:	e006      	b.n	d008257a <emit_rule_word.constprop.0+0x2b6>
d008256c:	541f      	strb	r7, [r3, r0]
d008256e:	4610      	mov	r0, r2
d0082570:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0082574:	2f00      	cmp	r7, #0
d0082576:	f000 82b6 	beq.w	d0082ae6 <emit_rule_word.constprop.0+0x822>
d008257a:	1c42      	adds	r2, r0, #1
d008257c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082580:	b292      	uxth	r2, r2
d0082582:	d3f3      	bcc.n	d008256c <emit_rule_word.constprop.0+0x2a8>
d0082584:	8008      	strh	r0, [r1, #0]
d0082586:	2200      	movs	r2, #0
d0082588:	541a      	strb	r2, [r3, r0]
d008258a:	e6f2      	b.n	d0082372 <emit_rule_word.constprop.0+0xae>
d008258c:	f00e 03ef 	and.w	r3, lr, #239	; 0xef
d0082590:	2b69      	cmp	r3, #105	; 0x69
d0082592:	f000 80f4 	beq.w	d008277e <emit_rule_word.constprop.0+0x4ba>
d0082596:	f00e 0efd 	and.w	lr, lr, #253	; 0xfd
d008259a:	f1be 0f75 	cmp.w	lr, #117	; 0x75
d008259e:	d16d      	bne.n	d008267c <emit_rule_word.constprop.0+0x3b8>
d00825a0:	8823      	ldrh	r3, [r4, #0]
d00825a2:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00825a6:	f4bf aee4 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d00825aa:	2204      	movs	r2, #4
d00825ac:	2087      	movs	r0, #135	; 0x87
d00825ae:	491b      	ldr	r1, [pc, #108]	; (d008261c <emit_rule_word.constprop.0+0x358>)
d00825b0:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d00825b4:	2200      	movs	r2, #0
d00825b6:	8823      	ldrh	r3, [r4, #0]
d00825b8:	880f      	ldrh	r7, [r1, #0]
d00825ba:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00825be:	8058      	strh	r0, [r3, #2]
d00825c0:	8823      	ldrh	r3, [r4, #0]
d00825c2:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00825c6:	705a      	strb	r2, [r3, #1]
d00825c8:	8823      	ldrh	r3, [r4, #0]
d00825ca:	3301      	adds	r3, #1
d00825cc:	8023      	strh	r3, [r4, #0]
d00825ce:	2f00      	cmp	r7, #0
d00825d0:	f000 8427 	beq.w	d0082e22 <emit_rule_word.constprop.0+0xb5e>
d00825d4:	1c7a      	adds	r2, r7, #1
d00825d6:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00825da:	f080 875d 	bcs.w	d0083498 <emit_rule_word.constprop.0+0x11d4>
d00825de:	4b10      	ldr	r3, [pc, #64]	; (d0082620 <emit_rule_word.constprop.0+0x35c>)
d00825e0:	2020      	movs	r0, #32
d00825e2:	b292      	uxth	r2, r2
d00825e4:	55d8      	strb	r0, [r3, r7]
d00825e6:	2000      	movs	r0, #0
d00825e8:	4617      	mov	r7, r2
d00825ea:	5498      	strb	r0, [r3, r2]
d00825ec:	f8df c048 	ldr.w	ip, [pc, #72]	; d0082638 <emit_rule_word.constprop.0+0x374>
d00825f0:	2041      	movs	r0, #65	; 0x41
d00825f2:	e006      	b.n	d0082602 <emit_rule_word.constprop.0+0x33e>
d00825f4:	55d8      	strb	r0, [r3, r7]
d00825f6:	4617      	mov	r7, r2
d00825f8:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d00825fc:	2800      	cmp	r0, #0
d00825fe:	f000 81f7 	beq.w	d00829f0 <emit_rule_word.constprop.0+0x72c>
d0082602:	1c7a      	adds	r2, r7, #1
d0082604:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082608:	b292      	uxth	r2, r2
d008260a:	d3f3      	bcc.n	d00825f4 <emit_rule_word.constprop.0+0x330>
d008260c:	800f      	strh	r7, [r1, #0]
d008260e:	2200      	movs	r2, #0
d0082610:	55da      	strb	r2, [r3, r7]
d0082612:	e6ae      	b.n	d0082372 <emit_rule_word.constprop.0+0xae>
d0082614:	01104101 	.word	0x01104101
d0082618:	d0085a90 	.word	0xd0085a90
d008261c:	d0087588 	.word	0xd0087588
d0082620:	d0086d88 	.word	0xd0086d88
d0082624:	d0086188 	.word	0xd0086188
d0082628:	d0085b30 	.word	0xd0085b30
d008262c:	d0085b34 	.word	0xd0085b34
d0082630:	d00859e8 	.word	0xd00859e8
d0082634:	d00859b8 	.word	0xd00859b8
d0082638:	d0085b24 	.word	0xd0085b24
d008263c:	f00e 03ef 	and.w	r3, lr, #239	; 0xef
d0082640:	2b69      	cmp	r3, #105	; 0x69
d0082642:	f001 80dd 	beq.w	d0083800 <emit_rule_word.constprop.0+0x153c>
d0082646:	f1be 0f65 	cmp.w	lr, #101	; 0x65
d008264a:	f001 80d9 	beq.w	d0083800 <emit_rule_word.constprop.0+0x153c>
d008264e:	2115      	movs	r1, #21
d0082650:	2300      	movs	r3, #0
d0082652:	4620      	mov	r0, r4
d0082654:	461a      	mov	r2, r3
d0082656:	f7fd fda1 	bl	d008019c <emit_phone.constprop.0>
d008265a:	fa1f fa87 	uxth.w	sl, r7
d008265e:	e68a      	b.n	d0082376 <emit_rule_word.constprop.0+0xb2>
d0082660:	800a      	strh	r2, [r1, #0]
d0082662:	e6e8      	b.n	d0082436 <emit_rule_word.constprop.0+0x172>
d0082664:	4bbf      	ldr	r3, [pc, #764]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d0082666:	e6d5      	b.n	d0082414 <emit_rule_word.constprop.0+0x150>
d0082668:	2a69      	cmp	r2, #105	; 0x69
d008266a:	d003      	beq.n	d0082674 <emit_rule_word.constprop.0+0x3b0>
d008266c:	b913      	cbnz	r3, d0082674 <emit_rule_word.constprop.0+0x3b0>
d008266e:	2a75      	cmp	r2, #117	; 0x75
d0082670:	f040 814f 	bne.w	d0082912 <emit_rule_word.constprop.0+0x64e>
d0082674:	f1be 0f72 	cmp.w	lr, #114	; 0x72
d0082678:	f000 8102 	beq.w	d0082880 <emit_rule_word.constprop.0+0x5bc>
d008267c:	8823      	ldrh	r3, [r4, #0]
d008267e:	2800      	cmp	r0, #0
d0082680:	f000 80b4 	beq.w	d00827ec <emit_rule_word.constprop.0+0x528>
d0082684:	2a61      	cmp	r2, #97	; 0x61
d0082686:	f000 838f 	beq.w	d0082da8 <emit_rule_word.constprop.0+0xae4>
d008268a:	2a65      	cmp	r2, #101	; 0x65
d008268c:	f000 84b9 	beq.w	d0083002 <emit_rule_word.constprop.0+0xd3e>
d0082690:	2a69      	cmp	r2, #105	; 0x69
d0082692:	f000 85cb 	beq.w	d008322c <emit_rule_word.constprop.0+0xf68>
d0082696:	2a6f      	cmp	r2, #111	; 0x6f
d0082698:	f000 8430 	beq.w	d0082efc <emit_rule_word.constprop.0+0xc38>
d008269c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00826a0:	d2db      	bcs.n	d008265a <emit_rule_word.constprop.0+0x396>
d00826a2:	220a      	movs	r2, #10
d00826a4:	2082      	movs	r0, #130	; 0x82
d00826a6:	49b0      	ldr	r1, [pc, #704]	; (d0082968 <emit_rule_word.constprop.0+0x6a4>)
d00826a8:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d00826ac:	2200      	movs	r2, #0
d00826ae:	8823      	ldrh	r3, [r4, #0]
d00826b0:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00826b4:	8058      	strh	r0, [r3, #2]
d00826b6:	8823      	ldrh	r3, [r4, #0]
d00826b8:	8808      	ldrh	r0, [r1, #0]
d00826ba:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00826be:	705a      	strb	r2, [r3, #1]
d00826c0:	8823      	ldrh	r3, [r4, #0]
d00826c2:	3301      	adds	r3, #1
d00826c4:	8023      	strh	r3, [r4, #0]
d00826c6:	2800      	cmp	r0, #0
d00826c8:	f040 83c6 	bne.w	d0082e58 <emit_rule_word.constprop.0+0xb94>
d00826cc:	4ba5      	ldr	r3, [pc, #660]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d00826ce:	f04f 0c55 	mov.w	ip, #85	; 0x55
d00826d2:	461a      	mov	r2, r3
d00826d4:	f8df e29c 	ldr.w	lr, [pc, #668]	; d0082974 <emit_rule_word.constprop.0+0x6b0>
d00826d8:	4663      	mov	r3, ip
d00826da:	4694      	mov	ip, r2
d00826dc:	e007      	b.n	d00826ee <emit_rule_word.constprop.0+0x42a>
d00826de:	f80c 3000 	strb.w	r3, [ip, r0]
d00826e2:	4610      	mov	r0, r2
d00826e4:	f81e 3f01 	ldrb.w	r3, [lr, #1]!
d00826e8:	2b00      	cmp	r3, #0
d00826ea:	f000 84d8 	beq.w	d008309e <emit_rule_word.constprop.0+0xdda>
d00826ee:	1c42      	adds	r2, r0, #1
d00826f0:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00826f4:	b292      	uxth	r2, r2
d00826f6:	d3f2      	bcc.n	d00826de <emit_rule_word.constprop.0+0x41a>
d00826f8:	4663      	mov	r3, ip
d00826fa:	4602      	mov	r2, r0
d00826fc:	8008      	strh	r0, [r1, #0]
d00826fe:	2100      	movs	r1, #0
d0082700:	fa1f fa87 	uxth.w	sl, r7
d0082704:	5499      	strb	r1, [r3, r2]
d0082706:	e636      	b.n	d0082376 <emit_rule_word.constprop.0+0xb2>
d0082708:	f8df c26c 	ldr.w	ip, [pc, #620]	; d0082978 <emit_rule_word.constprop.0+0x6b4>
d008270c:	4659      	mov	r1, fp
d008270e:	2374      	movs	r3, #116	; 0x74
d0082710:	f811 0b01 	ldrb.w	r0, [r1], #1
d0082714:	4298      	cmp	r0, r3
d0082716:	f040 81a8 	bne.w	d0082a6a <emit_rule_word.constprop.0+0x7a6>
d008271a:	f81c 3f01 	ldrb.w	r3, [ip, #1]!
d008271e:	2b00      	cmp	r3, #0
d0082720:	d1f6      	bne.n	d0082710 <emit_rule_word.constprop.0+0x44c>
d0082722:	8822      	ldrh	r2, [r4, #0]
d0082724:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0082728:	f4bf ae87 	bcs.w	d008243a <emit_rule_word.constprop.0+0x176>
d008272c:	2122      	movs	r1, #34	; 0x22
d008272e:	204e      	movs	r0, #78	; 0x4e
d0082730:	f809 1022 	strb.w	r1, [r9, r2, lsl #2]
d0082734:	8822      	ldrh	r2, [r4, #0]
d0082736:	498c      	ldr	r1, [pc, #560]	; (d0082968 <emit_rule_word.constprop.0+0x6a4>)
d0082738:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d008273c:	880f      	ldrh	r7, [r1, #0]
d008273e:	8050      	strh	r0, [r2, #2]
d0082740:	8822      	ldrh	r2, [r4, #0]
d0082742:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082746:	7053      	strb	r3, [r2, #1]
d0082748:	8823      	ldrh	r3, [r4, #0]
d008274a:	3301      	adds	r3, #1
d008274c:	8023      	strh	r3, [r4, #0]
d008274e:	2f00      	cmp	r7, #0
d0082750:	f040 815d 	bne.w	d0082a0e <emit_rule_word.constprop.0+0x74a>
d0082754:	4b83      	ldr	r3, [pc, #524]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d0082756:	f8df c224 	ldr.w	ip, [pc, #548]	; d008297c <emit_rule_word.constprop.0+0x6b8>
d008275a:	2054      	movs	r0, #84	; 0x54
d008275c:	e006      	b.n	d008276c <emit_rule_word.constprop.0+0x4a8>
d008275e:	55d8      	strb	r0, [r3, r7]
d0082760:	4617      	mov	r7, r2
d0082762:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d0082766:	2800      	cmp	r0, #0
d0082768:	f000 820d 	beq.w	d0082b86 <emit_rule_word.constprop.0+0x8c2>
d008276c:	1c7a      	adds	r2, r7, #1
d008276e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082772:	b292      	uxth	r2, r2
d0082774:	d3f3      	bcc.n	d008275e <emit_rule_word.constprop.0+0x49a>
d0082776:	800f      	strh	r7, [r1, #0]
d0082778:	2200      	movs	r2, #0
d008277a:	55da      	strb	r2, [r3, r7]
d008277c:	e65d      	b.n	d008243a <emit_rule_word.constprop.0+0x176>
d008277e:	8823      	ldrh	r3, [r4, #0]
d0082780:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082784:	f4bf adf5 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d0082788:	220b      	movs	r2, #11
d008278a:	2050      	movs	r0, #80	; 0x50
d008278c:	4976      	ldr	r1, [pc, #472]	; (d0082968 <emit_rule_word.constprop.0+0x6a4>)
d008278e:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0082792:	2200      	movs	r2, #0
d0082794:	8823      	ldrh	r3, [r4, #0]
d0082796:	880f      	ldrh	r7, [r1, #0]
d0082798:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008279c:	8058      	strh	r0, [r3, #2]
d008279e:	8823      	ldrh	r3, [r4, #0]
d00827a0:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00827a4:	705a      	strb	r2, [r3, #1]
d00827a6:	8823      	ldrh	r3, [r4, #0]
d00827a8:	3301      	adds	r3, #1
d00827aa:	8023      	strh	r3, [r4, #0]
d00827ac:	2f00      	cmp	r7, #0
d00827ae:	f040 8121 	bne.w	d00829f4 <emit_rule_word.constprop.0+0x730>
d00827b2:	4b6c      	ldr	r3, [pc, #432]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d00827b4:	f8df c1c8 	ldr.w	ip, [pc, #456]	; d0082980 <emit_rule_word.constprop.0+0x6bc>
d00827b8:	2045      	movs	r0, #69	; 0x45
d00827ba:	e006      	b.n	d00827ca <emit_rule_word.constprop.0+0x506>
d00827bc:	55d8      	strb	r0, [r3, r7]
d00827be:	4617      	mov	r7, r2
d00827c0:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d00827c4:	2800      	cmp	r0, #0
d00827c6:	f000 8113 	beq.w	d00829f0 <emit_rule_word.constprop.0+0x72c>
d00827ca:	1c7a      	adds	r2, r7, #1
d00827cc:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00827d0:	b292      	uxth	r2, r2
d00827d2:	d3f3      	bcc.n	d00827bc <emit_rule_word.constprop.0+0x4f8>
d00827d4:	e71a      	b.n	d008260c <emit_rule_word.constprop.0+0x348>
d00827d6:	f1ae 0161 	sub.w	r1, lr, #97	; 0x61
d00827da:	b2c9      	uxtb	r1, r1
d00827dc:	2918      	cmp	r1, #24
d00827de:	d84d      	bhi.n	d008287c <emit_rule_word.constprop.0+0x5b8>
d00827e0:	4862      	ldr	r0, [pc, #392]	; (d008296c <emit_rule_word.constprop.0+0x6a8>)
d00827e2:	40c8      	lsrs	r0, r1
d00827e4:	43c0      	mvns	r0, r0
d00827e6:	f000 0001 	and.w	r0, r0, #1
d00827ea:	e5a4      	b.n	d0082336 <emit_rule_word.constprop.0+0x72>
d00827ec:	2a61      	cmp	r2, #97	; 0x61
d00827ee:	f000 82ad 	beq.w	d0082d4c <emit_rule_word.constprop.0+0xa88>
d00827f2:	2a65      	cmp	r2, #101	; 0x65
d00827f4:	f000 845d 	beq.w	d00830b2 <emit_rule_word.constprop.0+0xdee>
d00827f8:	2a69      	cmp	r2, #105	; 0x69
d00827fa:	f000 84db 	beq.w	d00831b4 <emit_rule_word.constprop.0+0xef0>
d00827fe:	2a6f      	cmp	r2, #111	; 0x6f
d0082800:	f000 85a2 	beq.w	d0083348 <emit_rule_word.constprop.0+0x1084>
d0082804:	2a75      	cmp	r2, #117	; 0x75
d0082806:	f000 8498 	beq.w	d008313a <emit_rule_word.constprop.0+0xe76>
d008280a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008280e:	f4bf af24 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0082812:	2108      	movs	r1, #8
d0082814:	227d      	movs	r2, #125	; 0x7d
d0082816:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d008281a:	8823      	ldrh	r3, [r4, #0]
d008281c:	4952      	ldr	r1, [pc, #328]	; (d0082968 <emit_rule_word.constprop.0+0x6a4>)
d008281e:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082822:	f8b1 c000 	ldrh.w	ip, [r1]
d0082826:	805a      	strh	r2, [r3, #2]
d0082828:	8823      	ldrh	r3, [r4, #0]
d008282a:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008282e:	7058      	strb	r0, [r3, #1]
d0082830:	8823      	ldrh	r3, [r4, #0]
d0082832:	3301      	adds	r3, #1
d0082834:	8023      	strh	r3, [r4, #0]
d0082836:	f1bc 0f00 	cmp.w	ip, #0
d008283a:	f040 831e 	bne.w	d0082e7a <emit_rule_word.constprop.0+0xbb6>
d008283e:	4b49      	ldr	r3, [pc, #292]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d0082840:	f8df e140 	ldr.w	lr, [pc, #320]	; d0082984 <emit_rule_word.constprop.0+0x6c0>
d0082844:	2049      	movs	r0, #73	; 0x49
d0082846:	e007      	b.n	d0082858 <emit_rule_word.constprop.0+0x594>
d0082848:	f803 000c 	strb.w	r0, [r3, ip]
d008284c:	4694      	mov	ip, r2
d008284e:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d0082852:	2800      	cmp	r0, #0
d0082854:	f000 834d 	beq.w	d0082ef2 <emit_rule_word.constprop.0+0xc2e>
d0082858:	f10c 0201 	add.w	r2, ip, #1
d008285c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082860:	b292      	uxth	r2, r2
d0082862:	d3f1      	bcc.n	d0082848 <emit_rule_word.constprop.0+0x584>
d0082864:	f8a1 c000 	strh.w	ip, [r1]
d0082868:	2200      	movs	r2, #0
d008286a:	fa1f fa87 	uxth.w	sl, r7
d008286e:	f803 200c 	strb.w	r2, [r3, ip]
d0082872:	e580      	b.n	d0082376 <emit_rule_word.constprop.0+0xb2>
d0082874:	4b3b      	ldr	r3, [pc, #236]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d0082876:	e675      	b.n	d0082564 <emit_rule_word.constprop.0+0x2a0>
d0082878:	4b3a      	ldr	r3, [pc, #232]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d008287a:	e613      	b.n	d00824a4 <emit_rule_word.constprop.0+0x1e0>
d008287c:	2001      	movs	r0, #1
d008287e:	e55a      	b.n	d0082336 <emit_rule_word.constprop.0+0x72>
d0082880:	8823      	ldrh	r3, [r4, #0]
d0082882:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082886:	f4bf ad74 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d008288a:	2206      	movs	r2, #6
d008288c:	2091      	movs	r0, #145	; 0x91
d008288e:	4936      	ldr	r1, [pc, #216]	; (d0082968 <emit_rule_word.constprop.0+0x6a4>)
d0082890:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0082894:	2200      	movs	r2, #0
d0082896:	8823      	ldrh	r3, [r4, #0]
d0082898:	880f      	ldrh	r7, [r1, #0]
d008289a:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008289e:	8058      	strh	r0, [r3, #2]
d00828a0:	8823      	ldrh	r3, [r4, #0]
d00828a2:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00828a6:	705a      	strb	r2, [r3, #1]
d00828a8:	8823      	ldrh	r3, [r4, #0]
d00828aa:	3301      	adds	r3, #1
d00828ac:	8023      	strh	r3, [r4, #0]
d00828ae:	2f00      	cmp	r7, #0
d00828b0:	f000 82b5 	beq.w	d0082e1e <emit_rule_word.constprop.0+0xb5a>
d00828b4:	1c7a      	adds	r2, r7, #1
d00828b6:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00828ba:	f080 8596 	bcs.w	d00833ea <emit_rule_word.constprop.0+0x1126>
d00828be:	4b29      	ldr	r3, [pc, #164]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d00828c0:	2020      	movs	r0, #32
d00828c2:	b292      	uxth	r2, r2
d00828c4:	55d8      	strb	r0, [r3, r7]
d00828c6:	2000      	movs	r0, #0
d00828c8:	4617      	mov	r7, r2
d00828ca:	5498      	strb	r0, [r3, r2]
d00828cc:	f8df c0b8 	ldr.w	ip, [pc, #184]	; d0082988 <emit_rule_word.constprop.0+0x6c4>
d00828d0:	2045      	movs	r0, #69	; 0x45
d00828d2:	e006      	b.n	d00828e2 <emit_rule_word.constprop.0+0x61e>
d00828d4:	55d8      	strb	r0, [r3, r7]
d00828d6:	4617      	mov	r7, r2
d00828d8:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d00828dc:	2800      	cmp	r0, #0
d00828de:	f000 8087 	beq.w	d00829f0 <emit_rule_word.constprop.0+0x72c>
d00828e2:	1c7a      	adds	r2, r7, #1
d00828e4:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00828e8:	b292      	uxth	r2, r2
d00828ea:	d3f3      	bcc.n	d00828d4 <emit_rule_word.constprop.0+0x610>
d00828ec:	e68e      	b.n	d008260c <emit_rule_word.constprop.0+0x348>
d00828ee:	2a6f      	cmp	r2, #111	; 0x6f
d00828f0:	f47f aeba 	bne.w	d0082668 <emit_rule_word.constprop.0+0x3a4>
d00828f4:	f00e 0cfd 	and.w	ip, lr, #253	; 0xfd
d00828f8:	f1bc 0f75 	cmp.w	ip, #117	; 0x75
d00828fc:	f000 8145 	beq.w	d0082b8a <emit_rule_word.constprop.0+0x8c6>
d0082900:	f00e 0cef 	and.w	ip, lr, #239	; 0xef
d0082904:	f1bc 0f69 	cmp.w	ip, #105	; 0x69
d0082908:	f000 81a6 	beq.w	d0082c58 <emit_rule_word.constprop.0+0x994>
d008290c:	2b00      	cmp	r3, #0
d008290e:	f47f aeb1 	bne.w	d0082674 <emit_rule_word.constprop.0+0x3b0>
d0082912:	f1be 0f72 	cmp.w	lr, #114	; 0x72
d0082916:	f47f aeb1 	bne.w	d008267c <emit_rule_word.constprop.0+0x3b8>
d008291a:	2900      	cmp	r1, #0
d008291c:	f43f aeae 	beq.w	d008267c <emit_rule_word.constprop.0+0x3b8>
d0082920:	8823      	ldrh	r3, [r4, #0]
d0082922:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082926:	f4bf ad24 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d008292a:	2104      	movs	r1, #4
d008292c:	225f      	movs	r2, #95	; 0x5f
d008292e:	2001      	movs	r0, #1
d0082930:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0082934:	8823      	ldrh	r3, [r4, #0]
d0082936:	490c      	ldr	r1, [pc, #48]	; (d0082968 <emit_rule_word.constprop.0+0x6a4>)
d0082938:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008293c:	805a      	strh	r2, [r3, #2]
d008293e:	8823      	ldrh	r3, [r4, #0]
d0082940:	880a      	ldrh	r2, [r1, #0]
d0082942:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082946:	7058      	strb	r0, [r3, #1]
d0082948:	8823      	ldrh	r3, [r4, #0]
d008294a:	4403      	add	r3, r0
d008294c:	8023      	strh	r3, [r4, #0]
d008294e:	2a00      	cmp	r2, #0
d0082950:	d16a      	bne.n	d0082a28 <emit_rule_word.constprop.0+0x764>
d0082952:	4b04      	ldr	r3, [pc, #16]	; (d0082964 <emit_rule_word.constprop.0+0x6a0>)
d0082954:	4f06      	ldr	r7, [pc, #24]	; (d0082970 <emit_rule_word.constprop.0+0x6ac>)
d0082956:	f04f 0c41 	mov.w	ip, #65	; 0x41
d008295a:	4638      	mov	r0, r7
d008295c:	4667      	mov	r7, ip
d008295e:	4684      	mov	ip, r0
d0082960:	e01b      	b.n	d008299a <emit_rule_word.constprop.0+0x6d6>
d0082962:	bf00      	nop
d0082964:	d0086d88 	.word	0xd0086d88
d0082968:	d0087588 	.word	0xd0087588
d008296c:	01104111 	.word	0x01104111
d0082970:	d0085b24 	.word	0xd0085b24
d0082974:	d00859c8 	.word	0xd00859c8
d0082978:	d0085b74 	.word	0xd0085b74
d008297c:	d0085b38 	.word	0xd0085b38
d0082980:	d0085b14 	.word	0xd0085b14
d0082984:	d00859b8 	.word	0xd00859b8
d0082988:	d00859cc 	.word	0xd00859cc
d008298c:	549f      	strb	r7, [r3, r2]
d008298e:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0082992:	2f00      	cmp	r7, #0
d0082994:	f000 80a9 	beq.w	d0082aea <emit_rule_word.constprop.0+0x826>
d0082998:	4602      	mov	r2, r0
d008299a:	1c50      	adds	r0, r2, #1
d008299c:	f5b0 6f00 	cmp.w	r0, #2048	; 0x800
d00829a0:	b280      	uxth	r0, r0
d00829a2:	d3f3      	bcc.n	d008298c <emit_rule_word.constprop.0+0x6c8>
d00829a4:	2000      	movs	r0, #0
d00829a6:	4617      	mov	r7, r2
d00829a8:	800a      	strh	r2, [r1, #0]
d00829aa:	5498      	strb	r0, [r3, r2]
d00829ac:	f04f 0c00 	mov.w	ip, #0
d00829b0:	f803 c007 	strb.w	ip, [r3, r7]
d00829b4:	8820      	ldrh	r0, [r4, #0]
d00829b6:	f5b0 7f40 	cmp.w	r0, #768	; 0x300
d00829ba:	f4bf acda 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d00829be:	f04f 0b1e 	mov.w	fp, #30
d00829c2:	f04f 0e3e 	mov.w	lr, #62	; 0x3e
d00829c6:	f809 b020 	strb.w	fp, [r9, r0, lsl #2]
d00829ca:	8820      	ldrh	r0, [r4, #0]
d00829cc:	eb09 0080 	add.w	r0, r9, r0, lsl #2
d00829d0:	f8a0 e002 	strh.w	lr, [r0, #2]
d00829d4:	8820      	ldrh	r0, [r4, #0]
d00829d6:	eb09 0080 	add.w	r0, r9, r0, lsl #2
d00829da:	f880 c001 	strb.w	ip, [r0, #1]
d00829de:	8820      	ldrh	r0, [r4, #0]
d00829e0:	3001      	adds	r0, #1
d00829e2:	8020      	strh	r0, [r4, #0]
d00829e4:	bb6a      	cbnz	r2, d0082a42 <emit_rule_word.constprop.0+0x77e>
d00829e6:	2201      	movs	r2, #1
d00829e8:	b292      	uxth	r2, r2
d00829ea:	2052      	movs	r0, #82	; 0x52
d00829ec:	55d8      	strb	r0, [r3, r7]
d00829ee:	4617      	mov	r7, r2
d00829f0:	800a      	strh	r2, [r1, #0]
d00829f2:	e60c      	b.n	d008260e <emit_rule_word.constprop.0+0x34a>
d00829f4:	1c7a      	adds	r2, r7, #1
d00829f6:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00829fa:	f080 827c 	bcs.w	d0082ef6 <emit_rule_word.constprop.0+0xc32>
d00829fe:	4bc3      	ldr	r3, [pc, #780]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082a00:	2020      	movs	r0, #32
d0082a02:	b292      	uxth	r2, r2
d0082a04:	55d8      	strb	r0, [r3, r7]
d0082a06:	2000      	movs	r0, #0
d0082a08:	4617      	mov	r7, r2
d0082a0a:	5498      	strb	r0, [r3, r2]
d0082a0c:	e6d2      	b.n	d00827b4 <emit_rule_word.constprop.0+0x4f0>
d0082a0e:	1c7a      	adds	r2, r7, #1
d0082a10:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082a14:	f080 82ae 	bcs.w	d0082f74 <emit_rule_word.constprop.0+0xcb0>
d0082a18:	4bbc      	ldr	r3, [pc, #752]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082a1a:	2020      	movs	r0, #32
d0082a1c:	b292      	uxth	r2, r2
d0082a1e:	55d8      	strb	r0, [r3, r7]
d0082a20:	2000      	movs	r0, #0
d0082a22:	4617      	mov	r7, r2
d0082a24:	5498      	strb	r0, [r3, r2]
d0082a26:	e696      	b.n	d0082756 <emit_rule_word.constprop.0+0x492>
d0082a28:	1c50      	adds	r0, r2, #1
d0082a2a:	f5b0 6f00 	cmp.w	r0, #2048	; 0x800
d0082a2e:	f080 837b 	bcs.w	d0083128 <emit_rule_word.constprop.0+0xe64>
d0082a32:	4bb6      	ldr	r3, [pc, #728]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082a34:	2720      	movs	r7, #32
d0082a36:	b280      	uxth	r0, r0
d0082a38:	549f      	strb	r7, [r3, r2]
d0082a3a:	2700      	movs	r7, #0
d0082a3c:	4602      	mov	r2, r0
d0082a3e:	541f      	strb	r7, [r3, r0]
d0082a40:	e788      	b.n	d0082954 <emit_rule_word.constprop.0+0x690>
d0082a42:	3201      	adds	r2, #1
d0082a44:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082a48:	f080 8563 	bcs.w	d0083512 <emit_rule_word.constprop.0+0x124e>
d0082a4c:	b292      	uxth	r2, r2
d0082a4e:	2020      	movs	r0, #32
d0082a50:	800a      	strh	r2, [r1, #0]
d0082a52:	55d8      	strb	r0, [r3, r7]
d0082a54:	4617      	mov	r7, r2
d0082a56:	3201      	adds	r2, #1
d0082a58:	f803 c007 	strb.w	ip, [r3, r7]
d0082a5c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082a60:	d3c2      	bcc.n	d00829e8 <emit_rule_word.constprop.0+0x724>
d0082a62:	e5d4      	b.n	d008260e <emit_rule_word.constprop.0+0x34a>
d0082a64:	4602      	mov	r2, r0
d0082a66:	4ba9      	ldr	r3, [pc, #676]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082a68:	e4d1      	b.n	d008240e <emit_rule_word.constprop.0+0x14a>
d0082a6a:	f8df c2a8 	ldr.w	ip, [pc, #680]	; d0082d14 <emit_rule_word.constprop.0+0xa50>
d0082a6e:	465b      	mov	r3, fp
d0082a70:	2070      	movs	r0, #112	; 0x70
d0082a72:	f813 1b01 	ldrb.w	r1, [r3], #1
d0082a76:	4281      	cmp	r1, r0
d0082a78:	d14f      	bne.n	d0082b1a <emit_rule_word.constprop.0+0x856>
d0082a7a:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d0082a7e:	2800      	cmp	r0, #0
d0082a80:	d1f7      	bne.n	d0082a72 <emit_rule_word.constprop.0+0x7ae>
d0082a82:	8823      	ldrh	r3, [r4, #0]
d0082a84:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082a88:	f4bf acd7 	bcs.w	d008243a <emit_rule_word.constprop.0+0x176>
d0082a8c:	2114      	movs	r1, #20
d0082a8e:	2256      	movs	r2, #86	; 0x56
d0082a90:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0082a94:	8823      	ldrh	r3, [r4, #0]
d0082a96:	499e      	ldr	r1, [pc, #632]	; (d0082d10 <emit_rule_word.constprop.0+0xa4c>)
d0082a98:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082a9c:	880f      	ldrh	r7, [r1, #0]
d0082a9e:	805a      	strh	r2, [r3, #2]
d0082aa0:	8823      	ldrh	r3, [r4, #0]
d0082aa2:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082aa6:	7058      	strb	r0, [r3, #1]
d0082aa8:	8823      	ldrh	r3, [r4, #0]
d0082aaa:	3301      	adds	r3, #1
d0082aac:	8023      	strh	r3, [r4, #0]
d0082aae:	2f00      	cmp	r7, #0
d0082ab0:	f000 81b1 	beq.w	d0082e16 <emit_rule_word.constprop.0+0xb52>
d0082ab4:	1c7b      	adds	r3, r7, #1
d0082ab6:	f5b3 6f00 	cmp.w	r3, #2048	; 0x800
d0082aba:	f080 862d 	bcs.w	d0083718 <emit_rule_word.constprop.0+0x1454>
d0082abe:	b29a      	uxth	r2, r3
d0082ac0:	f04f 0c20 	mov.w	ip, #32
d0082ac4:	4b91      	ldr	r3, [pc, #580]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082ac6:	800a      	strh	r2, [r1, #0]
d0082ac8:	f803 c007 	strb.w	ip, [r3, r7]
d0082acc:	1c57      	adds	r7, r2, #1
d0082ace:	5498      	strb	r0, [r3, r2]
d0082ad0:	f5b7 6f00 	cmp.w	r7, #2048	; 0x800
d0082ad4:	d204      	bcs.n	d0082ae0 <emit_rule_word.constprop.0+0x81c>
d0082ad6:	b2b8      	uxth	r0, r7
d0082ad8:	2746      	movs	r7, #70	; 0x46
d0082ada:	549f      	strb	r7, [r3, r2]
d0082adc:	4602      	mov	r2, r0
d0082ade:	8008      	strh	r0, [r1, #0]
d0082ae0:	2100      	movs	r1, #0
d0082ae2:	5499      	strb	r1, [r3, r2]
d0082ae4:	e4a9      	b.n	d008243a <emit_rule_word.constprop.0+0x176>
d0082ae6:	800a      	strh	r2, [r1, #0]
d0082ae8:	e54d      	b.n	d0082586 <emit_rule_word.constprop.0+0x2c2>
d0082aea:	46bc      	mov	ip, r7
d0082aec:	8008      	strh	r0, [r1, #0]
d0082aee:	4607      	mov	r7, r0
d0082af0:	f803 c000 	strb.w	ip, [r3, r0]
d0082af4:	f100 0c01 	add.w	ip, r0, #1
d0082af8:	f5bc 6f00 	cmp.w	ip, #2048	; 0x800
d0082afc:	f080 8689 	bcs.w	d0083812 <emit_rule_word.constprop.0+0x154e>
d0082b00:	3202      	adds	r2, #2
d0082b02:	2727      	movs	r7, #39	; 0x27
d0082b04:	b292      	uxth	r2, r2
d0082b06:	541f      	strb	r7, [r3, r0]
d0082b08:	800a      	strh	r2, [r1, #0]
d0082b0a:	4617      	mov	r7, r2
d0082b0c:	e74e      	b.n	d00829ac <emit_rule_word.constprop.0+0x6e8>
d0082b0e:	4602      	mov	r2, r0
d0082b10:	4b7e      	ldr	r3, [pc, #504]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082b12:	e524      	b.n	d008255e <emit_rule_word.constprop.0+0x29a>
d0082b14:	4602      	mov	r2, r0
d0082b16:	4b7d      	ldr	r3, [pc, #500]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082b18:	e4c1      	b.n	d008249e <emit_rule_word.constprop.0+0x1da>
d0082b1a:	f8df c1fc 	ldr.w	ip, [pc, #508]	; d0082d18 <emit_rule_word.constprop.0+0xa54>
d0082b1e:	465b      	mov	r3, fp
d0082b20:	206e      	movs	r0, #110	; 0x6e
d0082b22:	f813 1b01 	ldrb.w	r1, [r3], #1
d0082b26:	4281      	cmp	r1, r0
d0082b28:	f040 8227 	bne.w	d0082f7a <emit_rule_word.constprop.0+0xcb6>
d0082b2c:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d0082b30:	2800      	cmp	r0, #0
d0082b32:	d1f6      	bne.n	d0082b22 <emit_rule_word.constprop.0+0x85e>
d0082b34:	8823      	ldrh	r3, [r4, #0]
d0082b36:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082b3a:	f4bf ac7e 	bcs.w	d008243a <emit_rule_word.constprop.0+0x176>
d0082b3e:	211c      	movs	r1, #28
d0082b40:	225c      	movs	r2, #92	; 0x5c
d0082b42:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0082b46:	8823      	ldrh	r3, [r4, #0]
d0082b48:	4971      	ldr	r1, [pc, #452]	; (d0082d10 <emit_rule_word.constprop.0+0xa4c>)
d0082b4a:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082b4e:	880f      	ldrh	r7, [r1, #0]
d0082b50:	805a      	strh	r2, [r3, #2]
d0082b52:	8823      	ldrh	r3, [r4, #0]
d0082b54:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082b58:	7058      	strb	r0, [r3, #1]
d0082b5a:	8823      	ldrh	r3, [r4, #0]
d0082b5c:	3301      	adds	r3, #1
d0082b5e:	8023      	strh	r3, [r4, #0]
d0082b60:	2f00      	cmp	r7, #0
d0082b62:	f040 81b9 	bne.w	d0082ed8 <emit_rule_word.constprop.0+0xc14>
d0082b66:	4b69      	ldr	r3, [pc, #420]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082b68:	f8df c1b0 	ldr.w	ip, [pc, #432]	; d0082d1c <emit_rule_word.constprop.0+0xa58>
d0082b6c:	204e      	movs	r0, #78	; 0x4e
d0082b6e:	e004      	b.n	d0082b7a <emit_rule_word.constprop.0+0x8b6>
d0082b70:	55d8      	strb	r0, [r3, r7]
d0082b72:	4617      	mov	r7, r2
d0082b74:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d0082b78:	b128      	cbz	r0, d0082b86 <emit_rule_word.constprop.0+0x8c2>
d0082b7a:	1c7a      	adds	r2, r7, #1
d0082b7c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082b80:	b292      	uxth	r2, r2
d0082b82:	d3f5      	bcc.n	d0082b70 <emit_rule_word.constprop.0+0x8ac>
d0082b84:	e5f7      	b.n	d0082776 <emit_rule_word.constprop.0+0x4b2>
d0082b86:	800a      	strh	r2, [r1, #0]
d0082b88:	e5f6      	b.n	d0082778 <emit_rule_word.constprop.0+0x4b4>
d0082b8a:	8823      	ldrh	r3, [r4, #0]
d0082b8c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082b90:	f4bf abef 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d0082b94:	220e      	movs	r2, #14
d0082b96:	2048      	movs	r0, #72	; 0x48
d0082b98:	495d      	ldr	r1, [pc, #372]	; (d0082d10 <emit_rule_word.constprop.0+0xa4c>)
d0082b9a:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0082b9e:	2200      	movs	r2, #0
d0082ba0:	8823      	ldrh	r3, [r4, #0]
d0082ba2:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082ba6:	8058      	strh	r0, [r3, #2]
d0082ba8:	8823      	ldrh	r3, [r4, #0]
d0082baa:	8808      	ldrh	r0, [r1, #0]
d0082bac:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082bb0:	705a      	strb	r2, [r3, #1]
d0082bb2:	8823      	ldrh	r3, [r4, #0]
d0082bb4:	3301      	adds	r3, #1
d0082bb6:	8023      	strh	r3, [r4, #0]
d0082bb8:	2800      	cmp	r0, #0
d0082bba:	f000 8128 	beq.w	d0082e0e <emit_rule_word.constprop.0+0xb4a>
d0082bbe:	1c42      	adds	r2, r0, #1
d0082bc0:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082bc4:	f080 840d 	bcs.w	d00833e2 <emit_rule_word.constprop.0+0x111e>
d0082bc8:	4b50      	ldr	r3, [pc, #320]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082bca:	2720      	movs	r7, #32
d0082bcc:	b292      	uxth	r2, r2
d0082bce:	541f      	strb	r7, [r3, r0]
d0082bd0:	2700      	movs	r7, #0
d0082bd2:	4610      	mov	r0, r2
d0082bd4:	549f      	strb	r7, [r3, r2]
d0082bd6:	f8df c148 	ldr.w	ip, [pc, #328]	; d0082d20 <emit_rule_word.constprop.0+0xa5c>
d0082bda:	2741      	movs	r7, #65	; 0x41
d0082bdc:	e006      	b.n	d0082bec <emit_rule_word.constprop.0+0x928>
d0082bde:	541f      	strb	r7, [r3, r0]
d0082be0:	4610      	mov	r0, r2
d0082be2:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0082be6:	2f00      	cmp	r7, #0
d0082be8:	f000 8261 	beq.w	d00830ae <emit_rule_word.constprop.0+0xdea>
d0082bec:	1c42      	adds	r2, r0, #1
d0082bee:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082bf2:	b292      	uxth	r2, r2
d0082bf4:	d3f3      	bcc.n	d0082bde <emit_rule_word.constprop.0+0x91a>
d0082bf6:	8008      	strh	r0, [r1, #0]
d0082bf8:	2700      	movs	r7, #0
d0082bfa:	4684      	mov	ip, r0
d0082bfc:	541f      	strb	r7, [r3, r0]
d0082bfe:	8822      	ldrh	r2, [r4, #0]
d0082c00:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0082c04:	f4bf abb5 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d0082c08:	f04f 0b09 	mov.w	fp, #9
d0082c0c:	f04f 0e3c 	mov.w	lr, #60	; 0x3c
d0082c10:	f809 b022 	strb.w	fp, [r9, r2, lsl #2]
d0082c14:	8822      	ldrh	r2, [r4, #0]
d0082c16:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082c1a:	f8a2 e002 	strh.w	lr, [r2, #2]
d0082c1e:	8822      	ldrh	r2, [r4, #0]
d0082c20:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082c24:	7057      	strb	r7, [r2, #1]
d0082c26:	8822      	ldrh	r2, [r4, #0]
d0082c28:	3201      	adds	r2, #1
d0082c2a:	8022      	strh	r2, [r4, #0]
d0082c2c:	2800      	cmp	r0, #0
d0082c2e:	f040 80fb 	bne.w	d0082e28 <emit_rule_word.constprop.0+0xb64>
d0082c32:	2201      	movs	r2, #1
d0082c34:	f8df e0ec 	ldr.w	lr, [pc, #236]	; d0082d24 <emit_rule_word.constprop.0+0xa60>
d0082c38:	2755      	movs	r7, #85	; 0x55
d0082c3a:	e007      	b.n	d0082c4c <emit_rule_word.constprop.0+0x988>
d0082c3c:	541f      	strb	r7, [r3, r0]
d0082c3e:	4660      	mov	r0, ip
d0082c40:	f81e 7f01 	ldrb.w	r7, [lr, #1]!
d0082c44:	1c42      	adds	r2, r0, #1
d0082c46:	2f00      	cmp	r7, #0
d0082c48:	f000 822d 	beq.w	d00830a6 <emit_rule_word.constprop.0+0xde2>
d0082c4c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082c50:	fa1f fc82 	uxth.w	ip, r2
d0082c54:	d3f2      	bcc.n	d0082c3c <emit_rule_word.constprop.0+0x978>
d0082c56:	e495      	b.n	d0082584 <emit_rule_word.constprop.0+0x2c0>
d0082c58:	8823      	ldrh	r3, [r4, #0]
d0082c5a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082c5e:	f4bf ab88 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d0082c62:	220f      	movs	r2, #15
d0082c64:	2048      	movs	r0, #72	; 0x48
d0082c66:	492a      	ldr	r1, [pc, #168]	; (d0082d10 <emit_rule_word.constprop.0+0xa4c>)
d0082c68:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0082c6c:	2200      	movs	r2, #0
d0082c6e:	8823      	ldrh	r3, [r4, #0]
d0082c70:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082c74:	8058      	strh	r0, [r3, #2]
d0082c76:	8823      	ldrh	r3, [r4, #0]
d0082c78:	8808      	ldrh	r0, [r1, #0]
d0082c7a:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082c7e:	705a      	strb	r2, [r3, #1]
d0082c80:	8823      	ldrh	r3, [r4, #0]
d0082c82:	3301      	adds	r3, #1
d0082c84:	8023      	strh	r3, [r4, #0]
d0082c86:	2800      	cmp	r0, #0
d0082c88:	f000 80c3 	beq.w	d0082e12 <emit_rule_word.constprop.0+0xb4e>
d0082c8c:	1c42      	adds	r2, r0, #1
d0082c8e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082c92:	f080 83ae 	bcs.w	d00833f2 <emit_rule_word.constprop.0+0x112e>
d0082c96:	4b1d      	ldr	r3, [pc, #116]	; (d0082d0c <emit_rule_word.constprop.0+0xa48>)
d0082c98:	2720      	movs	r7, #32
d0082c9a:	b292      	uxth	r2, r2
d0082c9c:	541f      	strb	r7, [r3, r0]
d0082c9e:	2700      	movs	r7, #0
d0082ca0:	4610      	mov	r0, r2
d0082ca2:	549f      	strb	r7, [r3, r2]
d0082ca4:	f8df c080 	ldr.w	ip, [pc, #128]	; d0082d28 <emit_rule_word.constprop.0+0xa64>
d0082ca8:	274f      	movs	r7, #79	; 0x4f
d0082caa:	e006      	b.n	d0082cba <emit_rule_word.constprop.0+0x9f6>
d0082cac:	541f      	strb	r7, [r3, r0]
d0082cae:	4610      	mov	r0, r2
d0082cb0:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0082cb4:	2f00      	cmp	r7, #0
d0082cb6:	f000 823e 	beq.w	d0083136 <emit_rule_word.constprop.0+0xe72>
d0082cba:	1c42      	adds	r2, r0, #1
d0082cbc:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082cc0:	b292      	uxth	r2, r2
d0082cc2:	d3f3      	bcc.n	d0082cac <emit_rule_word.constprop.0+0x9e8>
d0082cc4:	8008      	strh	r0, [r1, #0]
d0082cc6:	2700      	movs	r7, #0
d0082cc8:	4684      	mov	ip, r0
d0082cca:	541f      	strb	r7, [r3, r0]
d0082ccc:	8822      	ldrh	r2, [r4, #0]
d0082cce:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0082cd2:	f4bf ab4e 	bcs.w	d0082372 <emit_rule_word.constprop.0+0xae>
d0082cd6:	f04f 0b07 	mov.w	fp, #7
d0082cda:	f04f 0e3c 	mov.w	lr, #60	; 0x3c
d0082cde:	f809 b022 	strb.w	fp, [r9, r2, lsl #2]
d0082ce2:	8822      	ldrh	r2, [r4, #0]
d0082ce4:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082ce8:	f8a2 e002 	strh.w	lr, [r2, #2]
d0082cec:	8822      	ldrh	r2, [r4, #0]
d0082cee:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0082cf2:	7057      	strb	r7, [r2, #1]
d0082cf4:	8822      	ldrh	r2, [r4, #0]
d0082cf6:	3201      	adds	r2, #1
d0082cf8:	8022      	strh	r2, [r4, #0]
d0082cfa:	2800      	cmp	r0, #0
d0082cfc:	f040 80a0 	bne.w	d0082e40 <emit_rule_word.constprop.0+0xb7c>
d0082d00:	2201      	movs	r2, #1
d0082d02:	f8df c028 	ldr.w	ip, [pc, #40]	; d0082d2c <emit_rule_word.constprop.0+0xa68>
d0082d06:	2749      	movs	r7, #73	; 0x49
d0082d08:	e01a      	b.n	d0082d40 <emit_rule_word.constprop.0+0xa7c>
d0082d0a:	bf00      	nop
d0082d0c:	d0086d88 	.word	0xd0086d88
d0082d10:	d0087588 	.word	0xd0087588
d0082d14:	d0085b3c 	.word	0xd0085b3c
d0082d18:	d0085b40 	.word	0xd0085b40
d0082d1c:	d00859e4 	.word	0xd00859e4
d0082d20:	d0085b18 	.word	0xd0085b18
d0082d24:	d0085b1c 	.word	0xd0085b1c
d0082d28:	d0085b20 	.word	0xd0085b20
d0082d2c:	d00859d8 	.word	0xd00859d8
d0082d30:	541f      	strb	r7, [r3, r0]
d0082d32:	4670      	mov	r0, lr
d0082d34:	f81c 7f01 	ldrb.w	r7, [ip, #1]!
d0082d38:	1c42      	adds	r2, r0, #1
d0082d3a:	2f00      	cmp	r7, #0
d0082d3c:	f000 81f7 	beq.w	d008312e <emit_rule_word.constprop.0+0xe6a>
d0082d40:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082d44:	fa1f fe82 	uxth.w	lr, r2
d0082d48:	d3f2      	bcc.n	d0082d30 <emit_rule_word.constprop.0+0xa6c>
d0082d4a:	e41b      	b.n	d0082584 <emit_rule_word.constprop.0+0x2c0>
d0082d4c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082d50:	f4bf ac83 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0082d54:	2102      	movs	r1, #2
d0082d56:	2282      	movs	r2, #130	; 0x82
d0082d58:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0082d5c:	8823      	ldrh	r3, [r4, #0]
d0082d5e:	49c1      	ldr	r1, [pc, #772]	; (d0083064 <emit_rule_word.constprop.0+0xda0>)
d0082d60:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082d64:	f8b1 c000 	ldrh.w	ip, [r1]
d0082d68:	805a      	strh	r2, [r3, #2]
d0082d6a:	8823      	ldrh	r3, [r4, #0]
d0082d6c:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082d70:	7058      	strb	r0, [r3, #1]
d0082d72:	8823      	ldrh	r3, [r4, #0]
d0082d74:	3301      	adds	r3, #1
d0082d76:	8023      	strh	r3, [r4, #0]
d0082d78:	f1bc 0f00 	cmp.w	ip, #0
d0082d7c:	f040 808c 	bne.w	d0082e98 <emit_rule_word.constprop.0+0xbd4>
d0082d80:	4bb9      	ldr	r3, [pc, #740]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082d82:	f8df e2e8 	ldr.w	lr, [pc, #744]	; d008306c <emit_rule_word.constprop.0+0xda8>
d0082d86:	2041      	movs	r0, #65	; 0x41
d0082d88:	e007      	b.n	d0082d9a <emit_rule_word.constprop.0+0xad6>
d0082d8a:	f803 000c 	strb.w	r0, [r3, ip]
d0082d8e:	4694      	mov	ip, r2
d0082d90:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d0082d94:	2800      	cmp	r0, #0
d0082d96:	f000 80ac 	beq.w	d0082ef2 <emit_rule_word.constprop.0+0xc2e>
d0082d9a:	f10c 0201 	add.w	r2, ip, #1
d0082d9e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082da2:	b292      	uxth	r2, r2
d0082da4:	d3f1      	bcc.n	d0082d8a <emit_rule_word.constprop.0+0xac6>
d0082da6:	e55d      	b.n	d0082864 <emit_rule_word.constprop.0+0x5a0>
d0082da8:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082dac:	f4bf ac55 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0082db0:	220b      	movs	r2, #11
d0082db2:	2050      	movs	r0, #80	; 0x50
d0082db4:	49ab      	ldr	r1, [pc, #684]	; (d0083064 <emit_rule_word.constprop.0+0xda0>)
d0082db6:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0082dba:	2200      	movs	r2, #0
d0082dbc:	8823      	ldrh	r3, [r4, #0]
d0082dbe:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082dc2:	8058      	strh	r0, [r3, #2]
d0082dc4:	8823      	ldrh	r3, [r4, #0]
d0082dc6:	8808      	ldrh	r0, [r1, #0]
d0082dc8:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082dcc:	705a      	strb	r2, [r3, #1]
d0082dce:	8823      	ldrh	r3, [r4, #0]
d0082dd0:	3301      	adds	r3, #1
d0082dd2:	8023      	strh	r3, [r4, #0]
d0082dd4:	2800      	cmp	r0, #0
d0082dd6:	d16e      	bne.n	d0082eb6 <emit_rule_word.constprop.0+0xbf2>
d0082dd8:	4ba3      	ldr	r3, [pc, #652]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082dda:	f04f 0c45 	mov.w	ip, #69	; 0x45
d0082dde:	461a      	mov	r2, r3
d0082de0:	f8df e28c 	ldr.w	lr, [pc, #652]	; d0083070 <emit_rule_word.constprop.0+0xdac>
d0082de4:	4663      	mov	r3, ip
d0082de6:	4694      	mov	ip, r2
d0082de8:	e007      	b.n	d0082dfa <emit_rule_word.constprop.0+0xb36>
d0082dea:	f80c 3000 	strb.w	r3, [ip, r0]
d0082dee:	4610      	mov	r0, r2
d0082df0:	f81e 3f01 	ldrb.w	r3, [lr, #1]!
d0082df4:	2b00      	cmp	r3, #0
d0082df6:	f000 8353 	beq.w	d00834a0 <emit_rule_word.constprop.0+0x11dc>
d0082dfa:	1c42      	adds	r2, r0, #1
d0082dfc:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082e00:	b292      	uxth	r2, r2
d0082e02:	d3f2      	bcc.n	d0082dea <emit_rule_word.constprop.0+0xb26>
d0082e04:	4663      	mov	r3, ip
d0082e06:	8008      	strh	r0, [r1, #0]
d0082e08:	2200      	movs	r2, #0
d0082e0a:	541a      	strb	r2, [r3, r0]
d0082e0c:	e425      	b.n	d008265a <emit_rule_word.constprop.0+0x396>
d0082e0e:	4b96      	ldr	r3, [pc, #600]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e10:	e6e1      	b.n	d0082bd6 <emit_rule_word.constprop.0+0x912>
d0082e12:	4b95      	ldr	r3, [pc, #596]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e14:	e746      	b.n	d0082ca4 <emit_rule_word.constprop.0+0x9e0>
d0082e16:	4602      	mov	r2, r0
d0082e18:	4b93      	ldr	r3, [pc, #588]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e1a:	2701      	movs	r7, #1
d0082e1c:	e65b      	b.n	d0082ad6 <emit_rule_word.constprop.0+0x812>
d0082e1e:	4b92      	ldr	r3, [pc, #584]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e20:	e554      	b.n	d00828cc <emit_rule_word.constprop.0+0x608>
d0082e22:	4b91      	ldr	r3, [pc, #580]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e24:	f7ff bbe2 	b.w	d00825ec <emit_rule_word.constprop.0+0x328>
d0082e28:	1c42      	adds	r2, r0, #1
d0082e2a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082e2e:	d204      	bcs.n	d0082e3a <emit_rule_word.constprop.0+0xb76>
d0082e30:	b290      	uxth	r0, r2
d0082e32:	2720      	movs	r7, #32
d0082e34:	1c42      	adds	r2, r0, #1
d0082e36:	f803 700c 	strb.w	r7, [r3, ip]
d0082e3a:	2700      	movs	r7, #0
d0082e3c:	541f      	strb	r7, [r3, r0]
d0082e3e:	e6f9      	b.n	d0082c34 <emit_rule_word.constprop.0+0x970>
d0082e40:	1c42      	adds	r2, r0, #1
d0082e42:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082e46:	d204      	bcs.n	d0082e52 <emit_rule_word.constprop.0+0xb8e>
d0082e48:	b290      	uxth	r0, r2
d0082e4a:	2720      	movs	r7, #32
d0082e4c:	1c42      	adds	r2, r0, #1
d0082e4e:	f803 700c 	strb.w	r7, [r3, ip]
d0082e52:	2700      	movs	r7, #0
d0082e54:	541f      	strb	r7, [r3, r0]
d0082e56:	e754      	b.n	d0082d02 <emit_rule_word.constprop.0+0xa3e>
d0082e58:	1c42      	adds	r2, r0, #1
d0082e5a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082e5e:	f080 8322 	bcs.w	d00834a6 <emit_rule_word.constprop.0+0x11e2>
d0082e62:	4b81      	ldr	r3, [pc, #516]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e64:	f04f 0c20 	mov.w	ip, #32
d0082e68:	b292      	uxth	r2, r2
d0082e6a:	f803 c000 	strb.w	ip, [r3, r0]
d0082e6e:	f04f 0c00 	mov.w	ip, #0
d0082e72:	4610      	mov	r0, r2
d0082e74:	f803 c002 	strb.w	ip, [r3, r2]
d0082e78:	e429      	b.n	d00826ce <emit_rule_word.constprop.0+0x40a>
d0082e7a:	f10c 0201 	add.w	r2, ip, #1
d0082e7e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082e82:	f080 833c 	bcs.w	d00834fe <emit_rule_word.constprop.0+0x123a>
d0082e86:	4b78      	ldr	r3, [pc, #480]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082e88:	2020      	movs	r0, #32
d0082e8a:	b292      	uxth	r2, r2
d0082e8c:	f803 000c 	strb.w	r0, [r3, ip]
d0082e90:	2000      	movs	r0, #0
d0082e92:	4694      	mov	ip, r2
d0082e94:	5498      	strb	r0, [r3, r2]
d0082e96:	e4d3      	b.n	d0082840 <emit_rule_word.constprop.0+0x57c>
d0082e98:	f10c 0201 	add.w	r2, ip, #1
d0082e9c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082ea0:	f080 8424 	bcs.w	d00836ec <emit_rule_word.constprop.0+0x1428>
d0082ea4:	4b70      	ldr	r3, [pc, #448]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082ea6:	2020      	movs	r0, #32
d0082ea8:	b292      	uxth	r2, r2
d0082eaa:	f803 000c 	strb.w	r0, [r3, ip]
d0082eae:	2000      	movs	r0, #0
d0082eb0:	4694      	mov	ip, r2
d0082eb2:	5498      	strb	r0, [r3, r2]
d0082eb4:	e765      	b.n	d0082d82 <emit_rule_word.constprop.0+0xabe>
d0082eb6:	1c42      	adds	r2, r0, #1
d0082eb8:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082ebc:	f080 8412 	bcs.w	d00836e4 <emit_rule_word.constprop.0+0x1420>
d0082ec0:	4b69      	ldr	r3, [pc, #420]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082ec2:	f04f 0c20 	mov.w	ip, #32
d0082ec6:	b292      	uxth	r2, r2
d0082ec8:	f803 c000 	strb.w	ip, [r3, r0]
d0082ecc:	f04f 0c00 	mov.w	ip, #0
d0082ed0:	4610      	mov	r0, r2
d0082ed2:	f803 c002 	strb.w	ip, [r3, r2]
d0082ed6:	e780      	b.n	d0082dda <emit_rule_word.constprop.0+0xb16>
d0082ed8:	1c7a      	adds	r2, r7, #1
d0082eda:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082ede:	f080 83fb 	bcs.w	d00836d8 <emit_rule_word.constprop.0+0x1414>
d0082ee2:	4b61      	ldr	r3, [pc, #388]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082ee4:	2020      	movs	r0, #32
d0082ee6:	b292      	uxth	r2, r2
d0082ee8:	55d8      	strb	r0, [r3, r7]
d0082eea:	2000      	movs	r0, #0
d0082eec:	4617      	mov	r7, r2
d0082eee:	5498      	strb	r0, [r3, r2]
d0082ef0:	e63a      	b.n	d0082b68 <emit_rule_word.constprop.0+0x8a4>
d0082ef2:	800a      	strh	r2, [r1, #0]
d0082ef4:	e4b8      	b.n	d0082868 <emit_rule_word.constprop.0+0x5a4>
d0082ef6:	463a      	mov	r2, r7
d0082ef8:	4b5b      	ldr	r3, [pc, #364]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082efa:	e584      	b.n	d0082a06 <emit_rule_word.constprop.0+0x742>
d0082efc:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082f00:	f4bf abab 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0082f04:	220d      	movs	r2, #13
d0082f06:	205a      	movs	r0, #90	; 0x5a
d0082f08:	4956      	ldr	r1, [pc, #344]	; (d0083064 <emit_rule_word.constprop.0+0xda0>)
d0082f0a:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0082f0e:	2200      	movs	r2, #0
d0082f10:	8823      	ldrh	r3, [r4, #0]
d0082f12:	f8b1 c000 	ldrh.w	ip, [r1]
d0082f16:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082f1a:	8058      	strh	r0, [r3, #2]
d0082f1c:	8823      	ldrh	r3, [r4, #0]
d0082f1e:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082f22:	705a      	strb	r2, [r3, #1]
d0082f24:	8823      	ldrh	r3, [r4, #0]
d0082f26:	3301      	adds	r3, #1
d0082f28:	8023      	strh	r3, [r4, #0]
d0082f2a:	f1bc 0f00 	cmp.w	ip, #0
d0082f2e:	d112      	bne.n	d0082f56 <emit_rule_word.constprop.0+0xc92>
d0082f30:	4b4d      	ldr	r3, [pc, #308]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082f32:	f8df e140 	ldr.w	lr, [pc, #320]	; d0083074 <emit_rule_word.constprop.0+0xdb0>
d0082f36:	204f      	movs	r0, #79	; 0x4f
d0082f38:	e006      	b.n	d0082f48 <emit_rule_word.constprop.0+0xc84>
d0082f3a:	f803 000c 	strb.w	r0, [r3, ip]
d0082f3e:	4694      	mov	ip, r2
d0082f40:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d0082f44:	2800      	cmp	r0, #0
d0082f46:	d0d4      	beq.n	d0082ef2 <emit_rule_word.constprop.0+0xc2e>
d0082f48:	f10c 0201 	add.w	r2, ip, #1
d0082f4c:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082f50:	b292      	uxth	r2, r2
d0082f52:	d3f2      	bcc.n	d0082f3a <emit_rule_word.constprop.0+0xc76>
d0082f54:	e486      	b.n	d0082864 <emit_rule_word.constprop.0+0x5a0>
d0082f56:	f10c 0201 	add.w	r2, ip, #1
d0082f5a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082f5e:	f080 83c9 	bcs.w	d00836f4 <emit_rule_word.constprop.0+0x1430>
d0082f62:	4b41      	ldr	r3, [pc, #260]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082f64:	2020      	movs	r0, #32
d0082f66:	b292      	uxth	r2, r2
d0082f68:	f803 000c 	strb.w	r0, [r3, ip]
d0082f6c:	2000      	movs	r0, #0
d0082f6e:	4694      	mov	ip, r2
d0082f70:	5498      	strb	r0, [r3, r2]
d0082f72:	e7de      	b.n	d0082f32 <emit_rule_word.constprop.0+0xc6e>
d0082f74:	463a      	mov	r2, r7
d0082f76:	4b3c      	ldr	r3, [pc, #240]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082f78:	e552      	b.n	d0082a20 <emit_rule_word.constprop.0+0x75c>
d0082f7a:	f8df c0fc 	ldr.w	ip, [pc, #252]	; d0083078 <emit_rule_word.constprop.0+0xdb4>
d0082f7e:	465b      	mov	r3, fp
d0082f80:	2063      	movs	r0, #99	; 0x63
d0082f82:	f813 1b01 	ldrb.w	r1, [r3], #1
d0082f86:	4281      	cmp	r1, r0
d0082f88:	f040 8236 	bne.w	d00833f8 <emit_rule_word.constprop.0+0x1134>
d0082f8c:	f81c 0f01 	ldrb.w	r0, [ip, #1]!
d0082f90:	2800      	cmp	r0, #0
d0082f92:	d1f6      	bne.n	d0082f82 <emit_rule_word.constprop.0+0xcbe>
d0082f94:	8823      	ldrh	r3, [r4, #0]
d0082f96:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0082f9a:	f4bf aa4e 	bcs.w	d008243a <emit_rule_word.constprop.0+0x176>
d0082f9e:	2118      	movs	r1, #24
d0082fa0:	224c      	movs	r2, #76	; 0x4c
d0082fa2:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0082fa6:	8823      	ldrh	r3, [r4, #0]
d0082fa8:	492e      	ldr	r1, [pc, #184]	; (d0083064 <emit_rule_word.constprop.0+0xda0>)
d0082faa:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082fae:	f8b1 c000 	ldrh.w	ip, [r1]
d0082fb2:	805a      	strh	r2, [r3, #2]
d0082fb4:	8823      	ldrh	r3, [r4, #0]
d0082fb6:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0082fba:	7058      	strb	r0, [r3, #1]
d0082fbc:	8823      	ldrh	r3, [r4, #0]
d0082fbe:	3301      	adds	r3, #1
d0082fc0:	8023      	strh	r3, [r4, #0]
d0082fc2:	f1bc 0f00 	cmp.w	ip, #0
d0082fc6:	d108      	bne.n	d0082fda <emit_rule_word.constprop.0+0xd16>
d0082fc8:	4684      	mov	ip, r0
d0082fca:	4b27      	ldr	r3, [pc, #156]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082fcc:	2701      	movs	r7, #1
d0082fce:	b2ba      	uxth	r2, r7
d0082fd0:	204b      	movs	r0, #75	; 0x4b
d0082fd2:	800a      	strh	r2, [r1, #0]
d0082fd4:	f803 000c 	strb.w	r0, [r3, ip]
d0082fd8:	e582      	b.n	d0082ae0 <emit_rule_word.constprop.0+0x81c>
d0082fda:	f10c 0201 	add.w	r2, ip, #1
d0082fde:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0082fe2:	f080 8410 	bcs.w	d0083806 <emit_rule_word.constprop.0+0x1542>
d0082fe6:	b292      	uxth	r2, r2
d0082fe8:	4b1f      	ldr	r3, [pc, #124]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0082fea:	f04f 0e20 	mov.w	lr, #32
d0082fee:	1c57      	adds	r7, r2, #1
d0082ff0:	800a      	strh	r2, [r1, #0]
d0082ff2:	f803 e00c 	strb.w	lr, [r3, ip]
d0082ff6:	4694      	mov	ip, r2
d0082ff8:	f5b7 6f00 	cmp.w	r7, #2048	; 0x800
d0082ffc:	5498      	strb	r0, [r3, r2]
d0082ffe:	d3e6      	bcc.n	d0082fce <emit_rule_word.constprop.0+0xd0a>
d0083000:	e56e      	b.n	d0082ae0 <emit_rule_word.constprop.0+0x81c>
d0083002:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0083006:	f4bf ab28 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d008300a:	2208      	movs	r2, #8
d008300c:	207d      	movs	r0, #125	; 0x7d
d008300e:	4915      	ldr	r1, [pc, #84]	; (d0083064 <emit_rule_word.constprop.0+0xda0>)
d0083010:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d0083014:	2200      	movs	r2, #0
d0083016:	8823      	ldrh	r3, [r4, #0]
d0083018:	f8b1 c000 	ldrh.w	ip, [r1]
d008301c:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083020:	8058      	strh	r0, [r3, #2]
d0083022:	8823      	ldrh	r3, [r4, #0]
d0083024:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083028:	705a      	strb	r2, [r3, #1]
d008302a:	8823      	ldrh	r3, [r4, #0]
d008302c:	3301      	adds	r3, #1
d008302e:	8023      	strh	r3, [r4, #0]
d0083030:	f1bc 0f00 	cmp.w	ip, #0
d0083034:	d124      	bne.n	d0083080 <emit_rule_word.constprop.0+0xdbc>
d0083036:	4b0c      	ldr	r3, [pc, #48]	; (d0083068 <emit_rule_word.constprop.0+0xda4>)
d0083038:	f8df e040 	ldr.w	lr, [pc, #64]	; d008307c <emit_rule_word.constprop.0+0xdb8>
d008303c:	2049      	movs	r0, #73	; 0x49
d008303e:	e005      	b.n	d008304c <emit_rule_word.constprop.0+0xd88>
d0083040:	f803 000c 	strb.w	r0, [r3, ip]
d0083044:	4694      	mov	ip, r2
d0083046:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d008304a:	b348      	cbz	r0, d00830a0 <emit_rule_word.constprop.0+0xddc>
d008304c:	f10c 0201 	add.w	r2, ip, #1
d0083050:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083054:	b292      	uxth	r2, r2
d0083056:	d3f3      	bcc.n	d0083040 <emit_rule_word.constprop.0+0xd7c>
d0083058:	4662      	mov	r2, ip
d008305a:	f8a1 c000 	strh.w	ip, [r1]
d008305e:	f7ff bb4e 	b.w	d00826fe <emit_rule_word.constprop.0+0x43a>
d0083062:	bf00      	nop
d0083064:	d0087588 	.word	0xd0087588
d0083068:	d0086d88 	.word	0xd0086d88
d008306c:	d00859a8 	.word	0xd00859a8
d0083070:	d0085b14 	.word	0xd0085b14
d0083074:	d0085b28 	.word	0xd0085b28
d0083078:	d0085b44 	.word	0xd0085b44
d008307c:	d00859b8 	.word	0xd00859b8
d0083080:	f10c 0201 	add.w	r2, ip, #1
d0083084:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083088:	f080 8329 	bcs.w	d00836de <emit_rule_word.constprop.0+0x141a>
d008308c:	4bc5      	ldr	r3, [pc, #788]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d008308e:	2020      	movs	r0, #32
d0083090:	b292      	uxth	r2, r2
d0083092:	f803 000c 	strb.w	r0, [r3, ip]
d0083096:	2000      	movs	r0, #0
d0083098:	4694      	mov	ip, r2
d008309a:	5498      	strb	r0, [r3, r2]
d008309c:	e7cc      	b.n	d0083038 <emit_rule_word.constprop.0+0xd74>
d008309e:	4663      	mov	r3, ip
d00830a0:	800a      	strh	r2, [r1, #0]
d00830a2:	f7ff bb2c 	b.w	d00826fe <emit_rule_word.constprop.0+0x43a>
d00830a6:	f8a1 c000 	strh.w	ip, [r1]
d00830aa:	f7ff ba6c 	b.w	d0082586 <emit_rule_word.constprop.0+0x2c2>
d00830ae:	800a      	strh	r2, [r1, #0]
d00830b0:	e5a2      	b.n	d0082bf8 <emit_rule_word.constprop.0+0x934>
d00830b2:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00830b6:	f4bf aad0 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d00830ba:	2105      	movs	r1, #5
d00830bc:	2278      	movs	r2, #120	; 0x78
d00830be:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d00830c2:	8823      	ldrh	r3, [r4, #0]
d00830c4:	49b8      	ldr	r1, [pc, #736]	; (d00833a8 <emit_rule_word.constprop.0+0x10e4>)
d00830c6:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00830ca:	f8b1 c000 	ldrh.w	ip, [r1]
d00830ce:	805a      	strh	r2, [r3, #2]
d00830d0:	8823      	ldrh	r3, [r4, #0]
d00830d2:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00830d6:	7058      	strb	r0, [r3, #1]
d00830d8:	8823      	ldrh	r3, [r4, #0]
d00830da:	3301      	adds	r3, #1
d00830dc:	8023      	strh	r3, [r4, #0]
d00830de:	f1bc 0f00 	cmp.w	ip, #0
d00830e2:	d112      	bne.n	d008310a <emit_rule_word.constprop.0+0xe46>
d00830e4:	4baf      	ldr	r3, [pc, #700]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d00830e6:	f8df e2c4 	ldr.w	lr, [pc, #708]	; d00833ac <emit_rule_word.constprop.0+0x10e8>
d00830ea:	2045      	movs	r0, #69	; 0x45
d00830ec:	e006      	b.n	d00830fc <emit_rule_word.constprop.0+0xe38>
d00830ee:	f803 000c 	strb.w	r0, [r3, ip]
d00830f2:	4694      	mov	ip, r2
d00830f4:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d00830f8:	2800      	cmp	r0, #0
d00830fa:	d0d1      	beq.n	d00830a0 <emit_rule_word.constprop.0+0xddc>
d00830fc:	f10c 0201 	add.w	r2, ip, #1
d0083100:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083104:	b292      	uxth	r2, r2
d0083106:	d3f2      	bcc.n	d00830ee <emit_rule_word.constprop.0+0xe2a>
d0083108:	e7a6      	b.n	d0083058 <emit_rule_word.constprop.0+0xd94>
d008310a:	f10c 0201 	add.w	r2, ip, #1
d008310e:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083112:	f080 82f2 	bcs.w	d00836fa <emit_rule_word.constprop.0+0x1436>
d0083116:	4ba3      	ldr	r3, [pc, #652]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d0083118:	2020      	movs	r0, #32
d008311a:	b292      	uxth	r2, r2
d008311c:	f803 000c 	strb.w	r0, [r3, ip]
d0083120:	2000      	movs	r0, #0
d0083122:	4694      	mov	ip, r2
d0083124:	5498      	strb	r0, [r3, r2]
d0083126:	e7de      	b.n	d00830e6 <emit_rule_word.constprop.0+0xe22>
d0083128:	4610      	mov	r0, r2
d008312a:	4b9e      	ldr	r3, [pc, #632]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d008312c:	e485      	b.n	d0082a3a <emit_rule_word.constprop.0+0x776>
d008312e:	f8a1 e000 	strh.w	lr, [r1]
d0083132:	f7ff ba28 	b.w	d0082586 <emit_rule_word.constprop.0+0x2c2>
d0083136:	800a      	strh	r2, [r1, #0]
d0083138:	e5c5      	b.n	d0082cc6 <emit_rule_word.constprop.0+0xa02>
d008313a:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008313e:	f4bf aa8c 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083142:	2101      	movs	r1, #1
d0083144:	2278      	movs	r2, #120	; 0x78
d0083146:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d008314a:	8823      	ldrh	r3, [r4, #0]
d008314c:	4996      	ldr	r1, [pc, #600]	; (d00833a8 <emit_rule_word.constprop.0+0x10e4>)
d008314e:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083152:	f8b1 c000 	ldrh.w	ip, [r1]
d0083156:	805a      	strh	r2, [r3, #2]
d0083158:	8823      	ldrh	r3, [r4, #0]
d008315a:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008315e:	7058      	strb	r0, [r3, #1]
d0083160:	8823      	ldrh	r3, [r4, #0]
d0083162:	3301      	adds	r3, #1
d0083164:	8023      	strh	r3, [r4, #0]
d0083166:	f1bc 0f00 	cmp.w	ip, #0
d008316a:	d114      	bne.n	d0083196 <emit_rule_word.constprop.0+0xed2>
d008316c:	4b8d      	ldr	r3, [pc, #564]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d008316e:	f8df e240 	ldr.w	lr, [pc, #576]	; d00833b0 <emit_rule_word.constprop.0+0x10ec>
d0083172:	2041      	movs	r0, #65	; 0x41
d0083174:	e007      	b.n	d0083186 <emit_rule_word.constprop.0+0xec2>
d0083176:	f803 000c 	strb.w	r0, [r3, ip]
d008317a:	4694      	mov	ip, r2
d008317c:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d0083180:	2800      	cmp	r0, #0
d0083182:	f43f aeb6 	beq.w	d0082ef2 <emit_rule_word.constprop.0+0xc2e>
d0083186:	f10c 0201 	add.w	r2, ip, #1
d008318a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008318e:	b292      	uxth	r2, r2
d0083190:	d3f1      	bcc.n	d0083176 <emit_rule_word.constprop.0+0xeb2>
d0083192:	f7ff bb67 	b.w	d0082864 <emit_rule_word.constprop.0+0x5a0>
d0083196:	f10c 0201 	add.w	r2, ip, #1
d008319a:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008319e:	f080 82af 	bcs.w	d0083700 <emit_rule_word.constprop.0+0x143c>
d00831a2:	4b80      	ldr	r3, [pc, #512]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d00831a4:	2020      	movs	r0, #32
d00831a6:	b292      	uxth	r2, r2
d00831a8:	f803 000c 	strb.w	r0, [r3, ip]
d00831ac:	2000      	movs	r0, #0
d00831ae:	4694      	mov	ip, r2
d00831b0:	5498      	strb	r0, [r3, r2]
d00831b2:	e7dc      	b.n	d008316e <emit_rule_word.constprop.0+0xeaa>
d00831b4:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d00831b8:	f4bf aa4f 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d00831bc:	f04f 0c07 	mov.w	ip, #7
d00831c0:	4979      	ldr	r1, [pc, #484]	; (d00833a8 <emit_rule_word.constprop.0+0x10e4>)
d00831c2:	f809 c023 	strb.w	ip, [r9, r3, lsl #2]
d00831c6:	8823      	ldrh	r3, [r4, #0]
d00831c8:	f8b1 c000 	ldrh.w	ip, [r1]
d00831cc:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00831d0:	805a      	strh	r2, [r3, #2]
d00831d2:	8823      	ldrh	r3, [r4, #0]
d00831d4:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d00831d8:	7058      	strb	r0, [r3, #1]
d00831da:	8823      	ldrh	r3, [r4, #0]
d00831dc:	3301      	adds	r3, #1
d00831de:	8023      	strh	r3, [r4, #0]
d00831e0:	f1bc 0f00 	cmp.w	ip, #0
d00831e4:	d113      	bne.n	d008320e <emit_rule_word.constprop.0+0xf4a>
d00831e6:	4b6f      	ldr	r3, [pc, #444]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d00831e8:	f8df e1c8 	ldr.w	lr, [pc, #456]	; d00833b4 <emit_rule_word.constprop.0+0x10f0>
d00831ec:	2049      	movs	r0, #73	; 0x49
d00831ee:	e007      	b.n	d0083200 <emit_rule_word.constprop.0+0xf3c>
d00831f0:	f803 000c 	strb.w	r0, [r3, ip]
d00831f4:	4694      	mov	ip, r2
d00831f6:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d00831fa:	2800      	cmp	r0, #0
d00831fc:	f43f af50 	beq.w	d00830a0 <emit_rule_word.constprop.0+0xddc>
d0083200:	f10c 0201 	add.w	r2, ip, #1
d0083204:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083208:	b292      	uxth	r2, r2
d008320a:	d3f1      	bcc.n	d00831f0 <emit_rule_word.constprop.0+0xf2c>
d008320c:	e724      	b.n	d0083058 <emit_rule_word.constprop.0+0xd94>
d008320e:	f10c 0201 	add.w	r2, ip, #1
d0083212:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083216:	f080 827c 	bcs.w	d0083712 <emit_rule_word.constprop.0+0x144e>
d008321a:	4b62      	ldr	r3, [pc, #392]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d008321c:	2020      	movs	r0, #32
d008321e:	b292      	uxth	r2, r2
d0083220:	f803 000c 	strb.w	r0, [r3, ip]
d0083224:	2000      	movs	r0, #0
d0083226:	4694      	mov	ip, r2
d0083228:	5498      	strb	r0, [r3, r2]
d008322a:	e7dd      	b.n	d00831e8 <emit_rule_word.constprop.0+0xf24>
d008322c:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d0083230:	f4bf aa13 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083234:	220c      	movs	r2, #12
d0083236:	2048      	movs	r0, #72	; 0x48
d0083238:	495b      	ldr	r1, [pc, #364]	; (d00833a8 <emit_rule_word.constprop.0+0x10e4>)
d008323a:	f809 2023 	strb.w	r2, [r9, r3, lsl #2]
d008323e:	2200      	movs	r2, #0
d0083240:	8823      	ldrh	r3, [r4, #0]
d0083242:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083246:	8058      	strh	r0, [r3, #2]
d0083248:	8823      	ldrh	r3, [r4, #0]
d008324a:	8808      	ldrh	r0, [r1, #0]
d008324c:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083250:	705a      	strb	r2, [r3, #1]
d0083252:	8823      	ldrh	r3, [r4, #0]
d0083254:	3301      	adds	r3, #1
d0083256:	8023      	strh	r3, [r4, #0]
d0083258:	2800      	cmp	r0, #0
d008325a:	d164      	bne.n	d0083326 <emit_rule_word.constprop.0+0x1062>
d008325c:	4b51      	ldr	r3, [pc, #324]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d008325e:	f04f 0c41 	mov.w	ip, #65	; 0x41
d0083262:	461a      	mov	r2, r3
d0083264:	f8df e150 	ldr.w	lr, [pc, #336]	; d00833b8 <emit_rule_word.constprop.0+0x10f4>
d0083268:	4663      	mov	r3, ip
d008326a:	4694      	mov	ip, r2
d008326c:	e007      	b.n	d008327e <emit_rule_word.constprop.0+0xfba>
d008326e:	f80c 3000 	strb.w	r3, [ip, r0]
d0083272:	4610      	mov	r0, r2
d0083274:	f81e 3f01 	ldrb.w	r3, [lr, #1]!
d0083278:	2b00      	cmp	r3, #0
d008327a:	f000 8147 	beq.w	d008350c <emit_rule_word.constprop.0+0x1248>
d008327e:	1c42      	adds	r2, r0, #1
d0083280:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d0083284:	b292      	uxth	r2, r2
d0083286:	d3f2      	bcc.n	d008326e <emit_rule_word.constprop.0+0xfaa>
d0083288:	4663      	mov	r3, ip
d008328a:	4602      	mov	r2, r0
d008328c:	8008      	strh	r0, [r1, #0]
d008328e:	f04f 0c00 	mov.w	ip, #0
d0083292:	4696      	mov	lr, r2
d0083294:	f803 c002 	strb.w	ip, [r3, r2]
d0083298:	8820      	ldrh	r0, [r4, #0]
d008329a:	f5b0 7f40 	cmp.w	r0, #768	; 0x300
d008329e:	f4bf a9dc 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d00832a2:	f04f 0b08 	mov.w	fp, #8
d00832a6:	f04f 0a3c 	mov.w	sl, #60	; 0x3c
d00832aa:	f809 b020 	strb.w	fp, [r9, r0, lsl #2]
d00832ae:	8820      	ldrh	r0, [r4, #0]
d00832b0:	eb09 0080 	add.w	r0, r9, r0, lsl #2
d00832b4:	f8a0 a002 	strh.w	sl, [r0, #2]
d00832b8:	8820      	ldrh	r0, [r4, #0]
d00832ba:	eb09 0080 	add.w	r0, r9, r0, lsl #2
d00832be:	f880 c001 	strb.w	ip, [r0, #1]
d00832c2:	8820      	ldrh	r0, [r4, #0]
d00832c4:	3001      	adds	r0, #1
d00832c6:	8020      	strh	r0, [r4, #0]
d00832c8:	b9f2      	cbnz	r2, d0083308 <emit_rule_word.constprop.0+0x1044>
d00832ca:	2001      	movs	r0, #1
d00832cc:	f04f 0c49 	mov.w	ip, #73	; 0x49
d00832d0:	469e      	mov	lr, r3
d00832d2:	f8df a0e8 	ldr.w	sl, [pc, #232]	; d00833bc <emit_rule_word.constprop.0+0x10f8>
d00832d6:	4663      	mov	r3, ip
d00832d8:	46f4      	mov	ip, lr
d00832da:	e008      	b.n	d00832ee <emit_rule_word.constprop.0+0x102a>
d00832dc:	f80c 3002 	strb.w	r3, [ip, r2]
d00832e0:	4672      	mov	r2, lr
d00832e2:	f81a 3f01 	ldrb.w	r3, [sl, #1]!
d00832e6:	1c50      	adds	r0, r2, #1
d00832e8:	2b00      	cmp	r3, #0
d00832ea:	f000 810b 	beq.w	d0083504 <emit_rule_word.constprop.0+0x1240>
d00832ee:	f5b0 6f00 	cmp.w	r0, #2048	; 0x800
d00832f2:	fa1f fe80 	uxth.w	lr, r0
d00832f6:	d3f1      	bcc.n	d00832dc <emit_rule_word.constprop.0+0x1018>
d00832f8:	4663      	mov	r3, ip
d00832fa:	4696      	mov	lr, r2
d00832fc:	800a      	strh	r2, [r1, #0]
d00832fe:	2200      	movs	r2, #0
d0083300:	f803 200e 	strb.w	r2, [r3, lr]
d0083304:	f7ff b9a9 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083308:	1c50      	adds	r0, r2, #1
d008330a:	f5b0 6f00 	cmp.w	r0, #2048	; 0x800
d008330e:	d205      	bcs.n	d008331c <emit_rule_word.constprop.0+0x1058>
d0083310:	b282      	uxth	r2, r0
d0083312:	f04f 0c20 	mov.w	ip, #32
d0083316:	1c50      	adds	r0, r2, #1
d0083318:	f803 c00e 	strb.w	ip, [r3, lr]
d008331c:	f04f 0c00 	mov.w	ip, #0
d0083320:	f803 c002 	strb.w	ip, [r3, r2]
d0083324:	e7d2      	b.n	d00832cc <emit_rule_word.constprop.0+0x1008>
d0083326:	1c42      	adds	r2, r0, #1
d0083328:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008332c:	f080 81eb 	bcs.w	d0083706 <emit_rule_word.constprop.0+0x1442>
d0083330:	4b1c      	ldr	r3, [pc, #112]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d0083332:	f04f 0c20 	mov.w	ip, #32
d0083336:	b292      	uxth	r2, r2
d0083338:	f803 c000 	strb.w	ip, [r3, r0]
d008333c:	f04f 0c00 	mov.w	ip, #0
d0083340:	4610      	mov	r0, r2
d0083342:	f803 c002 	strb.w	ip, [r3, r2]
d0083346:	e78a      	b.n	d008325e <emit_rule_word.constprop.0+0xf9a>
d0083348:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008334c:	f4bf a985 	bcs.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083350:	2103      	movs	r1, #3
d0083352:	2287      	movs	r2, #135	; 0x87
d0083354:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0083358:	8823      	ldrh	r3, [r4, #0]
d008335a:	4913      	ldr	r1, [pc, #76]	; (d00833a8 <emit_rule_word.constprop.0+0x10e4>)
d008335c:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083360:	f8b1 c000 	ldrh.w	ip, [r1]
d0083364:	805a      	strh	r2, [r3, #2]
d0083366:	8823      	ldrh	r3, [r4, #0]
d0083368:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008336c:	7058      	strb	r0, [r3, #1]
d008336e:	8823      	ldrh	r3, [r4, #0]
d0083370:	3301      	adds	r3, #1
d0083372:	8023      	strh	r3, [r4, #0]
d0083374:	f1bc 0f00 	cmp.w	ip, #0
d0083378:	d124      	bne.n	d00833c4 <emit_rule_word.constprop.0+0x1100>
d008337a:	4b0a      	ldr	r3, [pc, #40]	; (d00833a4 <emit_rule_word.constprop.0+0x10e0>)
d008337c:	f8df e040 	ldr.w	lr, [pc, #64]	; d00833c0 <emit_rule_word.constprop.0+0x10fc>
d0083380:	2041      	movs	r0, #65	; 0x41
d0083382:	e007      	b.n	d0083394 <emit_rule_word.constprop.0+0x10d0>
d0083384:	f803 000c 	strb.w	r0, [r3, ip]
d0083388:	4694      	mov	ip, r2
d008338a:	f81e 0f01 	ldrb.w	r0, [lr, #1]!
d008338e:	2800      	cmp	r0, #0
d0083390:	f43f ae86 	beq.w	d00830a0 <emit_rule_word.constprop.0+0xddc>
d0083394:	f10c 0201 	add.w	r2, ip, #1
d0083398:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d008339c:	b292      	uxth	r2, r2
d008339e:	d3f1      	bcc.n	d0083384 <emit_rule_word.constprop.0+0x10c0>
d00833a0:	e65a      	b.n	d0083058 <emit_rule_word.constprop.0+0xd94>
d00833a2:	bf00      	nop
d00833a4:	d0086d88 	.word	0xd0086d88
d00833a8:	d0087588 	.word	0xd0087588
d00833ac:	d0085b2c 	.word	0xd0085b2c
d00833b0:	d00859a0 	.word	0xd00859a0
d00833b4:	d00859d8 	.word	0xd00859d8
d00833b8:	d00859a4 	.word	0xd00859a4
d00833bc:	d00859b8 	.word	0xd00859b8
d00833c0:	d00859b4 	.word	0xd00859b4
d00833c4:	f10c 0201 	add.w	r2, ip, #1
d00833c8:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00833cc:	f080 819e 	bcs.w	d008370c <emit_rule_word.constprop.0+0x1448>
d00833d0:	4bd4      	ldr	r3, [pc, #848]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00833d2:	2020      	movs	r0, #32
d00833d4:	b292      	uxth	r2, r2
d00833d6:	f803 000c 	strb.w	r0, [r3, ip]
d00833da:	2000      	movs	r0, #0
d00833dc:	4694      	mov	ip, r2
d00833de:	5498      	strb	r0, [r3, r2]
d00833e0:	e7cc      	b.n	d008337c <emit_rule_word.constprop.0+0x10b8>
d00833e2:	4602      	mov	r2, r0
d00833e4:	4bcf      	ldr	r3, [pc, #828]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00833e6:	f7ff bbf3 	b.w	d0082bd0 <emit_rule_word.constprop.0+0x90c>
d00833ea:	463a      	mov	r2, r7
d00833ec:	4bcd      	ldr	r3, [pc, #820]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00833ee:	f7ff ba6a 	b.w	d00828c6 <emit_rule_word.constprop.0+0x602>
d00833f2:	4602      	mov	r2, r0
d00833f4:	4bcb      	ldr	r3, [pc, #812]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00833f6:	e452      	b.n	d0082c9e <emit_rule_word.constprop.0+0x9da>
d00833f8:	48cb      	ldr	r0, [pc, #812]	; (d0083728 <emit_rule_word.constprop.0+0x1464>)
d00833fa:	4659      	mov	r1, fp
d00833fc:	2371      	movs	r3, #113	; 0x71
d00833fe:	f811 cb01 	ldrb.w	ip, [r1], #1
d0083402:	459c      	cmp	ip, r3
d0083404:	f040 8089 	bne.w	d008351a <emit_rule_word.constprop.0+0x1256>
d0083408:	f810 3f01 	ldrb.w	r3, [r0, #1]!
d008340c:	2b00      	cmp	r3, #0
d008340e:	d1f6      	bne.n	d00833fe <emit_rule_word.constprop.0+0x113a>
d0083410:	8822      	ldrh	r2, [r4, #0]
d0083412:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d0083416:	f4bf a810 	bcs.w	d008243a <emit_rule_word.constprop.0+0x176>
d008341a:	2118      	movs	r1, #24
d008341c:	202a      	movs	r0, #42	; 0x2a
d008341e:	f809 1022 	strb.w	r1, [r9, r2, lsl #2]
d0083422:	8822      	ldrh	r2, [r4, #0]
d0083424:	49c1      	ldr	r1, [pc, #772]	; (d008372c <emit_rule_word.constprop.0+0x1468>)
d0083426:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d008342a:	8050      	strh	r0, [r2, #2]
d008342c:	8820      	ldrh	r0, [r4, #0]
d008342e:	880a      	ldrh	r2, [r1, #0]
d0083430:	eb09 0080 	add.w	r0, r9, r0, lsl #2
d0083434:	7043      	strb	r3, [r0, #1]
d0083436:	8820      	ldrh	r0, [r4, #0]
d0083438:	3001      	adds	r0, #1
d008343a:	8020      	strh	r0, [r4, #0]
d008343c:	2a00      	cmp	r2, #0
d008343e:	d14a      	bne.n	d00834d6 <emit_rule_word.constprop.0+0x1212>
d0083440:	461f      	mov	r7, r3
d0083442:	2201      	movs	r2, #1
d0083444:	4bb7      	ldr	r3, [pc, #732]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d0083446:	b290      	uxth	r0, r2
d0083448:	224b      	movs	r2, #75	; 0x4b
d008344a:	8008      	strh	r0, [r1, #0]
d008344c:	55da      	strb	r2, [r3, r7]
d008344e:	f04f 0c00 	mov.w	ip, #0
d0083452:	4607      	mov	r7, r0
d0083454:	f803 c000 	strb.w	ip, [r3, r0]
d0083458:	8822      	ldrh	r2, [r4, #0]
d008345a:	f5b2 7f40 	cmp.w	r2, #768	; 0x300
d008345e:	f4be afec 	bcs.w	d008243a <emit_rule_word.constprop.0+0x176>
d0083462:	f04f 0b24 	mov.w	fp, #36	; 0x24
d0083466:	f04f 0e2c 	mov.w	lr, #44	; 0x2c
d008346a:	f809 b022 	strb.w	fp, [r9, r2, lsl #2]
d008346e:	8822      	ldrh	r2, [r4, #0]
d0083470:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d0083474:	f8a2 e002 	strh.w	lr, [r2, #2]
d0083478:	8822      	ldrh	r2, [r4, #0]
d008347a:	eb09 0282 	add.w	r2, r9, r2, lsl #2
d008347e:	f882 c001 	strb.w	ip, [r2, #1]
d0083482:	8822      	ldrh	r2, [r4, #0]
d0083484:	3201      	adds	r2, #1
d0083486:	8022      	strh	r2, [r4, #0]
d0083488:	b980      	cbnz	r0, d00834ac <emit_rule_word.constprop.0+0x11e8>
d008348a:	2201      	movs	r2, #1
d008348c:	b290      	uxth	r0, r2
d008348e:	2257      	movs	r2, #87	; 0x57
d0083490:	8008      	strh	r0, [r1, #0]
d0083492:	55da      	strb	r2, [r3, r7]
d0083494:	f7fe bfcf 	b.w	d0082436 <emit_rule_word.constprop.0+0x172>
d0083498:	463a      	mov	r2, r7
d008349a:	4ba2      	ldr	r3, [pc, #648]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d008349c:	f7ff b8a3 	b.w	d00825e6 <emit_rule_word.constprop.0+0x322>
d00834a0:	4663      	mov	r3, ip
d00834a2:	800a      	strh	r2, [r1, #0]
d00834a4:	e4b0      	b.n	d0082e08 <emit_rule_word.constprop.0+0xb44>
d00834a6:	4602      	mov	r2, r0
d00834a8:	4b9e      	ldr	r3, [pc, #632]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00834aa:	e4e0      	b.n	d0082e6e <emit_rule_word.constprop.0+0xbaa>
d00834ac:	1c42      	adds	r2, r0, #1
d00834ae:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00834b2:	d206      	bcs.n	d00834c2 <emit_rule_word.constprop.0+0x11fe>
d00834b4:	b290      	uxth	r0, r2
d00834b6:	f04f 0c20 	mov.w	ip, #32
d00834ba:	1c42      	adds	r2, r0, #1
d00834bc:	8008      	strh	r0, [r1, #0]
d00834be:	f803 c007 	strb.w	ip, [r3, r7]
d00834c2:	f04f 0c00 	mov.w	ip, #0
d00834c6:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00834ca:	4607      	mov	r7, r0
d00834cc:	f803 c000 	strb.w	ip, [r3, r0]
d00834d0:	d3dc      	bcc.n	d008348c <emit_rule_word.constprop.0+0x11c8>
d00834d2:	f7fe bfb0 	b.w	d0082436 <emit_rule_word.constprop.0+0x172>
d00834d6:	1c50      	adds	r0, r2, #1
d00834d8:	f5b0 6f00 	cmp.w	r0, #2048	; 0x800
d00834dc:	f080 818d 	bcs.w	d00837fa <emit_rule_word.constprop.0+0x1536>
d00834e0:	b280      	uxth	r0, r0
d00834e2:	4b90      	ldr	r3, [pc, #576]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00834e4:	2720      	movs	r7, #32
d00834e6:	8008      	strh	r0, [r1, #0]
d00834e8:	549f      	strb	r7, [r3, r2]
d00834ea:	1c42      	adds	r2, r0, #1
d00834ec:	f04f 0c00 	mov.w	ip, #0
d00834f0:	4607      	mov	r7, r0
d00834f2:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00834f6:	f803 c000 	strb.w	ip, [r3, r0]
d00834fa:	d3a4      	bcc.n	d0083446 <emit_rule_word.constprop.0+0x1182>
d00834fc:	e7a7      	b.n	d008344e <emit_rule_word.constprop.0+0x118a>
d00834fe:	4662      	mov	r2, ip
d0083500:	4b88      	ldr	r3, [pc, #544]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d0083502:	e4c5      	b.n	d0082e90 <emit_rule_word.constprop.0+0xbcc>
d0083504:	4663      	mov	r3, ip
d0083506:	f8a1 e000 	strh.w	lr, [r1]
d008350a:	e6f8      	b.n	d00832fe <emit_rule_word.constprop.0+0x103a>
d008350c:	4663      	mov	r3, ip
d008350e:	800a      	strh	r2, [r1, #0]
d0083510:	e6bd      	b.n	d008328e <emit_rule_word.constprop.0+0xfca>
d0083512:	f803 c007 	strb.w	ip, [r3, r7]
d0083516:	f7ff b87a 	b.w	d008260e <emit_rule_word.constprop.0+0x34a>
d008351a:	f1ba 0f00 	cmp.w	sl, #0
d008351e:	f000 8107 	beq.w	d0083730 <emit_rule_word.constprop.0+0x146c>
d0083522:	2a73      	cmp	r2, #115	; 0x73
d0083524:	bf18      	it	ne
d0083526:	2a7a      	cmpne	r2, #122	; 0x7a
d0083528:	d002      	beq.n	d0083530 <emit_rule_word.constprop.0+0x126c>
d008352a:	4572      	cmp	r2, lr
d008352c:	f43f a895 	beq.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083530:	f1a2 0362 	sub.w	r3, r2, #98	; 0x62
d0083534:	2b18      	cmp	r3, #24
d0083536:	f63f a890 	bhi.w	d008265a <emit_rule_word.constprop.0+0x396>
d008353a:	a201      	add	r2, pc, #4	; (adr r2, d0083540 <emit_rule_word.constprop.0+0x127c>)
d008353c:	f852 f023 	ldr.w	pc, [r2, r3, lsl #2]
d0083540:	d00836c9 	.word	0xd00836c9
d0083544:	d00836b1 	.word	0xd00836b1
d0083548:	d00836a1 	.word	0xd00836a1
d008354c:	d008265b 	.word	0xd008265b
d0083550:	d0083691 	.word	0xd0083691
d0083554:	d008263d 	.word	0xd008263d
d0083558:	d0083681 	.word	0xd0083681
d008355c:	d008265b 	.word	0xd008265b
d0083560:	d0083671 	.word	0xd0083671
d0083564:	d0083661 	.word	0xd0083661
d0083568:	d0083651 	.word	0xd0083651
d008356c:	d0083641 	.word	0xd0083641
d0083570:	d0083631 	.word	0xd0083631
d0083574:	d008265b 	.word	0xd008265b
d0083578:	d0083621 	.word	0xd0083621
d008357c:	d008265b 	.word	0xd008265b
d0083580:	d0083611 	.word	0xd0083611
d0083584:	d0083601 	.word	0xd0083601
d0083588:	d00835f1 	.word	0xd00835f1
d008358c:	d008265b 	.word	0xd008265b
d0083590:	d00835e1 	.word	0xd00835e1
d0083594:	d00835d1 	.word	0xd00835d1
d0083598:	d00835b5 	.word	0xd00835b5
d008359c:	d008265b 	.word	0xd008265b
d00835a0:	d00835a5 	.word	0xd00835a5
d00835a4:	2300      	movs	r3, #0
d00835a6:	2126      	movs	r1, #38	; 0x26
d00835a8:	4620      	mov	r0, r4
d00835aa:	461a      	mov	r2, r3
d00835ac:	f7fc fdf6 	bl	d008019c <emit_phone.constprop.0>
d00835b0:	f7ff b853 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00835b4:	4620      	mov	r0, r4
d00835b6:	2300      	movs	r3, #0
d00835b8:	222d      	movs	r2, #45	; 0x2d
d00835ba:	2118      	movs	r1, #24
d00835bc:	f7fc fdee 	bl	d008019c <emit_phone.constprop.0>
d00835c0:	2300      	movs	r3, #0
d00835c2:	2237      	movs	r2, #55	; 0x37
d00835c4:	211f      	movs	r1, #31
d00835c6:	4620      	mov	r0, r4
d00835c8:	f7fc fde8 	bl	d008019c <emit_phone.constprop.0>
d00835cc:	f7ff b845 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00835d0:	2300      	movs	r3, #0
d00835d2:	2124      	movs	r1, #36	; 0x24
d00835d4:	4620      	mov	r0, r4
d00835d6:	461a      	mov	r2, r3
d00835d8:	f7fc fde0 	bl	d008019c <emit_phone.constprop.0>
d00835dc:	f7ff b83d 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00835e0:	2300      	movs	r3, #0
d00835e2:	2123      	movs	r1, #35	; 0x23
d00835e4:	4620      	mov	r0, r4
d00835e6:	461a      	mov	r2, r3
d00835e8:	f7fc fdd8 	bl	d008019c <emit_phone.constprop.0>
d00835ec:	f7ff b835 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00835f0:	2300      	movs	r3, #0
d00835f2:	2121      	movs	r1, #33	; 0x21
d00835f4:	4620      	mov	r0, r4
d00835f6:	461a      	mov	r2, r3
d00835f8:	f7fc fdd0 	bl	d008019c <emit_phone.constprop.0>
d00835fc:	f7ff b82d 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083600:	2300      	movs	r3, #0
d0083602:	211f      	movs	r1, #31
d0083604:	4620      	mov	r0, r4
d0083606:	461a      	mov	r2, r3
d0083608:	f7fc fdc8 	bl	d008019c <emit_phone.constprop.0>
d008360c:	f7ff b825 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083610:	2300      	movs	r3, #0
d0083612:	211e      	movs	r1, #30
d0083614:	4620      	mov	r0, r4
d0083616:	461a      	mov	r2, r3
d0083618:	f7fc fdc0 	bl	d008019c <emit_phone.constprop.0>
d008361c:	f7ff b81d 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083620:	2300      	movs	r3, #0
d0083622:	211d      	movs	r1, #29
d0083624:	4620      	mov	r0, r4
d0083626:	461a      	mov	r2, r3
d0083628:	f7fc fdb8 	bl	d008019c <emit_phone.constprop.0>
d008362c:	f7ff b815 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083630:	2300      	movs	r3, #0
d0083632:	211b      	movs	r1, #27
d0083634:	4620      	mov	r0, r4
d0083636:	461a      	mov	r2, r3
d0083638:	f7fc fdb0 	bl	d008019c <emit_phone.constprop.0>
d008363c:	f7ff b80d 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083640:	2300      	movs	r3, #0
d0083642:	211a      	movs	r1, #26
d0083644:	4620      	mov	r0, r4
d0083646:	461a      	mov	r2, r3
d0083648:	f7fc fda8 	bl	d008019c <emit_phone.constprop.0>
d008364c:	f7ff b805 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083650:	2300      	movs	r3, #0
d0083652:	2119      	movs	r1, #25
d0083654:	4620      	mov	r0, r4
d0083656:	461a      	mov	r2, r3
d0083658:	f7fc fda0 	bl	d008019c <emit_phone.constprop.0>
d008365c:	f7fe bffd 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083660:	2300      	movs	r3, #0
d0083662:	2118      	movs	r1, #24
d0083664:	4620      	mov	r0, r4
d0083666:	461a      	mov	r2, r3
d0083668:	f7fc fd98 	bl	d008019c <emit_phone.constprop.0>
d008366c:	f7fe bff5 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083670:	2300      	movs	r3, #0
d0083672:	2117      	movs	r1, #23
d0083674:	4620      	mov	r0, r4
d0083676:	461a      	mov	r2, r3
d0083678:	f7fc fd90 	bl	d008019c <emit_phone.constprop.0>
d008367c:	f7fe bfed 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083680:	2300      	movs	r3, #0
d0083682:	2116      	movs	r1, #22
d0083684:	4620      	mov	r0, r4
d0083686:	461a      	mov	r2, r3
d0083688:	f7fc fd88 	bl	d008019c <emit_phone.constprop.0>
d008368c:	f7fe bfe5 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d0083690:	2300      	movs	r3, #0
d0083692:	2114      	movs	r1, #20
d0083694:	4620      	mov	r0, r4
d0083696:	461a      	mov	r2, r3
d0083698:	f7fc fd80 	bl	d008019c <emit_phone.constprop.0>
d008369c:	f7fe bfdd 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00836a0:	2300      	movs	r3, #0
d00836a2:	2112      	movs	r1, #18
d00836a4:	4620      	mov	r0, r4
d00836a6:	461a      	mov	r2, r3
d00836a8:	f7fc fd78 	bl	d008019c <emit_phone.constprop.0>
d00836ac:	f7fe bfd5 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00836b0:	f00e 03ef 	and.w	r3, lr, #239	; 0xef
d00836b4:	2b69      	cmp	r3, #105	; 0x69
d00836b6:	f000 809a 	beq.w	d00837ee <emit_rule_word.constprop.0+0x152a>
d00836ba:	f1be 0f65 	cmp.w	lr, #101	; 0x65
d00836be:	f000 8096 	beq.w	d00837ee <emit_rule_word.constprop.0+0x152a>
d00836c2:	2118      	movs	r1, #24
d00836c4:	f7fe bfc4 	b.w	d0082650 <emit_rule_word.constprop.0+0x38c>
d00836c8:	2300      	movs	r3, #0
d00836ca:	2110      	movs	r1, #16
d00836cc:	4620      	mov	r0, r4
d00836ce:	461a      	mov	r2, r3
d00836d0:	f7fc fd64 	bl	d008019c <emit_phone.constprop.0>
d00836d4:	f7fe bfc1 	b.w	d008265a <emit_rule_word.constprop.0+0x396>
d00836d8:	463a      	mov	r2, r7
d00836da:	4b12      	ldr	r3, [pc, #72]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00836dc:	e405      	b.n	d0082eea <emit_rule_word.constprop.0+0xc26>
d00836de:	4662      	mov	r2, ip
d00836e0:	4b10      	ldr	r3, [pc, #64]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00836e2:	e4d8      	b.n	d0083096 <emit_rule_word.constprop.0+0xdd2>
d00836e4:	4602      	mov	r2, r0
d00836e6:	4b0f      	ldr	r3, [pc, #60]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00836e8:	f7ff bbf0 	b.w	d0082ecc <emit_rule_word.constprop.0+0xc08>
d00836ec:	4662      	mov	r2, ip
d00836ee:	4b0d      	ldr	r3, [pc, #52]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00836f0:	f7ff bbdd 	b.w	d0082eae <emit_rule_word.constprop.0+0xbea>
d00836f4:	4662      	mov	r2, ip
d00836f6:	4b0b      	ldr	r3, [pc, #44]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00836f8:	e438      	b.n	d0082f6c <emit_rule_word.constprop.0+0xca8>
d00836fa:	4662      	mov	r2, ip
d00836fc:	4b09      	ldr	r3, [pc, #36]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d00836fe:	e50f      	b.n	d0083120 <emit_rule_word.constprop.0+0xe5c>
d0083700:	4662      	mov	r2, ip
d0083702:	4b08      	ldr	r3, [pc, #32]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d0083704:	e552      	b.n	d00831ac <emit_rule_word.constprop.0+0xee8>
d0083706:	4602      	mov	r2, r0
d0083708:	4b06      	ldr	r3, [pc, #24]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d008370a:	e617      	b.n	d008333c <emit_rule_word.constprop.0+0x1078>
d008370c:	4662      	mov	r2, ip
d008370e:	4b05      	ldr	r3, [pc, #20]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d0083710:	e663      	b.n	d00833da <emit_rule_word.constprop.0+0x1116>
d0083712:	4662      	mov	r2, ip
d0083714:	4b03      	ldr	r3, [pc, #12]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d0083716:	e585      	b.n	d0083224 <emit_rule_word.constprop.0+0xf60>
d0083718:	4b02      	ldr	r3, [pc, #8]	; (d0083724 <emit_rule_word.constprop.0+0x1460>)
d008371a:	463a      	mov	r2, r7
d008371c:	55d8      	strb	r0, [r3, r7]
d008371e:	f7ff b9df 	b.w	d0082ae0 <emit_rule_word.constprop.0+0x81c>
d0083722:	bf00      	nop
d0083724:	d0086d88 	.word	0xd0086d88
d0083728:	d0085b48 	.word	0xd0085b48
d008372c:	d0087588 	.word	0xd0087588
d0083730:	4839      	ldr	r0, [pc, #228]	; (d0083818 <emit_rule_word.constprop.0+0x1554>)
d0083732:	4659      	mov	r1, fp
d0083734:	236b      	movs	r3, #107	; 0x6b
d0083736:	f811 cb01 	ldrb.w	ip, [r1], #1
d008373a:	459c      	cmp	ip, r3
d008373c:	d13a      	bne.n	d00837b4 <emit_rule_word.constprop.0+0x14f0>
d008373e:	f810 3f01 	ldrb.w	r3, [r0, #1]!
d0083742:	2b00      	cmp	r3, #0
d0083744:	d1f7      	bne.n	d0083736 <emit_rule_word.constprop.0+0x1472>
d0083746:	8823      	ldrh	r3, [r4, #0]
d0083748:	f5b3 7f40 	cmp.w	r3, #768	; 0x300
d008374c:	d21a      	bcs.n	d0083784 <emit_rule_word.constprop.0+0x14c0>
d008374e:	211b      	movs	r1, #27
d0083750:	224c      	movs	r2, #76	; 0x4c
d0083752:	2000      	movs	r0, #0
d0083754:	f809 1023 	strb.w	r1, [r9, r3, lsl #2]
d0083758:	8823      	ldrh	r3, [r4, #0]
d008375a:	4930      	ldr	r1, [pc, #192]	; (d008381c <emit_rule_word.constprop.0+0x1558>)
d008375c:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d0083760:	805a      	strh	r2, [r3, #2]
d0083762:	8823      	ldrh	r3, [r4, #0]
d0083764:	880a      	ldrh	r2, [r1, #0]
d0083766:	eb09 0383 	add.w	r3, r9, r3, lsl #2
d008376a:	7058      	strb	r0, [r3, #1]
d008376c:	8823      	ldrh	r3, [r4, #0]
d008376e:	3301      	adds	r3, #1
d0083770:	8023      	strh	r3, [r4, #0]
d0083772:	b95a      	cbnz	r2, d008378c <emit_rule_word.constprop.0+0x14c8>
d0083774:	4b2a      	ldr	r3, [pc, #168]	; (d0083820 <emit_rule_word.constprop.0+0x155c>)
d0083776:	1c50      	adds	r0, r2, #1
d0083778:	274e      	movs	r7, #78	; 0x4e
d008377a:	b280      	uxth	r0, r0
d008377c:	549f      	strb	r7, [r3, r2]
d008377e:	8008      	strh	r0, [r1, #0]
d0083780:	2200      	movs	r2, #0
d0083782:	541a      	strb	r2, [r3, r0]
d0083784:	f04f 0a02 	mov.w	sl, #2
d0083788:	f7fe bdf5 	b.w	d0082376 <emit_rule_word.constprop.0+0xb2>
d008378c:	1c57      	adds	r7, r2, #1
d008378e:	f5b7 6f00 	cmp.w	r7, #2048	; 0x800
d0083792:	d22f      	bcs.n	d00837f4 <emit_rule_word.constprop.0+0x1530>
d0083794:	b2bf      	uxth	r7, r7
d0083796:	4b22      	ldr	r3, [pc, #136]	; (d0083820 <emit_rule_word.constprop.0+0x155c>)
d0083798:	2020      	movs	r0, #32
d008379a:	800f      	strh	r7, [r1, #0]
d008379c:	5498      	strb	r0, [r3, r2]
d008379e:	8808      	ldrh	r0, [r1, #0]
d00837a0:	f04f 0c00 	mov.w	ip, #0
d00837a4:	1c42      	adds	r2, r0, #1
d00837a6:	f803 c007 	strb.w	ip, [r3, r7]
d00837aa:	f5b2 6f00 	cmp.w	r2, #2048	; 0x800
d00837ae:	d2e7      	bcs.n	d0083780 <emit_rule_word.constprop.0+0x14bc>
d00837b0:	4602      	mov	r2, r0
d00837b2:	e7e0      	b.n	d0083776 <emit_rule_word.constprop.0+0x14b2>
d00837b4:	491b      	ldr	r1, [pc, #108]	; (d0083824 <emit_rule_word.constprop.0+0x1560>)
d00837b6:	465b      	mov	r3, fp
d00837b8:	e003      	b.n	d00837c2 <emit_rule_word.constprop.0+0x14fe>
d00837ba:	f813 cb01 	ldrb.w	ip, [r3], #1
d00837be:	4584      	cmp	ip, r0
d00837c0:	d104      	bne.n	d00837cc <emit_rule_word.constprop.0+0x1508>
d00837c2:	f811 0b01 	ldrb.w	r0, [r1], #1
d00837c6:	2800      	cmp	r0, #0
d00837c8:	d1f7      	bne.n	d00837ba <emit_rule_word.constprop.0+0x14f6>
d00837ca:	e7bc      	b.n	d0083746 <emit_rule_word.constprop.0+0x1482>
d00837cc:	4916      	ldr	r1, [pc, #88]	; (d0083828 <emit_rule_word.constprop.0+0x1564>)
d00837ce:	e004      	b.n	d00837da <emit_rule_word.constprop.0+0x1516>
d00837d0:	f81b 0b01 	ldrb.w	r0, [fp], #1
d00837d4:	4298      	cmp	r0, r3
d00837d6:	f47f aea4 	bne.w	d0083522 <emit_rule_word.constprop.0+0x125e>
d00837da:	f811 3b01 	ldrb.w	r3, [r1], #1
d00837de:	2b00      	cmp	r3, #0
d00837e0:	d1f6      	bne.n	d00837d0 <emit_rule_word.constprop.0+0x150c>
d00837e2:	461a      	mov	r2, r3
d00837e4:	211e      	movs	r1, #30
d00837e6:	4620      	mov	r0, r4
d00837e8:	f7fc fcd8 	bl	d008019c <emit_phone.constprop.0>
d00837ec:	e7ca      	b.n	d0083784 <emit_rule_word.constprop.0+0x14c0>
d00837ee:	211f      	movs	r1, #31
d00837f0:	f7fe bf2e 	b.w	d0082650 <emit_rule_word.constprop.0+0x38c>
d00837f4:	4617      	mov	r7, r2
d00837f6:	4b0a      	ldr	r3, [pc, #40]	; (d0083820 <emit_rule_word.constprop.0+0x155c>)
d00837f8:	e7d1      	b.n	d008379e <emit_rule_word.constprop.0+0x14da>
d00837fa:	4610      	mov	r0, r2
d00837fc:	4b08      	ldr	r3, [pc, #32]	; (d0083820 <emit_rule_word.constprop.0+0x155c>)
d00837fe:	e674      	b.n	d00834ea <emit_rule_word.constprop.0+0x1226>
d0083800:	2117      	movs	r1, #23
d0083802:	f7fe bf25 	b.w	d0082650 <emit_rule_word.constprop.0+0x38c>
d0083806:	4b06      	ldr	r3, [pc, #24]	; (d0083820 <emit_rule_word.constprop.0+0x155c>)
d0083808:	4662      	mov	r2, ip
d008380a:	f803 000c 	strb.w	r0, [r3, ip]
d008380e:	f7ff b967 	b.w	d0082ae0 <emit_rule_word.constprop.0+0x81c>
d0083812:	4602      	mov	r2, r0
d0083814:	f7ff b8ca 	b.w	d00829ac <emit_rule_word.constprop.0+0x6e8>
d0083818:	d0085b4c 	.word	0xd0085b4c
d008381c:	d0087588 	.word	0xd0087588
d0083820:	d0086d88 	.word	0xd0086d88
d0083824:	d0085b54 	.word	0xd0085b54
d0083828:	d0085b50 	.word	0xd0085b50

d008382c <speech_synth_render>:
d008382c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0083830:	f8df 917c 	ldr.w	r9, [pc, #380]	; d00839b0 <speech_synth_render+0x184>
d0083834:	f44f 724c 	mov.w	r2, #816	; 0x330
d0083838:	4680      	mov	r8, r0
d008383a:	2100      	movs	r1, #0
d008383c:	4648      	mov	r0, r9
d008383e:	ed2d 8b02 	vpush	{d8}
d0083842:	b0bf      	sub	sp, #252	; 0xfc
d0083844:	f001 f8d8 	bl	d00849f8 <memset>
d0083848:	4a52      	ldr	r2, [pc, #328]	; (d0083994 <speech_synth_render+0x168>)
d008384a:	23ff      	movs	r3, #255	; 0xff
d008384c:	f8c9 2004 	str.w	r2, [r9, #4]
d0083850:	f889 3312 	strb.w	r3, [r9, #786]	; 0x312
d0083854:	f1b8 0f00 	cmp.w	r8, #0
d0083858:	d004      	beq.n	d0083864 <speech_synth_render+0x38>
d008385a:	f898 3000 	ldrb.w	r3, [r8]
d008385e:	2b00      	cmp	r3, #0
d0083860:	f040 808a 	bne.w	d0083978 <speech_synth_render+0x14c>
d0083864:	2300      	movs	r3, #0
d0083866:	494c      	ldr	r1, [pc, #304]	; (d0083998 <speech_synth_render+0x16c>)
d0083868:	4a4c      	ldr	r2, [pc, #304]	; (d008399c <speech_synth_render+0x170>)
d008386a:	2768      	movs	r7, #104	; 0x68
d008386c:	f8df 8144 	ldr.w	r8, [pc, #324]	; d00839b4 <speech_synth_render+0x188>
d0083870:	f8ad 30c6 	strh.w	r3, [sp, #198]	; 0xc6
d0083874:	800b      	strh	r3, [r1, #0]
d0083876:	7013      	strb	r3, [r2, #0]
d0083878:	2100      	movs	r1, #0
d008387a:	4e49      	ldr	r6, [pc, #292]	; (d00839a0 <speech_synth_render+0x174>)
d008387c:	4d49      	ldr	r5, [pc, #292]	; (d00839a4 <speech_synth_render+0x178>)
d008387e:	460c      	mov	r4, r1
d0083880:	e015      	b.n	d00838ae <speech_synth_render+0x82>
d0083882:	1c63      	adds	r3, r4, #1
d0083884:	2b2f      	cmp	r3, #47	; 0x2f
d0083886:	d80b      	bhi.n	d00838a0 <speech_synth_render+0x74>
d0083888:	f1a7 0241 	sub.w	r2, r7, #65	; 0x41
d008388c:	b29b      	uxth	r3, r3
d008388e:	2a19      	cmp	r2, #25
d0083890:	d801      	bhi.n	d0083896 <speech_synth_render+0x6a>
d0083892:	3720      	adds	r7, #32
d0083894:	b2ff      	uxtb	r7, r7
d0083896:	aa3e      	add	r2, sp, #248	; 0xf8
d0083898:	4422      	add	r2, r4
d008389a:	461c      	mov	r4, r3
d008389c:	f802 7c30 	strb.w	r7, [r2, #-48]
d00838a0:	f818 7f01 	ldrb.w	r7, [r8, #1]!
d00838a4:	b1df      	cbz	r7, d00838de <speech_synth_render+0xb2>
d00838a6:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d00838aa:	f080 8087 	bcs.w	d00839bc <speech_synth_render+0x190>
d00838ae:	f027 0320 	bic.w	r3, r7, #32
d00838b2:	3b41      	subs	r3, #65	; 0x41
d00838b4:	2b19      	cmp	r3, #25
d00838b6:	d9e4      	bls.n	d0083882 <speech_synth_render+0x56>
d00838b8:	2c00      	cmp	r4, #0
d00838ba:	d13e      	bne.n	d008393a <speech_synth_render+0x10e>
d00838bc:	f1a7 0421 	sub.w	r4, r7, #33	; 0x21
d00838c0:	b2e4      	uxtb	r4, r4
d00838c2:	2c1e      	cmp	r4, #30
d00838c4:	d92b      	bls.n	d008391e <speech_synth_render+0xf2>
d00838c6:	3f30      	subs	r7, #48	; 0x30
d00838c8:	b2ff      	uxtb	r7, r7
d00838ca:	2f09      	cmp	r7, #9
d00838cc:	f240 86c2 	bls.w	d0084654 <speech_synth_render+0xe28>
d00838d0:	f818 7f01 	ldrb.w	r7, [r8, #1]!
d00838d4:	2400      	movs	r4, #0
d00838d6:	f8bd 10c6 	ldrh.w	r1, [sp, #198]	; 0xc6
d00838da:	2f00      	cmp	r7, #0
d00838dc:	d1e3      	bne.n	d00838a6 <speech_synth_render+0x7a>
d00838de:	b16c      	cbz	r4, d00838fc <speech_synth_render+0xd0>
d00838e0:	f5b1 7f40 	cmp.w	r1, #768	; 0x300
d00838e4:	d26a      	bcs.n	d00839bc <speech_synth_render+0x190>
d00838e6:	ab3e      	add	r3, sp, #248	; 0xf8
d00838e8:	f10d 01c6 	add.w	r1, sp, #198	; 0xc6
d00838ec:	a832      	add	r0, sp, #200	; 0xc8
d00838ee:	4423      	add	r3, r4
d00838f0:	f803 7c30 	strb.w	r7, [r3, #-48]
d00838f4:	f7fe fce6 	bl	d00822c4 <emit_rule_word.constprop.0>
d00838f8:	f8bd 10c6 	ldrh.w	r1, [sp, #198]	; 0xc6
d00838fc:	f8ad 10c8 	strh.w	r1, [sp, #200]	; 0xc8
d0083900:	2900      	cmp	r1, #0
d0083902:	d15d      	bne.n	d00839c0 <speech_synth_render+0x194>
d0083904:	2301      	movs	r3, #1
d0083906:	4928      	ldr	r1, [pc, #160]	; (d00839a8 <speech_synth_render+0x17c>)
d0083908:	2080      	movs	r0, #128	; 0x80
d008390a:	4a28      	ldr	r2, [pc, #160]	; (d00839ac <speech_synth_render+0x180>)
d008390c:	9305      	str	r3, [sp, #20]
d008390e:	7008      	strb	r0, [r1, #0]
d0083910:	4618      	mov	r0, r3
d0083912:	6013      	str	r3, [r2, #0]
d0083914:	b03f      	add	sp, #252	; 0xfc
d0083916:	ecbd 8b02 	vpop	{d8}
d008391a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d008391e:	fa25 f404 	lsr.w	r4, r5, r4
d0083922:	43e4      	mvns	r4, r4
d0083924:	f014 0401 	ands.w	r4, r4, #1
d0083928:	d117      	bne.n	d008395a <speech_synth_render+0x12e>
d008392a:	21b9      	movs	r1, #185	; 0xb9
d008392c:	f10d 00c6 	add.w	r0, sp, #198	; 0xc6
d0083930:	f7fc fbf6 	bl	d0080120 <emit_pause.constprop.0>
d0083934:	f8bd 10c6 	ldrh.w	r1, [sp, #198]	; 0xc6
d0083938:	e7b2      	b.n	d00838a0 <speech_synth_render+0x74>
d008393a:	ab3e      	add	r3, sp, #248	; 0xf8
d008393c:	f10d 01c6 	add.w	r1, sp, #198	; 0xc6
d0083940:	a832      	add	r0, sp, #200	; 0xc8
d0083942:	441c      	add	r4, r3
d0083944:	2300      	movs	r3, #0
d0083946:	f804 3c30 	strb.w	r3, [r4, #-48]
d008394a:	f7fe fcbb 	bl	d00822c4 <emit_rule_word.constprop.0>
d008394e:	210e      	movs	r1, #14
d0083950:	f10d 00c6 	add.w	r0, sp, #198	; 0xc6
d0083954:	f7fc fbe4 	bl	d0080120 <emit_pause.constprop.0>
d0083958:	e7b0      	b.n	d00838bc <speech_synth_render+0x90>
d008395a:	f1a7 033a 	sub.w	r3, r7, #58	; 0x3a
d008395e:	2b01      	cmp	r3, #1
d0083960:	d901      	bls.n	d0083966 <speech_synth_render+0x13a>
d0083962:	2f2c      	cmp	r7, #44	; 0x2c
d0083964:	d1af      	bne.n	d00838c6 <speech_synth_render+0x9a>
d0083966:	215f      	movs	r1, #95	; 0x5f
d0083968:	f10d 00c6 	add.w	r0, sp, #198	; 0xc6
d008396c:	f7fc fbd8 	bl	d0080120 <emit_pause.constprop.0>
d0083970:	2400      	movs	r4, #0
d0083972:	f8bd 10c6 	ldrh.w	r1, [sp, #198]	; 0xc6
d0083976:	e793      	b.n	d00838a0 <speech_synth_render+0x74>
d0083978:	2300      	movs	r3, #0
d008397a:	4908      	ldr	r1, [pc, #32]	; (d008399c <speech_synth_render+0x170>)
d008397c:	4a06      	ldr	r2, [pc, #24]	; (d0083998 <speech_synth_render+0x16c>)
d008397e:	700b      	strb	r3, [r1, #0]
d0083980:	f898 7000 	ldrb.w	r7, [r8]
d0083984:	f8ad 30c6 	strh.w	r3, [sp, #198]	; 0xc6
d0083988:	8013      	strh	r3, [r2, #0]
d008398a:	2f00      	cmp	r7, #0
d008398c:	f47f af74 	bne.w	d0083878 <speech_synth_render+0x4c>
d0083990:	e7b8      	b.n	d0083904 <speech_synth_render+0xd8>
d0083992:	bf00      	nop
d0083994:	1234abcd 	.word	0x1234abcd
d0083998:	d0087588 	.word	0xd0087588
d008399c:	d0086d88 	.word	0xd0086d88
d00839a0:	d0085c4c 	.word	0xd0085c4c
d00839a4:	40002001 	.word	0x40002001
d00839a8:	d00875a0 	.word	0xd00875a0
d00839ac:	d00c7f38 	.word	0xd00c7f38
d00839b0:	d00c7f3c 	.word	0xd00c7f3c
d00839b4:	d0085b58 	.word	0xd0085b58
d00839b8:	3fd70a3d 	.word	0x3fd70a3d
d00839bc:	f8ad 10c8 	strh.w	r1, [sp, #200]	; 0xc8
d00839c0:	2178      	movs	r1, #120	; 0x78
d00839c2:	a832      	add	r0, sp, #200	; 0xc8
d00839c4:	f7fc fbac 	bl	d0080120 <emit_pause.constprop.0>
d00839c8:	f8bd 10c8 	ldrh.w	r1, [sp, #200]	; 0xc8
d00839cc:	2900      	cmp	r1, #0
d00839ce:	f000 864e 	beq.w	d008466e <speech_synth_render+0xe42>
d00839d2:	2200      	movs	r2, #0
d00839d4:	ed1f 8a08 	vldr	s16, [pc, #-32]	; d00839b8 <speech_synth_render+0x18c>
d00839d8:	921b      	str	r2, [sp, #108]	; 0x6c
d00839da:	9205      	str	r2, [sp, #20]
d00839dc:	2a00      	cmp	r2, #0
d00839de:	f000 860d 	beq.w	d00845fc <speech_synth_render+0xdd0>
d00839e2:	f8bd 206c 	ldrh.w	r2, [sp, #108]	; 0x6c
d00839e6:	489f      	ldr	r0, [pc, #636]	; (d0083c64 <speech_synth_render+0x438>)
d00839e8:	1e53      	subs	r3, r2, #1
d00839ea:	f810 4023 	ldrb.w	r4, [r0, r3, lsl #2]
d00839ee:	1c53      	adds	r3, r2, #1
d00839f0:	428b      	cmp	r3, r1
d00839f2:	f080 85fd 	bcs.w	d00845f0 <speech_synth_render+0xdc4>
d00839f6:	499b      	ldr	r1, [pc, #620]	; (d0083c64 <speech_synth_render+0x438>)
d00839f8:	f811 3023 	ldrb.w	r3, [r1, r3, lsl #2]
d00839fc:	9308      	str	r3, [sp, #32]
d00839fe:	4999      	ldr	r1, [pc, #612]	; (d0083c64 <speech_synth_render+0x438>)
d0083a00:	f245 6522 	movw	r5, #22050	; 0x5622
d0083a04:	eb01 0382 	add.w	r3, r1, r2, lsl #2
d0083a08:	f811 6022 	ldrb.w	r6, [r1, r2, lsl #2]
d0083a0c:	4a96      	ldr	r2, [pc, #600]	; (d0083c68 <speech_synth_render+0x43c>)
d0083a0e:	8858      	ldrh	r0, [r3, #2]
d0083a10:	00b7      	lsls	r7, r6, #2
d0083a12:	eb06 0186 	add.w	r1, r6, r6, lsl #2
d0083a16:	9604      	str	r6, [sp, #16]
d0083a18:	fb05 f500 	mul.w	r5, r5, r0
d0083a1c:	4893      	ldr	r0, [pc, #588]	; (d0083c6c <speech_synth_render+0x440>)
d0083a1e:	9718      	str	r7, [sp, #96]	; 0x60
d0083a20:	eb00 0181 	add.w	r1, r0, r1, lsl #2
d0083a24:	fba2 7205 	umull	r7, r2, r2, r5
d0083a28:	7b89      	ldrb	r1, [r1, #14]
d0083a2a:	0992      	lsrs	r2, r2, #6
d0083a2c:	910a      	str	r1, [sp, #40]	; 0x28
d0083a2e:	9201      	str	r2, [sp, #4]
d0083a30:	2c00      	cmp	r4, #0
d0083a32:	f000 8578 	beq.w	d0084526 <speech_synth_render+0xcfa>
d0083a36:	2e00      	cmp	r6, #0
d0083a38:	f000 8581 	beq.w	d008453e <speech_synth_render+0xd12>
d0083a3c:	9e08      	ldr	r6, [sp, #32]
d0083a3e:	f081 0404 	eor.w	r4, r1, #4
d0083a42:	eb06 0286 	add.w	r2, r6, r6, lsl #2
d0083a46:	f3c4 0480 	ubfx	r4, r4, #2, #1
d0083a4a:	9622      	str	r6, [sp, #136]	; 0x88
d0083a4c:	eb00 0282 	add.w	r2, r0, r2, lsl #2
d0083a50:	7b92      	ldrb	r2, [r2, #14]
d0083a52:	9908      	ldr	r1, [sp, #32]
d0083a54:	b121      	cbz	r1, d0083a60 <speech_synth_render+0x234>
d0083a56:	f082 0204 	eor.w	r2, r2, #4
d0083a5a:	f3c2 0280 	ubfx	r2, r2, #2, #1
d0083a5e:	9208      	str	r2, [sp, #32]
d0083a60:	f247 522f 	movw	r2, #29999	; 0x752f
d0083a64:	4295      	cmp	r5, r2
d0083a66:	f240 85f0 	bls.w	d008464a <speech_synth_render+0xe1e>
d0083a6a:	f5b5 7f7a 	cmp.w	r5, #1000	; 0x3e8
d0083a6e:	bf34      	ite	cc
d0083a70:	2500      	movcc	r5, #0
d0083a72:	2501      	movcs	r5, #1
d0083a74:	4a7e      	ldr	r2, [pc, #504]	; (d0083c70 <speech_synth_render+0x444>)
d0083a76:	9905      	ldr	r1, [sp, #20]
d0083a78:	4291      	cmp	r1, r2
d0083a7a:	f200 8589 	bhi.w	d0084590 <speech_synth_render+0xd64>
d0083a7e:	2d00      	cmp	r5, #0
d0083a80:	f000 8586 	beq.w	d0084590 <speech_synth_render+0xd64>
d0083a84:	9e04      	ldr	r6, [sp, #16]
d0083a86:	f084 0401 	eor.w	r4, r4, #1
d0083a8a:	9a18      	ldr	r2, [sp, #96]	; 0x60
d0083a8c:	7859      	ldrb	r1, [r3, #1]
d0083a8e:	f004 0401 	and.w	r4, r4, #1
d0083a92:	1993      	adds	r3, r2, r6
d0083a94:	4f75      	ldr	r7, [pc, #468]	; (d0083c6c <speech_synth_render+0x440>)
d0083a96:	4a77      	ldr	r2, [pc, #476]	; (d0083c74 <speech_synth_render+0x448>)
d0083a98:	2900      	cmp	r1, #0
d0083a9a:	eb07 0383 	add.w	r3, r7, r3, lsl #2
d0083a9e:	9f01      	ldr	r7, [sp, #4]
d0083aa0:	9d0a      	ldr	r5, [sp, #40]	; 0x28
d0083aa2:	f04f 0100 	mov.w	r1, #0
d0083aa6:	fba2 c207 	umull	ip, r2, r2, r7
d0083aaa:	7b5b      	ldrb	r3, [r3, #13]
d0083aac:	f005 0010 	and.w	r0, r5, #16
d0083ab0:	bf18      	it	ne
d0083ab2:	f04f 0c97 	movne.w	ip, #151	; 0x97
d0083ab6:	ea4f 0752 	mov.w	r7, r2, lsr #1
d0083aba:	f1a6 0211 	sub.w	r2, r6, #17
d0083abe:	930c      	str	r3, [sp, #48]	; 0x30
d0083ac0:	f1a6 0318 	sub.w	r3, r6, #24
d0083ac4:	b2d2      	uxtb	r2, r2
d0083ac6:	bf08      	it	eq
d0083ac8:	f04f 0c7e 	moveq.w	ip, #126	; 0x7e
d0083acc:	902d      	str	r0, [sp, #180]	; 0xb4
d0083ace:	2800      	cmp	r0, #0
d0083ad0:	9427      	str	r4, [sp, #156]	; 0x9c
d0083ad2:	463c      	mov	r4, r7
d0083ad4:	4868      	ldr	r0, [pc, #416]	; (d0083c78 <speech_synth_render+0x44c>)
d0083ad6:	468a      	mov	sl, r1
d0083ad8:	920b      	str	r2, [sp, #44]	; 0x2c
d0083ada:	b2da      	uxtb	r2, r3
d0083adc:	9b05      	ldr	r3, [sp, #20]
d0083ade:	f104 045b 	add.w	r4, r4, #91	; 0x5b
d0083ae2:	9715      	str	r7, [sp, #84]	; 0x54
d0083ae4:	4403      	add	r3, r0
d0083ae6:	9424      	str	r4, [sp, #144]	; 0x90
d0083ae8:	f1c7 0400 	rsb	r4, r7, #0
d0083aec:	9f01      	ldr	r7, [sp, #4]
d0083aee:	9317      	str	r3, [sp, #92]	; 0x5c
d0083af0:	f005 0301 	and.w	r3, r5, #1
d0083af4:	9403      	str	r4, [sp, #12]
d0083af6:	bf14      	ite	ne
d0083af8:	247d      	movne	r4, #125	; 0x7d
d0083afa:	246e      	moveq	r4, #110	; 0x6e
d0083afc:	9328      	str	r3, [sp, #160]	; 0xa0
d0083afe:	f005 0301 	and.w	r3, r5, #1
d0083b02:	f8dd b030 	ldr.w	fp, [sp, #48]	; 0x30
d0083b06:	9429      	str	r4, [sp, #164]	; 0xa4
d0083b08:	bf14      	ite	ne
d0083b0a:	24d2      	movne	r4, #210	; 0xd2
d0083b0c:	24b4      	moveq	r4, #180	; 0xb4
d0083b0e:	9306      	str	r3, [sp, #24]
d0083b10:	f005 0304 	and.w	r3, r5, #4
d0083b14:	f8cd c08c 	str.w	ip, [sp, #140]	; 0x8c
d0083b18:	942a      	str	r4, [sp, #168]	; 0xa8
d0083b1a:	bf14      	ite	ne
d0083b1c:	f44f 74aa 	movne.w	r4, #340	; 0x154
d0083b20:	f44f 7496 	moveq.w	r4, #300	; 0x12c
d0083b24:	9309      	str	r3, [sp, #36]	; 0x24
d0083b26:	f005 0302 	and.w	r3, r5, #2
d0083b2a:	9226      	str	r2, [sp, #152]	; 0x98
d0083b2c:	942b      	str	r4, [sp, #172]	; 0xac
d0083b2e:	bf14      	ite	ne
d0083b30:	f44f 740c 	movne.w	r4, #560	; 0x230
d0083b34:	f44f 7402 	moveq.w	r4, #520	; 0x208
d0083b38:	9316      	str	r3, [sp, #88]	; 0x58
d0083b3a:	f005 0308 	and.w	r3, r5, #8
d0083b3e:	942c      	str	r4, [sp, #176]	; 0xb0
d0083b40:	bf14      	ite	ne
d0083b42:	f44f 744d 	movne.w	r4, #820	; 0x334
d0083b46:	f44f 743e 	moveq.w	r4, #760	; 0x2f8
d0083b4a:	9325      	str	r3, [sp, #148]	; 0x94
d0083b4c:	023b      	lsls	r3, r7, #8
d0083b4e:	942e      	str	r4, [sp, #184]	; 0xb8
d0083b50:	932f      	str	r3, [sp, #188]	; 0xbc
d0083b52:	9b23      	ldr	r3, [sp, #140]	; 0x8c
d0083b54:	f1ba 0f73 	cmp.w	sl, #115	; 0x73
d0083b58:	eb03 0801 	add.w	r8, r3, r1
d0083b5c:	fa1f f388 	uxth.w	r3, r8
d0083b60:	9302      	str	r3, [sp, #8]
d0083b62:	f200 83d8 	bhi.w	d0084316 <speech_synth_render+0xaea>
d0083b66:	9b27      	ldr	r3, [sp, #156]	; 0x9c
d0083b68:	2b00      	cmp	r3, #0
d0083b6a:	f000 83d4 	beq.w	d0084316 <speech_synth_render+0xaea>
d0083b6e:	ea4f 240a 	mov.w	r4, sl, lsl #8
d0083b72:	4b42      	ldr	r3, [pc, #264]	; (d0083c7c <speech_synth_render+0x450>)
d0083b74:	fba3 3404 	umull	r3, r4, r3, r4
d0083b78:	09a4      	lsrs	r4, r4, #6
d0083b7a:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0083b7c:	b13b      	cbz	r3, d0083b8e <speech_synth_render+0x362>
d0083b7e:	9b15      	ldr	r3, [sp, #84]	; 0x54
d0083b80:	4553      	cmp	r3, sl
d0083b82:	f240 84c5 	bls.w	d0084510 <speech_synth_render+0xce4>
d0083b86:	eb04 0484 	add.w	r4, r4, r4, lsl #2
d0083b8a:	f3c4 1497 	ubfx	r4, r4, #6, #24
d0083b8e:	f5b4 7fa0 	cmp.w	r4, #320	; 0x140
d0083b92:	4623      	mov	r3, r4
d0083b94:	bf28      	it	cs
d0083b96:	f44f 73a0 	movcs.w	r3, #320	; 0x140
d0083b9a:	f01a 0f3f 	tst.w	sl, #63	; 0x3f
d0083b9e:	931c      	str	r3, [sp, #112]	; 0x70
d0083ba0:	f000 82d8 	beq.w	d0084154 <speech_synth_render+0x928>
d0083ba4:	9b06      	ldr	r3, [sp, #24]
d0083ba6:	2b00      	cmp	r3, #0
d0083ba8:	f000 82c4 	beq.w	d0084134 <speech_synth_render+0x908>
d0083bac:	9b02      	ldr	r3, [sp, #8]
d0083bae:	4a34      	ldr	r2, [pc, #208]	; (d0083c80 <speech_synth_render+0x454>)
d0083bb0:	0419      	lsls	r1, r3, #16
d0083bb2:	f8b9 3000 	ldrh.w	r3, [r9]
d0083bb6:	f899 4311 	ldrb.w	r4, [r9, #785]	; 0x311
d0083bba:	fba2 2101 	umull	r2, r1, r2, r1
d0083bbe:	eb03 3191 	add.w	r1, r3, r1, lsr #14
d0083bc2:	b289      	uxth	r1, r1
d0083bc4:	428b      	cmp	r3, r1
d0083bc6:	f8a9 1000 	strh.w	r1, [r9]
d0083bca:	d903      	bls.n	d0083bd4 <speech_synth_render+0x3a8>
d0083bcc:	3401      	adds	r4, #1
d0083bce:	b2e4      	uxtb	r4, r4
d0083bd0:	f889 4311 	strb.w	r4, [r9, #785]	; 0x311
d0083bd4:	9b02      	ldr	r3, [sp, #8]
d0083bd6:	2b00      	cmp	r3, #0
d0083bd8:	f000 8497 	beq.w	d008450a <speech_synth_render+0xcde>
d0083bdc:	f240 387a 	movw	r8, #890	; 0x37a
d0083be0:	fbb8 f8f3 	udiv	r8, r8, r3
d0083be4:	fa5f f888 	uxtb.w	r8, r8
d0083be8:	f899 3310 	ldrb.w	r3, [r9, #784]	; 0x310
d0083bec:	2b00      	cmp	r3, #0
d0083bee:	d04c      	beq.n	d0083c8a <speech_synth_render+0x45e>
d0083bf0:	468e      	mov	lr, r1
d0083bf2:	9806      	ldr	r0, [sp, #24]
d0083bf4:	2600      	movs	r6, #0
d0083bf6:	2700      	movs	r7, #0
d0083bf8:	468c      	mov	ip, r1
d0083bfa:	9307      	str	r3, [sp, #28]
d0083bfc:	e00a      	b.n	d0083c14 <speech_synth_render+0x3e8>
d0083bfe:	1876      	adds	r6, r6, r1
d0083c00:	eb47 77e1 	adc.w	r7, r7, r1, asr #31
d0083c04:	3001      	adds	r0, #1
d0083c06:	9b07      	ldr	r3, [sp, #28]
d0083c08:	44e6      	add	lr, ip
d0083c0a:	b2c0      	uxtb	r0, r0
d0083c0c:	fa1f fe8e 	uxth.w	lr, lr
d0083c10:	4283      	cmp	r3, r0
d0083c12:	d337      	bcc.n	d0083c84 <speech_synth_render+0x458>
d0083c14:	f3ce 020e 	ubfx	r2, lr, #0, #15
d0083c18:	eb09 0180 	add.w	r1, r9, r0, lsl #2
d0083c1c:	1c85      	adds	r5, r0, #2
d0083c1e:	f8d1 318c 	ldr.w	r3, [r1, #396]	; 0x18c
d0083c22:	f5c2 4100 	rsb	r1, r2, #32768	; 0x8000
d0083c26:	f5b2 4f80 	cmp.w	r2, #16384	; 0x4000
d0083c2a:	9102      	str	r1, [sp, #8]
d0083c2c:	f859 1025 	ldr.w	r1, [r9, r5, lsl #2]
d0083c30:	bf88      	it	hi
d0083c32:	f8bd 2008 	ldrhhi.w	r2, [sp, #8]
d0083c36:	f41e 4f00 	tst.w	lr, #32768	; 0x8000
d0083c3a:	440b      	add	r3, r1
d0083c3c:	f849 3025 	str.w	r3, [r9, r5, lsl #2]
d0083c40:	f5c2 4500 	rsb	r5, r2, #32768	; 0x8000
d0083c44:	4619      	mov	r1, r3
d0083c46:	fb02 f205 	mul.w	r2, r2, r5
d0083c4a:	ea4f 3262 	mov.w	r2, r2, asr #13
d0083c4e:	bf18      	it	ne
d0083c50:	4252      	negne	r2, r2
d0083c52:	4580      	cmp	r8, r0
d0083c54:	b212      	sxth	r2, r2
d0083c56:	fb01 f102 	mul.w	r1, r1, r2
d0083c5a:	d2d0      	bcs.n	d0083bfe <speech_synth_render+0x3d2>
d0083c5c:	1a76      	subs	r6, r6, r1
d0083c5e:	eb67 77e1 	sbc.w	r7, r7, r1, asr #31
d0083c62:	e7cf      	b.n	d0083c04 <speech_synth_render+0x3d8>
d0083c64:	d0086188 	.word	0xd0086188
d0083c68:	10624dd3 	.word	0x10624dd3
d0083c6c:	d0085c94 	.word	0xd0085c94
d0083c70:	00040997 	.word	0x00040997
d0083c74:	aaaaaaab 	.word	0xaaaaaaab
d0083c78:	d008759f 	.word	0xd008759f
d0083c7c:	8d3dcb09 	.word	0x8d3dcb09
d0083c80:	be37c63b 	.word	0xbe37c63b
d0083c84:	0bf3      	lsrs	r3, r6, #15
d0083c86:	ea43 4347 	orr.w	r3, r3, r7, lsl #17
d0083c8a:	0760      	lsls	r0, r4, #29
d0083c8c:	f000 842d 	beq.w	d00844ea <speech_synth_render+0xcbe>
d0083c90:	011b      	lsls	r3, r3, #4
d0083c92:	4cd4      	ldr	r4, [pc, #848]	; (d0083fe4 <speech_synth_render+0x7b8>)
d0083c94:	fb84 2403 	smull	r2, r4, r4, r3
d0083c98:	17db      	asrs	r3, r3, #31
d0083c9a:	ebc3 0464 	rsb	r4, r3, r4, asr #1
d0083c9e:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0083ca0:	2b00      	cmp	r3, #0
d0083ca2:	f000 824c 	beq.w	d008413e <speech_synth_render+0x912>
d0083ca6:	9b15      	ldr	r3, [sp, #84]	; 0x54
d0083ca8:	4553      	cmp	r3, sl
d0083caa:	f200 812b 	bhi.w	d0083f04 <speech_synth_render+0x6d8>
d0083cae:	9b03      	ldr	r3, [sp, #12]
d0083cb0:	f5b3 7fbe 	cmp.w	r3, #380	; 0x17c
d0083cb4:	f080 8126 	bcs.w	d0083f04 <speech_synth_render+0x6d8>
d0083cb8:	9a0b      	ldr	r2, [sp, #44]	; 0x2c
d0083cba:	2a10      	cmp	r2, #16
d0083cbc:	f200 8485 	bhi.w	d00845ca <speech_synth_render+0xd9e>
d0083cc0:	4bc9      	ldr	r3, [pc, #804]	; (d0083fe8 <speech_synth_render+0x7bc>)
d0083cc2:	f853 5022 	ldr.w	r5, [r3, r2, lsl #2]
d0083cc6:	9b03      	ldr	r3, [sp, #12]
d0083cc8:	2b41      	cmp	r3, #65	; 0x41
d0083cca:	f240 8484 	bls.w	d00845d6 <speech_synth_render+0xdaa>
d0083cce:	461a      	mov	r2, r3
d0083cd0:	f44f 7596 	mov.w	r5, #300	; 0x12c
d0083cd4:	4bc5      	ldr	r3, [pc, #788]	; (d0083fec <speech_synth_render+0x7c0>)
d0083cd6:	fb05 3502 	mla	r5, r5, r2, r3
d0083cda:	f103 5354 	add.w	r3, r3, #889192448	; 0x35000000
d0083cde:	f5a3 0352 	sub.w	r3, r3, #13762560	; 0xd20000
d0083ce2:	f6a3 23b5 	subw	r3, r3, #2741	; 0xab5
d0083ce6:	fba3 3505 	umull	r3, r5, r3, r5
d0083cea:	09ad      	lsrs	r5, r5, #6
d0083cec:	f5c5 75aa 	rsb	r5, r5, #340	; 0x154
d0083cf0:	b2ad      	uxth	r5, r5
d0083cf2:	9b0b      	ldr	r3, [sp, #44]	; 0x2c
d0083cf4:	2b10      	cmp	r3, #16
d0083cf6:	f240 8463 	bls.w	d00845c0 <speech_synth_render+0xd94>
d0083cfa:	2170      	movs	r1, #112	; 0x70
d0083cfc:	4559      	cmp	r1, fp
d0083cfe:	9a0a      	ldr	r2, [sp, #40]	; 0x28
d0083d00:	9804      	ldr	r0, [sp, #16]
d0083d02:	bf38      	it	cc
d0083d04:	4659      	movcc	r1, fp
d0083d06:	f7fc fab3 	bl	d0080270 <render_noise.constprop.0>
d0083d0a:	9b04      	ldr	r3, [sp, #16]
d0083d0c:	fb05 f000 	mul.w	r0, r5, r0
d0083d10:	f8d9 6004 	ldr.w	r6, [r9, #4]
d0083d14:	49b6      	ldr	r1, [pc, #728]	; (d0083ff0 <speech_synth_render+0x7c4>)
d0083d16:	f1a3 0710 	sub.w	r7, r3, #16
d0083d1a:	4bb6      	ldr	r3, [pc, #728]	; (d0083ff4 <speech_synth_render+0x7c8>)
d0083d1c:	2800      	cmp	r0, #0
d0083d1e:	fb01 3306 	mla	r3, r1, r6, r3
d0083d22:	bfb8      	it	lt
d0083d24:	30ff      	addlt	r0, #255	; 0xff
d0083d26:	f9b9 6314 	ldrsh.w	r6, [r9, #788]	; 0x314
d0083d2a:	ea4f 4c23 	mov.w	ip, r3, asr #16
d0083d2e:	f8c9 3004 	str.w	r3, [r9, #4]
d0083d32:	1200      	asrs	r0, r0, #8
d0083d34:	ebc6 4623 	rsb	r6, r6, r3, asr #16
d0083d38:	f8a9 c314 	strh.w	ip, [r9, #788]	; 0x314
d0083d3c:	2f17      	cmp	r7, #23
d0083d3e:	f200 812e 	bhi.w	d0083f9e <speech_synth_render+0x772>
d0083d42:	e8df f017 	tbh	[pc, r7, lsl #1]
d0083d46:	013d      	.short	0x013d
d0083d48:	01b30018 	.word	0x01b30018
d0083d4c:	011b011b 	.word	0x011b011b
d0083d50:	01e601c4 	.word	0x01e601c4
d0083d54:	01c40018 	.word	0x01c40018
d0083d58:	012c012c 	.word	0x012c012c
d0083d5c:	012c012c 	.word	0x012c012c
d0083d60:	012c013d 	.word	0x012c013d
d0083d64:	001801d5 	.word	0x001801d5
d0083d68:	011b01b3 	.word	0x011b01b3
d0083d6c:	012c011b 	.word	0x012c011b
d0083d70:	01d5012c 	.word	0x01d5012c
d0083d74:	0018      	.short	0x0018
d0083d76:	ed9f 6aa0 	vldr	s12, [pc, #640]	; d0083ff8 <speech_synth_render+0x7cc>
d0083d7a:	2126      	movs	r1, #38	; 0x26
d0083d7c:	eddf 2ac8 	vldr	s5, [pc, #800]	; d00840a0 <speech_synth_render+0x874>
d0083d80:	275e      	movs	r7, #94	; 0x5e
d0083d82:	eddf 6a9e 	vldr	s13, [pc, #632]	; d0083ffc <speech_synth_render+0x7d0>
d0083d86:	f04f 0c84 	mov.w	ip, #132	; 0x84
d0083d8a:	ed9f 3a9d 	vldr	s6, [pc, #628]	; d0084000 <speech_synth_render+0x7d4>
d0083d8e:	ed9f 7a9d 	vldr	s14, [pc, #628]	; d0084004 <speech_synth_render+0x7d8>
d0083d92:	eddf 4abd 	vldr	s9, [pc, #756]	; d0084088 <speech_synth_render+0x85c>
d0083d96:	edd9 7ac7 	vldr	s15, [r9, #796]	; 0x31c
d0083d9a:	ee05 6a90 	vmov	s11, r6
d0083d9e:	eddf 3a9a 	vldr	s7, [pc, #616]	; d0084008 <speech_synth_render+0x7dc>
d0083da2:	eef1 1a04 	vmov.f32	s3, #20	; 0x40a00000  5.0
d0083da6:	eeb8 4ae5 	vcvt.f32.s32	s8, s11
d0083daa:	ed99 5ac6 	vldr	s10, [r9, #792]	; 0x318
d0083dae:	ee26 6a67 	vnmul.f32	s12, s12, s15
d0083db2:	eddf 5a96 	vldr	s11, [pc, #600]	; d008400c <speech_synth_render+0x7e0>
d0083db6:	eea7 5aa2 	vfma.f32	s10, s15, s5
d0083dba:	eeb9 2a04 	vmov.f32	s4, #148	; 0xc0a00000 -5.0
d0083dbe:	eea4 6a23 	vfma.f32	s12, s8, s7
d0083dc2:	fec5 3a61 	vminnm.f32	s7, s10, s3
d0083dc6:	fec3 3a82 	vmaxnm.f32	s7, s7, s4
d0083dca:	edc9 3ac6 	vstr	s7, [r9, #792]	; 0x318
d0083dce:	eef9 3a04 	vmov.f32	s7, #148	; 0xc0a00000 -5.0
d0083dd2:	ee36 6a45 	vsub.f32	s12, s12, s10
d0083dd6:	ed9f 5a8c 	vldr	s10, [pc, #560]	; d0084008 <speech_synth_render+0x7dc>
d0083dda:	eee6 7a22 	vfma.f32	s15, s12, s5
d0083dde:	eef1 2a04 	vmov.f32	s5, #20	; 0x40a00000  5.0
d0083de2:	fec7 7ae1 	vminnm.f32	s15, s15, s3
d0083de6:	fec7 7a82 	vmaxnm.f32	s15, s15, s4
d0083dea:	ee27 6aa5 	vmul.f32	s12, s15, s11
d0083dee:	edc9 7ac7 	vstr	s15, [r9, #796]	; 0x31c
d0083df2:	edd9 5ac8 	vldr	s11, [r9, #800]	; 0x320
d0083df6:	eefd 7ac6 	vcvt.s32.f32	s15, s12
d0083dfa:	ed9f 6a84 	vldr	s12, [pc, #528]	; d008400c <speech_synth_render+0x7e0>
d0083dfe:	ee17 2a90 	vmov	r2, s15
d0083e02:	edd9 7ac9 	vldr	s15, [r9, #804]	; 0x324
d0083e06:	ee66 6ae7 	vnmul.f32	s13, s13, s15
d0083e0a:	fb0c f202 	mul.w	r2, ip, r2
d0083e0e:	eee7 5a83 	vfma.f32	s11, s15, s6
d0083e12:	2a00      	cmp	r2, #0
d0083e14:	eee4 6a05 	vfma.f32	s13, s8, s10
d0083e18:	bfb8      	it	lt
d0083e1a:	327f      	addlt	r2, #127	; 0x7f
d0083e1c:	11d3      	asrs	r3, r2, #7
d0083e1e:	fe85 5ae2 	vminnm.f32	s10, s11, s5
d0083e22:	fe85 5a23 	vmaxnm.f32	s10, s10, s7
d0083e26:	ed89 5ac8 	vstr	s10, [r9, #800]	; 0x320
d0083e2a:	eeb9 5a04 	vmov.f32	s10, #148	; 0xc0a00000 -5.0
d0083e2e:	ee76 6ae5 	vsub.f32	s13, s13, s11
d0083e32:	eddf 5a75 	vldr	s11, [pc, #468]	; d0084008 <speech_synth_render+0x7dc>
d0083e36:	eee6 7a83 	vfma.f32	s15, s13, s6
d0083e3a:	fec7 7ae2 	vminnm.f32	s15, s15, s5
d0083e3e:	fec7 7aa3 	vmaxnm.f32	s15, s15, s7
d0083e42:	ee67 6a86 	vmul.f32	s13, s15, s12
d0083e46:	edc9 7ac9 	vstr	s15, [r9, #804]	; 0x324
d0083e4a:	ed99 6aca 	vldr	s12, [r9, #808]	; 0x328
d0083e4e:	eef1 3a04 	vmov.f32	s7, #20	; 0x40a00000  5.0
d0083e52:	eefd 7ae6 	vcvt.s32.f32	s15, s13
d0083e56:	eddf 6a6d 	vldr	s13, [pc, #436]	; d008400c <speech_synth_render+0x7e0>
d0083e5a:	ee17 2a90 	vmov	r2, s15
d0083e5e:	edd9 7acb 	vldr	s15, [r9, #812]	; 0x32c
d0083e62:	ee27 7a67 	vnmul.f32	s14, s14, s15
d0083e66:	fb07 f202 	mul.w	r2, r7, r2
d0083e6a:	eea7 6aa4 	vfma.f32	s12, s15, s9
d0083e6e:	4f68      	ldr	r7, [pc, #416]	; (d0084010 <speech_synth_render+0x7e4>)
d0083e70:	2a00      	cmp	r2, #0
d0083e72:	eea4 7a25 	vfma.f32	s14, s8, s11
d0083e76:	bfb8      	it	lt
d0083e78:	327f      	addlt	r2, #127	; 0x7f
d0083e7a:	eb03 12e2 	add.w	r2, r3, r2, asr #7
d0083e7e:	fec6 5a63 	vminnm.f32	s11, s12, s7
d0083e82:	fec5 5a85 	vmaxnm.f32	s11, s11, s10
d0083e86:	edc9 5aca 	vstr	s11, [r9, #808]	; 0x328
d0083e8a:	ee37 7a46 	vsub.f32	s14, s14, s12
d0083e8e:	eee7 7a24 	vfma.f32	s15, s14, s9
d0083e92:	fec7 7ae3 	vminnm.f32	s15, s15, s7
d0083e96:	fec7 7a85 	vmaxnm.f32	s15, s15, s10
d0083e9a:	ee27 7aa6 	vmul.f32	s14, s15, s13
d0083e9e:	edc9 7acb 	vstr	s15, [r9, #812]	; 0x32c
d0083ea2:	eefd 7ac7 	vcvt.s32.f32	s15, s14
d0083ea6:	ee17 3a90 	vmov	r3, s15
d0083eaa:	fb01 f303 	mul.w	r3, r1, r3
d0083eae:	17f1      	asrs	r1, r6, #31
d0083eb0:	2b00      	cmp	r3, #0
d0083eb2:	bfb8      	it	lt
d0083eb4:	337f      	addlt	r3, #127	; 0x7f
d0083eb6:	eb02 12e3 	add.w	r2, r2, r3, asr #7
d0083eba:	fb87 3606 	smull	r3, r6, r7, r6
d0083ebe:	f647 73ff 	movw	r3, #32767	; 0x7fff
d0083ec2:	ebc1 01a6 	rsb	r1, r1, r6, asr #2
d0083ec6:	440a      	add	r2, r1
d0083ec8:	ea82 71e2 	eor.w	r1, r2, r2, asr #31
d0083ecc:	eba1 71e2 	sub.w	r1, r1, r2, asr #31
d0083ed0:	ebc2 32c2 	rsb	r2, r2, r2, lsl #15
d0083ed4:	440b      	add	r3, r1
d0083ed6:	9926      	ldr	r1, [sp, #152]	; 0x98
d0083ed8:	2909      	cmp	r1, #9
d0083eda:	fb92 f2f3 	sdiv	r2, r2, r3
d0083ede:	f200 836d 	bhi.w	d00845bc <speech_synth_render+0xd90>
d0083ee2:	4b4c      	ldr	r3, [pc, #304]	; (d0084014 <speech_synth_render+0x7e8>)
d0083ee4:	f853 3021 	ldr.w	r3, [r3, r1, lsl #2]
d0083ee8:	fb03 f302 	mul.w	r3, r3, r2
d0083eec:	2b00      	cmp	r3, #0
d0083eee:	bfb8      	it	lt
d0083ef0:	33ff      	addlt	r3, #255	; 0xff
d0083ef2:	121b      	asrs	r3, r3, #8
d0083ef4:	fb05 f503 	mul.w	r5, r5, r3
d0083ef8:	2d00      	cmp	r5, #0
d0083efa:	bfb8      	it	lt
d0083efc:	35ff      	addlt	r5, #255	; 0xff
d0083efe:	eb00 2525 	add.w	r5, r0, r5, asr #8
d0083f02:	442c      	add	r4, r5
d0083f04:	9b1c      	ldr	r3, [sp, #112]	; 0x70
d0083f06:	fb04 f403 	mul.w	r4, r4, r3
d0083f0a:	9b16      	ldr	r3, [sp, #88]	; 0x58
d0083f0c:	2c00      	cmp	r4, #0
d0083f0e:	bfb8      	it	lt
d0083f10:	34ff      	addlt	r4, #255	; 0xff
d0083f12:	1224      	asrs	r4, r4, #8
d0083f14:	b13b      	cbz	r3, d0083f26 <speech_synth_render+0x6fa>
d0083f16:	ebc4 04c4 	rsb	r4, r4, r4, lsl #3
d0083f1a:	4b32      	ldr	r3, [pc, #200]	; (d0083fe4 <speech_synth_render+0x7b8>)
d0083f1c:	fb83 2304 	smull	r2, r3, r3, r4
d0083f20:	17e4      	asrs	r4, r4, #31
d0083f22:	ebc4 04a3 	rsb	r4, r4, r3, asr #2
d0083f26:	ea84 72e4 	eor.w	r2, r4, r4, asr #31
d0083f2a:	f647 73ff 	movw	r3, #32767	; 0x7fff
d0083f2e:	9903      	ldr	r1, [sp, #12]
d0083f30:	f10a 0a01 	add.w	sl, sl, #1
d0083f34:	eba2 72e4 	sub.w	r2, r2, r4, asr #31
d0083f38:	ebc4 34c4 	rsb	r4, r4, r4, lsl #15
d0083f3c:	3101      	adds	r1, #1
d0083f3e:	4413      	add	r3, r2
d0083f40:	9a05      	ldr	r2, [sp, #20]
d0083f42:	9103      	str	r1, [sp, #12]
d0083f44:	9917      	ldr	r1, [sp, #92]	; 0x5c
d0083f46:	3201      	adds	r2, #1
d0083f48:	fb94 f3f3 	sdiv	r3, r4, r3
d0083f4c:	11db      	asrs	r3, r3, #7
d0083f4e:	9205      	str	r2, [sp, #20]
d0083f50:	3380      	adds	r3, #128	; 0x80
d0083f52:	f383 0308 	usat	r3, #8, r3
d0083f56:	f801 3f01 	strb.w	r3, [r1, #1]!
d0083f5a:	9b01      	ldr	r3, [sp, #4]
d0083f5c:	9117      	str	r1, [sp, #92]	; 0x5c
d0083f5e:	4553      	cmp	r3, sl
d0083f60:	f240 8316 	bls.w	d0084590 <speech_synth_render+0xd64>
d0083f64:	4b2c      	ldr	r3, [pc, #176]	; (d0084018 <speech_synth_render+0x7ec>)
d0083f66:	429a      	cmp	r2, r3
d0083f68:	f200 8312 	bhi.w	d0084590 <speech_synth_render+0xd64>
d0083f6c:	4b2b      	ldr	r3, [pc, #172]	; (d008401c <speech_synth_render+0x7f0>)
d0083f6e:	fba3 230a 	umull	r2, r3, r3, sl
d0083f72:	4a2b      	ldr	r2, [pc, #172]	; (d0084020 <speech_synth_render+0x7f4>)
d0083f74:	f3c3 13c4 	ubfx	r3, r3, #7, #5
d0083f78:	56d1      	ldrsb	r1, [r2, r3]
d0083f7a:	e5ea      	b.n	d0083b52 <speech_synth_render+0x326>
d0083f7c:	eef0 4a48 	vmov.f32	s9, s16
d0083f80:	ed9f 6a28 	vldr	s12, [pc, #160]	; d0084024 <speech_synth_render+0x7f8>
d0083f84:	eddf 2a28 	vldr	s5, [pc, #160]	; d0084028 <speech_synth_render+0x7fc>
d0083f88:	212c      	movs	r1, #44	; 0x2c
d0083f8a:	eddf 6a28 	vldr	s13, [pc, #160]	; d008402c <speech_synth_render+0x800>
d0083f8e:	2746      	movs	r7, #70	; 0x46
d0083f90:	ed9f 3a34 	vldr	s6, [pc, #208]	; d0084064 <speech_synth_render+0x838>
d0083f94:	f04f 0c48 	mov.w	ip, #72	; 0x48
d0083f98:	ed9f 7a25 	vldr	s14, [pc, #148]	; d0084030 <speech_synth_render+0x804>
d0083f9c:	e6fb      	b.n	d0083d96 <speech_synth_render+0x56a>
d0083f9e:	eef0 4a48 	vmov.f32	s9, s16
d0083fa2:	ed9f 6a24 	vldr	s12, [pc, #144]	; d0084034 <speech_synth_render+0x808>
d0083fa6:	eddf 2a24 	vldr	s5, [pc, #144]	; d0084038 <speech_synth_render+0x80c>
d0083faa:	212c      	movs	r1, #44	; 0x2c
d0083fac:	eddf 6a23 	vldr	s13, [pc, #140]	; d008403c <speech_synth_render+0x810>
d0083fb0:	2750      	movs	r7, #80	; 0x50
d0083fb2:	ed9f 3a23 	vldr	s6, [pc, #140]	; d0084040 <speech_synth_render+0x814>
d0083fb6:	f04f 0c5e 	mov.w	ip, #94	; 0x5e
d0083fba:	ed9f 7a22 	vldr	s14, [pc, #136]	; d0084044 <speech_synth_render+0x818>
d0083fbe:	e6ea      	b.n	d0083d96 <speech_synth_render+0x56a>
d0083fc0:	ed9f 6a21 	vldr	s12, [pc, #132]	; d0084048 <speech_synth_render+0x81c>
d0083fc4:	2130      	movs	r1, #48	; 0x30
d0083fc6:	eddf 2a21 	vldr	s5, [pc, #132]	; d008404c <speech_synth_render+0x820>
d0083fca:	2756      	movs	r7, #86	; 0x56
d0083fcc:	eddf 6a20 	vldr	s13, [pc, #128]	; d0084050 <speech_synth_render+0x824>
d0083fd0:	f04f 0c5c 	mov.w	ip, #92	; 0x5c
d0083fd4:	ed9f 3a1f 	vldr	s6, [pc, #124]	; d0084054 <speech_synth_render+0x828>
d0083fd8:	ed9f 7a1f 	vldr	s14, [pc, #124]	; d0084058 <speech_synth_render+0x82c>
d0083fdc:	eddf 4a1f 	vldr	s9, [pc, #124]	; d008405c <speech_synth_render+0x830>
d0083fe0:	e6d9      	b.n	d0083d96 <speech_synth_render+0x56a>
d0083fe2:	bf00      	nop
d0083fe4:	66666667 	.word	0x66666667
d0083fe8:	d0085be0 	.word	0xd0085be0
d0083fec:	ffffb2a8 	.word	0xffffb2a8
d0083ff0:	0019660d 	.word	0x0019660d
d0083ff4:	3c6ef35f 	.word	0x3c6ef35f
d0083ff8:	3ec64c11 	.word	0x3ec64c11
d0083ffc:	3ec41afb 	.word	0x3ec41afb
d0084000:	3f852123 	.word	0x3f852123
d0084004:	3eef6994 	.word	0x3eef6994
d0084008:	38000000 	.word	0x38000000
d008400c:	46fffe00 	.word	0x46fffe00
d0084010:	38e38e39 	.word	0x38e38e39
d0084014:	d0085c24 	.word	0xd0085c24
d0084018:	00040997 	.word	0x00040997
d008401c:	4763d59d 	.word	0x4763d59d
d0084020:	d0085c74 	.word	0xd0085c74
d0084024:	3f94b197 	.word	0x3f94b197
d0084028:	3ef8059f 	.word	0x3ef8059f
d008402c:	3f3d85cf 	.word	0x3f3d85cf
d0084030:	3f058eff 	.word	0x3f058eff
d0084034:	3f11dbf6 	.word	0x3f11dbf6
d0084038:	3f2f1307 	.word	0x3f2f1307
d008403c:	3ee2f07c 	.word	0x3ee2f07c
d0084040:	3faf1307 	.word	0x3faf1307
d0084044:	3ee2f484 	.word	0x3ee2f484
d0084048:	3f6dc528 	.word	0x3f6dc528
d008404c:	3e78059f 	.word	0x3e78059f
d0084050:	3f309607 	.word	0x3f309607
d0084054:	3f06f400 	.word	0x3f06f400
d0084058:	3f01abb0 	.word	0x3f01abb0
d008405c:	3f834e45 	.word	0x3f834e45
d0084060:	3e8ba5f7 	.word	0x3e8ba5f7
d0084064:	3f8e3f76 	.word	0x3f8e3f76
d0084068:	3e8a7a14 	.word	0x3e8a7a14
d008406c:	3e9d9929 	.word	0x3e9d9929
d0084070:	3ecaee4f 	.word	0x3ecaee4f
d0084074:	3f27c791 	.word	0x3f27c791
d0084078:	3ec0dc8b 	.word	0x3ec0dc8b
d008407c:	3f817b68 	.word	0x3f817b68
d0084080:	3ec285c9 	.word	0x3ec285c9
d0084084:	3e637119 	.word	0x3e637119
d0084088:	3fbda9f2 	.word	0x3fbda9f2
d008408c:	3e85122f 	.word	0x3e85122f
d0084090:	3ea6bef1 	.word	0x3ea6bef1
d0084094:	3f9821cf 	.word	0x3f9821cf
d0084098:	3ea7c791 	.word	0x3ea7c791
d008409c:	3f464c11 	.word	0x3f464c11
d00840a0:	3f3a0438 	.word	0x3f3a0438
d00840a4:	3f1d4537 	.word	0x3f1d4537
d00840a8:	3fab6d4c 	.word	0x3fab6d4c
d00840ac:	eeb0 3a48 	vmov.f32	s6, s16
d00840b0:	ed1f 6a15 	vldr	s12, [pc, #-84]	; d0084060 <speech_synth_render+0x834>
d00840b4:	eef0 4a48 	vmov.f32	s9, s16
d00840b8:	ed5f 2a16 	vldr	s5, [pc, #-88]	; d0084064 <speech_synth_render+0x838>
d00840bc:	ed5f 6a16 	vldr	s13, [pc, #-88]	; d0084068 <speech_synth_render+0x83c>
d00840c0:	2140      	movs	r1, #64	; 0x40
d00840c2:	ed1f 7a16 	vldr	s14, [pc, #-88]	; d008406c <speech_synth_render+0x840>
d00840c6:	2776      	movs	r7, #118	; 0x76
d00840c8:	f04f 0c74 	mov.w	ip, #116	; 0x74
d00840cc:	e663      	b.n	d0083d96 <speech_synth_render+0x56a>
d00840ce:	ed1f 6a18 	vldr	s12, [pc, #-96]	; d0084070 <speech_synth_render+0x844>
d00840d2:	213a      	movs	r1, #58	; 0x3a
d00840d4:	ed5f 2a19 	vldr	s5, [pc, #-100]	; d0084074 <speech_synth_render+0x848>
d00840d8:	2780      	movs	r7, #128	; 0x80
d00840da:	ed5f 6a19 	vldr	s13, [pc, #-100]	; d0084078 <speech_synth_render+0x84c>
d00840de:	f04f 0c62 	mov.w	ip, #98	; 0x62
d00840e2:	ed1f 3a1a 	vldr	s6, [pc, #-104]	; d008407c <speech_synth_render+0x850>
d00840e6:	ed1f 7a1a 	vldr	s14, [pc, #-104]	; d0084080 <speech_synth_render+0x854>
d00840ea:	ed5f 4a19 	vldr	s9, [pc, #-100]	; d0084088 <speech_synth_render+0x85c>
d00840ee:	e652      	b.n	d0083d96 <speech_synth_render+0x56a>
d00840f0:	eeb0 3a48 	vmov.f32	s6, s16
d00840f4:	ed1f 6a1d 	vldr	s12, [pc, #-116]	; d0084084 <speech_synth_render+0x858>
d00840f8:	eef0 4a48 	vmov.f32	s9, s16
d00840fc:	ed5f 2a1e 	vldr	s5, [pc, #-120]	; d0084088 <speech_synth_render+0x85c>
d0084100:	ed5f 6a1e 	vldr	s13, [pc, #-120]	; d008408c <speech_synth_render+0x860>
d0084104:	2126      	movs	r1, #38	; 0x26
d0084106:	ed1f 7a1e 	vldr	s14, [pc, #-120]	; d0084090 <speech_synth_render+0x864>
d008410a:	2752      	movs	r7, #82	; 0x52
d008410c:	f04f 0c8e 	mov.w	ip, #142	; 0x8e
d0084110:	e641      	b.n	d0083d96 <speech_synth_render+0x56a>
d0084112:	ed1f 6a20 	vldr	s12, [pc, #-128]	; d0084094 <speech_synth_render+0x868>
d0084116:	211c      	movs	r1, #28
d0084118:	ed5f 2a21 	vldr	s5, [pc, #-132]	; d0084098 <speech_synth_render+0x86c>
d008411c:	2734      	movs	r7, #52	; 0x34
d008411e:	ed5f 6a21 	vldr	s13, [pc, #-132]	; d008409c <speech_synth_render+0x870>
d0084122:	f04f 0c40 	mov.w	ip, #64	; 0x40
d0084126:	ed1f 3a22 	vldr	s6, [pc, #-136]	; d00840a0 <speech_synth_render+0x874>
d008412a:	ed1f 7a22 	vldr	s14, [pc, #-136]	; d00840a4 <speech_synth_render+0x878>
d008412e:	ed5f 4a22 	vldr	s9, [pc, #-136]	; d00840a8 <speech_synth_render+0x87c>
d0084132:	e630      	b.n	d0083d96 <speech_synth_render+0x56a>
d0084134:	461c      	mov	r4, r3
d0084136:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0084138:	2b00      	cmp	r3, #0
d008413a:	f47f adb4 	bne.w	d0083ca6 <speech_synth_render+0x47a>
d008413e:	f1bb 0f00 	cmp.w	fp, #0
d0084142:	f43f aedf 	beq.w	d0083f04 <speech_synth_render+0x6d8>
d0084146:	9a0a      	ldr	r2, [sp, #40]	; 0x28
d0084148:	4659      	mov	r1, fp
d008414a:	9804      	ldr	r0, [sp, #16]
d008414c:	f7fc f890 	bl	d0080270 <render_noise.constprop.0>
d0084150:	4404      	add	r4, r0
d0084152:	e6d7      	b.n	d0083f04 <speech_synth_render+0x6d8>
d0084154:	9b18      	ldr	r3, [sp, #96]	; 0x60
d0084156:	9a04      	ldr	r2, [sp, #16]
d0084158:	1898      	adds	r0, r3, r2
d008415a:	9b22      	ldr	r3, [sp, #136]	; 0x88
d008415c:	eb03 0183 	add.w	r1, r3, r3, lsl #2
d0084160:	4b9a      	ldr	r3, [pc, #616]	; (d00843cc <speech_synth_render+0xba0>)
d0084162:	eb03 0080 	add.w	r0, r3, r0, lsl #2
d0084166:	eb03 0181 	add.w	r1, r3, r1, lsl #2
d008416a:	7ac5      	ldrb	r5, [r0, #11]
d008416c:	f8b0 c008 	ldrh.w	ip, [r0, #8]
d0084170:	f8b0 8004 	ldrh.w	r8, [r0, #4]
d0084174:	f8b0 e006 	ldrh.w	lr, [r0, #6]
d0084178:	f890 b00a 	ldrb.w	fp, [r0, #10]
d008417c:	7b00      	ldrb	r0, [r0, #12]
d008417e:	950d      	str	r5, [sp, #52]	; 0x34
d0084180:	9007      	str	r0, [sp, #28]
d0084182:	88cb      	ldrh	r3, [r1, #6]
d0084184:	7acd      	ldrb	r5, [r1, #11]
d0084186:	980d      	ldr	r0, [sp, #52]	; 0x34
d0084188:	2b00      	cmp	r3, #0
d008418a:	bf08      	it	eq
d008418c:	4673      	moveq	r3, lr
d008418e:	890c      	ldrh	r4, [r1, #8]
d0084190:	7b0f      	ldrb	r7, [r1, #12]
d0084192:	1a2d      	subs	r5, r5, r0
d0084194:	9807      	ldr	r0, [sp, #28]
d0084196:	2c00      	cmp	r4, #0
d0084198:	bf08      	it	eq
d008419a:	4664      	moveq	r4, ip
d008419c:	888a      	ldrh	r2, [r1, #4]
d008419e:	eba3 030e 	sub.w	r3, r3, lr
d00841a2:	7a8e      	ldrb	r6, [r1, #10]
d00841a4:	1a3f      	subs	r7, r7, r0
d00841a6:	7b49      	ldrb	r1, [r1, #13]
d00841a8:	eba4 040c 	sub.w	r4, r4, ip
d00841ac:	980c      	ldr	r0, [sp, #48]	; 0x30
d00841ae:	2a00      	cmp	r2, #0
d00841b0:	bf08      	it	eq
d00841b2:	4642      	moveq	r2, r8
d00841b4:	eba6 060b 	sub.w	r6, r6, fp
d00841b8:	fb0a f303 	mul.w	r3, sl, r3
d00841bc:	1a09      	subs	r1, r1, r0
d00841be:	9801      	ldr	r0, [sp, #4]
d00841c0:	eba2 0208 	sub.w	r2, r2, r8
d00841c4:	fb0a f404 	mul.w	r4, sl, r4
d00841c8:	fb0a f606 	mul.w	r6, sl, r6
d00841cc:	fb0a f202 	mul.w	r2, sl, r2
d00841d0:	fb0a f707 	mul.w	r7, sl, r7
d00841d4:	fb0a f505 	mul.w	r5, sl, r5
d00841d8:	fb0a f101 	mul.w	r1, sl, r1
d00841dc:	fb93 f3f0 	sdiv	r3, r3, r0
d00841e0:	fb94 f4f0 	sdiv	r4, r4, r0
d00841e4:	fb96 f6f0 	sdiv	r6, r6, r0
d00841e8:	fb92 f2f0 	sdiv	r2, r2, r0
d00841ec:	fb97 f7f0 	sdiv	r7, r7, r0
d00841f0:	4473      	add	r3, lr
d00841f2:	4464      	add	r4, ip
d00841f4:	445e      	add	r6, fp
d00841f6:	4442      	add	r2, r8
d00841f8:	b29b      	uxth	r3, r3
d00841fa:	fa1f fc84 	uxth.w	ip, r4
d00841fe:	9c0d      	ldr	r4, [sp, #52]	; 0x34
d0084200:	931e      	str	r3, [sp, #120]	; 0x78
d0084202:	b2f3      	uxtb	r3, r6
d0084204:	b292      	uxth	r2, r2
d0084206:	f8cd c040 	str.w	ip, [sp, #64]	; 0x40
d008420a:	931f      	str	r3, [sp, #124]	; 0x7c
d008420c:	9b16      	ldr	r3, [sp, #88]	; 0x58
d008420e:	921d      	str	r2, [sp, #116]	; 0x74
d0084210:	fb95 f5f0 	sdiv	r5, r5, r0
d0084214:	fb91 f1f0 	sdiv	r1, r1, r0
d0084218:	9807      	ldr	r0, [sp, #28]
d008421a:	4425      	add	r5, r4
d008421c:	f20c 3452 	addw	r4, ip, #850	; 0x352
d0084220:	4407      	add	r7, r0
d0084222:	980c      	ldr	r0, [sp, #48]	; 0x30
d0084224:	b2a2      	uxth	r2, r4
d0084226:	4401      	add	r1, r0
d0084228:	fa5f f885 	uxtb.w	r8, r5
d008422c:	b2f8      	uxtb	r0, r7
d008422e:	fa5f fb81 	uxtb.w	fp, r1
d0084232:	2b00      	cmp	r3, #0
d0084234:	f000 8083 	beq.w	d008433e <speech_synth_render+0xb12>
d0084238:	f20c 53aa 	addw	r3, ip, #1450	; 0x5aa
d008423c:	f641 57b0 	movw	r7, #7600	; 0x1db0
d0084240:	f241 76d4 	movw	r6, #6100	; 0x17d4
d0084244:	4d62      	ldr	r5, [pc, #392]	; (d00843d0 <speech_synth_render+0xba4>)
d0084246:	fa1f fc83 	uxth.w	ip, r3
d008424a:	f44f 7e70 	mov.w	lr, #960	; 0x3c0
d008424e:	fba5 3508 	umull	r3, r5, r5, r8
d0084252:	eb0b 034b 	add.w	r3, fp, fp, lsl #1
d0084256:	45bc      	cmp	ip, r7
d0084258:	ea4f 01db 	mov.w	r1, fp, lsr #3
d008425c:	ea4f 0393 	mov.w	r3, r3, lsr #2
d0084260:	bf28      	it	cs
d0084262:	46bc      	movcs	ip, r7
d0084264:	42b2      	cmp	r2, r6
d0084266:	ea4f 045b 	mov.w	r4, fp, lsr #1
d008426a:	931a      	str	r3, [sp, #104]	; 0x68
d008426c:	bf28      	it	cs
d008426e:	4632      	movcs	r2, r6
d0084270:	f641 1364 	movw	r3, #6500	; 0x1964
d0084274:	eb04 04d5 	add.w	r4, r4, r5, lsr #3
d0084278:	f8cd c034 	str.w	ip, [sp, #52]	; 0x34
d008427c:	9211      	str	r2, [sp, #68]	; 0x44
d008427e:	eb01 0250 	add.w	r2, r1, r0, lsr #1
d0084282:	9313      	str	r3, [sp, #76]	; 0x4c
d0084284:	f44f 7c82 	mov.w	ip, #260	; 0x104
d0084288:	f44f 6396 	mov.w	r3, #1200	; 0x4b0
d008428c:	920f      	str	r2, [sp, #60]	; 0x3c
d008428e:	f44f 77d2 	mov.w	r7, #420	; 0x1a4
d0084292:	f240 52dc 	movw	r2, #1500	; 0x5dc
d0084296:	f44f 762f 	mov.w	r6, #700	; 0x2bc
d008429a:	9419      	str	r4, [sp, #100]	; 0x64
d008429c:	9214      	str	r2, [sp, #80]	; 0x50
d008429e:	930e      	str	r3, [sp, #56]	; 0x38
d00842a0:	9b09      	ldr	r3, [sp, #36]	; 0x24
d00842a2:	b123      	cbz	r3, d00842ae <speech_synth_render+0xa82>
d00842a4:	f1bb 0f4c 	cmp.w	fp, #76	; 0x4c
d00842a8:	bf38      	it	cc
d00842aa:	f04f 0b4c 	movcc.w	fp, #76	; 0x4c
d00842ae:	9b06      	ldr	r3, [sp, #24]
d00842b0:	f899 4310 	ldrb.w	r4, [r9, #784]	; 0x310
d00842b4:	b143      	cbz	r3, d00842c8 <speech_synth_render+0xa9c>
d00842b6:	f642 3411 	movw	r4, #11025	; 0x2b11
d00842ba:	9b02      	ldr	r3, [sp, #8]
d00842bc:	fbb4 f4f3 	udiv	r4, r4, r3
d00842c0:	b2e4      	uxtb	r4, r4
d00842c2:	2c60      	cmp	r4, #96	; 0x60
d00842c4:	bf28      	it	cs
d00842c6:	2460      	movcs	r4, #96	; 0x60
d00842c8:	f89d 30a0 	ldrb.w	r3, [sp, #160]	; 0xa0
d00842cc:	2501      	movs	r5, #1
d00842ce:	9902      	ldr	r1, [sp, #8]
d00842d0:	9320      	str	r3, [sp, #128]	; 0x80
d00842d2:	4b40      	ldr	r3, [pc, #256]	; (d00843d4 <speech_synth_render+0xba8>)
d00842d4:	9412      	str	r4, [sp, #72]	; 0x48
d00842d6:	9307      	str	r3, [sp, #28]
d00842d8:	9021      	str	r0, [sp, #132]	; 0x84
d00842da:	b2eb      	uxtb	r3, r5
d00842dc:	9a12      	ldr	r2, [sp, #72]	; 0x48
d00842de:	429a      	cmp	r2, r3
d00842e0:	d302      	bcc.n	d00842e8 <speech_synth_render+0xabc>
d00842e2:	9b20      	ldr	r3, [sp, #128]	; 0x80
d00842e4:	2b00      	cmp	r3, #0
d00842e6:	d179      	bne.n	d00843dc <speech_synth_render+0xbb0>
d00842e8:	2300      	movs	r3, #0
d00842ea:	9807      	ldr	r0, [sp, #28]
d00842ec:	3501      	adds	r5, #1
d00842ee:	f850 2f04 	ldr.w	r2, [r0, #4]!
d00842f2:	1a9b      	subs	r3, r3, r2
d00842f4:	9a02      	ldr	r2, [sp, #8]
d00842f6:	9007      	str	r0, [sp, #28]
d00842f8:	bf48      	it	mi
d00842fa:	333f      	addmi	r3, #63	; 0x3f
d00842fc:	4411      	add	r1, r2
d00842fe:	2d61      	cmp	r5, #97	; 0x61
d0084300:	9a07      	ldr	r2, [sp, #28]
d0084302:	ea4f 13a3 	mov.w	r3, r3, asr #6
d0084306:	b289      	uxth	r1, r1
d0084308:	f8c2 3184 	str.w	r3, [r2, #388]	; 0x184
d008430c:	d1e5      	bne.n	d00842da <speech_synth_render+0xaae>
d008430e:	9c12      	ldr	r4, [sp, #72]	; 0x48
d0084310:	f889 4310 	strb.w	r4, [r9, #784]	; 0x310
d0084314:	e446      	b.n	d0083ba4 <speech_synth_render+0x378>
d0084316:	9b08      	ldr	r3, [sp, #32]
d0084318:	2b00      	cmp	r3, #0
d008431a:	f040 80e2 	bne.w	d00844e2 <speech_synth_render+0xcb6>
d008431e:	f10a 038e 	add.w	r3, sl, #142	; 0x8e
d0084322:	9a01      	ldr	r2, [sp, #4]
d0084324:	429a      	cmp	r2, r3
d0084326:	f080 80dc 	bcs.w	d00844e2 <speech_synth_render+0xcb6>
d008432a:	9b2f      	ldr	r3, [sp, #188]	; 0xbc
d008432c:	ebca 640a 	rsb	r4, sl, sl, lsl #24
d0084330:	eb03 2404 	add.w	r4, r3, r4, lsl #8
d0084334:	4b28      	ldr	r3, [pc, #160]	; (d00843d8 <speech_synth_render+0xbac>)
d0084336:	fba3 3404 	umull	r3, r4, r3, r4
d008433a:	09e4      	lsrs	r4, r4, #7
d008433c:	e41d      	b.n	d0083b7a <speech_synth_render+0x34e>
d008433e:	f241 76d4 	movw	r6, #6100	; 0x17d4
d0084342:	4613      	mov	r3, r2
d0084344:	0881      	lsrs	r1, r0, #2
d0084346:	42b2      	cmp	r2, r6
d0084348:	bf28      	it	cs
d008434a:	4633      	movcs	r3, r6
d008434c:	9311      	str	r3, [sp, #68]	; 0x44
d008434e:	9b25      	ldr	r3, [sp, #148]	; 0x94
d0084350:	2b00      	cmp	r3, #0
d0084352:	f040 8157 	bne.w	d0084604 <speech_synth_render+0xdd8>
d0084356:	9b2d      	ldr	r3, [sp, #180]	; 0xb4
d0084358:	f240 421a 	movw	r2, #1050	; 0x41a
d008435c:	4c1c      	ldr	r4, [pc, #112]	; (d00843d0 <speech_synth_render+0xba4>)
d008435e:	08c5      	lsrs	r5, r0, #3
d0084360:	2b00      	cmp	r3, #0
d0084362:	9e29      	ldr	r6, [sp, #164]	; 0xa4
d0084364:	fba4 3408 	umull	r3, r4, r4, r8
d0084368:	ea4f 0350 	mov.w	r3, r0, lsr #1
d008436c:	bf18      	it	ne
d008436e:	f44f 628c 	movne.w	r2, #1120	; 0x460
d0084372:	eb01 0141 	add.w	r1, r1, r1, lsl #1
d0084376:	eb03 03db 	add.w	r3, r3, fp, lsr #3
d008437a:	bf18      	it	ne
d008437c:	46b4      	movne	ip, r6
d008437e:	9214      	str	r2, [sp, #80]	; 0x50
d0084380:	eb05 02d4 	add.w	r2, r5, r4, lsr #3
d0084384:	930f      	str	r3, [sp, #60]	; 0x3c
d0084386:	f44f 53e1 	mov.w	r3, #7200	; 0x1c20
d008438a:	9219      	str	r2, [sp, #100]	; 0x64
d008438c:	ea4f 0191 	mov.w	r1, r1, lsr #2
d0084390:	9a2a      	ldr	r2, [sp, #168]	; 0xa8
d0084392:	bf08      	it	eq
d0084394:	f04f 0c6e 	moveq.w	ip, #110	; 0x6e
d0084398:	9313      	str	r3, [sp, #76]	; 0x4c
d008439a:	f241 235c 	movw	r3, #4700	; 0x125c
d008439e:	bf18      	it	ne
d00843a0:	4617      	movne	r7, r2
d00843a2:	9a2b      	ldr	r2, [sp, #172]	; 0xac
d00843a4:	bf06      	itte	eq
d00843a6:	27b4      	moveq	r7, #180	; 0xb4
d00843a8:	f44f 7696 	moveq.w	r6, #300	; 0x12c
d00843ac:	4616      	movne	r6, r2
d00843ae:	9a2c      	ldr	r2, [sp, #176]	; 0xb0
d00843b0:	bf08      	it	eq
d00843b2:	f44f 7e02 	moveq.w	lr, #520	; 0x208
d00843b6:	911a      	str	r1, [sp, #104]	; 0x68
d00843b8:	bf18      	it	ne
d00843ba:	4696      	movne	lr, r2
d00843bc:	9a2e      	ldr	r2, [sp, #184]	; 0xb8
d00843be:	bf08      	it	eq
d00843c0:	f44f 723e 	moveq.w	r2, #760	; 0x2f8
d00843c4:	930d      	str	r3, [sp, #52]	; 0x34
d00843c6:	920e      	str	r2, [sp, #56]	; 0x38
d00843c8:	e76a      	b.n	d00842a0 <speech_synth_render+0xa74>
d00843ca:	bf00      	nop
d00843cc:	d0085c94 	.word	0xd0085c94
d00843d0:	cccccccd 	.word	0xcccccccd
d00843d4:	d00c7f44 	.word	0xd00c7f44
d00843d8:	e6c2b449 	.word	0xe6c2b449
d00843dc:	9b1d      	ldr	r3, [sp, #116]	; 0x74
d00843de:	1acb      	subs	r3, r1, r3
d00843e0:	2b00      	cmp	r3, #0
d00843e2:	bfb8      	it	lt
d00843e4:	425b      	neglt	r3, r3
d00843e6:	4563      	cmp	r3, ip
d00843e8:	da79      	bge.n	d00844de <speech_synth_render+0xcb2>
d00843ea:	021b      	lsls	r3, r3, #8
d00843ec:	9a1f      	ldr	r2, [sp, #124]	; 0x7c
d00843ee:	fbb3 f3fc 	udiv	r3, r3, ip
d00843f2:	f5c3 7380 	rsb	r3, r3, #256	; 0x100
d00843f6:	fb03 f303 	mul.w	r3, r3, r3
d00843fa:	121b      	asrs	r3, r3, #8
d00843fc:	fb02 f303 	mul.w	r3, r2, r3
d0084400:	111b      	asrs	r3, r3, #4
d0084402:	9a1e      	ldr	r2, [sp, #120]	; 0x78
d0084404:	1a8a      	subs	r2, r1, r2
d0084406:	2a00      	cmp	r2, #0
d0084408:	bfb8      	it	lt
d008440a:	4252      	neglt	r2, r2
d008440c:	42ba      	cmp	r2, r7
d008440e:	da0b      	bge.n	d0084428 <speech_synth_render+0xbfc>
d0084410:	0212      	lsls	r2, r2, #8
d0084412:	fbb2 f2f7 	udiv	r2, r2, r7
d0084416:	f5c2 7280 	rsb	r2, r2, #256	; 0x100
d008441a:	fb02 f202 	mul.w	r2, r2, r2
d008441e:	1212      	asrs	r2, r2, #8
d0084420:	fb08 f202 	mul.w	r2, r8, r2
d0084424:	eb03 1322 	add.w	r3, r3, r2, asr #4
d0084428:	9a10      	ldr	r2, [sp, #64]	; 0x40
d008442a:	1a8a      	subs	r2, r1, r2
d008442c:	2a00      	cmp	r2, #0
d008442e:	bfb8      	it	lt
d0084430:	4252      	neglt	r2, r2
d0084432:	42b2      	cmp	r2, r6
d0084434:	da0c      	bge.n	d0084450 <speech_synth_render+0xc24>
d0084436:	0212      	lsls	r2, r2, #8
d0084438:	9821      	ldr	r0, [sp, #132]	; 0x84
d008443a:	fbb2 f2f6 	udiv	r2, r2, r6
d008443e:	f5c2 7280 	rsb	r2, r2, #256	; 0x100
d0084442:	fb02 f202 	mul.w	r2, r2, r2
d0084446:	1212      	asrs	r2, r2, #8
d0084448:	fb00 f202 	mul.w	r2, r0, r2
d008444c:	eb03 1322 	add.w	r3, r3, r2, asr #4
d0084450:	9a11      	ldr	r2, [sp, #68]	; 0x44
d0084452:	1a8a      	subs	r2, r1, r2
d0084454:	2a00      	cmp	r2, #0
d0084456:	bfb8      	it	lt
d0084458:	4252      	neglt	r2, r2
d008445a:	4572      	cmp	r2, lr
d008445c:	da0c      	bge.n	d0084478 <speech_synth_render+0xc4c>
d008445e:	0212      	lsls	r2, r2, #8
d0084460:	980f      	ldr	r0, [sp, #60]	; 0x3c
d0084462:	fbb2 f2fe 	udiv	r2, r2, lr
d0084466:	f5c2 7280 	rsb	r2, r2, #256	; 0x100
d008446a:	fb02 f202 	mul.w	r2, r2, r2
d008446e:	1212      	asrs	r2, r2, #8
d0084470:	fb00 f202 	mul.w	r2, r0, r2
d0084474:	eb03 1322 	add.w	r3, r3, r2, asr #4
d0084478:	9a0d      	ldr	r2, [sp, #52]	; 0x34
d008447a:	9c0e      	ldr	r4, [sp, #56]	; 0x38
d008447c:	1a8a      	subs	r2, r1, r2
d008447e:	2a00      	cmp	r2, #0
d0084480:	bfb8      	it	lt
d0084482:	4252      	neglt	r2, r2
d0084484:	42a2      	cmp	r2, r4
d0084486:	da0c      	bge.n	d00844a2 <speech_synth_render+0xc76>
d0084488:	0212      	lsls	r2, r2, #8
d008448a:	9819      	ldr	r0, [sp, #100]	; 0x64
d008448c:	fbb2 f2f4 	udiv	r2, r2, r4
d0084490:	f5c2 7280 	rsb	r2, r2, #256	; 0x100
d0084494:	fb02 f202 	mul.w	r2, r2, r2
d0084498:	1212      	asrs	r2, r2, #8
d008449a:	fb00 f202 	mul.w	r2, r0, r2
d008449e:	eb03 1322 	add.w	r3, r3, r2, asr #4
d00844a2:	9a13      	ldr	r2, [sp, #76]	; 0x4c
d00844a4:	9814      	ldr	r0, [sp, #80]	; 0x50
d00844a6:	1a8a      	subs	r2, r1, r2
d00844a8:	2a00      	cmp	r2, #0
d00844aa:	bfb8      	it	lt
d00844ac:	4252      	neglt	r2, r2
d00844ae:	4282      	cmp	r2, r0
d00844b0:	da0c      	bge.n	d00844cc <speech_synth_render+0xca0>
d00844b2:	0212      	lsls	r2, r2, #8
d00844b4:	fbb2 f2f0 	udiv	r2, r2, r0
d00844b8:	f5c2 7280 	rsb	r2, r2, #256	; 0x100
d00844bc:	981a      	ldr	r0, [sp, #104]	; 0x68
d00844be:	fb02 f202 	mul.w	r2, r2, r2
d00844c2:	1212      	asrs	r2, r2, #8
d00844c4:	fb00 f202 	mul.w	r2, r0, r2
d00844c8:	eb03 1322 	add.w	r3, r3, r2, asr #4
d00844cc:	f5b1 7f61 	cmp.w	r1, #900	; 0x384
d00844d0:	f4bf af0b 	bcs.w	d00842ea <speech_synth_render+0xabe>
d00844d4:	f5c1 7261 	rsb	r2, r1, #900	; 0x384
d00844d8:	eb03 03a2 	add.w	r3, r3, r2, asr #2
d00844dc:	e705      	b.n	d00842ea <speech_synth_render+0xabe>
d00844de:	2300      	movs	r3, #0
d00844e0:	e78f      	b.n	d0084402 <speech_synth_render+0xbd6>
d00844e2:	f44f 7480 	mov.w	r4, #256	; 0x100
d00844e6:	f7ff bb48 	b.w	d0083b7a <speech_synth_render+0x34e>
d00844ea:	eb03 0443 	add.w	r4, r3, r3, lsl #1
d00844ee:	eb13 0384 	adds.w	r3, r3, r4, lsl #2
d00844f2:	4c60      	ldr	r4, [pc, #384]	; (d0084674 <speech_synth_render+0xe48>)
d00844f4:	bf48      	it	mi
d00844f6:	330f      	addmi	r3, #15
d00844f8:	f023 030f 	bic.w	r3, r3, #15
d00844fc:	fb84 2403 	smull	r2, r4, r4, r3
d0084500:	17db      	asrs	r3, r3, #31
d0084502:	ebc3 0464 	rsb	r4, r3, r4, asr #1
d0084506:	f7ff bbca 	b.w	d0083c9e <speech_synth_render+0x472>
d008450a:	4698      	mov	r8, r3
d008450c:	f7ff bb6c 	b.w	d0083be8 <speech_synth_render+0x3bc>
d0084510:	9b24      	ldr	r3, [sp, #144]	; 0x90
d0084512:	4553      	cmp	r3, sl
d0084514:	f67f ab3b 	bls.w	d0083b8e <speech_synth_render+0x362>
d0084518:	f44f 73aa 	mov.w	r3, #340	; 0x154
d008451c:	fb03 f404 	mul.w	r4, r3, r4
d0084520:	0a24      	lsrs	r4, r4, #8
d0084522:	f7ff bb34 	b.w	d0083b8e <speech_synth_render+0x362>
d0084526:	9908      	ldr	r1, [sp, #32]
d0084528:	eb01 0281 	add.w	r2, r1, r1, lsl #2
d008452c:	9122      	str	r1, [sp, #136]	; 0x88
d008452e:	4952      	ldr	r1, [pc, #328]	; (d0084678 <speech_synth_render+0xe4c>)
d0084530:	eb01 0282 	add.w	r2, r1, r2, lsl #2
d0084534:	9904      	ldr	r1, [sp, #16]
d0084536:	7b92      	ldrb	r2, [r2, #14]
d0084538:	2900      	cmp	r1, #0
d008453a:	f47f aa8a 	bne.w	d0083a52 <speech_synth_render+0x226>
d008453e:	f44f 72c2 	mov.w	r2, #388	; 0x184
d0084542:	2100      	movs	r1, #0
d0084544:	484d      	ldr	r0, [pc, #308]	; (d008467c <speech_synth_render+0xe50>)
d0084546:	f000 fa57 	bl	d00849f8 <memset>
d008454a:	f44f 72c2 	mov.w	r2, #388	; 0x184
d008454e:	2100      	movs	r1, #0
d0084550:	484b      	ldr	r0, [pc, #300]	; (d0084680 <speech_synth_render+0xe54>)
d0084552:	f000 fa51 	bl	d00849f8 <memset>
d0084556:	2300      	movs	r3, #0
d0084558:	f5b5 7f7a 	cmp.w	r5, #1000	; 0x3e8
d008455c:	f889 3310 	strb.w	r3, [r9, #784]	; 0x310
d0084560:	d316      	bcc.n	d0084590 <speech_synth_render+0xd64>
d0084562:	4848      	ldr	r0, [pc, #288]	; (d0084684 <speech_synth_render+0xe58>)
d0084564:	9b05      	ldr	r3, [sp, #20]
d0084566:	4283      	cmp	r3, r0
d0084568:	d812      	bhi.n	d0084590 <speech_synth_render+0xd64>
d008456a:	1e5a      	subs	r2, r3, #1
d008456c:	4c46      	ldr	r4, [pc, #280]	; (d0084688 <speech_synth_render+0xe5c>)
d008456e:	461f      	mov	r7, r3
d0084570:	4619      	mov	r1, r3
d0084572:	4422      	add	r2, r4
d0084574:	2580      	movs	r5, #128	; 0x80
d0084576:	9e01      	ldr	r6, [sp, #4]
d0084578:	4613      	mov	r3, r2
d008457a:	3101      	adds	r1, #1
d008457c:	f802 5f01 	strb.w	r5, [r2, #1]!
d0084580:	3302      	adds	r3, #2
d0084582:	1b1b      	subs	r3, r3, r4
d0084584:	1bdb      	subs	r3, r3, r7
d0084586:	429e      	cmp	r6, r3
d0084588:	d901      	bls.n	d008458e <speech_synth_render+0xd62>
d008458a:	4281      	cmp	r1, r0
d008458c:	d9f4      	bls.n	d0084578 <speech_synth_render+0xd4c>
d008458e:	9105      	str	r1, [sp, #20]
d0084590:	4b3c      	ldr	r3, [pc, #240]	; (d0084684 <speech_synth_render+0xe58>)
d0084592:	9a05      	ldr	r2, [sp, #20]
d0084594:	429a      	cmp	r2, r3
d0084596:	d808      	bhi.n	d00845aa <speech_synth_render+0xd7e>
d0084598:	9b1b      	ldr	r3, [sp, #108]	; 0x6c
d008459a:	f8bd 10c8 	ldrh.w	r1, [sp, #200]	; 0xc8
d008459e:	3301      	adds	r3, #1
d00845a0:	b29a      	uxth	r2, r3
d00845a2:	931b      	str	r3, [sp, #108]	; 0x6c
d00845a4:	4291      	cmp	r1, r2
d00845a6:	f63f aa19 	bhi.w	d00839dc <speech_synth_render+0x1b0>
d00845aa:	9a05      	ldr	r2, [sp, #20]
d00845ac:	4b37      	ldr	r3, [pc, #220]	; (d008468c <speech_synth_render+0xe60>)
d00845ae:	4610      	mov	r0, r2
d00845b0:	601a      	str	r2, [r3, #0]
d00845b2:	b03f      	add	sp, #252	; 0xfc
d00845b4:	ecbd 8b02 	vpop	{d8}
d00845b8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00845bc:	2356      	movs	r3, #86	; 0x56
d00845be:	e493      	b.n	d0083ee8 <speech_synth_render+0x6bc>
d00845c0:	461a      	mov	r2, r3
d00845c2:	4b33      	ldr	r3, [pc, #204]	; (d0084690 <speech_synth_render+0xe64>)
d00845c4:	5c99      	ldrb	r1, [r3, r2]
d00845c6:	f7ff bb99 	b.w	d0083cfc <speech_synth_render+0x4d0>
d00845ca:	9b03      	ldr	r3, [sp, #12]
d00845cc:	f44f 75f0 	mov.w	r5, #480	; 0x1e0
d00845d0:	2b41      	cmp	r3, #65	; 0x41
d00845d2:	f63f ab7c 	bhi.w	d0083cce <speech_synth_render+0x4a2>
d00845d6:	4619      	mov	r1, r3
d00845d8:	f5a5 73aa 	sub.w	r3, r5, #340	; 0x154
d00845dc:	4a2d      	ldr	r2, [pc, #180]	; (d0084694 <speech_synth_render+0xe68>)
d00845de:	fb01 f303 	mul.w	r3, r1, r3
d00845e2:	fba2 2303 	umull	r2, r3, r2, r3
d00845e6:	eba5 1513 	sub.w	r5, r5, r3, lsr #4
d00845ea:	b2ad      	uxth	r5, r5
d00845ec:	f7ff bb81 	b.w	d0083cf2 <speech_synth_render+0x4c6>
d00845f0:	4b29      	ldr	r3, [pc, #164]	; (d0084698 <speech_synth_render+0xe6c>)
d00845f2:	f813 3022 	ldrb.w	r3, [r3, r2, lsl #2]
d00845f6:	9308      	str	r3, [sp, #32]
d00845f8:	f7ff ba01 	b.w	d00839fe <speech_synth_render+0x1d2>
d00845fc:	4b26      	ldr	r3, [pc, #152]	; (d0084698 <speech_synth_render+0xe6c>)
d00845fe:	781c      	ldrb	r4, [r3, #0]
d0084600:	f7ff b9f5 	b.w	d00839ee <speech_synth_render+0x1c2>
d0084604:	f44f 737a 	mov.w	r3, #1000	; 0x3e8
d0084608:	4d24      	ldr	r5, [pc, #144]	; (d008469c <speech_synth_render+0xe70>)
d008460a:	eb01 0141 	add.w	r1, r1, r1, lsl #1
d008460e:	f04f 0c5f 	mov.w	ip, #95	; 0x5f
d0084612:	9314      	str	r3, [sp, #80]	; 0x50
d0084614:	0842      	lsrs	r2, r0, #1
d0084616:	fba5 3508 	umull	r3, r5, r5, r8
d008461a:	088b      	lsrs	r3, r1, #2
d008461c:	27a0      	movs	r7, #160	; 0xa0
d008461e:	f44f 7682 	mov.w	r6, #260	; 0x104
d0084622:	931a      	str	r3, [sp, #104]	; 0x68
d0084624:	eb02 03db 	add.w	r3, r2, fp, lsr #3
d0084628:	08ed      	lsrs	r5, r5, #3
d008462a:	f44f 7ef0 	mov.w	lr, #480	; 0x1e0
d008462e:	930f      	str	r3, [sp, #60]	; 0x3c
d0084630:	f44f 53e1 	mov.w	r3, #7200	; 0x1c20
d0084634:	9313      	str	r3, [sp, #76]	; 0x4c
d0084636:	eb05 03d0 	add.w	r3, r5, r0, lsr #3
d008463a:	9319      	str	r3, [sp, #100]	; 0x64
d008463c:	f44f 7334 	mov.w	r3, #720	; 0x2d0
d0084640:	930e      	str	r3, [sp, #56]	; 0x38
d0084642:	f241 235c 	movw	r3, #4700	; 0x125c
d0084646:	930d      	str	r3, [sp, #52]	; 0x34
d0084648:	e62a      	b.n	d00842a0 <speech_synth_render+0xa74>
d008464a:	221e      	movs	r2, #30
d008464c:	2501      	movs	r5, #1
d008464e:	9201      	str	r2, [sp, #4]
d0084650:	f7ff ba10 	b.w	d0083a74 <speech_synth_render+0x248>
d0084654:	f856 0027 	ldr.w	r0, [r6, r7, lsl #2]
d0084658:	f10d 01c6 	add.w	r1, sp, #198	; 0xc6
d008465c:	f7fd fe32 	bl	d00822c4 <emit_rule_word.constprop.0>
d0084660:	210e      	movs	r1, #14
d0084662:	f10d 00c6 	add.w	r0, sp, #198	; 0xc6
d0084666:	f7fb fd5b 	bl	d0080120 <emit_pause.constprop.0>
d008466a:	f7ff b931 	b.w	d00838d0 <speech_synth_render+0xa4>
d008466e:	9105      	str	r1, [sp, #20]
d0084670:	e79b      	b.n	d00845aa <speech_synth_render+0xd7e>
d0084672:	bf00      	nop
d0084674:	66666667 	.word	0x66666667
d0084678:	d0085c94 	.word	0xd0085c94
d008467c:	d00c7f44 	.word	0xd00c7f44
d0084680:	d00c80c8 	.word	0xd00c80c8
d0084684:	00040997 	.word	0x00040997
d0084688:	d00875a0 	.word	0xd00875a0
d008468c:	d00c7f38 	.word	0xd00c7f38
d0084690:	d0085bcc 	.word	0xd0085bcc
d0084694:	3e0f83e1 	.word	0x3e0f83e1
d0084698:	d0086188 	.word	0xd0086188
d008469c:	cccccccd 	.word	0xcccccccd

d00846a0 <speech_synth_samples>:
d00846a0:	4800      	ldr	r0, [pc, #0]	; (d00846a4 <speech_synth_samples+0x4>)
d00846a2:	4770      	bx	lr
d00846a4:	d00875a0 	.word	0xd00875a0

d00846a8 <play_speech>:
d00846a8:	b530      	push	{r4, r5, lr}
d00846aa:	4c39      	ldr	r4, [pc, #228]	; (d0084790 <play_speech+0xe8>)
d00846ac:	b083      	sub	sp, #12
d00846ae:	4602      	mov	r2, r0
d00846b0:	2000      	movs	r0, #0
d00846b2:	7d23      	ldrb	r3, [r4, #20]
d00846b4:	7d61      	ldrb	r1, [r4, #21]
d00846b6:	7da5      	ldrb	r5, [r4, #22]
d00846b8:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d00846bc:	7de1      	ldrb	r1, [r4, #23]
d00846be:	9201      	str	r2, [sp, #4]
d00846c0:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d00846c4:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00846c8:	689b      	ldr	r3, [r3, #8]
d00846ca:	689b      	ldr	r3, [r3, #8]
d00846cc:	4798      	blx	r3
d00846ce:	7d23      	ldrb	r3, [r4, #20]
d00846d0:	7d61      	ldrb	r1, [r4, #21]
d00846d2:	7da0      	ldrb	r0, [r4, #22]
d00846d4:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d00846d8:	7de1      	ldrb	r1, [r4, #23]
d00846da:	ea43 4300 	orr.w	r3, r3, r0, lsl #16
d00846de:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00846e2:	689b      	ldr	r3, [r3, #8]
d00846e4:	68dd      	ldr	r5, [r3, #12]
d00846e6:	f7ff ffdb 	bl	d00846a0 <speech_synth_samples>
d00846ea:	2300      	movs	r3, #0
d00846ec:	4601      	mov	r1, r0
d00846ee:	9a01      	ldr	r2, [sp, #4]
d00846f0:	4618      	mov	r0, r3
d00846f2:	47a8      	blx	r5
d00846f4:	7d23      	ldrb	r3, [r4, #20]
d00846f6:	7d62      	ldrb	r2, [r4, #21]
d00846f8:	f245 6122 	movw	r1, #22050	; 0x5622
d00846fc:	7da5      	ldrb	r5, [r4, #22]
d00846fe:	2000      	movs	r0, #0
d0084700:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0084704:	7de2      	ldrb	r2, [r4, #23]
d0084706:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d008470a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008470e:	689b      	ldr	r3, [r3, #8]
d0084710:	691b      	ldr	r3, [r3, #16]
d0084712:	4798      	blx	r3
d0084714:	7d23      	ldrb	r3, [r4, #20]
d0084716:	7d62      	ldrb	r2, [r4, #21]
d0084718:	21ff      	movs	r1, #255	; 0xff
d008471a:	7da5      	ldrb	r5, [r4, #22]
d008471c:	2000      	movs	r0, #0
d008471e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0084722:	7de2      	ldrb	r2, [r4, #23]
d0084724:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0084728:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008472c:	689b      	ldr	r3, [r3, #8]
d008472e:	695b      	ldr	r3, [r3, #20]
d0084730:	4798      	blx	r3
d0084732:	7d23      	ldrb	r3, [r4, #20]
d0084734:	7d62      	ldrb	r2, [r4, #21]
d0084736:	2100      	movs	r1, #0
d0084738:	7da5      	ldrb	r5, [r4, #22]
d008473a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008473e:	7de2      	ldrb	r2, [r4, #23]
d0084740:	4608      	mov	r0, r1
d0084742:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0084746:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008474a:	689b      	ldr	r3, [r3, #8]
d008474c:	699b      	ldr	r3, [r3, #24]
d008474e:	4798      	blx	r3
d0084750:	7d23      	ldrb	r3, [r4, #20]
d0084752:	7d62      	ldrb	r2, [r4, #21]
d0084754:	2100      	movs	r1, #0
d0084756:	7da5      	ldrb	r5, [r4, #22]
d0084758:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008475c:	7de2      	ldrb	r2, [r4, #23]
d008475e:	4608      	mov	r0, r1
d0084760:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0084764:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0084768:	689b      	ldr	r3, [r3, #8]
d008476a:	6a1b      	ldr	r3, [r3, #32]
d008476c:	4798      	blx	r3
d008476e:	7d23      	ldrb	r3, [r4, #20]
d0084770:	7d62      	ldrb	r2, [r4, #21]
d0084772:	2000      	movs	r0, #0
d0084774:	7da1      	ldrb	r1, [r4, #22]
d0084776:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008477a:	7de2      	ldrb	r2, [r4, #23]
d008477c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0084780:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0084784:	689b      	ldr	r3, [r3, #8]
d0084786:	685b      	ldr	r3, [r3, #4]
d0084788:	b003      	add	sp, #12
d008478a:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d008478e:	4718      	bx	r3
d0084790:	2001f000 	.word	0x2001f000

d0084794 <main>:
d0084794:	b5f0      	push	{r4, r5, r6, r7, lr}
d0084796:	4c8b      	ldr	r4, [pc, #556]	; (d00849c4 <main+0x230>)
d0084798:	b097      	sub	sp, #92	; 0x5c
d008479a:	4606      	mov	r6, r0
d008479c:	f44f 2000 	mov.w	r0, #524288	; 0x80000
d00847a0:	7823      	ldrb	r3, [r4, #0]
d00847a2:	460d      	mov	r5, r1
d00847a4:	7862      	ldrb	r2, [r4, #1]
d00847a6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00847aa:	78a2      	ldrb	r2, [r4, #2]
d00847ac:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00847b0:	78e2      	ldrb	r2, [r4, #3]
d00847b2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00847b6:	681b      	ldr	r3, [r3, #0]
d00847b8:	4798      	blx	r3
d00847ba:	f7fb fc3f 	bl	d008003c <initMalloc>
d00847be:	7d23      	ldrb	r3, [r4, #20]
d00847c0:	7d62      	ldrb	r2, [r4, #21]
d00847c2:	2040      	movs	r0, #64	; 0x40
d00847c4:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00847c8:	7da2      	ldrb	r2, [r4, #22]
d00847ca:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00847ce:	7de2      	ldrb	r2, [r4, #23]
d00847d0:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00847d4:	681b      	ldr	r3, [r3, #0]
d00847d6:	681b      	ldr	r3, [r3, #0]
d00847d8:	4798      	blx	r3
d00847da:	7d23      	ldrb	r3, [r4, #20]
d00847dc:	7d61      	ldrb	r1, [r4, #21]
d00847de:	2201      	movs	r2, #1
d00847e0:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d00847e4:	7da1      	ldrb	r1, [r4, #22]
d00847e6:	4296      	cmp	r6, r2
d00847e8:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00847ec:	7de1      	ldrb	r1, [r4, #23]
d00847ee:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00847f2:	681b      	ldr	r3, [r3, #0]
d00847f4:	685b      	ldr	r3, [r3, #4]
d00847f6:	701a      	strb	r2, [r3, #0]
d00847f8:	f340 80dd 	ble.w	d00849b6 <main+0x222>
d00847fc:	686b      	ldr	r3, [r5, #4]
d00847fe:	4f72      	ldr	r7, [pc, #456]	; (d00849c8 <main+0x234>)
d0084800:	603b      	str	r3, [r7, #0]
d0084802:	6838      	ldr	r0, [r7, #0]
d0084804:	f7ff f812 	bl	d008382c <speech_synth_render>
d0084808:	7f23      	ldrb	r3, [r4, #28]
d008480a:	7f61      	ldrb	r1, [r4, #29]
d008480c:	4606      	mov	r6, r0
d008480e:	7fa2      	ldrb	r2, [r4, #30]
d0084810:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
d0084814:	7fe3      	ldrb	r3, [r4, #31]
d0084816:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008481a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d008481e:	685b      	ldr	r3, [r3, #4]
d0084820:	4798      	blx	r3
d0084822:	7f25      	ldrb	r5, [r4, #28]
d0084824:	7f61      	ldrb	r1, [r4, #29]
d0084826:	2001      	movs	r0, #1
d0084828:	7fa2      	ldrb	r2, [r4, #30]
d008482a:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d008482e:	7fe3      	ldrb	r3, [r4, #31]
d0084830:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0084834:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0084838:	691b      	ldr	r3, [r3, #16]
d008483a:	4798      	blx	r3
d008483c:	7f25      	ldrb	r5, [r4, #28]
d008483e:	7f61      	ldrb	r1, [r4, #29]
d0084840:	2000      	movs	r0, #0
d0084842:	7fa2      	ldrb	r2, [r4, #30]
d0084844:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d0084848:	7fe3      	ldrb	r3, [r4, #31]
d008484a:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008484e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0084852:	6a1b      	ldr	r3, [r3, #32]
d0084854:	4798      	blx	r3
d0084856:	f894 c01c 	ldrb.w	ip, [r4, #28]
d008485a:	7f62      	ldrb	r2, [r4, #29]
d008485c:	230d      	movs	r3, #13
d008485e:	7fa0      	ldrb	r0, [r4, #30]
d0084860:	2112      	movs	r1, #18
d0084862:	ea4c 2202 	orr.w	r2, ip, r2, lsl #8
d0084866:	7fe5      	ldrb	r5, [r4, #31]
d0084868:	ea42 4000 	orr.w	r0, r2, r0, lsl #16
d008486c:	4a57      	ldr	r2, [pc, #348]	; (d00849cc <main+0x238>)
d008486e:	ea40 6505 	orr.w	r5, r0, r5, lsl #24
d0084872:	200c      	movs	r0, #12
d0084874:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d0084876:	47a8      	blx	r5
d0084878:	f894 c01c 	ldrb.w	ip, [r4, #28]
d008487c:	7f62      	ldrb	r2, [r4, #29]
d008487e:	2307      	movs	r3, #7
d0084880:	7fa0      	ldrb	r0, [r4, #30]
d0084882:	212a      	movs	r1, #42	; 0x2a
d0084884:	ea4c 2202 	orr.w	r2, ip, r2, lsl #8
d0084888:	7fe5      	ldrb	r5, [r4, #31]
d008488a:	ea42 4000 	orr.w	r0, r2, r0, lsl #16
d008488e:	4a50      	ldr	r2, [pc, #320]	; (d00849d0 <main+0x23c>)
d0084890:	ea40 6505 	orr.w	r5, r0, r5, lsl #24
d0084894:	200c      	movs	r0, #12
d0084896:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d0084898:	47a8      	blx	r5
d008489a:	7f22      	ldrb	r2, [r4, #28]
d008489c:	7f60      	ldrb	r0, [r4, #29]
d008489e:	230e      	movs	r3, #14
d00848a0:	f894 c01e 	ldrb.w	ip, [r4, #30]
d00848a4:	2142      	movs	r1, #66	; 0x42
d00848a6:	ea42 2000 	orr.w	r0, r2, r0, lsl #8
d00848aa:	7fe5      	ldrb	r5, [r4, #31]
d00848ac:	683a      	ldr	r2, [r7, #0]
d00848ae:	ea40 470c 	orr.w	r7, r0, ip, lsl #16
d00848b2:	200c      	movs	r0, #12
d00848b4:	ea47 6505 	orr.w	r5, r7, r5, lsl #24
d00848b8:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d00848ba:	47a8      	blx	r5
d00848bc:	f245 6222 	movw	r2, #22050	; 0x5622
d00848c0:	4633      	mov	r3, r6
d00848c2:	2150      	movs	r1, #80	; 0x50
d00848c4:	9200      	str	r2, [sp, #0]
d00848c6:	a802      	add	r0, sp, #8
d00848c8:	4a42      	ldr	r2, [pc, #264]	; (d00849d4 <main+0x240>)
d00848ca:	f000 fa15 	bl	d0084cf8 <sniprintf>
d00848ce:	7f21      	ldrb	r1, [r4, #28]
d00848d0:	f894 c01d 	ldrb.w	ip, [r4, #29]
d00848d4:	230c      	movs	r3, #12
d00848d6:	7fa7      	ldrb	r7, [r4, #30]
d00848d8:	aa02      	add	r2, sp, #8
d00848da:	ea41 2c0c 	orr.w	ip, r1, ip, lsl #8
d00848de:	7fe5      	ldrb	r5, [r4, #31]
d00848e0:	4618      	mov	r0, r3
d00848e2:	2168      	movs	r1, #104	; 0x68
d00848e4:	ea4c 4707 	orr.w	r7, ip, r7, lsl #16
d00848e8:	ea47 6505 	orr.w	r5, r7, r5, lsl #24
d00848ec:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d00848ee:	47a8      	blx	r5
d00848f0:	7f22      	ldrb	r2, [r4, #28]
d00848f2:	f894 c01d 	ldrb.w	ip, [r4, #29]
d00848f6:	230f      	movs	r3, #15
d00848f8:	7fa7      	ldrb	r7, [r4, #30]
d00848fa:	2180      	movs	r1, #128	; 0x80
d00848fc:	ea42 2c0c 	orr.w	ip, r2, ip, lsl #8
d0084900:	7fe5      	ldrb	r5, [r4, #31]
d0084902:	4a35      	ldr	r2, [pc, #212]	; (d00849d8 <main+0x244>)
d0084904:	200c      	movs	r0, #12
d0084906:	ea4c 4707 	orr.w	r7, ip, r7, lsl #16
d008490a:	ea47 6505 	orr.w	r5, r7, r5, lsl #24
d008490e:	6aed      	ldr	r5, [r5, #44]	; 0x2c
d0084910:	47a8      	blx	r5
d0084912:	7f20      	ldrb	r0, [r4, #28]
d0084914:	7f61      	ldrb	r1, [r4, #29]
d0084916:	7fa2      	ldrb	r2, [r4, #30]
d0084918:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d008491c:	7fe3      	ldrb	r3, [r4, #31]
d008491e:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0084922:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0084926:	6b1b      	ldr	r3, [r3, #48]	; 0x30
d0084928:	4798      	blx	r3
d008492a:	4630      	mov	r0, r6
d008492c:	f7ff febc 	bl	d00846a8 <play_speech>
d0084930:	7820      	ldrb	r0, [r4, #0]
d0084932:	7861      	ldrb	r1, [r4, #1]
d0084934:	78a2      	ldrb	r2, [r4, #2]
d0084936:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d008493a:	78e3      	ldrb	r3, [r4, #3]
d008493c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0084940:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0084944:	6a1b      	ldr	r3, [r3, #32]
d0084946:	4798      	blx	r3
d0084948:	7d23      	ldrb	r3, [r4, #20]
d008494a:	7d61      	ldrb	r1, [r4, #21]
d008494c:	4607      	mov	r7, r0
d008494e:	7da2      	ldrb	r2, [r4, #22]
d0084950:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
d0084954:	7de3      	ldrb	r3, [r4, #23]
d0084956:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008495a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d008495e:	685b      	ldr	r3, [r3, #4]
d0084960:	685b      	ldr	r3, [r3, #4]
d0084962:	4798      	blx	r3
d0084964:	7a25      	ldrb	r5, [r4, #8]
d0084966:	7a61      	ldrb	r1, [r4, #9]
d0084968:	7aa2      	ldrb	r2, [r4, #10]
d008496a:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d008496e:	7ae3      	ldrb	r3, [r4, #11]
d0084970:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0084974:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0084978:	689b      	ldr	r3, [r3, #8]
d008497a:	4798      	blx	r3
d008497c:	7f25      	ldrb	r5, [r4, #28]
d008497e:	7f61      	ldrb	r1, [r4, #29]
d0084980:	7fa2      	ldrb	r2, [r4, #30]
d0084982:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d0084986:	7fe3      	ldrb	r3, [r4, #31]
d0084988:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d008498c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0084990:	699b      	ldr	r3, [r3, #24]
d0084992:	4798      	blx	r3
d0084994:	07fb      	lsls	r3, r7, #31
d0084996:	d410      	bmi.n	d00849ba <main+0x226>
d0084998:	7823      	ldrb	r3, [r4, #0]
d008499a:	7862      	ldrb	r2, [r4, #1]
d008499c:	78a1      	ldrb	r1, [r4, #2]
d008499e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00849a2:	78e2      	ldrb	r2, [r4, #3]
d00849a4:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00849a8:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00849ac:	685b      	ldr	r3, [r3, #4]
d00849ae:	4798      	blx	r3
d00849b0:	2000      	movs	r0, #0
d00849b2:	b017      	add	sp, #92	; 0x5c
d00849b4:	bdf0      	pop	{r4, r5, r6, r7, pc}
d00849b6:	4f04      	ldr	r7, [pc, #16]	; (d00849c8 <main+0x234>)
d00849b8:	e723      	b.n	d0084802 <main+0x6e>
d00849ba:	4630      	mov	r0, r6
d00849bc:	f7ff fe74 	bl	d00846a8 <play_speech>
d00849c0:	e7ea      	b.n	d0084998 <main+0x204>
d00849c2:	bf00      	nop
d00849c4:	2001f000 	.word	0x2001f000
d00849c8:	d0086110 	.word	0xd0086110
d00849cc:	d0085fb4 	.word	0xd0085fb4
d00849d0:	d0085fc4 	.word	0xd0085fc4
d00849d4:	d0085fdc 	.word	0xd0085fdc
d00849d8:	d0085ff4 	.word	0xd0085ff4

d00849dc <__errno>:
d00849dc:	4b01      	ldr	r3, [pc, #4]	; (d00849e4 <__errno+0x8>)
d00849de:	6818      	ldr	r0, [r3, #0]
d00849e0:	4770      	bx	lr
d00849e2:	bf00      	nop
d00849e4:	d0086114 	.word	0xd0086114

d00849e8 <malloc>:
d00849e8:	4b02      	ldr	r3, [pc, #8]	; (d00849f4 <malloc+0xc>)
d00849ea:	4601      	mov	r1, r0
d00849ec:	6818      	ldr	r0, [r3, #0]
d00849ee:	f000 b85b 	b.w	d0084aa8 <_malloc_r>
d00849f2:	bf00      	nop
d00849f4:	d0086114 	.word	0xd0086114

d00849f8 <memset>:
d00849f8:	4402      	add	r2, r0
d00849fa:	4603      	mov	r3, r0
d00849fc:	4293      	cmp	r3, r2
d00849fe:	d100      	bne.n	d0084a02 <memset+0xa>
d0084a00:	4770      	bx	lr
d0084a02:	f803 1b01 	strb.w	r1, [r3], #1
d0084a06:	e7f9      	b.n	d00849fc <memset+0x4>

d0084a08 <_free_r>:
d0084a08:	b537      	push	{r0, r1, r2, r4, r5, lr}
d0084a0a:	2900      	cmp	r1, #0
d0084a0c:	d048      	beq.n	d0084aa0 <_free_r+0x98>
d0084a0e:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0084a12:	9001      	str	r0, [sp, #4]
d0084a14:	2b00      	cmp	r3, #0
d0084a16:	f1a1 0404 	sub.w	r4, r1, #4
d0084a1a:	bfb8      	it	lt
d0084a1c:	18e4      	addlt	r4, r4, r3
d0084a1e:	f000 fb8f 	bl	d0085140 <__malloc_lock>
d0084a22:	4a20      	ldr	r2, [pc, #128]	; (d0084aa4 <_free_r+0x9c>)
d0084a24:	9801      	ldr	r0, [sp, #4]
d0084a26:	6813      	ldr	r3, [r2, #0]
d0084a28:	4615      	mov	r5, r2
d0084a2a:	b933      	cbnz	r3, d0084a3a <_free_r+0x32>
d0084a2c:	6063      	str	r3, [r4, #4]
d0084a2e:	6014      	str	r4, [r2, #0]
d0084a30:	b003      	add	sp, #12
d0084a32:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d0084a36:	f000 bb89 	b.w	d008514c <__malloc_unlock>
d0084a3a:	42a3      	cmp	r3, r4
d0084a3c:	d90b      	bls.n	d0084a56 <_free_r+0x4e>
d0084a3e:	6821      	ldr	r1, [r4, #0]
d0084a40:	1862      	adds	r2, r4, r1
d0084a42:	4293      	cmp	r3, r2
d0084a44:	bf04      	itt	eq
d0084a46:	681a      	ldreq	r2, [r3, #0]
d0084a48:	685b      	ldreq	r3, [r3, #4]
d0084a4a:	6063      	str	r3, [r4, #4]
d0084a4c:	bf04      	itt	eq
d0084a4e:	1852      	addeq	r2, r2, r1
d0084a50:	6022      	streq	r2, [r4, #0]
d0084a52:	602c      	str	r4, [r5, #0]
d0084a54:	e7ec      	b.n	d0084a30 <_free_r+0x28>
d0084a56:	461a      	mov	r2, r3
d0084a58:	685b      	ldr	r3, [r3, #4]
d0084a5a:	b10b      	cbz	r3, d0084a60 <_free_r+0x58>
d0084a5c:	42a3      	cmp	r3, r4
d0084a5e:	d9fa      	bls.n	d0084a56 <_free_r+0x4e>
d0084a60:	6811      	ldr	r1, [r2, #0]
d0084a62:	1855      	adds	r5, r2, r1
d0084a64:	42a5      	cmp	r5, r4
d0084a66:	d10b      	bne.n	d0084a80 <_free_r+0x78>
d0084a68:	6824      	ldr	r4, [r4, #0]
d0084a6a:	4421      	add	r1, r4
d0084a6c:	1854      	adds	r4, r2, r1
d0084a6e:	42a3      	cmp	r3, r4
d0084a70:	6011      	str	r1, [r2, #0]
d0084a72:	d1dd      	bne.n	d0084a30 <_free_r+0x28>
d0084a74:	681c      	ldr	r4, [r3, #0]
d0084a76:	685b      	ldr	r3, [r3, #4]
d0084a78:	6053      	str	r3, [r2, #4]
d0084a7a:	4421      	add	r1, r4
d0084a7c:	6011      	str	r1, [r2, #0]
d0084a7e:	e7d7      	b.n	d0084a30 <_free_r+0x28>
d0084a80:	d902      	bls.n	d0084a88 <_free_r+0x80>
d0084a82:	230c      	movs	r3, #12
d0084a84:	6003      	str	r3, [r0, #0]
d0084a86:	e7d3      	b.n	d0084a30 <_free_r+0x28>
d0084a88:	6825      	ldr	r5, [r4, #0]
d0084a8a:	1961      	adds	r1, r4, r5
d0084a8c:	428b      	cmp	r3, r1
d0084a8e:	bf04      	itt	eq
d0084a90:	6819      	ldreq	r1, [r3, #0]
d0084a92:	685b      	ldreq	r3, [r3, #4]
d0084a94:	6063      	str	r3, [r4, #4]
d0084a96:	bf04      	itt	eq
d0084a98:	1949      	addeq	r1, r1, r5
d0084a9a:	6021      	streq	r1, [r4, #0]
d0084a9c:	6054      	str	r4, [r2, #4]
d0084a9e:	e7c7      	b.n	d0084a30 <_free_r+0x28>
d0084aa0:	b003      	add	sp, #12
d0084aa2:	bd30      	pop	{r4, r5, pc}
d0084aa4:	d00c826c 	.word	0xd00c826c

d0084aa8 <_malloc_r>:
d0084aa8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0084aaa:	1ccd      	adds	r5, r1, #3
d0084aac:	f025 0503 	bic.w	r5, r5, #3
d0084ab0:	3508      	adds	r5, #8
d0084ab2:	2d0c      	cmp	r5, #12
d0084ab4:	bf38      	it	cc
d0084ab6:	250c      	movcc	r5, #12
d0084ab8:	2d00      	cmp	r5, #0
d0084aba:	4606      	mov	r6, r0
d0084abc:	db01      	blt.n	d0084ac2 <_malloc_r+0x1a>
d0084abe:	42a9      	cmp	r1, r5
d0084ac0:	d903      	bls.n	d0084aca <_malloc_r+0x22>
d0084ac2:	230c      	movs	r3, #12
d0084ac4:	6033      	str	r3, [r6, #0]
d0084ac6:	2000      	movs	r0, #0
d0084ac8:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0084aca:	f000 fb39 	bl	d0085140 <__malloc_lock>
d0084ace:	4921      	ldr	r1, [pc, #132]	; (d0084b54 <_malloc_r+0xac>)
d0084ad0:	680a      	ldr	r2, [r1, #0]
d0084ad2:	4614      	mov	r4, r2
d0084ad4:	b99c      	cbnz	r4, d0084afe <_malloc_r+0x56>
d0084ad6:	4f20      	ldr	r7, [pc, #128]	; (d0084b58 <_malloc_r+0xb0>)
d0084ad8:	683b      	ldr	r3, [r7, #0]
d0084ada:	b923      	cbnz	r3, d0084ae6 <_malloc_r+0x3e>
d0084adc:	4621      	mov	r1, r4
d0084ade:	4630      	mov	r0, r6
d0084ae0:	f7fb fafe 	bl	d00800e0 <_sbrk_r>
d0084ae4:	6038      	str	r0, [r7, #0]
d0084ae6:	4629      	mov	r1, r5
d0084ae8:	4630      	mov	r0, r6
d0084aea:	f7fb faf9 	bl	d00800e0 <_sbrk_r>
d0084aee:	1c43      	adds	r3, r0, #1
d0084af0:	d123      	bne.n	d0084b3a <_malloc_r+0x92>
d0084af2:	230c      	movs	r3, #12
d0084af4:	6033      	str	r3, [r6, #0]
d0084af6:	4630      	mov	r0, r6
d0084af8:	f000 fb28 	bl	d008514c <__malloc_unlock>
d0084afc:	e7e3      	b.n	d0084ac6 <_malloc_r+0x1e>
d0084afe:	6823      	ldr	r3, [r4, #0]
d0084b00:	1b5b      	subs	r3, r3, r5
d0084b02:	d417      	bmi.n	d0084b34 <_malloc_r+0x8c>
d0084b04:	2b0b      	cmp	r3, #11
d0084b06:	d903      	bls.n	d0084b10 <_malloc_r+0x68>
d0084b08:	6023      	str	r3, [r4, #0]
d0084b0a:	441c      	add	r4, r3
d0084b0c:	6025      	str	r5, [r4, #0]
d0084b0e:	e004      	b.n	d0084b1a <_malloc_r+0x72>
d0084b10:	6863      	ldr	r3, [r4, #4]
d0084b12:	42a2      	cmp	r2, r4
d0084b14:	bf0c      	ite	eq
d0084b16:	600b      	streq	r3, [r1, #0]
d0084b18:	6053      	strne	r3, [r2, #4]
d0084b1a:	4630      	mov	r0, r6
d0084b1c:	f000 fb16 	bl	d008514c <__malloc_unlock>
d0084b20:	f104 000b 	add.w	r0, r4, #11
d0084b24:	1d23      	adds	r3, r4, #4
d0084b26:	f020 0007 	bic.w	r0, r0, #7
d0084b2a:	1ac2      	subs	r2, r0, r3
d0084b2c:	d0cc      	beq.n	d0084ac8 <_malloc_r+0x20>
d0084b2e:	1a1b      	subs	r3, r3, r0
d0084b30:	50a3      	str	r3, [r4, r2]
d0084b32:	e7c9      	b.n	d0084ac8 <_malloc_r+0x20>
d0084b34:	4622      	mov	r2, r4
d0084b36:	6864      	ldr	r4, [r4, #4]
d0084b38:	e7cc      	b.n	d0084ad4 <_malloc_r+0x2c>
d0084b3a:	1cc4      	adds	r4, r0, #3
d0084b3c:	f024 0403 	bic.w	r4, r4, #3
d0084b40:	42a0      	cmp	r0, r4
d0084b42:	d0e3      	beq.n	d0084b0c <_malloc_r+0x64>
d0084b44:	1a21      	subs	r1, r4, r0
d0084b46:	4630      	mov	r0, r6
d0084b48:	f7fb faca 	bl	d00800e0 <_sbrk_r>
d0084b4c:	3001      	adds	r0, #1
d0084b4e:	d1dd      	bne.n	d0084b0c <_malloc_r+0x64>
d0084b50:	e7cf      	b.n	d0084af2 <_malloc_r+0x4a>
d0084b52:	bf00      	nop
d0084b54:	d00c826c 	.word	0xd00c826c
d0084b58:	d00c8270 	.word	0xd00c8270

d0084b5c <setbuf>:
d0084b5c:	2900      	cmp	r1, #0
d0084b5e:	f44f 6380 	mov.w	r3, #1024	; 0x400
d0084b62:	bf0c      	ite	eq
d0084b64:	2202      	moveq	r2, #2
d0084b66:	2200      	movne	r2, #0
d0084b68:	f000 b800 	b.w	d0084b6c <setvbuf>

d0084b6c <setvbuf>:
d0084b6c:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d0084b70:	461d      	mov	r5, r3
d0084b72:	4b5d      	ldr	r3, [pc, #372]	; (d0084ce8 <setvbuf+0x17c>)
d0084b74:	681f      	ldr	r7, [r3, #0]
d0084b76:	4604      	mov	r4, r0
d0084b78:	460e      	mov	r6, r1
d0084b7a:	4690      	mov	r8, r2
d0084b7c:	b127      	cbz	r7, d0084b88 <setvbuf+0x1c>
d0084b7e:	69bb      	ldr	r3, [r7, #24]
d0084b80:	b913      	cbnz	r3, d0084b88 <setvbuf+0x1c>
d0084b82:	4638      	mov	r0, r7
d0084b84:	f000 fa18 	bl	d0084fb8 <__sinit>
d0084b88:	4b58      	ldr	r3, [pc, #352]	; (d0084cec <setvbuf+0x180>)
d0084b8a:	429c      	cmp	r4, r3
d0084b8c:	d167      	bne.n	d0084c5e <setvbuf+0xf2>
d0084b8e:	687c      	ldr	r4, [r7, #4]
d0084b90:	f1b8 0f02 	cmp.w	r8, #2
d0084b94:	d006      	beq.n	d0084ba4 <setvbuf+0x38>
d0084b96:	f1b8 0f01 	cmp.w	r8, #1
d0084b9a:	f200 809f 	bhi.w	d0084cdc <setvbuf+0x170>
d0084b9e:	2d00      	cmp	r5, #0
d0084ba0:	f2c0 809c 	blt.w	d0084cdc <setvbuf+0x170>
d0084ba4:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0084ba6:	07db      	lsls	r3, r3, #31
d0084ba8:	d405      	bmi.n	d0084bb6 <setvbuf+0x4a>
d0084baa:	89a3      	ldrh	r3, [r4, #12]
d0084bac:	0598      	lsls	r0, r3, #22
d0084bae:	d402      	bmi.n	d0084bb6 <setvbuf+0x4a>
d0084bb0:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0084bb2:	f000 fa9f 	bl	d00850f4 <__retarget_lock_acquire_recursive>
d0084bb6:	4621      	mov	r1, r4
d0084bb8:	4638      	mov	r0, r7
d0084bba:	f000 f969 	bl	d0084e90 <_fflush_r>
d0084bbe:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0084bc0:	b141      	cbz	r1, d0084bd4 <setvbuf+0x68>
d0084bc2:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0084bc6:	4299      	cmp	r1, r3
d0084bc8:	d002      	beq.n	d0084bd0 <setvbuf+0x64>
d0084bca:	4638      	mov	r0, r7
d0084bcc:	f7ff ff1c 	bl	d0084a08 <_free_r>
d0084bd0:	2300      	movs	r3, #0
d0084bd2:	6363      	str	r3, [r4, #52]	; 0x34
d0084bd4:	2300      	movs	r3, #0
d0084bd6:	61a3      	str	r3, [r4, #24]
d0084bd8:	6063      	str	r3, [r4, #4]
d0084bda:	89a3      	ldrh	r3, [r4, #12]
d0084bdc:	0619      	lsls	r1, r3, #24
d0084bde:	d503      	bpl.n	d0084be8 <setvbuf+0x7c>
d0084be0:	6921      	ldr	r1, [r4, #16]
d0084be2:	4638      	mov	r0, r7
d0084be4:	f7ff ff10 	bl	d0084a08 <_free_r>
d0084be8:	89a3      	ldrh	r3, [r4, #12]
d0084bea:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d0084bee:	f023 0303 	bic.w	r3, r3, #3
d0084bf2:	f1b8 0f02 	cmp.w	r8, #2
d0084bf6:	81a3      	strh	r3, [r4, #12]
d0084bf8:	d06c      	beq.n	d0084cd4 <setvbuf+0x168>
d0084bfa:	ab01      	add	r3, sp, #4
d0084bfc:	466a      	mov	r2, sp
d0084bfe:	4621      	mov	r1, r4
d0084c00:	4638      	mov	r0, r7
d0084c02:	f000 fa79 	bl	d00850f8 <__swhatbuf_r>
d0084c06:	89a3      	ldrh	r3, [r4, #12]
d0084c08:	4318      	orrs	r0, r3
d0084c0a:	81a0      	strh	r0, [r4, #12]
d0084c0c:	2d00      	cmp	r5, #0
d0084c0e:	d130      	bne.n	d0084c72 <setvbuf+0x106>
d0084c10:	9d00      	ldr	r5, [sp, #0]
d0084c12:	4628      	mov	r0, r5
d0084c14:	f7ff fee8 	bl	d00849e8 <malloc>
d0084c18:	4606      	mov	r6, r0
d0084c1a:	2800      	cmp	r0, #0
d0084c1c:	d155      	bne.n	d0084cca <setvbuf+0x15e>
d0084c1e:	f8dd 9000 	ldr.w	r9, [sp]
d0084c22:	45a9      	cmp	r9, r5
d0084c24:	d14a      	bne.n	d0084cbc <setvbuf+0x150>
d0084c26:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0084c2a:	2200      	movs	r2, #0
d0084c2c:	60a2      	str	r2, [r4, #8]
d0084c2e:	f104 0247 	add.w	r2, r4, #71	; 0x47
d0084c32:	6022      	str	r2, [r4, #0]
d0084c34:	6122      	str	r2, [r4, #16]
d0084c36:	2201      	movs	r2, #1
d0084c38:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0084c3c:	6162      	str	r2, [r4, #20]
d0084c3e:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0084c40:	f043 0302 	orr.w	r3, r3, #2
d0084c44:	07d2      	lsls	r2, r2, #31
d0084c46:	81a3      	strh	r3, [r4, #12]
d0084c48:	d405      	bmi.n	d0084c56 <setvbuf+0xea>
d0084c4a:	f413 7f00 	tst.w	r3, #512	; 0x200
d0084c4e:	d102      	bne.n	d0084c56 <setvbuf+0xea>
d0084c50:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0084c52:	f000 fa50 	bl	d00850f6 <__retarget_lock_release_recursive>
d0084c56:	4628      	mov	r0, r5
d0084c58:	b003      	add	sp, #12
d0084c5a:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0084c5e:	4b24      	ldr	r3, [pc, #144]	; (d0084cf0 <setvbuf+0x184>)
d0084c60:	429c      	cmp	r4, r3
d0084c62:	d101      	bne.n	d0084c68 <setvbuf+0xfc>
d0084c64:	68bc      	ldr	r4, [r7, #8]
d0084c66:	e793      	b.n	d0084b90 <setvbuf+0x24>
d0084c68:	4b22      	ldr	r3, [pc, #136]	; (d0084cf4 <setvbuf+0x188>)
d0084c6a:	429c      	cmp	r4, r3
d0084c6c:	bf08      	it	eq
d0084c6e:	68fc      	ldreq	r4, [r7, #12]
d0084c70:	e78e      	b.n	d0084b90 <setvbuf+0x24>
d0084c72:	2e00      	cmp	r6, #0
d0084c74:	d0cd      	beq.n	d0084c12 <setvbuf+0xa6>
d0084c76:	69bb      	ldr	r3, [r7, #24]
d0084c78:	b913      	cbnz	r3, d0084c80 <setvbuf+0x114>
d0084c7a:	4638      	mov	r0, r7
d0084c7c:	f000 f99c 	bl	d0084fb8 <__sinit>
d0084c80:	f1b8 0f01 	cmp.w	r8, #1
d0084c84:	bf08      	it	eq
d0084c86:	89a3      	ldrheq	r3, [r4, #12]
d0084c88:	6026      	str	r6, [r4, #0]
d0084c8a:	bf04      	itt	eq
d0084c8c:	f043 0301 	orreq.w	r3, r3, #1
d0084c90:	81a3      	strheq	r3, [r4, #12]
d0084c92:	89a2      	ldrh	r2, [r4, #12]
d0084c94:	f012 0308 	ands.w	r3, r2, #8
d0084c98:	e9c4 6504 	strd	r6, r5, [r4, #16]
d0084c9c:	d01c      	beq.n	d0084cd8 <setvbuf+0x16c>
d0084c9e:	07d3      	lsls	r3, r2, #31
d0084ca0:	bf41      	itttt	mi
d0084ca2:	2300      	movmi	r3, #0
d0084ca4:	426d      	negmi	r5, r5
d0084ca6:	60a3      	strmi	r3, [r4, #8]
d0084ca8:	61a5      	strmi	r5, [r4, #24]
d0084caa:	bf58      	it	pl
d0084cac:	60a5      	strpl	r5, [r4, #8]
d0084cae:	6e65      	ldr	r5, [r4, #100]	; 0x64
d0084cb0:	f015 0501 	ands.w	r5, r5, #1
d0084cb4:	d115      	bne.n	d0084ce2 <setvbuf+0x176>
d0084cb6:	f412 7f00 	tst.w	r2, #512	; 0x200
d0084cba:	e7c8      	b.n	d0084c4e <setvbuf+0xe2>
d0084cbc:	4648      	mov	r0, r9
d0084cbe:	f7ff fe93 	bl	d00849e8 <malloc>
d0084cc2:	4606      	mov	r6, r0
d0084cc4:	2800      	cmp	r0, #0
d0084cc6:	d0ae      	beq.n	d0084c26 <setvbuf+0xba>
d0084cc8:	464d      	mov	r5, r9
d0084cca:	89a3      	ldrh	r3, [r4, #12]
d0084ccc:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0084cd0:	81a3      	strh	r3, [r4, #12]
d0084cd2:	e7d0      	b.n	d0084c76 <setvbuf+0x10a>
d0084cd4:	2500      	movs	r5, #0
d0084cd6:	e7a8      	b.n	d0084c2a <setvbuf+0xbe>
d0084cd8:	60a3      	str	r3, [r4, #8]
d0084cda:	e7e8      	b.n	d0084cae <setvbuf+0x142>
d0084cdc:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0084ce0:	e7b9      	b.n	d0084c56 <setvbuf+0xea>
d0084ce2:	2500      	movs	r5, #0
d0084ce4:	e7b7      	b.n	d0084c56 <setvbuf+0xea>
d0084ce6:	bf00      	nop
d0084ce8:	d0086114 	.word	0xd0086114
d0084cec:	d0086094 	.word	0xd0086094
d0084cf0:	d00860b4 	.word	0xd00860b4
d0084cf4:	d0086074 	.word	0xd0086074

d0084cf8 <sniprintf>:
d0084cf8:	b40c      	push	{r2, r3}
d0084cfa:	b530      	push	{r4, r5, lr}
d0084cfc:	4b17      	ldr	r3, [pc, #92]	; (d0084d5c <sniprintf+0x64>)
d0084cfe:	1e0c      	subs	r4, r1, #0
d0084d00:	681d      	ldr	r5, [r3, #0]
d0084d02:	b09d      	sub	sp, #116	; 0x74
d0084d04:	da08      	bge.n	d0084d18 <sniprintf+0x20>
d0084d06:	238b      	movs	r3, #139	; 0x8b
d0084d08:	602b      	str	r3, [r5, #0]
d0084d0a:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0084d0e:	b01d      	add	sp, #116	; 0x74
d0084d10:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d0084d14:	b002      	add	sp, #8
d0084d16:	4770      	bx	lr
d0084d18:	f44f 7302 	mov.w	r3, #520	; 0x208
d0084d1c:	f8ad 3014 	strh.w	r3, [sp, #20]
d0084d20:	bf14      	ite	ne
d0084d22:	f104 33ff 	addne.w	r3, r4, #4294967295	; 0xffffffff
d0084d26:	4623      	moveq	r3, r4
d0084d28:	9304      	str	r3, [sp, #16]
d0084d2a:	9307      	str	r3, [sp, #28]
d0084d2c:	f64f 73ff 	movw	r3, #65535	; 0xffff
d0084d30:	9002      	str	r0, [sp, #8]
d0084d32:	9006      	str	r0, [sp, #24]
d0084d34:	f8ad 3016 	strh.w	r3, [sp, #22]
d0084d38:	9a20      	ldr	r2, [sp, #128]	; 0x80
d0084d3a:	ab21      	add	r3, sp, #132	; 0x84
d0084d3c:	a902      	add	r1, sp, #8
d0084d3e:	4628      	mov	r0, r5
d0084d40:	9301      	str	r3, [sp, #4]
d0084d42:	f000 fa65 	bl	d0085210 <_svfiprintf_r>
d0084d46:	1c43      	adds	r3, r0, #1
d0084d48:	bfbc      	itt	lt
d0084d4a:	238b      	movlt	r3, #139	; 0x8b
d0084d4c:	602b      	strlt	r3, [r5, #0]
d0084d4e:	2c00      	cmp	r4, #0
d0084d50:	d0dd      	beq.n	d0084d0e <sniprintf+0x16>
d0084d52:	9b02      	ldr	r3, [sp, #8]
d0084d54:	2200      	movs	r2, #0
d0084d56:	701a      	strb	r2, [r3, #0]
d0084d58:	e7d9      	b.n	d0084d0e <sniprintf+0x16>
d0084d5a:	bf00      	nop
d0084d5c:	d0086114 	.word	0xd0086114

d0084d60 <strcmp>:
d0084d60:	f810 2b01 	ldrb.w	r2, [r0], #1
d0084d64:	f811 3b01 	ldrb.w	r3, [r1], #1
d0084d68:	2a01      	cmp	r2, #1
d0084d6a:	bf28      	it	cs
d0084d6c:	429a      	cmpcs	r2, r3
d0084d6e:	d0f7      	beq.n	d0084d60 <strcmp>
d0084d70:	1ad0      	subs	r0, r2, r3
d0084d72:	4770      	bx	lr

d0084d74 <strlen>:
d0084d74:	4603      	mov	r3, r0
d0084d76:	f813 2b01 	ldrb.w	r2, [r3], #1
d0084d7a:	2a00      	cmp	r2, #0
d0084d7c:	d1fb      	bne.n	d0084d76 <strlen+0x2>
d0084d7e:	1a18      	subs	r0, r3, r0
d0084d80:	3801      	subs	r0, #1
d0084d82:	4770      	bx	lr

d0084d84 <__sflush_r>:
d0084d84:	898a      	ldrh	r2, [r1, #12]
d0084d86:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0084d8a:	4605      	mov	r5, r0
d0084d8c:	0710      	lsls	r0, r2, #28
d0084d8e:	460c      	mov	r4, r1
d0084d90:	d458      	bmi.n	d0084e44 <__sflush_r+0xc0>
d0084d92:	684b      	ldr	r3, [r1, #4]
d0084d94:	2b00      	cmp	r3, #0
d0084d96:	dc05      	bgt.n	d0084da4 <__sflush_r+0x20>
d0084d98:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d0084d9a:	2b00      	cmp	r3, #0
d0084d9c:	dc02      	bgt.n	d0084da4 <__sflush_r+0x20>
d0084d9e:	2000      	movs	r0, #0
d0084da0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0084da4:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0084da6:	2e00      	cmp	r6, #0
d0084da8:	d0f9      	beq.n	d0084d9e <__sflush_r+0x1a>
d0084daa:	2300      	movs	r3, #0
d0084dac:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d0084db0:	682f      	ldr	r7, [r5, #0]
d0084db2:	602b      	str	r3, [r5, #0]
d0084db4:	d032      	beq.n	d0084e1c <__sflush_r+0x98>
d0084db6:	6d60      	ldr	r0, [r4, #84]	; 0x54
d0084db8:	89a3      	ldrh	r3, [r4, #12]
d0084dba:	075a      	lsls	r2, r3, #29
d0084dbc:	d505      	bpl.n	d0084dca <__sflush_r+0x46>
d0084dbe:	6863      	ldr	r3, [r4, #4]
d0084dc0:	1ac0      	subs	r0, r0, r3
d0084dc2:	6b63      	ldr	r3, [r4, #52]	; 0x34
d0084dc4:	b10b      	cbz	r3, d0084dca <__sflush_r+0x46>
d0084dc6:	6c23      	ldr	r3, [r4, #64]	; 0x40
d0084dc8:	1ac0      	subs	r0, r0, r3
d0084dca:	2300      	movs	r3, #0
d0084dcc:	4602      	mov	r2, r0
d0084dce:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0084dd0:	6a21      	ldr	r1, [r4, #32]
d0084dd2:	4628      	mov	r0, r5
d0084dd4:	47b0      	blx	r6
d0084dd6:	1c43      	adds	r3, r0, #1
d0084dd8:	89a3      	ldrh	r3, [r4, #12]
d0084dda:	d106      	bne.n	d0084dea <__sflush_r+0x66>
d0084ddc:	6829      	ldr	r1, [r5, #0]
d0084dde:	291d      	cmp	r1, #29
d0084de0:	d82c      	bhi.n	d0084e3c <__sflush_r+0xb8>
d0084de2:	4a2a      	ldr	r2, [pc, #168]	; (d0084e8c <__sflush_r+0x108>)
d0084de4:	40ca      	lsrs	r2, r1
d0084de6:	07d6      	lsls	r6, r2, #31
d0084de8:	d528      	bpl.n	d0084e3c <__sflush_r+0xb8>
d0084dea:	2200      	movs	r2, #0
d0084dec:	6062      	str	r2, [r4, #4]
d0084dee:	04d9      	lsls	r1, r3, #19
d0084df0:	6922      	ldr	r2, [r4, #16]
d0084df2:	6022      	str	r2, [r4, #0]
d0084df4:	d504      	bpl.n	d0084e00 <__sflush_r+0x7c>
d0084df6:	1c42      	adds	r2, r0, #1
d0084df8:	d101      	bne.n	d0084dfe <__sflush_r+0x7a>
d0084dfa:	682b      	ldr	r3, [r5, #0]
d0084dfc:	b903      	cbnz	r3, d0084e00 <__sflush_r+0x7c>
d0084dfe:	6560      	str	r0, [r4, #84]	; 0x54
d0084e00:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0084e02:	602f      	str	r7, [r5, #0]
d0084e04:	2900      	cmp	r1, #0
d0084e06:	d0ca      	beq.n	d0084d9e <__sflush_r+0x1a>
d0084e08:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0084e0c:	4299      	cmp	r1, r3
d0084e0e:	d002      	beq.n	d0084e16 <__sflush_r+0x92>
d0084e10:	4628      	mov	r0, r5
d0084e12:	f7ff fdf9 	bl	d0084a08 <_free_r>
d0084e16:	2000      	movs	r0, #0
d0084e18:	6360      	str	r0, [r4, #52]	; 0x34
d0084e1a:	e7c1      	b.n	d0084da0 <__sflush_r+0x1c>
d0084e1c:	6a21      	ldr	r1, [r4, #32]
d0084e1e:	2301      	movs	r3, #1
d0084e20:	4628      	mov	r0, r5
d0084e22:	47b0      	blx	r6
d0084e24:	1c41      	adds	r1, r0, #1
d0084e26:	d1c7      	bne.n	d0084db8 <__sflush_r+0x34>
d0084e28:	682b      	ldr	r3, [r5, #0]
d0084e2a:	2b00      	cmp	r3, #0
d0084e2c:	d0c4      	beq.n	d0084db8 <__sflush_r+0x34>
d0084e2e:	2b1d      	cmp	r3, #29
d0084e30:	d001      	beq.n	d0084e36 <__sflush_r+0xb2>
d0084e32:	2b16      	cmp	r3, #22
d0084e34:	d101      	bne.n	d0084e3a <__sflush_r+0xb6>
d0084e36:	602f      	str	r7, [r5, #0]
d0084e38:	e7b1      	b.n	d0084d9e <__sflush_r+0x1a>
d0084e3a:	89a3      	ldrh	r3, [r4, #12]
d0084e3c:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0084e40:	81a3      	strh	r3, [r4, #12]
d0084e42:	e7ad      	b.n	d0084da0 <__sflush_r+0x1c>
d0084e44:	690f      	ldr	r7, [r1, #16]
d0084e46:	2f00      	cmp	r7, #0
d0084e48:	d0a9      	beq.n	d0084d9e <__sflush_r+0x1a>
d0084e4a:	0793      	lsls	r3, r2, #30
d0084e4c:	680e      	ldr	r6, [r1, #0]
d0084e4e:	bf08      	it	eq
d0084e50:	694b      	ldreq	r3, [r1, #20]
d0084e52:	600f      	str	r7, [r1, #0]
d0084e54:	bf18      	it	ne
d0084e56:	2300      	movne	r3, #0
d0084e58:	eba6 0807 	sub.w	r8, r6, r7
d0084e5c:	608b      	str	r3, [r1, #8]
d0084e5e:	f1b8 0f00 	cmp.w	r8, #0
d0084e62:	dd9c      	ble.n	d0084d9e <__sflush_r+0x1a>
d0084e64:	6a21      	ldr	r1, [r4, #32]
d0084e66:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d0084e68:	4643      	mov	r3, r8
d0084e6a:	463a      	mov	r2, r7
d0084e6c:	4628      	mov	r0, r5
d0084e6e:	47b0      	blx	r6
d0084e70:	2800      	cmp	r0, #0
d0084e72:	dc06      	bgt.n	d0084e82 <__sflush_r+0xfe>
d0084e74:	89a3      	ldrh	r3, [r4, #12]
d0084e76:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0084e7a:	81a3      	strh	r3, [r4, #12]
d0084e7c:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0084e80:	e78e      	b.n	d0084da0 <__sflush_r+0x1c>
d0084e82:	4407      	add	r7, r0
d0084e84:	eba8 0800 	sub.w	r8, r8, r0
d0084e88:	e7e9      	b.n	d0084e5e <__sflush_r+0xda>
d0084e8a:	bf00      	nop
d0084e8c:	20400001 	.word	0x20400001

d0084e90 <_fflush_r>:
d0084e90:	b538      	push	{r3, r4, r5, lr}
d0084e92:	690b      	ldr	r3, [r1, #16]
d0084e94:	4605      	mov	r5, r0
d0084e96:	460c      	mov	r4, r1
d0084e98:	b913      	cbnz	r3, d0084ea0 <_fflush_r+0x10>
d0084e9a:	2500      	movs	r5, #0
d0084e9c:	4628      	mov	r0, r5
d0084e9e:	bd38      	pop	{r3, r4, r5, pc}
d0084ea0:	b118      	cbz	r0, d0084eaa <_fflush_r+0x1a>
d0084ea2:	6983      	ldr	r3, [r0, #24]
d0084ea4:	b90b      	cbnz	r3, d0084eaa <_fflush_r+0x1a>
d0084ea6:	f000 f887 	bl	d0084fb8 <__sinit>
d0084eaa:	4b14      	ldr	r3, [pc, #80]	; (d0084efc <_fflush_r+0x6c>)
d0084eac:	429c      	cmp	r4, r3
d0084eae:	d11b      	bne.n	d0084ee8 <_fflush_r+0x58>
d0084eb0:	686c      	ldr	r4, [r5, #4]
d0084eb2:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0084eb6:	2b00      	cmp	r3, #0
d0084eb8:	d0ef      	beq.n	d0084e9a <_fflush_r+0xa>
d0084eba:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0084ebc:	07d0      	lsls	r0, r2, #31
d0084ebe:	d404      	bmi.n	d0084eca <_fflush_r+0x3a>
d0084ec0:	0599      	lsls	r1, r3, #22
d0084ec2:	d402      	bmi.n	d0084eca <_fflush_r+0x3a>
d0084ec4:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0084ec6:	f000 f915 	bl	d00850f4 <__retarget_lock_acquire_recursive>
d0084eca:	4628      	mov	r0, r5
d0084ecc:	4621      	mov	r1, r4
d0084ece:	f7ff ff59 	bl	d0084d84 <__sflush_r>
d0084ed2:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0084ed4:	07da      	lsls	r2, r3, #31
d0084ed6:	4605      	mov	r5, r0
d0084ed8:	d4e0      	bmi.n	d0084e9c <_fflush_r+0xc>
d0084eda:	89a3      	ldrh	r3, [r4, #12]
d0084edc:	059b      	lsls	r3, r3, #22
d0084ede:	d4dd      	bmi.n	d0084e9c <_fflush_r+0xc>
d0084ee0:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0084ee2:	f000 f908 	bl	d00850f6 <__retarget_lock_release_recursive>
d0084ee6:	e7d9      	b.n	d0084e9c <_fflush_r+0xc>
d0084ee8:	4b05      	ldr	r3, [pc, #20]	; (d0084f00 <_fflush_r+0x70>)
d0084eea:	429c      	cmp	r4, r3
d0084eec:	d101      	bne.n	d0084ef2 <_fflush_r+0x62>
d0084eee:	68ac      	ldr	r4, [r5, #8]
d0084ef0:	e7df      	b.n	d0084eb2 <_fflush_r+0x22>
d0084ef2:	4b04      	ldr	r3, [pc, #16]	; (d0084f04 <_fflush_r+0x74>)
d0084ef4:	429c      	cmp	r4, r3
d0084ef6:	bf08      	it	eq
d0084ef8:	68ec      	ldreq	r4, [r5, #12]
d0084efa:	e7da      	b.n	d0084eb2 <_fflush_r+0x22>
d0084efc:	d0086094 	.word	0xd0086094
d0084f00:	d00860b4 	.word	0xd00860b4
d0084f04:	d0086074 	.word	0xd0086074

d0084f08 <std>:
d0084f08:	2300      	movs	r3, #0
d0084f0a:	b510      	push	{r4, lr}
d0084f0c:	4604      	mov	r4, r0
d0084f0e:	e9c0 3300 	strd	r3, r3, [r0]
d0084f12:	e9c0 3304 	strd	r3, r3, [r0, #16]
d0084f16:	6083      	str	r3, [r0, #8]
d0084f18:	8181      	strh	r1, [r0, #12]
d0084f1a:	6643      	str	r3, [r0, #100]	; 0x64
d0084f1c:	81c2      	strh	r2, [r0, #14]
d0084f1e:	6183      	str	r3, [r0, #24]
d0084f20:	4619      	mov	r1, r3
d0084f22:	2208      	movs	r2, #8
d0084f24:	305c      	adds	r0, #92	; 0x5c
d0084f26:	f7ff fd67 	bl	d00849f8 <memset>
d0084f2a:	4b05      	ldr	r3, [pc, #20]	; (d0084f40 <std+0x38>)
d0084f2c:	6263      	str	r3, [r4, #36]	; 0x24
d0084f2e:	4b05      	ldr	r3, [pc, #20]	; (d0084f44 <std+0x3c>)
d0084f30:	62a3      	str	r3, [r4, #40]	; 0x28
d0084f32:	4b05      	ldr	r3, [pc, #20]	; (d0084f48 <std+0x40>)
d0084f34:	62e3      	str	r3, [r4, #44]	; 0x2c
d0084f36:	4b05      	ldr	r3, [pc, #20]	; (d0084f4c <std+0x44>)
d0084f38:	6224      	str	r4, [r4, #32]
d0084f3a:	6323      	str	r3, [r4, #48]	; 0x30
d0084f3c:	bd10      	pop	{r4, pc}
d0084f3e:	bf00      	nop
d0084f40:	d0085739 	.word	0xd0085739
d0084f44:	d008575b 	.word	0xd008575b
d0084f48:	d0085793 	.word	0xd0085793
d0084f4c:	d00857b7 	.word	0xd00857b7

d0084f50 <_cleanup_r>:
d0084f50:	4901      	ldr	r1, [pc, #4]	; (d0084f58 <_cleanup_r+0x8>)
d0084f52:	f000 b8af 	b.w	d00850b4 <_fwalk_reent>
d0084f56:	bf00      	nop
d0084f58:	d0084e91 	.word	0xd0084e91

d0084f5c <__sfmoreglue>:
d0084f5c:	b570      	push	{r4, r5, r6, lr}
d0084f5e:	1e4a      	subs	r2, r1, #1
d0084f60:	2568      	movs	r5, #104	; 0x68
d0084f62:	4355      	muls	r5, r2
d0084f64:	460e      	mov	r6, r1
d0084f66:	f105 0174 	add.w	r1, r5, #116	; 0x74
d0084f6a:	f7ff fd9d 	bl	d0084aa8 <_malloc_r>
d0084f6e:	4604      	mov	r4, r0
d0084f70:	b140      	cbz	r0, d0084f84 <__sfmoreglue+0x28>
d0084f72:	2100      	movs	r1, #0
d0084f74:	e9c0 1600 	strd	r1, r6, [r0]
d0084f78:	300c      	adds	r0, #12
d0084f7a:	60a0      	str	r0, [r4, #8]
d0084f7c:	f105 0268 	add.w	r2, r5, #104	; 0x68
d0084f80:	f7ff fd3a 	bl	d00849f8 <memset>
d0084f84:	4620      	mov	r0, r4
d0084f86:	bd70      	pop	{r4, r5, r6, pc}

d0084f88 <__sfp_lock_acquire>:
d0084f88:	4801      	ldr	r0, [pc, #4]	; (d0084f90 <__sfp_lock_acquire+0x8>)
d0084f8a:	f000 b8b3 	b.w	d00850f4 <__retarget_lock_acquire_recursive>
d0084f8e:	bf00      	nop
d0084f90:	d00c8280 	.word	0xd00c8280

d0084f94 <__sfp_lock_release>:
d0084f94:	4801      	ldr	r0, [pc, #4]	; (d0084f9c <__sfp_lock_release+0x8>)
d0084f96:	f000 b8ae 	b.w	d00850f6 <__retarget_lock_release_recursive>
d0084f9a:	bf00      	nop
d0084f9c:	d00c8280 	.word	0xd00c8280

d0084fa0 <__sinit_lock_acquire>:
d0084fa0:	4801      	ldr	r0, [pc, #4]	; (d0084fa8 <__sinit_lock_acquire+0x8>)
d0084fa2:	f000 b8a7 	b.w	d00850f4 <__retarget_lock_acquire_recursive>
d0084fa6:	bf00      	nop
d0084fa8:	d00c827b 	.word	0xd00c827b

d0084fac <__sinit_lock_release>:
d0084fac:	4801      	ldr	r0, [pc, #4]	; (d0084fb4 <__sinit_lock_release+0x8>)
d0084fae:	f000 b8a2 	b.w	d00850f6 <__retarget_lock_release_recursive>
d0084fb2:	bf00      	nop
d0084fb4:	d00c827b 	.word	0xd00c827b

d0084fb8 <__sinit>:
d0084fb8:	b510      	push	{r4, lr}
d0084fba:	4604      	mov	r4, r0
d0084fbc:	f7ff fff0 	bl	d0084fa0 <__sinit_lock_acquire>
d0084fc0:	69a3      	ldr	r3, [r4, #24]
d0084fc2:	b11b      	cbz	r3, d0084fcc <__sinit+0x14>
d0084fc4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d0084fc8:	f7ff bff0 	b.w	d0084fac <__sinit_lock_release>
d0084fcc:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d0084fd0:	6523      	str	r3, [r4, #80]	; 0x50
d0084fd2:	4b13      	ldr	r3, [pc, #76]	; (d0085020 <__sinit+0x68>)
d0084fd4:	4a13      	ldr	r2, [pc, #76]	; (d0085024 <__sinit+0x6c>)
d0084fd6:	681b      	ldr	r3, [r3, #0]
d0084fd8:	62a2      	str	r2, [r4, #40]	; 0x28
d0084fda:	42a3      	cmp	r3, r4
d0084fdc:	bf04      	itt	eq
d0084fde:	2301      	moveq	r3, #1
d0084fe0:	61a3      	streq	r3, [r4, #24]
d0084fe2:	4620      	mov	r0, r4
d0084fe4:	f000 f820 	bl	d0085028 <__sfp>
d0084fe8:	6060      	str	r0, [r4, #4]
d0084fea:	4620      	mov	r0, r4
d0084fec:	f000 f81c 	bl	d0085028 <__sfp>
d0084ff0:	60a0      	str	r0, [r4, #8]
d0084ff2:	4620      	mov	r0, r4
d0084ff4:	f000 f818 	bl	d0085028 <__sfp>
d0084ff8:	2200      	movs	r2, #0
d0084ffa:	60e0      	str	r0, [r4, #12]
d0084ffc:	2104      	movs	r1, #4
d0084ffe:	6860      	ldr	r0, [r4, #4]
d0085000:	f7ff ff82 	bl	d0084f08 <std>
d0085004:	68a0      	ldr	r0, [r4, #8]
d0085006:	2201      	movs	r2, #1
d0085008:	2109      	movs	r1, #9
d008500a:	f7ff ff7d 	bl	d0084f08 <std>
d008500e:	68e0      	ldr	r0, [r4, #12]
d0085010:	2202      	movs	r2, #2
d0085012:	2112      	movs	r1, #18
d0085014:	f7ff ff78 	bl	d0084f08 <std>
d0085018:	2301      	movs	r3, #1
d008501a:	61a3      	str	r3, [r4, #24]
d008501c:	e7d2      	b.n	d0084fc4 <__sinit+0xc>
d008501e:	bf00      	nop
d0085020:	d0086070 	.word	0xd0086070
d0085024:	d0084f51 	.word	0xd0084f51

d0085028 <__sfp>:
d0085028:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008502a:	4607      	mov	r7, r0
d008502c:	f7ff ffac 	bl	d0084f88 <__sfp_lock_acquire>
d0085030:	4b1e      	ldr	r3, [pc, #120]	; (d00850ac <__sfp+0x84>)
d0085032:	681e      	ldr	r6, [r3, #0]
d0085034:	69b3      	ldr	r3, [r6, #24]
d0085036:	b913      	cbnz	r3, d008503e <__sfp+0x16>
d0085038:	4630      	mov	r0, r6
d008503a:	f7ff ffbd 	bl	d0084fb8 <__sinit>
d008503e:	3648      	adds	r6, #72	; 0x48
d0085040:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d0085044:	3b01      	subs	r3, #1
d0085046:	d503      	bpl.n	d0085050 <__sfp+0x28>
d0085048:	6833      	ldr	r3, [r6, #0]
d008504a:	b30b      	cbz	r3, d0085090 <__sfp+0x68>
d008504c:	6836      	ldr	r6, [r6, #0]
d008504e:	e7f7      	b.n	d0085040 <__sfp+0x18>
d0085050:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d0085054:	b9d5      	cbnz	r5, d008508c <__sfp+0x64>
d0085056:	4b16      	ldr	r3, [pc, #88]	; (d00850b0 <__sfp+0x88>)
d0085058:	60e3      	str	r3, [r4, #12]
d008505a:	f104 0058 	add.w	r0, r4, #88	; 0x58
d008505e:	6665      	str	r5, [r4, #100]	; 0x64
d0085060:	f000 f847 	bl	d00850f2 <__retarget_lock_init_recursive>
d0085064:	f7ff ff96 	bl	d0084f94 <__sfp_lock_release>
d0085068:	e9c4 5501 	strd	r5, r5, [r4, #4]
d008506c:	e9c4 5504 	strd	r5, r5, [r4, #16]
d0085070:	6025      	str	r5, [r4, #0]
d0085072:	61a5      	str	r5, [r4, #24]
d0085074:	2208      	movs	r2, #8
d0085076:	4629      	mov	r1, r5
d0085078:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d008507c:	f7ff fcbc 	bl	d00849f8 <memset>
d0085080:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d0085084:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d0085088:	4620      	mov	r0, r4
d008508a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d008508c:	3468      	adds	r4, #104	; 0x68
d008508e:	e7d9      	b.n	d0085044 <__sfp+0x1c>
d0085090:	2104      	movs	r1, #4
d0085092:	4638      	mov	r0, r7
d0085094:	f7ff ff62 	bl	d0084f5c <__sfmoreglue>
d0085098:	4604      	mov	r4, r0
d008509a:	6030      	str	r0, [r6, #0]
d008509c:	2800      	cmp	r0, #0
d008509e:	d1d5      	bne.n	d008504c <__sfp+0x24>
d00850a0:	f7ff ff78 	bl	d0084f94 <__sfp_lock_release>
d00850a4:	230c      	movs	r3, #12
d00850a6:	603b      	str	r3, [r7, #0]
d00850a8:	e7ee      	b.n	d0085088 <__sfp+0x60>
d00850aa:	bf00      	nop
d00850ac:	d0086070 	.word	0xd0086070
d00850b0:	ffff0001 	.word	0xffff0001

d00850b4 <_fwalk_reent>:
d00850b4:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d00850b8:	4606      	mov	r6, r0
d00850ba:	4688      	mov	r8, r1
d00850bc:	f100 0448 	add.w	r4, r0, #72	; 0x48
d00850c0:	2700      	movs	r7, #0
d00850c2:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d00850c6:	f1b9 0901 	subs.w	r9, r9, #1
d00850ca:	d505      	bpl.n	d00850d8 <_fwalk_reent+0x24>
d00850cc:	6824      	ldr	r4, [r4, #0]
d00850ce:	2c00      	cmp	r4, #0
d00850d0:	d1f7      	bne.n	d00850c2 <_fwalk_reent+0xe>
d00850d2:	4638      	mov	r0, r7
d00850d4:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d00850d8:	89ab      	ldrh	r3, [r5, #12]
d00850da:	2b01      	cmp	r3, #1
d00850dc:	d907      	bls.n	d00850ee <_fwalk_reent+0x3a>
d00850de:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d00850e2:	3301      	adds	r3, #1
d00850e4:	d003      	beq.n	d00850ee <_fwalk_reent+0x3a>
d00850e6:	4629      	mov	r1, r5
d00850e8:	4630      	mov	r0, r6
d00850ea:	47c0      	blx	r8
d00850ec:	4307      	orrs	r7, r0
d00850ee:	3568      	adds	r5, #104	; 0x68
d00850f0:	e7e9      	b.n	d00850c6 <_fwalk_reent+0x12>

d00850f2 <__retarget_lock_init_recursive>:
d00850f2:	4770      	bx	lr

d00850f4 <__retarget_lock_acquire_recursive>:
d00850f4:	4770      	bx	lr

d00850f6 <__retarget_lock_release_recursive>:
d00850f6:	4770      	bx	lr

d00850f8 <__swhatbuf_r>:
d00850f8:	b570      	push	{r4, r5, r6, lr}
d00850fa:	460e      	mov	r6, r1
d00850fc:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0085100:	2900      	cmp	r1, #0
d0085102:	b096      	sub	sp, #88	; 0x58
d0085104:	4614      	mov	r4, r2
d0085106:	461d      	mov	r5, r3
d0085108:	da07      	bge.n	d008511a <__swhatbuf_r+0x22>
d008510a:	2300      	movs	r3, #0
d008510c:	602b      	str	r3, [r5, #0]
d008510e:	89b3      	ldrh	r3, [r6, #12]
d0085110:	061a      	lsls	r2, r3, #24
d0085112:	d410      	bmi.n	d0085136 <__swhatbuf_r+0x3e>
d0085114:	f44f 6380 	mov.w	r3, #1024	; 0x400
d0085118:	e00e      	b.n	d0085138 <__swhatbuf_r+0x40>
d008511a:	466a      	mov	r2, sp
d008511c:	f000 fb60 	bl	d00857e0 <_fstat_r>
d0085120:	2800      	cmp	r0, #0
d0085122:	dbf2      	blt.n	d008510a <__swhatbuf_r+0x12>
d0085124:	9a01      	ldr	r2, [sp, #4]
d0085126:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d008512a:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d008512e:	425a      	negs	r2, r3
d0085130:	415a      	adcs	r2, r3
d0085132:	602a      	str	r2, [r5, #0]
d0085134:	e7ee      	b.n	d0085114 <__swhatbuf_r+0x1c>
d0085136:	2340      	movs	r3, #64	; 0x40
d0085138:	2000      	movs	r0, #0
d008513a:	6023      	str	r3, [r4, #0]
d008513c:	b016      	add	sp, #88	; 0x58
d008513e:	bd70      	pop	{r4, r5, r6, pc}

d0085140 <__malloc_lock>:
d0085140:	4801      	ldr	r0, [pc, #4]	; (d0085148 <__malloc_lock+0x8>)
d0085142:	f7ff bfd7 	b.w	d00850f4 <__retarget_lock_acquire_recursive>
d0085146:	bf00      	nop
d0085148:	d00c827c 	.word	0xd00c827c

d008514c <__malloc_unlock>:
d008514c:	4801      	ldr	r0, [pc, #4]	; (d0085154 <__malloc_unlock+0x8>)
d008514e:	f7ff bfd2 	b.w	d00850f6 <__retarget_lock_release_recursive>
d0085152:	bf00      	nop
d0085154:	d00c827c 	.word	0xd00c827c

d0085158 <__ssputs_r>:
d0085158:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d008515c:	688e      	ldr	r6, [r1, #8]
d008515e:	429e      	cmp	r6, r3
d0085160:	4682      	mov	sl, r0
d0085162:	460c      	mov	r4, r1
d0085164:	4690      	mov	r8, r2
d0085166:	461f      	mov	r7, r3
d0085168:	d838      	bhi.n	d00851dc <__ssputs_r+0x84>
d008516a:	898a      	ldrh	r2, [r1, #12]
d008516c:	f412 6f90 	tst.w	r2, #1152	; 0x480
d0085170:	d032      	beq.n	d00851d8 <__ssputs_r+0x80>
d0085172:	6825      	ldr	r5, [r4, #0]
d0085174:	6909      	ldr	r1, [r1, #16]
d0085176:	eba5 0901 	sub.w	r9, r5, r1
d008517a:	6965      	ldr	r5, [r4, #20]
d008517c:	eb05 0545 	add.w	r5, r5, r5, lsl #1
d0085180:	eb05 75d5 	add.w	r5, r5, r5, lsr #31
d0085184:	3301      	adds	r3, #1
d0085186:	444b      	add	r3, r9
d0085188:	106d      	asrs	r5, r5, #1
d008518a:	429d      	cmp	r5, r3
d008518c:	bf38      	it	cc
d008518e:	461d      	movcc	r5, r3
d0085190:	0553      	lsls	r3, r2, #21
d0085192:	d531      	bpl.n	d00851f8 <__ssputs_r+0xa0>
d0085194:	4629      	mov	r1, r5
d0085196:	f7ff fc87 	bl	d0084aa8 <_malloc_r>
d008519a:	4606      	mov	r6, r0
d008519c:	b950      	cbnz	r0, d00851b4 <__ssputs_r+0x5c>
d008519e:	230c      	movs	r3, #12
d00851a0:	f8ca 3000 	str.w	r3, [sl]
d00851a4:	89a3      	ldrh	r3, [r4, #12]
d00851a6:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d00851aa:	81a3      	strh	r3, [r4, #12]
d00851ac:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00851b0:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d00851b4:	6921      	ldr	r1, [r4, #16]
d00851b6:	464a      	mov	r2, r9
d00851b8:	f000 fb8a 	bl	d00858d0 <memcpy>
d00851bc:	89a3      	ldrh	r3, [r4, #12]
d00851be:	f423 6390 	bic.w	r3, r3, #1152	; 0x480
d00851c2:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d00851c6:	81a3      	strh	r3, [r4, #12]
d00851c8:	6126      	str	r6, [r4, #16]
d00851ca:	6165      	str	r5, [r4, #20]
d00851cc:	444e      	add	r6, r9
d00851ce:	eba5 0509 	sub.w	r5, r5, r9
d00851d2:	6026      	str	r6, [r4, #0]
d00851d4:	60a5      	str	r5, [r4, #8]
d00851d6:	463e      	mov	r6, r7
d00851d8:	42be      	cmp	r6, r7
d00851da:	d900      	bls.n	d00851de <__ssputs_r+0x86>
d00851dc:	463e      	mov	r6, r7
d00851de:	4632      	mov	r2, r6
d00851e0:	6820      	ldr	r0, [r4, #0]
d00851e2:	4641      	mov	r1, r8
d00851e4:	f000 fb82 	bl	d00858ec <memmove>
d00851e8:	68a3      	ldr	r3, [r4, #8]
d00851ea:	6822      	ldr	r2, [r4, #0]
d00851ec:	1b9b      	subs	r3, r3, r6
d00851ee:	4432      	add	r2, r6
d00851f0:	60a3      	str	r3, [r4, #8]
d00851f2:	6022      	str	r2, [r4, #0]
d00851f4:	2000      	movs	r0, #0
d00851f6:	e7db      	b.n	d00851b0 <__ssputs_r+0x58>
d00851f8:	462a      	mov	r2, r5
d00851fa:	f000 fb91 	bl	d0085920 <_realloc_r>
d00851fe:	4606      	mov	r6, r0
d0085200:	2800      	cmp	r0, #0
d0085202:	d1e1      	bne.n	d00851c8 <__ssputs_r+0x70>
d0085204:	6921      	ldr	r1, [r4, #16]
d0085206:	4650      	mov	r0, sl
d0085208:	f7ff fbfe 	bl	d0084a08 <_free_r>
d008520c:	e7c7      	b.n	d008519e <__ssputs_r+0x46>
	...

d0085210 <_svfiprintf_r>:
d0085210:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0085214:	4698      	mov	r8, r3
d0085216:	898b      	ldrh	r3, [r1, #12]
d0085218:	061b      	lsls	r3, r3, #24
d008521a:	b09d      	sub	sp, #116	; 0x74
d008521c:	4607      	mov	r7, r0
d008521e:	460d      	mov	r5, r1
d0085220:	4614      	mov	r4, r2
d0085222:	d50e      	bpl.n	d0085242 <_svfiprintf_r+0x32>
d0085224:	690b      	ldr	r3, [r1, #16]
d0085226:	b963      	cbnz	r3, d0085242 <_svfiprintf_r+0x32>
d0085228:	2140      	movs	r1, #64	; 0x40
d008522a:	f7ff fc3d 	bl	d0084aa8 <_malloc_r>
d008522e:	6028      	str	r0, [r5, #0]
d0085230:	6128      	str	r0, [r5, #16]
d0085232:	b920      	cbnz	r0, d008523e <_svfiprintf_r+0x2e>
d0085234:	230c      	movs	r3, #12
d0085236:	603b      	str	r3, [r7, #0]
d0085238:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008523c:	e0d1      	b.n	d00853e2 <_svfiprintf_r+0x1d2>
d008523e:	2340      	movs	r3, #64	; 0x40
d0085240:	616b      	str	r3, [r5, #20]
d0085242:	2300      	movs	r3, #0
d0085244:	9309      	str	r3, [sp, #36]	; 0x24
d0085246:	2320      	movs	r3, #32
d0085248:	f88d 3029 	strb.w	r3, [sp, #41]	; 0x29
d008524c:	f8cd 800c 	str.w	r8, [sp, #12]
d0085250:	2330      	movs	r3, #48	; 0x30
d0085252:	f8df 81a8 	ldr.w	r8, [pc, #424]	; d00853fc <_svfiprintf_r+0x1ec>
d0085256:	f88d 302a 	strb.w	r3, [sp, #42]	; 0x2a
d008525a:	f04f 0901 	mov.w	r9, #1
d008525e:	4623      	mov	r3, r4
d0085260:	469a      	mov	sl, r3
d0085262:	f813 2b01 	ldrb.w	r2, [r3], #1
d0085266:	b10a      	cbz	r2, d008526c <_svfiprintf_r+0x5c>
d0085268:	2a25      	cmp	r2, #37	; 0x25
d008526a:	d1f9      	bne.n	d0085260 <_svfiprintf_r+0x50>
d008526c:	ebba 0b04 	subs.w	fp, sl, r4
d0085270:	d00b      	beq.n	d008528a <_svfiprintf_r+0x7a>
d0085272:	465b      	mov	r3, fp
d0085274:	4622      	mov	r2, r4
d0085276:	4629      	mov	r1, r5
d0085278:	4638      	mov	r0, r7
d008527a:	f7ff ff6d 	bl	d0085158 <__ssputs_r>
d008527e:	3001      	adds	r0, #1
d0085280:	f000 80aa 	beq.w	d00853d8 <_svfiprintf_r+0x1c8>
d0085284:	9a09      	ldr	r2, [sp, #36]	; 0x24
d0085286:	445a      	add	r2, fp
d0085288:	9209      	str	r2, [sp, #36]	; 0x24
d008528a:	f89a 3000 	ldrb.w	r3, [sl]
d008528e:	2b00      	cmp	r3, #0
d0085290:	f000 80a2 	beq.w	d00853d8 <_svfiprintf_r+0x1c8>
d0085294:	2300      	movs	r3, #0
d0085296:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d008529a:	e9cd 2305 	strd	r2, r3, [sp, #20]
d008529e:	f10a 0a01 	add.w	sl, sl, #1
d00852a2:	9304      	str	r3, [sp, #16]
d00852a4:	9307      	str	r3, [sp, #28]
d00852a6:	f88d 3053 	strb.w	r3, [sp, #83]	; 0x53
d00852aa:	931a      	str	r3, [sp, #104]	; 0x68
d00852ac:	4654      	mov	r4, sl
d00852ae:	2205      	movs	r2, #5
d00852b0:	f814 1b01 	ldrb.w	r1, [r4], #1
d00852b4:	4851      	ldr	r0, [pc, #324]	; (d00853fc <_svfiprintf_r+0x1ec>)
d00852b6:	f000 fabb 	bl	d0085830 <memchr>
d00852ba:	9a04      	ldr	r2, [sp, #16]
d00852bc:	b9d8      	cbnz	r0, d00852f6 <_svfiprintf_r+0xe6>
d00852be:	06d0      	lsls	r0, r2, #27
d00852c0:	bf44      	itt	mi
d00852c2:	2320      	movmi	r3, #32
d00852c4:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d00852c8:	0711      	lsls	r1, r2, #28
d00852ca:	bf44      	itt	mi
d00852cc:	232b      	movmi	r3, #43	; 0x2b
d00852ce:	f88d 3053 	strbmi.w	r3, [sp, #83]	; 0x53
d00852d2:	f89a 3000 	ldrb.w	r3, [sl]
d00852d6:	2b2a      	cmp	r3, #42	; 0x2a
d00852d8:	d015      	beq.n	d0085306 <_svfiprintf_r+0xf6>
d00852da:	9a07      	ldr	r2, [sp, #28]
d00852dc:	4654      	mov	r4, sl
d00852de:	2000      	movs	r0, #0
d00852e0:	f04f 0c0a 	mov.w	ip, #10
d00852e4:	4621      	mov	r1, r4
d00852e6:	f811 3b01 	ldrb.w	r3, [r1], #1
d00852ea:	3b30      	subs	r3, #48	; 0x30
d00852ec:	2b09      	cmp	r3, #9
d00852ee:	d94e      	bls.n	d008538e <_svfiprintf_r+0x17e>
d00852f0:	b1b0      	cbz	r0, d0085320 <_svfiprintf_r+0x110>
d00852f2:	9207      	str	r2, [sp, #28]
d00852f4:	e014      	b.n	d0085320 <_svfiprintf_r+0x110>
d00852f6:	eba0 0308 	sub.w	r3, r0, r8
d00852fa:	fa09 f303 	lsl.w	r3, r9, r3
d00852fe:	4313      	orrs	r3, r2
d0085300:	9304      	str	r3, [sp, #16]
d0085302:	46a2      	mov	sl, r4
d0085304:	e7d2      	b.n	d00852ac <_svfiprintf_r+0x9c>
d0085306:	9b03      	ldr	r3, [sp, #12]
d0085308:	1d19      	adds	r1, r3, #4
d008530a:	681b      	ldr	r3, [r3, #0]
d008530c:	9103      	str	r1, [sp, #12]
d008530e:	2b00      	cmp	r3, #0
d0085310:	bfbb      	ittet	lt
d0085312:	425b      	neglt	r3, r3
d0085314:	f042 0202 	orrlt.w	r2, r2, #2
d0085318:	9307      	strge	r3, [sp, #28]
d008531a:	9307      	strlt	r3, [sp, #28]
d008531c:	bfb8      	it	lt
d008531e:	9204      	strlt	r2, [sp, #16]
d0085320:	7823      	ldrb	r3, [r4, #0]
d0085322:	2b2e      	cmp	r3, #46	; 0x2e
d0085324:	d10c      	bne.n	d0085340 <_svfiprintf_r+0x130>
d0085326:	7863      	ldrb	r3, [r4, #1]
d0085328:	2b2a      	cmp	r3, #42	; 0x2a
d008532a:	d135      	bne.n	d0085398 <_svfiprintf_r+0x188>
d008532c:	9b03      	ldr	r3, [sp, #12]
d008532e:	1d1a      	adds	r2, r3, #4
d0085330:	681b      	ldr	r3, [r3, #0]
d0085332:	9203      	str	r2, [sp, #12]
d0085334:	2b00      	cmp	r3, #0
d0085336:	bfb8      	it	lt
d0085338:	f04f 33ff 	movlt.w	r3, #4294967295	; 0xffffffff
d008533c:	3402      	adds	r4, #2
d008533e:	9305      	str	r3, [sp, #20]
d0085340:	f8df a0c8 	ldr.w	sl, [pc, #200]	; d008540c <_svfiprintf_r+0x1fc>
d0085344:	7821      	ldrb	r1, [r4, #0]
d0085346:	2203      	movs	r2, #3
d0085348:	4650      	mov	r0, sl
d008534a:	f000 fa71 	bl	d0085830 <memchr>
d008534e:	b140      	cbz	r0, d0085362 <_svfiprintf_r+0x152>
d0085350:	2340      	movs	r3, #64	; 0x40
d0085352:	eba0 000a 	sub.w	r0, r0, sl
d0085356:	fa03 f000 	lsl.w	r0, r3, r0
d008535a:	9b04      	ldr	r3, [sp, #16]
d008535c:	4303      	orrs	r3, r0
d008535e:	3401      	adds	r4, #1
d0085360:	9304      	str	r3, [sp, #16]
d0085362:	f814 1b01 	ldrb.w	r1, [r4], #1
d0085366:	4826      	ldr	r0, [pc, #152]	; (d0085400 <_svfiprintf_r+0x1f0>)
d0085368:	f88d 1028 	strb.w	r1, [sp, #40]	; 0x28
d008536c:	2206      	movs	r2, #6
d008536e:	f000 fa5f 	bl	d0085830 <memchr>
d0085372:	2800      	cmp	r0, #0
d0085374:	d038      	beq.n	d00853e8 <_svfiprintf_r+0x1d8>
d0085376:	4b23      	ldr	r3, [pc, #140]	; (d0085404 <_svfiprintf_r+0x1f4>)
d0085378:	bb1b      	cbnz	r3, d00853c2 <_svfiprintf_r+0x1b2>
d008537a:	9b03      	ldr	r3, [sp, #12]
d008537c:	3307      	adds	r3, #7
d008537e:	f023 0307 	bic.w	r3, r3, #7
d0085382:	3308      	adds	r3, #8
d0085384:	9303      	str	r3, [sp, #12]
d0085386:	9b09      	ldr	r3, [sp, #36]	; 0x24
d0085388:	4433      	add	r3, r6
d008538a:	9309      	str	r3, [sp, #36]	; 0x24
d008538c:	e767      	b.n	d008525e <_svfiprintf_r+0x4e>
d008538e:	fb0c 3202 	mla	r2, ip, r2, r3
d0085392:	460c      	mov	r4, r1
d0085394:	2001      	movs	r0, #1
d0085396:	e7a5      	b.n	d00852e4 <_svfiprintf_r+0xd4>
d0085398:	2300      	movs	r3, #0
d008539a:	3401      	adds	r4, #1
d008539c:	9305      	str	r3, [sp, #20]
d008539e:	4619      	mov	r1, r3
d00853a0:	f04f 0c0a 	mov.w	ip, #10
d00853a4:	4620      	mov	r0, r4
d00853a6:	f810 2b01 	ldrb.w	r2, [r0], #1
d00853aa:	3a30      	subs	r2, #48	; 0x30
d00853ac:	2a09      	cmp	r2, #9
d00853ae:	d903      	bls.n	d00853b8 <_svfiprintf_r+0x1a8>
d00853b0:	2b00      	cmp	r3, #0
d00853b2:	d0c5      	beq.n	d0085340 <_svfiprintf_r+0x130>
d00853b4:	9105      	str	r1, [sp, #20]
d00853b6:	e7c3      	b.n	d0085340 <_svfiprintf_r+0x130>
d00853b8:	fb0c 2101 	mla	r1, ip, r1, r2
d00853bc:	4604      	mov	r4, r0
d00853be:	2301      	movs	r3, #1
d00853c0:	e7f0      	b.n	d00853a4 <_svfiprintf_r+0x194>
d00853c2:	ab03      	add	r3, sp, #12
d00853c4:	9300      	str	r3, [sp, #0]
d00853c6:	462a      	mov	r2, r5
d00853c8:	4b0f      	ldr	r3, [pc, #60]	; (d0085408 <_svfiprintf_r+0x1f8>)
d00853ca:	a904      	add	r1, sp, #16
d00853cc:	4638      	mov	r0, r7
d00853ce:	f3af 8000 	nop.w
d00853d2:	1c42      	adds	r2, r0, #1
d00853d4:	4606      	mov	r6, r0
d00853d6:	d1d6      	bne.n	d0085386 <_svfiprintf_r+0x176>
d00853d8:	89ab      	ldrh	r3, [r5, #12]
d00853da:	065b      	lsls	r3, r3, #25
d00853dc:	f53f af2c 	bmi.w	d0085238 <_svfiprintf_r+0x28>
d00853e0:	9809      	ldr	r0, [sp, #36]	; 0x24
d00853e2:	b01d      	add	sp, #116	; 0x74
d00853e4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
d00853e8:	ab03      	add	r3, sp, #12
d00853ea:	9300      	str	r3, [sp, #0]
d00853ec:	462a      	mov	r2, r5
d00853ee:	4b06      	ldr	r3, [pc, #24]	; (d0085408 <_svfiprintf_r+0x1f8>)
d00853f0:	a904      	add	r1, sp, #16
d00853f2:	4638      	mov	r0, r7
d00853f4:	f000 f87a 	bl	d00854ec <_printf_i>
d00853f8:	e7eb      	b.n	d00853d2 <_svfiprintf_r+0x1c2>
d00853fa:	bf00      	nop
d00853fc:	d00860d4 	.word	0xd00860d4
d0085400:	d00860de 	.word	0xd00860de
d0085404:	00000000 	.word	0x00000000
d0085408:	d0085159 	.word	0xd0085159
d008540c:	d00860da 	.word	0xd00860da

d0085410 <_printf_common>:
d0085410:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
d0085414:	4616      	mov	r6, r2
d0085416:	4699      	mov	r9, r3
d0085418:	688a      	ldr	r2, [r1, #8]
d008541a:	690b      	ldr	r3, [r1, #16]
d008541c:	f8dd 8020 	ldr.w	r8, [sp, #32]
d0085420:	4293      	cmp	r3, r2
d0085422:	bfb8      	it	lt
d0085424:	4613      	movlt	r3, r2
d0085426:	6033      	str	r3, [r6, #0]
d0085428:	f891 2043 	ldrb.w	r2, [r1, #67]	; 0x43
d008542c:	4607      	mov	r7, r0
d008542e:	460c      	mov	r4, r1
d0085430:	b10a      	cbz	r2, d0085436 <_printf_common+0x26>
d0085432:	3301      	adds	r3, #1
d0085434:	6033      	str	r3, [r6, #0]
d0085436:	6823      	ldr	r3, [r4, #0]
d0085438:	0699      	lsls	r1, r3, #26
d008543a:	bf42      	ittt	mi
d008543c:	6833      	ldrmi	r3, [r6, #0]
d008543e:	3302      	addmi	r3, #2
d0085440:	6033      	strmi	r3, [r6, #0]
d0085442:	6825      	ldr	r5, [r4, #0]
d0085444:	f015 0506 	ands.w	r5, r5, #6
d0085448:	d106      	bne.n	d0085458 <_printf_common+0x48>
d008544a:	f104 0a19 	add.w	sl, r4, #25
d008544e:	68e3      	ldr	r3, [r4, #12]
d0085450:	6832      	ldr	r2, [r6, #0]
d0085452:	1a9b      	subs	r3, r3, r2
d0085454:	42ab      	cmp	r3, r5
d0085456:	dc26      	bgt.n	d00854a6 <_printf_common+0x96>
d0085458:	f894 2043 	ldrb.w	r2, [r4, #67]	; 0x43
d008545c:	1e13      	subs	r3, r2, #0
d008545e:	6822      	ldr	r2, [r4, #0]
d0085460:	bf18      	it	ne
d0085462:	2301      	movne	r3, #1
d0085464:	0692      	lsls	r2, r2, #26
d0085466:	d42b      	bmi.n	d00854c0 <_printf_common+0xb0>
d0085468:	f104 0243 	add.w	r2, r4, #67	; 0x43
d008546c:	4649      	mov	r1, r9
d008546e:	4638      	mov	r0, r7
d0085470:	47c0      	blx	r8
d0085472:	3001      	adds	r0, #1
d0085474:	d01e      	beq.n	d00854b4 <_printf_common+0xa4>
d0085476:	6823      	ldr	r3, [r4, #0]
d0085478:	68e5      	ldr	r5, [r4, #12]
d008547a:	6832      	ldr	r2, [r6, #0]
d008547c:	f003 0306 	and.w	r3, r3, #6
d0085480:	2b04      	cmp	r3, #4
d0085482:	bf08      	it	eq
d0085484:	1aad      	subeq	r5, r5, r2
d0085486:	68a3      	ldr	r3, [r4, #8]
d0085488:	6922      	ldr	r2, [r4, #16]
d008548a:	bf0c      	ite	eq
d008548c:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
d0085490:	2500      	movne	r5, #0
d0085492:	4293      	cmp	r3, r2
d0085494:	bfc4      	itt	gt
d0085496:	1a9b      	subgt	r3, r3, r2
d0085498:	18ed      	addgt	r5, r5, r3
d008549a:	2600      	movs	r6, #0
d008549c:	341a      	adds	r4, #26
d008549e:	42b5      	cmp	r5, r6
d00854a0:	d11a      	bne.n	d00854d8 <_printf_common+0xc8>
d00854a2:	2000      	movs	r0, #0
d00854a4:	e008      	b.n	d00854b8 <_printf_common+0xa8>
d00854a6:	2301      	movs	r3, #1
d00854a8:	4652      	mov	r2, sl
d00854aa:	4649      	mov	r1, r9
d00854ac:	4638      	mov	r0, r7
d00854ae:	47c0      	blx	r8
d00854b0:	3001      	adds	r0, #1
d00854b2:	d103      	bne.n	d00854bc <_printf_common+0xac>
d00854b4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00854b8:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d00854bc:	3501      	adds	r5, #1
d00854be:	e7c6      	b.n	d008544e <_printf_common+0x3e>
d00854c0:	18e1      	adds	r1, r4, r3
d00854c2:	1c5a      	adds	r2, r3, #1
d00854c4:	2030      	movs	r0, #48	; 0x30
d00854c6:	f881 0043 	strb.w	r0, [r1, #67]	; 0x43
d00854ca:	4422      	add	r2, r4
d00854cc:	f894 1045 	ldrb.w	r1, [r4, #69]	; 0x45
d00854d0:	f882 1043 	strb.w	r1, [r2, #67]	; 0x43
d00854d4:	3302      	adds	r3, #2
d00854d6:	e7c7      	b.n	d0085468 <_printf_common+0x58>
d00854d8:	2301      	movs	r3, #1
d00854da:	4622      	mov	r2, r4
d00854dc:	4649      	mov	r1, r9
d00854de:	4638      	mov	r0, r7
d00854e0:	47c0      	blx	r8
d00854e2:	3001      	adds	r0, #1
d00854e4:	d0e6      	beq.n	d00854b4 <_printf_common+0xa4>
d00854e6:	3601      	adds	r6, #1
d00854e8:	e7d9      	b.n	d008549e <_printf_common+0x8e>
	...

d00854ec <_printf_i>:
d00854ec:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
d00854f0:	460c      	mov	r4, r1
d00854f2:	4691      	mov	r9, r2
d00854f4:	7e27      	ldrb	r7, [r4, #24]
d00854f6:	990c      	ldr	r1, [sp, #48]	; 0x30
d00854f8:	2f78      	cmp	r7, #120	; 0x78
d00854fa:	4680      	mov	r8, r0
d00854fc:	469a      	mov	sl, r3
d00854fe:	f104 0243 	add.w	r2, r4, #67	; 0x43
d0085502:	d807      	bhi.n	d0085514 <_printf_i+0x28>
d0085504:	2f62      	cmp	r7, #98	; 0x62
d0085506:	d80a      	bhi.n	d008551e <_printf_i+0x32>
d0085508:	2f00      	cmp	r7, #0
d008550a:	f000 80d8 	beq.w	d00856be <_printf_i+0x1d2>
d008550e:	2f58      	cmp	r7, #88	; 0x58
d0085510:	f000 80a3 	beq.w	d008565a <_printf_i+0x16e>
d0085514:	f104 0642 	add.w	r6, r4, #66	; 0x42
d0085518:	f884 7042 	strb.w	r7, [r4, #66]	; 0x42
d008551c:	e03a      	b.n	d0085594 <_printf_i+0xa8>
d008551e:	f1a7 0363 	sub.w	r3, r7, #99	; 0x63
d0085522:	2b15      	cmp	r3, #21
d0085524:	d8f6      	bhi.n	d0085514 <_printf_i+0x28>
d0085526:	a001      	add	r0, pc, #4	; (adr r0, d008552c <_printf_i+0x40>)
d0085528:	f850 f023 	ldr.w	pc, [r0, r3, lsl #2]
d008552c:	d0085585 	.word	0xd0085585
d0085530:	d0085599 	.word	0xd0085599
d0085534:	d0085515 	.word	0xd0085515
d0085538:	d0085515 	.word	0xd0085515
d008553c:	d0085515 	.word	0xd0085515
d0085540:	d0085515 	.word	0xd0085515
d0085544:	d0085599 	.word	0xd0085599
d0085548:	d0085515 	.word	0xd0085515
d008554c:	d0085515 	.word	0xd0085515
d0085550:	d0085515 	.word	0xd0085515
d0085554:	d0085515 	.word	0xd0085515
d0085558:	d00856a5 	.word	0xd00856a5
d008555c:	d00855c9 	.word	0xd00855c9
d0085560:	d0085687 	.word	0xd0085687
d0085564:	d0085515 	.word	0xd0085515
d0085568:	d0085515 	.word	0xd0085515
d008556c:	d00856c7 	.word	0xd00856c7
d0085570:	d0085515 	.word	0xd0085515
d0085574:	d00855c9 	.word	0xd00855c9
d0085578:	d0085515 	.word	0xd0085515
d008557c:	d0085515 	.word	0xd0085515
d0085580:	d008568f 	.word	0xd008568f
d0085584:	680b      	ldr	r3, [r1, #0]
d0085586:	1d1a      	adds	r2, r3, #4
d0085588:	681b      	ldr	r3, [r3, #0]
d008558a:	600a      	str	r2, [r1, #0]
d008558c:	f104 0642 	add.w	r6, r4, #66	; 0x42
d0085590:	f884 3042 	strb.w	r3, [r4, #66]	; 0x42
d0085594:	2301      	movs	r3, #1
d0085596:	e0a3      	b.n	d00856e0 <_printf_i+0x1f4>
d0085598:	6825      	ldr	r5, [r4, #0]
d008559a:	6808      	ldr	r0, [r1, #0]
d008559c:	062e      	lsls	r6, r5, #24
d008559e:	f100 0304 	add.w	r3, r0, #4
d00855a2:	d50a      	bpl.n	d00855ba <_printf_i+0xce>
d00855a4:	6805      	ldr	r5, [r0, #0]
d00855a6:	600b      	str	r3, [r1, #0]
d00855a8:	2d00      	cmp	r5, #0
d00855aa:	da03      	bge.n	d00855b4 <_printf_i+0xc8>
d00855ac:	232d      	movs	r3, #45	; 0x2d
d00855ae:	426d      	negs	r5, r5
d00855b0:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d00855b4:	485e      	ldr	r0, [pc, #376]	; (d0085730 <_printf_i+0x244>)
d00855b6:	230a      	movs	r3, #10
d00855b8:	e019      	b.n	d00855ee <_printf_i+0x102>
d00855ba:	f015 0f40 	tst.w	r5, #64	; 0x40
d00855be:	6805      	ldr	r5, [r0, #0]
d00855c0:	600b      	str	r3, [r1, #0]
d00855c2:	bf18      	it	ne
d00855c4:	b22d      	sxthne	r5, r5
d00855c6:	e7ef      	b.n	d00855a8 <_printf_i+0xbc>
d00855c8:	680b      	ldr	r3, [r1, #0]
d00855ca:	6825      	ldr	r5, [r4, #0]
d00855cc:	1d18      	adds	r0, r3, #4
d00855ce:	6008      	str	r0, [r1, #0]
d00855d0:	0628      	lsls	r0, r5, #24
d00855d2:	d501      	bpl.n	d00855d8 <_printf_i+0xec>
d00855d4:	681d      	ldr	r5, [r3, #0]
d00855d6:	e002      	b.n	d00855de <_printf_i+0xf2>
d00855d8:	0669      	lsls	r1, r5, #25
d00855da:	d5fb      	bpl.n	d00855d4 <_printf_i+0xe8>
d00855dc:	881d      	ldrh	r5, [r3, #0]
d00855de:	4854      	ldr	r0, [pc, #336]	; (d0085730 <_printf_i+0x244>)
d00855e0:	2f6f      	cmp	r7, #111	; 0x6f
d00855e2:	bf0c      	ite	eq
d00855e4:	2308      	moveq	r3, #8
d00855e6:	230a      	movne	r3, #10
d00855e8:	2100      	movs	r1, #0
d00855ea:	f884 1043 	strb.w	r1, [r4, #67]	; 0x43
d00855ee:	6866      	ldr	r6, [r4, #4]
d00855f0:	60a6      	str	r6, [r4, #8]
d00855f2:	2e00      	cmp	r6, #0
d00855f4:	bfa2      	ittt	ge
d00855f6:	6821      	ldrge	r1, [r4, #0]
d00855f8:	f021 0104 	bicge.w	r1, r1, #4
d00855fc:	6021      	strge	r1, [r4, #0]
d00855fe:	b90d      	cbnz	r5, d0085604 <_printf_i+0x118>
d0085600:	2e00      	cmp	r6, #0
d0085602:	d04d      	beq.n	d00856a0 <_printf_i+0x1b4>
d0085604:	4616      	mov	r6, r2
d0085606:	fbb5 f1f3 	udiv	r1, r5, r3
d008560a:	fb03 5711 	mls	r7, r3, r1, r5
d008560e:	5dc7      	ldrb	r7, [r0, r7]
d0085610:	f806 7d01 	strb.w	r7, [r6, #-1]!
d0085614:	462f      	mov	r7, r5
d0085616:	42bb      	cmp	r3, r7
d0085618:	460d      	mov	r5, r1
d008561a:	d9f4      	bls.n	d0085606 <_printf_i+0x11a>
d008561c:	2b08      	cmp	r3, #8
d008561e:	d10b      	bne.n	d0085638 <_printf_i+0x14c>
d0085620:	6823      	ldr	r3, [r4, #0]
d0085622:	07df      	lsls	r7, r3, #31
d0085624:	d508      	bpl.n	d0085638 <_printf_i+0x14c>
d0085626:	6923      	ldr	r3, [r4, #16]
d0085628:	6861      	ldr	r1, [r4, #4]
d008562a:	4299      	cmp	r1, r3
d008562c:	bfde      	ittt	le
d008562e:	2330      	movle	r3, #48	; 0x30
d0085630:	f806 3c01 	strble.w	r3, [r6, #-1]
d0085634:	f106 36ff 	addle.w	r6, r6, #4294967295	; 0xffffffff
d0085638:	1b92      	subs	r2, r2, r6
d008563a:	6122      	str	r2, [r4, #16]
d008563c:	f8cd a000 	str.w	sl, [sp]
d0085640:	464b      	mov	r3, r9
d0085642:	aa03      	add	r2, sp, #12
d0085644:	4621      	mov	r1, r4
d0085646:	4640      	mov	r0, r8
d0085648:	f7ff fee2 	bl	d0085410 <_printf_common>
d008564c:	3001      	adds	r0, #1
d008564e:	d14c      	bne.n	d00856ea <_printf_i+0x1fe>
d0085650:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0085654:	b004      	add	sp, #16
d0085656:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
d008565a:	4835      	ldr	r0, [pc, #212]	; (d0085730 <_printf_i+0x244>)
d008565c:	f884 7045 	strb.w	r7, [r4, #69]	; 0x45
d0085660:	6823      	ldr	r3, [r4, #0]
d0085662:	680e      	ldr	r6, [r1, #0]
d0085664:	061f      	lsls	r7, r3, #24
d0085666:	f856 5b04 	ldr.w	r5, [r6], #4
d008566a:	600e      	str	r6, [r1, #0]
d008566c:	d514      	bpl.n	d0085698 <_printf_i+0x1ac>
d008566e:	07d9      	lsls	r1, r3, #31
d0085670:	bf44      	itt	mi
d0085672:	f043 0320 	orrmi.w	r3, r3, #32
d0085676:	6023      	strmi	r3, [r4, #0]
d0085678:	b91d      	cbnz	r5, d0085682 <_printf_i+0x196>
d008567a:	6823      	ldr	r3, [r4, #0]
d008567c:	f023 0320 	bic.w	r3, r3, #32
d0085680:	6023      	str	r3, [r4, #0]
d0085682:	2310      	movs	r3, #16
d0085684:	e7b0      	b.n	d00855e8 <_printf_i+0xfc>
d0085686:	6823      	ldr	r3, [r4, #0]
d0085688:	f043 0320 	orr.w	r3, r3, #32
d008568c:	6023      	str	r3, [r4, #0]
d008568e:	2378      	movs	r3, #120	; 0x78
d0085690:	4828      	ldr	r0, [pc, #160]	; (d0085734 <_printf_i+0x248>)
d0085692:	f884 3045 	strb.w	r3, [r4, #69]	; 0x45
d0085696:	e7e3      	b.n	d0085660 <_printf_i+0x174>
d0085698:	065e      	lsls	r6, r3, #25
d008569a:	bf48      	it	mi
d008569c:	b2ad      	uxthmi	r5, r5
d008569e:	e7e6      	b.n	d008566e <_printf_i+0x182>
d00856a0:	4616      	mov	r6, r2
d00856a2:	e7bb      	b.n	d008561c <_printf_i+0x130>
d00856a4:	680b      	ldr	r3, [r1, #0]
d00856a6:	6826      	ldr	r6, [r4, #0]
d00856a8:	6960      	ldr	r0, [r4, #20]
d00856aa:	1d1d      	adds	r5, r3, #4
d00856ac:	600d      	str	r5, [r1, #0]
d00856ae:	0635      	lsls	r5, r6, #24
d00856b0:	681b      	ldr	r3, [r3, #0]
d00856b2:	d501      	bpl.n	d00856b8 <_printf_i+0x1cc>
d00856b4:	6018      	str	r0, [r3, #0]
d00856b6:	e002      	b.n	d00856be <_printf_i+0x1d2>
d00856b8:	0671      	lsls	r1, r6, #25
d00856ba:	d5fb      	bpl.n	d00856b4 <_printf_i+0x1c8>
d00856bc:	8018      	strh	r0, [r3, #0]
d00856be:	2300      	movs	r3, #0
d00856c0:	6123      	str	r3, [r4, #16]
d00856c2:	4616      	mov	r6, r2
d00856c4:	e7ba      	b.n	d008563c <_printf_i+0x150>
d00856c6:	680b      	ldr	r3, [r1, #0]
d00856c8:	1d1a      	adds	r2, r3, #4
d00856ca:	600a      	str	r2, [r1, #0]
d00856cc:	681e      	ldr	r6, [r3, #0]
d00856ce:	6862      	ldr	r2, [r4, #4]
d00856d0:	2100      	movs	r1, #0
d00856d2:	4630      	mov	r0, r6
d00856d4:	f000 f8ac 	bl	d0085830 <memchr>
d00856d8:	b108      	cbz	r0, d00856de <_printf_i+0x1f2>
d00856da:	1b80      	subs	r0, r0, r6
d00856dc:	6060      	str	r0, [r4, #4]
d00856de:	6863      	ldr	r3, [r4, #4]
d00856e0:	6123      	str	r3, [r4, #16]
d00856e2:	2300      	movs	r3, #0
d00856e4:	f884 3043 	strb.w	r3, [r4, #67]	; 0x43
d00856e8:	e7a8      	b.n	d008563c <_printf_i+0x150>
d00856ea:	6923      	ldr	r3, [r4, #16]
d00856ec:	4632      	mov	r2, r6
d00856ee:	4649      	mov	r1, r9
d00856f0:	4640      	mov	r0, r8
d00856f2:	47d0      	blx	sl
d00856f4:	3001      	adds	r0, #1
d00856f6:	d0ab      	beq.n	d0085650 <_printf_i+0x164>
d00856f8:	6823      	ldr	r3, [r4, #0]
d00856fa:	079b      	lsls	r3, r3, #30
d00856fc:	d413      	bmi.n	d0085726 <_printf_i+0x23a>
d00856fe:	68e0      	ldr	r0, [r4, #12]
d0085700:	9b03      	ldr	r3, [sp, #12]
d0085702:	4298      	cmp	r0, r3
d0085704:	bfb8      	it	lt
d0085706:	4618      	movlt	r0, r3
d0085708:	e7a4      	b.n	d0085654 <_printf_i+0x168>
d008570a:	2301      	movs	r3, #1
d008570c:	4632      	mov	r2, r6
d008570e:	4649      	mov	r1, r9
d0085710:	4640      	mov	r0, r8
d0085712:	47d0      	blx	sl
d0085714:	3001      	adds	r0, #1
d0085716:	d09b      	beq.n	d0085650 <_printf_i+0x164>
d0085718:	3501      	adds	r5, #1
d008571a:	68e3      	ldr	r3, [r4, #12]
d008571c:	9903      	ldr	r1, [sp, #12]
d008571e:	1a5b      	subs	r3, r3, r1
d0085720:	42ab      	cmp	r3, r5
d0085722:	dcf2      	bgt.n	d008570a <_printf_i+0x21e>
d0085724:	e7eb      	b.n	d00856fe <_printf_i+0x212>
d0085726:	2500      	movs	r5, #0
d0085728:	f104 0619 	add.w	r6, r4, #25
d008572c:	e7f5      	b.n	d008571a <_printf_i+0x22e>
d008572e:	bf00      	nop
d0085730:	d00860e5 	.word	0xd00860e5
d0085734:	d00860f6 	.word	0xd00860f6

d0085738 <__sread>:
d0085738:	b510      	push	{r4, lr}
d008573a:	460c      	mov	r4, r1
d008573c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0085740:	f000 f914 	bl	d008596c <_read_r>
d0085744:	2800      	cmp	r0, #0
d0085746:	bfab      	itete	ge
d0085748:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d008574a:	89a3      	ldrhlt	r3, [r4, #12]
d008574c:	181b      	addge	r3, r3, r0
d008574e:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d0085752:	bfac      	ite	ge
d0085754:	6563      	strge	r3, [r4, #84]	; 0x54
d0085756:	81a3      	strhlt	r3, [r4, #12]
d0085758:	bd10      	pop	{r4, pc}

d008575a <__swrite>:
d008575a:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008575e:	461f      	mov	r7, r3
d0085760:	898b      	ldrh	r3, [r1, #12]
d0085762:	05db      	lsls	r3, r3, #23
d0085764:	4605      	mov	r5, r0
d0085766:	460c      	mov	r4, r1
d0085768:	4616      	mov	r6, r2
d008576a:	d505      	bpl.n	d0085778 <__swrite+0x1e>
d008576c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0085770:	2302      	movs	r3, #2
d0085772:	2200      	movs	r2, #0
d0085774:	f000 f846 	bl	d0085804 <_lseek_r>
d0085778:	89a3      	ldrh	r3, [r4, #12]
d008577a:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d008577e:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d0085782:	81a3      	strh	r3, [r4, #12]
d0085784:	4632      	mov	r2, r6
d0085786:	463b      	mov	r3, r7
d0085788:	4628      	mov	r0, r5
d008578a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d008578e:	f7fa bc61 	b.w	d0080054 <_write_r>

d0085792 <__sseek>:
d0085792:	b510      	push	{r4, lr}
d0085794:	460c      	mov	r4, r1
d0085796:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d008579a:	f000 f833 	bl	d0085804 <_lseek_r>
d008579e:	1c43      	adds	r3, r0, #1
d00857a0:	89a3      	ldrh	r3, [r4, #12]
d00857a2:	bf15      	itete	ne
d00857a4:	6560      	strne	r0, [r4, #84]	; 0x54
d00857a6:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d00857aa:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d00857ae:	81a3      	strheq	r3, [r4, #12]
d00857b0:	bf18      	it	ne
d00857b2:	81a3      	strhne	r3, [r4, #12]
d00857b4:	bd10      	pop	{r4, pc}

d00857b6 <__sclose>:
d00857b6:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00857ba:	f000 b801 	b.w	d00857c0 <_close_r>
	...

d00857c0 <_close_r>:
d00857c0:	b538      	push	{r3, r4, r5, lr}
d00857c2:	4d06      	ldr	r5, [pc, #24]	; (d00857dc <_close_r+0x1c>)
d00857c4:	2300      	movs	r3, #0
d00857c6:	4604      	mov	r4, r0
d00857c8:	4608      	mov	r0, r1
d00857ca:	602b      	str	r3, [r5, #0]
d00857cc:	f7fa fc7c 	bl	d00800c8 <_close>
d00857d0:	1c43      	adds	r3, r0, #1
d00857d2:	d102      	bne.n	d00857da <_close_r+0x1a>
d00857d4:	682b      	ldr	r3, [r5, #0]
d00857d6:	b103      	cbz	r3, d00857da <_close_r+0x1a>
d00857d8:	6023      	str	r3, [r4, #0]
d00857da:	bd38      	pop	{r3, r4, r5, pc}
d00857dc:	d00c8284 	.word	0xd00c8284

d00857e0 <_fstat_r>:
d00857e0:	b538      	push	{r3, r4, r5, lr}
d00857e2:	4d07      	ldr	r5, [pc, #28]	; (d0085800 <_fstat_r+0x20>)
d00857e4:	2300      	movs	r3, #0
d00857e6:	4604      	mov	r4, r0
d00857e8:	4608      	mov	r0, r1
d00857ea:	4611      	mov	r1, r2
d00857ec:	602b      	str	r3, [r5, #0]
d00857ee:	f7fa fc6f 	bl	d00800d0 <_fstat>
d00857f2:	1c43      	adds	r3, r0, #1
d00857f4:	d102      	bne.n	d00857fc <_fstat_r+0x1c>
d00857f6:	682b      	ldr	r3, [r5, #0]
d00857f8:	b103      	cbz	r3, d00857fc <_fstat_r+0x1c>
d00857fa:	6023      	str	r3, [r4, #0]
d00857fc:	bd38      	pop	{r3, r4, r5, pc}
d00857fe:	bf00      	nop
d0085800:	d00c8284 	.word	0xd00c8284

d0085804 <_lseek_r>:
d0085804:	b538      	push	{r3, r4, r5, lr}
d0085806:	4d07      	ldr	r5, [pc, #28]	; (d0085824 <_lseek_r+0x20>)
d0085808:	4604      	mov	r4, r0
d008580a:	4608      	mov	r0, r1
d008580c:	4611      	mov	r1, r2
d008580e:	2200      	movs	r2, #0
d0085810:	602a      	str	r2, [r5, #0]
d0085812:	461a      	mov	r2, r3
d0085814:	f7fa fc62 	bl	d00800dc <_lseek>
d0085818:	1c43      	adds	r3, r0, #1
d008581a:	d102      	bne.n	d0085822 <_lseek_r+0x1e>
d008581c:	682b      	ldr	r3, [r5, #0]
d008581e:	b103      	cbz	r3, d0085822 <_lseek_r+0x1e>
d0085820:	6023      	str	r3, [r4, #0]
d0085822:	bd38      	pop	{r3, r4, r5, pc}
d0085824:	d00c8284 	.word	0xd00c8284
	...

d0085830 <memchr>:
d0085830:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d0085834:	2a10      	cmp	r2, #16
d0085836:	db2b      	blt.n	d0085890 <memchr+0x60>
d0085838:	f010 0f07 	tst.w	r0, #7
d008583c:	d008      	beq.n	d0085850 <memchr+0x20>
d008583e:	f810 3b01 	ldrb.w	r3, [r0], #1
d0085842:	3a01      	subs	r2, #1
d0085844:	428b      	cmp	r3, r1
d0085846:	d02d      	beq.n	d00858a4 <memchr+0x74>
d0085848:	f010 0f07 	tst.w	r0, #7
d008584c:	b342      	cbz	r2, d00858a0 <memchr+0x70>
d008584e:	d1f6      	bne.n	d008583e <memchr+0xe>
d0085850:	b4f0      	push	{r4, r5, r6, r7}
d0085852:	ea41 2101 	orr.w	r1, r1, r1, lsl #8
d0085856:	ea41 4101 	orr.w	r1, r1, r1, lsl #16
d008585a:	f022 0407 	bic.w	r4, r2, #7
d008585e:	f07f 0700 	mvns.w	r7, #0
d0085862:	2300      	movs	r3, #0
d0085864:	e8f0 5602 	ldrd	r5, r6, [r0], #8
d0085868:	3c08      	subs	r4, #8
d008586a:	ea85 0501 	eor.w	r5, r5, r1
d008586e:	ea86 0601 	eor.w	r6, r6, r1
d0085872:	fa85 f547 	uadd8	r5, r5, r7
d0085876:	faa3 f587 	sel	r5, r3, r7
d008587a:	fa86 f647 	uadd8	r6, r6, r7
d008587e:	faa5 f687 	sel	r6, r5, r7
d0085882:	b98e      	cbnz	r6, d00858a8 <memchr+0x78>
d0085884:	d1ee      	bne.n	d0085864 <memchr+0x34>
d0085886:	bcf0      	pop	{r4, r5, r6, r7}
d0085888:	f001 01ff 	and.w	r1, r1, #255	; 0xff
d008588c:	f002 0207 	and.w	r2, r2, #7
d0085890:	b132      	cbz	r2, d00858a0 <memchr+0x70>
d0085892:	f810 3b01 	ldrb.w	r3, [r0], #1
d0085896:	3a01      	subs	r2, #1
d0085898:	ea83 0301 	eor.w	r3, r3, r1
d008589c:	b113      	cbz	r3, d00858a4 <memchr+0x74>
d008589e:	d1f8      	bne.n	d0085892 <memchr+0x62>
d00858a0:	2000      	movs	r0, #0
d00858a2:	4770      	bx	lr
d00858a4:	3801      	subs	r0, #1
d00858a6:	4770      	bx	lr
d00858a8:	2d00      	cmp	r5, #0
d00858aa:	bf06      	itte	eq
d00858ac:	4635      	moveq	r5, r6
d00858ae:	3803      	subeq	r0, #3
d00858b0:	3807      	subne	r0, #7
d00858b2:	f015 0f01 	tst.w	r5, #1
d00858b6:	d107      	bne.n	d00858c8 <memchr+0x98>
d00858b8:	3001      	adds	r0, #1
d00858ba:	f415 7f80 	tst.w	r5, #256	; 0x100
d00858be:	bf02      	ittt	eq
d00858c0:	3001      	addeq	r0, #1
d00858c2:	f415 3fc0 	tsteq.w	r5, #98304	; 0x18000
d00858c6:	3001      	addeq	r0, #1
d00858c8:	bcf0      	pop	{r4, r5, r6, r7}
d00858ca:	3801      	subs	r0, #1
d00858cc:	4770      	bx	lr
d00858ce:	bf00      	nop

d00858d0 <memcpy>:
d00858d0:	440a      	add	r2, r1
d00858d2:	4291      	cmp	r1, r2
d00858d4:	f100 33ff 	add.w	r3, r0, #4294967295	; 0xffffffff
d00858d8:	d100      	bne.n	d00858dc <memcpy+0xc>
d00858da:	4770      	bx	lr
d00858dc:	b510      	push	{r4, lr}
d00858de:	f811 4b01 	ldrb.w	r4, [r1], #1
d00858e2:	f803 4f01 	strb.w	r4, [r3, #1]!
d00858e6:	4291      	cmp	r1, r2
d00858e8:	d1f9      	bne.n	d00858de <memcpy+0xe>
d00858ea:	bd10      	pop	{r4, pc}

d00858ec <memmove>:
d00858ec:	4288      	cmp	r0, r1
d00858ee:	b510      	push	{r4, lr}
d00858f0:	eb01 0402 	add.w	r4, r1, r2
d00858f4:	d902      	bls.n	d00858fc <memmove+0x10>
d00858f6:	4284      	cmp	r4, r0
d00858f8:	4623      	mov	r3, r4
d00858fa:	d807      	bhi.n	d008590c <memmove+0x20>
d00858fc:	1e43      	subs	r3, r0, #1
d00858fe:	42a1      	cmp	r1, r4
d0085900:	d008      	beq.n	d0085914 <memmove+0x28>
d0085902:	f811 2b01 	ldrb.w	r2, [r1], #1
d0085906:	f803 2f01 	strb.w	r2, [r3, #1]!
d008590a:	e7f8      	b.n	d00858fe <memmove+0x12>
d008590c:	4402      	add	r2, r0
d008590e:	4601      	mov	r1, r0
d0085910:	428a      	cmp	r2, r1
d0085912:	d100      	bne.n	d0085916 <memmove+0x2a>
d0085914:	bd10      	pop	{r4, pc}
d0085916:	f813 4d01 	ldrb.w	r4, [r3, #-1]!
d008591a:	f802 4d01 	strb.w	r4, [r2, #-1]!
d008591e:	e7f7      	b.n	d0085910 <memmove+0x24>

d0085920 <_realloc_r>:
d0085920:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0085922:	4607      	mov	r7, r0
d0085924:	4614      	mov	r4, r2
d0085926:	460e      	mov	r6, r1
d0085928:	b921      	cbnz	r1, d0085934 <_realloc_r+0x14>
d008592a:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
d008592e:	4611      	mov	r1, r2
d0085930:	f7ff b8ba 	b.w	d0084aa8 <_malloc_r>
d0085934:	b922      	cbnz	r2, d0085940 <_realloc_r+0x20>
d0085936:	f7ff f867 	bl	d0084a08 <_free_r>
d008593a:	4625      	mov	r5, r4
d008593c:	4628      	mov	r0, r5
d008593e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0085940:	f000 f826 	bl	d0085990 <_malloc_usable_size_r>
d0085944:	42a0      	cmp	r0, r4
d0085946:	d20f      	bcs.n	d0085968 <_realloc_r+0x48>
d0085948:	4621      	mov	r1, r4
d008594a:	4638      	mov	r0, r7
d008594c:	f7ff f8ac 	bl	d0084aa8 <_malloc_r>
d0085950:	4605      	mov	r5, r0
d0085952:	2800      	cmp	r0, #0
d0085954:	d0f2      	beq.n	d008593c <_realloc_r+0x1c>
d0085956:	4631      	mov	r1, r6
d0085958:	4622      	mov	r2, r4
d008595a:	f7ff ffb9 	bl	d00858d0 <memcpy>
d008595e:	4631      	mov	r1, r6
d0085960:	4638      	mov	r0, r7
d0085962:	f7ff f851 	bl	d0084a08 <_free_r>
d0085966:	e7e9      	b.n	d008593c <_realloc_r+0x1c>
d0085968:	4635      	mov	r5, r6
d008596a:	e7e7      	b.n	d008593c <_realloc_r+0x1c>

d008596c <_read_r>:
d008596c:	b538      	push	{r3, r4, r5, lr}
d008596e:	4d07      	ldr	r5, [pc, #28]	; (d008598c <_read_r+0x20>)
d0085970:	4604      	mov	r4, r0
d0085972:	4608      	mov	r0, r1
d0085974:	4611      	mov	r1, r2
d0085976:	2200      	movs	r2, #0
d0085978:	602a      	str	r2, [r5, #0]
d008597a:	461a      	mov	r2, r3
d008597c:	f7fa fb9a 	bl	d00800b4 <_read>
d0085980:	1c43      	adds	r3, r0, #1
d0085982:	d102      	bne.n	d008598a <_read_r+0x1e>
d0085984:	682b      	ldr	r3, [r5, #0]
d0085986:	b103      	cbz	r3, d008598a <_read_r+0x1e>
d0085988:	6023      	str	r3, [r4, #0]
d008598a:	bd38      	pop	{r3, r4, r5, pc}
d008598c:	d00c8284 	.word	0xd00c8284

d0085990 <_malloc_usable_size_r>:
d0085990:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0085994:	1f18      	subs	r0, r3, #4
d0085996:	2b00      	cmp	r3, #0
d0085998:	bfbc      	itt	lt
d008599a:	580b      	ldrlt	r3, [r1, r0]
d008599c:	18c0      	addlt	r0, r0, r3
d008599e:	4770      	bx	lr
d00859a0:	00004841 	.word	0x00004841
d00859a4:	00005941 	.word	0x00005941
d00859a8:	00004541 	.word	0x00004541
d00859ac:	00646e61 	.word	0x00646e61
d00859b0:	00657261 	.word	0x00657261
d00859b4:	00004141 	.word	0x00004141
d00859b8:	00005949 	.word	0x00005949
d00859bc:	706d6f63 	.word	0x706d6f63
d00859c0:	72657475 	.word	0x72657475
d00859c4:	00000000 	.word	0x00000000
d00859c8:	00005755 	.word	0x00005755
d00859cc:	00005245 	.word	0x00005245
d00859d0:	69766564 	.word	0x69766564
d00859d4:	00006563 	.word	0x00006563
d00859d8:	00004849 	.word	0x00004849
d00859dc:	6c676e65 	.word	0x6c676e65
d00859e0:	00687369 	.word	0x00687369
d00859e4:	0000474e 	.word	0x0000474e
d00859e8:	00004853 	.word	0x00004853
d00859ec:	6f737065 	.word	0x6f737065
d00859f0:	0000006e 	.word	0x0000006e
d00859f4:	68676965 	.word	0x68676965
d00859f8:	00000074 	.word	0x00000074
d00859fc:	65707365 	.word	0x65707365
d0085a00:	00006b61 	.word	0x00006b61
d0085a04:	65766966 	.word	0x65766966
d0085a08:	00000000 	.word	0x00000000
d0085a0c:	72756f66 	.word	0x72756f66
d0085a10:	00000000 	.word	0x00000000
d0085a14:	6d6f7266 	.word	0x6d6f7266
d0085a18:	00000000 	.word	0x00000000
d0085a1c:	6b776168 	.word	0x6b776168
d0085a20:	00676e69 	.word	0x00676e69
d0085a24:	6b776168 	.word	0x6b776168
d0085a28:	00736e69 	.word	0x00736e69
d0085a2c:	6c6c6568 	.word	0x6c6c6568
d0085a30:	0000006f 	.word	0x0000006f
d0085a34:	6963616d 	.word	0x6963616d
d0085a38:	736f746e 	.word	0x736f746e
d0085a3c:	00000068 	.word	0x00000068
d0085a40:	7272616e 	.word	0x7272616e
d0085a44:	726f7461 	.word	0x726f7461
d0085a48:	00000000 	.word	0x00000000
d0085a4c:	656e696e 	.word	0x656e696e
d0085a50:	00000000 	.word	0x00000000
d0085a54:	00656e6f 	.word	0x00656e6f
d0085a58:	6e6f6870 	.word	0x6e6f6870
d0085a5c:	00656d65 	.word	0x00656d65
d0085a60:	6e6f6870 	.word	0x6e6f6870
d0085a64:	73656d65 	.word	0x73656d65
d0085a68:	00000000 	.word	0x00000000
d0085a6c:	6c617571 	.word	0x6c617571
d0085a70:	00797469 	.word	0x00797469
d0085a74:	62646973 	.word	0x62646973
d0085a78:	0000786f 	.word	0x0000786f
d0085a7c:	61657073 	.word	0x61657073
d0085a80:	0000006b 	.word	0x0000006b
d0085a84:	61657073 	.word	0x61657073
d0085a88:	0000736b 	.word	0x0000736b
d0085a8c:	65657073 	.word	0x65657073
d0085a90:	00006863 	.word	0x00006863
d0085a94:	70657473 	.word	0x70657473
d0085a98:	006e6568 	.word	0x006e6568
d0085a9c:	76657473 	.word	0x76657473
d0085aa0:	00006e65 	.word	0x00006e65
d0085aa4:	76657473 	.word	0x76657473
d0085aa8:	00000065 	.word	0x00000065
d0085aac:	65766573 	.word	0x65766573
d0085ab0:	0000006e 	.word	0x0000006e
d0085ab4:	00786973 	.word	0x00786973
d0085ab8:	746e7973 	.word	0x746e7973
d0085abc:	00000068 	.word	0x00000068
d0085ac0:	746e7973 	.word	0x746e7973
d0085ac4:	69736568 	.word	0x69736568
d0085ac8:	00000073 	.word	0x00000073
d0085acc:	74616874 	.word	0x74616874
d0085ad0:	00000000 	.word	0x00000000
d0085ad4:	00656874 	.word	0x00656874
d0085ad8:	65726874 	.word	0x65726874
d0085adc:	00000065 	.word	0x00000065
d0085ae0:	73696874 	.word	0x73696874
d0085ae4:	00000000 	.word	0x00000000
d0085ae8:	00006f74 	.word	0x00006f74
d0085aec:	006f6f74 	.word	0x006f6f74
d0085af0:	006f7774 	.word	0x006f7774
d0085af4:	63696f76 	.word	0x63696f76
d0085af8:	00000065 	.word	0x00000065
d0085afc:	00736177 	.word	0x00736177
d0085b00:	00756f79 	.word	0x00756f79
d0085b04:	72756f79 	.word	0x72756f79
d0085b08:	00000000 	.word	0x00000000
d0085b0c:	6f72657a 	.word	0x6f72657a
d0085b10:	00000000 	.word	0x00000000
d0085b14:	00005945 	.word	0x00005945
d0085b18:	00005741 	.word	0x00005741
d0085b1c:	00004855 	.word	0x00004855
d0085b20:	0000594f 	.word	0x0000594f
d0085b24:	00004f41 	.word	0x00004f41
d0085b28:	0000574f 	.word	0x0000574f
d0085b2c:	00004845 	.word	0x00004845
d0085b30:	00004843 	.word	0x00004843
d0085b34:	00006873 	.word	0x00006873
d0085b38:	00004854 	.word	0x00004854
d0085b3c:	00006870 	.word	0x00006870
d0085b40:	0000676e 	.word	0x0000676e
d0085b44:	00006b63 	.word	0x00006b63
d0085b48:	00007571 	.word	0x00007571
d0085b4c:	00006e6b 	.word	0x00006e6b
d0085b50:	00007277 	.word	0x00007277
d0085b54:	00006e67 	.word	0x00006e67
d0085b58:	6c6c6568 	.word	0x6c6c6568
d0085b5c:	7266206f 	.word	0x7266206f
d0085b60:	73206d6f 	.word	0x73206d6f
d0085b64:	6f626469 	.word	0x6f626469
d0085b68:	70732078 	.word	0x70732078
d0085b6c:	68636565 	.word	0x68636565
d0085b70:	6e797320 	.word	0x6e797320
d0085b74:	00006874 	.word	0x00006874
d0085b78:	0000005f 	.word	0x0000005f
d0085b7c:	00000042 	.word	0x00000042
d0085b80:	00000044 	.word	0x00000044
d0085b84:	00004844 	.word	0x00004844
d0085b88:	00000046 	.word	0x00000046
d0085b8c:	00000047 	.word	0x00000047
d0085b90:	00004848 	.word	0x00004848
d0085b94:	0000484a 	.word	0x0000484a
d0085b98:	0000004b 	.word	0x0000004b
d0085b9c:	0000004c 	.word	0x0000004c
d0085ba0:	0000004d 	.word	0x0000004d
d0085ba4:	0000004e 	.word	0x0000004e
d0085ba8:	00000050 	.word	0x00000050
d0085bac:	00000052 	.word	0x00000052
d0085bb0:	00000053 	.word	0x00000053
d0085bb4:	00000054 	.word	0x00000054
d0085bb8:	00000056 	.word	0x00000056
d0085bbc:	00000057 	.word	0x00000057
d0085bc0:	00000059 	.word	0x00000059
d0085bc4:	0000005a 	.word	0x0000005a
d0085bc8:	0000485a 	.word	0x0000485a

d0085bcc <CSWTCH.137>:
d0085bcc:	7070708e 96707070 70707070 70707084     .pppppp.pppp.ppp
d0085bdc:	000000a0                                ....

d0085be0 <CSWTCH.139>:
d0085be0:	00000208 000001e0 000001e0 000001e0     ................
d0085bf0:	000001e0 000001e0 000001e0 000002bc     ................
d0085c00:	000001e0 000001e0 000001e0 000001e0     ................
d0085c10:	00000258 000001e0 000001e0 000001e0     X...............
d0085c20:	000002f8                                ....

d0085c24 <CSWTCH.141>:
d0085c24:	00000060 00000056 00000056 00000056     `...V...V...V...
d0085c34:	00000056 0000004e 00000056 00000056     V...N...V...V...
d0085c44:	00000056 00000069                       V...i...

d0085c4c <digits.6184>:
d0085c4c:	d0085b0c d0085a54 d0085af0 d0085ad8     .[..TZ...Z...Z..
d0085c5c:	d0085a0c d0085a04 d0085ab4 d0085aac     .Z...Z...Z...Z..
d0085c6c:	d00859f4 d0085a4c                       .Y..LZ..

d0085c74 <flutter.6421>:
d0085c74:	02010100 feff0001 0100fffe 00010202     ................
d0085c84:	fefdfeff 010100ff 00ffff00 00010201     ................

d0085c94 <phone_specs>:
d0085c94:	d0085b78 00000000 00000000 00000000     x[..............
d0085ca4:	0000002d d00859a0 04d802d0 4e7009f6     -....Y........pN
d0085cb4:	00010526 00000078 d00859a8 06b802b2     &...x....Y......
d0085cc4:	5c7009c4 00010328 00000082 d00859b4     ..p\(........Y..
d0085cd4:	046002f8 42740992 00010324 00000087     ..`...tB$.......
d0085ce4:	d0085b24 03a20230 3e700988 00010322     $[..0.....p>"...
d0085cf4:	00000087 d0085b2c 07300230 626a09b0     ....,[..0.0...jb
d0085d04:	0001032a 00000078 d00859cc 052801d6     *...x....Y....(.
d0085d14:	4c6c06ae 0011024e 00000091 d00859d8     ..lLN........Y..
d0085d24:	07c60186 6c620a28 00010230 00000069     ....(.bl0...i...
d0085d34:	d00859b8 08ca012c 765a0b68 00010138     .Y..,...h.Zv8...
d0085d44:	0000007d d0085b1c 046001cc 4260094c     }....[....`.L.`B
d0085d54:	00010222 00000069 d00859c8 0384014a     "...i....Y..J...
d0085d64:	405808c0 00010124 00000082 d0085b14     ..X@$........[..
d0085d74:	080201b8 6e620a64 0001012e 00000050     ....d.bn....P...
d0085d84:	d00859a4 05dc028a 547009f6 0001022a     .Y........pT*...
d0085d94:	00000055 d0085b28 03b601f4 46680960     U...([......`.hF
d0085da4:	00010126 0000005a d0085b18 04d802d0     &...Z....[......
d0085db4:	4a70099c 00010226 0000005a d0085b20     ..pJ&...Z... [..
d0085dc4:	04100230 4a6a0974 00010226 0000005a     0...t.jJ&...Z...
d0085dd4:	d0085b7c 02d00104 1e460898 00050812     |[........F.....
d0085de4:	0000003e d0085b30 075801ae 40280b2c     >...0[....X.,.(@
d0085df4:	00065c54 00000056 d0085b80 06540136     T\..V....[..6.T.
d0085e04:	2e3e0a28 0005081a 0000003a d0085b84     (.>.....:....[..
d0085e14:	058c0154 263209ec 00032a19 00000048     T.....2&.*..H...
d0085e24:	d0085b88 04c4012c 18120ce4 00026e5c     .[..,.......\n..
d0085e34:	00000056 d0085b8c 0460012c 263e0992     V....[..,.`...>&
d0085e44:	00050816 00000040 d0085b90 05dc0208     ....@....[......
d0085e54:	202a0a8c 00022e1e 00000041 d0085b94     ..* ....A....[..
d0085e64:	071c01ae 40300abe 00073a46 00000056     ......0@F:..V...
d0085e74:	d0085b98 0604014a 2c1a0a8c 0004764e     .[..J......,Nv..
d0085e84:	0000004c d0085b9c 04380168 385c0a28     L....[..h.8.(.\8
d0085e94:	0011011e 00000052 d0085ba0 03d400fa     ....R....[......
d0085ea4:	20680834 00090110 00000052 d0085ba4     4.h ....R....[..
d0085eb4:	05780118 2c6009c4 00090116 0000004c     ..x...`,....L...
d0085ec4:	d00859e4 0460012c 265e094c 00090114     .Y..,.`.L.^&....
d0085ed4:	0000005c d0085ba8 03840104 18120960     \....[......`...
d0085ee4:	0004703c 00000048 d0085bac 04b00168     <p..H....[..h...
d0085ef4:	3e540690 00110152 0000005a d0085bb0     ..T>R...Z....[..
d0085f04:	06a4014a 12081004 00027d7c 0000005c     J.......|}..\...
d0085f14:	d00859e8 05dc0168 260c0b86 00027674     .Y..h......&tv..
d0085f24:	00000064 d0085bb4 06a4014a 24120ce4     d....[..J......$
d0085f34:	0004825c 00000040 d0085b38 05280154     \...@...8[..T.(.
d0085f44:	1e120c1c 00025c62 0000004e d0085bb8     ....b\..N....[..
d0085f54:	04c4012c 1c1e0ce4 00034852 00000050     ,.......RH..P...
d0085f64:	d0085bbc 02f8012c 365208ac 0011011c     .[..,.....R6....
d0085f74:	00000048 d0085bc0 08340118 6c460b68     H....[....4.h.Fl
d0085f84:	0011012e 00000046 d0085bc4 06a4014a     ....F....[..J...
d0085f94:	1a181004 00035070 00000056 d0085bc8     ....pP..V....[..
d0085fa4:	05f00168 2a180bb8 00034b6c 0000005a     h......*lK..Z...
d0085fb4:	45455053 53204843 48544e59 00000000     SPEECH SYNTH....
d0085fc4:	4d524148 43494e4f 41524620 5620454d     HARMONIC FRAME V
d0085fd4:	4543494f 00000000 20756c25 706d6173     OICE....%lu samp
d0085fe4:	2073656c 25207461 7a682075 00000000     les at %u hz....
d0085ff4:	45524946 6572203a 79616c70 00000000     FIRE: replay....
d0086004:	6c6c6548 54202e6f 20736968 74207369     Hello. This is t
d0086014:	53206568 4f424449 70732058 68636565     he SIDBOX speech
d0086024:	6e797320 202e6874 74207449 736e7275      synth. It turns
d0086034:	676e4520 6873696c 746e6920 6870206f      English into ph
d0086044:	6d656e6f 202c7365 20646e61 61657073     onemes, and spea
d0086054:	7720736b 20687469 6f662061 6e616d72     ks with a forman
d0086064:	6f762074 2e656369 00000000              t voice.....

d0086070 <_global_impure_ptr>:
d0086070:	d0086118                                .a..

d0086074 <__sf_fake_stderr>:
	...

d0086094 <__sf_fake_stdin>:
	...

d00860b4 <__sf_fake_stdout>:
	...
d00860d4:	2b302d23 6c680020 6665004c 47464567     #-0+ .hlL.efgEFG
d00860e4:	32313000 36353433 41393837 45444342     .0123456789ABCDE
d00860f4:	31300046 35343332 39383736 64636261     F.0123456789abcd
d0086104:	                                         ef.

Disassembly of section .init:

d0086108 <_init>:
d0086108:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008610a:	bf00      	nop

Disassembly of section .fini:

d008610c <_fini>:
d008610c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d008610e:	bf00      	nop
