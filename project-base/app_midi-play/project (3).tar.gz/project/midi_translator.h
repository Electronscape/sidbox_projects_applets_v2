#ifndef MIDI_TRANSLATOR_H
#define MIDI_TRANSLATOR_H

#include <stdbool.h>
#include <stdint.h>

typedef enum {
    MIDI_TRANSLATOR_RAW = 0,
    MIDI_TRANSLATOR_MT32,
    MIDI_TRANSLATOR_PSR84
} MidiTranslatorProfile;

typedef bool (*MidiTranslatorSendFn)(const uint8_t *data, uint8_t len, bool urgent, void *user);

const char *midi_translator_profile_name(MidiTranslatorProfile profile);

void midi_translator_reset_state(void);
void midi_translator_send_setup_burst(MidiTranslatorProfile profile, MidiTranslatorSendFn send, void *user);

bool midi_translator_accepts_sysex(MidiTranslatorProfile profile, uint8_t status, const uint8_t *data, uint32_t len);
bool midi_translator_translate_voice_packet(MidiTranslatorProfile profile, uint8_t *packet, uint8_t *packet_len);
bool midi_translator_send_voice_packet(MidiTranslatorProfile profile, const uint8_t *packet, uint8_t packet_len, MidiTranslatorSendFn send, void *user);

#endif
