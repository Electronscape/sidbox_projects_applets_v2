
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0080010 <applet_entry>:
d0080010:	b570      	push	{r4, r5, r6, lr}
d0080012:	4e09      	ldr	r6, [pc, #36]	; (d0080038 <applet_entry+0x28>)
d0080014:	460d      	mov	r5, r1
d0080016:	4604      	mov	r4, r0
d0080018:	2100      	movs	r1, #0
d008001a:	6833      	ldr	r3, [r6, #0]
d008001c:	6898      	ldr	r0, [r3, #8]
d008001e:	f001 f851 	bl	d00810c4 <setbuf>
d0080022:	6833      	ldr	r3, [r6, #0]
d0080024:	2100      	movs	r1, #0
d0080026:	68d8      	ldr	r0, [r3, #12]
d0080028:	f001 f84c 	bl	d00810c4 <setbuf>
d008002c:	4629      	mov	r1, r5
d008002e:	4620      	mov	r0, r4
d0080030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0080034:	f000 bb90 	b.w	d0080758 <main>
d0080038:	d0087724 	.word	0xd0087724

d008003c <gfx_createBitmap>:
d008003c:	b510      	push	{r4, lr}
d008003e:	4604      	mov	r4, r0
d0080040:	fb01 f002 	mul.w	r0, r1, r2
d0080044:	b292      	uxth	r2, r2
d0080046:	80a1      	strh	r1, [r4, #4]
d0080048:	60e0      	str	r0, [r4, #12]
d008004a:	80e2      	strh	r2, [r4, #6]
d008004c:	8122      	strh	r2, [r4, #8]
d008004e:	f000 ff7f 	bl	d0080f50 <malloc>
d0080052:	6020      	str	r0, [r4, #0]
d0080054:	bd10      	pop	{r4, pc}
d0080056:	bf00      	nop

d0080058 <initMalloc>:
d0080058:	4902      	ldr	r1, [pc, #8]	; (d0080064 <initMalloc+0xc>)
d008005a:	4b03      	ldr	r3, [pc, #12]	; (d0080068 <initMalloc+0x10>)
d008005c:	4a03      	ldr	r2, [pc, #12]	; (d008006c <initMalloc+0x14>)
d008005e:	1a5b      	subs	r3, r3, r1
d0080060:	6013      	str	r3, [r2, #0]
d0080062:	4770      	bx	lr
d0080064:	d0089a78 	.word	0xd0089a78
d0080068:	d0600000 	.word	0xd0600000
d008006c:	d0087a08 	.word	0xd0087a08

d0080070 <_write_r>:
d0080070:	3901      	subs	r1, #1
d0080072:	2901      	cmp	r1, #1
d0080074:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0080076:	d81f      	bhi.n	d00800b8 <_write_r+0x48>
d0080078:	b1e2      	cbz	r2, d00800b4 <_write_r+0x44>
d008007a:	461c      	mov	r4, r3
d008007c:	b1d3      	cbz	r3, d00800b4 <_write_r+0x44>
d008007e:	4d12      	ldr	r5, [pc, #72]	; (d00800c8 <_write_r+0x58>)
d0080080:	682e      	ldr	r6, [r5, #0]
d0080082:	b9ae      	cbnz	r6, d00800b0 <_write_r+0x40>
d0080084:	4f11      	ldr	r7, [pc, #68]	; (d00800cc <_write_r+0x5c>)
d0080086:	2301      	movs	r3, #1
d0080088:	4611      	mov	r1, r2
d008008a:	4630      	mov	r0, r6
d008008c:	602b      	str	r3, [r5, #0]
d008008e:	4622      	mov	r2, r4
d0080090:	7a3b      	ldrb	r3, [r7, #8]
d0080092:	f897 c009 	ldrb.w	ip, [r7, #9]
d0080096:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d008009a:	f897 c00a 	ldrb.w	ip, [r7, #10]
d008009e:	7aff      	ldrb	r7, [r7, #11]
d00800a0:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d00800a4:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d00800a8:	681b      	ldr	r3, [r3, #0]
d00800aa:	685b      	ldr	r3, [r3, #4]
d00800ac:	4798      	blx	r3
d00800ae:	602e      	str	r6, [r5, #0]
d00800b0:	4620      	mov	r0, r4
d00800b2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800b4:	2000      	movs	r0, #0
d00800b6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800b8:	f000 ff44 	bl	d0080f44 <__errno>
d00800bc:	2209      	movs	r2, #9
d00800be:	4603      	mov	r3, r0
d00800c0:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800c4:	601a      	str	r2, [r3, #0]
d00800c6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00800c8:	d00877a4 	.word	0xd00877a4
d00800cc:	2001f000 	.word	0x2001f000

d00800d0 <_read>:
d00800d0:	b508      	push	{r3, lr}
d00800d2:	f000 ff37 	bl	d0080f44 <__errno>
d00800d6:	2258      	movs	r2, #88	; 0x58
d00800d8:	4603      	mov	r3, r0
d00800da:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800de:	601a      	str	r2, [r3, #0]
d00800e0:	bd08      	pop	{r3, pc}
d00800e2:	bf00      	nop

d00800e4 <_close>:
d00800e4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00800e8:	4770      	bx	lr
d00800ea:	bf00      	nop

d00800ec <_fstat>:
d00800ec:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d00800f0:	2000      	movs	r0, #0
d00800f2:	604b      	str	r3, [r1, #4]
d00800f4:	4770      	bx	lr
d00800f6:	bf00      	nop

d00800f8 <_lseek>:
d00800f8:	2000      	movs	r0, #0
d00800fa:	4770      	bx	lr

d00800fc <_sbrk_r>:
d00800fc:	4b0c      	ldr	r3, [pc, #48]	; (d0080130 <_sbrk_r+0x34>)
d00800fe:	4a0d      	ldr	r2, [pc, #52]	; (d0080134 <_sbrk_r+0x38>)
d0080100:	6818      	ldr	r0, [r3, #0]
d0080102:	b510      	push	{r4, lr}
d0080104:	b918      	cbnz	r0, d008010e <_sbrk_r+0x12>
d0080106:	1dd0      	adds	r0, r2, #7
d0080108:	f020 0007 	bic.w	r0, r0, #7
d008010c:	6018      	str	r0, [r3, #0]
d008010e:	4401      	add	r1, r0
d0080110:	4c09      	ldr	r4, [pc, #36]	; (d0080138 <_sbrk_r+0x3c>)
d0080112:	42a1      	cmp	r1, r4
d0080114:	d803      	bhi.n	d008011e <_sbrk_r+0x22>
d0080116:	4291      	cmp	r1, r2
d0080118:	d301      	bcc.n	d008011e <_sbrk_r+0x22>
d008011a:	6019      	str	r1, [r3, #0]
d008011c:	bd10      	pop	{r4, pc}
d008011e:	f000 ff11 	bl	d0080f44 <__errno>
d0080122:	220c      	movs	r2, #12
d0080124:	4603      	mov	r3, r0
d0080126:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008012a:	601a      	str	r2, [r3, #0]
d008012c:	bd10      	pop	{r4, pc}
d008012e:	bf00      	nop
d0080130:	d00877a0 	.word	0xd00877a0
d0080134:	d0089a78 	.word	0xd0089a78
d0080138:	d0600000 	.word	0xd0600000

d008013c <draw_star_speed_range>:
d008013c:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0080140:	4c30      	ldr	r4, [pc, #192]	; (d0080204 <draw_star_speed_range+0xc8>)
d0080142:	2501      	movs	r5, #1
d0080144:	4606      	mov	r6, r0
d0080146:	460f      	mov	r7, r1
d0080148:	f8df 80bc 	ldr.w	r8, [pc, #188]	; d0080208 <draw_star_speed_range+0xcc>
d008014c:	f8df a0bc 	ldr.w	sl, [pc, #188]	; d008020c <draw_star_speed_range+0xd0>
d0080150:	7923      	ldrb	r3, [r4, #4]
d0080152:	42b3      	cmp	r3, r6
d0080154:	d34e      	bcc.n	d00801f4 <draw_star_speed_range+0xb8>
d0080156:	42bb      	cmp	r3, r7
d0080158:	d84c      	bhi.n	d00801f4 <draw_star_speed_range+0xb8>
d008015a:	f8df 90b4 	ldr.w	r9, [pc, #180]	; d0080210 <draw_star_speed_range+0xd4>
d008015e:	7960      	ldrb	r0, [r4, #5]
d0080160:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080164:	f899 100d 	ldrb.w	r1, [r9, #13]
d0080168:	f899 c00e 	ldrb.w	ip, [r9, #14]
d008016c:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d0080170:	f899 100f 	ldrb.w	r1, [r9, #15]
d0080174:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0080178:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d008017c:	685b      	ldr	r3, [r3, #4]
d008017e:	68db      	ldr	r3, [r3, #12]
d0080180:	4798      	blx	r3
d0080182:	f894 b004 	ldrb.w	fp, [r4, #4]
d0080186:	f1bb 0f08 	cmp.w	fp, #8
d008018a:	f200 82b2 	bhi.w	d00806f2 <draw_star_speed_range+0x5b6>
d008018e:	f1bb 0f06 	cmp.w	fp, #6
d0080192:	f200 82b1 	bhi.w	d00806f8 <draw_star_speed_range+0x5bc>
d0080196:	f1bb 0f04 	cmp.w	fp, #4
d008019a:	d83b      	bhi.n	d0080214 <draw_star_speed_range+0xd8>
d008019c:	f1bb 0f02 	cmp.w	fp, #2
d00801a0:	f200 82b7 	bhi.w	d0080712 <draw_star_speed_range+0x5d6>
d00801a4:	d038      	beq.n	d0080218 <draw_star_speed_range+0xdc>
d00801a6:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d00801aa:	f9b4 0000 	ldrsh.w	r0, [r4]
d00801ae:	f1a1 0c26 	sub.w	ip, r1, #38	; 0x26
d00801b2:	b283      	uxth	r3, r0
d00801b4:	fa1f fc8c 	uxth.w	ip, ip
d00801b8:	f5bc 7f8d 	cmp.w	ip, #282	; 0x11a
d00801bc:	f080 819f 	bcs.w	d00804fe <draw_star_speed_range+0x3c2>
d00801c0:	f5b3 7ff0 	cmp.w	r3, #480	; 0x1e0
d00801c4:	f080 819b 	bcs.w	d00804fe <draw_star_speed_range+0x3c2>
d00801c8:	f899 300c 	ldrb.w	r3, [r9, #12]
d00801cc:	f899 e00d 	ldrb.w	lr, [r9, #13]
d00801d0:	f899 c00e 	ldrb.w	ip, [r9, #14]
d00801d4:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d00801d8:	f899 e00f 	ldrb.w	lr, [r9, #15]
d00801dc:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d00801e0:	ea43 630e 	orr.w	r3, r3, lr, lsl #24
d00801e4:	e185      	b.n	d00804f2 <draw_star_speed_range+0x3b6>
d00801e6:	285b      	cmp	r0, #91	; 0x5b
d00801e8:	f240 82ad 	bls.w	d0080746 <draw_star_speed_range+0x60a>
d00801ec:	2209      	movs	r2, #9
d00801ee:	2302      	movs	r3, #2
d00801f0:	7122      	strb	r2, [r4, #4]
d00801f2:	7163      	strb	r3, [r4, #5]
d00801f4:	2d60      	cmp	r5, #96	; 0x60
d00801f6:	f000 82a4 	beq.w	d0080742 <draw_star_speed_range+0x606>
d00801fa:	3501      	adds	r5, #1
d00801fc:	3406      	adds	r4, #6
d00801fe:	b2ed      	uxtb	r5, r5
d0080200:	e7a6      	b.n	d0080150 <draw_star_speed_range+0x14>
d0080202:	bf00      	nop
d0080204:	d00877c0 	.word	0xd00877c0
d0080208:	41c64e6d 	.word	0x41c64e6d
d008020c:	11a3019b 	.word	0x11a3019b
d0080210:	2001f000 	.word	0x2001f000
d0080214:	f04f 0b05 	mov.w	fp, #5
d0080218:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d008021c:	f9b4 0000 	ldrsh.w	r0, [r4]
d0080220:	f1a1 0326 	sub.w	r3, r1, #38	; 0x26
d0080224:	b29b      	uxth	r3, r3
d0080226:	f5b3 7f8d 	cmp.w	r3, #282	; 0x11a
d008022a:	d219      	bcs.n	d0080260 <draw_star_speed_range+0x124>
d008022c:	fa1f fc80 	uxth.w	ip, r0
d0080230:	f5bc 7ff0 	cmp.w	ip, #480	; 0x1e0
d0080234:	d216      	bcs.n	d0080264 <draw_star_speed_range+0x128>
d0080236:	f899 300c 	ldrb.w	r3, [r9, #12]
d008023a:	f899 e00d 	ldrb.w	lr, [r9, #13]
d008023e:	f899 c00e 	ldrb.w	ip, [r9, #14]
d0080242:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d0080246:	f899 e00f 	ldrb.w	lr, [r9, #15]
d008024a:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d008024e:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d0080252:	685b      	ldr	r3, [r3, #4]
d0080254:	689b      	ldr	r3, [r3, #8]
d0080256:	4798      	blx	r3
d0080258:	f9b4 0000 	ldrsh.w	r0, [r4]
d008025c:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d0080260:	fa1f fc80 	uxth.w	ip, r0
d0080264:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d0080268:	f10c 0001 	add.w	r0, ip, #1
d008026c:	4663      	mov	r3, ip
d008026e:	fa1f fe8e 	uxth.w	lr, lr
d0080272:	b280      	uxth	r0, r0
d0080274:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d0080278:	d219      	bcs.n	d00802ae <draw_star_speed_range+0x172>
d008027a:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d008027e:	d216      	bcs.n	d00802ae <draw_star_speed_range+0x172>
d0080280:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080284:	b200      	sxth	r0, r0
d0080286:	f899 e00d 	ldrb.w	lr, [r9, #13]
d008028a:	f899 c00e 	ldrb.w	ip, [r9, #14]
d008028e:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d0080292:	f899 e00f 	ldrb.w	lr, [r9, #15]
d0080296:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d008029a:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d008029e:	685b      	ldr	r3, [r3, #4]
d00802a0:	689b      	ldr	r3, [r3, #8]
d00802a2:	4798      	blx	r3
d00802a4:	f9b4 0000 	ldrsh.w	r0, [r4]
d00802a8:	fa1f fc80 	uxth.w	ip, r0
d00802ac:	4663      	mov	r3, ip
d00802ae:	f1bb 0f02 	cmp.w	fp, #2
d00802b2:	f000 8122 	beq.w	d00804fa <draw_star_speed_range+0x3be>
d00802b6:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d00802ba:	f10c 0002 	add.w	r0, ip, #2
d00802be:	4663      	mov	r3, ip
d00802c0:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d00802c4:	b280      	uxth	r0, r0
d00802c6:	fa1f fe8e 	uxth.w	lr, lr
d00802ca:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d00802ce:	d219      	bcs.n	d0080304 <draw_star_speed_range+0x1c8>
d00802d0:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d00802d4:	d216      	bcs.n	d0080304 <draw_star_speed_range+0x1c8>
d00802d6:	f899 300c 	ldrb.w	r3, [r9, #12]
d00802da:	b200      	sxth	r0, r0
d00802dc:	f899 e00d 	ldrb.w	lr, [r9, #13]
d00802e0:	f899 c00e 	ldrb.w	ip, [r9, #14]
d00802e4:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d00802e8:	f899 e00f 	ldrb.w	lr, [r9, #15]
d00802ec:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d00802f0:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d00802f4:	685b      	ldr	r3, [r3, #4]
d00802f6:	689b      	ldr	r3, [r3, #8]
d00802f8:	4798      	blx	r3
d00802fa:	f9b4 0000 	ldrsh.w	r0, [r4]
d00802fe:	fa1f fc80 	uxth.w	ip, r0
d0080302:	4663      	mov	r3, ip
d0080304:	f1bb 0f03 	cmp.w	fp, #3
d0080308:	f000 80f7 	beq.w	d00804fa <draw_star_speed_range+0x3be>
d008030c:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d0080310:	f10c 0003 	add.w	r0, ip, #3
d0080314:	4663      	mov	r3, ip
d0080316:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d008031a:	b280      	uxth	r0, r0
d008031c:	fa1f fe8e 	uxth.w	lr, lr
d0080320:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d0080324:	d219      	bcs.n	d008035a <draw_star_speed_range+0x21e>
d0080326:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d008032a:	d216      	bcs.n	d008035a <draw_star_speed_range+0x21e>
d008032c:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080330:	b200      	sxth	r0, r0
d0080332:	f899 e00d 	ldrb.w	lr, [r9, #13]
d0080336:	f899 c00e 	ldrb.w	ip, [r9, #14]
d008033a:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d008033e:	f899 e00f 	ldrb.w	lr, [r9, #15]
d0080342:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d0080346:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d008034a:	685b      	ldr	r3, [r3, #4]
d008034c:	689b      	ldr	r3, [r3, #8]
d008034e:	4798      	blx	r3
d0080350:	f9b4 0000 	ldrsh.w	r0, [r4]
d0080354:	fa1f fc80 	uxth.w	ip, r0
d0080358:	4663      	mov	r3, ip
d008035a:	f1bb 0f04 	cmp.w	fp, #4
d008035e:	f000 80cc 	beq.w	d00804fa <draw_star_speed_range+0x3be>
d0080362:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d0080366:	f10c 0004 	add.w	r0, ip, #4
d008036a:	4663      	mov	r3, ip
d008036c:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d0080370:	b280      	uxth	r0, r0
d0080372:	fa1f fe8e 	uxth.w	lr, lr
d0080376:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d008037a:	d219      	bcs.n	d00803b0 <draw_star_speed_range+0x274>
d008037c:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d0080380:	d216      	bcs.n	d00803b0 <draw_star_speed_range+0x274>
d0080382:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080386:	b200      	sxth	r0, r0
d0080388:	f899 e00d 	ldrb.w	lr, [r9, #13]
d008038c:	f899 c00e 	ldrb.w	ip, [r9, #14]
d0080390:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d0080394:	f899 e00f 	ldrb.w	lr, [r9, #15]
d0080398:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d008039c:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d00803a0:	685b      	ldr	r3, [r3, #4]
d00803a2:	689b      	ldr	r3, [r3, #8]
d00803a4:	4798      	blx	r3
d00803a6:	f9b4 0000 	ldrsh.w	r0, [r4]
d00803aa:	fa1f fc80 	uxth.w	ip, r0
d00803ae:	4663      	mov	r3, ip
d00803b0:	f1bb 0f05 	cmp.w	fp, #5
d00803b4:	f000 80a1 	beq.w	d00804fa <draw_star_speed_range+0x3be>
d00803b8:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d00803bc:	f10c 0005 	add.w	r0, ip, #5
d00803c0:	4663      	mov	r3, ip
d00803c2:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d00803c6:	b280      	uxth	r0, r0
d00803c8:	fa1f fe8e 	uxth.w	lr, lr
d00803cc:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d00803d0:	d219      	bcs.n	d0080406 <draw_star_speed_range+0x2ca>
d00803d2:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d00803d6:	d216      	bcs.n	d0080406 <draw_star_speed_range+0x2ca>
d00803d8:	f899 300c 	ldrb.w	r3, [r9, #12]
d00803dc:	b200      	sxth	r0, r0
d00803de:	f899 e00d 	ldrb.w	lr, [r9, #13]
d00803e2:	f899 c00e 	ldrb.w	ip, [r9, #14]
d00803e6:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d00803ea:	f899 e00f 	ldrb.w	lr, [r9, #15]
d00803ee:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d00803f2:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d00803f6:	685b      	ldr	r3, [r3, #4]
d00803f8:	689b      	ldr	r3, [r3, #8]
d00803fa:	4798      	blx	r3
d00803fc:	f9b4 0000 	ldrsh.w	r0, [r4]
d0080400:	fa1f fc80 	uxth.w	ip, r0
d0080404:	4663      	mov	r3, ip
d0080406:	f1bb 0f06 	cmp.w	fp, #6
d008040a:	d076      	beq.n	d00804fa <draw_star_speed_range+0x3be>
d008040c:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d0080410:	f10c 0006 	add.w	r0, ip, #6
d0080414:	4663      	mov	r3, ip
d0080416:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d008041a:	b280      	uxth	r0, r0
d008041c:	fa1f fe8e 	uxth.w	lr, lr
d0080420:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d0080424:	d219      	bcs.n	d008045a <draw_star_speed_range+0x31e>
d0080426:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d008042a:	d216      	bcs.n	d008045a <draw_star_speed_range+0x31e>
d008042c:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080430:	b200      	sxth	r0, r0
d0080432:	f899 e00d 	ldrb.w	lr, [r9, #13]
d0080436:	f899 c00e 	ldrb.w	ip, [r9, #14]
d008043a:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d008043e:	f899 e00f 	ldrb.w	lr, [r9, #15]
d0080442:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d0080446:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d008044a:	685b      	ldr	r3, [r3, #4]
d008044c:	689b      	ldr	r3, [r3, #8]
d008044e:	4798      	blx	r3
d0080450:	f9b4 0000 	ldrsh.w	r0, [r4]
d0080454:	fa1f fc80 	uxth.w	ip, r0
d0080458:	4663      	mov	r3, ip
d008045a:	f1bb 0f07 	cmp.w	fp, #7
d008045e:	d04c      	beq.n	d00804fa <draw_star_speed_range+0x3be>
d0080460:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d0080464:	f10c 0007 	add.w	r0, ip, #7
d0080468:	4663      	mov	r3, ip
d008046a:	f1a1 0e26 	sub.w	lr, r1, #38	; 0x26
d008046e:	b280      	uxth	r0, r0
d0080470:	fa1f fe8e 	uxth.w	lr, lr
d0080474:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d0080478:	d219      	bcs.n	d00804ae <draw_star_speed_range+0x372>
d008047a:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d008047e:	d216      	bcs.n	d00804ae <draw_star_speed_range+0x372>
d0080480:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080484:	b200      	sxth	r0, r0
d0080486:	f899 e00d 	ldrb.w	lr, [r9, #13]
d008048a:	f899 c00e 	ldrb.w	ip, [r9, #14]
d008048e:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d0080492:	f899 e00f 	ldrb.w	lr, [r9, #15]
d0080496:	ea43 4c0c 	orr.w	ip, r3, ip, lsl #16
d008049a:	ea4c 630e 	orr.w	r3, ip, lr, lsl #24
d008049e:	685b      	ldr	r3, [r3, #4]
d00804a0:	689b      	ldr	r3, [r3, #8]
d00804a2:	4798      	blx	r3
d00804a4:	f9b4 0000 	ldrsh.w	r0, [r4]
d00804a8:	fa1f fc80 	uxth.w	ip, r0
d00804ac:	4663      	mov	r3, ip
d00804ae:	f1bb 0f09 	cmp.w	fp, #9
d00804b2:	d122      	bne.n	d00804fa <draw_star_speed_range+0x3be>
d00804b4:	f9b4 1002 	ldrsh.w	r1, [r4, #2]
d00804b8:	4663      	mov	r3, ip
d00804ba:	f1a1 0c26 	sub.w	ip, r1, #38	; 0x26
d00804be:	f103 0008 	add.w	r0, r3, #8
d00804c2:	fa1f fc8c 	uxth.w	ip, ip
d00804c6:	b280      	uxth	r0, r0
d00804c8:	f5bc 7f8d 	cmp.w	ip, #282	; 0x11a
d00804cc:	d215      	bcs.n	d00804fa <draw_star_speed_range+0x3be>
d00804ce:	f5b0 7ff0 	cmp.w	r0, #480	; 0x1e0
d00804d2:	d212      	bcs.n	d00804fa <draw_star_speed_range+0x3be>
d00804d4:	f899 300c 	ldrb.w	r3, [r9, #12]
d00804d8:	b200      	sxth	r0, r0
d00804da:	f899 c00d 	ldrb.w	ip, [r9, #13]
d00804de:	f899 b00e 	ldrb.w	fp, [r9, #14]
d00804e2:	ea43 2e0c 	orr.w	lr, r3, ip, lsl #8
d00804e6:	f899 300f 	ldrb.w	r3, [r9, #15]
d00804ea:	ea4e 4c0b 	orr.w	ip, lr, fp, lsl #16
d00804ee:	ea4c 6303 	orr.w	r3, ip, r3, lsl #24
d00804f2:	685b      	ldr	r3, [r3, #4]
d00804f4:	689b      	ldr	r3, [r3, #8]
d00804f6:	4798      	blx	r3
d00804f8:	8823      	ldrh	r3, [r4, #0]
d00804fa:	f894 b004 	ldrb.w	fp, [r4, #4]
d00804fe:	f1bb 0f06 	cmp.w	fp, #6
d0080502:	f240 80e6 	bls.w	d00806d2 <draw_star_speed_range+0x596>
d0080506:	1c58      	adds	r0, r3, #1
d0080508:	8861      	ldrh	r1, [r4, #2]
d008050a:	f240 1bdf 	movw	fp, #479	; 0x1df
d008050e:	fa1f fc80 	uxth.w	ip, r0
d0080512:	f1a1 0e27 	sub.w	lr, r1, #39	; 0x27
d0080516:	b200      	sxth	r0, r0
d0080518:	45dc      	cmp	ip, fp
d008051a:	bf94      	ite	ls
d008051c:	2200      	movls	r2, #0
d008051e:	2201      	movhi	r2, #1
d0080520:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d0080524:	d21e      	bcs.n	d0080564 <draw_star_speed_range+0x428>
d0080526:	b9ea      	cbnz	r2, d0080564 <draw_star_speed_range+0x428>
d0080528:	f899 300c 	ldrb.w	r3, [r9, #12]
d008052c:	3901      	subs	r1, #1
d008052e:	f899 e00d 	ldrb.w	lr, [r9, #13]
d0080532:	f899 c00e 	ldrb.w	ip, [r9, #14]
d0080536:	b209      	sxth	r1, r1
d0080538:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d008053c:	f899 e00f 	ldrb.w	lr, [r9, #15]
d0080540:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0080544:	ea43 6c0e 	orr.w	ip, r3, lr, lsl #24
d0080548:	f8dc 3004 	ldr.w	r3, [ip, #4]
d008054c:	689b      	ldr	r3, [r3, #8]
d008054e:	4798      	blx	r3
d0080550:	8823      	ldrh	r3, [r4, #0]
d0080552:	8861      	ldrh	r1, [r4, #2]
d0080554:	1c58      	adds	r0, r3, #1
d0080556:	fa1f fc80 	uxth.w	ip, r0
d008055a:	b200      	sxth	r0, r0
d008055c:	45dc      	cmp	ip, fp
d008055e:	bf94      	ite	ls
d0080560:	2200      	movls	r2, #0
d0080562:	2201      	movhi	r2, #1
d0080564:	f1a1 0e25 	sub.w	lr, r1, #37	; 0x25
d0080568:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d008056c:	f080 80bb 	bcs.w	d00806e6 <draw_star_speed_range+0x5aa>
d0080570:	2a00      	cmp	r2, #0
d0080572:	f040 80b8 	bne.w	d00806e6 <draw_star_speed_range+0x5aa>
d0080576:	f899 300c 	ldrb.w	r3, [r9, #12]
d008057a:	3101      	adds	r1, #1
d008057c:	f899 e00d 	ldrb.w	lr, [r9, #13]
d0080580:	f899 c00e 	ldrb.w	ip, [r9, #14]
d0080584:	b209      	sxth	r1, r1
d0080586:	ea43 2e0e 	orr.w	lr, r3, lr, lsl #8
d008058a:	f899 300f 	ldrb.w	r3, [r9, #15]
d008058e:	ea4e 4c0c 	orr.w	ip, lr, ip, lsl #16
d0080592:	ea4c 6303 	orr.w	r3, ip, r3, lsl #24
d0080596:	685b      	ldr	r3, [r3, #4]
d0080598:	689b      	ldr	r3, [r3, #8]
d008059a:	4798      	blx	r3
d008059c:	f894 b004 	ldrb.w	fp, [r4, #4]
d00805a0:	8823      	ldrh	r3, [r4, #0]
d00805a2:	f1bb 0f08 	cmp.w	fp, #8
d00805a6:	f240 8094 	bls.w	d00806d2 <draw_star_speed_range+0x596>
d00805aa:	1cd8      	adds	r0, r3, #3
d00805ac:	8861      	ldrh	r1, [r4, #2]
d00805ae:	f240 1bdf 	movw	fp, #479	; 0x1df
d00805b2:	fa1f fc80 	uxth.w	ip, r0
d00805b6:	f1a1 0e27 	sub.w	lr, r1, #39	; 0x27
d00805ba:	b200      	sxth	r0, r0
d00805bc:	45dc      	cmp	ip, fp
d00805be:	bf94      	ite	ls
d00805c0:	2200      	movls	r2, #0
d00805c2:	2201      	movhi	r2, #1
d00805c4:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d00805c8:	d21e      	bcs.n	d0080608 <draw_star_speed_range+0x4cc>
d00805ca:	b9ea      	cbnz	r2, d0080608 <draw_star_speed_range+0x4cc>
d00805cc:	f899 300c 	ldrb.w	r3, [r9, #12]
d00805d0:	3901      	subs	r1, #1
d00805d2:	f899 e00d 	ldrb.w	lr, [r9, #13]
d00805d6:	f899 c00e 	ldrb.w	ip, [r9, #14]
d00805da:	b209      	sxth	r1, r1
d00805dc:	ea43 230e 	orr.w	r3, r3, lr, lsl #8
d00805e0:	f899 e00f 	ldrb.w	lr, [r9, #15]
d00805e4:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d00805e8:	ea43 6c0e 	orr.w	ip, r3, lr, lsl #24
d00805ec:	f8dc 3004 	ldr.w	r3, [ip, #4]
d00805f0:	689b      	ldr	r3, [r3, #8]
d00805f2:	4798      	blx	r3
d00805f4:	8823      	ldrh	r3, [r4, #0]
d00805f6:	8861      	ldrh	r1, [r4, #2]
d00805f8:	1cd8      	adds	r0, r3, #3
d00805fa:	fa1f fc80 	uxth.w	ip, r0
d00805fe:	b200      	sxth	r0, r0
d0080600:	45dc      	cmp	ip, fp
d0080602:	bf94      	ite	ls
d0080604:	2200      	movls	r2, #0
d0080606:	2201      	movhi	r2, #1
d0080608:	f1a1 0e25 	sub.w	lr, r1, #37	; 0x25
d008060c:	f5be 7f8d 	cmp.w	lr, #282	; 0x11a
d0080610:	d214      	bcs.n	d008063c <draw_star_speed_range+0x500>
d0080612:	b99a      	cbnz	r2, d008063c <draw_star_speed_range+0x500>
d0080614:	f899 300c 	ldrb.w	r3, [r9, #12]
d0080618:	3101      	adds	r1, #1
d008061a:	f899 c00d 	ldrb.w	ip, [r9, #13]
d008061e:	f899 e00e 	ldrb.w	lr, [r9, #14]
d0080622:	b209      	sxth	r1, r1
d0080624:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d0080628:	f899 200f 	ldrb.w	r2, [r9, #15]
d008062c:	ea43 430e 	orr.w	r3, r3, lr, lsl #16
d0080630:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080634:	685b      	ldr	r3, [r3, #4]
d0080636:	689b      	ldr	r3, [r3, #8]
d0080638:	4798      	blx	r3
d008063a:	8823      	ldrh	r3, [r4, #0]
d008063c:	f894 b004 	ldrb.w	fp, [r4, #4]
d0080640:	eba3 030b 	sub.w	r3, r3, fp
d0080644:	f1bb 0f08 	cmp.w	fp, #8
d0080648:	b21b      	sxth	r3, r3
d008064a:	8023      	strh	r3, [r4, #0]
d008064c:	d84e      	bhi.n	d00806ec <draw_star_speed_range+0x5b0>
d008064e:	f1bb 0f06 	cmp.w	fp, #6
d0080652:	d845      	bhi.n	d00806e0 <draw_star_speed_range+0x5a4>
d0080654:	f1bb 0f04 	cmp.w	fp, #4
d0080658:	d858      	bhi.n	d008070c <draw_star_speed_range+0x5d0>
d008065a:	f1bb 0f02 	cmp.w	fp, #2
d008065e:	d85b      	bhi.n	d0080718 <draw_star_speed_range+0x5dc>
d0080660:	d064      	beq.n	d008072c <draw_star_speed_range+0x5f0>
d0080662:	f04f 32ff 	mov.w	r2, #4294967295	; 0xffffffff
d0080666:	4293      	cmp	r3, r2
d0080668:	f6bf adc4 	bge.w	d00801f4 <draw_star_speed_range+0xb8>
d008066c:	4938      	ldr	r1, [pc, #224]	; (d0080750 <draw_star_speed_range+0x614>)
d008066e:	f243 0e39 	movw	lr, #12345	; 0x3039
d0080672:	f240 1c19 	movw	ip, #281	; 0x119
d0080676:	1e68      	subs	r0, r5, #1
d0080678:	680b      	ldr	r3, [r1, #0]
d008067a:	b2c0      	uxtb	r0, r0
d008067c:	fb08 e303 	mla	r3, r8, r3, lr
d0080680:	281f      	cmp	r0, #31
d0080682:	ea4f 4213 	mov.w	r2, r3, lsr #16
d0080686:	fb08 e303 	mla	r3, r8, r3, lr
d008068a:	fbaa eb02 	umull	lr, fp, sl, r2
d008068e:	ea4f 4e13 	mov.w	lr, r3, lsr #16
d0080692:	600b      	str	r3, [r1, #0]
d0080694:	eba2 030b 	sub.w	r3, r2, fp
d0080698:	492e      	ldr	r1, [pc, #184]	; (d0080754 <draw_star_speed_range+0x618>)
d008069a:	eb0b 0353 	add.w	r3, fp, r3, lsr #1
d008069e:	fba1 910e 	umull	r9, r1, r1, lr
d00806a2:	ea4f 2313 	mov.w	r3, r3, lsr #8
d00806a6:	ea4f 01d1 	mov.w	r1, r1, lsr #3
d00806aa:	fb0c e111 	mls	r1, ip, r1, lr
d00806ae:	ebc3 1c03 	rsb	ip, r3, r3, lsl #4
d00806b2:	ebc3 134c 	rsb	r3, r3, ip, lsl #5
d00806b6:	f101 0126 	add.w	r1, r1, #38	; 0x26
d00806ba:	eba2 0203 	sub.w	r2, r2, r3
d00806be:	8061      	strh	r1, [r4, #2]
d00806c0:	f502 72f0 	add.w	r2, r2, #480	; 0x1e0
d00806c4:	8022      	strh	r2, [r4, #0]
d00806c6:	d81a      	bhi.n	d00806fe <draw_star_speed_range+0x5c2>
d00806c8:	2201      	movs	r2, #1
d00806ca:	2306      	movs	r3, #6
d00806cc:	7122      	strb	r2, [r4, #4]
d00806ce:	7163      	strb	r3, [r4, #5]
d00806d0:	e593      	b.n	d00801fa <draw_star_speed_range+0xbe>
d00806d2:	eba3 030b 	sub.w	r3, r3, fp
d00806d6:	f1bb 0f06 	cmp.w	fp, #6
d00806da:	b21b      	sxth	r3, r3
d00806dc:	8023      	strh	r3, [r4, #0]
d00806de:	d9b9      	bls.n	d0080654 <draw_star_speed_range+0x518>
d00806e0:	f06f 0206 	mvn.w	r2, #6
d00806e4:	e7bf      	b.n	d0080666 <draw_star_speed_range+0x52a>
d00806e6:	f894 b004 	ldrb.w	fp, [r4, #4]
d00806ea:	e75a      	b.n	d00805a2 <draw_star_speed_range+0x466>
d00806ec:	f06f 0208 	mvn.w	r2, #8
d00806f0:	e7b9      	b.n	d0080666 <draw_star_speed_range+0x52a>
d00806f2:	f04f 0b09 	mov.w	fp, #9
d00806f6:	e58f      	b.n	d0080218 <draw_star_speed_range+0xdc>
d00806f8:	f04f 0b07 	mov.w	fp, #7
d00806fc:	e58c      	b.n	d0080218 <draw_star_speed_range+0xdc>
d00806fe:	2835      	cmp	r0, #53	; 0x35
d0080700:	d80d      	bhi.n	d008071e <draw_star_speed_range+0x5e2>
d0080702:	2202      	movs	r2, #2
d0080704:	2306      	movs	r3, #6
d0080706:	7122      	strb	r2, [r4, #4]
d0080708:	7163      	strb	r3, [r4, #5]
d008070a:	e576      	b.n	d00801fa <draw_star_speed_range+0xbe>
d008070c:	f06f 0204 	mvn.w	r2, #4
d0080710:	e7a9      	b.n	d0080666 <draw_star_speed_range+0x52a>
d0080712:	f04f 0b03 	mov.w	fp, #3
d0080716:	e57f      	b.n	d0080218 <draw_star_speed_range+0xdc>
d0080718:	f06f 0202 	mvn.w	r2, #2
d008071c:	e7a3      	b.n	d0080666 <draw_star_speed_range+0x52a>
d008071e:	2847      	cmp	r0, #71	; 0x47
d0080720:	d807      	bhi.n	d0080732 <draw_star_speed_range+0x5f6>
d0080722:	2203      	movs	r2, #3
d0080724:	2305      	movs	r3, #5
d0080726:	7122      	strb	r2, [r4, #4]
d0080728:	7163      	strb	r3, [r4, #5]
d008072a:	e566      	b.n	d00801fa <draw_star_speed_range+0xbe>
d008072c:	f06f 0201 	mvn.w	r2, #1
d0080730:	e799      	b.n	d0080666 <draw_star_speed_range+0x52a>
d0080732:	2853      	cmp	r0, #83	; 0x53
d0080734:	f63f ad57 	bhi.w	d00801e6 <draw_star_speed_range+0xaa>
d0080738:	2205      	movs	r2, #5
d008073a:	2301      	movs	r3, #1
d008073c:	7122      	strb	r2, [r4, #4]
d008073e:	7163      	strb	r3, [r4, #5]
d0080740:	e55b      	b.n	d00801fa <draw_star_speed_range+0xbe>
d0080742:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
d0080746:	2207      	movs	r2, #7
d0080748:	2301      	movs	r3, #1
d008074a:	7122      	strb	r2, [r4, #4]
d008074c:	7163      	strb	r3, [r4, #5]
d008074e:	e554      	b.n	d00801fa <draw_star_speed_range+0xbe>
d0080750:	d0087720 	.word	0xd0087720
d0080754:	0749cb29 	.word	0x0749cb29

d0080758 <main>:
d0080758:	4ca6      	ldr	r4, [pc, #664]	; (d00809f4 <main+0x29c>)
d008075a:	f44f 2000 	mov.w	r0, #524288	; 0x80000
d008075e:	2602      	movs	r6, #2
d0080760:	f04f 0a00 	mov.w	sl, #0
d0080764:	7823      	ldrb	r3, [r4, #0]
d0080766:	7862      	ldrb	r2, [r4, #1]
d0080768:	78a1      	ldrb	r1, [r4, #2]
d008076a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008076e:	78e2      	ldrb	r2, [r4, #3]
d0080770:	f8df 9294 	ldr.w	r9, [pc, #660]	; d0080a08 <main+0x2b0>
d0080774:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080778:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008077c:	e92d 4880 	stmdb	sp!, {r7, fp, lr}
d0080780:	681b      	ldr	r3, [r3, #0]
d0080782:	b087      	sub	sp, #28
d0080784:	4798      	blx	r3
d0080786:	46d3      	mov	fp, sl
d0080788:	f7ff fc66 	bl	d0080058 <initMalloc>
d008078c:	7b23      	ldrb	r3, [r4, #12]
d008078e:	7b62      	ldrb	r2, [r4, #13]
d0080790:	2190      	movs	r1, #144	; 0x90
d0080792:	7ba5      	ldrb	r5, [r4, #14]
d0080794:	20dc      	movs	r0, #220	; 0xdc
d0080796:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008079a:	7be2      	ldrb	r2, [r4, #15]
d008079c:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d00807a0:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00807a4:	681b      	ldr	r3, [r3, #0]
d00807a6:	691b      	ldr	r3, [r3, #16]
d00807a8:	4798      	blx	r3
d00807aa:	7b20      	ldrb	r0, [r4, #12]
d00807ac:	7b61      	ldrb	r1, [r4, #13]
d00807ae:	f44f 73a0 	mov.w	r3, #320	; 0x140
d00807b2:	7ba2      	ldrb	r2, [r4, #14]
d00807b4:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
d00807b8:	7be1      	ldrb	r1, [r4, #15]
d00807ba:	ea40 4002 	orr.w	r0, r0, r2, lsl #16
d00807be:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d00807c2:	ea40 6001 	orr.w	r0, r0, r1, lsl #24
d00807c6:	4619      	mov	r1, r3
d00807c8:	6805      	ldr	r5, [r0, #0]
d00807ca:	4610      	mov	r0, r2
d00807cc:	9600      	str	r6, [sp, #0]
d00807ce:	696d      	ldr	r5, [r5, #20]
d00807d0:	47a8      	blx	r5
d00807d2:	7d23      	ldrb	r3, [r4, #20]
d00807d4:	7d62      	ldrb	r2, [r4, #21]
d00807d6:	f44f 7000 	mov.w	r0, #512	; 0x200
d00807da:	7da1      	ldrb	r1, [r4, #22]
d00807dc:	2510      	movs	r5, #16
d00807de:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00807e2:	7de2      	ldrb	r2, [r4, #23]
d00807e4:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00807e8:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00807ec:	681b      	ldr	r3, [r3, #0]
d00807ee:	681b      	ldr	r3, [r3, #0]
d00807f0:	4798      	blx	r3
d00807f2:	7d22      	ldrb	r2, [r4, #20]
d00807f4:	7d63      	ldrb	r3, [r4, #21]
d00807f6:	2101      	movs	r1, #1
d00807f8:	ea42 2203 	orr.w	r2, r2, r3, lsl #8
d00807fc:	7da3      	ldrb	r3, [r4, #22]
d00807fe:	7de0      	ldrb	r0, [r4, #23]
d0080800:	ea42 4203 	orr.w	r2, r2, r3, lsl #16
d0080804:	7b23      	ldrb	r3, [r4, #12]
d0080806:	ea42 6200 	orr.w	r2, r2, r0, lsl #24
d008080a:	7b60      	ldrb	r0, [r4, #13]
d008080c:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
d0080810:	6810      	ldr	r0, [r2, #0]
d0080812:	7ba2      	ldrb	r2, [r4, #14]
d0080814:	6840      	ldr	r0, [r0, #4]
d0080816:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d008081a:	7be2      	ldrb	r2, [r4, #15]
d008081c:	7001      	strb	r1, [r0, #0]
d008081e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080822:	681b      	ldr	r3, [r3, #0]
d0080824:	6b5b      	ldr	r3, [r3, #52]	; 0x34
d0080826:	4798      	blx	r3
d0080828:	7b23      	ldrb	r3, [r4, #12]
d008082a:	4973      	ldr	r1, [pc, #460]	; (d00809f8 <main+0x2a0>)
d008082c:	7b62      	ldrb	r2, [r4, #13]
d008082e:	6008      	str	r0, [r1, #0]
d0080830:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080834:	7ba1      	ldrb	r1, [r4, #14]
d0080836:	7be2      	ldrb	r2, [r4, #15]
d0080838:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d008083c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080840:	681b      	ldr	r3, [r3, #0]
d0080842:	6b9b      	ldr	r3, [r3, #56]	; 0x38
d0080844:	4798      	blx	r3
d0080846:	7b23      	ldrb	r3, [r4, #12]
d0080848:	496c      	ldr	r1, [pc, #432]	; (d00809fc <main+0x2a4>)
d008084a:	7b62      	ldrb	r2, [r4, #13]
d008084c:	6008      	str	r0, [r1, #0]
d008084e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080852:	7ba1      	ldrb	r1, [r4, #14]
d0080854:	7be2      	ldrb	r2, [r4, #15]
d0080856:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d008085a:	4869      	ldr	r0, [pc, #420]	; (d0080a00 <main+0x2a8>)
d008085c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080860:	681b      	ldr	r3, [r3, #0]
d0080862:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d0080864:	4798      	blx	r3
d0080866:	7e23      	ldrb	r3, [r4, #24]
d0080868:	7e62      	ldrb	r2, [r4, #25]
d008086a:	7ea1      	ldrb	r1, [r4, #26]
d008086c:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080870:	7ee2      	ldrb	r2, [r4, #27]
d0080872:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080876:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008087a:	681b      	ldr	r3, [r3, #0]
d008087c:	4798      	blx	r3
d008087e:	7b23      	ldrb	r3, [r4, #12]
d0080880:	7b62      	ldrb	r2, [r4, #13]
d0080882:	7ba1      	ldrb	r1, [r4, #14]
d0080884:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080888:	7be2      	ldrb	r2, [r4, #15]
d008088a:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d008088e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080892:	681b      	ldr	r3, [r3, #0]
d0080894:	6d5b      	ldr	r3, [r3, #84]	; 0x54
d0080896:	4798      	blx	r3
d0080898:	7b23      	ldrb	r3, [r4, #12]
d008089a:	7b62      	ldrb	r2, [r4, #13]
d008089c:	2157      	movs	r1, #87	; 0x57
d008089e:	2050      	movs	r0, #80	; 0x50
d00808a0:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00808a4:	7ba2      	ldrb	r2, [r4, #14]
d00808a6:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00808aa:	7be2      	ldrb	r2, [r4, #15]
d00808ac:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00808b0:	681b      	ldr	r3, [r3, #0]
d00808b2:	6e1b      	ldr	r3, [r3, #96]	; 0x60
d00808b4:	4798      	blx	r3
d00808b6:	7b23      	ldrb	r3, [r4, #12]
d00808b8:	7b62      	ldrb	r2, [r4, #13]
d00808ba:	2004      	movs	r0, #4
d00808bc:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00808c0:	7ba2      	ldrb	r2, [r4, #14]
d00808c2:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00808c6:	7be2      	ldrb	r2, [r4, #15]
d00808c8:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00808cc:	681b      	ldr	r3, [r3, #0]
d00808ce:	6e5b      	ldr	r3, [r3, #100]	; 0x64
d00808d0:	4798      	blx	r3
d00808d2:	f44f 71f0 	mov.w	r1, #480	; 0x1e0
d00808d6:	f44f 72a0 	mov.w	r2, #320	; 0x140
d00808da:	484a      	ldr	r0, [pc, #296]	; (d0080a04 <main+0x2ac>)
d00808dc:	f7ff fbae 	bl	d008003c <gfx_createBitmap>
d00808e0:	7b23      	ldrb	r3, [r4, #12]
d00808e2:	7b62      	ldrb	r2, [r4, #13]
d00808e4:	4847      	ldr	r0, [pc, #284]	; (d0080a04 <main+0x2ac>)
d00808e6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00808ea:	7ba2      	ldrb	r2, [r4, #14]
d00808ec:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d00808f0:	7be2      	ldrb	r2, [r4, #15]
d00808f2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00808f6:	681b      	ldr	r3, [r3, #0]
d00808f8:	699b      	ldr	r3, [r3, #24]
d00808fa:	4798      	blx	r3
d00808fc:	7b23      	ldrb	r3, [r4, #12]
d00808fe:	7b62      	ldrb	r2, [r4, #13]
d0080900:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080904:	7ba2      	ldrb	r2, [r4, #14]
d0080906:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d008090a:	7be2      	ldrb	r2, [r4, #15]
d008090c:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080910:	685b      	ldr	r3, [r3, #4]
d0080912:	681b      	ldr	r3, [r3, #0]
d0080914:	4798      	blx	r3
d0080916:	e03d      	b.n	d0080994 <main+0x23c>
d0080918:	7b23      	ldrb	r3, [r4, #12]
d008091a:	f102 0711 	add.w	r7, r2, #17
d008091e:	7b62      	ldrb	r2, [r4, #13]
d0080920:	4628      	mov	r0, r5
d0080922:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0080926:	fa0f f887 	sxth.w	r8, r7
d008092a:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d008092e:	7be2      	ldrb	r2, [r4, #15]
d0080930:	f819 7c01 	ldrb.w	r7, [r9, #-1]
d0080934:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0080938:	9105      	str	r1, [sp, #20]
d008093a:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d008093e:	685b      	ldr	r3, [r3, #4]
d0080940:	68db      	ldr	r3, [r3, #12]
d0080942:	4798      	blx	r3
d0080944:	7b22      	ldrb	r2, [r4, #12]
d0080946:	f894 e00d 	ldrb.w	lr, [r4, #13]
d008094a:	2311      	movs	r3, #17
d008094c:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0080950:	ea42 200e 	orr.w	r0, r2, lr, lsl #8
d0080954:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080958:	9905      	ldr	r1, [sp, #20]
d008095a:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d008095e:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d0080962:	2000      	movs	r0, #0
d0080964:	ea4c 6c0e 	orr.w	ip, ip, lr, lsl #24
d0080968:	f8dc c004 	ldr.w	ip, [ip, #4]
d008096c:	f8dc 6004 	ldr.w	r6, [ip, #4]
d0080970:	47b0      	blx	r6
d0080972:	42af      	cmp	r7, r5
d0080974:	d003      	beq.n	d008097e <main+0x226>
d0080976:	f10a 0301 	add.w	r3, sl, #1
d008097a:	4598      	cmp	r8, r3
d008097c:	dc73      	bgt.n	d0080a66 <main+0x30e>
d008097e:	fa1f f38b 	uxth.w	r3, fp
d0080982:	2b11      	cmp	r3, #17
d0080984:	f000 8096 	beq.w	d0080ab4 <main+0x35c>
d0080988:	f10b 0b01 	add.w	fp, fp, #1
d008098c:	f10a 0a11 	add.w	sl, sl, #17
d0080990:	f819 5f01 	ldrb.w	r5, [r9, #1]!
d0080994:	fa1f f28a 	uxth.w	r2, sl
d0080998:	f1bb 0f11 	cmp.w	fp, #17
d008099c:	fa0f f18a 	sxth.w	r1, sl
d00809a0:	fa0f f78b 	sxth.w	r7, fp
d00809a4:	9204      	str	r2, [sp, #16]
d00809a6:	d031      	beq.n	d0080a0c <main+0x2b4>
d00809a8:	2f00      	cmp	r7, #0
d00809aa:	d1b5      	bne.n	d0080918 <main+0x1c0>
d00809ac:	7b23      	ldrb	r3, [r4, #12]
d00809ae:	7b62      	ldrb	r2, [r4, #13]
d00809b0:	7ba5      	ldrb	r5, [r4, #14]
d00809b2:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00809b6:	7be2      	ldrb	r2, [r4, #15]
d00809b8:	f899 0000 	ldrb.w	r0, [r9]
d00809bc:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d00809c0:	9104      	str	r1, [sp, #16]
d00809c2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00809c6:	685b      	ldr	r3, [r3, #4]
d00809c8:	68db      	ldr	r3, [r3, #12]
d00809ca:	4798      	blx	r3
d00809cc:	7b23      	ldrb	r3, [r4, #12]
d00809ce:	7b62      	ldrb	r2, [r4, #13]
d00809d0:	4638      	mov	r0, r7
d00809d2:	f894 c00e 	ldrb.w	ip, [r4, #14]
d00809d6:	ea43 2502 	orr.w	r5, r3, r2, lsl #8
d00809da:	7be6      	ldrb	r6, [r4, #15]
d00809dc:	9904      	ldr	r1, [sp, #16]
d00809de:	2311      	movs	r3, #17
d00809e0:	ea45 450c 	orr.w	r5, r5, ip, lsl #16
d00809e4:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d00809e8:	ea45 6506 	orr.w	r5, r5, r6, lsl #24
d00809ec:	686d      	ldr	r5, [r5, #4]
d00809ee:	686d      	ldr	r5, [r5, #4]
d00809f0:	47a8      	blx	r5
d00809f2:	e7c9      	b.n	d0080988 <main+0x230>
d00809f4:	2001f000 	.word	0x2001f000
d00809f8:	d0087a60 	.word	0xd0087a60
d00809fc:	d0087a40 	.word	0xd0087a40
d0080a00:	d0081760 	.word	0xd0081760
d0080a04:	d0087a20 	.word	0xd0087a20
d0080a08:	d0087600 	.word	0xd0087600
d0080a0c:	7b23      	ldrb	r3, [r4, #12]
d0080a0e:	4628      	mov	r0, r5
d0080a10:	7b62      	ldrb	r2, [r4, #13]
d0080a12:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0080a16:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080a1a:	7be2      	ldrb	r2, [r4, #15]
d0080a1c:	f819 7c01 	ldrb.w	r7, [r9, #-1]
d0080a20:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0080a24:	9105      	str	r1, [sp, #20]
d0080a26:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080a2a:	685b      	ldr	r3, [r3, #4]
d0080a2c:	68db      	ldr	r3, [r3, #12]
d0080a2e:	4798      	blx	r3
d0080a30:	7b22      	ldrb	r2, [r4, #12]
d0080a32:	f894 e00d 	ldrb.w	lr, [r4, #13]
d0080a36:	7ba0      	ldrb	r0, [r4, #14]
d0080a38:	ea42 2c0e 	orr.w	ip, r2, lr, lsl #8
d0080a3c:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080a40:	9b04      	ldr	r3, [sp, #16]
d0080a42:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0080a46:	ea4c 4c00 	orr.w	ip, ip, r0, lsl #16
d0080a4a:	9905      	ldr	r1, [sp, #20]
d0080a4c:	f5c3 73a0 	rsb	r3, r3, #320	; 0x140
d0080a50:	2000      	movs	r0, #0
d0080a52:	ea4c 6c0e 	orr.w	ip, ip, lr, lsl #24
d0080a56:	b21b      	sxth	r3, r3
d0080a58:	f8dc c004 	ldr.w	ip, [ip, #4]
d0080a5c:	f8dc 8004 	ldr.w	r8, [ip, #4]
d0080a60:	47c0      	blx	r8
d0080a62:	42bd      	cmp	r5, r7
d0080a64:	d08b      	beq.n	d008097e <main+0x226>
d0080a66:	7b23      	ldrb	r3, [r4, #12]
d0080a68:	4638      	mov	r0, r7
d0080a6a:	7b62      	ldrb	r2, [r4, #13]
d0080a6c:	7ba1      	ldrb	r1, [r4, #14]
d0080a6e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080a72:	7be2      	ldrb	r2, [r4, #15]
d0080a74:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080a78:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080a7c:	685b      	ldr	r3, [r3, #4]
d0080a7e:	68db      	ldr	r3, [r3, #12]
d0080a80:	4798      	blx	r3
d0080a82:	7b25      	ldrb	r5, [r4, #12]
d0080a84:	7b62      	ldrb	r2, [r4, #13]
d0080a86:	2302      	movs	r3, #2
d0080a88:	7ba0      	ldrb	r0, [r4, #14]
d0080a8a:	ea45 2502 	orr.w	r5, r5, r2, lsl #8
d0080a8e:	7be7      	ldrb	r7, [r4, #15]
d0080a90:	9904      	ldr	r1, [sp, #16]
d0080a92:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0080a96:	ea45 4500 	orr.w	r5, r5, r0, lsl #16
d0080a9a:	2000      	movs	r0, #0
d0080a9c:	3103      	adds	r1, #3
d0080a9e:	ea45 6507 	orr.w	r5, r5, r7, lsl #24
d0080aa2:	b209      	sxth	r1, r1
d0080aa4:	686d      	ldr	r5, [r5, #4]
d0080aa6:	686d      	ldr	r5, [r5, #4]
d0080aa8:	47a8      	blx	r5
d0080aaa:	fa1f f38b 	uxth.w	r3, fp
d0080aae:	2b11      	cmp	r3, #17
d0080ab0:	f47f af6a 	bne.w	d0080988 <main+0x230>
d0080ab4:	7b23      	ldrb	r3, [r4, #12]
d0080ab6:	2700      	movs	r7, #0
d0080ab8:	7b62      	ldrb	r2, [r4, #13]
d0080aba:	f243 0939 	movw	r9, #12345	; 0x3039
d0080abe:	7ba1      	ldrb	r1, [r4, #14]
d0080ac0:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080ac4:	7be2      	ldrb	r2, [r4, #15]
d0080ac6:	485f      	ldr	r0, [pc, #380]	; (d0080c44 <main+0x4ec>)
d0080ac8:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080acc:	f8df a198 	ldr.w	sl, [pc, #408]	; d0080c68 <main+0x510>
d0080ad0:	4d5d      	ldr	r5, [pc, #372]	; (d0080c48 <main+0x4f0>)
d0080ad2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080ad6:	f8df b194 	ldr.w	fp, [pc, #404]	; d0080c6c <main+0x514>
d0080ada:	681b      	ldr	r3, [r3, #0]
d0080adc:	6a1b      	ldr	r3, [r3, #32]
d0080ade:	4798      	blx	r3
d0080ae0:	7b23      	ldrb	r3, [r4, #12]
d0080ae2:	7b62      	ldrb	r2, [r4, #13]
d0080ae4:	7ba1      	ldrb	r1, [r4, #14]
d0080ae6:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080aea:	7be2      	ldrb	r2, [r4, #15]
d0080aec:	4857      	ldr	r0, [pc, #348]	; (d0080c4c <main+0x4f4>)
d0080aee:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080af2:	6800      	ldr	r0, [r0, #0]
d0080af4:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080af8:	681b      	ldr	r3, [r3, #0]
d0080afa:	69db      	ldr	r3, [r3, #28]
d0080afc:	4798      	blx	r3
d0080afe:	7b23      	ldrb	r3, [r4, #12]
d0080b00:	7b62      	ldrb	r2, [r4, #13]
d0080b02:	7ba1      	ldrb	r1, [r4, #14]
d0080b04:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0080b08:	7be2      	ldrb	r2, [r4, #15]
d0080b0a:	4851      	ldr	r0, [pc, #324]	; (d0080c50 <main+0x4f8>)
d0080b0c:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d0080b10:	6800      	ldr	r0, [r0, #0]
d0080b12:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0080b16:	681b      	ldr	r3, [r3, #0]
d0080b18:	699b      	ldr	r3, [r3, #24]
d0080b1a:	4798      	blx	r3
d0080b1c:	494d      	ldr	r1, [pc, #308]	; (d0080c54 <main+0x4fc>)
d0080b1e:	f44f 62ca 	mov.w	r2, #1616	; 0x650
d0080b22:	f44f 73f0 	mov.w	r3, #480	; 0x1e0
d0080b26:	6808      	ldr	r0, [r1, #0]
d0080b28:	f8ca 2000 	str.w	r2, [sl]
d0080b2c:	494a      	ldr	r1, [pc, #296]	; (d0080c58 <main+0x500>)
d0080b2e:	602b      	str	r3, [r5, #0]
d0080b30:	e006      	b.n	d0080b40 <main+0x3e8>
d0080b32:	2306      	movs	r3, #6
d0080b34:	f04f 0201 	mov.w	r2, #1
d0080b38:	714b      	strb	r3, [r1, #5]
d0080b3a:	710a      	strb	r2, [r1, #4]
d0080b3c:	3701      	adds	r7, #1
d0080b3e:	3106      	adds	r1, #6
d0080b40:	fb0b 9000 	mla	r0, fp, r0, r9
d0080b44:	b2fb      	uxtb	r3, r7
d0080b46:	2f1f      	cmp	r7, #31
d0080b48:	ea4f 4610 	mov.w	r6, r0, lsr #16
d0080b4c:	9304      	str	r3, [sp, #16]
d0080b4e:	4b43      	ldr	r3, [pc, #268]	; (d0080c5c <main+0x504>)
d0080b50:	fb0b 9000 	mla	r0, fp, r0, r9
d0080b54:	fba3 2306 	umull	r2, r3, r3, r6
d0080b58:	ea4f 4810 	mov.w	r8, r0, lsr #16
d0080b5c:	eba6 0203 	sub.w	r2, r6, r3
d0080b60:	eb03 0352 	add.w	r3, r3, r2, lsr #1
d0080b64:	4a3e      	ldr	r2, [pc, #248]	; (d0080c60 <main+0x508>)
d0080b66:	ea4f 2313 	mov.w	r3, r3, lsr #8
d0080b6a:	fba2 c208 	umull	ip, r2, r2, r8
d0080b6e:	f240 1c19 	movw	ip, #281	; 0x119
d0080b72:	ea4f 02d2 	mov.w	r2, r2, lsr #3
d0080b76:	ebc3 1e03 	rsb	lr, r3, r3, lsl #4
d0080b7a:	fb0c 8212 	mls	r2, ip, r2, r8
d0080b7e:	ebc3 134e 	rsb	r3, r3, lr, lsl #5
d0080b82:	f102 0226 	add.w	r2, r2, #38	; 0x26
d0080b86:	eba6 0603 	sub.w	r6, r6, r3
d0080b8a:	804a      	strh	r2, [r1, #2]
d0080b8c:	800e      	strh	r6, [r1, #0]
d0080b8e:	d9d0      	bls.n	d0080b32 <main+0x3da>
d0080b90:	9b04      	ldr	r3, [sp, #16]
d0080b92:	2b35      	cmp	r3, #53	; 0x35
d0080b94:	d805      	bhi.n	d0080ba2 <main+0x44a>
d0080b96:	2306      	movs	r3, #6
d0080b98:	f04f 0202 	mov.w	r2, #2
d0080b9c:	714b      	strb	r3, [r1, #5]
d0080b9e:	710a      	strb	r2, [r1, #4]
d0080ba0:	e7cc      	b.n	d0080b3c <main+0x3e4>
d0080ba2:	2b47      	cmp	r3, #71	; 0x47
d0080ba4:	d804      	bhi.n	d0080bb0 <main+0x458>
d0080ba6:	2203      	movs	r2, #3
d0080ba8:	2305      	movs	r3, #5
d0080baa:	710a      	strb	r2, [r1, #4]
d0080bac:	714b      	strb	r3, [r1, #5]
d0080bae:	e7c5      	b.n	d0080b3c <main+0x3e4>
d0080bb0:	2b53      	cmp	r3, #83	; 0x53
d0080bb2:	d805      	bhi.n	d0080bc0 <main+0x468>
d0080bb4:	2305      	movs	r3, #5
d0080bb6:	f04f 0201 	mov.w	r2, #1
d0080bba:	710b      	strb	r3, [r1, #4]
d0080bbc:	714a      	strb	r2, [r1, #5]
d0080bbe:	e7bd      	b.n	d0080b3c <main+0x3e4>
d0080bc0:	2b5b      	cmp	r3, #91	; 0x5b
d0080bc2:	d806      	bhi.n	d0080bd2 <main+0x47a>
d0080bc4:	f04f 0307 	mov.w	r3, #7
d0080bc8:	710b      	strb	r3, [r1, #4]
d0080bca:	f04f 0301 	mov.w	r3, #1
d0080bce:	714b      	strb	r3, [r1, #5]
d0080bd0:	e7b4      	b.n	d0080b3c <main+0x3e4>
d0080bd2:	f04f 0309 	mov.w	r3, #9
d0080bd6:	710b      	strb	r3, [r1, #4]
d0080bd8:	f04f 0302 	mov.w	r3, #2
d0080bdc:	714b      	strb	r3, [r1, #5]
d0080bde:	9b04      	ldr	r3, [sp, #16]
d0080be0:	2b5f      	cmp	r3, #95	; 0x5f
d0080be2:	d1ab      	bne.n	d0080b3c <main+0x3e4>
d0080be4:	4b1b      	ldr	r3, [pc, #108]	; (d0080c54 <main+0x4fc>)
d0080be6:	f8df 9088 	ldr.w	r9, [pc, #136]	; d0080c70 <main+0x518>
d0080bea:	f8df b088 	ldr.w	fp, [pc, #136]	; d0080c74 <main+0x51c>
d0080bee:	f8df 8088 	ldr.w	r8, [pc, #136]	; d0080c78 <main+0x520>
d0080bf2:	ed9f 8a1c 	vldr	s16, [pc, #112]	; d0080c64 <main+0x50c>
d0080bf6:	6018      	str	r0, [r3, #0]
d0080bf8:	7b20      	ldrb	r0, [r4, #12]
d0080bfa:	7b61      	ldrb	r1, [r4, #13]
d0080bfc:	7ba2      	ldrb	r2, [r4, #14]
d0080bfe:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0080c02:	7be3      	ldrb	r3, [r4, #15]
d0080c04:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0080c08:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0080c0c:	681b      	ldr	r3, [r3, #0]
d0080c0e:	68db      	ldr	r3, [r3, #12]
d0080c10:	4798      	blx	r3
d0080c12:	7b20      	ldrb	r0, [r4, #12]
d0080c14:	7b61      	ldrb	r1, [r4, #13]
d0080c16:	7ba2      	ldrb	r2, [r4, #14]
d0080c18:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0080c1c:	7be3      	ldrb	r3, [r4, #15]
d0080c1e:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0080c22:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0080c26:	685b      	ldr	r3, [r3, #4]
d0080c28:	681b      	ldr	r3, [r3, #0]
d0080c2a:	4798      	blx	r3
d0080c2c:	f8d9 1000 	ldr.w	r1, [r9]
d0080c30:	3902      	subs	r1, #2
d0080c32:	f111 0f43 	cmn.w	r1, #67	; 0x43
d0080c36:	f2c0 8168 	blt.w	d0080f0a <main+0x7b2>
d0080c3a:	f8c9 1000 	str.w	r1, [r9]
d0080c3e:	2300      	movs	r3, #0
d0080c40:	9304      	str	r3, [sp, #16]
d0080c42:	e01d      	b.n	d0080c80 <main+0x528>
d0080c44:	d0087a20 	.word	0xd0087a20
d0080c48:	d0087700 	.word	0xd0087700
d0080c4c:	d0087a60 	.word	0xd0087a60
d0080c50:	d0087a40 	.word	0xd0087a40
d0080c54:	d0087720 	.word	0xd0087720
d0080c58:	d00877c0 	.word	0xd00877c0
d0080c5c:	11a3019b 	.word	0x11a3019b
d0080c60:	0749cb29 	.word	0x0749cb29
d0080c64:	d0087614 	.word	0xd0087614
d0080c68:	d00877b0 	.word	0xd00877b0
d0080c6c:	41c64e6d 	.word	0x41c64e6d
d0080c70:	d00877ac 	.word	0xd00877ac
d0080c74:	d0087704 	.word	0xd0087704
d0080c78:	d00877a8 	.word	0xd00877a8
d0080c7c:	f8d9 1000 	ldr.w	r1, [r9]
d0080c80:	7b20      	ldrb	r0, [r4, #12]
d0080c82:	4419      	add	r1, r3
d0080c84:	7b62      	ldrb	r2, [r4, #13]
d0080c86:	2720      	movs	r7, #32
d0080c88:	f894 c00e 	ldrb.w	ip, [r4, #14]
d0080c8c:	2344      	movs	r3, #68	; 0x44
d0080c8e:	ea40 2002 	orr.w	r0, r0, r2, lsl #8
d0080c92:	7be6      	ldrb	r6, [r4, #15]
d0080c94:	b209      	sxth	r1, r1
d0080c96:	2200      	movs	r2, #0
d0080c98:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d0080c9c:	48a3      	ldr	r0, [pc, #652]	; (d0080f2c <main+0x7d4>)
d0080c9e:	ea4c 6606 	orr.w	r6, ip, r6, lsl #24
d0080ca2:	6876      	ldr	r6, [r6, #4]
d0080ca4:	9700      	str	r7, [sp, #0]
d0080ca6:	69b6      	ldr	r6, [r6, #24]
d0080ca8:	47b0      	blx	r6
d0080caa:	9b04      	ldr	r3, [sp, #16]
d0080cac:	3344      	adds	r3, #68	; 0x44
d0080cae:	b29b      	uxth	r3, r3
d0080cb0:	f5b3 7f08 	cmp.w	r3, #544	; 0x220
d0080cb4:	9304      	str	r3, [sp, #16]
d0080cb6:	d1e1      	bne.n	d0080c7c <main+0x524>
d0080cb8:	682b      	ldr	r3, [r5, #0]
d0080cba:	f8da 2000 	ldr.w	r2, [sl]
d0080cbe:	3b03      	subs	r3, #3
d0080cc0:	4252      	negs	r2, r2
d0080cc2:	602b      	str	r3, [r5, #0]
d0080cc4:	4293      	cmp	r3, r2
d0080cc6:	dc02      	bgt.n	d0080cce <main+0x576>
d0080cc8:	f44f 73f0 	mov.w	r3, #480	; 0x1e0
d0080ccc:	602b      	str	r3, [r5, #0]
d0080cce:	7b26      	ldrb	r6, [r4, #12]
d0080cd0:	2010      	movs	r0, #16
d0080cd2:	7b61      	ldrb	r1, [r4, #13]
d0080cd4:	7ba2      	ldrb	r2, [r4, #14]
d0080cd6:	ea46 2101 	orr.w	r1, r6, r1, lsl #8
d0080cda:	7be3      	ldrb	r3, [r4, #15]
d0080cdc:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0080ce0:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0080ce4:	685b      	ldr	r3, [r3, #4]
d0080ce6:	68db      	ldr	r3, [r3, #12]
d0080ce8:	4798      	blx	r3
d0080cea:	7b20      	ldrb	r0, [r4, #12]
d0080cec:	7b66      	ldrb	r6, [r4, #13]
d0080cee:	2302      	movs	r3, #2
d0080cf0:	f894 e00e 	ldrb.w	lr, [r4, #14]
d0080cf4:	ee18 2a10 	vmov	r2, s16
d0080cf8:	ea40 2106 	orr.w	r1, r0, r6, lsl #8
d0080cfc:	f894 c00f 	ldrb.w	ip, [r4, #15]
d0080d00:	6828      	ldr	r0, [r5, #0]
d0080d02:	461f      	mov	r7, r3
d0080d04:	ea41 460e 	orr.w	r6, r1, lr, lsl #16
d0080d08:	210e      	movs	r1, #14
d0080d0a:	3802      	subs	r0, #2
d0080d0c:	ea46 660c 	orr.w	r6, r6, ip, lsl #24
d0080d10:	6876      	ldr	r6, [r6, #4]
d0080d12:	9300      	str	r3, [sp, #0]
d0080d14:	6b36      	ldr	r6, [r6, #48]	; 0x30
d0080d16:	47b0      	blx	r6
d0080d18:	7b20      	ldrb	r0, [r4, #12]
d0080d1a:	7b66      	ldrb	r6, [r4, #13]
d0080d1c:	463b      	mov	r3, r7
d0080d1e:	f894 e00e 	ldrb.w	lr, [r4, #14]
d0080d22:	ee18 2a10 	vmov	r2, s16
d0080d26:	ea40 2106 	orr.w	r1, r0, r6, lsl #8
d0080d2a:	f894 c00f 	ldrb.w	ip, [r4, #15]
d0080d2e:	6828      	ldr	r0, [r5, #0]
d0080d30:	ea41 460e 	orr.w	r6, r1, lr, lsl #16
d0080d34:	210e      	movs	r1, #14
d0080d36:	4438      	add	r0, r7
d0080d38:	ea46 660c 	orr.w	r6, r6, ip, lsl #24
d0080d3c:	6876      	ldr	r6, [r6, #4]
d0080d3e:	9700      	str	r7, [sp, #0]
d0080d40:	6b36      	ldr	r6, [r6, #48]	; 0x30
d0080d42:	47b0      	blx	r6
d0080d44:	7b21      	ldrb	r1, [r4, #12]
d0080d46:	f894 c00d 	ldrb.w	ip, [r4, #13]
d0080d4a:	463b      	mov	r3, r7
d0080d4c:	7ba6      	ldrb	r6, [r4, #14]
d0080d4e:	ee18 2a10 	vmov	r2, s16
d0080d52:	ea41 200c 	orr.w	r0, r1, ip, lsl #8
d0080d56:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080d5a:	210c      	movs	r1, #12
d0080d5c:	ea40 4c06 	orr.w	ip, r0, r6, lsl #16
d0080d60:	6828      	ldr	r0, [r5, #0]
d0080d62:	ea4c 660e 	orr.w	r6, ip, lr, lsl #24
d0080d66:	6876      	ldr	r6, [r6, #4]
d0080d68:	9700      	str	r7, [sp, #0]
d0080d6a:	6b36      	ldr	r6, [r6, #48]	; 0x30
d0080d6c:	47b0      	blx	r6
d0080d6e:	7b21      	ldrb	r1, [r4, #12]
d0080d70:	f894 c00d 	ldrb.w	ip, [r4, #13]
d0080d74:	463b      	mov	r3, r7
d0080d76:	7ba6      	ldrb	r6, [r4, #14]
d0080d78:	ee18 2a10 	vmov	r2, s16
d0080d7c:	ea41 200c 	orr.w	r0, r1, ip, lsl #8
d0080d80:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080d84:	2110      	movs	r1, #16
d0080d86:	ea40 4c06 	orr.w	ip, r0, r6, lsl #16
d0080d8a:	6828      	ldr	r0, [r5, #0]
d0080d8c:	ea4c 660e 	orr.w	r6, ip, lr, lsl #24
d0080d90:	6876      	ldr	r6, [r6, #4]
d0080d92:	9700      	str	r7, [sp, #0]
d0080d94:	6b36      	ldr	r6, [r6, #48]	; 0x30
d0080d96:	47b0      	blx	r6
d0080d98:	7b20      	ldrb	r0, [r4, #12]
d0080d9a:	7b62      	ldrb	r2, [r4, #13]
d0080d9c:	f04f 0e0c 	mov.w	lr, #12
d0080da0:	7ba1      	ldrb	r1, [r4, #14]
d0080da2:	f04f 0c57 	mov.w	ip, #87	; 0x57
d0080da6:	ea40 2302 	orr.w	r3, r0, r2, lsl #8
d0080daa:	7be6      	ldrb	r6, [r4, #15]
d0080dac:	2050      	movs	r0, #80	; 0x50
d0080dae:	ea43 4201 	orr.w	r2, r3, r1, lsl #16
d0080db2:	463b      	mov	r3, r7
d0080db4:	ea42 6106 	orr.w	r1, r2, r6, lsl #24
d0080db8:	ee18 2a10 	vmov	r2, s16
d0080dbc:	684e      	ldr	r6, [r1, #4]
d0080dbe:	210e      	movs	r1, #14
d0080dc0:	f8cd e00c 	str.w	lr, [sp, #12]
d0080dc4:	f8cd c008 	str.w	ip, [sp, #8]
d0080dc8:	9700      	str	r7, [sp, #0]
d0080dca:	9001      	str	r0, [sp, #4]
d0080dcc:	6828      	ldr	r0, [r5, #0]
d0080dce:	6b76      	ldr	r6, [r6, #52]	; 0x34
d0080dd0:	47b0      	blx	r6
d0080dd2:	7b26      	ldrb	r6, [r4, #12]
d0080dd4:	7b61      	ldrb	r1, [r4, #13]
d0080dd6:	2001      	movs	r0, #1
d0080dd8:	7ba2      	ldrb	r2, [r4, #14]
d0080dda:	ea46 2101 	orr.w	r1, r6, r1, lsl #8
d0080dde:	7be3      	ldrb	r3, [r4, #15]
d0080de0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0080de4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0080de8:	685b      	ldr	r3, [r3, #4]
d0080dea:	68db      	ldr	r3, [r3, #12]
d0080dec:	4798      	blx	r3
d0080dee:	7b21      	ldrb	r1, [r4, #12]
d0080df0:	f894 c00d 	ldrb.w	ip, [r4, #13]
d0080df4:	2305      	movs	r3, #5
d0080df6:	7ba6      	ldrb	r6, [r4, #14]
d0080df8:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0080dfc:	ea41 200c 	orr.w	r0, r1, ip, lsl #8
d0080e00:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080e04:	2120      	movs	r1, #32
d0080e06:	ea40 4c06 	orr.w	ip, r0, r6, lsl #16
d0080e0a:	2000      	movs	r0, #0
d0080e0c:	ea4c 660e 	orr.w	r6, ip, lr, lsl #24
d0080e10:	6876      	ldr	r6, [r6, #4]
d0080e12:	6876      	ldr	r6, [r6, #4]
d0080e14:	47b0      	blx	r6
d0080e16:	2105      	movs	r1, #5
d0080e18:	2000      	movs	r0, #0
d0080e1a:	f7ff f98f 	bl	d008013c <draw_star_speed_range>
d0080e1e:	f8bb 1000 	ldrh.w	r1, [fp]
d0080e22:	3901      	subs	r1, #1
d0080e24:	b209      	sxth	r1, r1
d0080e26:	f111 0fa5 	cmn.w	r1, #165	; 0xa5
d0080e2a:	db79      	blt.n	d0080f20 <main+0x7c8>
d0080e2c:	f8ab 1000 	strh.w	r1, [fp]
d0080e30:	7b22      	ldrb	r2, [r4, #12]
d0080e32:	f04f 0c76 	mov.w	ip, #118	; 0x76
d0080e36:	7b60      	ldrb	r0, [r4, #13]
d0080e38:	23a5      	movs	r3, #165	; 0xa5
d0080e3a:	7ba6      	ldrb	r6, [r4, #14]
d0080e3c:	ea42 2200 	orr.w	r2, r2, r0, lsl #8
d0080e40:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080e44:	ea42 4006 	orr.w	r0, r2, r6, lsl #16
d0080e48:	2225      	movs	r2, #37	; 0x25
d0080e4a:	ea40 660e 	orr.w	r6, r0, lr, lsl #24
d0080e4e:	4838      	ldr	r0, [pc, #224]	; (d0080f30 <main+0x7d8>)
d0080e50:	6876      	ldr	r6, [r6, #4]
d0080e52:	f8cd c000 	str.w	ip, [sp]
d0080e56:	69b6      	ldr	r6, [r6, #24]
d0080e58:	47b0      	blx	r6
d0080e5a:	7b22      	ldrb	r2, [r4, #12]
d0080e5c:	7b60      	ldrb	r0, [r4, #13]
d0080e5e:	f04f 0c11 	mov.w	ip, #17
d0080e62:	7ba6      	ldrb	r6, [r4, #14]
d0080e64:	231f      	movs	r3, #31
d0080e66:	ea42 2100 	orr.w	r1, r2, r0, lsl #8
d0080e6a:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080e6e:	2278      	movs	r2, #120	; 0x78
d0080e70:	ea41 4006 	orr.w	r0, r1, r6, lsl #16
d0080e74:	211e      	movs	r1, #30
d0080e76:	ea40 660e 	orr.w	r6, r0, lr, lsl #24
d0080e7a:	482e      	ldr	r0, [pc, #184]	; (d0080f34 <main+0x7dc>)
d0080e7c:	6876      	ldr	r6, [r6, #4]
d0080e7e:	f8cd c000 	str.w	ip, [sp]
d0080e82:	69b6      	ldr	r6, [r6, #24]
d0080e84:	47b0      	blx	r6
d0080e86:	7b21      	ldrb	r1, [r4, #12]
d0080e88:	f894 c00d 	ldrb.w	ip, [r4, #13]
d0080e8c:	2320      	movs	r3, #32
d0080e8e:	7ba6      	ldrb	r6, [r4, #14]
d0080e90:	2275      	movs	r2, #117	; 0x75
d0080e92:	ea41 200c 	orr.w	r0, r1, ip, lsl #8
d0080e96:	f894 e00f 	ldrb.w	lr, [r4, #15]
d0080e9a:	f44f 71a0 	mov.w	r1, #320	; 0x140
d0080e9e:	ea40 4c06 	orr.w	ip, r0, r6, lsl #16
d0080ea2:	4825      	ldr	r0, [pc, #148]	; (d0080f38 <main+0x7e0>)
d0080ea4:	ea4c 660e 	orr.w	r6, ip, lr, lsl #24
d0080ea8:	6876      	ldr	r6, [r6, #4]
d0080eaa:	9300      	str	r3, [sp, #0]
d0080eac:	69b6      	ldr	r6, [r6, #24]
d0080eae:	47b0      	blx	r6
d0080eb0:	21ff      	movs	r1, #255	; 0xff
d0080eb2:	2007      	movs	r0, #7
d0080eb4:	f7ff f942 	bl	d008013c <draw_star_speed_range>
d0080eb8:	f898 3000 	ldrb.w	r3, [r8]
d0080ebc:	f1c3 0301 	rsb	r3, r3, #1
d0080ec0:	b2db      	uxtb	r3, r3
d0080ec2:	f888 3000 	strb.w	r3, [r8]
d0080ec6:	f898 3000 	ldrb.w	r3, [r8]
d0080eca:	7b21      	ldrb	r1, [r4, #12]
d0080ecc:	7b60      	ldrb	r0, [r4, #13]
d0080ece:	7ba2      	ldrb	r2, [r4, #14]
d0080ed0:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d0080ed4:	b1eb      	cbz	r3, d0080f12 <main+0x7ba>
d0080ed6:	4919      	ldr	r1, [pc, #100]	; (d0080f3c <main+0x7e4>)
d0080ed8:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d0080edc:	7be3      	ldrb	r3, [r4, #15]
d0080ede:	6809      	ldr	r1, [r1, #0]
d0080ee0:	4817      	ldr	r0, [pc, #92]	; (d0080f40 <main+0x7e8>)
d0080ee2:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0080ee6:	6800      	ldr	r0, [r0, #0]
d0080ee8:	681b      	ldr	r3, [r3, #0]
d0080eea:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d0080eec:	4798      	blx	r3
d0080eee:	7b20      	ldrb	r0, [r4, #12]
d0080ef0:	7b61      	ldrb	r1, [r4, #13]
d0080ef2:	7ba2      	ldrb	r2, [r4, #14]
d0080ef4:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0080ef8:	7be3      	ldrb	r3, [r4, #15]
d0080efa:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0080efe:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0080f02:	681b      	ldr	r3, [r3, #0]
d0080f04:	681b      	ldr	r3, [r3, #0]
d0080f06:	4798      	blx	r3
d0080f08:	e676      	b.n	d0080bf8 <main+0x4a0>
d0080f0a:	2100      	movs	r1, #0
d0080f0c:	f8c9 1000 	str.w	r1, [r9]
d0080f10:	e695      	b.n	d0080c3e <main+0x4e6>
d0080f12:	490b      	ldr	r1, [pc, #44]	; (d0080f40 <main+0x7e8>)
d0080f14:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d0080f18:	7be3      	ldrb	r3, [r4, #15]
d0080f1a:	6809      	ldr	r1, [r1, #0]
d0080f1c:	4807      	ldr	r0, [pc, #28]	; (d0080f3c <main+0x7e4>)
d0080f1e:	e7e0      	b.n	d0080ee2 <main+0x78a>
d0080f20:	f44f 7370 	mov.w	r3, #960	; 0x3c0
d0080f24:	4619      	mov	r1, r3
d0080f26:	f8ab 3000 	strh.w	r3, [fp]
d0080f2a:	e781      	b.n	d0080e30 <main+0x6d8>
d0080f2c:	d0086d80 	.word	0xd0086d80
d0080f30:	d0081b60 	.word	0xd0081b60
d0080f34:	d0086b70 	.word	0xd0086b70
d0080f38:	d0086770 	.word	0xd0086770
d0080f3c:	d0087a40 	.word	0xd0087a40
d0080f40:	d0087a60 	.word	0xd0087a60

d0080f44 <__errno>:
d0080f44:	4b01      	ldr	r3, [pc, #4]	; (d0080f4c <__errno+0x8>)
d0080f46:	6818      	ldr	r0, [r3, #0]
d0080f48:	4770      	bx	lr
d0080f4a:	bf00      	nop
d0080f4c:	d0087724 	.word	0xd0087724

d0080f50 <malloc>:
d0080f50:	4b02      	ldr	r3, [pc, #8]	; (d0080f5c <malloc+0xc>)
d0080f52:	4601      	mov	r1, r0
d0080f54:	6818      	ldr	r0, [r3, #0]
d0080f56:	f000 b85b 	b.w	d0081010 <_malloc_r>
d0080f5a:	bf00      	nop
d0080f5c:	d0087724 	.word	0xd0087724

d0080f60 <memset>:
d0080f60:	4402      	add	r2, r0
d0080f62:	4603      	mov	r3, r0
d0080f64:	4293      	cmp	r3, r2
d0080f66:	d100      	bne.n	d0080f6a <memset+0xa>
d0080f68:	4770      	bx	lr
d0080f6a:	f803 1b01 	strb.w	r1, [r3], #1
d0080f6e:	e7f9      	b.n	d0080f64 <memset+0x4>

d0080f70 <_free_r>:
d0080f70:	b537      	push	{r0, r1, r2, r4, r5, lr}
d0080f72:	2900      	cmp	r1, #0
d0080f74:	d048      	beq.n	d0081008 <_free_r+0x98>
d0080f76:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0080f7a:	9001      	str	r0, [sp, #4]
d0080f7c:	2b00      	cmp	r3, #0
d0080f7e:	f1a1 0404 	sub.w	r4, r1, #4
d0080f82:	bfb8      	it	lt
d0080f84:	18e4      	addlt	r4, r4, r3
d0080f86:	f000 fb49 	bl	d008161c <__malloc_lock>
d0080f8a:	4a20      	ldr	r2, [pc, #128]	; (d008100c <_free_r+0x9c>)
d0080f8c:	9801      	ldr	r0, [sp, #4]
d0080f8e:	6813      	ldr	r3, [r2, #0]
d0080f90:	4615      	mov	r5, r2
d0080f92:	b933      	cbnz	r3, d0080fa2 <_free_r+0x32>
d0080f94:	6063      	str	r3, [r4, #4]
d0080f96:	6014      	str	r4, [r2, #0]
d0080f98:	b003      	add	sp, #12
d0080f9a:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d0080f9e:	f000 bb43 	b.w	d0081628 <__malloc_unlock>
d0080fa2:	42a3      	cmp	r3, r4
d0080fa4:	d90b      	bls.n	d0080fbe <_free_r+0x4e>
d0080fa6:	6821      	ldr	r1, [r4, #0]
d0080fa8:	1862      	adds	r2, r4, r1
d0080faa:	4293      	cmp	r3, r2
d0080fac:	bf04      	itt	eq
d0080fae:	681a      	ldreq	r2, [r3, #0]
d0080fb0:	685b      	ldreq	r3, [r3, #4]
d0080fb2:	6063      	str	r3, [r4, #4]
d0080fb4:	bf04      	itt	eq
d0080fb6:	1852      	addeq	r2, r2, r1
d0080fb8:	6022      	streq	r2, [r4, #0]
d0080fba:	602c      	str	r4, [r5, #0]
d0080fbc:	e7ec      	b.n	d0080f98 <_free_r+0x28>
d0080fbe:	461a      	mov	r2, r3
d0080fc0:	685b      	ldr	r3, [r3, #4]
d0080fc2:	b10b      	cbz	r3, d0080fc8 <_free_r+0x58>
d0080fc4:	42a3      	cmp	r3, r4
d0080fc6:	d9fa      	bls.n	d0080fbe <_free_r+0x4e>
d0080fc8:	6811      	ldr	r1, [r2, #0]
d0080fca:	1855      	adds	r5, r2, r1
d0080fcc:	42a5      	cmp	r5, r4
d0080fce:	d10b      	bne.n	d0080fe8 <_free_r+0x78>
d0080fd0:	6824      	ldr	r4, [r4, #0]
d0080fd2:	4421      	add	r1, r4
d0080fd4:	1854      	adds	r4, r2, r1
d0080fd6:	42a3      	cmp	r3, r4
d0080fd8:	6011      	str	r1, [r2, #0]
d0080fda:	d1dd      	bne.n	d0080f98 <_free_r+0x28>
d0080fdc:	681c      	ldr	r4, [r3, #0]
d0080fde:	685b      	ldr	r3, [r3, #4]
d0080fe0:	6053      	str	r3, [r2, #4]
d0080fe2:	4421      	add	r1, r4
d0080fe4:	6011      	str	r1, [r2, #0]
d0080fe6:	e7d7      	b.n	d0080f98 <_free_r+0x28>
d0080fe8:	d902      	bls.n	d0080ff0 <_free_r+0x80>
d0080fea:	230c      	movs	r3, #12
d0080fec:	6003      	str	r3, [r0, #0]
d0080fee:	e7d3      	b.n	d0080f98 <_free_r+0x28>
d0080ff0:	6825      	ldr	r5, [r4, #0]
d0080ff2:	1961      	adds	r1, r4, r5
d0080ff4:	428b      	cmp	r3, r1
d0080ff6:	bf04      	itt	eq
d0080ff8:	6819      	ldreq	r1, [r3, #0]
d0080ffa:	685b      	ldreq	r3, [r3, #4]
d0080ffc:	6063      	str	r3, [r4, #4]
d0080ffe:	bf04      	itt	eq
d0081000:	1949      	addeq	r1, r1, r5
d0081002:	6021      	streq	r1, [r4, #0]
d0081004:	6054      	str	r4, [r2, #4]
d0081006:	e7c7      	b.n	d0080f98 <_free_r+0x28>
d0081008:	b003      	add	sp, #12
d008100a:	bd30      	pop	{r4, r5, pc}
d008100c:	d0087a00 	.word	0xd0087a00

d0081010 <_malloc_r>:
d0081010:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0081012:	1ccd      	adds	r5, r1, #3
d0081014:	f025 0503 	bic.w	r5, r5, #3
d0081018:	3508      	adds	r5, #8
d008101a:	2d0c      	cmp	r5, #12
d008101c:	bf38      	it	cc
d008101e:	250c      	movcc	r5, #12
d0081020:	2d00      	cmp	r5, #0
d0081022:	4606      	mov	r6, r0
d0081024:	db01      	blt.n	d008102a <_malloc_r+0x1a>
d0081026:	42a9      	cmp	r1, r5
d0081028:	d903      	bls.n	d0081032 <_malloc_r+0x22>
d008102a:	230c      	movs	r3, #12
d008102c:	6033      	str	r3, [r6, #0]
d008102e:	2000      	movs	r0, #0
d0081030:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0081032:	f000 faf3 	bl	d008161c <__malloc_lock>
d0081036:	4921      	ldr	r1, [pc, #132]	; (d00810bc <_malloc_r+0xac>)
d0081038:	680a      	ldr	r2, [r1, #0]
d008103a:	4614      	mov	r4, r2
d008103c:	b99c      	cbnz	r4, d0081066 <_malloc_r+0x56>
d008103e:	4f20      	ldr	r7, [pc, #128]	; (d00810c0 <_malloc_r+0xb0>)
d0081040:	683b      	ldr	r3, [r7, #0]
d0081042:	b923      	cbnz	r3, d008104e <_malloc_r+0x3e>
d0081044:	4621      	mov	r1, r4
d0081046:	4630      	mov	r0, r6
d0081048:	f7ff f858 	bl	d00800fc <_sbrk_r>
d008104c:	6038      	str	r0, [r7, #0]
d008104e:	4629      	mov	r1, r5
d0081050:	4630      	mov	r0, r6
d0081052:	f7ff f853 	bl	d00800fc <_sbrk_r>
d0081056:	1c43      	adds	r3, r0, #1
d0081058:	d123      	bne.n	d00810a2 <_malloc_r+0x92>
d008105a:	230c      	movs	r3, #12
d008105c:	6033      	str	r3, [r6, #0]
d008105e:	4630      	mov	r0, r6
d0081060:	f000 fae2 	bl	d0081628 <__malloc_unlock>
d0081064:	e7e3      	b.n	d008102e <_malloc_r+0x1e>
d0081066:	6823      	ldr	r3, [r4, #0]
d0081068:	1b5b      	subs	r3, r3, r5
d008106a:	d417      	bmi.n	d008109c <_malloc_r+0x8c>
d008106c:	2b0b      	cmp	r3, #11
d008106e:	d903      	bls.n	d0081078 <_malloc_r+0x68>
d0081070:	6023      	str	r3, [r4, #0]
d0081072:	441c      	add	r4, r3
d0081074:	6025      	str	r5, [r4, #0]
d0081076:	e004      	b.n	d0081082 <_malloc_r+0x72>
d0081078:	6863      	ldr	r3, [r4, #4]
d008107a:	42a2      	cmp	r2, r4
d008107c:	bf0c      	ite	eq
d008107e:	600b      	streq	r3, [r1, #0]
d0081080:	6053      	strne	r3, [r2, #4]
d0081082:	4630      	mov	r0, r6
d0081084:	f000 fad0 	bl	d0081628 <__malloc_unlock>
d0081088:	f104 000b 	add.w	r0, r4, #11
d008108c:	1d23      	adds	r3, r4, #4
d008108e:	f020 0007 	bic.w	r0, r0, #7
d0081092:	1ac2      	subs	r2, r0, r3
d0081094:	d0cc      	beq.n	d0081030 <_malloc_r+0x20>
d0081096:	1a1b      	subs	r3, r3, r0
d0081098:	50a3      	str	r3, [r4, r2]
d008109a:	e7c9      	b.n	d0081030 <_malloc_r+0x20>
d008109c:	4622      	mov	r2, r4
d008109e:	6864      	ldr	r4, [r4, #4]
d00810a0:	e7cc      	b.n	d008103c <_malloc_r+0x2c>
d00810a2:	1cc4      	adds	r4, r0, #3
d00810a4:	f024 0403 	bic.w	r4, r4, #3
d00810a8:	42a0      	cmp	r0, r4
d00810aa:	d0e3      	beq.n	d0081074 <_malloc_r+0x64>
d00810ac:	1a21      	subs	r1, r4, r0
d00810ae:	4630      	mov	r0, r6
d00810b0:	f7ff f824 	bl	d00800fc <_sbrk_r>
d00810b4:	3001      	adds	r0, #1
d00810b6:	d1dd      	bne.n	d0081074 <_malloc_r+0x64>
d00810b8:	e7cf      	b.n	d008105a <_malloc_r+0x4a>
d00810ba:	bf00      	nop
d00810bc:	d0087a00 	.word	0xd0087a00
d00810c0:	d0087a04 	.word	0xd0087a04

d00810c4 <setbuf>:
d00810c4:	2900      	cmp	r1, #0
d00810c6:	f44f 6380 	mov.w	r3, #1024	; 0x400
d00810ca:	bf0c      	ite	eq
d00810cc:	2202      	moveq	r2, #2
d00810ce:	2200      	movne	r2, #0
d00810d0:	f000 b800 	b.w	d00810d4 <setvbuf>

d00810d4 <setvbuf>:
d00810d4:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d00810d8:	461d      	mov	r5, r3
d00810da:	4b5d      	ldr	r3, [pc, #372]	; (d0081250 <setvbuf+0x17c>)
d00810dc:	681f      	ldr	r7, [r3, #0]
d00810de:	4604      	mov	r4, r0
d00810e0:	460e      	mov	r6, r1
d00810e2:	4690      	mov	r8, r2
d00810e4:	b127      	cbz	r7, d00810f0 <setvbuf+0x1c>
d00810e6:	69bb      	ldr	r3, [r7, #24]
d00810e8:	b913      	cbnz	r3, d00810f0 <setvbuf+0x1c>
d00810ea:	4638      	mov	r0, r7
d00810ec:	f000 f9d2 	bl	d0081494 <__sinit>
d00810f0:	4b58      	ldr	r3, [pc, #352]	; (d0081254 <setvbuf+0x180>)
d00810f2:	429c      	cmp	r4, r3
d00810f4:	d167      	bne.n	d00811c6 <setvbuf+0xf2>
d00810f6:	687c      	ldr	r4, [r7, #4]
d00810f8:	f1b8 0f02 	cmp.w	r8, #2
d00810fc:	d006      	beq.n	d008110c <setvbuf+0x38>
d00810fe:	f1b8 0f01 	cmp.w	r8, #1
d0081102:	f200 809f 	bhi.w	d0081244 <setvbuf+0x170>
d0081106:	2d00      	cmp	r5, #0
d0081108:	f2c0 809c 	blt.w	d0081244 <setvbuf+0x170>
d008110c:	6e63      	ldr	r3, [r4, #100]	; 0x64
d008110e:	07db      	lsls	r3, r3, #31
d0081110:	d405      	bmi.n	d008111e <setvbuf+0x4a>
d0081112:	89a3      	ldrh	r3, [r4, #12]
d0081114:	0598      	lsls	r0, r3, #22
d0081116:	d402      	bmi.n	d008111e <setvbuf+0x4a>
d0081118:	6da0      	ldr	r0, [r4, #88]	; 0x58
d008111a:	f000 fa59 	bl	d00815d0 <__retarget_lock_acquire_recursive>
d008111e:	4621      	mov	r1, r4
d0081120:	4638      	mov	r0, r7
d0081122:	f000 f923 	bl	d008136c <_fflush_r>
d0081126:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0081128:	b141      	cbz	r1, d008113c <setvbuf+0x68>
d008112a:	f104 0344 	add.w	r3, r4, #68	; 0x44
d008112e:	4299      	cmp	r1, r3
d0081130:	d002      	beq.n	d0081138 <setvbuf+0x64>
d0081132:	4638      	mov	r0, r7
d0081134:	f7ff ff1c 	bl	d0080f70 <_free_r>
d0081138:	2300      	movs	r3, #0
d008113a:	6363      	str	r3, [r4, #52]	; 0x34
d008113c:	2300      	movs	r3, #0
d008113e:	61a3      	str	r3, [r4, #24]
d0081140:	6063      	str	r3, [r4, #4]
d0081142:	89a3      	ldrh	r3, [r4, #12]
d0081144:	0619      	lsls	r1, r3, #24
d0081146:	d503      	bpl.n	d0081150 <setvbuf+0x7c>
d0081148:	6921      	ldr	r1, [r4, #16]
d008114a:	4638      	mov	r0, r7
d008114c:	f7ff ff10 	bl	d0080f70 <_free_r>
d0081150:	89a3      	ldrh	r3, [r4, #12]
d0081152:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d0081156:	f023 0303 	bic.w	r3, r3, #3
d008115a:	f1b8 0f02 	cmp.w	r8, #2
d008115e:	81a3      	strh	r3, [r4, #12]
d0081160:	d06c      	beq.n	d008123c <setvbuf+0x168>
d0081162:	ab01      	add	r3, sp, #4
d0081164:	466a      	mov	r2, sp
d0081166:	4621      	mov	r1, r4
d0081168:	4638      	mov	r0, r7
d008116a:	f000 fa33 	bl	d00815d4 <__swhatbuf_r>
d008116e:	89a3      	ldrh	r3, [r4, #12]
d0081170:	4318      	orrs	r0, r3
d0081172:	81a0      	strh	r0, [r4, #12]
d0081174:	2d00      	cmp	r5, #0
d0081176:	d130      	bne.n	d00811da <setvbuf+0x106>
d0081178:	9d00      	ldr	r5, [sp, #0]
d008117a:	4628      	mov	r0, r5
d008117c:	f7ff fee8 	bl	d0080f50 <malloc>
d0081180:	4606      	mov	r6, r0
d0081182:	2800      	cmp	r0, #0
d0081184:	d155      	bne.n	d0081232 <setvbuf+0x15e>
d0081186:	f8dd 9000 	ldr.w	r9, [sp]
d008118a:	45a9      	cmp	r9, r5
d008118c:	d14a      	bne.n	d0081224 <setvbuf+0x150>
d008118e:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0081192:	2200      	movs	r2, #0
d0081194:	60a2      	str	r2, [r4, #8]
d0081196:	f104 0247 	add.w	r2, r4, #71	; 0x47
d008119a:	6022      	str	r2, [r4, #0]
d008119c:	6122      	str	r2, [r4, #16]
d008119e:	2201      	movs	r2, #1
d00811a0:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d00811a4:	6162      	str	r2, [r4, #20]
d00811a6:	6e62      	ldr	r2, [r4, #100]	; 0x64
d00811a8:	f043 0302 	orr.w	r3, r3, #2
d00811ac:	07d2      	lsls	r2, r2, #31
d00811ae:	81a3      	strh	r3, [r4, #12]
d00811b0:	d405      	bmi.n	d00811be <setvbuf+0xea>
d00811b2:	f413 7f00 	tst.w	r3, #512	; 0x200
d00811b6:	d102      	bne.n	d00811be <setvbuf+0xea>
d00811b8:	6da0      	ldr	r0, [r4, #88]	; 0x58
d00811ba:	f000 fa0a 	bl	d00815d2 <__retarget_lock_release_recursive>
d00811be:	4628      	mov	r0, r5
d00811c0:	b003      	add	sp, #12
d00811c2:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d00811c6:	4b24      	ldr	r3, [pc, #144]	; (d0081258 <setvbuf+0x184>)
d00811c8:	429c      	cmp	r4, r3
d00811ca:	d101      	bne.n	d00811d0 <setvbuf+0xfc>
d00811cc:	68bc      	ldr	r4, [r7, #8]
d00811ce:	e793      	b.n	d00810f8 <setvbuf+0x24>
d00811d0:	4b22      	ldr	r3, [pc, #136]	; (d008125c <setvbuf+0x188>)
d00811d2:	429c      	cmp	r4, r3
d00811d4:	bf08      	it	eq
d00811d6:	68fc      	ldreq	r4, [r7, #12]
d00811d8:	e78e      	b.n	d00810f8 <setvbuf+0x24>
d00811da:	2e00      	cmp	r6, #0
d00811dc:	d0cd      	beq.n	d008117a <setvbuf+0xa6>
d00811de:	69bb      	ldr	r3, [r7, #24]
d00811e0:	b913      	cbnz	r3, d00811e8 <setvbuf+0x114>
d00811e2:	4638      	mov	r0, r7
d00811e4:	f000 f956 	bl	d0081494 <__sinit>
d00811e8:	f1b8 0f01 	cmp.w	r8, #1
d00811ec:	bf08      	it	eq
d00811ee:	89a3      	ldrheq	r3, [r4, #12]
d00811f0:	6026      	str	r6, [r4, #0]
d00811f2:	bf04      	itt	eq
d00811f4:	f043 0301 	orreq.w	r3, r3, #1
d00811f8:	81a3      	strheq	r3, [r4, #12]
d00811fa:	89a2      	ldrh	r2, [r4, #12]
d00811fc:	f012 0308 	ands.w	r3, r2, #8
d0081200:	e9c4 6504 	strd	r6, r5, [r4, #16]
d0081204:	d01c      	beq.n	d0081240 <setvbuf+0x16c>
d0081206:	07d3      	lsls	r3, r2, #31
d0081208:	bf41      	itttt	mi
d008120a:	2300      	movmi	r3, #0
d008120c:	426d      	negmi	r5, r5
d008120e:	60a3      	strmi	r3, [r4, #8]
d0081210:	61a5      	strmi	r5, [r4, #24]
d0081212:	bf58      	it	pl
d0081214:	60a5      	strpl	r5, [r4, #8]
d0081216:	6e65      	ldr	r5, [r4, #100]	; 0x64
d0081218:	f015 0501 	ands.w	r5, r5, #1
d008121c:	d115      	bne.n	d008124a <setvbuf+0x176>
d008121e:	f412 7f00 	tst.w	r2, #512	; 0x200
d0081222:	e7c8      	b.n	d00811b6 <setvbuf+0xe2>
d0081224:	4648      	mov	r0, r9
d0081226:	f7ff fe93 	bl	d0080f50 <malloc>
d008122a:	4606      	mov	r6, r0
d008122c:	2800      	cmp	r0, #0
d008122e:	d0ae      	beq.n	d008118e <setvbuf+0xba>
d0081230:	464d      	mov	r5, r9
d0081232:	89a3      	ldrh	r3, [r4, #12]
d0081234:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0081238:	81a3      	strh	r3, [r4, #12]
d008123a:	e7d0      	b.n	d00811de <setvbuf+0x10a>
d008123c:	2500      	movs	r5, #0
d008123e:	e7a8      	b.n	d0081192 <setvbuf+0xbe>
d0081240:	60a3      	str	r3, [r4, #8]
d0081242:	e7e8      	b.n	d0081216 <setvbuf+0x142>
d0081244:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0081248:	e7b9      	b.n	d00811be <setvbuf+0xea>
d008124a:	2500      	movs	r5, #0
d008124c:	e7b7      	b.n	d00811be <setvbuf+0xea>
d008124e:	bf00      	nop
d0081250:	d0087724 	.word	0xd0087724
d0081254:	d00876a0 	.word	0xd00876a0
d0081258:	d00876c0 	.word	0xd00876c0
d008125c:	d0087680 	.word	0xd0087680

d0081260 <__sflush_r>:
d0081260:	898a      	ldrh	r2, [r1, #12]
d0081262:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0081266:	4605      	mov	r5, r0
d0081268:	0710      	lsls	r0, r2, #28
d008126a:	460c      	mov	r4, r1
d008126c:	d458      	bmi.n	d0081320 <__sflush_r+0xc0>
d008126e:	684b      	ldr	r3, [r1, #4]
d0081270:	2b00      	cmp	r3, #0
d0081272:	dc05      	bgt.n	d0081280 <__sflush_r+0x20>
d0081274:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d0081276:	2b00      	cmp	r3, #0
d0081278:	dc02      	bgt.n	d0081280 <__sflush_r+0x20>
d008127a:	2000      	movs	r0, #0
d008127c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d0081280:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0081282:	2e00      	cmp	r6, #0
d0081284:	d0f9      	beq.n	d008127a <__sflush_r+0x1a>
d0081286:	2300      	movs	r3, #0
d0081288:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d008128c:	682f      	ldr	r7, [r5, #0]
d008128e:	602b      	str	r3, [r5, #0]
d0081290:	d032      	beq.n	d00812f8 <__sflush_r+0x98>
d0081292:	6d60      	ldr	r0, [r4, #84]	; 0x54
d0081294:	89a3      	ldrh	r3, [r4, #12]
d0081296:	075a      	lsls	r2, r3, #29
d0081298:	d505      	bpl.n	d00812a6 <__sflush_r+0x46>
d008129a:	6863      	ldr	r3, [r4, #4]
d008129c:	1ac0      	subs	r0, r0, r3
d008129e:	6b63      	ldr	r3, [r4, #52]	; 0x34
d00812a0:	b10b      	cbz	r3, d00812a6 <__sflush_r+0x46>
d00812a2:	6c23      	ldr	r3, [r4, #64]	; 0x40
d00812a4:	1ac0      	subs	r0, r0, r3
d00812a6:	2300      	movs	r3, #0
d00812a8:	4602      	mov	r2, r0
d00812aa:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d00812ac:	6a21      	ldr	r1, [r4, #32]
d00812ae:	4628      	mov	r0, r5
d00812b0:	47b0      	blx	r6
d00812b2:	1c43      	adds	r3, r0, #1
d00812b4:	89a3      	ldrh	r3, [r4, #12]
d00812b6:	d106      	bne.n	d00812c6 <__sflush_r+0x66>
d00812b8:	6829      	ldr	r1, [r5, #0]
d00812ba:	291d      	cmp	r1, #29
d00812bc:	d82c      	bhi.n	d0081318 <__sflush_r+0xb8>
d00812be:	4a2a      	ldr	r2, [pc, #168]	; (d0081368 <__sflush_r+0x108>)
d00812c0:	40ca      	lsrs	r2, r1
d00812c2:	07d6      	lsls	r6, r2, #31
d00812c4:	d528      	bpl.n	d0081318 <__sflush_r+0xb8>
d00812c6:	2200      	movs	r2, #0
d00812c8:	6062      	str	r2, [r4, #4]
d00812ca:	04d9      	lsls	r1, r3, #19
d00812cc:	6922      	ldr	r2, [r4, #16]
d00812ce:	6022      	str	r2, [r4, #0]
d00812d0:	d504      	bpl.n	d00812dc <__sflush_r+0x7c>
d00812d2:	1c42      	adds	r2, r0, #1
d00812d4:	d101      	bne.n	d00812da <__sflush_r+0x7a>
d00812d6:	682b      	ldr	r3, [r5, #0]
d00812d8:	b903      	cbnz	r3, d00812dc <__sflush_r+0x7c>
d00812da:	6560      	str	r0, [r4, #84]	; 0x54
d00812dc:	6b61      	ldr	r1, [r4, #52]	; 0x34
d00812de:	602f      	str	r7, [r5, #0]
d00812e0:	2900      	cmp	r1, #0
d00812e2:	d0ca      	beq.n	d008127a <__sflush_r+0x1a>
d00812e4:	f104 0344 	add.w	r3, r4, #68	; 0x44
d00812e8:	4299      	cmp	r1, r3
d00812ea:	d002      	beq.n	d00812f2 <__sflush_r+0x92>
d00812ec:	4628      	mov	r0, r5
d00812ee:	f7ff fe3f 	bl	d0080f70 <_free_r>
d00812f2:	2000      	movs	r0, #0
d00812f4:	6360      	str	r0, [r4, #52]	; 0x34
d00812f6:	e7c1      	b.n	d008127c <__sflush_r+0x1c>
d00812f8:	6a21      	ldr	r1, [r4, #32]
d00812fa:	2301      	movs	r3, #1
d00812fc:	4628      	mov	r0, r5
d00812fe:	47b0      	blx	r6
d0081300:	1c41      	adds	r1, r0, #1
d0081302:	d1c7      	bne.n	d0081294 <__sflush_r+0x34>
d0081304:	682b      	ldr	r3, [r5, #0]
d0081306:	2b00      	cmp	r3, #0
d0081308:	d0c4      	beq.n	d0081294 <__sflush_r+0x34>
d008130a:	2b1d      	cmp	r3, #29
d008130c:	d001      	beq.n	d0081312 <__sflush_r+0xb2>
d008130e:	2b16      	cmp	r3, #22
d0081310:	d101      	bne.n	d0081316 <__sflush_r+0xb6>
d0081312:	602f      	str	r7, [r5, #0]
d0081314:	e7b1      	b.n	d008127a <__sflush_r+0x1a>
d0081316:	89a3      	ldrh	r3, [r4, #12]
d0081318:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d008131c:	81a3      	strh	r3, [r4, #12]
d008131e:	e7ad      	b.n	d008127c <__sflush_r+0x1c>
d0081320:	690f      	ldr	r7, [r1, #16]
d0081322:	2f00      	cmp	r7, #0
d0081324:	d0a9      	beq.n	d008127a <__sflush_r+0x1a>
d0081326:	0793      	lsls	r3, r2, #30
d0081328:	680e      	ldr	r6, [r1, #0]
d008132a:	bf08      	it	eq
d008132c:	694b      	ldreq	r3, [r1, #20]
d008132e:	600f      	str	r7, [r1, #0]
d0081330:	bf18      	it	ne
d0081332:	2300      	movne	r3, #0
d0081334:	eba6 0807 	sub.w	r8, r6, r7
d0081338:	608b      	str	r3, [r1, #8]
d008133a:	f1b8 0f00 	cmp.w	r8, #0
d008133e:	dd9c      	ble.n	d008127a <__sflush_r+0x1a>
d0081340:	6a21      	ldr	r1, [r4, #32]
d0081342:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d0081344:	4643      	mov	r3, r8
d0081346:	463a      	mov	r2, r7
d0081348:	4628      	mov	r0, r5
d008134a:	47b0      	blx	r6
d008134c:	2800      	cmp	r0, #0
d008134e:	dc06      	bgt.n	d008135e <__sflush_r+0xfe>
d0081350:	89a3      	ldrh	r3, [r4, #12]
d0081352:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0081356:	81a3      	strh	r3, [r4, #12]
d0081358:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d008135c:	e78e      	b.n	d008127c <__sflush_r+0x1c>
d008135e:	4407      	add	r7, r0
d0081360:	eba8 0800 	sub.w	r8, r8, r0
d0081364:	e7e9      	b.n	d008133a <__sflush_r+0xda>
d0081366:	bf00      	nop
d0081368:	20400001 	.word	0x20400001

d008136c <_fflush_r>:
d008136c:	b538      	push	{r3, r4, r5, lr}
d008136e:	690b      	ldr	r3, [r1, #16]
d0081370:	4605      	mov	r5, r0
d0081372:	460c      	mov	r4, r1
d0081374:	b913      	cbnz	r3, d008137c <_fflush_r+0x10>
d0081376:	2500      	movs	r5, #0
d0081378:	4628      	mov	r0, r5
d008137a:	bd38      	pop	{r3, r4, r5, pc}
d008137c:	b118      	cbz	r0, d0081386 <_fflush_r+0x1a>
d008137e:	6983      	ldr	r3, [r0, #24]
d0081380:	b90b      	cbnz	r3, d0081386 <_fflush_r+0x1a>
d0081382:	f000 f887 	bl	d0081494 <__sinit>
d0081386:	4b14      	ldr	r3, [pc, #80]	; (d00813d8 <_fflush_r+0x6c>)
d0081388:	429c      	cmp	r4, r3
d008138a:	d11b      	bne.n	d00813c4 <_fflush_r+0x58>
d008138c:	686c      	ldr	r4, [r5, #4]
d008138e:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0081392:	2b00      	cmp	r3, #0
d0081394:	d0ef      	beq.n	d0081376 <_fflush_r+0xa>
d0081396:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0081398:	07d0      	lsls	r0, r2, #31
d008139a:	d404      	bmi.n	d00813a6 <_fflush_r+0x3a>
d008139c:	0599      	lsls	r1, r3, #22
d008139e:	d402      	bmi.n	d00813a6 <_fflush_r+0x3a>
d00813a0:	6da0      	ldr	r0, [r4, #88]	; 0x58
d00813a2:	f000 f915 	bl	d00815d0 <__retarget_lock_acquire_recursive>
d00813a6:	4628      	mov	r0, r5
d00813a8:	4621      	mov	r1, r4
d00813aa:	f7ff ff59 	bl	d0081260 <__sflush_r>
d00813ae:	6e63      	ldr	r3, [r4, #100]	; 0x64
d00813b0:	07da      	lsls	r2, r3, #31
d00813b2:	4605      	mov	r5, r0
d00813b4:	d4e0      	bmi.n	d0081378 <_fflush_r+0xc>
d00813b6:	89a3      	ldrh	r3, [r4, #12]
d00813b8:	059b      	lsls	r3, r3, #22
d00813ba:	d4dd      	bmi.n	d0081378 <_fflush_r+0xc>
d00813bc:	6da0      	ldr	r0, [r4, #88]	; 0x58
d00813be:	f000 f908 	bl	d00815d2 <__retarget_lock_release_recursive>
d00813c2:	e7d9      	b.n	d0081378 <_fflush_r+0xc>
d00813c4:	4b05      	ldr	r3, [pc, #20]	; (d00813dc <_fflush_r+0x70>)
d00813c6:	429c      	cmp	r4, r3
d00813c8:	d101      	bne.n	d00813ce <_fflush_r+0x62>
d00813ca:	68ac      	ldr	r4, [r5, #8]
d00813cc:	e7df      	b.n	d008138e <_fflush_r+0x22>
d00813ce:	4b04      	ldr	r3, [pc, #16]	; (d00813e0 <_fflush_r+0x74>)
d00813d0:	429c      	cmp	r4, r3
d00813d2:	bf08      	it	eq
d00813d4:	68ec      	ldreq	r4, [r5, #12]
d00813d6:	e7da      	b.n	d008138e <_fflush_r+0x22>
d00813d8:	d00876a0 	.word	0xd00876a0
d00813dc:	d00876c0 	.word	0xd00876c0
d00813e0:	d0087680 	.word	0xd0087680

d00813e4 <std>:
d00813e4:	2300      	movs	r3, #0
d00813e6:	b510      	push	{r4, lr}
d00813e8:	4604      	mov	r4, r0
d00813ea:	e9c0 3300 	strd	r3, r3, [r0]
d00813ee:	e9c0 3304 	strd	r3, r3, [r0, #16]
d00813f2:	6083      	str	r3, [r0, #8]
d00813f4:	8181      	strh	r1, [r0, #12]
d00813f6:	6643      	str	r3, [r0, #100]	; 0x64
d00813f8:	81c2      	strh	r2, [r0, #14]
d00813fa:	6183      	str	r3, [r0, #24]
d00813fc:	4619      	mov	r1, r3
d00813fe:	2208      	movs	r2, #8
d0081400:	305c      	adds	r0, #92	; 0x5c
d0081402:	f7ff fdad 	bl	d0080f60 <memset>
d0081406:	4b05      	ldr	r3, [pc, #20]	; (d008141c <std+0x38>)
d0081408:	6263      	str	r3, [r4, #36]	; 0x24
d008140a:	4b05      	ldr	r3, [pc, #20]	; (d0081420 <std+0x3c>)
d008140c:	62a3      	str	r3, [r4, #40]	; 0x28
d008140e:	4b05      	ldr	r3, [pc, #20]	; (d0081424 <std+0x40>)
d0081410:	62e3      	str	r3, [r4, #44]	; 0x2c
d0081412:	4b05      	ldr	r3, [pc, #20]	; (d0081428 <std+0x44>)
d0081414:	6224      	str	r4, [r4, #32]
d0081416:	6323      	str	r3, [r4, #48]	; 0x30
d0081418:	bd10      	pop	{r4, pc}
d008141a:	bf00      	nop
d008141c:	d0081635 	.word	0xd0081635
d0081420:	d0081657 	.word	0xd0081657
d0081424:	d008168f 	.word	0xd008168f
d0081428:	d00816b3 	.word	0xd00816b3

d008142c <_cleanup_r>:
d008142c:	4901      	ldr	r1, [pc, #4]	; (d0081434 <_cleanup_r+0x8>)
d008142e:	f000 b8af 	b.w	d0081590 <_fwalk_reent>
d0081432:	bf00      	nop
d0081434:	d008136d 	.word	0xd008136d

d0081438 <__sfmoreglue>:
d0081438:	b570      	push	{r4, r5, r6, lr}
d008143a:	1e4a      	subs	r2, r1, #1
d008143c:	2568      	movs	r5, #104	; 0x68
d008143e:	4355      	muls	r5, r2
d0081440:	460e      	mov	r6, r1
d0081442:	f105 0174 	add.w	r1, r5, #116	; 0x74
d0081446:	f7ff fde3 	bl	d0081010 <_malloc_r>
d008144a:	4604      	mov	r4, r0
d008144c:	b140      	cbz	r0, d0081460 <__sfmoreglue+0x28>
d008144e:	2100      	movs	r1, #0
d0081450:	e9c0 1600 	strd	r1, r6, [r0]
d0081454:	300c      	adds	r0, #12
d0081456:	60a0      	str	r0, [r4, #8]
d0081458:	f105 0268 	add.w	r2, r5, #104	; 0x68
d008145c:	f7ff fd80 	bl	d0080f60 <memset>
d0081460:	4620      	mov	r0, r4
d0081462:	bd70      	pop	{r4, r5, r6, pc}

d0081464 <__sfp_lock_acquire>:
d0081464:	4801      	ldr	r0, [pc, #4]	; (d008146c <__sfp_lock_acquire+0x8>)
d0081466:	f000 b8b3 	b.w	d00815d0 <__retarget_lock_acquire_recursive>
d008146a:	bf00      	nop
d008146c:	d0087a6c 	.word	0xd0087a6c

d0081470 <__sfp_lock_release>:
d0081470:	4801      	ldr	r0, [pc, #4]	; (d0081478 <__sfp_lock_release+0x8>)
d0081472:	f000 b8ae 	b.w	d00815d2 <__retarget_lock_release_recursive>
d0081476:	bf00      	nop
d0081478:	d0087a6c 	.word	0xd0087a6c

d008147c <__sinit_lock_acquire>:
d008147c:	4801      	ldr	r0, [pc, #4]	; (d0081484 <__sinit_lock_acquire+0x8>)
d008147e:	f000 b8a7 	b.w	d00815d0 <__retarget_lock_acquire_recursive>
d0081482:	bf00      	nop
d0081484:	d0087a67 	.word	0xd0087a67

d0081488 <__sinit_lock_release>:
d0081488:	4801      	ldr	r0, [pc, #4]	; (d0081490 <__sinit_lock_release+0x8>)
d008148a:	f000 b8a2 	b.w	d00815d2 <__retarget_lock_release_recursive>
d008148e:	bf00      	nop
d0081490:	d0087a67 	.word	0xd0087a67

d0081494 <__sinit>:
d0081494:	b510      	push	{r4, lr}
d0081496:	4604      	mov	r4, r0
d0081498:	f7ff fff0 	bl	d008147c <__sinit_lock_acquire>
d008149c:	69a3      	ldr	r3, [r4, #24]
d008149e:	b11b      	cbz	r3, d00814a8 <__sinit+0x14>
d00814a0:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d00814a4:	f7ff bff0 	b.w	d0081488 <__sinit_lock_release>
d00814a8:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d00814ac:	6523      	str	r3, [r4, #80]	; 0x50
d00814ae:	4b13      	ldr	r3, [pc, #76]	; (d00814fc <__sinit+0x68>)
d00814b0:	4a13      	ldr	r2, [pc, #76]	; (d0081500 <__sinit+0x6c>)
d00814b2:	681b      	ldr	r3, [r3, #0]
d00814b4:	62a2      	str	r2, [r4, #40]	; 0x28
d00814b6:	42a3      	cmp	r3, r4
d00814b8:	bf04      	itt	eq
d00814ba:	2301      	moveq	r3, #1
d00814bc:	61a3      	streq	r3, [r4, #24]
d00814be:	4620      	mov	r0, r4
d00814c0:	f000 f820 	bl	d0081504 <__sfp>
d00814c4:	6060      	str	r0, [r4, #4]
d00814c6:	4620      	mov	r0, r4
d00814c8:	f000 f81c 	bl	d0081504 <__sfp>
d00814cc:	60a0      	str	r0, [r4, #8]
d00814ce:	4620      	mov	r0, r4
d00814d0:	f000 f818 	bl	d0081504 <__sfp>
d00814d4:	2200      	movs	r2, #0
d00814d6:	60e0      	str	r0, [r4, #12]
d00814d8:	2104      	movs	r1, #4
d00814da:	6860      	ldr	r0, [r4, #4]
d00814dc:	f7ff ff82 	bl	d00813e4 <std>
d00814e0:	68a0      	ldr	r0, [r4, #8]
d00814e2:	2201      	movs	r2, #1
d00814e4:	2109      	movs	r1, #9
d00814e6:	f7ff ff7d 	bl	d00813e4 <std>
d00814ea:	68e0      	ldr	r0, [r4, #12]
d00814ec:	2202      	movs	r2, #2
d00814ee:	2112      	movs	r1, #18
d00814f0:	f7ff ff78 	bl	d00813e4 <std>
d00814f4:	2301      	movs	r3, #1
d00814f6:	61a3      	str	r3, [r4, #24]
d00814f8:	e7d2      	b.n	d00814a0 <__sinit+0xc>
d00814fa:	bf00      	nop
d00814fc:	d008767c 	.word	0xd008767c
d0081500:	d008142d 	.word	0xd008142d

d0081504 <__sfp>:
d0081504:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0081506:	4607      	mov	r7, r0
d0081508:	f7ff ffac 	bl	d0081464 <__sfp_lock_acquire>
d008150c:	4b1e      	ldr	r3, [pc, #120]	; (d0081588 <__sfp+0x84>)
d008150e:	681e      	ldr	r6, [r3, #0]
d0081510:	69b3      	ldr	r3, [r6, #24]
d0081512:	b913      	cbnz	r3, d008151a <__sfp+0x16>
d0081514:	4630      	mov	r0, r6
d0081516:	f7ff ffbd 	bl	d0081494 <__sinit>
d008151a:	3648      	adds	r6, #72	; 0x48
d008151c:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d0081520:	3b01      	subs	r3, #1
d0081522:	d503      	bpl.n	d008152c <__sfp+0x28>
d0081524:	6833      	ldr	r3, [r6, #0]
d0081526:	b30b      	cbz	r3, d008156c <__sfp+0x68>
d0081528:	6836      	ldr	r6, [r6, #0]
d008152a:	e7f7      	b.n	d008151c <__sfp+0x18>
d008152c:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d0081530:	b9d5      	cbnz	r5, d0081568 <__sfp+0x64>
d0081532:	4b16      	ldr	r3, [pc, #88]	; (d008158c <__sfp+0x88>)
d0081534:	60e3      	str	r3, [r4, #12]
d0081536:	f104 0058 	add.w	r0, r4, #88	; 0x58
d008153a:	6665      	str	r5, [r4, #100]	; 0x64
d008153c:	f000 f847 	bl	d00815ce <__retarget_lock_init_recursive>
d0081540:	f7ff ff96 	bl	d0081470 <__sfp_lock_release>
d0081544:	e9c4 5501 	strd	r5, r5, [r4, #4]
d0081548:	e9c4 5504 	strd	r5, r5, [r4, #16]
d008154c:	6025      	str	r5, [r4, #0]
d008154e:	61a5      	str	r5, [r4, #24]
d0081550:	2208      	movs	r2, #8
d0081552:	4629      	mov	r1, r5
d0081554:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d0081558:	f7ff fd02 	bl	d0080f60 <memset>
d008155c:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d0081560:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d0081564:	4620      	mov	r0, r4
d0081566:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0081568:	3468      	adds	r4, #104	; 0x68
d008156a:	e7d9      	b.n	d0081520 <__sfp+0x1c>
d008156c:	2104      	movs	r1, #4
d008156e:	4638      	mov	r0, r7
d0081570:	f7ff ff62 	bl	d0081438 <__sfmoreglue>
d0081574:	4604      	mov	r4, r0
d0081576:	6030      	str	r0, [r6, #0]
d0081578:	2800      	cmp	r0, #0
d008157a:	d1d5      	bne.n	d0081528 <__sfp+0x24>
d008157c:	f7ff ff78 	bl	d0081470 <__sfp_lock_release>
d0081580:	230c      	movs	r3, #12
d0081582:	603b      	str	r3, [r7, #0]
d0081584:	e7ee      	b.n	d0081564 <__sfp+0x60>
d0081586:	bf00      	nop
d0081588:	d008767c 	.word	0xd008767c
d008158c:	ffff0001 	.word	0xffff0001

d0081590 <_fwalk_reent>:
d0081590:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0081594:	4606      	mov	r6, r0
d0081596:	4688      	mov	r8, r1
d0081598:	f100 0448 	add.w	r4, r0, #72	; 0x48
d008159c:	2700      	movs	r7, #0
d008159e:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d00815a2:	f1b9 0901 	subs.w	r9, r9, #1
d00815a6:	d505      	bpl.n	d00815b4 <_fwalk_reent+0x24>
d00815a8:	6824      	ldr	r4, [r4, #0]
d00815aa:	2c00      	cmp	r4, #0
d00815ac:	d1f7      	bne.n	d008159e <_fwalk_reent+0xe>
d00815ae:	4638      	mov	r0, r7
d00815b0:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d00815b4:	89ab      	ldrh	r3, [r5, #12]
d00815b6:	2b01      	cmp	r3, #1
d00815b8:	d907      	bls.n	d00815ca <_fwalk_reent+0x3a>
d00815ba:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d00815be:	3301      	adds	r3, #1
d00815c0:	d003      	beq.n	d00815ca <_fwalk_reent+0x3a>
d00815c2:	4629      	mov	r1, r5
d00815c4:	4630      	mov	r0, r6
d00815c6:	47c0      	blx	r8
d00815c8:	4307      	orrs	r7, r0
d00815ca:	3568      	adds	r5, #104	; 0x68
d00815cc:	e7e9      	b.n	d00815a2 <_fwalk_reent+0x12>

d00815ce <__retarget_lock_init_recursive>:
d00815ce:	4770      	bx	lr

d00815d0 <__retarget_lock_acquire_recursive>:
d00815d0:	4770      	bx	lr

d00815d2 <__retarget_lock_release_recursive>:
d00815d2:	4770      	bx	lr

d00815d4 <__swhatbuf_r>:
d00815d4:	b570      	push	{r4, r5, r6, lr}
d00815d6:	460e      	mov	r6, r1
d00815d8:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00815dc:	2900      	cmp	r1, #0
d00815de:	b096      	sub	sp, #88	; 0x58
d00815e0:	4614      	mov	r4, r2
d00815e2:	461d      	mov	r5, r3
d00815e4:	da07      	bge.n	d00815f6 <__swhatbuf_r+0x22>
d00815e6:	2300      	movs	r3, #0
d00815e8:	602b      	str	r3, [r5, #0]
d00815ea:	89b3      	ldrh	r3, [r6, #12]
d00815ec:	061a      	lsls	r2, r3, #24
d00815ee:	d410      	bmi.n	d0081612 <__swhatbuf_r+0x3e>
d00815f0:	f44f 6380 	mov.w	r3, #1024	; 0x400
d00815f4:	e00e      	b.n	d0081614 <__swhatbuf_r+0x40>
d00815f6:	466a      	mov	r2, sp
d00815f8:	f000 f870 	bl	d00816dc <_fstat_r>
d00815fc:	2800      	cmp	r0, #0
d00815fe:	dbf2      	blt.n	d00815e6 <__swhatbuf_r+0x12>
d0081600:	9a01      	ldr	r2, [sp, #4]
d0081602:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d0081606:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d008160a:	425a      	negs	r2, r3
d008160c:	415a      	adcs	r2, r3
d008160e:	602a      	str	r2, [r5, #0]
d0081610:	e7ee      	b.n	d00815f0 <__swhatbuf_r+0x1c>
d0081612:	2340      	movs	r3, #64	; 0x40
d0081614:	2000      	movs	r0, #0
d0081616:	6023      	str	r3, [r4, #0]
d0081618:	b016      	add	sp, #88	; 0x58
d008161a:	bd70      	pop	{r4, r5, r6, pc}

d008161c <__malloc_lock>:
d008161c:	4801      	ldr	r0, [pc, #4]	; (d0081624 <__malloc_lock+0x8>)
d008161e:	f7ff bfd7 	b.w	d00815d0 <__retarget_lock_acquire_recursive>
d0081622:	bf00      	nop
d0081624:	d0087a68 	.word	0xd0087a68

d0081628 <__malloc_unlock>:
d0081628:	4801      	ldr	r0, [pc, #4]	; (d0081630 <__malloc_unlock+0x8>)
d008162a:	f7ff bfd2 	b.w	d00815d2 <__retarget_lock_release_recursive>
d008162e:	bf00      	nop
d0081630:	d0087a68 	.word	0xd0087a68

d0081634 <__sread>:
d0081634:	b510      	push	{r4, lr}
d0081636:	460c      	mov	r4, r1
d0081638:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d008163c:	f000 f872 	bl	d0081724 <_read_r>
d0081640:	2800      	cmp	r0, #0
d0081642:	bfab      	itete	ge
d0081644:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d0081646:	89a3      	ldrhlt	r3, [r4, #12]
d0081648:	181b      	addge	r3, r3, r0
d008164a:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d008164e:	bfac      	ite	ge
d0081650:	6563      	strge	r3, [r4, #84]	; 0x54
d0081652:	81a3      	strhlt	r3, [r4, #12]
d0081654:	bd10      	pop	{r4, pc}

d0081656 <__swrite>:
d0081656:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d008165a:	461f      	mov	r7, r3
d008165c:	898b      	ldrh	r3, [r1, #12]
d008165e:	05db      	lsls	r3, r3, #23
d0081660:	4605      	mov	r5, r0
d0081662:	460c      	mov	r4, r1
d0081664:	4616      	mov	r6, r2
d0081666:	d505      	bpl.n	d0081674 <__swrite+0x1e>
d0081668:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d008166c:	2302      	movs	r3, #2
d008166e:	2200      	movs	r2, #0
d0081670:	f000 f846 	bl	d0081700 <_lseek_r>
d0081674:	89a3      	ldrh	r3, [r4, #12]
d0081676:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d008167a:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d008167e:	81a3      	strh	r3, [r4, #12]
d0081680:	4632      	mov	r2, r6
d0081682:	463b      	mov	r3, r7
d0081684:	4628      	mov	r0, r5
d0081686:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d008168a:	f7fe bcf1 	b.w	d0080070 <_write_r>

d008168e <__sseek>:
d008168e:	b510      	push	{r4, lr}
d0081690:	460c      	mov	r4, r1
d0081692:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0081696:	f000 f833 	bl	d0081700 <_lseek_r>
d008169a:	1c43      	adds	r3, r0, #1
d008169c:	89a3      	ldrh	r3, [r4, #12]
d008169e:	bf15      	itete	ne
d00816a0:	6560      	strne	r0, [r4, #84]	; 0x54
d00816a2:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d00816a6:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d00816aa:	81a3      	strheq	r3, [r4, #12]
d00816ac:	bf18      	it	ne
d00816ae:	81a3      	strhne	r3, [r4, #12]
d00816b0:	bd10      	pop	{r4, pc}

d00816b2 <__sclose>:
d00816b2:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00816b6:	f000 b801 	b.w	d00816bc <_close_r>
	...

d00816bc <_close_r>:
d00816bc:	b538      	push	{r3, r4, r5, lr}
d00816be:	4d06      	ldr	r5, [pc, #24]	; (d00816d8 <_close_r+0x1c>)
d00816c0:	2300      	movs	r3, #0
d00816c2:	4604      	mov	r4, r0
d00816c4:	4608      	mov	r0, r1
d00816c6:	602b      	str	r3, [r5, #0]
d00816c8:	f7fe fd0c 	bl	d00800e4 <_close>
d00816cc:	1c43      	adds	r3, r0, #1
d00816ce:	d102      	bne.n	d00816d6 <_close_r+0x1a>
d00816d0:	682b      	ldr	r3, [r5, #0]
d00816d2:	b103      	cbz	r3, d00816d6 <_close_r+0x1a>
d00816d4:	6023      	str	r3, [r4, #0]
d00816d6:	bd38      	pop	{r3, r4, r5, pc}
d00816d8:	d0087a70 	.word	0xd0087a70

d00816dc <_fstat_r>:
d00816dc:	b538      	push	{r3, r4, r5, lr}
d00816de:	4d07      	ldr	r5, [pc, #28]	; (d00816fc <_fstat_r+0x20>)
d00816e0:	2300      	movs	r3, #0
d00816e2:	4604      	mov	r4, r0
d00816e4:	4608      	mov	r0, r1
d00816e6:	4611      	mov	r1, r2
d00816e8:	602b      	str	r3, [r5, #0]
d00816ea:	f7fe fcff 	bl	d00800ec <_fstat>
d00816ee:	1c43      	adds	r3, r0, #1
d00816f0:	d102      	bne.n	d00816f8 <_fstat_r+0x1c>
d00816f2:	682b      	ldr	r3, [r5, #0]
d00816f4:	b103      	cbz	r3, d00816f8 <_fstat_r+0x1c>
d00816f6:	6023      	str	r3, [r4, #0]
d00816f8:	bd38      	pop	{r3, r4, r5, pc}
d00816fa:	bf00      	nop
d00816fc:	d0087a70 	.word	0xd0087a70

d0081700 <_lseek_r>:
d0081700:	b538      	push	{r3, r4, r5, lr}
d0081702:	4d07      	ldr	r5, [pc, #28]	; (d0081720 <_lseek_r+0x20>)
d0081704:	4604      	mov	r4, r0
d0081706:	4608      	mov	r0, r1
d0081708:	4611      	mov	r1, r2
d008170a:	2200      	movs	r2, #0
d008170c:	602a      	str	r2, [r5, #0]
d008170e:	461a      	mov	r2, r3
d0081710:	f7fe fcf2 	bl	d00800f8 <_lseek>
d0081714:	1c43      	adds	r3, r0, #1
d0081716:	d102      	bne.n	d008171e <_lseek_r+0x1e>
d0081718:	682b      	ldr	r3, [r5, #0]
d008171a:	b103      	cbz	r3, d008171e <_lseek_r+0x1e>
d008171c:	6023      	str	r3, [r4, #0]
d008171e:	bd38      	pop	{r3, r4, r5, pc}
d0081720:	d0087a70 	.word	0xd0087a70

d0081724 <_read_r>:
d0081724:	b538      	push	{r3, r4, r5, lr}
d0081726:	4d07      	ldr	r5, [pc, #28]	; (d0081744 <_read_r+0x20>)
d0081728:	4604      	mov	r4, r0
d008172a:	4608      	mov	r0, r1
d008172c:	4611      	mov	r1, r2
d008172e:	2200      	movs	r2, #0
d0081730:	602a      	str	r2, [r5, #0]
d0081732:	461a      	mov	r2, r3
d0081734:	f7fe fccc 	bl	d00800d0 <_read>
d0081738:	1c43      	adds	r3, r0, #1
d008173a:	d102      	bne.n	d0081742 <_read_r+0x1e>
d008173c:	682b      	ldr	r3, [r5, #0]
d008173e:	b103      	cbz	r3, d0081742 <_read_r+0x1e>
d0081740:	6023      	str	r3, [r4, #0]
d0081742:	bd38      	pop	{r3, r4, r5, pc}
d0081744:	d0087a70 	.word	0xd0087a70
	...

d0081760 <clut>:
d0081760:	00000000 ffafafaf ffffffff ff3b67a2     .............g;.
d0081770:	ffaa907c ff959595 ff7b7b7b ffffa997     |.......{{{.....
d0081780:	ff37a91d ff7ca9ff ffbf8112 ffebbf66     ..7...|.....f...
d0081790:	ff78c178 ff3d9318 ffb33418 ffd9311c     x.x...=..4...1..
d00817a0:	ff000000 ff00000e ff00001d ff00002b     ............+...
d00817b0:	ff000139 ff000147 ff000156 ff000164     9...G...V...d...
d00817c0:	ff0001d2 ff0001ff ffcecece ff00ff00     ................
d00817d0:	ffb2ff00 ffffe700 ffff9600 ffff1100     ................
d00817e0:	ff491200 ff491355 ff4914aa ff4916ff     ..I.U.I...I...I.
d00817f0:	ff5b1700 ff5b1855 ff5b19aa ff5b1aff     ..[.U.[...[...[.
d0081800:	ff6d1b00 ff6d1c55 ff00e300 ff85ff54     ..m.U.m.....T...
d0081810:	ffc4ff00 ffffd900 ffffa41f ffe05400     .............T..
d0081820:	ffff0000 ff922655 ff9227aa ff9228ff     ....U&...'...(..
d0081830:	ffa42900 ffa42a55 ffa42baa ffa42cff     .)..U*...+...,..
d0081840:	ffb62d00 ffb62f55 ffb630aa ffb631ff     .-..U/...0...1..
d0081850:	ffc93200 ffc93355 ffc934aa ffc935ff     .2..U3...4...5..
d0081860:	ffdb3700 ffdb3855 ffdb39aa ffdb3aff     .7..U8...9...:..
d0081870:	ffed3b00 ffed3c55 ffed3daa ffed3fff     .;..U<...=...?..
d0081880:	ffff4000 ffff4155 ffff42aa ffff43ff     .@..UA...B...C..
d0081890:	ff004400 ff004555 ff0046aa ff0048ff     .D..UE...F...H..
d00818a0:	ffffff00 ff12ff55 ff12ee55 ff12b6ff     ....U...U.......
d00818b0:	ff001fff ff9d0ec7 fff10000 ffff7700     .............w..
d00818c0:	ff375200 ff375355 ff3754aa ff3755ff     .R7.US7..T7..U7.
d00818d0:	ff495600 ff495855 ff4959aa ff495aff     .VI.UXI..YI..ZI.
d00818e0:	ff5b5b00 ff5b5c55 ff5b5daa ff5b5eff     .[[.U\[..][..^[.
d00818f0:	ff6d6000 ff6d6155 ff6d62aa ff6d63ff     .`m.Uam..bm..cm.
d0081900:	ff6d6400 ff806555 ff8066aa ff8067ff     .dm.Ue...f...g..
d0081910:	ff926900 ff926a55 ff926baa ff926cff     .i..Uj...k...l..
d0081920:	ffa46d00 ffa46e55 ffa46faa ffa471ff     .m..Un...o...q..
d0081930:	ffb67200 ffb67355 ffb674aa ffb675ff     .r..Us...t...u..
d0081940:	ffc97600 ffc97755 ffc979aa ffc97aff     .v..Uw...y...z..
d0081950:	ffdb7b00 ffdb7c55 ffdb7daa ffdb7eff     .{..U|...}...~..
d0081960:	ffed7f00 ffed8055 ffed82aa ffed83ff     ....U...........
d0081970:	ffff8400 ffff8555 ffff86aa ffff87ff     ....U...........
d0081980:	ff008800 ff008a55 ff008baa ff008cff     ....U...........
d0081990:	ff128d00 ff128e55 ff128faa ff1290ff     ....U...........
d00819a0:	ff249200 ff249355 ff2494aa ff2495ff     ..$.U.$...$...$.
d00819b0:	ff379600 ff379755 ff3798aa ff3799ff     ..7.U.7...7...7.
d00819c0:	ff499b00 ff499c55 ff499daa ff499eff     ..I.U.I...I...I.
d00819d0:	ff5b9f00 ff5ba055 ff5ba1aa ff5ba3ff     ..[.U.[...[...[.
d00819e0:	ffa4b5d5 ffa0b0f8 ff94a3e6 ff7c89c1     ..............|.
d00819f0:	ff6281c0 ff1c62a1 ff4254ea ff62a1bd     ..b..b...TB...b.
d0081a00:	ff7093c0 ff4977a1 ff003faa ff1554ff     ..p..wI..?...T..
d0081a10:	ff1c50b9 ff00b3ff ff0088aa ff00b5ff     .P..............
d0081a20:	ff0e62ff ff5eb7e3 ffbdc0b9 ff85b9ff     .b....^.........
d0081a30:	ff006caf ff1f81b9 ff3f5baa ffc9beff     .l.......[?.....
d0081a40:	ff5bafcb ffdbc055 ffdbc1aa ffbdc0c0     ..[.U...........
d0081a50:	ffedc400 ffedc555 ffedc6aa ffedc7ff     ....U...........
d0081a60:	ffffc800 ffffc955 ffffcaaa ffffccff     ....U...........
d0081a70:	ff00cd00 ff00ce55 ff00cfaa ff00d0ff     ....U...........
d0081a80:	ff12d100 ff12d255 ff12d3aa ff12d5ff     ....U...........
d0081a90:	ff24d600 ff24d755 ff24d8aa ff24d9ff     ..$.U.$...$...$.
d0081aa0:	ff37da00 ff37db55 ff37ddaa ff37deff     ..7.U.7...7...7.
d0081ab0:	ff49df00 ff49e055 ff49e1aa ff49e2ff     ..I.U.I...I...I.
d0081ac0:	ff5be300 ff5be555 ff5be6aa ff5be7ff     ..[.U.[...[...[.
d0081ad0:	ff6de800 ff6de955 ff6deaaa ff6debff     ..m.U.m...m...m.
d0081ae0:	ff0458ec ff0422ac ff0077ff ff0054ee     .X..."...w...T..
d0081af0:	ff0033dd ff990000 ffff0000 ffff6600     .3...........f..
d0081b00:	ffffdd00 ffa4f755 ffa4f8aa ffa4f9ff     ....U...........
d0081b10:	ffb6fa00 ffb6fb55 ffb6fcaa ffb6feff     ....U...........
d0081b20:	ffff00ff ff000000 ff131313 ff272727     ............'''.
d0081b30:	ff3a3a3a ff4e4e4e ff626262 ff757575     :::.NNN.bbb.uuu.
d0081b40:	ff898989 ff9c9c9c ffb0b0b0 ffc4c4c4     ................
d0081b50:	ffd7d7d7 ffebebeb ffffffff ffffffff     ................

d0081b60 <projx_spacestation>:
	...
d0081b9c:	f9f8f500 f5f5f5f9 f8f8f5f5 f7f7f7f7     ................
d0081bac:	f5f6f6f7 0000f5f5 00000000 00000000     ................
	...
d0081c40:	f5f5f600 f7f4f5f9 f3f4f7f7 f4f4f5f5     ................
d0081c50:	f6f4f5f4 f5f5f5f6 00000000 00000000     ................
	...
d0081ce4:	f3f6f5f4 f4f5f9f4 f3f6f6f7 f4f4f5f3     ................
d0081cf4:	f5f4f4f4 f5f6f6f5 f5f5f5f5 000000f4     ................
	...
d0081d88:	f5f8f500 f5faf4f4 f6f6f6f4 f5f5f3f3     ................
d0081d98:	f6f5f4f4 f6f6f6f7 f4f4f4f6 00f4f5f4     ................
	...
d0081e2c:	f8f8f200 faf4f4f5 f6f6f4f5 f7f4f4f6     ................
d0081e3c:	f7f7f8f7 f5f5f6f7 f4f6f5f6 f4f4f4f4     ................
d0081e4c:	000000f4 00000000 00000000 00000000     ................
	...
d0081ed0:	f8f4f200 f5f4f6f5 f9f5f5fa f5f5f8f9     ................
d0081ee0:	f6f7f8f8 f5f4f4f5 f5f5f5f5 f4f4f4f6     ................
d0081ef0:	00fbf5f4 00000000 00000000 00000000     ................
	...
d0081f74:	f3f40000 f4f4f4f3 f4f7fafa f3f3f4f4     ................
d0081f84:	f5f7f8f5 f4f4f4f4 f5f5f5f4 f4f6f5f6     ................
d0081f94:	f4f5f4f4 000000f4 00000000 00000000     ................
	...
d0082018:	f5f40000 f7f6f5f5 f7fafaf8 f5f6f6f6     ................
d0082028:	f8f7f5f5 f4f4f5f4 f5f4f5f4 f5f6f5f5     ................
d0082038:	f5f5f5f6 0000f4f5 00000000 00000000     ................
	...
d00820bc:	f3000000 f6f6f3f3 f7f7f8f5 f6f6f6f5     ................
d00820cc:	f6f3f3f3 f2f2f8f5 f3f2f2f2 f3f6f6f3     ................
d00820dc:	f3f4f3f4 00f3f3f3 00000000 00000000     ................
	...
d0082164:	f4f4f4f5 f7f7f5f5 f4f4f5f5 f3f3f3f4     ................
d0082174:	f3f5f5f3 f5f5f3f3 f2f3f4f5 f3f4f1f2     ................
d0082184:	f3f3f3f4 00000000 00000000 00000000     ................
	...
d0082208:	f6f5f5f4 f7f5f5f5 f4f5f5f7 f3f3f4f4     ................
d0082218:	f5f4f3f3 f4f4f5f5 f2f2f2f2 f3f4f3f3     ................
d0082228:	00f3f3f3 00000000 00000000 00000000     ................
	...
d00822ac:	f5f5f300 f7f7f6f6 f4f5f7f7 f5f6f4f4     ................
d00822bc:	f5f5f5f5 f2f2f5f5 f4f4f4f2 f3f4f4f5     ................
d00822cc:	f3f3f3f3 0000f5f3 00000000 00000000     ................
	...
d0082350:	f4f30000 f7f6f6f5 f5f5f7f7 f6f4f4f4     ................
d0082360:	f5f5f5f5 f5f5f5f5 f4f5f5f5 f3f3f4f4     ................
d0082370:	f4f3f3f3 0000f5f5 00000000 00000000     ................
	...
d00823f4:	f3000000 f5f5f4f5 f5f7f6f6 f4f4f4f5     ................
d0082404:	f5f5f5f5 f5f5f5f5 f3f4f4f5 f3f3f3f3     ................
d0082414:	f5f4f3f2 0000f2f5 00000000 00000000     ................
	...
d008249c:	f4f5f300 f5f5f4f4 f5f5f5f5 f5f5f5f5     ................
d00824ac:	f4f5f5f5 f3f3f3f4 f4f2f3f3 f5f5f5f4     ................
d00824bc:	0000f2f2 00000000 00000000 00000000     ................
	...
d0082544:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f4f4f4f5     ................
d0082554:	f4f2f3f3 f5f4f2f3 f2f2f5f5 00000000     ................
	...
d00825e8:	f3000000 f5f5f5f5 f6f5f5f5 f2f2f2f8     ................
d00825f8:	f5f4f2f2 f5f5f5f5 00f1f3f3 00000000     ................
	...
d0082698:	f5f2f2f4 f4f4f2f5 f4f6f4f9 f4f2f2f1     ................
d00826a8:	0000f3f3 00000000 00000000 00000000     ................
	...
d008273c:	f2f4f500 f2f1f5f7 f2f1f4f3 f4f3f2f2     ................
d008274c:	f3f3f4f4 00000000 00000000 00000000     ................
	...
d00827e0:	f20000f3 f5f5f5f2 f3f4f4f5 f4f4f3f3     ................
d00827f0:	f3f4f3f4 0000f3f3 00000000 00000000     ................
	...
d0082880:	f3000000 f4f5f5f4 f4f4f4f4 f4f5f4f4     ................
d0082890:	f4f4f4f4 f4f5f4f4 f3f3f3f4 00000000     ................
	...
d0082924:	f3000000 f5f5f5f5 f5f5f5f5 f5f5f5f5     ................
d0082934:	f5f5f5f5 f5f5f5f5 f3f4f4f5 000000f3     ................
	...
d00829cc:	f6f5f5f4 f9f8f7f6 f9f9f9f9 f7f7f7f9     ................
d00829dc:	f5f5f6f6 f4f4f5f5 0000f3f3 00000000     ................
	...
d0082a70:	f5f5f4f3 f8f7f6f6 f9f9f9f9 f6f7f7f9     ................
d0082a80:	f5f5f5f6 f4f5f5f5 00f3f3f4 00000000     ................
	...
d0082b14:	f5f40000 f6f6f5f5 f8f8f7f7 f6f7f7f7     ................
d0082b24:	f5f5f6f6 f4f5f5f5 0000f3f4 00000000     ................
	...
d0082bb8:	f3000000 f5f5f5f4 f6f6f6f6 f6f6f6f6     ................
d0082bc8:	f5f5f5f6 f4f5f5f5 00f5f2f4 00000000     ................
	...
d0082c60:	f4f30000 f5f5f5f4 f5f5f5f5 f5f5f5f5     ................
d0082c70:	f2f5f5f5 f3f2f2f5 00000000 00000000     ................
	...
d0082d08:	f3f30000 f2f2f2f3 f3f5f3f3 f2f1f1f5     ................
d0082d18:	f3f3f3f2 0000f3f3 00000000 00000000     ................
	...
d0082dac:	f3f30000 f2f2f3f2 f4f3f2f2 f2f2f4f4     ................
d0082dbc:	f3f4f3f3 00f3f3f3 00000000 00000000     ................
	...
d0082e50:	f5000000 f2f4f4f5 f4f3f2f2 f3f4f5f6     ................
d0082e60:	f3f3f3f2 f3f3f3f4 000000f3 00000000     ................
	...
d0082e7c:	f2f2f200 f2f2f2f2 f2f2f2f2 f2f2f2f2     ................
d0082e8c:	f2f2f2f2 f2f2f2f2 000000f2 00000000     ................
	...
d0082ef4:	f3000000 f3f5f5f5 f3f2f2f2 f4f5f6f5     ................
d0082f04:	f3f3f2f3 f3f7f5f4 f1f3f3f3 f2f2f2f1     ................
d0082f14:	f2f2f2f2 f2f2f2f2 f2f2f2f2 f2f2f2f2     ................
d0082f24:	f3f3f2f3 f3f3f3f3 f3f3f3f3 f3f3f3f3     ................
d0082f34:	f3f3f5f2 f2f2f3f3 f2f2f2f2 00000000     ................
	...
d0082f9c:	f5f5f5f3 f2f2f2f3 f5f6f4f4 f3f2f4f4     ................
d0082fac:	f5f5f5f3 f3f3f3f5 f3f1f1f2 f3f3f3f3     ................
d0082fbc:	f3f3f3f3 f3f3f3f3 f3f3f3f3 f3f3f3f3     ................
d0082fcc:	f3f3f3f3 f3f3f3f3 f2f3f3f3 f3f3f5f3     ................
d0082fdc:	f3f3f3f3 f3f3f3f3 f2f2f2f3 000000f2     ................
	...
d0083040:	f5f5f400 f2f2f3f5 f6f4f3f2 f2f2f4f6     ................
d0083050:	f5f5f4f3 f3f3f7f5 f2f2f3f3 f3f3f2f1     ................
d0083060:	f3f3f3f3 f3f3f3f3 f3f3f3f3 f3f3f3f3     ................
d0083070:	f3f3f3f3 f3f3f3f3 f2f3f3f3 f3f3f3f5     ................
d0083080:	f3f3f3f3 f3f3f3f3 f3f3f3f3 f2f2f3f3     ................
d0083090:	000000f2 00000000 00000000 00000000     ................
	...
d00830e4:	f5f50000 f2f3f4f5 f2f2f1f2 f4f3f5f4     ................
d00830f4:	f5f5f3f2 f7f5f5f5 f3f3f3f3 f2f1f2f2     ................
d0083104:	f3f3f3f3 f3f3f3f3 f3f3f3f3 f2f3f3f3     ................
d0083114:	f4f2f2f2 f5f4f4f4 f5f5f5f5 f5f5f5f5     ................
d0083124:	f5f5f6f5 f3f3f4f4 f3f3f3f3 f3f3f3f3     ................
d0083134:	f1f1f2f3 0000f1f1 00000000 00000000     ................
	...
d0083188:	f5f30000 f2f3f5f5 f2f2f2f2 f5f6f5f4     ................
d0083198:	f5f3f2f2 f5f5f5f5 f3f3f5f9 f2f2f2f3     ................
d00831a8:	f4f4f1f1 f4f4f4f4 f4f4f4f4 f3f4f4f4     ................
d00831b8:	f1f5f4f2 f5f5f4f2 f5f5f5f5 f5f5f5f5     ................
d00831c8:	f5f5f5f5 f5f5f5f5 f3f3f4f4 f3f3f3f3     ................
d00831d8:	f3f3f3f3 f1f1f1f2 00f1f1f1 00000000     ................
	...
d008322c:	f3000000 f3f5f5f5 f2f2f2f3 f5f3f2f1     ................
d008323c:	f3f4f3f5 f5f5f5f4 f3f9f5f5 f2f3f3f3     ................
d008324c:	f1f1f2f2 f4f4f4f4 f4f4f4f4 f4f4f4f4     ................
d008325c:	f5f6f6f2 f4f5f2f2 f5f5f5f5 f5f5f5f5     ................
d008326c:	f5f5f5f5 f5f5f5f5 f4f4f5f5 f3f3f3f3     ................
d008327c:	f3f3f3f3 f1f2f3f3 f1f1f1f1 00f1f1f1     ................
	...
d00832d0:	f1000000 f5f5f5f4 f2f2f2f3 f4f4f2f2     ................
d00832e0:	f4f5f6f6 f5f3f2f1 f9f5f5f5 f3f3f3f6     ................
d00832f0:	f2f2f2f3 f4f4f2f1 f4f4f4f4 f2f4f4f4     ................
d0083300:	f2f4f3f2 f3f3f5f4 f5f5f5f5 f5f5f5f5     ................
d0083310:	f5f5f5f5 f5f5f5f5 f6f5f5f5 f3f3f4f5     ................
d0083320:	f3f3f3f4 f3f3f3f3 f1f1f1f2 f1f1f1f1     ................
d0083330:	0000f2f1 00000000 00000000 00000000     ................
	...
d0083370:	f3000000 f3f3f3f3 f5f5f5f2 f2f3f3f4     ................
d0083380:	f2f1f2f2 f5f6f5f4 f3f5f5f4 f5f5f5f3     ................
d0083390:	f3f5f9f5 f2f3f3f3 f3f1f2f2 f4f4f4f4     ................
d00833a0:	f2f4f4f4 f4f4f5f4 f3f2f3f5 f4f5f3f3     ................
d00833b0:	f3f3f3f3 f4f4f3f4 f5f5f4f4 f6f5f5f5     ................
d00833c0:	f4f5f6f5 f4f3f3f4 f3f4f3f3 f1f2f4f3     ................
d00833d0:	f1f1f1f1 f1f1f1f1 000000f1 00000000     ................
	...
d0083414:	f3f3f300 f4f4f4f4 f6f5f2f2 f2f3f3f5     ................
d0083424:	f5f2f2f2 f5f5f5f3 f6f6f5f4 f5f3f1f6     ................
d0083434:	f9f6f5f5 f3f3f3f3 f2f2f2f2 f4f4f4f1     ................
d0083444:	f2f2f5f4 f5f3f5f2 f3f2f3f6 f4f3f3f3     ................
d0083454:	f6f6f6f6 f6f7f7f6 f5f7f6f7 f5f5f4f4     ................
d0083464:	f6f5f6f5 f4f3f4f4 f3f4f3f3 f2f3f4f3     ................
d0083474:	f1f1f1f1 f1f1f1f1 f1f1f1f1 00000000     ................
	...
d00834b4:	f3000000 f4f4f4f3 f4f4f4f4 f5f3f2f2     ................
d00834c4:	f3f3f5f6 f5f2f2f3 f5f5f5f5 f7f6f5f5     ................
d00834d4:	f1f1f6f6 f5f5f5f4 f3f3f5f9 f2f2f3f3     ................
d00834e4:	f4f1f1f2 f3f3f4f4 f4f5f2f2 f3f2f2f3     ................
d00834f4:	f2f2f1f2 f1f2f1f2 f1f1f1f1 f4f2f1f1     ................
d0083504:	f5f5f7f5 f6f5f5f4 f4f5f6f5 f3f4f3f3     ................
d0083514:	f3f3f4f3 f1f1f1f3 f1f1f1f1 f1f1f1f1     ................
d0083524:	0000f2f1 00000000 00000000 00000000     ................
	...
d0083558:	f4f4f4f3 f4f2f4f4 f3f4f4f4 f4f2f2f3     ................
d0083568:	f3f5f6f5 f5f2f2f3 f5f5f5f5 f6f6f5f5     ................
d0083578:	f4f6f6f6 f5f4f1f1 f3f9f5f5 f3f3f3f3     ................
d0083588:	f1f2f2f2 f5f3f2f5 f5f3f3f5 f5f2f2f2     ................
d0083598:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f2f2f5f5     ................
d00835a8:	f2f1f1f1 f5f5f7f5 f5f6f6f4 f3f4f3f3     ................
d00835b8:	f3f3f4f3 f2f2f2f4 f1f1f1f2 f1f1f1f1     ................
d00835c8:	f1f1f1f1 00000000 00000000 00000000     ................
	...
d00835f8:	f4f30000 f4f4f4f4 f4f4f4f4 f3f3f4f3     ................
d0083608:	f3f2f3f3 f4f5f6f5 f5f3f2f3 f5f5f5f5     ................
d0083618:	f7f7f6f5 f1f6f6f6 f1f1f1f1 f5f5f5f1     ................
d0083628:	f3f3f3f6 f2f2f2f3 f5f3f2f1 f3f5f5f7     ................
d0083638:	f5f5f2f2 00000000 00000000 00000000     ................
d0083648:	f5000000 f5f5f5f5 f7f2f2f2 f6f4f6f7     ................
d0083658:	f3f4f3f6 f3f3f4f3 f1f2f3f4 f2f2f1f2     ................
d0083668:	f1f1f1f1 f1f1f1f1 000000f1 00000000     ................
	...
d008369c:	f4f4f400 f4f4f4f4 f3f4f3f4 f3f3f3f3     ................
d00836ac:	f2f2f3f3 f5f6f5f3 f4f3f3f3 f5f5f5f5     ................
d00836bc:	f7f8f7f5 f1f5f7f8 f1f1f1f1 f5f4f1f1     ................
d00836cc:	f3f5f5f5 f2f3f3f3 f3f2f2f2 f5f7f5f5     ................
d00836dc:	f5f5f5f3 00000000 00000000 00000000     ................
	...
d00836f4:	f5f5f500 f6f5f4f1 f3f4f5f4 f3f3f4f3     ................
d0083704:	f2f3f3f4 f1f2f1f2 f1f2f2f1 f1f1f1f1     ................
d0083714:	00f2f1f1 00000000 00000000 00000000     ................
	...
d008373c:	f3000000 f4f4f4f3 f2f3f4f3 f3f3f3f3     ................
d008374c:	f3f3f3f3 f2f3f3f3 f6f5f4f2 f3f3f3f5     ................
d008375c:	f5f5f5f5 f8f9f7f5 f1f7f8f8 f1f1f1f1     ................
d008376c:	f1f1f1f1 f5f5f5f4 f3f3f3f3 f1f2f2f2     ................
d008377c:	f5f5f3f2 f4f2f2f3 00000000 00000000     ................
	...
d008379c:	f1f5f500 f3f5f7f5 f3f3f4f3 f2f3f3f4     ................
d00837ac:	f2f2f2f2 f1f1f1f2 f1f1f1f1 f2f2f1f2     ................
	...
d00837e0:	f4f30000 f2f4f4f4 f2f3f2f3 f3f2f3f3     ................
d00837f0:	f3f3f3f3 f3f3f3f3 f5f5f2f2 f3f3f4f6     ................
d0083800:	f5f5f5f4 f9f9f2f3 f1f1f8f8 f1f1f1f1     ................
d0083810:	f2f2f1f1 f5f5f1f1 f3f3f5f5 f2f2f3f3     ................
d0083820:	f3f2f2f1 f3f2f2f3 00000000 00000000     ................
d0083830:	f2f20000 000000f2 00000000 00000000     ................
d0083840:	00000000 f4f8f2f1 f3f4f3f4 f2f4f3f4     ................
d0083850:	f2f2f2f2 f1f2f2f2 f1f1f1f1 f1f2f1f2     ................
d0083860:	000000f2 00000000 00000000 00000000     ................
	...
d0083884:	f4f4f4f3 f2f3f4f4 f2f3f2f3 f3f2f3f3     ................
d0083894:	f3f3f3f3 f3f3f3f3 f5f2f2f3 f3f3f5f6     ................
d00838a4:	f5f5f5f3 f2f8f6f5 f1f1f8f8 f1f1f1f1     ................
d00838b4:	f4f2f1f1 f4f1f1f1 f3f5f5f5 f2f5f3f3     ................
d00838c4:	f5f1f2f2 f5f2f2f2 00000000 00000000     ................
d00838d4:	f3000000 0000f3f3 00000000 00000000     ................
d00838e4:	00000000 f3f1f500 f3f4f3f4 f3f4f3f4     ................
d00838f4:	f2f2f2f2 f1f2f2f2 f1f1f1f1 f2f2f1f1     ................
d0083904:	0000f2f2 00000000 00000000 00000000     ................
	...
d0083924:	f4f30000 f4f4f4f4 f2f2f2f3 f2f3f2f3     ................
d0083934:	f3f2f3f3 f3f3f3f3 f3f3f3f3 f2f2f3f3     ................
d0083944:	f3f5f6f5 f5f5f4f3 f7f6f6f5 f1f1f1f8     ................
d0083954:	f1f1f1f1 f2f4f1f1 f2f1f1f1 f5f5f4f1     ................
d0083964:	f4f5f5f5 f1f2f2f3 00f5f5f2 00000000     ................
d0083974:	00000000 f3000000 f3f5f5f5 f1f20000     ................
d0083984:	f1f1f1f1 f1f1f1f1 f3f4f3f2 f3f4f3f4     ................
d0083994:	f3f4f3f4 f2f2f2f2 f2f2f2f2 f1f1f1f1     ................
d00839a4:	f2f2f1f1 00f2f2f1 00000000 00000000     ................
	...
d00839c8:	f4f4f400 f3f4f4f4 f2f2f2f2 f2f3f2f3     ................
d00839d8:	f3f2f2f3 f3f3f2f3 f5f4f4f3 f5f4f5f5     ................
d00839e8:	f5f5f7f4 f8f4f3f3 f6f9f6f5 f1f7f7f9     ................
d00839f8:	f1f1f1f1 f1f1f1f1 f1f1f1f1 f5f3f1f1     ................
d0083a08:	f4f5f5f5 f5f5f2f2 f3f5f5f4 f5f6f5f3     ................
d0083a18:	f5f4f4f4 f4f4f4f3 f5f7f7f5 f2f3f3f5     ................
d0083a28:	f4f4f4f2 f4f6f6f4 f3f4f2f3 f3f4f3f4     ................
d0083a38:	f3f4f3f4 f2f2f2f2 f2f2f2f2 f1f1f1f1     ................
d0083a48:	f2f2f1f1 f2f2f2f2 00000000 00000000     ................
	...
d0083a6c:	f2f4f4f3 f2f2f4f4 f2f2f2f2 f2f2f2f2     ................
d0083a7c:	f2f2f2f2 f2f2f2f2 f5f5f5f4 f5f5f5f5     ................
d0083a8c:	f5f7f5f5 f5f3f3f4 f7f6f5f5 f7f6f7f5     ................
d0083a9c:	f1f1f1f1 f1f1f4f4 f1f1f1f1 f4f1f1f1     ................
d0083aac:	f5f5f5f4 f3f3f2f2 f2f3f3f3 f3f2f2f2     ................
d0083abc:	f8f5f3f3 f1f4f5f5 f7f7f5f3 f3f3f4f4     ................
d0083acc:	f3f2f2f2 f4f4f3f3 f4f3f2f3 f3f4f3f4     ................
d0083adc:	f3f4f3f4 f2f2f2f2 f2f2f2f2 f1f1f1f1     ................
d0083aec:	f2f1f1f1 f2f2f2f2 00000000 00000000     ................
	...
d0083b0c:	f3000000 f4f4f4f4 f2f2f2f4 f4f4f3f2     ................
d0083b1c:	f5f5f5f4 f2f4f5f5 f3f3f3f2 f2f4f2f2     ................
d0083b2c:	f2f5f5f2 f7f5f2f1 f3f3f3f5 f6f5f5f5     ................
d0083b3c:	f7f6f6f6 f4f1f1f6 f1f1f1f4 f1f1f1f1     ................
d0083b4c:	f5f5f7f1 f5f5f3f4 f4f2f2f4 f5f4f6f5     ................
d0083b5c:	f7f9f8f7 f4f4f5f6 f5f1f3f4 f5f5f3f1     ................
d0083b6c:	f5f5f7f2 f8f5f5f5 f4f5f5f6 f4f3f3f3     ................
d0083b7c:	f3f4f3f4 f2f4f3f4 f2f2f2f3 f2f2f2f2     ................
d0083b8c:	f1f1f1f1 f2f1f1f1 f2f2f2f2 000000f2     ................
	...
d0083bb0:	f4f30000 f4f4f4f4 f2f2f2f4 f2f2f2f2     ................
d0083bc0:	f2f3f3f3 f2f1f1f2 f5f5f3f2 f5f2f3f5     ................
d0083bd0:	f5f5f5f5 f7f5f8f5 f3f3f5f6 f5f5f5f3     ................
d0083be0:	f6f5f6f6 f4f4f6f6 f1f1f1f1 f1f1f1f1     ................
d0083bf0:	f5f5f7f1 f5f3f4f4 f3f1f4f5 f2f2f2f2     ................
d0083c00:	f3f3f3f2 f3f3f6f3 f5f2f3f3 f3f1f2f7     ................
d0083c10:	f2f2f5f5 f4f4f4f2 f3f4f4f4 f4f3f2f3     ................
d0083c20:	f4f4f3f4 f2f4f3f3 f2f3f4f3 f2f2f2f3     ................
d0083c30:	f1f1f1f1 f2f1f1f1 f2f2f2f2 000000f3     ................
	...
d0083c54:	f4f40000 f4f4f4f4 f2f2f2f2 f4f2f2f2     ................
d0083c64:	f4f5f5f4 f5f5f4f3 f7f5f3f2 f3f5f5f7     ................
d0083c74:	f2f3f3f2 f4f1f2f2 f3f5f6f7 f5f5f4f3     ................
d0083c84:	f5f6f6f5 f3f6f6f6 f4f1f1f1 f1f1f1f4     ................
d0083c94:	f5f5f5f1 f3f4f4f5 f3f4f5f4 f5f5f4f2     ................
d0083ca4:	f2f2f4f5 f5f1f1f3 f1f4f4f4 f1f3f5f4     ................
d0083cb4:	f3f3f3f2 f2f5f1f2 f3f3f3f3 f4f3f4f4     ................
d0083cc4:	f4f4f3f4 f2f4f4f3 f2f5f1f3 f2f2f2f3     ................
d0083cd4:	f1f1f1f1 f2f1f1f1 f2f2f2f2 0000f4f3     ................
	...
d0083cf8:	f4f4f300 f2f4f4f4 f2f2f2f2 f7f4f2f2     ................
d0083d08:	f9f7f5f7 f5f6f7f6 f5f3f2f6 f5f7f7f7     ................
d0083d18:	f5f5f2f3 f8f9f8f7 f4f5f7f5 f5f5f3f3     ................
d0083d28:	f5f6f5f5 f6f6f6f5 f4f4f5f6 f1f1f1f4     ................
d0083d38:	f5f5f1f1 f4f4f5f5 f3f5f3f2 f2f2f2f3     ................
d0083d48:	f2f2f2f2 f3f3f2f2 f3f3f3f2 f5f5f1f2     ................
d0083d58:	f2f2f5f5 f3f5f5f2 f4f3f2f3 f4f4f4f4     ................
d0083d68:	f4f4f4f4 f2f3f4f3 f1f3f2f3 f3f2f4f3     ................
d0083d78:	f1f2f2f2 f2f1f1f1 f2f2f2f2 0000f4f2     ................
	...
d0083d9c:	f5f4f4f3 f2f4f4f4 f2f2f2f2 f2f2f2f2     ................
d0083dac:	f5f4f5f3 f3f3f4f5 f3f2f1f2 f7f7f5f5     ................
d0083dbc:	f2f2f3f5 f3f3f3f2 f5f7f5f1 f5f3f3f3     ................
d0083dcc:	f5f5f5f5 f6f5f5f5 f1f5f6f5 f1f1f1f1     ................
d0083ddc:	f5f5f1f1 f4f4f5f5 f5f3f4f4 f5f2f2f4     ................
d0083dec:	f5f5f2f5 f2f1f5f2 f2f2f2f1 f4f4f3f4     ................
d0083dfc:	f5f3f2f5 f2f2f5f5 f4f4f3f2 f4f4f4f4     ................
d0083e0c:	f4f4f4f4 f2f3f3f3 f2f3f2f3 f2f2f2f3     ................
d0083e1c:	f2f3f2f5 f2f1f2f1 f2f2f2f2 0000f5f2     ................
	...
d0083e40:	f4f4f4f4 f2f2f2f2 f2f2f2f1 f2f2f2f2     ................
d0083e50:	f2f1f1f2 f7f5f3f2 f3f4f5f6 f5f5f3f2     ................
d0083e60:	f5f2f3f5 f200f4f4 f7f5f5f1 f3f3f3f5     ................
d0083e70:	f5f5f4f3 f5f5f5f5 f5f5f6f5 f1f1f1f5     ................
d0083e80:	f5f5f7f1 f4f5f5f5 f2f3f4f4 f2f2f4f4     ................
d0083e90:	f4f1f2f2 f1f5f2f5 f2f2f2f2 f2f2f2f2     ................
d0083ea0:	f2f5f5f5 f2f2f2f2 f4f4f4f3 f4f4f4f4     ................
d0083eb0:	f4f4f4f4 f2f3f3f3 f2f3f2f3 f2f3f2f3     ................
d0083ec0:	f2f5f1f3 f2f2f3f2 f2f2f2f3 0000f5f2     ................
	...
d0083ee0:	f3000000 f4f4f4f4 f2f1f4f4 f2f2f2f1     ................
d0083ef0:	f3f2f2f2 f2f2f4f5 f2f2f2f2 f2f2f2f2     ................
d0083f00:	f3f2f2f2 f2f2f3f3 00000000 f7f40000     ................
d0083f10:	f3f3f5f6 f4f4f4f3 f5f5f4f4 f5f5f5f5     ................
d0083f20:	f1f1f5f5 f5f5f7f1 f4f5f5f5 f3f4f4f4     ................
d0083f30:	f3f5f3f2 f4f3f3f4 f2f2f5f2 f2f2f2f2     ................
d0083f40:	f2f5f5f5 f2f5f5f5 f3f2f2f2 f4f4f4f4     ................
d0083f50:	f4f4f4f4 f3f4f4f4 f3f3f3f3 f2f3f3f2     ................
d0083f60:	f2f2f1f3 f1f3f2f3 f2f3f4f3 f2f2f2f3     ................
d0083f70:	0000f5f2 00000000 00000000 00000000     ................
d0083f80:	00000000 f3f30000 f4f4f4f4 f1f1f4f4     ................
d0083f90:	f2f1f2f1 f5f3f2f2 f2f2f3f4 f5f5f5f5     ................
d0083fa0:	f5f5f5f5 f5f5f5f5 f5f2f2f2 000000f5     ................
d0083fb0:	f5000000 f3f4f5f7 f4f4f3f2 f5f5f5f4     ................
d0083fc0:	f5f5f5f5 f5f2f5f5 f5f5f5f5 f4f4f5f5     ................
d0083fd0:	f3f4f4f4 f4f2f2f2 f5f3f3f4 f2f5f2f1     ................
d0083fe0:	f5f2f2f2 f2f2f5f5 f2f2f2f2 f4f2f2f2     ................
d0083ff0:	f4f4f4f4 f4f4f4f4 f3f3f4f4 f3f3f3f3     ................
d0084000:	f2f3f3f2 f1f2f1f2 f2f3f1f2 f2f2f2f3     ................
d0084010:	f2f2f2f5 0000f5f3 00000000 00000000     ................
	...
d0084028:	f3f3f300 f4f4f4f4 f1f1f4f4 f2f1f2f1     ................
d0084038:	f5f4f2f1 f5f2f2f3 000000f5 00000000     ................
d0084048:	00000000 f5f5f500 00000000 00000000     ................
d0084058:	f3f5f7f5 f3f3f2f2 f4f4f4f4 f5f5f5f5     ................
d0084068:	f2f5f5f5 f5f5f5f5 f4f4f5f5 f3f4f4f4     ................
d0084078:	f2f3f2f2 f3f3f4f4 f2f2f2f5 f2f2f2f2     ................
d0084088:	f2f2f2f2 f2f2f2f2 f2f2f2f2 f4f4f5f5     ................
d0084098:	f4f4f4f4 f3f3f4f3 f3f3f3f4 f2f3f3f3     ................
d00840a8:	f2f1f2f2 f1f2f1f2 f2f3f2f3 f2f4f1f3     ................
d00840b8:	0000f4f5 00000000 00000000 00000000     ................
d00840c8:	00000000 f3f3f300 f4f4f4f4 f1f4f4f4     ................
d00840d8:	f2f1f1f1 f3f4f3f1 f5f5f2f2 00000000     ................
	...
d00840fc:	f3f2f200 f2f3f3f3 f4f4f3f2 f4f4f4f4     ................
d008410c:	f5f5f5f5 f5f5f5f5 f4f4f4f5 f3f4f4f3     ................
d008411c:	f3f2f2f3 f3f5f4f2 f2f2f2f5 f2f2f2f2     ................
d008412c:	f2f2f2f2 f2f2f2f2 f2f2f2f2 f5f4f5f2     ................
d008413c:	f4f3f4f4 f3f3f4f3 f4f3f3f4 f2f3f3f3     ................
d008414c:	f2f1f2f2 f2f2f1f2 f2f3f2f1 f4f2f2f3     ................
d008415c:	000000f4 00000000 00000000 00000000     ................
d008416c:	00000000 f3f3f300 f4f4f4f4 f4f4f4f4     ................
d008417c:	f2f1f1f1 f2f4f4f1 00f5f5f2 00000000     ................
	...
d00841a0:	f3f40000 f5f5f5f5 f3f3f2f3 f4f4f4f4     ................
d00841b0:	f4f4f4f4 f4f4f4f4 f4f4f4f4 f3f3f4f4     ................
d00841c0:	f2f2f2f3 f3f3f2f3 f2f2f3f5 f2f2f2f2     ................
d00841d0:	f2f2f2f2 f2f2f2f2 f2f2f2f2 f4f5f4f3     ................
d00841e0:	f4f5f4f3 f4f3f4f3 f4f3f3f4 f2f2f3f3     ................
d00841f0:	f2f1f2f2 f2f2f1f2 f2f3f3f1 f5f3f2f3     ................
d0084200:	000000f4 00000000 00000000 00000000     ................
d0084210:	00000000 f4f3f3f3 f4f4f4f4 f4f4f4f4     ................
d0084220:	f1f1f1f4 f2f3f4f1 0000f5f2 00000000     ................
	...
d0084244:	f3f20000 f5f7f7f5 f2f3f5f5 f3f2f2f2     ................
d0084254:	f4f4f4f3 f4f4f4f4 f4f4f4f4 f3f3f3f4     ................
d0084264:	f2f2f2f3 f5f2f3f3 f2f3f3f5 f2f2f2f2     ................
d0084274:	f2f2f2f2 f2f2f2f2 f4f3f3f2 f4f4f4f4     ................
d0084284:	f4f3f4f3 f4f3f4f5 f4f3f3f3 f2f2f2f2     ................
d0084294:	f2f2f2f2 f2f2f1f2 f2f3f3f2 f5f4f2f3     ................
	...
d00842b8:	f4f2f3f3 f4f4f5f3 f4f4f4f4 f1f1f4f4     ................
d00842c8:	f2f3f3f1 0000f5f5 00000000 00000000     ................
	...
d00842e8:	f2000000 f7f7f5f3 f3f5f7f7 f3f2f2f2     ................
d00842f8:	f4f4f3f3 f4f4f4f4 f3f3f4f4 f3f3f3f3     ................
d0084308:	f2f2f2f2 f2f2f4f3 f2f3f5f5 f2f2f2f2     ................
d0084318:	f2f2f2f2 f2f2f2f2 f4f4f4f2 f4f4f4f4     ................
d0084328:	f4f4f4f4 f4f4f5f2 f2f3f4f3 f2f2f2f2     ................
d0084338:	f2f2f2f2 f3f2f2f2 f2f3f3f2 f4f5f3f3     ................
	...
d008435c:	f2f2f3f3 f4f5f5f5 f4f4f4f4 f1f4f4f4     ................
d008436c:	f2f3f3f1 000000f5 00000000 00000000     ................
	...
d0084390:	f7f5f3f2 f5f7f7f7 f2f2f2f3 f3f3f3f2     ................
d00843a0:	f3f3f3f3 f3f3f3f3 f3f3f3f3 f3f2f2f2     ................
d00843b0:	f2f3f5f3 f2f9f5f2 f2f2f2f2 f2f2f2f2     ................
d00843c0:	f2f2f2f2 f4f4f4f4 f4f4f4f4 f3f4f3f4     ................
d00843d0:	f5f3f4f3 f4f3f4f4 f2f2f2f2 f2f2f2f2     ................
d00843e0:	f3f2f2f2 f3f3f3f3 00f5f5f3 00000000     ................
	...
d0084400:	f2f2f3f3 f5f5f5f5 f4f4f4f4 f3f3f4f4     ................
d0084410:	f1f2f1f2 000000f5 00000000 00000000     ................
	...
d0084434:	f3f3f3f2 f7f7f7f3 f2f2f3f5 f2f2f2f2     ................
d0084444:	f3f3f3f2 f3f3f3f3 f2f2f3f3 f3f2f2f2     ................
d0084454:	f3f3f6f4 f1f9f2f2 f3f2f2f2 f2f2f2f3     ................
d0084464:	f2f2f2f2 f4f4f4f3 f4f4f4f4 f3f4f4f4     ................
d0084474:	f4f3f4f4 f4f3f5f3 f2f2f4f3 f2f2f2f2     ................
d0084484:	f3f3f2f2 f3f3f3f3 0000f5f5 00000000     ................
	...
d00844a4:	f2f2f2f3 f5f5f5f5 f3f4f4f5 f4f3f3f3     ................
d00844b4:	f1f4f5f5 000000f5 00000000 00000000     ................
	...
d00844d8:	f2f4f4f4 f9f5f2f3 f2f2f3f9 f2f7f2f2     ................
d00844e8:	f2f2f2f6 f2f2f2f2 f2f2f2f2 f5f4f3f2     ................
d00844f8:	f5f5f6f6 f3f4f3f3 f4f3f3f2 f2f4f4f4     ................
d0084508:	f4f3f2f4 f4f4f4f4 f4f5f4f4 f3f4f4f4     ................
d0084518:	f4f3f4f4 f5f3f3f4 f4f3f4f3 f2f2f2f2     ................
d0084528:	f3f3f4f2 f5f3f3f3 000000f5 00000000     ................
	...
d0084548:	f3f2f2f3 f5f5f5f3 f3f5f5f5 f5f5f4f3     ................
d0084558:	f4f4f4f5 00f3f3f4 00000000 00000000     ................
	...
d0084578:	f1000000 f2f2f5f3 f5f3f2f5 f2f5f5f5     ................
d0084588:	f3f2f2f1 f2f2f2f2 f2f2f2f2 f4f4f3f3     ................
d0084598:	f5f5f5f5 f4f4f3f5 f4f4f5f2 f4f4f4f4     ................
d00845a8:	f4f4f4f4 f4f4f4f4 f4f4f4f4 f4f5f4f4     ................
d00845b8:	f4f4f4f4 f4f2f2f3 f2f4f3f4 f4f3f4f5     ................
d00845c8:	f4f2f4f3 f3f3f4f3 f5f5f3f3 00000000     ................
	...
d00845ec:	f3f2f2f3 f5f5f5f3 f6f5f5f5 f4f5f5f4     ................
d00845fc:	f4f4f4f4 f4f4f4f4 f3f4f4f4 000000f3     ................
	...
d008461c:	f1f10000 f1f2f6f6 f2f3f5f3 f5f5f5f5     ................
d008462c:	f2f1f1f5 f4f4f3f3 f4f4f4f4 f6f5f5f5     ................
d008463c:	f4f5f6f6 f4f4f4f4 f5f2f4f4 f4f4f4f4     ................
d008464c:	f4f4f4f4 f4f4f4f4 f5f4f4f4 f5f4f4f4     ................
d008465c:	f2f4f5f4 f2f2f2f2 f4f4f3f2 f4f5f2f3     ................
d008466c:	f4f3f4f3 f3f3f4f3 00f5f5f3 00000000     ................
	...
d0084690:	f3f2f2f3 f5f5f4f3 f6f5f6f5 f4f6f8f5     ................
d00846a0:	f4f4f4f4 f4f4f4f4 f4f4f4f4 f4f4f4f4     ................
d00846b0:	00f1f3f4 00000000 00000000 00000000     ................
d00846c0:	f4f20000 f2f2f5f5 f5f5f4f4 f5f5f5f5     ................
d00846d0:	f5f5f2f2 f2f2f1f1 f3f2f2f2 f4f4f3f3     ................
d00846e0:	f4f4f4f4 f4f4f4f4 f4f4f4f4 f4f5f5f2     ................
d00846f0:	f4f4f4f4 f5f4f5f4 f5f4f5f4 f4f4f5f4     ................
d0084700:	f2f2f5f4 f2f2f2f2 f4f4f2f2 f3f3f3f3     ................
d0084710:	f4f3f4f5 f3f3f3f3 0000f5f5 00000000     ................
	...
d0084734:	f3f3f400 f5f3f4f3 f6f5f6f5 f7f6f8f5     ................
d0084744:	f4f4f5f7 f4f4f4f4 f4f4f4f4 f4f4f4f4     ................
d0084754:	f5f5f2f4 f3f3f4f4 0000f3f3 00000000     ................
d0084764:	f4f4f4f3 f2f2f5f4 f3f3f3f3 f4f3f4f3     ................
d0084774:	f4f3f4f3 f4f4f4f4 f4f4f5f2 f4f4f4f4     ................
d0084784:	f4f4f4f4 f4f4f4f4 f5f4f4f4 f6f4f4f5     ................
d0084794:	f4f4f5f5 f5f4f5f5 f4f4f5f4 f3f3f4f4     ................
d00847a4:	f3f2f2f3 f2f2f2f2 f2f2f2f2 f3f4f4f3     ................
d00847b4:	f3f4f3f2 f5f3f3f3 000000f5 00000000     ................
	...
d00847d8:	f3f50000 f4f3f4f3 f6f5f6f4 f6f8f6f5     ................
d00847e8:	f7f7f6f7 f4f4f4f5 f4f4f4f4 f4f4f4f4     ................
d00847f8:	f5f5f5f2 f4f4f4f4 f4f4f4f4 f4f4f4f4     ................
d0084808:	f4f4f4f4 f4f5f2f4 f4f4f4f4 f4f4f4f4     ................
d0084818:	f4f4f4f4 f4f4f4f4 f4f4f5f2 f4f4f4f4     ................
d0084828:	f4f4f4f4 f4f4f4f4 f5f5f5f4 f3f5f5f5     ................
d0084838:	f4f5f5f6 f5f4f4f5 f4f4f5f4 f2f3f2f3     ................
d0084848:	f3f2f2f3 f2f2f2f2 f2f2f2f2 f3f4f2f2     ................
d0084858:	f3f2f3f4 f5f5f3f3 00000000 00000000     ................
	...
d008487c:	f6f30000 f4f3f4f3 f6f5f5f4 f8f5f5f5     ................
d008488c:	f7f6f7f6 f5f8f7f7 f4f4f5f5 f2f4f4f4     ................
d008489c:	f4f5f5f5 f4f4f4f4 f4f4f4f4 f4f4f4f4     ................
d00848ac:	f4f4f4f4 f4f5f4f2 f4f4f4f4 f4f4f4f4     ................
d00848bc:	f4f4f4f4 f4f4f4f4 f4f5f2f4 f4f4f4f4     ................
d00848cc:	f4f5f4f4 f5f5f5f5 f5f5f5f5 f5f5f5f5     ................
d00848dc:	f5f5f5f4 f5f4f4f5 f2f5f4f4 f2f3f2f3     ................
d00848ec:	f3f2f2f3 f2f3f2f2 f2f2f2f2 f3f4f4f3     ................
d00848fc:	f2f3f4f4 00f5f5f2 00000000 00000000     ................
	...
d0084920:	f3000000 f4f4f5f6 f6f5f5f4 f8f5f6f5     ................
d0084930:	f5f5f7f6 f5f5f5f5 f8f8f8f8 f5f5f6f7     ................
d0084940:	f4f4f5f5 f4f4f4f4 f4f4f4f4 f4f4f4f4     ................
d0084950:	f2f4f4f4 f4f4f5f4 f4f4f4f4 f4f4f4f4     ................
d0084960:	f4f4f4f4 f4f4f4f4 f5f6f3f4 f5f5f5f5     ................
d0084970:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f5f5f5f5     ................
d0084980:	f6f4f5f5 f5f5f5f5 f2f3f3f2 f2f3f2f3     ................
d0084990:	f2f3f2f3 f2f3f2f2 f4f3f2f2 f4f4f4f4     ................
d00849a0:	f5f3f4f4 0000f2f5 00000000 00000000     ................
	...
d00849c8:	f5f7f5f5 f6f5f5f4 f8f5f6f5 f5f5f7f6     ................
d00849d8:	f8f8f7f8 f8f8f6f6 f8f6f8f8 f7f7f8f9     ................
d00849e8:	f5f5f6f7 f4f4f4f5 f4f4f4f4 f2f2f4f4     ................
d00849f8:	f4f4f6f5 f4f4f4f4 f5f5f5f4 f5f5f5f5     ................
d0084a08:	f6f5f6f6 f7f4f5f5 f5f5f5f6 f5f5f5f5     ................
d0084a18:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f3f5f5f5     ................
d0084a28:	f5f5f5f6 f2f3f3f4 f2f3f2f3 f2f3f2f3     ................
d0084a38:	f2f3f2f3 f4f4f4f3 f4f4f4f4 f5f5f4f4     ................
d0084a48:	0000f2f5 00000000 00000000 00000000     ................
	...
d0084a6c:	f7f4f500 f5f5f6f6 f8f8f8f6 f5f5f7f6     ................
d0084a7c:	f9f8f8f8 f6f9f5f8 f6f9f6f8 f8f8f8f9     ................
d0084a8c:	f7f7f7f7 f7f7f7f7 f7f7f7f7 f2f2f6f7     ................
d0084a9c:	f7f6f7f8 f7f6f6f6 f6f6f6f6 f5f6f6f6     ................
d0084aac:	f6f5f6f6 f5f5f6f5 f5f5f5f8 f5f5f5f5     ................
d0084abc:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f5f5f5f3     ................
d0084acc:	f5f5f5f4 f2f5f5f5 f2f3f3f3 f2f3f2f3     ................
d0084adc:	f4f3f2f3 f4f4f4f4 f4f4f4f4 f5f5f5f5     ................
d0084aec:	000000f4 00000000 00000000 00000000     ................
	...
d0084b10:	f2f50000 f6f6f7f5 f6f6f6f7 f5f6f7f7     ................
d0084b20:	f9f7f9f8 f8f5f5f9 f8f9f9f8 f8f8f8f8     ................
d0084b30:	f8f7f8f7 f7f7f7f7 f7f7f7f7 f2f7f6f7     ................
d0084b40:	f7f6f7f5 f7f6f7f6 f6f6f6f6 f6f6f6f6     ................
d0084b50:	f6f5f6f6 f5f5f6f5 f6f5f7f5 f5f5f5f5     ................
d0084b60:	f5f5f5f5 f5f5f5f5 f3f4f3f4 f5f5f4f4     ................
d0084b70:	f5f5f4f5 f4f5f5f5 f2f2f3f3 f4f3f2f3     ................
d0084b80:	f4f4f4f3 f4f4f4f4 f5f5f5f4 00f4f5f5     ................
	...
d0084bb8:	f5f5f4f5 f7f6f5f7 f7f8f8f5 f3f5f9f8     ................
d0084bc8:	f3f2f2f5 f9fbf5f3 f8f8f8f8 f8f7f8f7     ................
d0084bd8:	f7f8f7f7 f7f7f7f7 f7f7f7f7 f7f6f9f2     ................
d0084be8:	f7f6f7f6 f6f6f6f6 f6f6f6f6 f6f5f6f6     ................
d0084bf8:	f6f5f6f5 f6f6f5f5 f5f5f5f5 f5f5f5f5     ................
d0084c08:	f3f3f4f4 f3f4f3f4 f5f3f3f4 f4f5f5f5     ................
d0084c18:	f5f5f5f6 f3f2f3f5 f4f5f4f3 f4f4f4f4     ................
d0084c28:	f5f5f5f4 f4f5f5f5 00000000 00000000     ................
	...
d0084c5c:	f3f50000 f5f4f5f3 f6f6f5f8 f2f5f5f3     ................
d0084c6c:	f2f2f2f5 f7f5f2f2 f6f6f8f8 f6f5f6f7     ................
d0084c7c:	f7f8f7f7 f7f7f7f7 f7f7f7f7 f7f7f2f5     ................
d0084c8c:	f7f6f7f6 f6f7f6f6 f6f6f6f6 f6f5f6f6     ................
d0084c9c:	f6f5f6f6 f6f6f5f5 f4f4f4f6 f4f4f4f4     ................
d0084cac:	f4f3f4f4 f3f4f3f4 f3f4f3f4 f5f5f5f4     ................
d0084cbc:	f5f5f6f3 f5f4f5f5 f4f5f4f5 f5f5f4f4     ................
d0084ccc:	f5f5f5f5 f20000f4 00000000 00000000     ................
	...
d0084d00:	f2000000 f5f4f4f2 f6f5f4f5 f2f2f5f6     ................
d0084d10:	f2f2f2f2 f3f2f2f2 f6f9f9f5 f6f5f6f5     ................
d0084d20:	f5f6f5f5 f5f5f5f5 f7f5f5f5 f7f2f5f6     ................
d0084d30:	f5f5f5f6 f5f5f5f5 f5f5f5f5 f5f5f5f5     ................
d0084d40:	f6f4f4f5 f7f5f6f5 f4f5f6f6 f4f4f4f4     ................
d0084d50:	f4f3f4f4 f3f4f3f4 f3f4f3f4 f5f5f3f4     ................
d0084d60:	f5f6f3f5 f5f5f5f5 f5f4f4f4 f5f5f5f5     ................
d0084d70:	0000f4f5 00000000 00000000 00000000     ................
	...
d0084da8:	f2f2f200 f2f3f5f4 f5f6f4f2 f2f2f2f2     ................
d0084db8:	f2f2f200 f9f5f5f2 f6f6f5f9 f5f6f6f5     ................
d0084dc8:	f5f5f6f5 f5f5f5f5 f2f8f5f7 f5f5f7f6     ................
d0084dd8:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f5f5f4f5     ................
d0084de8:	f5f5f6f5 f4f6f6f7 f4f4f4f4 f4f4f4f4     ................
d0084df8:	f3f4f3f4 f3f4f3f4 f5f5f5f4 f5f2f5f5     ................
d0084e08:	f4f4f4f4 f5f5f5f5 f2f4f5f5 00000000     ................
	...
d0084e4c:	f2000000 f2f5f4f2 f2f2f2f2 f2f2f5f4     ................
d0084e5c:	f20000f2 f2f5f2f2 f8f9f9f9 f5f5f6f5     ................
d0084e6c:	f5f5f6f5 f5f5f5f5 f8f5f7f7 f5f6f7f7     ................
d0084e7c:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f5f5f4f5     ................
d0084e8c:	f6f5f6f4 f5f6f7f5 f4f4f5f4 f4f4f4f4     ................
d0084e9c:	f4f4f3f4 f5f5f5f4 f5f5f5f5 f2f5f5f5     ................
d0084eac:	f5f5f5f5 f4f5f5f5 00000000 00000000     ................
	...
d0084ef4:	f4f2f200 f2f2f2f2 f4f2f2f2 f40000f2     ................
d0084f04:	f2f5f4f4 f9f8f8f8 f6f5f6f9 f5f5f6f5     ................
d0084f14:	f5f5f5f5 f8f5f7f5 f5f6f7f7 f5f5f5f5     ................
d0084f24:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f6f5f6f4     ................
d0084f34:	f6f7f5f5 f4f4f5f5 f5f4f4f4 f5f5f5f5     ................
d0084f44:	f5f5f5f5 f5f5f5f5 f6f6f5f5 f5f5f5f2     ................
	...
d0084f98:	f2000000 f2f2f4f4 f2f2f2f2 000000f2     ................
d0084fa8:	f4000000 f9f5f5f5 f6f8f8f9 f5f5f6f5     ................
d0084fb8:	f5f5f5f6 f5f7f7f5 f7f6f7f9 f5f5f5f5     ................
d0084fc8:	f5f5f5f5 f5f5f5f5 f5f5f5f5 f6f6f5f5     ................
d0084fd8:	f8f3f6f6 f5f5f6f5 f5f5f5f5 f5f5f5f5     ................
d0084fe8:	f5f5f5f5 f6f9f6f5 f5f5f5f6 f2f3f3f3     ................
d0084ff8:	0000f2f2 00000000 00000000 00000000     ................
	...
d0085040:	f2f2f2f2 f2f2f200 f2f200f2 00000000     ................
d0085050:	f4f4f200 f9f9f9f5 f9f9f9f9 f8f9f8f9     ................
d0085060:	f6f8f8f8 f8f8f8f9 f8f7f8f7 f7f7f7f7     ................
d0085070:	f6f7f6f7 f6f7f6f7 f6f6f6f6 f2f6f6f6     ................
d0085080:	f5f5f5f7 f5f5f5f5 f9f9f5f5 f5f5f5f9     ................
d0085090:	f5f5f5f5 f5f5f5f5 f3f3f4f4 00f2f2f2     ................
	...
d00850e4:	f2000000 f2000000 0000f2f2 00000000     ................
d00850f4:	00000000 f5f5f200 f8f9f8f9 f8f9f8f9     ................
d0085104:	f8f8f8f8 f8f8f9f5 f8f7f8f7 f6f6f7f7     ................
d0085114:	f6f7f6f7 f6f7f6f7 f5f6f6f6 f9f6f5f6     ................
d0085124:	f6f5f6f2 f6f6f6f6 f9f9f9f6 f5f5f5f5     ................
d0085134:	f6f6f6f6 f5f5f5f6 f3f4f4f5 f2f2f2f3     ................
d0085144:	f2f2f2f2 000000f2 00000000 00000000     ................
	...
d008518c:	f2000000 0000f2f2 00000000 00000000     ................
d008519c:	f2f20000 f9f9f9f5 f6f6f6f6 f5f6f6f6     ................
d00851ac:	f5f5f2f5 f6f7f6f6 f6f6f6f6 f6f6f6f6     ................
d00851bc:	f6f6f6f6 f8f8f6f6 f8f8f8f8 f5f2f2f8     ................
d00851cc:	f6f5f5f4 f6f6f7f6 f6f6f6f6 f6f6f6f6     ................
d00851dc:	f5f5f5f5 f4f4f5f5 f2f2f3f3 f3f2f2f2     ................
d00851ec:	00f2f2f3 00000000 00000000 00000000     ................
	...
d0085234:	0000f200 00000000 00000000 00000000     ................
d0085244:	f5f50000 f9f9f9f9 f9f9f9f9 f9f5f9f9     ................
d0085254:	f9f9f9f9 f9f9f9f9 f9f9f9f9 f9f9f9f9     ................
d0085264:	f5f9f9f9 f2f3f3f5 f2f2f2f2 f5f5f4f2     ................
d0085274:	f7f6f6f5 f7f8f8f7 f6f6f7f7 f5f5f5f6     ................
d0085284:	f4f4f5f5 f2f2f2f3 f2f2f2f2 f2f3f3f3     ................
	...
d0085310:	f4f4f2f2 f4f2f2f2 f6f5f5f5 f6f6f6f6     ................
d0085320:	f6f6f6f6 f5f5f5f5 f3f4f5f5 fef2f2f2     ................
d0085330:	f2f2f2fe f3f3f3f2 000000f2 00000000     ................
	...
d00853b4:	f4000000 f2f2f2f2 f4f4f3f2 f5f5f5f5     ................
d00853c4:	f5f5f5f5 f5f5f5f5 f2f2f3f3 f8f2f2f2     ................
d00853d4:	f2f2f2f2 f3f3f3f2 0000f2f3 00000000     ................
	...
d008545c:	f3f2f200 f2f2f2f2 f3f3f3f2 f3f3f3f3     ................
d008546c:	f2f3f3f3 f2f2f2f2 f2f2f4f2 f2f2f2f2     ................
d008547c:	f3f3f3f2 00f2f2f3 00000000 00000000     ................
	...
d0085500:	f3f20000 f9f2f2f2 f2f2f2f2 f2f2f2f2     ................
d0085510:	f2f2f2f2 f2f2f2f2 f2f2f2f2 f2f2f2f2     ................
d0085520:	f3f3f3f2 f2f3f3f3 00000000 00000000     ................
	...
d00855a4:	f2000000 f2f2f3f2 f9f2f2f2 f4f2f2f2     ................
d00855b4:	f2f9f2f2 f2f2f2f6 f2f2f2f2 f3f2f2f2     ................
d00855c4:	f3f3f3f3 f3f3f3f4 000000f2 00000000     ................
	...
d008564c:	f3f4f5f4 f2f2f2f2 f2f2f2f2 f2f2f2f2     ................
d008565c:	f2f2f2f2 f2f2f2f2 f3f3f3f2 f3f4f3f3     ................
d008566c:	f2f3f3f3 000000f5 00000000 00000000     ................
	...
d00856f0:	f5f5f300 f4f5f6f6 f2f2f2f3 f2f2f2f2     ................
d0085700:	f2f2f2f2 f3f2f2f2 f4f3f3f3 f3f4f4f5     ................
d0085710:	f2f3f3f3 000000f2 00000000 00000000     ................
	...
d0085794:	f4f30000 f7f6f6f5 f5f5f7f7 f6f4f4f4     ................
d00857a4:	f5f5f5f5 f5f5f5f5 f4f5f5f5 f3f3f4f4     ................
d00857b4:	f2f2f3f3 0000f3f5 00000000 00000000     ................
	...
d0085838:	f5000000 f5f5f4f5 f5f7f6f6 f4f4f4f5     ................
d0085848:	f5f5f5f5 f5f5f5f5 f3f4f4f5 f3f3f3f3     ................
d0085858:	f3f2f2f2 00f2f3f5 00000000 00000000     ................
	...
d00858e0:	f4f5f300 f5f5f4f4 f5f5f5f5 f5f5f5f5     ................
d00858f0:	f4f5f5f5 f3f3f3f4 f2f2f3f3 f3f5f3f2     ................
d0085900:	0000f3f5 00000000 00000000 00000000     ................
	...
d0085988:	f3f5f3f5 f5f5f5f5 f5f5f5f5 f4f4f4f5     ................
d0085998:	f2f2f3f3 f2f2f2f2 f3f5f3f5 00f5f3f5     ................
	...
d0085a2c:	f3f50000 f3f5f3f5 f3f5f3f5 f3f5f3f8     ................
d0085a3c:	f3f5f3f5 f3f5f3f5 f3f5f3f5 00f5f3f5     ................
	...
d0085ad4:	f3f5f300 f3f5f3f5 f5f5f3f5 f4f5f5f5     ................
d0085ae4:	f3f5f4f5 f3f5f3f5 f5f5f3f5 00000000     ................
	...
d0085b78:	f3000000 f3f5f3f5 f4f5f3f5 f5f5f5f5     ................
d0085b88:	f3f5f4f5 f3f5f3f5 f5f5f3f5 00000000     ................
	...
d0085c20:	f3f50000 f3f5f3f5 f5f5f4f5 f4f5f5f5     ................
d0085c30:	f3f5f3f5 f3f5f3f5 000000f5 00000000     ................
	...
d0085cc8:	f3f5f300 f5f5f4f5 f4f5f5f5 f3f5f4f5     ................
d0085cd8:	f3f5f3f5 000000f5 00000000 00000000     ................
	...
d0085d6c:	f3000000 f4f5f3f5 f5f5f5f5 f3f5f4f5     ................
d0085d7c:	f3f5f3f5 000000f5 00000000 00000000     ................
	...
d0085e14:	f3f5f2f2 f5f5f4f5 f3f5f4f5 f5f5f3f5     ................
d0085e24:	0000f2f5 00000000 00000000 00000000     ................
	...
d0085ebc:	f4f5f300 f4f5f5f5 f5f5f5f5 000000f5     ................
	...
d0085f60:	f2000000 f5f5f5f5 f2f5f9f5 0000f2f5     ................
	...
d0086008:	f3000000 f2f5f2f5 00f2f5f9 00000000     ................
	...
d00860b0:	f5f2f500 f50000f2 00000000 00000000     ................
	...
d0086154:	f2f50000 0000f5f2 000000f5 00000000     ................
	...
d00861f8:	f3000000 00f5f2f5 0000f900 00000000     ................
	...
d00862a0:	f5f2f500 00000000 00000000 00000000     ................
	...
d0086344:	f2f90000 000000f5 00000000 00000000     ................
	...
d00863ec:	00f5f1f2 00000000 00000000 00000000     ................
	...
d0086490:	f5f1f100 00000000 00000000 00000000     ................
	...
d0086534:	00f10000 000000f5 00000000 00000000     ................
	...
d00865dc:	0000f500 00000000 00000000 00000000     ................
	...
d0086680:	f5f20000 00000000 00000000 00000000     ................
	...
d0086728:	000000f9 00000000 00000000 00000000     ................
	...

d0086770 <px_enemy>:
	...
d008677c:	f2f2f2f2 00f2f2f2 00000000 00000000     ................
	...
d0086798:	f3f3f200 e1e1e1e1 f3e1e1e1 0000f2f3     ................
	...
d00867b4:	e5000000 e1e1e1e5 e1e1e1e1 e1e1e1e1     ................
d00867c4:	00e5e1e1 00000000 00000000 00000000     ................
d00867d4:	e5e50000 e4e4e1e6 e4e4e4e4 e1e1e1e4     ................
d00867e4:	e5e6e1e1 000000e5 00000000 00000000     ................
d00867f4:	e7e5e500 e4e4e4e7 e4e4e4e4 e1e4e4e4     ................
d0086804:	e7e7e1e1 0000e5e5 00000000 00000000     ................
d0086814:	e7e7e5e5 e3e3e3e8 e4e4e3e3 e4e4e4e4     ................
d0086824:	e7e8e1e4 00e5e5e7 00000000 e5000000     ................
d0086834:	e8e7e7e5 e3e3e3e8 e3e3e3e3 e4e4e4e4     ................
d0086844:	e8e8e4e4 e5e5e7e7 00000000 e5e50000     ................
d0086854:	e8e8e7e7 e3e3e3fe e3e3e3e3 e4e4e4e3     ................
d0086864:	e8fee4e4 e5e7e7e8 000000e5 e6e50000     ................
d0086874:	fee8e8e7 e2e2e2fe e3e3e3e3 e4e4e3e3     ................
d0086884:	fefee4e4 e6e7e8e8 000000e5 e4e1f200     ................
d0086894:	e2e3e3e3 e2e2e2e2 f3f3e1e4 e4e1f3f3     ................
d00868a4:	e4e4e4e4 e1e1e1e1 0000f2e1 e4e1f300     ................
d00868b4:	e2e3e3e3 f3e2e2e2 f3f3f3f3 f3f3f3f3     ................
d00868c4:	e4e4e4e4 e1e1e1e1 0000f3e1 e3e4f200     ................
d00868d4:	e2e2e3e3 f3f3e2e2 f3f3f3f3 f3f3f3f3     ................
d00868e4:	e4e4e4f3 e1e1e1e4 0000f2e1 e3e4e1f2     ................
d00868f4:	e2e2e3e3 f3f3e4e2 f3f3f3f3 f3f3f3f3     ................
d0086904:	e4e4e1f3 e1e1e1e4 00f2e1e1 e3e4e1f2     ................
d0086914:	e2e2e3e3 f3f3e1e2 f3f3f3f3 f3f3f3f3     ................
d0086924:	e4e4f3f3 e1e1e1e4 00f2e1e1 e3e4e1f2     ................
d0086934:	e2e3e3e3 f3f3f3e2 f3f3f3f3 f3f3f3f3     ................
d0086944:	e4e4f3f3 e1e1e1e4 00f2e1e1 e3e4e1f2     ................
d0086954:	e2e3e3e3 f3f3f3e2 f3f3f3f3 f3f3f3f3     ................
d0086964:	e4e3f3f3 e1e1e1e4 00f2e1e1 e4e4e1f2     ................
d0086974:	e3e3e3e3 f3f3f3e3 f3f3f3f3 f3f3f3f3     ................
d0086984:	e4e3f3f3 e1e1e1e4 00f2e1e1 e4e4e1f2     ................
d0086994:	e3e3e3e3 f3f3e1e3 f3f3f3f3 f3f3f3f3     ................
d00869a4:	e4e3e1f3 e1e1e1e4 00f2e1e1 e4e1e1f2     ................
d00869b4:	e3e3e3e4 f3f3e4e3 f3f3f3f3 f3f3f3f3     ................
d00869c4:	e4e3e3f3 e1e1e1e1 00f2e1e1 e4e1f200     ................
d00869d4:	e3e3e4e4 f3f3e3e3 f3f3f3f3 f3f3f3f3     ................
d00869e4:	e4e4f8e1 e1e1e1e1 0000f2e1 e1e1f300     ................
d00869f4:	e3e4e4e4 f3e3e3e3 f3f3f3f3 e1f3f3f3     ................
d0086a04:	e1e4e4f9 e1e1e1e1 0000f3e1 e1e1f200     ................
d0086a14:	e4e4e4e4 e3e3e3e4 f3f3e1e4 f8e3e1f3     ................
d0086a24:	e1e4e4e4 e1e1e1e1 0000f2e1 e6e50000     ................
d0086a34:	fee8e8e7 e4e4e4fe e3e3e4e4 e4e3e2e3     ................
d0086a44:	fefee4e4 e6e7e8e8 000000e5 e5e50000     ................
d0086a54:	e8e8e7e7 e4e4e4fe e4e4e4e4 e4e4e4e4     ................
d0086a64:	e8fee1e4 e5e7e7e8 000000e5 e5000000     ................
d0086a74:	e8e7e7e5 e4e4e4e8 e4e4e4e4 e1e4e4e4     ................
d0086a84:	e8e8e1e1 e5e5e7e7 00000000 00000000     ................
d0086a94:	e7e7e5e5 e4e4e1e8 e4e4e4e4 e1e1e1e4     ................
d0086aa4:	e7e8e1e1 00e5e5e7 00000000 00000000     ................
d0086ab4:	e7e5e500 e1e1e1e7 e1e1e1e1 e1e1e1e1     ................
d0086ac4:	e7e7e1e1 0000e5e5 00000000 00000000     ................
d0086ad4:	e5e50000 e1e1e1e6 e1e1e1e1 e1e1e1e1     ................
d0086ae4:	e5e6e1e1 000000e5 00000000 00000000     ................
d0086af4:	e5000000 e1e1e1e5 e1e1e1e1 e1e1e1e1     ................
d0086b04:	e5e5e1e1 00000000 00000000 00000000     ................
d0086b14:	00000000 f2f3f200 e1e1e1e1 f2e1e1e1     ................
d0086b24:	0000f2f3 00000000 00000000 00000000     ................
	...
d0086b3c:	f2f2f2f2 00f2f2f2 00000000 00000000     ................
	...

d0086b70 <px_ship>:
d0086b70:	00000000 0000f2f2 00000000 00000000     ................
	...
d0086b90:	f8f30000 0000f2f8 00000000 00000000     ................
	...
d0086bb0:	f8f8f300 0000f2f8 00000000 00000000     ................
	...
d0086bd0:	f6f6f6f2 0000f2f5 00000000 00000000     ................
	...
d0086bec:	f2000000 f5f5f5f5 f2f2f2f2 f2f2f2f2     ................
d0086bfc:	f2f2f2f2 0000f2f2 00000000 00000000     ................
d0086c0c:	f2f20000 f7f7f5f5 f7fbfbf5 f7e0e1f2     ................
d0086c1c:	f6f6f7f7 00f2f2f5 00000000 f2f20000     ................
d0086c2c:	f7f2f3f2 f5f7f9f9 f2f7fbfb f9e0e0e1     ................
d0086c3c:	fbfbfbfb f2f2fbf2 00000000 f7f7f200     ................
d0086c4c:	f5f5f2f5 fbf5f5f5 e1f2f7fb e0e0e0e1     ................
d0086c5c:	fbf2e0e0 f2e1e1f2 00000000 f7fbfbf2     ................
d0086c6c:	fbfbf7f5 fbf9f5f9 e1f3f5f9 e1e1e1e1     ................
d0086c7c:	e1f2fbf2 f2e1fbe0 f2000000 f3f6f7f7     ................
d0086c8c:	f9fbf9f7 fbf9f7f5 f2f2f5f7 fbf2f2f2     ................
d0086c9c:	e1f3f2f2 f2e1fbe0 f7f20000 f7f2f6f7     ................
d0086cac:	f9f9f9f9 f9f9f7f5 f9f9f9f9 f3f5f9f9     ................
d0086cbc:	e1f3f2f2 f2f2e0e0 f2f2f200 f9f5f2f3     ................
d0086ccc:	f9f9f9f9 f4f4f5f5 f5f5f5f4 f7f8f8f8     ................
d0086cdc:	e1f3f2f5 00f2e1e1 f2000000 f2f2f2f2     ................
d0086cec:	f2f2f2f2 f3f5f5f3 f3f3f2f2 f8f8f7f5     ................
d0086cfc:	f2f2f3f5 0000f2f2 00000000 f5f5f5f2     ................
d0086d0c:	f5f4f5f5 f3f5f5f5 f2f2f2f3 f8f8f5f2     ................
d0086d1c:	f8f9f9f9 0000f2f6 f2000000 f6f6f6f6     ................
d0086d2c:	f7f5f2f6 f5f5f5f7 f4f3f4f5 f2f2f2f5     ................
d0086d3c:	f2f2f2f2 000000f2 f7f20000 f2f7f7f7     ................
d0086d4c:	f6f2f200 f2f2f7f7 f2f2f2f2 000000f2     ................
	...
d0086d64:	f2f20000 0000f2f2 f2f20000 000000f2     ................
	...

d0086d80 <topscroll_bar_bg1>:
d0086d80:	9f9f9f9f 9f9f9f9f 9f9f9f9f 020202a0     ................
d0086d90:	a0020202 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086da0:	029f9f9f 02020202 9f9fa002 9f9f9f9f     ................
d0086db0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086dc0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 029f9f9f     ................
d0086dd0:	02020202 02020202 9f020202 9f9f9f9f     ................
d0086de0:	9f9f9f9f 0202a09f a3020202 9f9fa3a3     ................
d0086df0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086e00:	a00202a0 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086e10:	02029f9f 02020202 02020202 9f9fa002     ................
d0086e20:	9f9f9f9f 9f9f9f9f 0202a09f 02020202     ................
d0086e30:	02020202 9f9f0202 9f9f9f9f 9f9f9f9f     ................
d0086e40:	0202029f 02020202 9f9f9f9f 9f9f9f9f     ................
d0086e50:	9f9f9f9f 9f9f9f9f a00202a0 02a09f9f     ................
d0086e60:	9f9f9f02 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086e70:	02020202 9f020202 9f9f9f9f 9f9f9f9f     ................
d0086e80:	a09f9f9f 02020202 02020202 9f9f0202     ................
d0086e90:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086ea0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086eb0:	029f9f9f 0202a0a0 9f9f0202 9f9f9f9f     ................
d0086ec0:	9f9f9f9f 9f9f9f9f 0202a09f 02020202     ................
d0086ed0:	9f9f9f02 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086ee0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086ef0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f00:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f10:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f20:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f30:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f40:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f50:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f60:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f70:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f80:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086f90:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086fa0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086fb0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086fc0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086fd0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086fe0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0086ff0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087000:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087010:	a0a0a09f a0a0a0a0 9f9f9f9f 9f9f9f9f     ................
d0087020:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087030:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087040:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087050:	b79f9f9f 02020202 b7b702a0 9fa0a0a0     ................
d0087060:	9f9f9f9f 9f9f9f9f 9f9f9f9f 8f8f9f9f     ................
d0087070:	9f9f8f8f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087080:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d0087090:	9f9f9f9f b7b79f9f 02a00202 b7020202     ................
d00870a0:	9f9fa0b7 9f9f9f9f 8f9f9f9f 8f8f8f8f     ................
d00870b0:	8f8f8f8f 8f8f8f8f a0a0a0a0 9fa0a0a0     ................
d00870c0:	9f9f9f9f 9f9f9f9f 9f9f9f9f 9f9f9f9f     ................
d00870d0:	8f8f8f8f 8f8f8f8f 09098f8f a0a0a009     ................
d00870e0:	9fa0a0a0 9f9f9f9f 8f8f8f9f 8f8f8f8f     ................
d00870f0:	8f8f8f8f 8f8f8f8f 02b78f8f a0020202     ................
d0087100:	a0b7b702 8f8fa0a0 8f8f8f8f 8f8f8f8f     ................
d0087110:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087120:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087130:	8f8f8f8f 8f8f8f8f 8f8f8f8f 02b7b78f     ................
d0087140:	0202a002 b7b70202 8f8f8fa0 8f8f8f8f     ................
d0087150:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087160:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087170:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087180:	8f8f8f8f a0a0a0a0 8f8fa0a0 06068f8f     ................
d0087190:	06060606 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00871a0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00871b0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00871c0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00871d0:	0605068f 06060606 8f8f8f06 8f8f8f8f     ................
d00871e0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00871f0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087200:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087210:	8f8f8f8f 06060506 06060606 8f8f0606     ................
d0087220:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087230:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087240:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087250:	8f8f8f8f 068f8f8f 06060605 06060606     ................
d0087260:	8f8f0606 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087270:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087280:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087290:	8f8f8f8f 8f8f8f8f 05068f8f 06060606     ................
d00872a0:	06060606 8f066006 8f8f8f8f 8f8f8f8f     .....`..........
d00872b0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00872c0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00872d0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 0605068f     ................
d00872e0:	06060606 06060606 06600606 8f8f8f8f     ..........`.....
d00872f0:	05058f8f 05050505 05050505 8f8f8f8f     ................
d0087300:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087310:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087320:	06050606 06060606 06060606 06600606     ..............`.
d0087330:	8f8f8f06 05010505 05050505 05050505     ................
d0087340:	8f8f0505 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087350:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087360:	068f8f8f 06060506 06060606 06060606     ................
d0087370:	60060606 05058f06 05050101 05050505     ...`............
d0087380:	05050505 8f050605 8f8f8f8f 8f8f8f8f     ................
d0087390:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00873a0:	8f8f8f8f 06068f8f 06060605 06060606     ................
d00873b0:	06060606 60060606 01050505 05050505     .......`........
d00873c0:	05050505 05050505 05060505 8f8f8f8f     ................
d00873d0:	8f8f8f8f 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d00873e0:	8f8f8f8f 8f8f8f8f 0506068f 06060606     ................
d00873f0:	06060606 06060606 05050606 05010105     ................
d0087400:	05050505 05050505 05050505 06050505     ................
d0087410:	8f8f0505 8f8f8f8f 8f8f8f8f 8f8f8f8f     ................
d0087420:	8f8f8f8f 8f8f8f8f 8f8f0d8f 06050606     ................
d0087430:	06060606 06060606 06060606 050d0505     ................
d0087440:	05050501 05050505 05050505 05050505     ................
d0087450:	05050505 8f050506 8f8f8f8f 8f8f8f8f     ................
d0087460:	8f8f8f8f 8f8f8f8f 8f0d8f8f 068f0d8f     ................
d0087470:	06060606 06060606 060d0606 05060606     ................
d0087480:	050d0505 05050d05 05050505 050d050d     ................
d0087490:	05050505 05050505 05050605 0d8f8f05     ................
d00874a0:	8f8f8f8f 8f0d8f0d 8f8f8f8f 0d0d0d0d     ................
d00874b0:	0d0d0d0d 0d0d0d0d 0d0d0d0d 0d0d0d0d     ................
d00874c0:	0d0d0d0d 0d0d0d0d 0d0d0d0d 0d0d0d0d     ................
d00874d0:	0d0d0d0d 0d0d0d0d 0d0d0d0d 0d0d0d0d     ................
d00874e0:	0d0d0d0d 0d0d0d0d 0d0d0d0d 0d0d0d0d     ................
d00874f0:	0d0a0b0a 0a0a0a0d 0b0a0b0a 0a0a0a0a     ................
d0087500:	0a0a0a0a 680a0a0a 0b0b0a68 0a0a0a0a     .......hh.......
d0087510:	0a0a0b0a 680a0a0a 0a0a0a0a 6868680a     .......h.....hhh
d0087520:	0b0b0b0a 0a0a0b0a 0a0a0b0a 0a0b0b0b     ................
d0087530:	0a0a0b0b 0b0b0a0a 0b0a0a0a 0a0a0a0b     ................
d0087540:	0a0a0a0a 0a0b0a0a 0a0a0a0a 0a0a0a0a     ................
d0087550:	0b0a0a0a 0a0a0a0a 0a0a0a0a 0b0b0a0a     ................
d0087560:	0a0a0a0a 0a0a0a0b 0a0a0b0a 0a0a0a0a     ................
d0087570:	0a0a0a0a 0b0b0a0a 0a0a0b0a 0a0a0b0a     ................
d0087580:	0a680a0b 0b0a0a0a 0a0a0b0b 0a0a6868     ..h.........hh..
d0087590:	680a0a0a 0a0b0a68 0a686868 680a0a0a     ...hh...hhh....h
d00875a0:	0a0a6868 0b0a0a0a 0a0a0a0a 0b0b0a0a     hh..............
d00875b0:	0a0a0a0a 0a0a0a0a 0b0a0a0a 0a0a0a0a     ................
d00875c0:	6868680b 0a0a0a0a 68680a0a 0a0a0a0a     .hhh......hh....
d00875d0:	0b0a0a0a 0a0a0a0b 0a0a0a0a 0a0a0a0a     ................
d00875e0:	0a0a0a0a 0a0a0a0a 0a0a0a0a 0a0a0a0a     ................
d00875f0:	0a0a0a0a 680a0a0a 0b0b6868 0a0a0a0a     .......hhh......

d0087600 <gradient_cols.9116>:
d0087600:	11101010 13121211 15141413 17161615     ................
d0087610:	00001717                                ....

d0087614 <txtTitle>:
d0087614:	73696874 20736920 65742061 73207473     this is a test s
d0087624:	6c6f7263 202c796c 656d6f73 6e696874     crolly, somethin
d0087634:	6f742067 73657420 6f662074 6f6e2072     g to test for no
d0087644:	62202c77 77207475 206c6c69 656b616d     w, but will make
d0087654:	20746920 696c2061 656c7474 74656220      it a little bet
d0087664:	20726574 6c6c6966 65742079 20797478     ter filly texty 
d0087674:	66757473 00000066                       stuff...

d008767c <_global_impure_ptr>:
d008767c:	d0087728                                (w..

d0087680 <__sf_fake_stderr>:
	...

d00876a0 <__sf_fake_stdin>:
	...

d00876c0 <__sf_fake_stdout>:
	...

Disassembly of section .init:

d00876e0 <_init>:
d00876e0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00876e2:	bf00      	nop

Disassembly of section .fini:

d00876e4 <_fini>:
d00876e4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00876e6:	bf00      	nop
