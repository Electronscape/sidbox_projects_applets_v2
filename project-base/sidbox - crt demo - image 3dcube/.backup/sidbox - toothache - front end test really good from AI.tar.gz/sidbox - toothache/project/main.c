#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "main.h"
#include "apis.h"

#define APP_TITLE       "TOOTH ACHE"
#define SCREEN_W        480
#define SCREEN_H        320
#define METER_COUNT     16

enum {
    COL_BLACK = 0,
    COL_BG,
    COL_BG_2,
    COL_PANEL,
    COL_PANEL_HI,
    COL_TEXT,
    COL_TEXT_DIM,
    COL_CYAN,
    COL_GREEN,
    COL_YELLOW,
    COL_RED,
    COL_BLUE,
    COL_MAGENTA,
    COL_WHITE,
    COL_SHADOW,
    COL_SCAN
};

static gfx_bitmap_t *front_a;
static gfx_bitmap_t *front_b;
static uint8_t draw_side;

static uint32_t MEMALIGN32 palette[256];

static uint32_t argb(uint8_t r, uint8_t g, uint8_t b)
{
    return 0xFF000000u | ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
}

static void build_palette(void)
{
    memset(palette, 0, sizeof(palette));

    palette[COL_BLACK]    = argb(0, 0, 0);
    palette[COL_BG]       = argb(4, 8, 18);
    palette[COL_BG_2]     = argb(8, 16, 30);
    palette[COL_PANEL]    = argb(18, 29, 42);
    palette[COL_PANEL_HI] = argb(31, 50, 66);
    palette[COL_TEXT]     = argb(226, 241, 239);
    palette[COL_TEXT_DIM] = argb(117, 145, 151);
    palette[COL_CYAN]     = argb(0, 215, 224);
    palette[COL_GREEN]    = argb(51, 232, 144);
    palette[COL_YELLOW]   = argb(255, 207, 82);
    palette[COL_RED]      = argb(247, 91, 91);
    palette[COL_BLUE]     = argb(63, 129, 255);
    palette[COL_MAGENTA]  = argb(227, 89, 255);
    palette[COL_WHITE]    = argb(255, 255, 255);
    palette[COL_SHADOW]   = argb(2, 4, 10);
    palette[COL_SCAN]     = argb(21, 80, 87);

    for (uint16_t i = 0; i < 32; ++i) {
        palette[32 + i] = argb((uint8_t)(4 + i),
                               (uint8_t)(10 + (i * 2)),
                               (uint8_t)(22 + (i * 3)));
    }

    for (uint16_t i = 0; i < 32; ++i) {
        palette[64 + i] = argb((uint8_t)(0 + (i / 3)),
                               (uint8_t)(88 + (i * 4)),
                               (uint8_t)(108 + (i * 3)));
    }

    for (uint16_t i = 0; i < 32; ++i) {
        palette[96 + i] = argb((uint8_t)(80 + (i * 5)),
                               (uint8_t)(40 + (i * 3)),
                               (uint8_t)(210 - (i * 2)));
    }
}

static uint8_t meter_level(uint32_t frame, uint8_t meter)
{
    uint8_t phase = (uint8_t)((frame * 3u + (uint32_t)meter * 13u) & 63u);
    uint8_t tri = (phase < 32u) ? phase : (uint8_t)(63u - phase);

    return (uint8_t)(14u + (tri * 2u));
}

static void draw_text_shadow(int16_t x, int16_t y, const char *text)
{
    gfx_setcolour(COL_SHADOW);
    gfx_drawtext((long)(x + 1), (long)(y + 1), text);
    gfx_setcolour(COL_TEXT);
    gfx_drawtext(x, y, text);
}

static void draw_panel(int16_t x, int16_t y, int16_t w, int16_t h)
{
    gfx_setcolour(COL_SHADOW);
    gfx_rectf((int16_t)(x + 3), (int16_t)(y + 3), w, h);
    gfx_setcolour(COL_PANEL);
    gfx_rectf(x, y, w, h);
    gfx_setcolour(COL_PANEL_HI);
    gfx_rectf(x, y, w, 2);
    gfx_rectf(x, y, 2, h);
}

static void draw_background(uint32_t frame)
{
    uint8_t offset = (uint8_t)((frame >> 2) & 31u);

    for (int16_t y = 0; y < SCREEN_H; y = (int16_t)(y + 8)) {
        gfx_setcolour((uint8_t)(32u + (((uint16_t)y >> 3) + offset) % 32u));
        gfx_rectf(0, y, SCREEN_W, 8);
    }

    gfx_setcolour(COL_SCAN);
    for (int16_t y = (int16_t)(frame & 15u); y < SCREEN_H; y = (int16_t)(y + 16)) {
        gfx_rectf(0, y, SCREEN_W, 1);
    }

    for (uint8_t i = 0; i < 36; ++i) {
        int16_t x = (int16_t)(((uint32_t)i * 73u + frame * 2u) % SCREEN_W);
        int16_t y = (int16_t)(52u + (((uint32_t)i * 47u) % 148u));
        gfx_setcolour((uint8_t)(COL_CYAN + ((i + frame) & 3u)));
        gfx_plot(x, y);
    }
}

static void draw_header(uint32_t frame)
{
    gfx_setcolour(COL_PANEL);
    gfx_rectf(0, 0, SCREEN_W, 42);
    gfx_setcolour(COL_CYAN);
    gfx_rectf(0, 40, SCREEN_W, 2);

    draw_text_shadow(18, 13, "SIDBOX MUSIC BOX");

    gfx_setcolour((frame & 32u) ? COL_GREEN : COL_YELLOW);
    gfx_rectf(362, 12, 10, 10);
    gfx_setcolour(COL_TEXT_DIM);
    gfx_drawtext(380, 13, "BOOT FRONTEND");
}

static void draw_meters(uint32_t frame)
{
    const int16_t x0 = 30;
    const int16_t y0 = 64;
    const int16_t w = 420;
    const int16_t h = 138;
    const int16_t base_y = (int16_t)(y0 + h - 18);
    const int16_t bar_w = 18;
    const int16_t gap = 8;

    draw_panel(x0, y0, w, h);

    gfx_setcolour(COL_TEXT_DIM);
    gfx_drawtext(x0 + 14, y0 + 12, "GRAPHICS PRIMITIVE TEST");

    for (uint8_t i = 0; i < METER_COUNT; ++i) {
        int16_t x = (int16_t)(x0 + 14 + (int16_t)i * (bar_w + gap));
        uint8_t height = meter_level(frame, i);

        gfx_setcolour(COL_BG_2);
        gfx_rectf(x, (int16_t)(base_y - 96), bar_w, 96);

        for (uint8_t seg = 0; seg < height; seg = (uint8_t)(seg + 8)) {
            uint8_t colour = COL_GREEN;
            if (seg > 64u) {
                colour = COL_RED;
            } else if (seg > 42u) {
                colour = COL_YELLOW;
            }

            gfx_setcolour(colour);
            gfx_rectf(x, (int16_t)(base_y - seg - 6), bar_w, 5);
        }
    }

    gfx_setcolour(COL_CYAN);
    gfx_rectf(x0 + 14, base_y + 11, (int16_t)(80 + (frame % 318u)), 3);
}

static void draw_playlist(uint32_t frame)
{
    uint8_t selected = (uint8_t)((frame >> 7) % 3u);

    draw_panel(28, 222, 294, 70);
    gfx_setcolour(COL_TEXT_DIM);
    gfx_drawtext(42, 234, "STARTUP:/LOADWB NOT FOUND");

    for (uint8_t row = 0; row < 3; ++row) {
        int16_t y = (int16_t)(250 + row * 13);

        if (row == selected) {
            gfx_setcolour(COL_BLUE);
            gfx_rectf(39, (int16_t)(y - 2), 270, 11);
        }

        gfx_setcolour(row == selected ? COL_WHITE : COL_TEXT_DIM);
        if (row == 0) {
            gfx_drawtext(46, y, "01  BOOT_TEST.MOD");
        } else if (row == 1) {
            gfx_drawtext(46, y, "02  SD CARD SCAN SOON");
        } else {
            gfx_drawtext(46, y, "03  TOOTHACHE.APP");
        }
    }
}

static void draw_transport(uint32_t frame)
{
    int16_t pulse = (int16_t)((frame >> 2) & 15u);

    draw_panel(340, 222, 110, 70);

    gfx_setcolour(COL_GREEN);
    for (int16_t i = 0; i < 18; ++i) {
        gfx_rectf((int16_t)(368 + i), (int16_t)(244 - (i / 2)), 1, (int16_t)(10 + i));
    }

    gfx_setcolour(COL_YELLOW);
    gfx_rectf(398, 239, 5, 30);
    gfx_rectf(408, 239, 5, 30);

    gfx_setcolour(COL_CYAN);
    gfx_rectf(360, 277, (int16_t)(70 + pulse), 3);

    gfx_setcolour(COL_TEXT_DIM);
    gfx_drawtext(358, 228, "NO OS GUI");
}

static void draw_scene(uint32_t frame)
{
    draw_background(frame);
    draw_header(frame);
    draw_meters(frame);
    draw_playlist(frame);
    draw_transport(frame);

    gfx_setcolour(COL_TEXT_DIM);
    gfx_drawtext(18, 304, "TOOTH ACHE FRONTEND TEST - CORE GRAPHICS ONLY");
}

static void flip_to_next_draw_buffer(void)
{
    draw_side = (uint8_t)(1u - draw_side);

    if (draw_side) {
        gfx_dispfbuffer(front_a, front_b);
    } else {
        gfx_dispfbuffer(front_b, front_a);
    }
}

int main(int argc, char *argv[])
{
    uint32_t frame = 0;

    (void)argc;
    (void)argv;

    initMalloc();
    printf(APP_TITLE " boot frontend test starting\n");

    gfx_setlcd(DEFAULT_RENDER_ORDER, FPS_50);
    gfx_mode(SCREEN_W, SCREEN_H, SCREEN_W, SCREEN_H,
             DISPFLAG_SINGLELAYER | DISPFLAG_NOSCROLLABLE);

    front_a = gfx_getdrawbuffer();
    front_b = gfx_getshowbuffer();

    build_palette();
    gfx_usefpalette(palette);

    gfx_showfbuffer(front_a);
    gfx_usebuffer(front_b);
    lcd_bright(100);

    for (;;) {
        gfx_lcdwait();
        flip_to_next_draw_buffer();
        draw_scene(frame++);
        gfx_displaynow();
    }

    return 0x00;
}
