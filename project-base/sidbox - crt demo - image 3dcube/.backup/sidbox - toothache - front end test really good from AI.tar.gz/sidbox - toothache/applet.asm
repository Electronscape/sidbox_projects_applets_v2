
compiled/applet.elf:     file format elf32-littlearm


Disassembly of section .text:

d0040010 <applet_entry>:
d0040010:	b570      	push	{r4, r5, r6, lr}
d0040012:	4e09      	ldr	r6, [pc, #36]	; (d0040038 <applet_entry+0x28>)
d0040014:	460d      	mov	r5, r1
d0040016:	4604      	mov	r4, r0
d0040018:	2100      	movs	r1, #0
d004001a:	6833      	ldr	r3, [r6, #0]
d004001c:	6898      	ldr	r0, [r3, #8]
d004001e:	f000 ff77 	bl	d0040f10 <setbuf>
d0040022:	6833      	ldr	r3, [r6, #0]
d0040024:	2100      	movs	r1, #0
d0040026:	68d8      	ldr	r0, [r3, #12]
d0040028:	f000 ff72 	bl	d0040f10 <setbuf>
d004002c:	4629      	mov	r1, r5
d004002e:	4620      	mov	r0, r4
d0040030:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
d0040034:	f000 b8fc 	b.w	d0040230 <main>
d0040038:	d0041a80 	.word	0xd0041a80

d004003c <initMalloc>:
d004003c:	4902      	ldr	r1, [pc, #8]	; (d0040048 <initMalloc+0xc>)
d004003e:	4b03      	ldr	r3, [pc, #12]	; (d004004c <initMalloc+0x10>)
d0040040:	4a03      	ldr	r2, [pc, #12]	; (d0040050 <initMalloc+0x14>)
d0040042:	1a5b      	subs	r3, r3, r1
d0040044:	6013      	str	r3, [r2, #0]
d0040046:	4770      	bx	lr
d0040048:	d0043f40 	.word	0xd0043f40
d004004c:	d0600000 	.word	0xd0600000
d0040050:	d0041f28 	.word	0xd0041f28

d0040054 <_write_r>:
d0040054:	3901      	subs	r1, #1
d0040056:	2901      	cmp	r1, #1
d0040058:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d004005a:	d81f      	bhi.n	d004009c <_write_r+0x48>
d004005c:	b1e2      	cbz	r2, d0040098 <_write_r+0x44>
d004005e:	461c      	mov	r4, r3
d0040060:	b1d3      	cbz	r3, d0040098 <_write_r+0x44>
d0040062:	4d12      	ldr	r5, [pc, #72]	; (d00400ac <_write_r+0x58>)
d0040064:	682e      	ldr	r6, [r5, #0]
d0040066:	b9ae      	cbnz	r6, d0040094 <_write_r+0x40>
d0040068:	4f11      	ldr	r7, [pc, #68]	; (d00400b0 <_write_r+0x5c>)
d004006a:	2301      	movs	r3, #1
d004006c:	4611      	mov	r1, r2
d004006e:	4630      	mov	r0, r6
d0040070:	602b      	str	r3, [r5, #0]
d0040072:	4622      	mov	r2, r4
d0040074:	7a3b      	ldrb	r3, [r7, #8]
d0040076:	f897 c009 	ldrb.w	ip, [r7, #9]
d004007a:	ea43 230c 	orr.w	r3, r3, ip, lsl #8
d004007e:	f897 c00a 	ldrb.w	ip, [r7, #10]
d0040082:	7aff      	ldrb	r7, [r7, #11]
d0040084:	ea43 430c 	orr.w	r3, r3, ip, lsl #16
d0040088:	ea43 6307 	orr.w	r3, r3, r7, lsl #24
d004008c:	681b      	ldr	r3, [r3, #0]
d004008e:	685b      	ldr	r3, [r3, #4]
d0040090:	4798      	blx	r3
d0040092:	602e      	str	r6, [r5, #0]
d0040094:	4620      	mov	r0, r4
d0040096:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0040098:	2000      	movs	r0, #0
d004009a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d004009c:	f000 feb4 	bl	d0040e08 <__errno>
d00400a0:	2209      	movs	r2, #9
d00400a2:	4603      	mov	r3, r0
d00400a4:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00400a8:	601a      	str	r2, [r3, #0]
d00400aa:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d00400ac:	d0041b04 	.word	0xd0041b04
d00400b0:	2001f000 	.word	0x2001f000

d00400b4 <_read>:
d00400b4:	b508      	push	{r3, lr}
d00400b6:	f000 fea7 	bl	d0040e08 <__errno>
d00400ba:	2258      	movs	r2, #88	; 0x58
d00400bc:	4603      	mov	r3, r0
d00400be:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00400c2:	601a      	str	r2, [r3, #0]
d00400c4:	bd08      	pop	{r3, pc}
d00400c6:	bf00      	nop

d00400c8 <_close>:
d00400c8:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d00400cc:	4770      	bx	lr
d00400ce:	bf00      	nop

d00400d0 <_fstat>:
d00400d0:	f44f 5300 	mov.w	r3, #8192	; 0x2000
d00400d4:	2000      	movs	r0, #0
d00400d6:	604b      	str	r3, [r1, #4]
d00400d8:	4770      	bx	lr
d00400da:	bf00      	nop

d00400dc <_lseek>:
d00400dc:	2000      	movs	r0, #0
d00400de:	4770      	bx	lr

d00400e0 <_sbrk_r>:
d00400e0:	4b0c      	ldr	r3, [pc, #48]	; (d0040114 <_sbrk_r+0x34>)
d00400e2:	4a0d      	ldr	r2, [pc, #52]	; (d0040118 <_sbrk_r+0x38>)
d00400e4:	6818      	ldr	r0, [r3, #0]
d00400e6:	b510      	push	{r4, lr}
d00400e8:	b918      	cbnz	r0, d00400f2 <_sbrk_r+0x12>
d00400ea:	1dd0      	adds	r0, r2, #7
d00400ec:	f020 0007 	bic.w	r0, r0, #7
d00400f0:	6018      	str	r0, [r3, #0]
d00400f2:	4401      	add	r1, r0
d00400f4:	4c09      	ldr	r4, [pc, #36]	; (d004011c <_sbrk_r+0x3c>)
d00400f6:	42a1      	cmp	r1, r4
d00400f8:	d803      	bhi.n	d0040102 <_sbrk_r+0x22>
d00400fa:	4291      	cmp	r1, r2
d00400fc:	d301      	bcc.n	d0040102 <_sbrk_r+0x22>
d00400fe:	6019      	str	r1, [r3, #0]
d0040100:	bd10      	pop	{r4, pc}
d0040102:	f000 fe81 	bl	d0040e08 <__errno>
d0040106:	220c      	movs	r2, #12
d0040108:	4603      	mov	r3, r0
d004010a:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d004010e:	601a      	str	r2, [r3, #0]
d0040110:	bd10      	pop	{r4, pc}
d0040112:	bf00      	nop
d0040114:	d0041b00 	.word	0xd0041b00
d0040118:	d0043f40 	.word	0xd0043f40
d004011c:	d0600000 	.word	0xd0600000

d0040120 <_isatty>:
d0040120:	2001      	movs	r0, #1
d0040122:	4770      	bx	lr

d0040124 <draw_panel>:
d0040124:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0040128:	4c40      	ldr	r4, [pc, #256]	; (d004022c <draw_panel+0x108>)
d004012a:	4698      	mov	r8, r3
d004012c:	b082      	sub	sp, #8
d004012e:	4606      	mov	r6, r0
d0040130:	7b25      	ldrb	r5, [r4, #12]
d0040132:	200e      	movs	r0, #14
d0040134:	7b67      	ldrb	r7, [r4, #13]
d0040136:	f894 e00e 	ldrb.w	lr, [r4, #14]
d004013a:	ea45 2507 	orr.w	r5, r5, r7, lsl #8
d004013e:	f894 c00f 	ldrb.w	ip, [r4, #15]
d0040142:	460f      	mov	r7, r1
d0040144:	9201      	str	r2, [sp, #4]
d0040146:	ea45 450e 	orr.w	r5, r5, lr, lsl #16
d004014a:	ea45 650c 	orr.w	r5, r5, ip, lsl #24
d004014e:	686b      	ldr	r3, [r5, #4]
d0040150:	68db      	ldr	r3, [r3, #12]
d0040152:	4798      	blx	r3
d0040154:	7b25      	ldrb	r5, [r4, #12]
d0040156:	7b63      	ldrb	r3, [r4, #13]
d0040158:	1cf9      	adds	r1, r7, #3
d004015a:	f894 e00e 	ldrb.w	lr, [r4, #14]
d004015e:	1cf0      	adds	r0, r6, #3
d0040160:	ea45 2503 	orr.w	r5, r5, r3, lsl #8
d0040164:	f894 c00f 	ldrb.w	ip, [r4, #15]
d0040168:	9a01      	ldr	r2, [sp, #4]
d004016a:	4643      	mov	r3, r8
d004016c:	ea45 450e 	orr.w	r5, r5, lr, lsl #16
d0040170:	b209      	sxth	r1, r1
d0040172:	ea45 650c 	orr.w	r5, r5, ip, lsl #24
d0040176:	b200      	sxth	r0, r0
d0040178:	686d      	ldr	r5, [r5, #4]
d004017a:	686d      	ldr	r5, [r5, #4]
d004017c:	47a8      	blx	r5
d004017e:	7b23      	ldrb	r3, [r4, #12]
d0040180:	7b61      	ldrb	r1, [r4, #13]
d0040182:	2003      	movs	r0, #3
d0040184:	7ba5      	ldrb	r5, [r4, #14]
d0040186:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d004018a:	7be1      	ldrb	r1, [r4, #15]
d004018c:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d0040190:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d0040194:	685b      	ldr	r3, [r3, #4]
d0040196:	68db      	ldr	r3, [r3, #12]
d0040198:	4798      	blx	r3
d004019a:	7b25      	ldrb	r5, [r4, #12]
d004019c:	7b61      	ldrb	r1, [r4, #13]
d004019e:	4643      	mov	r3, r8
d00401a0:	7ba0      	ldrb	r0, [r4, #14]
d00401a2:	ea45 2501 	orr.w	r5, r5, r1, lsl #8
d00401a6:	f894 c00f 	ldrb.w	ip, [r4, #15]
d00401aa:	9a01      	ldr	r2, [sp, #4]
d00401ac:	4639      	mov	r1, r7
d00401ae:	ea45 4500 	orr.w	r5, r5, r0, lsl #16
d00401b2:	4630      	mov	r0, r6
d00401b4:	ea45 650c 	orr.w	r5, r5, ip, lsl #24
d00401b8:	686d      	ldr	r5, [r5, #4]
d00401ba:	686d      	ldr	r5, [r5, #4]
d00401bc:	47a8      	blx	r5
d00401be:	7b23      	ldrb	r3, [r4, #12]
d00401c0:	7b61      	ldrb	r1, [r4, #13]
d00401c2:	2004      	movs	r0, #4
d00401c4:	7ba5      	ldrb	r5, [r4, #14]
d00401c6:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
d00401ca:	7be1      	ldrb	r1, [r4, #15]
d00401cc:	ea43 4305 	orr.w	r3, r3, r5, lsl #16
d00401d0:	ea43 6301 	orr.w	r3, r3, r1, lsl #24
d00401d4:	685b      	ldr	r3, [r3, #4]
d00401d6:	68db      	ldr	r3, [r3, #12]
d00401d8:	4798      	blx	r3
d00401da:	7b25      	ldrb	r5, [r4, #12]
d00401dc:	7b63      	ldrb	r3, [r4, #13]
d00401de:	4639      	mov	r1, r7
d00401e0:	f894 e00e 	ldrb.w	lr, [r4, #14]
d00401e4:	4630      	mov	r0, r6
d00401e6:	ea45 2503 	orr.w	r5, r5, r3, lsl #8
d00401ea:	f894 c00f 	ldrb.w	ip, [r4, #15]
d00401ee:	9a01      	ldr	r2, [sp, #4]
d00401f0:	2302      	movs	r3, #2
d00401f2:	ea45 450e 	orr.w	r5, r5, lr, lsl #16
d00401f6:	ea45 650c 	orr.w	r5, r5, ip, lsl #24
d00401fa:	686d      	ldr	r5, [r5, #4]
d00401fc:	686d      	ldr	r5, [r5, #4]
d00401fe:	47a8      	blx	r5
d0040200:	7b25      	ldrb	r5, [r4, #12]
d0040202:	7b62      	ldrb	r2, [r4, #13]
d0040204:	4639      	mov	r1, r7
d0040206:	f894 c00e 	ldrb.w	ip, [r4, #14]
d004020a:	4643      	mov	r3, r8
d004020c:	ea45 2502 	orr.w	r5, r5, r2, lsl #8
d0040210:	7be7      	ldrb	r7, [r4, #15]
d0040212:	4630      	mov	r0, r6
d0040214:	2202      	movs	r2, #2
d0040216:	ea45 440c 	orr.w	r4, r5, ip, lsl #16
d004021a:	ea44 6407 	orr.w	r4, r4, r7, lsl #24
d004021e:	6864      	ldr	r4, [r4, #4]
d0040220:	6864      	ldr	r4, [r4, #4]
d0040222:	46a4      	mov	ip, r4
d0040224:	b002      	add	sp, #8
d0040226:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d004022a:	4760      	bx	ip
d004022c:	2001f000 	.word	0x2001f000

d0040230 <main>:
d0040230:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
d0040234:	f8df b2fc 	ldr.w	fp, [pc, #764]	; d0040534 <main+0x304>
d0040238:	b087      	sub	sp, #28
d004023a:	f7ff feff 	bl	d004003c <initMalloc>
d004023e:	48b4      	ldr	r0, [pc, #720]	; (d0040510 <main+0x2e0>)
d0040240:	f000 fe5e 	bl	d0040f00 <puts>
d0040244:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0040248:	f89b 200d 	ldrb.w	r2, [fp, #13]
d004024c:	2190      	movs	r1, #144	; 0x90
d004024e:	f89b 400e 	ldrb.w	r4, [fp, #14]
d0040252:	20dc      	movs	r0, #220	; 0xdc
d0040254:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040258:	f89b 200f 	ldrb.w	r2, [fp, #15]
d004025c:	2500      	movs	r5, #0
d004025e:	f04f 37ff 	mov.w	r7, #4294967295	; 0xffffffff
d0040262:	ea43 4304 	orr.w	r3, r3, r4, lsl #16
d0040266:	4cab      	ldr	r4, [pc, #684]	; (d0040514 <main+0x2e4>)
d0040268:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004026c:	681b      	ldr	r3, [r3, #0]
d004026e:	691b      	ldr	r3, [r3, #16]
d0040270:	4798      	blx	r3
d0040272:	f89b 600c 	ldrb.w	r6, [fp, #12]
d0040276:	f89b 000d 	ldrb.w	r0, [fp, #13]
d004027a:	f44f 73a0 	mov.w	r3, #320	; 0x140
d004027e:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0040282:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0040286:	ea46 2600 	orr.w	r6, r6, r0, lsl #8
d004028a:	f89b 000f 	ldrb.w	r0, [fp, #15]
d004028e:	ea46 4601 	orr.w	r6, r6, r1, lsl #16
d0040292:	4619      	mov	r1, r3
d0040294:	ea46 6600 	orr.w	r6, r6, r0, lsl #24
d0040298:	4610      	mov	r0, r2
d004029a:	6836      	ldr	r6, [r6, #0]
d004029c:	9500      	str	r5, [sp, #0]
d004029e:	6976      	ldr	r6, [r6, #20]
d00402a0:	47b0      	blx	r6
d00402a2:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00402a6:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00402aa:	f89b 100e 	ldrb.w	r1, [fp, #14]
d00402ae:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00402b2:	f89b 200f 	ldrb.w	r2, [fp, #15]
d00402b6:	4e98      	ldr	r6, [pc, #608]	; (d0040518 <main+0x2e8>)
d00402b8:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00402bc:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00402c0:	681b      	ldr	r3, [r3, #0]
d00402c2:	6b5b      	ldr	r3, [r3, #52]	; 0x34
d00402c4:	4798      	blx	r3
d00402c6:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00402ca:	4994      	ldr	r1, [pc, #592]	; (d004051c <main+0x2ec>)
d00402cc:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00402d0:	6008      	str	r0, [r1, #0]
d00402d2:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00402d6:	f89b 100e 	ldrb.w	r1, [fp, #14]
d00402da:	f89b 200f 	ldrb.w	r2, [fp, #15]
d00402de:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00402e2:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00402e6:	681b      	ldr	r3, [r3, #0]
d00402e8:	6b9b      	ldr	r3, [r3, #56]	; 0x38
d00402ea:	4798      	blx	r3
d00402ec:	4629      	mov	r1, r5
d00402ee:	4603      	mov	r3, r0
d00402f0:	4d8b      	ldr	r5, [pc, #556]	; (d0040520 <main+0x2f0>)
d00402f2:	4620      	mov	r0, r4
d00402f4:	f44f 6280 	mov.w	r2, #1024	; 0x400
d00402f8:	602b      	str	r3, [r5, #0]
d00402fa:	f000 fd8b 	bl	d0040e14 <memset>
d00402fe:	2516      	movs	r5, #22
d0040300:	f104 037c 	add.w	r3, r4, #124	; 0x7c
d0040304:	a174      	add	r1, pc, #464	; (adr r1, d00404d8 <main+0x2a8>)
d0040306:	e9d1 0100 	ldrd	r0, r1, [r1]
d004030a:	e9c4 670c 	strd	r6, r7, [r4, #48]	; 0x30
d004030e:	e9c4 0100 	strd	r0, r1, [r4]
d0040312:	a773      	add	r7, pc, #460	; (adr r7, d00404e0 <main+0x2b0>)
d0040314:	e9d7 6700 	ldrd	r6, r7, [r7]
d0040318:	a173      	add	r1, pc, #460	; (adr r1, d00404e8 <main+0x2b8>)
d004031a:	e9d1 0100 	ldrd	r0, r1, [r1]
d004031e:	e9c4 6702 	strd	r6, r7, [r4, #8]
d0040322:	e9c4 0104 	strd	r0, r1, [r4, #16]
d0040326:	a772      	add	r7, pc, #456	; (adr r7, d00404f0 <main+0x2c0>)
d0040328:	e9d7 6700 	ldrd	r6, r7, [r7]
d004032c:	a172      	add	r1, pc, #456	; (adr r1, d00404f8 <main+0x2c8>)
d004032e:	e9d1 0100 	ldrd	r0, r1, [r1]
d0040332:	e9c4 6706 	strd	r6, r7, [r4, #24]
d0040336:	e9c4 0108 	strd	r0, r1, [r4, #32]
d004033a:	a771      	add	r7, pc, #452	; (adr r7, d0040500 <main+0x2d0>)
d004033c:	e9d7 6700 	ldrd	r6, r7, [r7]
d0040340:	a171      	add	r1, pc, #452	; (adr r1, d0040508 <main+0x2d8>)
d0040342:	e9d1 0100 	ldrd	r0, r1, [r1]
d0040346:	e9c4 670a 	strd	r6, r7, [r4, #40]	; 0x28
d004034a:	e9c4 010e 	strd	r0, r1, [r4, #56]	; 0x38
d004034e:	f44f 6620 	mov.w	r6, #2560	; 0xa00
d0040352:	f44f 2180 	mov.w	r1, #262144	; 0x40000
d0040356:	ea45 0201 	orr.w	r2, r5, r1
d004035a:	f501 3180 	add.w	r1, r1, #65536	; 0x10000
d004035e:	3503      	adds	r5, #3
d0040360:	4332      	orrs	r2, r6
d0040362:	f5b1 1f10 	cmp.w	r1, #2359296	; 0x240000
d0040366:	f506 7600 	add.w	r6, r6, #512	; 0x200
d004036a:	f042 427f 	orr.w	r2, r2, #4278190080	; 0xff000000
d004036e:	f843 2f04 	str.w	r2, [r3, #4]!
d0040372:	d1f0      	bne.n	d0040356 <main+0x126>
d0040374:	4d6b      	ldr	r5, [pc, #428]	; (d0040524 <main+0x2f4>)
d0040376:	246c      	movs	r4, #108	; 0x6c
d0040378:	f44f 40b0 	mov.w	r0, #22528	; 0x5800
d004037c:	2100      	movs	r1, #0
d004037e:	4e6a      	ldr	r6, [pc, #424]	; (d0040528 <main+0x2f8>)
d0040380:	b28a      	uxth	r2, r1
d0040382:	ea44 0300 	orr.w	r3, r4, r0
d0040386:	3101      	adds	r1, #1
d0040388:	f500 6080 	add.w	r0, r0, #1024	; 0x400
d004038c:	fba6 7202 	umull	r7, r2, r6, r2
d0040390:	3403      	adds	r4, #3
d0040392:	2920      	cmp	r1, #32
d0040394:	ea4f 0252 	mov.w	r2, r2, lsr #1
d0040398:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d004039c:	f043 437f 	orr.w	r3, r3, #4278190080	; 0xff000000
d00403a0:	f845 3f04 	str.w	r3, [r5, #4]!
d00403a4:	d1ec      	bne.n	d0040380 <main+0x150>
d00403a6:	4c61      	ldr	r4, [pc, #388]	; (d004052c <main+0x2fc>)
d00403a8:	f44f 5020 	mov.w	r0, #10240	; 0x2800
d00403ac:	21d2      	movs	r1, #210	; 0xd2
d00403ae:	f44f 02a0 	mov.w	r2, #5242880	; 0x500000
d00403b2:	ea41 0302 	orr.w	r3, r1, r2
d00403b6:	f502 22a0 	add.w	r2, r2, #327680	; 0x50000
d00403ba:	3902      	subs	r1, #2
d00403bc:	4303      	orrs	r3, r0
d00403be:	f5b2 0f70 	cmp.w	r2, #15728640	; 0xf00000
d00403c2:	f500 7040 	add.w	r0, r0, #768	; 0x300
d00403c6:	f043 437f 	orr.w	r3, r3, #4278190080	; 0xff000000
d00403ca:	f844 3f04 	str.w	r3, [r4, #4]!
d00403ce:	d1f0      	bne.n	d00403b2 <main+0x182>
d00403d0:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00403d4:	f04f 0a00 	mov.w	sl, #0
d00403d8:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00403dc:	f89b 100e 	ldrb.w	r1, [fp, #14]
d00403e0:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d00403e4:	f89b 200f 	ldrb.w	r2, [fp, #15]
d00403e8:	484a      	ldr	r0, [pc, #296]	; (d0040514 <main+0x2e4>)
d00403ea:	ea43 4301 	orr.w	r3, r3, r1, lsl #16
d00403ee:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d00403f2:	681b      	ldr	r3, [r3, #0]
d00403f4:	6cdb      	ldr	r3, [r3, #76]	; 0x4c
d00403f6:	4798      	blx	r3
d00403f8:	f89b 300c 	ldrb.w	r3, [fp, #12]
d00403fc:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0040400:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040404:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040408:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d004040c:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0040410:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040414:	4a41      	ldr	r2, [pc, #260]	; (d004051c <main+0x2ec>)
d0040416:	681b      	ldr	r3, [r3, #0]
d0040418:	6810      	ldr	r0, [r2, #0]
d004041a:	69db      	ldr	r3, [r3, #28]
d004041c:	4798      	blx	r3
d004041e:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0040422:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0040426:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d004042a:	f89b 200e 	ldrb.w	r2, [fp, #14]
d004042e:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d0040432:	f89b 200f 	ldrb.w	r2, [fp, #15]
d0040436:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d004043a:	4a39      	ldr	r2, [pc, #228]	; (d0040520 <main+0x2f0>)
d004043c:	681b      	ldr	r3, [r3, #0]
d004043e:	6810      	ldr	r0, [r2, #0]
d0040440:	699b      	ldr	r3, [r3, #24]
d0040442:	4798      	blx	r3
d0040444:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0040448:	f89b 200d 	ldrb.w	r2, [fp, #13]
d004044c:	2064      	movs	r0, #100	; 0x64
d004044e:	ea43 2302 	orr.w	r3, r3, r2, lsl #8
d0040452:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040456:	ea43 4302 	orr.w	r3, r3, r2, lsl #16
d004045a:	f89b 200f 	ldrb.w	r2, [fp, #15]
d004045e:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
d0040462:	681b      	ldr	r3, [r3, #0]
d0040464:	689b      	ldr	r3, [r3, #8]
d0040466:	4798      	blx	r3
d0040468:	f89b 000c 	ldrb.w	r0, [fp, #12]
d004046c:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040470:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040474:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0040478:	f89b 300f 	ldrb.w	r3, [fp, #15]
d004047c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040480:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040484:	681b      	ldr	r3, [r3, #0]
d0040486:	68db      	ldr	r3, [r3, #12]
d0040488:	4798      	blx	r3
d004048a:	4a29      	ldr	r2, [pc, #164]	; (d0040530 <main+0x300>)
d004048c:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0040490:	7813      	ldrb	r3, [r2, #0]
d0040492:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0040496:	f1c3 0301 	rsb	r3, r3, #1
d004049a:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d004049e:	b2db      	uxtb	r3, r3
d00404a0:	7013      	strb	r3, [r2, #0]
d00404a2:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00404a6:	2b00      	cmp	r3, #0
d00404a8:	f000 8499 	beq.w	d0040dde <main+0xbae>
d00404ac:	491c      	ldr	r1, [pc, #112]	; (d0040520 <main+0x2f0>)
d00404ae:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d00404b2:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00404b6:	6809      	ldr	r1, [r1, #0]
d00404b8:	4818      	ldr	r0, [pc, #96]	; (d004051c <main+0x2ec>)
d00404ba:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00404be:	6800      	ldr	r0, [r0, #0]
d00404c0:	f3ca 0784 	ubfx	r7, sl, #2, #5
d00404c4:	f04f 0800 	mov.w	r8, #0
d00404c8:	681b      	ldr	r3, [r3, #0]
d00404ca:	6a5b      	ldr	r3, [r3, #36]	; 0x24
d00404cc:	4798      	blx	r3
d00404ce:	ea4f 039a 	mov.w	r3, sl, lsr #2
d00404d2:	9305      	str	r3, [sp, #20]
d00404d4:	e030      	b.n	d0040538 <main+0x308>
d00404d6:	bf00      	nop
d00404d8:	ff000000 	.word	0xff000000
d00404dc:	ff040812 	.word	0xff040812
d00404e0:	ff08101e 	.word	0xff08101e
d00404e4:	ff121d2a 	.word	0xff121d2a
d00404e8:	ff1f3242 	.word	0xff1f3242
d00404ec:	ffe2f1ef 	.word	0xffe2f1ef
d00404f0:	ff759197 	.word	0xff759197
d00404f4:	ff00d7e0 	.word	0xff00d7e0
d00404f8:	ff33e890 	.word	0xff33e890
d00404fc:	ffffcf52 	.word	0xffffcf52
d0040500:	fff75b5b 	.word	0xfff75b5b
d0040504:	ff3f81ff 	.word	0xff3f81ff
d0040508:	ff02040a 	.word	0xff02040a
d004050c:	ff155057 	.word	0xff155057
d0040510:	d0041918 	.word	0xd0041918
d0040514:	d0041b20 	.word	0xd0041b20
d0040518:	ffe359ff 	.word	0xffe359ff
d004051c:	d0041b0c 	.word	0xd0041b0c
d0040520:	d0041b10 	.word	0xd0041b10
d0040524:	d0041c1c 	.word	0xd0041c1c
d0040528:	aaaaaaab 	.word	0xaaaaaaab
d004052c:	d0041c9c 	.word	0xd0041c9c
d0040530:	d0041b08 	.word	0xd0041b08
d0040534:	2001f000 	.word	0x2001f000
d0040538:	f89b 400c 	ldrb.w	r4, [fp, #12]
d004053c:	eb07 00d8 	add.w	r0, r7, r8, lsr #3
d0040540:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0040544:	fa1f f688 	uxth.w	r6, r8
d0040548:	f89b 200e 	ldrb.w	r2, [fp, #14]
d004054c:	f000 001f 	and.w	r0, r0, #31
d0040550:	ea44 2303 	orr.w	r3, r4, r3, lsl #8
d0040554:	f89b 100f 	ldrb.w	r1, [fp, #15]
d0040558:	3020      	adds	r0, #32
d004055a:	3608      	adds	r6, #8
d004055c:	ea43 4202 	orr.w	r2, r3, r2, lsl #16
d0040560:	ea42 6301 	orr.w	r3, r2, r1, lsl #24
d0040564:	685b      	ldr	r3, [r3, #4]
d0040566:	68db      	ldr	r3, [r3, #12]
d0040568:	4798      	blx	r3
d004056a:	f89b 000c 	ldrb.w	r0, [fp, #12]
d004056e:	f89b 500d 	ldrb.w	r5, [fp, #13]
d0040572:	2308      	movs	r3, #8
d0040574:	f89b c00e 	ldrb.w	ip, [fp, #14]
d0040578:	4641      	mov	r1, r8
d004057a:	ea40 2005 	orr.w	r0, r0, r5, lsl #8
d004057e:	f89b 400f 	ldrb.w	r4, [fp, #15]
d0040582:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0040586:	fa0f f886 	sxth.w	r8, r6
d004058a:	ea40 450c 	orr.w	r5, r0, ip, lsl #16
d004058e:	2000      	movs	r0, #0
d0040590:	ea45 6404 	orr.w	r4, r5, r4, lsl #24
d0040594:	6864      	ldr	r4, [r4, #4]
d0040596:	6864      	ldr	r4, [r4, #4]
d0040598:	47a0      	blx	r4
d004059a:	b2b3      	uxth	r3, r6
d004059c:	f5b3 7fa0 	cmp.w	r3, #320	; 0x140
d00405a0:	d1ca      	bne.n	d0040538 <main+0x308>
d00405a2:	f89b 400c 	ldrb.w	r4, [fp, #12]
d00405a6:	200f      	movs	r0, #15
d00405a8:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00405ac:	f00a 070f 	and.w	r7, sl, #15
d00405b0:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00405b4:	ea44 2101 	orr.w	r1, r4, r1, lsl #8
d00405b8:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00405bc:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00405c0:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00405c4:	685b      	ldr	r3, [r3, #4]
d00405c6:	68db      	ldr	r3, [r3, #12]
d00405c8:	4798      	blx	r3
d00405ca:	f89b 600c 	ldrb.w	r6, [fp, #12]
d00405ce:	4639      	mov	r1, r7
d00405d0:	f89b 000d 	ldrb.w	r0, [fp, #13]
d00405d4:	3710      	adds	r7, #16
d00405d6:	f89b 500e 	ldrb.w	r5, [fp, #14]
d00405da:	2301      	movs	r3, #1
d00405dc:	ea46 2000 	orr.w	r0, r6, r0, lsl #8
d00405e0:	f89b 400f 	ldrb.w	r4, [fp, #15]
d00405e4:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d00405e8:	ea40 4505 	orr.w	r5, r0, r5, lsl #16
d00405ec:	2000      	movs	r0, #0
d00405ee:	ea45 6404 	orr.w	r4, r5, r4, lsl #24
d00405f2:	6864      	ldr	r4, [r4, #4]
d00405f4:	6864      	ldr	r4, [r4, #4]
d00405f6:	47a0      	blx	r4
d00405f8:	b2bb      	uxth	r3, r7
d00405fa:	b23f      	sxth	r7, r7
d00405fc:	f5b3 7fa0 	cmp.w	r3, #320	; 0x140
d0040600:	d3e3      	bcc.n	d00405ca <main+0x39a>
d0040602:	fa5f f48a 	uxtb.w	r4, sl
d0040606:	f04f 0800 	mov.w	r8, #0
d004060a:	ea4f 094a 	mov.w	r9, sl, lsl #1
d004060e:	2794      	movs	r7, #148	; 0x94
d0040610:	4625      	mov	r5, r4
d0040612:	4ed1      	ldr	r6, [pc, #836]	; (d0040958 <main+0x728>)
d0040614:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0040618:	f005 0003 	and.w	r0, r5, #3
d004061c:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040620:	3501      	adds	r5, #1
d0040622:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040626:	3007      	adds	r0, #7
d0040628:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
d004062c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040630:	b2ed      	uxtb	r5, r5
d0040632:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040636:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d004063a:	685b      	ldr	r3, [r3, #4]
d004063c:	68db      	ldr	r3, [r3, #12]
d004063e:	4798      	blx	r3
d0040640:	f89b e00c 	ldrb.w	lr, [fp, #12]
d0040644:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0040648:	ea4f 0198 	mov.w	r1, r8, lsr #2
d004064c:	fba6 3009 	umull	r3, r0, r6, r9
d0040650:	f89b 300e 	ldrb.w	r3, [fp, #14]
d0040654:	ea4e 2c02 	orr.w	ip, lr, r2, lsl #8
d0040658:	4ac0      	ldr	r2, [pc, #768]	; (d004095c <main+0x72c>)
d004065a:	0a00      	lsrs	r0, r0, #8
d004065c:	fba2 2101 	umull	r2, r1, r2, r1
d0040660:	ea4c 4203 	orr.w	r2, ip, r3, lsl #16
d0040664:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040668:	ebc0 1000 	rsb	r0, r0, r0, lsl #4
d004066c:	0889      	lsrs	r1, r1, #2
d004066e:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040672:	fb07 8111 	mls	r1, r7, r1, r8
d0040676:	eba9 1040 	sub.w	r0, r9, r0, lsl #5
d004067a:	685b      	ldr	r3, [r3, #4]
d004067c:	f108 082f 	add.w	r8, r8, #47	; 0x2f
d0040680:	3134      	adds	r1, #52	; 0x34
d0040682:	b200      	sxth	r0, r0
d0040684:	689b      	ldr	r3, [r3, #8]
d0040686:	f109 0949 	add.w	r9, r9, #73	; 0x49
d004068a:	b209      	sxth	r1, r1
d004068c:	4798      	blx	r3
d004068e:	f240 639c 	movw	r3, #1692	; 0x69c
d0040692:	4598      	cmp	r8, r3
d0040694:	d1be      	bne.n	d0040614 <main+0x3e4>
d0040696:	f89b 500c 	ldrb.w	r5, [fp, #12]
d004069a:	2003      	movs	r0, #3
d004069c:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00406a0:	eb04 0444 	add.w	r4, r4, r4, lsl #1
d00406a4:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00406a8:	272c      	movs	r7, #44	; 0x2c
d00406aa:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d00406ae:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00406b2:	b2e4      	uxtb	r4, r4
d00406b4:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00406b8:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00406bc:	685b      	ldr	r3, [r3, #4]
d00406be:	68db      	ldr	r3, [r3, #12]
d00406c0:	4798      	blx	r3
d00406c2:	f89b 600c 	ldrb.w	r6, [fp, #12]
d00406c6:	f89b 000d 	ldrb.w	r0, [fp, #13]
d00406ca:	2100      	movs	r1, #0
d00406cc:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00406d0:	232a      	movs	r3, #42	; 0x2a
d00406d2:	ea46 2000 	orr.w	r0, r6, r0, lsl #8
d00406d6:	f89b 500f 	ldrb.w	r5, [fp, #15]
d00406da:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d00406de:	4608      	mov	r0, r1
d00406e0:	ea42 6505 	orr.w	r5, r2, r5, lsl #24
d00406e4:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d00406e8:	686d      	ldr	r5, [r5, #4]
d00406ea:	686d      	ldr	r5, [r5, #4]
d00406ec:	47a8      	blx	r5
d00406ee:	f89b 500c 	ldrb.w	r5, [fp, #12]
d00406f2:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00406f6:	2007      	movs	r0, #7
d00406f8:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00406fc:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d0040700:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040704:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040708:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d004070c:	685b      	ldr	r3, [r3, #4]
d004070e:	68db      	ldr	r3, [r3, #12]
d0040710:	4798      	blx	r3
d0040712:	f89b 600c 	ldrb.w	r6, [fp, #12]
d0040716:	f89b 100d 	ldrb.w	r1, [fp, #13]
d004071a:	2302      	movs	r3, #2
d004071c:	f89b 000e 	ldrb.w	r0, [fp, #14]
d0040720:	f44f 72f0 	mov.w	r2, #480	; 0x1e0
d0040724:	ea46 2101 	orr.w	r1, r6, r1, lsl #8
d0040728:	f89b 500f 	ldrb.w	r5, [fp, #15]
d004072c:	ea41 4000 	orr.w	r0, r1, r0, lsl #16
d0040730:	2128      	movs	r1, #40	; 0x28
d0040732:	ea40 6505 	orr.w	r5, r0, r5, lsl #24
d0040736:	2000      	movs	r0, #0
d0040738:	686d      	ldr	r5, [r5, #4]
d004073a:	686d      	ldr	r5, [r5, #4]
d004073c:	47a8      	blx	r5
d004073e:	f89b 500c 	ldrb.w	r5, [fp, #12]
d0040742:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040746:	200e      	movs	r0, #14
d0040748:	f89b 200e 	ldrb.w	r2, [fp, #14]
d004074c:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d0040750:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040754:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040758:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d004075c:	685b      	ldr	r3, [r3, #4]
d004075e:	68db      	ldr	r3, [r3, #12]
d0040760:	4798      	blx	r3
d0040762:	f89b 600c 	ldrb.w	r6, [fp, #12]
d0040766:	f89b 000d 	ldrb.w	r0, [fp, #13]
d004076a:	210e      	movs	r1, #14
d004076c:	f89b 500e 	ldrb.w	r5, [fp, #14]
d0040770:	ea46 2000 	orr.w	r0, r6, r0, lsl #8
d0040774:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040778:	4a79      	ldr	r2, [pc, #484]	; (d0040960 <main+0x730>)
d004077a:	ea40 4505 	orr.w	r5, r0, r5, lsl #16
d004077e:	2013      	movs	r0, #19
d0040780:	ea45 6303 	orr.w	r3, r5, r3, lsl #24
d0040784:	685b      	ldr	r3, [r3, #4]
d0040786:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0040788:	4798      	blx	r3
d004078a:	f89b 500c 	ldrb.w	r5, [fp, #12]
d004078e:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040792:	2005      	movs	r0, #5
d0040794:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040798:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d004079c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00407a0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00407a4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00407a8:	685b      	ldr	r3, [r3, #4]
d00407aa:	68db      	ldr	r3, [r3, #12]
d00407ac:	4798      	blx	r3
d00407ae:	f89b 600c 	ldrb.w	r6, [fp, #12]
d00407b2:	f89b 000d 	ldrb.w	r0, [fp, #13]
d00407b6:	210d      	movs	r1, #13
d00407b8:	f89b 500e 	ldrb.w	r5, [fp, #14]
d00407bc:	ea46 2000 	orr.w	r0, r6, r0, lsl #8
d00407c0:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00407c4:	4a66      	ldr	r2, [pc, #408]	; (d0040960 <main+0x730>)
d00407c6:	ea40 4505 	orr.w	r5, r0, r5, lsl #16
d00407ca:	2012      	movs	r0, #18
d00407cc:	ea45 6303 	orr.w	r3, r5, r3, lsl #24
d00407d0:	685b      	ldr	r3, [r3, #4]
d00407d2:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d00407d4:	4798      	blx	r3
d00407d6:	f89b 000c 	ldrb.w	r0, [fp, #12]
d00407da:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00407de:	f01a 0f20 	tst.w	sl, #32
d00407e2:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00407e6:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d00407ea:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00407ee:	bf14      	ite	ne
d00407f0:	2008      	movne	r0, #8
d00407f2:	2009      	moveq	r0, #9
d00407f4:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00407f8:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00407fc:	685b      	ldr	r3, [r3, #4]
d00407fe:	68db      	ldr	r3, [r3, #12]
d0040800:	4798      	blx	r3
d0040802:	f89b 600c 	ldrb.w	r6, [fp, #12]
d0040806:	f89b 200d 	ldrb.w	r2, [fp, #13]
d004080a:	230a      	movs	r3, #10
d004080c:	f89b 000e 	ldrb.w	r0, [fp, #14]
d0040810:	210c      	movs	r1, #12
d0040812:	ea46 2202 	orr.w	r2, r6, r2, lsl #8
d0040816:	f89b 500f 	ldrb.w	r5, [fp, #15]
d004081a:	ea42 4000 	orr.w	r0, r2, r0, lsl #16
d004081e:	461a      	mov	r2, r3
d0040820:	ea40 6505 	orr.w	r5, r0, r5, lsl #24
d0040824:	f44f 70b5 	mov.w	r0, #362	; 0x16a
d0040828:	686d      	ldr	r5, [r5, #4]
d004082a:	686d      	ldr	r5, [r5, #4]
d004082c:	47a8      	blx	r5
d004082e:	f89b 500c 	ldrb.w	r5, [fp, #12]
d0040832:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040836:	2006      	movs	r0, #6
d0040838:	f89b 200e 	ldrb.w	r2, [fp, #14]
d004083c:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d0040840:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040844:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040848:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d004084c:	685b      	ldr	r3, [r3, #4]
d004084e:	68db      	ldr	r3, [r3, #12]
d0040850:	4798      	blx	r3
d0040852:	f89b 600c 	ldrb.w	r6, [fp, #12]
d0040856:	f89b 200d 	ldrb.w	r2, [fp, #13]
d004085a:	210d      	movs	r1, #13
d004085c:	f89b 500e 	ldrb.w	r5, [fp, #14]
d0040860:	f44f 70be 	mov.w	r0, #380	; 0x17c
d0040864:	ea46 2202 	orr.w	r2, r6, r2, lsl #8
d0040868:	f89b 300f 	ldrb.w	r3, [fp, #15]
d004086c:	ea42 4505 	orr.w	r5, r2, r5, lsl #16
d0040870:	4a3c      	ldr	r2, [pc, #240]	; (d0040964 <main+0x734>)
d0040872:	ea45 6303 	orr.w	r3, r5, r3, lsl #24
d0040876:	685b      	ldr	r3, [r3, #4]
d0040878:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d004087a:	4798      	blx	r3
d004087c:	238a      	movs	r3, #138	; 0x8a
d004087e:	f44f 72d2 	mov.w	r2, #420	; 0x1a4
d0040882:	2140      	movs	r1, #64	; 0x40
d0040884:	201e      	movs	r0, #30
d0040886:	f7ff fc4d 	bl	d0040124 <draw_panel>
d004088a:	f89b 500c 	ldrb.w	r5, [fp, #12]
d004088e:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040892:	2006      	movs	r0, #6
d0040894:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040898:	ea45 2101 	orr.w	r1, r5, r1, lsl #8
d004089c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00408a0:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00408a4:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d00408a8:	685b      	ldr	r3, [r3, #4]
d00408aa:	68db      	ldr	r3, [r3, #12]
d00408ac:	4798      	blx	r3
d00408ae:	f89b 600c 	ldrb.w	r6, [fp, #12]
d00408b2:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00408b6:	214c      	movs	r1, #76	; 0x4c
d00408b8:	f89b 500e 	ldrb.w	r5, [fp, #14]
d00408bc:	4638      	mov	r0, r7
d00408be:	ea46 2202 	orr.w	r2, r6, r2, lsl #8
d00408c2:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00408c6:	ea42 4505 	orr.w	r5, r2, r5, lsl #16
d00408ca:	4a27      	ldr	r2, [pc, #156]	; (d0040968 <main+0x738>)
d00408cc:	ea45 6303 	orr.w	r3, r5, r3, lsl #24
d00408d0:	685b      	ldr	r3, [r3, #4]
d00408d2:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d00408d4:	4798      	blx	r3
d00408d6:	06a3      	lsls	r3, r4, #26
d00408d8:	fa0f f987 	sxth.w	r9, r7
d00408dc:	f004 053f 	and.w	r5, r4, #63	; 0x3f
d00408e0:	d502      	bpl.n	d00408e8 <main+0x6b8>
d00408e2:	f1c5 053f 	rsb	r5, r5, #63	; 0x3f
d00408e6:	b2ed      	uxtb	r5, r5
d00408e8:	f89b 600c 	ldrb.w	r6, [fp, #12]
d00408ec:	2002      	movs	r0, #2
d00408ee:	f89b 200d 	ldrb.w	r2, [fp, #13]
d00408f2:	3507      	adds	r5, #7
d00408f4:	f89b c00e 	ldrb.w	ip, [fp, #14]
d00408f8:	f04f 0800 	mov.w	r8, #0
d00408fc:	ea46 2102 	orr.w	r1, r6, r2, lsl #8
d0040900:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040904:	006d      	lsls	r5, r5, #1
d0040906:	ea41 420c 	orr.w	r2, r1, ip, lsl #16
d004090a:	b2ed      	uxtb	r5, r5
d004090c:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040910:	685b      	ldr	r3, [r3, #4]
d0040912:	68db      	ldr	r3, [r3, #12]
d0040914:	4798      	blx	r3
d0040916:	f89b c00c 	ldrb.w	ip, [fp, #12]
d004091a:	f89b 100d 	ldrb.w	r1, [fp, #13]
d004091e:	2360      	movs	r3, #96	; 0x60
d0040920:	f89b 000e 	ldrb.w	r0, [fp, #14]
d0040924:	2212      	movs	r2, #18
d0040926:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d004092a:	f89b 600f 	ldrb.w	r6, [fp, #15]
d004092e:	ea41 4000 	orr.w	r0, r1, r0, lsl #16
d0040932:	2158      	movs	r1, #88	; 0x58
d0040934:	ea40 6606 	orr.w	r6, r0, r6, lsl #24
d0040938:	4648      	mov	r0, r9
d004093a:	6876      	ldr	r6, [r6, #4]
d004093c:	6876      	ldr	r6, [r6, #4]
d004093e:	47b0      	blx	r6
d0040940:	f1b8 0f40 	cmp.w	r8, #64	; 0x40
d0040944:	f04f 000a 	mov.w	r0, #10
d0040948:	d810      	bhi.n	d004096c <main+0x73c>
d004094a:	f1b8 0f2b 	cmp.w	r8, #43	; 0x2b
d004094e:	bf34      	ite	cc
d0040950:	2008      	movcc	r0, #8
d0040952:	2009      	movcs	r0, #9
d0040954:	e00a      	b.n	d004096c <main+0x73c>
d0040956:	bf00      	nop
d0040958:	88888889 	.word	0x88888889
d004095c:	1bacf915 	.word	0x1bacf915
d0040960:	d0041940 	.word	0xd0041940
d0040964:	d0041954 	.word	0xd0041954
d0040968:	d0041964 	.word	0xd0041964
d004096c:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0040970:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040974:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040978:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
d004097c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040980:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040984:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040988:	685b      	ldr	r3, [r3, #4]
d004098a:	68db      	ldr	r3, [r3, #12]
d004098c:	4798      	blx	r3
d004098e:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0040992:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0040996:	2305      	movs	r3, #5
d0040998:	f89b c00e 	ldrb.w	ip, [fp, #14]
d004099c:	2212      	movs	r2, #18
d004099e:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d00409a2:	f89b 600f 	ldrb.w	r6, [fp, #15]
d00409a6:	f1c8 01b2 	rsb	r1, r8, #178	; 0xb2
d00409aa:	f108 0808 	add.w	r8, r8, #8
d00409ae:	ea40 4c0c 	orr.w	ip, r0, ip, lsl #16
d00409b2:	4648      	mov	r0, r9
d00409b4:	fa5f f888 	uxtb.w	r8, r8
d00409b8:	ea4c 6606 	orr.w	r6, ip, r6, lsl #24
d00409bc:	6876      	ldr	r6, [r6, #4]
d00409be:	6876      	ldr	r6, [r6, #4]
d00409c0:	47b0      	blx	r6
d00409c2:	4545      	cmp	r5, r8
d00409c4:	d8bc      	bhi.n	d0040940 <main+0x710>
d00409c6:	371a      	adds	r7, #26
d00409c8:	340d      	adds	r4, #13
d00409ca:	b2bf      	uxth	r7, r7
d00409cc:	b2e4      	uxtb	r4, r4
d00409ce:	f5b7 7fe6 	cmp.w	r7, #460	; 0x1cc
d00409d2:	d180      	bne.n	d00408d6 <main+0x6a6>
d00409d4:	f89b 600c 	ldrb.w	r6, [fp, #12]
d00409d8:	2007      	movs	r0, #7
d00409da:	f89b 100d 	ldrb.w	r1, [fp, #13]
d00409de:	2501      	movs	r5, #1
d00409e0:	f89b 200e 	ldrb.w	r2, [fp, #14]
d00409e4:	24fa      	movs	r4, #250	; 0xfa
d00409e6:	ea46 2101 	orr.w	r1, r6, r1, lsl #8
d00409ea:	f89b 300f 	ldrb.w	r3, [fp, #15]
d00409ee:	2600      	movs	r6, #0
d00409f0:	f8df 9384 	ldr.w	r9, [pc, #900]	; d0040d78 <main+0xb48>
d00409f4:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d00409f8:	f8df 8380 	ldr.w	r8, [pc, #896]	; d0040d7c <main+0xb4c>
d00409fc:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040a00:	685b      	ldr	r3, [r3, #4]
d0040a02:	68db      	ldr	r3, [r3, #12]
d0040a04:	4798      	blx	r3
d0040a06:	f89b 000c 	ldrb.w	r0, [fp, #12]
d0040a0a:	f89b 300d 	ldrb.w	r3, [fp, #13]
d0040a0e:	fa2a fc05 	lsr.w	ip, sl, r5
d0040a12:	f89b 100e 	ldrb.w	r1, [fp, #14]
d0040a16:	f44f 729f 	mov.w	r2, #318	; 0x13e
d0040a1a:	ea40 2303 	orr.w	r3, r0, r3, lsl #8
d0040a1e:	48d1      	ldr	r0, [pc, #836]	; (d0040d64 <main+0xb34>)
d0040a20:	fba0 700c 	umull	r7, r0, r0, ip
d0040a24:	ea43 4101 	orr.w	r1, r3, r1, lsl #16
d0040a28:	f89b 700f 	ldrb.w	r7, [fp, #15]
d0040a2c:	2303      	movs	r3, #3
d0040a2e:	0900      	lsrs	r0, r0, #4
d0040a30:	ea41 6707 	orr.w	r7, r1, r7, lsl #24
d0040a34:	21c3      	movs	r1, #195	; 0xc3
d0040a36:	fb02 a210 	mls	r2, r2, r0, sl
d0040a3a:	202c      	movs	r0, #44	; 0x2c
d0040a3c:	687f      	ldr	r7, [r7, #4]
d0040a3e:	3250      	adds	r2, #80	; 0x50
d0040a40:	687f      	ldr	r7, [r7, #4]
d0040a42:	b212      	sxth	r2, r2
d0040a44:	47b8      	blx	r7
d0040a46:	48c8      	ldr	r0, [pc, #800]	; (d0040d68 <main+0xb38>)
d0040a48:	ea4f 17da 	mov.w	r7, sl, lsr #7
d0040a4c:	2346      	movs	r3, #70	; 0x46
d0040a4e:	f44f 7293 	mov.w	r2, #294	; 0x126
d0040a52:	21de      	movs	r1, #222	; 0xde
d0040a54:	fba0 c007 	umull	ip, r0, r0, r7
d0040a58:	40e8      	lsrs	r0, r5
d0040a5a:	eb00 0040 	add.w	r0, r0, r0, lsl #1
d0040a5e:	1a3f      	subs	r7, r7, r0
d0040a60:	201c      	movs	r0, #28
d0040a62:	b2ff      	uxtb	r7, r7
d0040a64:	9704      	str	r7, [sp, #16]
d0040a66:	f7ff fb5d 	bl	d0040124 <draw_panel>
d0040a6a:	f89b 700c 	ldrb.w	r7, [fp, #12]
d0040a6e:	2006      	movs	r0, #6
d0040a70:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040a74:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040a78:	ea47 2101 	orr.w	r1, r7, r1, lsl #8
d0040a7c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040a80:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040a84:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040a88:	685b      	ldr	r3, [r3, #4]
d0040a8a:	68db      	ldr	r3, [r3, #12]
d0040a8c:	4798      	blx	r3
d0040a8e:	f89b 700c 	ldrb.w	r7, [fp, #12]
d0040a92:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0040a96:	21ea      	movs	r1, #234	; 0xea
d0040a98:	f89b 000e 	ldrb.w	r0, [fp, #14]
d0040a9c:	ea47 2202 	orr.w	r2, r7, r2, lsl #8
d0040aa0:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040aa4:	ea42 4000 	orr.w	r0, r2, r0, lsl #16
d0040aa8:	4ab0      	ldr	r2, [pc, #704]	; (d0040d6c <main+0xb3c>)
d0040aaa:	ea40 6303 	orr.w	r3, r0, r3, lsl #24
d0040aae:	202a      	movs	r0, #42	; 0x2a
d0040ab0:	685b      	ldr	r3, [r3, #4]
d0040ab2:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0040ab4:	4798      	blx	r3
d0040ab6:	b2f2      	uxtb	r2, r6
d0040ab8:	9b04      	ldr	r3, [sp, #16]
d0040aba:	2006      	movs	r0, #6
d0040abc:	f89b c00c 	ldrb.w	ip, [fp, #12]
d0040ac0:	4293      	cmp	r3, r2
d0040ac2:	9203      	str	r2, [sp, #12]
d0040ac4:	f000 815c 	beq.w	d0040d80 <main+0xb50>
d0040ac8:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040acc:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040ad0:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d0040ad4:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040ad8:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040adc:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040ae0:	685b      	ldr	r3, [r3, #4]
d0040ae2:	68db      	ldr	r3, [r3, #12]
d0040ae4:	4798      	blx	r3
d0040ae6:	4621      	mov	r1, r4
d0040ae8:	464a      	mov	r2, r9
d0040aea:	202e      	movs	r0, #46	; 0x2e
d0040aec:	2e00      	cmp	r6, #0
d0040aee:	f000 8120 	beq.w	d0040d32 <main+0xb02>
d0040af2:	9b03      	ldr	r3, [sp, #12]
d0040af4:	2b01      	cmp	r3, #1
d0040af6:	f000 817b 	beq.w	d0040df0 <main+0xbc0>
d0040afa:	f89b e00c 	ldrb.w	lr, [fp, #12]
d0040afe:	f89b c00d 	ldrb.w	ip, [fp, #13]
d0040b02:	f89b 700e 	ldrb.w	r7, [fp, #14]
d0040b06:	ea4e 2c0c 	orr.w	ip, lr, ip, lsl #8
d0040b0a:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040b0e:	ea4c 4707 	orr.w	r7, ip, r7, lsl #16
d0040b12:	ea47 6303 	orr.w	r3, r7, r3, lsl #24
d0040b16:	685b      	ldr	r3, [r3, #4]
d0040b18:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0040b1a:	4798      	blx	r3
d0040b1c:	2d03      	cmp	r5, #3
d0040b1e:	f040 811b 	bne.w	d0040d58 <main+0xb28>
d0040b22:	2346      	movs	r3, #70	; 0x46
d0040b24:	226e      	movs	r2, #110	; 0x6e
d0040b26:	21de      	movs	r1, #222	; 0xde
d0040b28:	f44f 70aa 	mov.w	r0, #340	; 0x154
d0040b2c:	f7ff fafa 	bl	d0040124 <draw_panel>
d0040b30:	f89b 000c 	ldrb.w	r0, [fp, #12]
d0040b34:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040b38:	2600      	movs	r6, #0
d0040b3a:	9b05      	ldr	r3, [sp, #20]
d0040b3c:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040b40:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0040b44:	f003 070f 	and.w	r7, r3, #15
d0040b48:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040b4c:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040b50:	2008      	movs	r0, #8
d0040b52:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040b56:	685b      	ldr	r3, [r3, #4]
d0040b58:	68db      	ldr	r3, [r3, #12]
d0040b5a:	4798      	blx	r3
d0040b5c:	f89b 300c 	ldrb.w	r3, [fp, #12]
d0040b60:	b2b0      	uxth	r0, r6
d0040b62:	f89b 200d 	ldrb.w	r2, [fp, #13]
d0040b66:	f346 014e 	sbfx	r1, r6, #1, #15
d0040b6a:	f89b 500e 	ldrb.w	r5, [fp, #14]
d0040b6e:	3601      	adds	r6, #1
d0040b70:	ea43 2202 	orr.w	r2, r3, r2, lsl #8
d0040b74:	f89b 400f 	ldrb.w	r4, [fp, #15]
d0040b78:	f100 030a 	add.w	r3, r0, #10
d0040b7c:	f500 70b8 	add.w	r0, r0, #368	; 0x170
d0040b80:	ea42 4505 	orr.w	r5, r2, r5, lsl #16
d0040b84:	f1c1 01f4 	rsb	r1, r1, #244	; 0xf4
d0040b88:	b21b      	sxth	r3, r3
d0040b8a:	2201      	movs	r2, #1
d0040b8c:	ea45 6404 	orr.w	r4, r5, r4, lsl #24
d0040b90:	b200      	sxth	r0, r0
d0040b92:	6864      	ldr	r4, [r4, #4]
d0040b94:	6864      	ldr	r4, [r4, #4]
d0040b96:	47a0      	blx	r4
d0040b98:	2e12      	cmp	r6, #18
d0040b9a:	d1df      	bne.n	d0040b5c <main+0x92c>
d0040b9c:	f89b 400c 	ldrb.w	r4, [fp, #12]
d0040ba0:	2009      	movs	r0, #9
d0040ba2:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040ba6:	f10a 0a01 	add.w	sl, sl, #1
d0040baa:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040bae:	ea44 2101 	orr.w	r1, r4, r1, lsl #8
d0040bb2:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040bb6:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040bba:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040bbe:	685b      	ldr	r3, [r3, #4]
d0040bc0:	68db      	ldr	r3, [r3, #12]
d0040bc2:	4798      	blx	r3
d0040bc4:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0040bc8:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0040bcc:	231e      	movs	r3, #30
d0040bce:	f89b 500e 	ldrb.w	r5, [fp, #14]
d0040bd2:	2205      	movs	r2, #5
d0040bd4:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d0040bd8:	f89b 400f 	ldrb.w	r4, [fp, #15]
d0040bdc:	21ef      	movs	r1, #239	; 0xef
d0040bde:	ea40 4505 	orr.w	r5, r0, r5, lsl #16
d0040be2:	f44f 70c7 	mov.w	r0, #398	; 0x18e
d0040be6:	ea45 6404 	orr.w	r4, r5, r4, lsl #24
d0040bea:	6864      	ldr	r4, [r4, #4]
d0040bec:	6864      	ldr	r4, [r4, #4]
d0040bee:	47a0      	blx	r4
d0040bf0:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0040bf4:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0040bf8:	231e      	movs	r3, #30
d0040bfa:	f89b 500e 	ldrb.w	r5, [fp, #14]
d0040bfe:	2205      	movs	r2, #5
d0040c00:	ea41 2000 	orr.w	r0, r1, r0, lsl #8
d0040c04:	f89b 400f 	ldrb.w	r4, [fp, #15]
d0040c08:	21ef      	movs	r1, #239	; 0xef
d0040c0a:	ea40 4505 	orr.w	r5, r0, r5, lsl #16
d0040c0e:	f44f 70cc 	mov.w	r0, #408	; 0x198
d0040c12:	ea45 6404 	orr.w	r4, r5, r4, lsl #24
d0040c16:	6864      	ldr	r4, [r4, #4]
d0040c18:	6864      	ldr	r4, [r4, #4]
d0040c1a:	47a0      	blx	r4
d0040c1c:	f89b 400c 	ldrb.w	r4, [fp, #12]
d0040c20:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040c24:	2007      	movs	r0, #7
d0040c26:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040c2a:	ea44 2101 	orr.w	r1, r4, r1, lsl #8
d0040c2e:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040c32:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040c36:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040c3a:	685b      	ldr	r3, [r3, #4]
d0040c3c:	68db      	ldr	r3, [r3, #12]
d0040c3e:	4798      	blx	r3
d0040c40:	f89b 100c 	ldrb.w	r1, [fp, #12]
d0040c44:	f89b 400d 	ldrb.w	r4, [fp, #13]
d0040c48:	f107 0246 	add.w	r2, r7, #70	; 0x46
d0040c4c:	f89b 500e 	ldrb.w	r5, [fp, #14]
d0040c50:	2303      	movs	r3, #3
d0040c52:	ea41 2704 	orr.w	r7, r1, r4, lsl #8
d0040c56:	f89b 400f 	ldrb.w	r4, [fp, #15]
d0040c5a:	f240 1115 	movw	r1, #277	; 0x115
d0040c5e:	f44f 70b4 	mov.w	r0, #360	; 0x168
d0040c62:	ea47 4505 	orr.w	r5, r7, r5, lsl #16
d0040c66:	ea45 6404 	orr.w	r4, r5, r4, lsl #24
d0040c6a:	6864      	ldr	r4, [r4, #4]
d0040c6c:	6864      	ldr	r4, [r4, #4]
d0040c6e:	47a0      	blx	r4
d0040c70:	f89b 400c 	ldrb.w	r4, [fp, #12]
d0040c74:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040c78:	2006      	movs	r0, #6
d0040c7a:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040c7e:	ea44 2101 	orr.w	r1, r4, r1, lsl #8
d0040c82:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040c86:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040c8a:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040c8e:	685b      	ldr	r3, [r3, #4]
d0040c90:	68db      	ldr	r3, [r3, #12]
d0040c92:	4798      	blx	r3
d0040c94:	f89b 200c 	ldrb.w	r2, [fp, #12]
d0040c98:	f89b 500d 	ldrb.w	r5, [fp, #13]
d0040c9c:	21e4      	movs	r1, #228	; 0xe4
d0040c9e:	f89b 400e 	ldrb.w	r4, [fp, #14]
d0040ca2:	f44f 70b3 	mov.w	r0, #358	; 0x166
d0040ca6:	ea42 2505 	orr.w	r5, r2, r5, lsl #8
d0040caa:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040cae:	4a30      	ldr	r2, [pc, #192]	; (d0040d70 <main+0xb40>)
d0040cb0:	ea45 4404 	orr.w	r4, r5, r4, lsl #16
d0040cb4:	ea44 6303 	orr.w	r3, r4, r3, lsl #24
d0040cb8:	685b      	ldr	r3, [r3, #4]
d0040cba:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0040cbc:	4798      	blx	r3
d0040cbe:	f89b 400c 	ldrb.w	r4, [fp, #12]
d0040cc2:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040cc6:	2006      	movs	r0, #6
d0040cc8:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040ccc:	ea44 2101 	orr.w	r1, r4, r1, lsl #8
d0040cd0:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040cd4:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040cd8:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040cdc:	685b      	ldr	r3, [r3, #4]
d0040cde:	68db      	ldr	r3, [r3, #12]
d0040ce0:	4798      	blx	r3
d0040ce2:	f89b 200c 	ldrb.w	r2, [fp, #12]
d0040ce6:	f89b 500d 	ldrb.w	r5, [fp, #13]
d0040cea:	4630      	mov	r0, r6
d0040cec:	f89b 400e 	ldrb.w	r4, [fp, #14]
d0040cf0:	f44f 7198 	mov.w	r1, #304	; 0x130
d0040cf4:	ea42 2505 	orr.w	r5, r2, r5, lsl #8
d0040cf8:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040cfc:	4a1d      	ldr	r2, [pc, #116]	; (d0040d74 <main+0xb44>)
d0040cfe:	ea45 4404 	orr.w	r4, r5, r4, lsl #16
d0040d02:	ea44 6303 	orr.w	r3, r4, r3, lsl #24
d0040d06:	685b      	ldr	r3, [r3, #4]
d0040d08:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0040d0a:	4798      	blx	r3
d0040d0c:	f89b 000c 	ldrb.w	r0, [fp, #12]
d0040d10:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040d14:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040d18:	ea40 2101 	orr.w	r1, r0, r1, lsl #8
d0040d1c:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040d20:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040d24:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040d28:	681b      	ldr	r3, [r3, #0]
d0040d2a:	681b      	ldr	r3, [r3, #0]
d0040d2c:	4798      	blx	r3
d0040d2e:	f7ff bb9b 	b.w	d0040468 <main+0x238>
d0040d32:	f89b c00c 	ldrb.w	ip, [fp, #12]
d0040d36:	4642      	mov	r2, r8
d0040d38:	f89b 700d 	ldrb.w	r7, [fp, #13]
d0040d3c:	f89b 300e 	ldrb.w	r3, [fp, #14]
d0040d40:	ea4c 2007 	orr.w	r0, ip, r7, lsl #8
d0040d44:	f89b c00f 	ldrb.w	ip, [fp, #15]
d0040d48:	ea40 4703 	orr.w	r7, r0, r3, lsl #16
d0040d4c:	202e      	movs	r0, #46	; 0x2e
d0040d4e:	ea47 630c 	orr.w	r3, r7, ip, lsl #24
d0040d52:	685b      	ldr	r3, [r3, #4]
d0040d54:	6adb      	ldr	r3, [r3, #44]	; 0x2c
d0040d56:	4798      	blx	r3
d0040d58:	3501      	adds	r5, #1
d0040d5a:	3601      	adds	r6, #1
d0040d5c:	340d      	adds	r4, #13
d0040d5e:	b2ed      	uxtb	r5, r5
d0040d60:	e6a9      	b.n	d0040ab6 <main+0x886>
d0040d62:	bf00      	nop
d0040d64:	19c2d14f 	.word	0x19c2d14f
d0040d68:	aaaaaaab 	.word	0xaaaaaaab
d0040d6c:	d004197c 	.word	0xd004197c
d0040d70:	d00419d8 	.word	0xd00419d8
d0040d74:	d00419e4 	.word	0xd00419e4
d0040d78:	d00419c4 	.word	0xd00419c4
d0040d7c:	d0041998 	.word	0xd0041998
d0040d80:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040d84:	200b      	movs	r0, #11
d0040d86:	f89b 200e 	ldrb.w	r2, [fp, #14]
d0040d8a:	ea4c 2101 	orr.w	r1, ip, r1, lsl #8
d0040d8e:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040d92:	ea41 4202 	orr.w	r2, r1, r2, lsl #16
d0040d96:	ea42 6303 	orr.w	r3, r2, r3, lsl #24
d0040d9a:	685b      	ldr	r3, [r3, #4]
d0040d9c:	68db      	ldr	r3, [r3, #12]
d0040d9e:	4798      	blx	r3
d0040da0:	f89b 200c 	ldrb.w	r2, [fp, #12]
d0040da4:	f89b 000d 	ldrb.w	r0, [fp, #13]
d0040da8:	1ea1      	subs	r1, r4, #2
d0040daa:	f89b e00e 	ldrb.w	lr, [fp, #14]
d0040dae:	230b      	movs	r3, #11
d0040db0:	ea42 2000 	orr.w	r0, r2, r0, lsl #8
d0040db4:	f89b c00f 	ldrb.w	ip, [fp, #15]
d0040db8:	b209      	sxth	r1, r1
d0040dba:	f44f 7287 	mov.w	r2, #270	; 0x10e
d0040dbe:	ea40 4e0e 	orr.w	lr, r0, lr, lsl #16
d0040dc2:	2027      	movs	r0, #39	; 0x27
d0040dc4:	ea4e 6c0c 	orr.w	ip, lr, ip, lsl #24
d0040dc8:	f8dc c004 	ldr.w	ip, [ip, #4]
d0040dcc:	f8dc 7004 	ldr.w	r7, [ip, #4]
d0040dd0:	47b8      	blx	r7
d0040dd2:	f89b c00c 	ldrb.w	ip, [fp, #12]
d0040dd6:	200d      	movs	r0, #13
d0040dd8:	f89b 100d 	ldrb.w	r1, [fp, #13]
d0040ddc:	e676      	b.n	d0040acc <main+0x89c>
d0040dde:	4907      	ldr	r1, [pc, #28]	; (d0040dfc <main+0xbcc>)
d0040de0:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
d0040de4:	f89b 300f 	ldrb.w	r3, [fp, #15]
d0040de8:	6809      	ldr	r1, [r1, #0]
d0040dea:	4805      	ldr	r0, [pc, #20]	; (d0040e00 <main+0xbd0>)
d0040dec:	f7ff bb65 	b.w	d00404ba <main+0x28a>
d0040df0:	f89b c00c 	ldrb.w	ip, [fp, #12]
d0040df4:	4a03      	ldr	r2, [pc, #12]	; (d0040e04 <main+0xbd4>)
d0040df6:	f89b 700d 	ldrb.w	r7, [fp, #13]
d0040dfa:	e79f      	b.n	d0040d3c <main+0xb0c>
d0040dfc:	d0041b0c 	.word	0xd0041b0c
d0040e00:	d0041b10 	.word	0xd0041b10
d0040e04:	d00419ac 	.word	0xd00419ac

d0040e08 <__errno>:
d0040e08:	4b01      	ldr	r3, [pc, #4]	; (d0040e10 <__errno+0x8>)
d0040e0a:	6818      	ldr	r0, [r3, #0]
d0040e0c:	4770      	bx	lr
d0040e0e:	bf00      	nop
d0040e10:	d0041a80 	.word	0xd0041a80

d0040e14 <memset>:
d0040e14:	4402      	add	r2, r0
d0040e16:	4603      	mov	r3, r0
d0040e18:	4293      	cmp	r3, r2
d0040e1a:	d100      	bne.n	d0040e1e <memset+0xa>
d0040e1c:	4770      	bx	lr
d0040e1e:	f803 1b01 	strb.w	r1, [r3], #1
d0040e22:	e7f9      	b.n	d0040e18 <memset+0x4>

d0040e24 <_puts_r>:
d0040e24:	b570      	push	{r4, r5, r6, lr}
d0040e26:	460e      	mov	r6, r1
d0040e28:	4605      	mov	r5, r0
d0040e2a:	b118      	cbz	r0, d0040e34 <_puts_r+0x10>
d0040e2c:	6983      	ldr	r3, [r0, #24]
d0040e2e:	b90b      	cbnz	r3, d0040e34 <_puts_r+0x10>
d0040e30:	f000 fb16 	bl	d0041460 <__sinit>
d0040e34:	69ab      	ldr	r3, [r5, #24]
d0040e36:	68ac      	ldr	r4, [r5, #8]
d0040e38:	b913      	cbnz	r3, d0040e40 <_puts_r+0x1c>
d0040e3a:	4628      	mov	r0, r5
d0040e3c:	f000 fb10 	bl	d0041460 <__sinit>
d0040e40:	4b2c      	ldr	r3, [pc, #176]	; (d0040ef4 <_puts_r+0xd0>)
d0040e42:	429c      	cmp	r4, r3
d0040e44:	d120      	bne.n	d0040e88 <_puts_r+0x64>
d0040e46:	686c      	ldr	r4, [r5, #4]
d0040e48:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0040e4a:	07db      	lsls	r3, r3, #31
d0040e4c:	d405      	bmi.n	d0040e5a <_puts_r+0x36>
d0040e4e:	89a3      	ldrh	r3, [r4, #12]
d0040e50:	0598      	lsls	r0, r3, #22
d0040e52:	d402      	bmi.n	d0040e5a <_puts_r+0x36>
d0040e54:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0040e56:	f000 fba1 	bl	d004159c <__retarget_lock_acquire_recursive>
d0040e5a:	89a3      	ldrh	r3, [r4, #12]
d0040e5c:	0719      	lsls	r1, r3, #28
d0040e5e:	d51d      	bpl.n	d0040e9c <_puts_r+0x78>
d0040e60:	6923      	ldr	r3, [r4, #16]
d0040e62:	b1db      	cbz	r3, d0040e9c <_puts_r+0x78>
d0040e64:	3e01      	subs	r6, #1
d0040e66:	68a3      	ldr	r3, [r4, #8]
d0040e68:	f816 1f01 	ldrb.w	r1, [r6, #1]!
d0040e6c:	3b01      	subs	r3, #1
d0040e6e:	60a3      	str	r3, [r4, #8]
d0040e70:	bb39      	cbnz	r1, d0040ec2 <_puts_r+0x9e>
d0040e72:	2b00      	cmp	r3, #0
d0040e74:	da38      	bge.n	d0040ee8 <_puts_r+0xc4>
d0040e76:	4622      	mov	r2, r4
d0040e78:	210a      	movs	r1, #10
d0040e7a:	4628      	mov	r0, r5
d0040e7c:	f000 f916 	bl	d00410ac <__swbuf_r>
d0040e80:	3001      	adds	r0, #1
d0040e82:	d011      	beq.n	d0040ea8 <_puts_r+0x84>
d0040e84:	250a      	movs	r5, #10
d0040e86:	e011      	b.n	d0040eac <_puts_r+0x88>
d0040e88:	4b1b      	ldr	r3, [pc, #108]	; (d0040ef8 <_puts_r+0xd4>)
d0040e8a:	429c      	cmp	r4, r3
d0040e8c:	d101      	bne.n	d0040e92 <_puts_r+0x6e>
d0040e8e:	68ac      	ldr	r4, [r5, #8]
d0040e90:	e7da      	b.n	d0040e48 <_puts_r+0x24>
d0040e92:	4b1a      	ldr	r3, [pc, #104]	; (d0040efc <_puts_r+0xd8>)
d0040e94:	429c      	cmp	r4, r3
d0040e96:	bf08      	it	eq
d0040e98:	68ec      	ldreq	r4, [r5, #12]
d0040e9a:	e7d5      	b.n	d0040e48 <_puts_r+0x24>
d0040e9c:	4621      	mov	r1, r4
d0040e9e:	4628      	mov	r0, r5
d0040ea0:	f000 f956 	bl	d0041150 <__swsetup_r>
d0040ea4:	2800      	cmp	r0, #0
d0040ea6:	d0dd      	beq.n	d0040e64 <_puts_r+0x40>
d0040ea8:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0040eac:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0040eae:	07da      	lsls	r2, r3, #31
d0040eb0:	d405      	bmi.n	d0040ebe <_puts_r+0x9a>
d0040eb2:	89a3      	ldrh	r3, [r4, #12]
d0040eb4:	059b      	lsls	r3, r3, #22
d0040eb6:	d402      	bmi.n	d0040ebe <_puts_r+0x9a>
d0040eb8:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0040eba:	f000 fb70 	bl	d004159e <__retarget_lock_release_recursive>
d0040ebe:	4628      	mov	r0, r5
d0040ec0:	bd70      	pop	{r4, r5, r6, pc}
d0040ec2:	2b00      	cmp	r3, #0
d0040ec4:	da04      	bge.n	d0040ed0 <_puts_r+0xac>
d0040ec6:	69a2      	ldr	r2, [r4, #24]
d0040ec8:	429a      	cmp	r2, r3
d0040eca:	dc06      	bgt.n	d0040eda <_puts_r+0xb6>
d0040ecc:	290a      	cmp	r1, #10
d0040ece:	d004      	beq.n	d0040eda <_puts_r+0xb6>
d0040ed0:	6823      	ldr	r3, [r4, #0]
d0040ed2:	1c5a      	adds	r2, r3, #1
d0040ed4:	6022      	str	r2, [r4, #0]
d0040ed6:	7019      	strb	r1, [r3, #0]
d0040ed8:	e7c5      	b.n	d0040e66 <_puts_r+0x42>
d0040eda:	4622      	mov	r2, r4
d0040edc:	4628      	mov	r0, r5
d0040ede:	f000 f8e5 	bl	d00410ac <__swbuf_r>
d0040ee2:	3001      	adds	r0, #1
d0040ee4:	d1bf      	bne.n	d0040e66 <_puts_r+0x42>
d0040ee6:	e7df      	b.n	d0040ea8 <_puts_r+0x84>
d0040ee8:	6823      	ldr	r3, [r4, #0]
d0040eea:	250a      	movs	r5, #10
d0040eec:	1c5a      	adds	r2, r3, #1
d0040eee:	6022      	str	r2, [r4, #0]
d0040ef0:	701d      	strb	r5, [r3, #0]
d0040ef2:	e7db      	b.n	d0040eac <_puts_r+0x88>
d0040ef4:	d0041a38 	.word	0xd0041a38
d0040ef8:	d0041a58 	.word	0xd0041a58
d0040efc:	d0041a18 	.word	0xd0041a18

d0040f00 <puts>:
d0040f00:	4b02      	ldr	r3, [pc, #8]	; (d0040f0c <puts+0xc>)
d0040f02:	4601      	mov	r1, r0
d0040f04:	6818      	ldr	r0, [r3, #0]
d0040f06:	f7ff bf8d 	b.w	d0040e24 <_puts_r>
d0040f0a:	bf00      	nop
d0040f0c:	d0041a80 	.word	0xd0041a80

d0040f10 <setbuf>:
d0040f10:	2900      	cmp	r1, #0
d0040f12:	f44f 6380 	mov.w	r3, #1024	; 0x400
d0040f16:	bf0c      	ite	eq
d0040f18:	2202      	moveq	r2, #2
d0040f1a:	2200      	movne	r2, #0
d0040f1c:	f000 b800 	b.w	d0040f20 <setvbuf>

d0040f20 <setvbuf>:
d0040f20:	e92d 43f7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, lr}
d0040f24:	461d      	mov	r5, r3
d0040f26:	4b5d      	ldr	r3, [pc, #372]	; (d004109c <setvbuf+0x17c>)
d0040f28:	681f      	ldr	r7, [r3, #0]
d0040f2a:	4604      	mov	r4, r0
d0040f2c:	460e      	mov	r6, r1
d0040f2e:	4690      	mov	r8, r2
d0040f30:	b127      	cbz	r7, d0040f3c <setvbuf+0x1c>
d0040f32:	69bb      	ldr	r3, [r7, #24]
d0040f34:	b913      	cbnz	r3, d0040f3c <setvbuf+0x1c>
d0040f36:	4638      	mov	r0, r7
d0040f38:	f000 fa92 	bl	d0041460 <__sinit>
d0040f3c:	4b58      	ldr	r3, [pc, #352]	; (d00410a0 <setvbuf+0x180>)
d0040f3e:	429c      	cmp	r4, r3
d0040f40:	d167      	bne.n	d0041012 <setvbuf+0xf2>
d0040f42:	687c      	ldr	r4, [r7, #4]
d0040f44:	f1b8 0f02 	cmp.w	r8, #2
d0040f48:	d006      	beq.n	d0040f58 <setvbuf+0x38>
d0040f4a:	f1b8 0f01 	cmp.w	r8, #1
d0040f4e:	f200 809f 	bhi.w	d0041090 <setvbuf+0x170>
d0040f52:	2d00      	cmp	r5, #0
d0040f54:	f2c0 809c 	blt.w	d0041090 <setvbuf+0x170>
d0040f58:	6e63      	ldr	r3, [r4, #100]	; 0x64
d0040f5a:	07db      	lsls	r3, r3, #31
d0040f5c:	d405      	bmi.n	d0040f6a <setvbuf+0x4a>
d0040f5e:	89a3      	ldrh	r3, [r4, #12]
d0040f60:	0598      	lsls	r0, r3, #22
d0040f62:	d402      	bmi.n	d0040f6a <setvbuf+0x4a>
d0040f64:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0040f66:	f000 fb19 	bl	d004159c <__retarget_lock_acquire_recursive>
d0040f6a:	4621      	mov	r1, r4
d0040f6c:	4638      	mov	r0, r7
d0040f6e:	f000 f9e3 	bl	d0041338 <_fflush_r>
d0040f72:	6b61      	ldr	r1, [r4, #52]	; 0x34
d0040f74:	b141      	cbz	r1, d0040f88 <setvbuf+0x68>
d0040f76:	f104 0344 	add.w	r3, r4, #68	; 0x44
d0040f7a:	4299      	cmp	r1, r3
d0040f7c:	d002      	beq.n	d0040f84 <setvbuf+0x64>
d0040f7e:	4638      	mov	r0, r7
d0040f80:	f000 fb7a 	bl	d0041678 <_free_r>
d0040f84:	2300      	movs	r3, #0
d0040f86:	6363      	str	r3, [r4, #52]	; 0x34
d0040f88:	2300      	movs	r3, #0
d0040f8a:	61a3      	str	r3, [r4, #24]
d0040f8c:	6063      	str	r3, [r4, #4]
d0040f8e:	89a3      	ldrh	r3, [r4, #12]
d0040f90:	0619      	lsls	r1, r3, #24
d0040f92:	d503      	bpl.n	d0040f9c <setvbuf+0x7c>
d0040f94:	6921      	ldr	r1, [r4, #16]
d0040f96:	4638      	mov	r0, r7
d0040f98:	f000 fb6e 	bl	d0041678 <_free_r>
d0040f9c:	89a3      	ldrh	r3, [r4, #12]
d0040f9e:	f423 634a 	bic.w	r3, r3, #3232	; 0xca0
d0040fa2:	f023 0303 	bic.w	r3, r3, #3
d0040fa6:	f1b8 0f02 	cmp.w	r8, #2
d0040faa:	81a3      	strh	r3, [r4, #12]
d0040fac:	d06c      	beq.n	d0041088 <setvbuf+0x168>
d0040fae:	ab01      	add	r3, sp, #4
d0040fb0:	466a      	mov	r2, sp
d0040fb2:	4621      	mov	r1, r4
d0040fb4:	4638      	mov	r0, r7
d0040fb6:	f000 faf3 	bl	d00415a0 <__swhatbuf_r>
d0040fba:	89a3      	ldrh	r3, [r4, #12]
d0040fbc:	4318      	orrs	r0, r3
d0040fbe:	81a0      	strh	r0, [r4, #12]
d0040fc0:	2d00      	cmp	r5, #0
d0040fc2:	d130      	bne.n	d0041026 <setvbuf+0x106>
d0040fc4:	9d00      	ldr	r5, [sp, #0]
d0040fc6:	4628      	mov	r0, r5
d0040fc8:	f000 fb4e 	bl	d0041668 <malloc>
d0040fcc:	4606      	mov	r6, r0
d0040fce:	2800      	cmp	r0, #0
d0040fd0:	d155      	bne.n	d004107e <setvbuf+0x15e>
d0040fd2:	f8dd 9000 	ldr.w	r9, [sp]
d0040fd6:	45a9      	cmp	r9, r5
d0040fd8:	d14a      	bne.n	d0041070 <setvbuf+0x150>
d0040fda:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0040fde:	2200      	movs	r2, #0
d0040fe0:	60a2      	str	r2, [r4, #8]
d0040fe2:	f104 0247 	add.w	r2, r4, #71	; 0x47
d0040fe6:	6022      	str	r2, [r4, #0]
d0040fe8:	6122      	str	r2, [r4, #16]
d0040fea:	2201      	movs	r2, #1
d0040fec:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d0040ff0:	6162      	str	r2, [r4, #20]
d0040ff2:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0040ff4:	f043 0302 	orr.w	r3, r3, #2
d0040ff8:	07d2      	lsls	r2, r2, #31
d0040ffa:	81a3      	strh	r3, [r4, #12]
d0040ffc:	d405      	bmi.n	d004100a <setvbuf+0xea>
d0040ffe:	f413 7f00 	tst.w	r3, #512	; 0x200
d0041002:	d102      	bne.n	d004100a <setvbuf+0xea>
d0041004:	6da0      	ldr	r0, [r4, #88]	; 0x58
d0041006:	f000 faca 	bl	d004159e <__retarget_lock_release_recursive>
d004100a:	4628      	mov	r0, r5
d004100c:	b003      	add	sp, #12
d004100e:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
d0041012:	4b24      	ldr	r3, [pc, #144]	; (d00410a4 <setvbuf+0x184>)
d0041014:	429c      	cmp	r4, r3
d0041016:	d101      	bne.n	d004101c <setvbuf+0xfc>
d0041018:	68bc      	ldr	r4, [r7, #8]
d004101a:	e793      	b.n	d0040f44 <setvbuf+0x24>
d004101c:	4b22      	ldr	r3, [pc, #136]	; (d00410a8 <setvbuf+0x188>)
d004101e:	429c      	cmp	r4, r3
d0041020:	bf08      	it	eq
d0041022:	68fc      	ldreq	r4, [r7, #12]
d0041024:	e78e      	b.n	d0040f44 <setvbuf+0x24>
d0041026:	2e00      	cmp	r6, #0
d0041028:	d0cd      	beq.n	d0040fc6 <setvbuf+0xa6>
d004102a:	69bb      	ldr	r3, [r7, #24]
d004102c:	b913      	cbnz	r3, d0041034 <setvbuf+0x114>
d004102e:	4638      	mov	r0, r7
d0041030:	f000 fa16 	bl	d0041460 <__sinit>
d0041034:	f1b8 0f01 	cmp.w	r8, #1
d0041038:	bf08      	it	eq
d004103a:	89a3      	ldrheq	r3, [r4, #12]
d004103c:	6026      	str	r6, [r4, #0]
d004103e:	bf04      	itt	eq
d0041040:	f043 0301 	orreq.w	r3, r3, #1
d0041044:	81a3      	strheq	r3, [r4, #12]
d0041046:	89a2      	ldrh	r2, [r4, #12]
d0041048:	f012 0308 	ands.w	r3, r2, #8
d004104c:	e9c4 6504 	strd	r6, r5, [r4, #16]
d0041050:	d01c      	beq.n	d004108c <setvbuf+0x16c>
d0041052:	07d3      	lsls	r3, r2, #31
d0041054:	bf41      	itttt	mi
d0041056:	2300      	movmi	r3, #0
d0041058:	426d      	negmi	r5, r5
d004105a:	60a3      	strmi	r3, [r4, #8]
d004105c:	61a5      	strmi	r5, [r4, #24]
d004105e:	bf58      	it	pl
d0041060:	60a5      	strpl	r5, [r4, #8]
d0041062:	6e65      	ldr	r5, [r4, #100]	; 0x64
d0041064:	f015 0501 	ands.w	r5, r5, #1
d0041068:	d115      	bne.n	d0041096 <setvbuf+0x176>
d004106a:	f412 7f00 	tst.w	r2, #512	; 0x200
d004106e:	e7c8      	b.n	d0041002 <setvbuf+0xe2>
d0041070:	4648      	mov	r0, r9
d0041072:	f000 faf9 	bl	d0041668 <malloc>
d0041076:	4606      	mov	r6, r0
d0041078:	2800      	cmp	r0, #0
d004107a:	d0ae      	beq.n	d0040fda <setvbuf+0xba>
d004107c:	464d      	mov	r5, r9
d004107e:	89a3      	ldrh	r3, [r4, #12]
d0041080:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0041084:	81a3      	strh	r3, [r4, #12]
d0041086:	e7d0      	b.n	d004102a <setvbuf+0x10a>
d0041088:	2500      	movs	r5, #0
d004108a:	e7a8      	b.n	d0040fde <setvbuf+0xbe>
d004108c:	60a3      	str	r3, [r4, #8]
d004108e:	e7e8      	b.n	d0041062 <setvbuf+0x142>
d0041090:	f04f 35ff 	mov.w	r5, #4294967295	; 0xffffffff
d0041094:	e7b9      	b.n	d004100a <setvbuf+0xea>
d0041096:	2500      	movs	r5, #0
d0041098:	e7b7      	b.n	d004100a <setvbuf+0xea>
d004109a:	bf00      	nop
d004109c:	d0041a80 	.word	0xd0041a80
d00410a0:	d0041a38 	.word	0xd0041a38
d00410a4:	d0041a58 	.word	0xd0041a58
d00410a8:	d0041a18 	.word	0xd0041a18

d00410ac <__swbuf_r>:
d00410ac:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00410ae:	460e      	mov	r6, r1
d00410b0:	4614      	mov	r4, r2
d00410b2:	4605      	mov	r5, r0
d00410b4:	b118      	cbz	r0, d00410be <__swbuf_r+0x12>
d00410b6:	6983      	ldr	r3, [r0, #24]
d00410b8:	b90b      	cbnz	r3, d00410be <__swbuf_r+0x12>
d00410ba:	f000 f9d1 	bl	d0041460 <__sinit>
d00410be:	4b21      	ldr	r3, [pc, #132]	; (d0041144 <__swbuf_r+0x98>)
d00410c0:	429c      	cmp	r4, r3
d00410c2:	d12b      	bne.n	d004111c <__swbuf_r+0x70>
d00410c4:	686c      	ldr	r4, [r5, #4]
d00410c6:	69a3      	ldr	r3, [r4, #24]
d00410c8:	60a3      	str	r3, [r4, #8]
d00410ca:	89a3      	ldrh	r3, [r4, #12]
d00410cc:	071a      	lsls	r2, r3, #28
d00410ce:	d52f      	bpl.n	d0041130 <__swbuf_r+0x84>
d00410d0:	6923      	ldr	r3, [r4, #16]
d00410d2:	b36b      	cbz	r3, d0041130 <__swbuf_r+0x84>
d00410d4:	6923      	ldr	r3, [r4, #16]
d00410d6:	6820      	ldr	r0, [r4, #0]
d00410d8:	1ac0      	subs	r0, r0, r3
d00410da:	6963      	ldr	r3, [r4, #20]
d00410dc:	b2f6      	uxtb	r6, r6
d00410de:	4283      	cmp	r3, r0
d00410e0:	4637      	mov	r7, r6
d00410e2:	dc04      	bgt.n	d00410ee <__swbuf_r+0x42>
d00410e4:	4621      	mov	r1, r4
d00410e6:	4628      	mov	r0, r5
d00410e8:	f000 f926 	bl	d0041338 <_fflush_r>
d00410ec:	bb30      	cbnz	r0, d004113c <__swbuf_r+0x90>
d00410ee:	68a3      	ldr	r3, [r4, #8]
d00410f0:	3b01      	subs	r3, #1
d00410f2:	60a3      	str	r3, [r4, #8]
d00410f4:	6823      	ldr	r3, [r4, #0]
d00410f6:	1c5a      	adds	r2, r3, #1
d00410f8:	6022      	str	r2, [r4, #0]
d00410fa:	701e      	strb	r6, [r3, #0]
d00410fc:	6963      	ldr	r3, [r4, #20]
d00410fe:	3001      	adds	r0, #1
d0041100:	4283      	cmp	r3, r0
d0041102:	d004      	beq.n	d004110e <__swbuf_r+0x62>
d0041104:	89a3      	ldrh	r3, [r4, #12]
d0041106:	07db      	lsls	r3, r3, #31
d0041108:	d506      	bpl.n	d0041118 <__swbuf_r+0x6c>
d004110a:	2e0a      	cmp	r6, #10
d004110c:	d104      	bne.n	d0041118 <__swbuf_r+0x6c>
d004110e:	4621      	mov	r1, r4
d0041110:	4628      	mov	r0, r5
d0041112:	f000 f911 	bl	d0041338 <_fflush_r>
d0041116:	b988      	cbnz	r0, d004113c <__swbuf_r+0x90>
d0041118:	4638      	mov	r0, r7
d004111a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d004111c:	4b0a      	ldr	r3, [pc, #40]	; (d0041148 <__swbuf_r+0x9c>)
d004111e:	429c      	cmp	r4, r3
d0041120:	d101      	bne.n	d0041126 <__swbuf_r+0x7a>
d0041122:	68ac      	ldr	r4, [r5, #8]
d0041124:	e7cf      	b.n	d00410c6 <__swbuf_r+0x1a>
d0041126:	4b09      	ldr	r3, [pc, #36]	; (d004114c <__swbuf_r+0xa0>)
d0041128:	429c      	cmp	r4, r3
d004112a:	bf08      	it	eq
d004112c:	68ec      	ldreq	r4, [r5, #12]
d004112e:	e7ca      	b.n	d00410c6 <__swbuf_r+0x1a>
d0041130:	4621      	mov	r1, r4
d0041132:	4628      	mov	r0, r5
d0041134:	f000 f80c 	bl	d0041150 <__swsetup_r>
d0041138:	2800      	cmp	r0, #0
d004113a:	d0cb      	beq.n	d00410d4 <__swbuf_r+0x28>
d004113c:	f04f 37ff 	mov.w	r7, #4294967295	; 0xffffffff
d0041140:	e7ea      	b.n	d0041118 <__swbuf_r+0x6c>
d0041142:	bf00      	nop
d0041144:	d0041a38 	.word	0xd0041a38
d0041148:	d0041a58 	.word	0xd0041a58
d004114c:	d0041a18 	.word	0xd0041a18

d0041150 <__swsetup_r>:
d0041150:	4b32      	ldr	r3, [pc, #200]	; (d004121c <__swsetup_r+0xcc>)
d0041152:	b570      	push	{r4, r5, r6, lr}
d0041154:	681d      	ldr	r5, [r3, #0]
d0041156:	4606      	mov	r6, r0
d0041158:	460c      	mov	r4, r1
d004115a:	b125      	cbz	r5, d0041166 <__swsetup_r+0x16>
d004115c:	69ab      	ldr	r3, [r5, #24]
d004115e:	b913      	cbnz	r3, d0041166 <__swsetup_r+0x16>
d0041160:	4628      	mov	r0, r5
d0041162:	f000 f97d 	bl	d0041460 <__sinit>
d0041166:	4b2e      	ldr	r3, [pc, #184]	; (d0041220 <__swsetup_r+0xd0>)
d0041168:	429c      	cmp	r4, r3
d004116a:	d10f      	bne.n	d004118c <__swsetup_r+0x3c>
d004116c:	686c      	ldr	r4, [r5, #4]
d004116e:	89a3      	ldrh	r3, [r4, #12]
d0041170:	f9b4 200c 	ldrsh.w	r2, [r4, #12]
d0041174:	0719      	lsls	r1, r3, #28
d0041176:	d42c      	bmi.n	d00411d2 <__swsetup_r+0x82>
d0041178:	06dd      	lsls	r5, r3, #27
d004117a:	d411      	bmi.n	d00411a0 <__swsetup_r+0x50>
d004117c:	2309      	movs	r3, #9
d004117e:	6033      	str	r3, [r6, #0]
d0041180:	f042 0340 	orr.w	r3, r2, #64	; 0x40
d0041184:	81a3      	strh	r3, [r4, #12]
d0041186:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d004118a:	e03e      	b.n	d004120a <__swsetup_r+0xba>
d004118c:	4b25      	ldr	r3, [pc, #148]	; (d0041224 <__swsetup_r+0xd4>)
d004118e:	429c      	cmp	r4, r3
d0041190:	d101      	bne.n	d0041196 <__swsetup_r+0x46>
d0041192:	68ac      	ldr	r4, [r5, #8]
d0041194:	e7eb      	b.n	d004116e <__swsetup_r+0x1e>
d0041196:	4b24      	ldr	r3, [pc, #144]	; (d0041228 <__swsetup_r+0xd8>)
d0041198:	429c      	cmp	r4, r3
d004119a:	bf08      	it	eq
d004119c:	68ec      	ldreq	r4, [r5, #12]
d004119e:	e7e6      	b.n	d004116e <__swsetup_r+0x1e>
d00411a0:	0758      	lsls	r0, r3, #29
d00411a2:	d512      	bpl.n	d00411ca <__swsetup_r+0x7a>
d00411a4:	6b61      	ldr	r1, [r4, #52]	; 0x34
d00411a6:	b141      	cbz	r1, d00411ba <__swsetup_r+0x6a>
d00411a8:	f104 0344 	add.w	r3, r4, #68	; 0x44
d00411ac:	4299      	cmp	r1, r3
d00411ae:	d002      	beq.n	d00411b6 <__swsetup_r+0x66>
d00411b0:	4630      	mov	r0, r6
d00411b2:	f000 fa61 	bl	d0041678 <_free_r>
d00411b6:	2300      	movs	r3, #0
d00411b8:	6363      	str	r3, [r4, #52]	; 0x34
d00411ba:	89a3      	ldrh	r3, [r4, #12]
d00411bc:	f023 0324 	bic.w	r3, r3, #36	; 0x24
d00411c0:	81a3      	strh	r3, [r4, #12]
d00411c2:	2300      	movs	r3, #0
d00411c4:	6063      	str	r3, [r4, #4]
d00411c6:	6923      	ldr	r3, [r4, #16]
d00411c8:	6023      	str	r3, [r4, #0]
d00411ca:	89a3      	ldrh	r3, [r4, #12]
d00411cc:	f043 0308 	orr.w	r3, r3, #8
d00411d0:	81a3      	strh	r3, [r4, #12]
d00411d2:	6923      	ldr	r3, [r4, #16]
d00411d4:	b94b      	cbnz	r3, d00411ea <__swsetup_r+0x9a>
d00411d6:	89a3      	ldrh	r3, [r4, #12]
d00411d8:	f403 7320 	and.w	r3, r3, #640	; 0x280
d00411dc:	f5b3 7f00 	cmp.w	r3, #512	; 0x200
d00411e0:	d003      	beq.n	d00411ea <__swsetup_r+0x9a>
d00411e2:	4621      	mov	r1, r4
d00411e4:	4630      	mov	r0, r6
d00411e6:	f000 f9ff 	bl	d00415e8 <__smakebuf_r>
d00411ea:	89a0      	ldrh	r0, [r4, #12]
d00411ec:	f9b4 200c 	ldrsh.w	r2, [r4, #12]
d00411f0:	f010 0301 	ands.w	r3, r0, #1
d00411f4:	d00a      	beq.n	d004120c <__swsetup_r+0xbc>
d00411f6:	2300      	movs	r3, #0
d00411f8:	60a3      	str	r3, [r4, #8]
d00411fa:	6963      	ldr	r3, [r4, #20]
d00411fc:	425b      	negs	r3, r3
d00411fe:	61a3      	str	r3, [r4, #24]
d0041200:	6923      	ldr	r3, [r4, #16]
d0041202:	b943      	cbnz	r3, d0041216 <__swsetup_r+0xc6>
d0041204:	f010 0080 	ands.w	r0, r0, #128	; 0x80
d0041208:	d1ba      	bne.n	d0041180 <__swsetup_r+0x30>
d004120a:	bd70      	pop	{r4, r5, r6, pc}
d004120c:	0781      	lsls	r1, r0, #30
d004120e:	bf58      	it	pl
d0041210:	6963      	ldrpl	r3, [r4, #20]
d0041212:	60a3      	str	r3, [r4, #8]
d0041214:	e7f4      	b.n	d0041200 <__swsetup_r+0xb0>
d0041216:	2000      	movs	r0, #0
d0041218:	e7f7      	b.n	d004120a <__swsetup_r+0xba>
d004121a:	bf00      	nop
d004121c:	d0041a80 	.word	0xd0041a80
d0041220:	d0041a38 	.word	0xd0041a38
d0041224:	d0041a58 	.word	0xd0041a58
d0041228:	d0041a18 	.word	0xd0041a18

d004122c <__sflush_r>:
d004122c:	898a      	ldrh	r2, [r1, #12]
d004122e:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d0041232:	4605      	mov	r5, r0
d0041234:	0710      	lsls	r0, r2, #28
d0041236:	460c      	mov	r4, r1
d0041238:	d458      	bmi.n	d00412ec <__sflush_r+0xc0>
d004123a:	684b      	ldr	r3, [r1, #4]
d004123c:	2b00      	cmp	r3, #0
d004123e:	dc05      	bgt.n	d004124c <__sflush_r+0x20>
d0041240:	6c0b      	ldr	r3, [r1, #64]	; 0x40
d0041242:	2b00      	cmp	r3, #0
d0041244:	dc02      	bgt.n	d004124c <__sflush_r+0x20>
d0041246:	2000      	movs	r0, #0
d0041248:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
d004124c:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d004124e:	2e00      	cmp	r6, #0
d0041250:	d0f9      	beq.n	d0041246 <__sflush_r+0x1a>
d0041252:	2300      	movs	r3, #0
d0041254:	f412 5280 	ands.w	r2, r2, #4096	; 0x1000
d0041258:	682f      	ldr	r7, [r5, #0]
d004125a:	602b      	str	r3, [r5, #0]
d004125c:	d032      	beq.n	d00412c4 <__sflush_r+0x98>
d004125e:	6d60      	ldr	r0, [r4, #84]	; 0x54
d0041260:	89a3      	ldrh	r3, [r4, #12]
d0041262:	075a      	lsls	r2, r3, #29
d0041264:	d505      	bpl.n	d0041272 <__sflush_r+0x46>
d0041266:	6863      	ldr	r3, [r4, #4]
d0041268:	1ac0      	subs	r0, r0, r3
d004126a:	6b63      	ldr	r3, [r4, #52]	; 0x34
d004126c:	b10b      	cbz	r3, d0041272 <__sflush_r+0x46>
d004126e:	6c23      	ldr	r3, [r4, #64]	; 0x40
d0041270:	1ac0      	subs	r0, r0, r3
d0041272:	2300      	movs	r3, #0
d0041274:	4602      	mov	r2, r0
d0041276:	6ae6      	ldr	r6, [r4, #44]	; 0x2c
d0041278:	6a21      	ldr	r1, [r4, #32]
d004127a:	4628      	mov	r0, r5
d004127c:	47b0      	blx	r6
d004127e:	1c43      	adds	r3, r0, #1
d0041280:	89a3      	ldrh	r3, [r4, #12]
d0041282:	d106      	bne.n	d0041292 <__sflush_r+0x66>
d0041284:	6829      	ldr	r1, [r5, #0]
d0041286:	291d      	cmp	r1, #29
d0041288:	d82c      	bhi.n	d00412e4 <__sflush_r+0xb8>
d004128a:	4a2a      	ldr	r2, [pc, #168]	; (d0041334 <__sflush_r+0x108>)
d004128c:	40ca      	lsrs	r2, r1
d004128e:	07d6      	lsls	r6, r2, #31
d0041290:	d528      	bpl.n	d00412e4 <__sflush_r+0xb8>
d0041292:	2200      	movs	r2, #0
d0041294:	6062      	str	r2, [r4, #4]
d0041296:	04d9      	lsls	r1, r3, #19
d0041298:	6922      	ldr	r2, [r4, #16]
d004129a:	6022      	str	r2, [r4, #0]
d004129c:	d504      	bpl.n	d00412a8 <__sflush_r+0x7c>
d004129e:	1c42      	adds	r2, r0, #1
d00412a0:	d101      	bne.n	d00412a6 <__sflush_r+0x7a>
d00412a2:	682b      	ldr	r3, [r5, #0]
d00412a4:	b903      	cbnz	r3, d00412a8 <__sflush_r+0x7c>
d00412a6:	6560      	str	r0, [r4, #84]	; 0x54
d00412a8:	6b61      	ldr	r1, [r4, #52]	; 0x34
d00412aa:	602f      	str	r7, [r5, #0]
d00412ac:	2900      	cmp	r1, #0
d00412ae:	d0ca      	beq.n	d0041246 <__sflush_r+0x1a>
d00412b0:	f104 0344 	add.w	r3, r4, #68	; 0x44
d00412b4:	4299      	cmp	r1, r3
d00412b6:	d002      	beq.n	d00412be <__sflush_r+0x92>
d00412b8:	4628      	mov	r0, r5
d00412ba:	f000 f9dd 	bl	d0041678 <_free_r>
d00412be:	2000      	movs	r0, #0
d00412c0:	6360      	str	r0, [r4, #52]	; 0x34
d00412c2:	e7c1      	b.n	d0041248 <__sflush_r+0x1c>
d00412c4:	6a21      	ldr	r1, [r4, #32]
d00412c6:	2301      	movs	r3, #1
d00412c8:	4628      	mov	r0, r5
d00412ca:	47b0      	blx	r6
d00412cc:	1c41      	adds	r1, r0, #1
d00412ce:	d1c7      	bne.n	d0041260 <__sflush_r+0x34>
d00412d0:	682b      	ldr	r3, [r5, #0]
d00412d2:	2b00      	cmp	r3, #0
d00412d4:	d0c4      	beq.n	d0041260 <__sflush_r+0x34>
d00412d6:	2b1d      	cmp	r3, #29
d00412d8:	d001      	beq.n	d00412de <__sflush_r+0xb2>
d00412da:	2b16      	cmp	r3, #22
d00412dc:	d101      	bne.n	d00412e2 <__sflush_r+0xb6>
d00412de:	602f      	str	r7, [r5, #0]
d00412e0:	e7b1      	b.n	d0041246 <__sflush_r+0x1a>
d00412e2:	89a3      	ldrh	r3, [r4, #12]
d00412e4:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d00412e8:	81a3      	strh	r3, [r4, #12]
d00412ea:	e7ad      	b.n	d0041248 <__sflush_r+0x1c>
d00412ec:	690f      	ldr	r7, [r1, #16]
d00412ee:	2f00      	cmp	r7, #0
d00412f0:	d0a9      	beq.n	d0041246 <__sflush_r+0x1a>
d00412f2:	0793      	lsls	r3, r2, #30
d00412f4:	680e      	ldr	r6, [r1, #0]
d00412f6:	bf08      	it	eq
d00412f8:	694b      	ldreq	r3, [r1, #20]
d00412fa:	600f      	str	r7, [r1, #0]
d00412fc:	bf18      	it	ne
d00412fe:	2300      	movne	r3, #0
d0041300:	eba6 0807 	sub.w	r8, r6, r7
d0041304:	608b      	str	r3, [r1, #8]
d0041306:	f1b8 0f00 	cmp.w	r8, #0
d004130a:	dd9c      	ble.n	d0041246 <__sflush_r+0x1a>
d004130c:	6a21      	ldr	r1, [r4, #32]
d004130e:	6aa6      	ldr	r6, [r4, #40]	; 0x28
d0041310:	4643      	mov	r3, r8
d0041312:	463a      	mov	r2, r7
d0041314:	4628      	mov	r0, r5
d0041316:	47b0      	blx	r6
d0041318:	2800      	cmp	r0, #0
d004131a:	dc06      	bgt.n	d004132a <__sflush_r+0xfe>
d004131c:	89a3      	ldrh	r3, [r4, #12]
d004131e:	f043 0340 	orr.w	r3, r3, #64	; 0x40
d0041322:	81a3      	strh	r3, [r4, #12]
d0041324:	f04f 30ff 	mov.w	r0, #4294967295	; 0xffffffff
d0041328:	e78e      	b.n	d0041248 <__sflush_r+0x1c>
d004132a:	4407      	add	r7, r0
d004132c:	eba8 0800 	sub.w	r8, r8, r0
d0041330:	e7e9      	b.n	d0041306 <__sflush_r+0xda>
d0041332:	bf00      	nop
d0041334:	20400001 	.word	0x20400001

d0041338 <_fflush_r>:
d0041338:	b538      	push	{r3, r4, r5, lr}
d004133a:	690b      	ldr	r3, [r1, #16]
d004133c:	4605      	mov	r5, r0
d004133e:	460c      	mov	r4, r1
d0041340:	b913      	cbnz	r3, d0041348 <_fflush_r+0x10>
d0041342:	2500      	movs	r5, #0
d0041344:	4628      	mov	r0, r5
d0041346:	bd38      	pop	{r3, r4, r5, pc}
d0041348:	b118      	cbz	r0, d0041352 <_fflush_r+0x1a>
d004134a:	6983      	ldr	r3, [r0, #24]
d004134c:	b90b      	cbnz	r3, d0041352 <_fflush_r+0x1a>
d004134e:	f000 f887 	bl	d0041460 <__sinit>
d0041352:	4b14      	ldr	r3, [pc, #80]	; (d00413a4 <_fflush_r+0x6c>)
d0041354:	429c      	cmp	r4, r3
d0041356:	d11b      	bne.n	d0041390 <_fflush_r+0x58>
d0041358:	686c      	ldr	r4, [r5, #4]
d004135a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d004135e:	2b00      	cmp	r3, #0
d0041360:	d0ef      	beq.n	d0041342 <_fflush_r+0xa>
d0041362:	6e62      	ldr	r2, [r4, #100]	; 0x64
d0041364:	07d0      	lsls	r0, r2, #31
d0041366:	d404      	bmi.n	d0041372 <_fflush_r+0x3a>
d0041368:	0599      	lsls	r1, r3, #22
d004136a:	d402      	bmi.n	d0041372 <_fflush_r+0x3a>
d004136c:	6da0      	ldr	r0, [r4, #88]	; 0x58
d004136e:	f000 f915 	bl	d004159c <__retarget_lock_acquire_recursive>
d0041372:	4628      	mov	r0, r5
d0041374:	4621      	mov	r1, r4
d0041376:	f7ff ff59 	bl	d004122c <__sflush_r>
d004137a:	6e63      	ldr	r3, [r4, #100]	; 0x64
d004137c:	07da      	lsls	r2, r3, #31
d004137e:	4605      	mov	r5, r0
d0041380:	d4e0      	bmi.n	d0041344 <_fflush_r+0xc>
d0041382:	89a3      	ldrh	r3, [r4, #12]
d0041384:	059b      	lsls	r3, r3, #22
d0041386:	d4dd      	bmi.n	d0041344 <_fflush_r+0xc>
d0041388:	6da0      	ldr	r0, [r4, #88]	; 0x58
d004138a:	f000 f908 	bl	d004159e <__retarget_lock_release_recursive>
d004138e:	e7d9      	b.n	d0041344 <_fflush_r+0xc>
d0041390:	4b05      	ldr	r3, [pc, #20]	; (d00413a8 <_fflush_r+0x70>)
d0041392:	429c      	cmp	r4, r3
d0041394:	d101      	bne.n	d004139a <_fflush_r+0x62>
d0041396:	68ac      	ldr	r4, [r5, #8]
d0041398:	e7df      	b.n	d004135a <_fflush_r+0x22>
d004139a:	4b04      	ldr	r3, [pc, #16]	; (d00413ac <_fflush_r+0x74>)
d004139c:	429c      	cmp	r4, r3
d004139e:	bf08      	it	eq
d00413a0:	68ec      	ldreq	r4, [r5, #12]
d00413a2:	e7da      	b.n	d004135a <_fflush_r+0x22>
d00413a4:	d0041a38 	.word	0xd0041a38
d00413a8:	d0041a58 	.word	0xd0041a58
d00413ac:	d0041a18 	.word	0xd0041a18

d00413b0 <std>:
d00413b0:	2300      	movs	r3, #0
d00413b2:	b510      	push	{r4, lr}
d00413b4:	4604      	mov	r4, r0
d00413b6:	e9c0 3300 	strd	r3, r3, [r0]
d00413ba:	e9c0 3304 	strd	r3, r3, [r0, #16]
d00413be:	6083      	str	r3, [r0, #8]
d00413c0:	8181      	strh	r1, [r0, #12]
d00413c2:	6643      	str	r3, [r0, #100]	; 0x64
d00413c4:	81c2      	strh	r2, [r0, #14]
d00413c6:	6183      	str	r3, [r0, #24]
d00413c8:	4619      	mov	r1, r3
d00413ca:	2208      	movs	r2, #8
d00413cc:	305c      	adds	r0, #92	; 0x5c
d00413ce:	f7ff fd21 	bl	d0040e14 <memset>
d00413d2:	4b05      	ldr	r3, [pc, #20]	; (d00413e8 <std+0x38>)
d00413d4:	6263      	str	r3, [r4, #36]	; 0x24
d00413d6:	4b05      	ldr	r3, [pc, #20]	; (d00413ec <std+0x3c>)
d00413d8:	62a3      	str	r3, [r4, #40]	; 0x28
d00413da:	4b05      	ldr	r3, [pc, #20]	; (d00413f0 <std+0x40>)
d00413dc:	62e3      	str	r3, [r4, #44]	; 0x2c
d00413de:	4b05      	ldr	r3, [pc, #20]	; (d00413f4 <std+0x44>)
d00413e0:	6224      	str	r4, [r4, #32]
d00413e2:	6323      	str	r3, [r4, #48]	; 0x30
d00413e4:	bd10      	pop	{r4, pc}
d00413e6:	bf00      	nop
d00413e8:	d00417cd 	.word	0xd00417cd
d00413ec:	d00417ef 	.word	0xd00417ef
d00413f0:	d0041827 	.word	0xd0041827
d00413f4:	d004184b 	.word	0xd004184b

d00413f8 <_cleanup_r>:
d00413f8:	4901      	ldr	r1, [pc, #4]	; (d0041400 <_cleanup_r+0x8>)
d00413fa:	f000 b8af 	b.w	d004155c <_fwalk_reent>
d00413fe:	bf00      	nop
d0041400:	d0041339 	.word	0xd0041339

d0041404 <__sfmoreglue>:
d0041404:	b570      	push	{r4, r5, r6, lr}
d0041406:	1e4a      	subs	r2, r1, #1
d0041408:	2568      	movs	r5, #104	; 0x68
d004140a:	4355      	muls	r5, r2
d004140c:	460e      	mov	r6, r1
d004140e:	f105 0174 	add.w	r1, r5, #116	; 0x74
d0041412:	f000 f981 	bl	d0041718 <_malloc_r>
d0041416:	4604      	mov	r4, r0
d0041418:	b140      	cbz	r0, d004142c <__sfmoreglue+0x28>
d004141a:	2100      	movs	r1, #0
d004141c:	e9c0 1600 	strd	r1, r6, [r0]
d0041420:	300c      	adds	r0, #12
d0041422:	60a0      	str	r0, [r4, #8]
d0041424:	f105 0268 	add.w	r2, r5, #104	; 0x68
d0041428:	f7ff fcf4 	bl	d0040e14 <memset>
d004142c:	4620      	mov	r0, r4
d004142e:	bd70      	pop	{r4, r5, r6, pc}

d0041430 <__sfp_lock_acquire>:
d0041430:	4801      	ldr	r0, [pc, #4]	; (d0041438 <__sfp_lock_acquire+0x8>)
d0041432:	f000 b8b3 	b.w	d004159c <__retarget_lock_acquire_recursive>
d0041436:	bf00      	nop
d0041438:	d0041f34 	.word	0xd0041f34

d004143c <__sfp_lock_release>:
d004143c:	4801      	ldr	r0, [pc, #4]	; (d0041444 <__sfp_lock_release+0x8>)
d004143e:	f000 b8ae 	b.w	d004159e <__retarget_lock_release_recursive>
d0041442:	bf00      	nop
d0041444:	d0041f34 	.word	0xd0041f34

d0041448 <__sinit_lock_acquire>:
d0041448:	4801      	ldr	r0, [pc, #4]	; (d0041450 <__sinit_lock_acquire+0x8>)
d004144a:	f000 b8a7 	b.w	d004159c <__retarget_lock_acquire_recursive>
d004144e:	bf00      	nop
d0041450:	d0041f2f 	.word	0xd0041f2f

d0041454 <__sinit_lock_release>:
d0041454:	4801      	ldr	r0, [pc, #4]	; (d004145c <__sinit_lock_release+0x8>)
d0041456:	f000 b8a2 	b.w	d004159e <__retarget_lock_release_recursive>
d004145a:	bf00      	nop
d004145c:	d0041f2f 	.word	0xd0041f2f

d0041460 <__sinit>:
d0041460:	b510      	push	{r4, lr}
d0041462:	4604      	mov	r4, r0
d0041464:	f7ff fff0 	bl	d0041448 <__sinit_lock_acquire>
d0041468:	69a3      	ldr	r3, [r4, #24]
d004146a:	b11b      	cbz	r3, d0041474 <__sinit+0x14>
d004146c:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
d0041470:	f7ff bff0 	b.w	d0041454 <__sinit_lock_release>
d0041474:	e9c4 3312 	strd	r3, r3, [r4, #72]	; 0x48
d0041478:	6523      	str	r3, [r4, #80]	; 0x50
d004147a:	4b13      	ldr	r3, [pc, #76]	; (d00414c8 <__sinit+0x68>)
d004147c:	4a13      	ldr	r2, [pc, #76]	; (d00414cc <__sinit+0x6c>)
d004147e:	681b      	ldr	r3, [r3, #0]
d0041480:	62a2      	str	r2, [r4, #40]	; 0x28
d0041482:	42a3      	cmp	r3, r4
d0041484:	bf04      	itt	eq
d0041486:	2301      	moveq	r3, #1
d0041488:	61a3      	streq	r3, [r4, #24]
d004148a:	4620      	mov	r0, r4
d004148c:	f000 f820 	bl	d00414d0 <__sfp>
d0041490:	6060      	str	r0, [r4, #4]
d0041492:	4620      	mov	r0, r4
d0041494:	f000 f81c 	bl	d00414d0 <__sfp>
d0041498:	60a0      	str	r0, [r4, #8]
d004149a:	4620      	mov	r0, r4
d004149c:	f000 f818 	bl	d00414d0 <__sfp>
d00414a0:	2200      	movs	r2, #0
d00414a2:	60e0      	str	r0, [r4, #12]
d00414a4:	2104      	movs	r1, #4
d00414a6:	6860      	ldr	r0, [r4, #4]
d00414a8:	f7ff ff82 	bl	d00413b0 <std>
d00414ac:	68a0      	ldr	r0, [r4, #8]
d00414ae:	2201      	movs	r2, #1
d00414b0:	2109      	movs	r1, #9
d00414b2:	f7ff ff7d 	bl	d00413b0 <std>
d00414b6:	68e0      	ldr	r0, [r4, #12]
d00414b8:	2202      	movs	r2, #2
d00414ba:	2112      	movs	r1, #18
d00414bc:	f7ff ff78 	bl	d00413b0 <std>
d00414c0:	2301      	movs	r3, #1
d00414c2:	61a3      	str	r3, [r4, #24]
d00414c4:	e7d2      	b.n	d004146c <__sinit+0xc>
d00414c6:	bf00      	nop
d00414c8:	d0041a14 	.word	0xd0041a14
d00414cc:	d00413f9 	.word	0xd00413f9

d00414d0 <__sfp>:
d00414d0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d00414d2:	4607      	mov	r7, r0
d00414d4:	f7ff ffac 	bl	d0041430 <__sfp_lock_acquire>
d00414d8:	4b1e      	ldr	r3, [pc, #120]	; (d0041554 <__sfp+0x84>)
d00414da:	681e      	ldr	r6, [r3, #0]
d00414dc:	69b3      	ldr	r3, [r6, #24]
d00414de:	b913      	cbnz	r3, d00414e6 <__sfp+0x16>
d00414e0:	4630      	mov	r0, r6
d00414e2:	f7ff ffbd 	bl	d0041460 <__sinit>
d00414e6:	3648      	adds	r6, #72	; 0x48
d00414e8:	e9d6 3401 	ldrd	r3, r4, [r6, #4]
d00414ec:	3b01      	subs	r3, #1
d00414ee:	d503      	bpl.n	d00414f8 <__sfp+0x28>
d00414f0:	6833      	ldr	r3, [r6, #0]
d00414f2:	b30b      	cbz	r3, d0041538 <__sfp+0x68>
d00414f4:	6836      	ldr	r6, [r6, #0]
d00414f6:	e7f7      	b.n	d00414e8 <__sfp+0x18>
d00414f8:	f9b4 500c 	ldrsh.w	r5, [r4, #12]
d00414fc:	b9d5      	cbnz	r5, d0041534 <__sfp+0x64>
d00414fe:	4b16      	ldr	r3, [pc, #88]	; (d0041558 <__sfp+0x88>)
d0041500:	60e3      	str	r3, [r4, #12]
d0041502:	f104 0058 	add.w	r0, r4, #88	; 0x58
d0041506:	6665      	str	r5, [r4, #100]	; 0x64
d0041508:	f000 f847 	bl	d004159a <__retarget_lock_init_recursive>
d004150c:	f7ff ff96 	bl	d004143c <__sfp_lock_release>
d0041510:	e9c4 5501 	strd	r5, r5, [r4, #4]
d0041514:	e9c4 5504 	strd	r5, r5, [r4, #16]
d0041518:	6025      	str	r5, [r4, #0]
d004151a:	61a5      	str	r5, [r4, #24]
d004151c:	2208      	movs	r2, #8
d004151e:	4629      	mov	r1, r5
d0041520:	f104 005c 	add.w	r0, r4, #92	; 0x5c
d0041524:	f7ff fc76 	bl	d0040e14 <memset>
d0041528:	e9c4 550d 	strd	r5, r5, [r4, #52]	; 0x34
d004152c:	e9c4 5512 	strd	r5, r5, [r4, #72]	; 0x48
d0041530:	4620      	mov	r0, r4
d0041532:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d0041534:	3468      	adds	r4, #104	; 0x68
d0041536:	e7d9      	b.n	d00414ec <__sfp+0x1c>
d0041538:	2104      	movs	r1, #4
d004153a:	4638      	mov	r0, r7
d004153c:	f7ff ff62 	bl	d0041404 <__sfmoreglue>
d0041540:	4604      	mov	r4, r0
d0041542:	6030      	str	r0, [r6, #0]
d0041544:	2800      	cmp	r0, #0
d0041546:	d1d5      	bne.n	d00414f4 <__sfp+0x24>
d0041548:	f7ff ff78 	bl	d004143c <__sfp_lock_release>
d004154c:	230c      	movs	r3, #12
d004154e:	603b      	str	r3, [r7, #0]
d0041550:	e7ee      	b.n	d0041530 <__sfp+0x60>
d0041552:	bf00      	nop
d0041554:	d0041a14 	.word	0xd0041a14
d0041558:	ffff0001 	.word	0xffff0001

d004155c <_fwalk_reent>:
d004155c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
d0041560:	4606      	mov	r6, r0
d0041562:	4688      	mov	r8, r1
d0041564:	f100 0448 	add.w	r4, r0, #72	; 0x48
d0041568:	2700      	movs	r7, #0
d004156a:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
d004156e:	f1b9 0901 	subs.w	r9, r9, #1
d0041572:	d505      	bpl.n	d0041580 <_fwalk_reent+0x24>
d0041574:	6824      	ldr	r4, [r4, #0]
d0041576:	2c00      	cmp	r4, #0
d0041578:	d1f7      	bne.n	d004156a <_fwalk_reent+0xe>
d004157a:	4638      	mov	r0, r7
d004157c:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
d0041580:	89ab      	ldrh	r3, [r5, #12]
d0041582:	2b01      	cmp	r3, #1
d0041584:	d907      	bls.n	d0041596 <_fwalk_reent+0x3a>
d0041586:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
d004158a:	3301      	adds	r3, #1
d004158c:	d003      	beq.n	d0041596 <_fwalk_reent+0x3a>
d004158e:	4629      	mov	r1, r5
d0041590:	4630      	mov	r0, r6
d0041592:	47c0      	blx	r8
d0041594:	4307      	orrs	r7, r0
d0041596:	3568      	adds	r5, #104	; 0x68
d0041598:	e7e9      	b.n	d004156e <_fwalk_reent+0x12>

d004159a <__retarget_lock_init_recursive>:
d004159a:	4770      	bx	lr

d004159c <__retarget_lock_acquire_recursive>:
d004159c:	4770      	bx	lr

d004159e <__retarget_lock_release_recursive>:
d004159e:	4770      	bx	lr

d00415a0 <__swhatbuf_r>:
d00415a0:	b570      	push	{r4, r5, r6, lr}
d00415a2:	460e      	mov	r6, r1
d00415a4:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00415a8:	2900      	cmp	r1, #0
d00415aa:	b096      	sub	sp, #88	; 0x58
d00415ac:	4614      	mov	r4, r2
d00415ae:	461d      	mov	r5, r3
d00415b0:	da07      	bge.n	d00415c2 <__swhatbuf_r+0x22>
d00415b2:	2300      	movs	r3, #0
d00415b4:	602b      	str	r3, [r5, #0]
d00415b6:	89b3      	ldrh	r3, [r6, #12]
d00415b8:	061a      	lsls	r2, r3, #24
d00415ba:	d410      	bmi.n	d00415de <__swhatbuf_r+0x3e>
d00415bc:	f44f 6380 	mov.w	r3, #1024	; 0x400
d00415c0:	e00e      	b.n	d00415e0 <__swhatbuf_r+0x40>
d00415c2:	466a      	mov	r2, sp
d00415c4:	f000 f956 	bl	d0041874 <_fstat_r>
d00415c8:	2800      	cmp	r0, #0
d00415ca:	dbf2      	blt.n	d00415b2 <__swhatbuf_r+0x12>
d00415cc:	9a01      	ldr	r2, [sp, #4]
d00415ce:	f402 4270 	and.w	r2, r2, #61440	; 0xf000
d00415d2:	f5a2 5300 	sub.w	r3, r2, #8192	; 0x2000
d00415d6:	425a      	negs	r2, r3
d00415d8:	415a      	adcs	r2, r3
d00415da:	602a      	str	r2, [r5, #0]
d00415dc:	e7ee      	b.n	d00415bc <__swhatbuf_r+0x1c>
d00415de:	2340      	movs	r3, #64	; 0x40
d00415e0:	2000      	movs	r0, #0
d00415e2:	6023      	str	r3, [r4, #0]
d00415e4:	b016      	add	sp, #88	; 0x58
d00415e6:	bd70      	pop	{r4, r5, r6, pc}

d00415e8 <__smakebuf_r>:
d00415e8:	898b      	ldrh	r3, [r1, #12]
d00415ea:	b573      	push	{r0, r1, r4, r5, r6, lr}
d00415ec:	079d      	lsls	r5, r3, #30
d00415ee:	4606      	mov	r6, r0
d00415f0:	460c      	mov	r4, r1
d00415f2:	d507      	bpl.n	d0041604 <__smakebuf_r+0x1c>
d00415f4:	f104 0347 	add.w	r3, r4, #71	; 0x47
d00415f8:	6023      	str	r3, [r4, #0]
d00415fa:	6123      	str	r3, [r4, #16]
d00415fc:	2301      	movs	r3, #1
d00415fe:	6163      	str	r3, [r4, #20]
d0041600:	b002      	add	sp, #8
d0041602:	bd70      	pop	{r4, r5, r6, pc}
d0041604:	ab01      	add	r3, sp, #4
d0041606:	466a      	mov	r2, sp
d0041608:	f7ff ffca 	bl	d00415a0 <__swhatbuf_r>
d004160c:	9900      	ldr	r1, [sp, #0]
d004160e:	4605      	mov	r5, r0
d0041610:	4630      	mov	r0, r6
d0041612:	f000 f881 	bl	d0041718 <_malloc_r>
d0041616:	b948      	cbnz	r0, d004162c <__smakebuf_r+0x44>
d0041618:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
d004161c:	059a      	lsls	r2, r3, #22
d004161e:	d4ef      	bmi.n	d0041600 <__smakebuf_r+0x18>
d0041620:	f023 0303 	bic.w	r3, r3, #3
d0041624:	f043 0302 	orr.w	r3, r3, #2
d0041628:	81a3      	strh	r3, [r4, #12]
d004162a:	e7e3      	b.n	d00415f4 <__smakebuf_r+0xc>
d004162c:	4b0d      	ldr	r3, [pc, #52]	; (d0041664 <__smakebuf_r+0x7c>)
d004162e:	62b3      	str	r3, [r6, #40]	; 0x28
d0041630:	89a3      	ldrh	r3, [r4, #12]
d0041632:	6020      	str	r0, [r4, #0]
d0041634:	f043 0380 	orr.w	r3, r3, #128	; 0x80
d0041638:	81a3      	strh	r3, [r4, #12]
d004163a:	9b00      	ldr	r3, [sp, #0]
d004163c:	6163      	str	r3, [r4, #20]
d004163e:	9b01      	ldr	r3, [sp, #4]
d0041640:	6120      	str	r0, [r4, #16]
d0041642:	b15b      	cbz	r3, d004165c <__smakebuf_r+0x74>
d0041644:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d0041648:	4630      	mov	r0, r6
d004164a:	f000 f925 	bl	d0041898 <_isatty_r>
d004164e:	b128      	cbz	r0, d004165c <__smakebuf_r+0x74>
d0041650:	89a3      	ldrh	r3, [r4, #12]
d0041652:	f023 0303 	bic.w	r3, r3, #3
d0041656:	f043 0301 	orr.w	r3, r3, #1
d004165a:	81a3      	strh	r3, [r4, #12]
d004165c:	89a0      	ldrh	r0, [r4, #12]
d004165e:	4305      	orrs	r5, r0
d0041660:	81a5      	strh	r5, [r4, #12]
d0041662:	e7cd      	b.n	d0041600 <__smakebuf_r+0x18>
d0041664:	d00413f9 	.word	0xd00413f9

d0041668 <malloc>:
d0041668:	4b02      	ldr	r3, [pc, #8]	; (d0041674 <malloc+0xc>)
d004166a:	4601      	mov	r1, r0
d004166c:	6818      	ldr	r0, [r3, #0]
d004166e:	f000 b853 	b.w	d0041718 <_malloc_r>
d0041672:	bf00      	nop
d0041674:	d0041a80 	.word	0xd0041a80

d0041678 <_free_r>:
d0041678:	b537      	push	{r0, r1, r2, r4, r5, lr}
d004167a:	2900      	cmp	r1, #0
d004167c:	d048      	beq.n	d0041710 <_free_r+0x98>
d004167e:	f851 3c04 	ldr.w	r3, [r1, #-4]
d0041682:	9001      	str	r0, [sp, #4]
d0041684:	2b00      	cmp	r3, #0
d0041686:	f1a1 0404 	sub.w	r4, r1, #4
d004168a:	bfb8      	it	lt
d004168c:	18e4      	addlt	r4, r4, r3
d004168e:	f000 f925 	bl	d00418dc <__malloc_lock>
d0041692:	4a20      	ldr	r2, [pc, #128]	; (d0041714 <_free_r+0x9c>)
d0041694:	9801      	ldr	r0, [sp, #4]
d0041696:	6813      	ldr	r3, [r2, #0]
d0041698:	4615      	mov	r5, r2
d004169a:	b933      	cbnz	r3, d00416aa <_free_r+0x32>
d004169c:	6063      	str	r3, [r4, #4]
d004169e:	6014      	str	r4, [r2, #0]
d00416a0:	b003      	add	sp, #12
d00416a2:	e8bd 4030 	ldmia.w	sp!, {r4, r5, lr}
d00416a6:	f000 b91f 	b.w	d00418e8 <__malloc_unlock>
d00416aa:	42a3      	cmp	r3, r4
d00416ac:	d90b      	bls.n	d00416c6 <_free_r+0x4e>
d00416ae:	6821      	ldr	r1, [r4, #0]
d00416b0:	1862      	adds	r2, r4, r1
d00416b2:	4293      	cmp	r3, r2
d00416b4:	bf04      	itt	eq
d00416b6:	681a      	ldreq	r2, [r3, #0]
d00416b8:	685b      	ldreq	r3, [r3, #4]
d00416ba:	6063      	str	r3, [r4, #4]
d00416bc:	bf04      	itt	eq
d00416be:	1852      	addeq	r2, r2, r1
d00416c0:	6022      	streq	r2, [r4, #0]
d00416c2:	602c      	str	r4, [r5, #0]
d00416c4:	e7ec      	b.n	d00416a0 <_free_r+0x28>
d00416c6:	461a      	mov	r2, r3
d00416c8:	685b      	ldr	r3, [r3, #4]
d00416ca:	b10b      	cbz	r3, d00416d0 <_free_r+0x58>
d00416cc:	42a3      	cmp	r3, r4
d00416ce:	d9fa      	bls.n	d00416c6 <_free_r+0x4e>
d00416d0:	6811      	ldr	r1, [r2, #0]
d00416d2:	1855      	adds	r5, r2, r1
d00416d4:	42a5      	cmp	r5, r4
d00416d6:	d10b      	bne.n	d00416f0 <_free_r+0x78>
d00416d8:	6824      	ldr	r4, [r4, #0]
d00416da:	4421      	add	r1, r4
d00416dc:	1854      	adds	r4, r2, r1
d00416de:	42a3      	cmp	r3, r4
d00416e0:	6011      	str	r1, [r2, #0]
d00416e2:	d1dd      	bne.n	d00416a0 <_free_r+0x28>
d00416e4:	681c      	ldr	r4, [r3, #0]
d00416e6:	685b      	ldr	r3, [r3, #4]
d00416e8:	6053      	str	r3, [r2, #4]
d00416ea:	4421      	add	r1, r4
d00416ec:	6011      	str	r1, [r2, #0]
d00416ee:	e7d7      	b.n	d00416a0 <_free_r+0x28>
d00416f0:	d902      	bls.n	d00416f8 <_free_r+0x80>
d00416f2:	230c      	movs	r3, #12
d00416f4:	6003      	str	r3, [r0, #0]
d00416f6:	e7d3      	b.n	d00416a0 <_free_r+0x28>
d00416f8:	6825      	ldr	r5, [r4, #0]
d00416fa:	1961      	adds	r1, r4, r5
d00416fc:	428b      	cmp	r3, r1
d00416fe:	bf04      	itt	eq
d0041700:	6819      	ldreq	r1, [r3, #0]
d0041702:	685b      	ldreq	r3, [r3, #4]
d0041704:	6063      	str	r3, [r4, #4]
d0041706:	bf04      	itt	eq
d0041708:	1949      	addeq	r1, r1, r5
d004170a:	6021      	streq	r1, [r4, #0]
d004170c:	6054      	str	r4, [r2, #4]
d004170e:	e7c7      	b.n	d00416a0 <_free_r+0x28>
d0041710:	b003      	add	sp, #12
d0041712:	bd30      	pop	{r4, r5, pc}
d0041714:	d0041f20 	.word	0xd0041f20

d0041718 <_malloc_r>:
d0041718:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d004171a:	1ccd      	adds	r5, r1, #3
d004171c:	f025 0503 	bic.w	r5, r5, #3
d0041720:	3508      	adds	r5, #8
d0041722:	2d0c      	cmp	r5, #12
d0041724:	bf38      	it	cc
d0041726:	250c      	movcc	r5, #12
d0041728:	2d00      	cmp	r5, #0
d004172a:	4606      	mov	r6, r0
d004172c:	db01      	blt.n	d0041732 <_malloc_r+0x1a>
d004172e:	42a9      	cmp	r1, r5
d0041730:	d903      	bls.n	d004173a <_malloc_r+0x22>
d0041732:	230c      	movs	r3, #12
d0041734:	6033      	str	r3, [r6, #0]
d0041736:	2000      	movs	r0, #0
d0041738:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
d004173a:	f000 f8cf 	bl	d00418dc <__malloc_lock>
d004173e:	4921      	ldr	r1, [pc, #132]	; (d00417c4 <_malloc_r+0xac>)
d0041740:	680a      	ldr	r2, [r1, #0]
d0041742:	4614      	mov	r4, r2
d0041744:	b99c      	cbnz	r4, d004176e <_malloc_r+0x56>
d0041746:	4f20      	ldr	r7, [pc, #128]	; (d00417c8 <_malloc_r+0xb0>)
d0041748:	683b      	ldr	r3, [r7, #0]
d004174a:	b923      	cbnz	r3, d0041756 <_malloc_r+0x3e>
d004174c:	4621      	mov	r1, r4
d004174e:	4630      	mov	r0, r6
d0041750:	f7fe fcc6 	bl	d00400e0 <_sbrk_r>
d0041754:	6038      	str	r0, [r7, #0]
d0041756:	4629      	mov	r1, r5
d0041758:	4630      	mov	r0, r6
d004175a:	f7fe fcc1 	bl	d00400e0 <_sbrk_r>
d004175e:	1c43      	adds	r3, r0, #1
d0041760:	d123      	bne.n	d00417aa <_malloc_r+0x92>
d0041762:	230c      	movs	r3, #12
d0041764:	6033      	str	r3, [r6, #0]
d0041766:	4630      	mov	r0, r6
d0041768:	f000 f8be 	bl	d00418e8 <__malloc_unlock>
d004176c:	e7e3      	b.n	d0041736 <_malloc_r+0x1e>
d004176e:	6823      	ldr	r3, [r4, #0]
d0041770:	1b5b      	subs	r3, r3, r5
d0041772:	d417      	bmi.n	d00417a4 <_malloc_r+0x8c>
d0041774:	2b0b      	cmp	r3, #11
d0041776:	d903      	bls.n	d0041780 <_malloc_r+0x68>
d0041778:	6023      	str	r3, [r4, #0]
d004177a:	441c      	add	r4, r3
d004177c:	6025      	str	r5, [r4, #0]
d004177e:	e004      	b.n	d004178a <_malloc_r+0x72>
d0041780:	6863      	ldr	r3, [r4, #4]
d0041782:	42a2      	cmp	r2, r4
d0041784:	bf0c      	ite	eq
d0041786:	600b      	streq	r3, [r1, #0]
d0041788:	6053      	strne	r3, [r2, #4]
d004178a:	4630      	mov	r0, r6
d004178c:	f000 f8ac 	bl	d00418e8 <__malloc_unlock>
d0041790:	f104 000b 	add.w	r0, r4, #11
d0041794:	1d23      	adds	r3, r4, #4
d0041796:	f020 0007 	bic.w	r0, r0, #7
d004179a:	1ac2      	subs	r2, r0, r3
d004179c:	d0cc      	beq.n	d0041738 <_malloc_r+0x20>
d004179e:	1a1b      	subs	r3, r3, r0
d00417a0:	50a3      	str	r3, [r4, r2]
d00417a2:	e7c9      	b.n	d0041738 <_malloc_r+0x20>
d00417a4:	4622      	mov	r2, r4
d00417a6:	6864      	ldr	r4, [r4, #4]
d00417a8:	e7cc      	b.n	d0041744 <_malloc_r+0x2c>
d00417aa:	1cc4      	adds	r4, r0, #3
d00417ac:	f024 0403 	bic.w	r4, r4, #3
d00417b0:	42a0      	cmp	r0, r4
d00417b2:	d0e3      	beq.n	d004177c <_malloc_r+0x64>
d00417b4:	1a21      	subs	r1, r4, r0
d00417b6:	4630      	mov	r0, r6
d00417b8:	f7fe fc92 	bl	d00400e0 <_sbrk_r>
d00417bc:	3001      	adds	r0, #1
d00417be:	d1dd      	bne.n	d004177c <_malloc_r+0x64>
d00417c0:	e7cf      	b.n	d0041762 <_malloc_r+0x4a>
d00417c2:	bf00      	nop
d00417c4:	d0041f20 	.word	0xd0041f20
d00417c8:	d0041f24 	.word	0xd0041f24

d00417cc <__sread>:
d00417cc:	b510      	push	{r4, lr}
d00417ce:	460c      	mov	r4, r1
d00417d0:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d00417d4:	f000 f88e 	bl	d00418f4 <_read_r>
d00417d8:	2800      	cmp	r0, #0
d00417da:	bfab      	itete	ge
d00417dc:	6d63      	ldrge	r3, [r4, #84]	; 0x54
d00417de:	89a3      	ldrhlt	r3, [r4, #12]
d00417e0:	181b      	addge	r3, r3, r0
d00417e2:	f423 5380 	biclt.w	r3, r3, #4096	; 0x1000
d00417e6:	bfac      	ite	ge
d00417e8:	6563      	strge	r3, [r4, #84]	; 0x54
d00417ea:	81a3      	strhlt	r3, [r4, #12]
d00417ec:	bd10      	pop	{r4, pc}

d00417ee <__swrite>:
d00417ee:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
d00417f2:	461f      	mov	r7, r3
d00417f4:	898b      	ldrh	r3, [r1, #12]
d00417f6:	05db      	lsls	r3, r3, #23
d00417f8:	4605      	mov	r5, r0
d00417fa:	460c      	mov	r4, r1
d00417fc:	4616      	mov	r6, r2
d00417fe:	d505      	bpl.n	d004180c <__swrite+0x1e>
d0041800:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d0041804:	2302      	movs	r3, #2
d0041806:	2200      	movs	r2, #0
d0041808:	f000 f856 	bl	d00418b8 <_lseek_r>
d004180c:	89a3      	ldrh	r3, [r4, #12]
d004180e:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
d0041812:	f423 5380 	bic.w	r3, r3, #4096	; 0x1000
d0041816:	81a3      	strh	r3, [r4, #12]
d0041818:	4632      	mov	r2, r6
d004181a:	463b      	mov	r3, r7
d004181c:	4628      	mov	r0, r5
d004181e:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
d0041822:	f7fe bc17 	b.w	d0040054 <_write_r>

d0041826 <__sseek>:
d0041826:	b510      	push	{r4, lr}
d0041828:	460c      	mov	r4, r1
d004182a:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d004182e:	f000 f843 	bl	d00418b8 <_lseek_r>
d0041832:	1c43      	adds	r3, r0, #1
d0041834:	89a3      	ldrh	r3, [r4, #12]
d0041836:	bf15      	itete	ne
d0041838:	6560      	strne	r0, [r4, #84]	; 0x54
d004183a:	f423 5380 	biceq.w	r3, r3, #4096	; 0x1000
d004183e:	f443 5380 	orrne.w	r3, r3, #4096	; 0x1000
d0041842:	81a3      	strheq	r3, [r4, #12]
d0041844:	bf18      	it	ne
d0041846:	81a3      	strhne	r3, [r4, #12]
d0041848:	bd10      	pop	{r4, pc}

d004184a <__sclose>:
d004184a:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
d004184e:	f000 b801 	b.w	d0041854 <_close_r>
	...

d0041854 <_close_r>:
d0041854:	b538      	push	{r3, r4, r5, lr}
d0041856:	4d06      	ldr	r5, [pc, #24]	; (d0041870 <_close_r+0x1c>)
d0041858:	2300      	movs	r3, #0
d004185a:	4604      	mov	r4, r0
d004185c:	4608      	mov	r0, r1
d004185e:	602b      	str	r3, [r5, #0]
d0041860:	f7fe fc32 	bl	d00400c8 <_close>
d0041864:	1c43      	adds	r3, r0, #1
d0041866:	d102      	bne.n	d004186e <_close_r+0x1a>
d0041868:	682b      	ldr	r3, [r5, #0]
d004186a:	b103      	cbz	r3, d004186e <_close_r+0x1a>
d004186c:	6023      	str	r3, [r4, #0]
d004186e:	bd38      	pop	{r3, r4, r5, pc}
d0041870:	d0041f38 	.word	0xd0041f38

d0041874 <_fstat_r>:
d0041874:	b538      	push	{r3, r4, r5, lr}
d0041876:	4d07      	ldr	r5, [pc, #28]	; (d0041894 <_fstat_r+0x20>)
d0041878:	2300      	movs	r3, #0
d004187a:	4604      	mov	r4, r0
d004187c:	4608      	mov	r0, r1
d004187e:	4611      	mov	r1, r2
d0041880:	602b      	str	r3, [r5, #0]
d0041882:	f7fe fc25 	bl	d00400d0 <_fstat>
d0041886:	1c43      	adds	r3, r0, #1
d0041888:	d102      	bne.n	d0041890 <_fstat_r+0x1c>
d004188a:	682b      	ldr	r3, [r5, #0]
d004188c:	b103      	cbz	r3, d0041890 <_fstat_r+0x1c>
d004188e:	6023      	str	r3, [r4, #0]
d0041890:	bd38      	pop	{r3, r4, r5, pc}
d0041892:	bf00      	nop
d0041894:	d0041f38 	.word	0xd0041f38

d0041898 <_isatty_r>:
d0041898:	b538      	push	{r3, r4, r5, lr}
d004189a:	4d06      	ldr	r5, [pc, #24]	; (d00418b4 <_isatty_r+0x1c>)
d004189c:	2300      	movs	r3, #0
d004189e:	4604      	mov	r4, r0
d00418a0:	4608      	mov	r0, r1
d00418a2:	602b      	str	r3, [r5, #0]
d00418a4:	f7fe fc3c 	bl	d0040120 <_isatty>
d00418a8:	1c43      	adds	r3, r0, #1
d00418aa:	d102      	bne.n	d00418b2 <_isatty_r+0x1a>
d00418ac:	682b      	ldr	r3, [r5, #0]
d00418ae:	b103      	cbz	r3, d00418b2 <_isatty_r+0x1a>
d00418b0:	6023      	str	r3, [r4, #0]
d00418b2:	bd38      	pop	{r3, r4, r5, pc}
d00418b4:	d0041f38 	.word	0xd0041f38

d00418b8 <_lseek_r>:
d00418b8:	b538      	push	{r3, r4, r5, lr}
d00418ba:	4d07      	ldr	r5, [pc, #28]	; (d00418d8 <_lseek_r+0x20>)
d00418bc:	4604      	mov	r4, r0
d00418be:	4608      	mov	r0, r1
d00418c0:	4611      	mov	r1, r2
d00418c2:	2200      	movs	r2, #0
d00418c4:	602a      	str	r2, [r5, #0]
d00418c6:	461a      	mov	r2, r3
d00418c8:	f7fe fc08 	bl	d00400dc <_lseek>
d00418cc:	1c43      	adds	r3, r0, #1
d00418ce:	d102      	bne.n	d00418d6 <_lseek_r+0x1e>
d00418d0:	682b      	ldr	r3, [r5, #0]
d00418d2:	b103      	cbz	r3, d00418d6 <_lseek_r+0x1e>
d00418d4:	6023      	str	r3, [r4, #0]
d00418d6:	bd38      	pop	{r3, r4, r5, pc}
d00418d8:	d0041f38 	.word	0xd0041f38

d00418dc <__malloc_lock>:
d00418dc:	4801      	ldr	r0, [pc, #4]	; (d00418e4 <__malloc_lock+0x8>)
d00418de:	f7ff be5d 	b.w	d004159c <__retarget_lock_acquire_recursive>
d00418e2:	bf00      	nop
d00418e4:	d0041f30 	.word	0xd0041f30

d00418e8 <__malloc_unlock>:
d00418e8:	4801      	ldr	r0, [pc, #4]	; (d00418f0 <__malloc_unlock+0x8>)
d00418ea:	f7ff be58 	b.w	d004159e <__retarget_lock_release_recursive>
d00418ee:	bf00      	nop
d00418f0:	d0041f30 	.word	0xd0041f30

d00418f4 <_read_r>:
d00418f4:	b538      	push	{r3, r4, r5, lr}
d00418f6:	4d07      	ldr	r5, [pc, #28]	; (d0041914 <_read_r+0x20>)
d00418f8:	4604      	mov	r4, r0
d00418fa:	4608      	mov	r0, r1
d00418fc:	4611      	mov	r1, r2
d00418fe:	2200      	movs	r2, #0
d0041900:	602a      	str	r2, [r5, #0]
d0041902:	461a      	mov	r2, r3
d0041904:	f7fe fbd6 	bl	d00400b4 <_read>
d0041908:	1c43      	adds	r3, r0, #1
d004190a:	d102      	bne.n	d0041912 <_read_r+0x1e>
d004190c:	682b      	ldr	r3, [r5, #0]
d004190e:	b103      	cbz	r3, d0041912 <_read_r+0x1e>
d0041910:	6023      	str	r3, [r4, #0]
d0041912:	bd38      	pop	{r3, r4, r5, pc}
d0041914:	d0041f38 	.word	0xd0041f38
d0041918:	544f4f54 	.word	0x544f4f54
d004191c:	43412048 	.word	0x43412048
d0041920:	62204548 	.word	0x62204548
d0041924:	20746f6f 	.word	0x20746f6f
d0041928:	6e6f7266 	.word	0x6e6f7266
d004192c:	646e6574 	.word	0x646e6574
d0041930:	73657420 	.word	0x73657420
d0041934:	74732074 	.word	0x74732074
d0041938:	69747261 	.word	0x69747261
d004193c:	0000676e 	.word	0x0000676e
d0041940:	42444953 	.word	0x42444953
d0041944:	4d20584f 	.word	0x4d20584f
d0041948:	43495355 	.word	0x43495355
d004194c:	584f4220 	.word	0x584f4220
d0041950:	00000000 	.word	0x00000000
d0041954:	544f4f42 	.word	0x544f4f42
d0041958:	4f524620 	.word	0x4f524620
d004195c:	4e45544e 	.word	0x4e45544e
d0041960:	00000044 	.word	0x00000044
d0041964:	50415247 	.word	0x50415247
d0041968:	53434948 	.word	0x53434948
d004196c:	49525020 	.word	0x49525020
d0041970:	4954494d 	.word	0x4954494d
d0041974:	54204556 	.word	0x54204556
d0041978:	00545345 	.word	0x00545345
d004197c:	52415453 	.word	0x52415453
d0041980:	3a505554 	.word	0x3a505554
d0041984:	414f4c2f 	.word	0x414f4c2f
d0041988:	20425744 	.word	0x20425744
d004198c:	20544f4e 	.word	0x20544f4e
d0041990:	4e554f46 	.word	0x4e554f46
d0041994:	00000044 	.word	0x00000044
d0041998:	20203130 	.word	0x20203130
d004199c:	544f4f42 	.word	0x544f4f42
d00419a0:	5345545f 	.word	0x5345545f
d00419a4:	4f4d2e54 	.word	0x4f4d2e54
d00419a8:	00000044 	.word	0x00000044
d00419ac:	20203230 	.word	0x20203230
d00419b0:	43204453 	.word	0x43204453
d00419b4:	20445241 	.word	0x20445241
d00419b8:	4e414353 	.word	0x4e414353
d00419bc:	4f4f5320 	.word	0x4f4f5320
d00419c0:	0000004e 	.word	0x0000004e
d00419c4:	20203330 	.word	0x20203330
d00419c8:	544f4f54 	.word	0x544f4f54
d00419cc:	48434148 	.word	0x48434148
d00419d0:	50412e45 	.word	0x50412e45
d00419d4:	00000050 	.word	0x00000050
d00419d8:	4f204f4e 	.word	0x4f204f4e
d00419dc:	55472053 	.word	0x55472053
d00419e0:	00000049 	.word	0x00000049
d00419e4:	544f4f54 	.word	0x544f4f54
d00419e8:	43412048 	.word	0x43412048
d00419ec:	46204548 	.word	0x46204548
d00419f0:	544e4f52 	.word	0x544e4f52
d00419f4:	20444e45 	.word	0x20444e45
d00419f8:	54534554 	.word	0x54534554
d00419fc:	43202d20 	.word	0x43202d20
d0041a00:	2045524f 	.word	0x2045524f
d0041a04:	50415247 	.word	0x50415247
d0041a08:	53434948 	.word	0x53434948
d0041a0c:	4c4e4f20 	.word	0x4c4e4f20
d0041a10:	00000059 	.word	0x00000059

d0041a14 <_global_impure_ptr>:
d0041a14:	d0041a84                                ....

d0041a18 <__sf_fake_stderr>:
	...

d0041a38 <__sf_fake_stdin>:
	...

d0041a58 <__sf_fake_stdout>:
	...

Disassembly of section .init:

d0041a78 <_init>:
d0041a78:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0041a7a:	bf00      	nop

Disassembly of section .fini:

d0041a7c <_fini>:
d0041a7c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
d0041a7e:	bf00      	nop
